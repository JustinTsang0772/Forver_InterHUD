














local a,b=...
local d,f,h,i=b.Blueprints,b.Share,b.Store,b.Schema

local a={}
b.Collections=a

local c,e={},{}

local function g(b)
local a={}
for c,b in ipairs(b.groups or{})do
for c,b in ipairs(b.members or{})do a[#a+1]=b end
end
for c,b in ipairs(b.loose or{})do a[#a+1]=b end
return a
end
a.members=g

function a.register(a,b)
assert(type(a)=="string"and not c[a],"collection registered twice or unnamed: "..tostring(a))
assert(type(b.class)=="string"and type(b.label)=="string","collection "..a..": class and label")
for c,b in ipairs(g(b))do
assert(type(b.premade)=="string","collection "..a..": a member names its pre-made")
assert(b.variant==nil,"collection "..a..": pre-mades have no variants yet")
local c=d.premade(b.premade)
assert(not(c and c.races),"collection "..a..": no racials ("..b.premade.."): a player adds their own")
end
c[a]=b
e[#e+1]=a
end
function a.keys()return e end
function a.get(a)return c[a]end
function a.forClass(d)
local a={}
for e,b in ipairs(e)do
if c[b].class==d then a[#a+1]=b end
end
table.sort(a,function(a,b)return c[a].label<c[b].label end)
return a
end


local function j(a)
local c=d.premade(a.premade)
if not c then return nil end
local c=d.makePremade(a.premade)
if a.off then c.enabled=false end
if a.position then c.position=b.copy(a.position)end
return c
end

function a.build(a,g,e)
e=e or{}
local a=assert(c[a],"no collection "..tostring(a))
local c,d={},{}
for a,e in ipairs(a.groups or{})do
local a={}
for c,d in pairs(e)do
if c~="members"then a[c]=b.copy(d)end
end
a.members={}
for d,b in ipairs(e.members or{})do
local b=j(b)
if b then
c[#c+1]=b
a.members[#a.members+1]=b.id
end
end
d[#d+1]=a
end
for b,a in ipairs(a.loose or{})do
local a=j(a)
if a then c[#c+1]=a end
end


local f=b.NewModel.className(a.class).." - "..a.label
if g=="profile"then
return{kind="profile",class=a.class,name=f,interhud=h.VERSION,
profile={elements=c,groups=d,specials=b.copy(a.specials),
styles=b.copy(a.styles)}}
end
return{kind="elements",class=a.class,name=f,interhud=h.VERSION,elements=c,
groups=d,styles=e.styles and b.copy(a.styles)or nil}
end

function a.check(b,c,d)
return f.checkEnvelope(a.build(b,c,d))
end


local function e(b)
local a={}
if b.stop then a[#a+1]={kind="refuse",path="",text=b.stop}end
for c,b in ipairs(b.refused or{})do a[#a+1]=b end
if#a==0 then a[1]={kind="refuse",path="",text="This collection can't be built."}end
return a
end

function a.use(c,b)
b=b or{}
local a=a.check(c,"profile")
if not a.ok then return false,e(a)end
local b,c=f.apply(a,{use=b.switch~=false})
return b,c,b and a.profileName or nil
end

function a.add(d,b)
b=b or{}
local a=a.check(d,"elements",b)
if not a.ok then return false,e(a)end


return f.apply(a,{styles=true,specials=c[d].specials})
end

function a.counts(a)
local a=assert(c[a],"no collection "..tostring(a))
local b,c=0,0
for e,a in ipairs(g(a))do
local a=d.premade(a.premade)
if a and i.holdsAlert(a.record)then c=c+1 elseif a then b=b+1 end
end
local d={}
for c,b in ipairs(i.fieldsOf("specials"))do
local a=a.specials and a.specials[b.name]
if a and a.enabled then d[#d+1]=b.label or b.name end
end
return{elements=b,alerts=c,groups=#(a.groups or{}),specials=d}
end
