


local b,a=...
local b=a.Collections

local function a(a,b)
local a={premade="shaman-"..a}
for b,c in pairs(b or{})do a[b]=c end
return a
end

b.register("shaman-standard",{
class="SHAMAN",
label="Standard",

line="A collection based on the ShamanForever addon defaults.",
groups={
{id="main",name="Main",scale=1.2,position={point="CENTER",x=0,y=-180},
members={a("shields"),a("shocks"),a("firenova"),a("stormstrike"),a("chainlightning"),a("riptide")}},

{id="procs",name="Procs",position={point="CENTER",x=0,y=-108},
members={a("elementalfocus"),a("flurry",{off=true}),a("maelstrom"),
a("improvedstormstrike",{off=true})}},
{id="cures",name="Cures",scale=1.4,position={point="CENTER",x=-379,y=146.5},
members={a("curepoison"),a("curedisease")}},
{id="prep",name="Prep",scale=1.4,position={point="CENTER",x=0,y=292},
members={a("imbue")}},
{id="target",name="Target",position={point="CENTER",x=202,y=-88},
members={a("flameshock"),a("purge")}},
{id="totems",name="Totems",growFrom="end",position={point="CENTER",x=-159,y=-92},
members={a("earthbind"),a("stoneclaw"),a("grounding")}},
{id="cooldowns",name="Cooldowns",scale=1.1,position={point="CENTER",x=-588,y=-90},
members={a("manatide"),a("farseer"),a("naturesswiftness")}},
{id="survival",name="Survival",arrangement="column",growFrom="start",["while"]="game.inCombat",
otherwise=40,position={point="CENTER",x=-608,y=-236},
members={a("reincarnation")}},
{id="utility",name="Utility",position={point="CENTER",x=-639.5,y=-207.5},
members={a("waterwalking"),a("waterbreathing")}},
},
loose={
a("projection",{position={point="CENTER",x=-548,y=-178}}),
a("stormstrike-alert",{position={point="CENTER",x=6.5,y=197}}),
a("elementalfocus-alert",{position={point="CENTER",x=0,y=71.5}}),
a("maelstrom-alert",{position={point="CENTER",x=0,y=-7}}),
},
specials={

totemBar={enabled=true},
},
})
