






local b,a=...
local f=a.Schema
local d=a.Layers
local c=a.Styles
local e=a.Media





local b={"ring",true}
local b=d.registerPart("border",{label="Border",rung="border",rides=true,
fields={f.styleField("border"),

{name="ring",type="boolean",default=false,group="ring",label="Ring inside"},
{name="ringColour",type="colour",default="#ffffff",under=b,group="ring",label="Ring colour"},
{name="ringSize",type="number",default=3,min=1,max=6,step=1,unit="px",under=b,
group="ring",label="Ring thickness"}},

changes={{name="colour",type="colour",label="Colour"},
{name="ring",type="boolean",group="ring",label="Ring inside"},
{name="ringColour",type="colour",under=b,group="ring",label="Ring colour"},
{name="ringSize",type="number",under=b,group="ring",label="Ring thickness"}}})

d.attach("bar","border","border")

local f={0,0,0,1}
local i={0.71,0.55,0.29,1}
local g,h,j={0.85,0.68,0.39,1},{0.43,0.29,0.13,1},{0.10,0.07,0.03,1}









c.kind("border","line",{label="Line",uses={thickness=true,colour=true},
rings={{px="thickness",colour="colour"}}})
c.kind("border","hairline",{label="Gold hairline",
rings={{colour=f},{colour=i,takesState=true},{colour=f}}})
c.kind("border","bevel",{label="Bronze bevel",uses={thickness=true},
rings={{colour=f},{px="thickness",top=g,left=g,bottom=h,
right=h,takesState=true},{colour=j}}})
c.kind("border","button",{label="Forever action button",
mask={atlas="UI-HUD-ActionBar-IconFrame-Mask",scale=64/45},swipeInset=3/45,
art={atlas="UI-HUD-ActionBar-IconFrame",inset={0,1/45,0,0},

opening={2/46,5/46,2/45,4/45},edge={0,3/46,0,2/45},

corner=5/47},
})
c.kind("border","cdm",{label="Cooldown Manager",
mask={atlas="UI-HUD-CoolDownManager-Mask"},swipe="Interface\\HUD\\UI-HUD-CoolDownManager-Icon-Swipe",
art={atlas="UI-HUD-CoolDownManager-IconOverlay",inset={0.18,0.18,0.16,0.16},opening=15/86,
edge=13/86,corner=0.06}})

local g=c.get("border","line")



local function h(d,e)
local b=a.Art.hasAtlas
local a=c.kindOf("border",d)
if(a.art and not b(a.art.atlas))or(a.mask and a.mask.atlas and not b(a.mask.atlas))
or(e and not a.rings)then
return g
end
return a
end


local function n(a,b,c)
local a=a.px=="thickness"and b.thickness or a.px or 1
return d.lineWidth(a,c)
end




function b.framing(c,d,e,a)
local b=h(c,a)
local a=0
for d,b in ipairs(b.rings or{})do a=a+n(b,c,e)end
if b.art then
local b=b.art.inset
local b=math.max(b[1],b[2],b[3],b[4])
a=math.max(a,d*b/(1+2*b))
end
return{inset=math.min(a,math.max((d-4)/2,0)),look=b}
end




local i=e.WHITE
function b.frameSwipe(c,h,e,a)
local b=e.framedBy and b.framing(e.framedBy,math.min(a.w,a.h),e.scale)or nil
local f,g=b and b.inset or 0,b and b.look or{}
local a=f+(g.swipeInset or 0)*(a.w-2*f)


if g.rings and f>0 then a=math.max(a-math.min(f,d.lineWidth(1,e.scale)),0)end
c:ClearAllPoints()
c:SetPoint("TOPLEFT",h,"TOPLEFT",a,-a)
c:SetPoint("BOTTOMRIGHT",h,"BOTTOMRIGHT",-a,a)
c:SetSwipeTexture(g.swipe or i)
return b
end



local function g(c,b,e,a)
local c,d=e-2*b.inset,c.art.inset
local b,c,d,f=b.inset-d[1]*c,b.inset-d[2]*c,b.inset-d[3]*c,b.inset-d[4]*c
local e,g=e-b-c,e-d-f
if type(a)~="table"then a={a,a,a,a}end
return{b+a[1]*e,c+a[2]*e,d+a[3]*g,f+a[4]*g}
end



function b.glowInset(a,c)
if not a.framedBy then return 0 end
local b=b.framing(a.framedBy,math.min(c.w,c.h),a.scale)
local a=b.look
if a.rings then return 0 end
if a.art and a.art.edge then return g(a,b,math.min(c.w,c.h),a.art.edge)end
return b.inset
end



function b.glowShape(a,c)
if not a.framedBy then return 0 end
local a=b.framing(a.framedBy,math.min(c.w,c.h),a.scale).look
if a.rings or not a.art then return 0 end
return a.art.corner or 0,a.mask
end

local function h(a,b)
if a=="colour"then return{e.rgba(b.colour)}end
return a or f
end

function b.routes(a,c,b)
return d.sideRoutes(a,d.partSockets(a,b,nil))
end






local i,c=3,4
local j=a.Art.MEDIA.."Line-Ring"
local k={a.Art.MEDIA.."Line-Top",a.Art.MEDIA.."Line-Bottom",a.Art.MEDIA.."Line-Left",
a.Art.MEDIA.."Line-Right"}
a.Debug.experimental("a border's rings as sliced textures on scaled holders, under an aura's button (FR-21; the"
.." line-border-2 run's R3 by eye only)","I")
local function f(b,d)
local b=b:CreateTexture(nil,"OVERLAY")
b:SetAllPoints()

b:SetTexture(d,"CLAMP","CLAMP","NEAREST")
b:SetTextureSliceMargins(c,c,c,c)
b:SetTextureSliceMode(a.Art.STRETCHED)
b:Hide()
return b
end
function b.create(a)
local c=CreateFrame("Frame",nil,a)
local function a()
local a=CreateFrame("Frame",nil,c)
local b={}
for c,d in ipairs(k)do b[c]=f(a,d)end
return{holder=a,whole=f(a,j),sides=b}
end
local d={}
for b=1,i do d[b]=a()end


local a=a()
a.holder:Hide()
local b=a.holder:CreateMaskTexture()
b:SetTexture(e.WHITE,"CLAMPTOBLACKADDITIVE","CLAMPTOBLACKADDITIVE")
b:SetAllPoints(a.holder)
a.whole:AddMaskTexture(b)
a.mask=b
local b=c:CreateTexture(nil,"OVERLAY")
b:Hide()
return{frame=c,rings=d,stateRing=a,art=b}
end
local function r(a,b)return assert(a.rings[b],"a border look with more rings than made")end



local function k(e,f,a,d,b,g)
local c=d/c
local d=e.holder
d:SetScale(c)
d:ClearAllPoints()

local i,j,k,l=a,a,a,a
if type(a)=="table"then i,j,k,l=a[1],a[2],a[3],a[4]end
d:SetPoint("TOPLEFT",f,"TOPLEFT",i/c,-k/c)
d:SetPoint("BOTTOMRIGHT",f,"BOTTOMRIGHT",-j/c,l/c)
d:Show()
local a={b.top,b.bottom,b.left,b.right}
local c=a[1]or a[2]or a[3]or a[4]
e.whole:SetShown(not c)
if not c then
local a=h(b.colour,g)
e.whole:SetVertexColor(a[1],a[2],a[3],a[4]or 1)
end
for d=1,4 do
local e=e.sides[d]
e:SetShown(c~=nil)
if c then
local a=h(a[d]or b.colour,g)
e:SetVertexColor(a[1],a[2],a[3],a[4]or 1)
end
end
end



local function o(b,d,a,f,g)
local a,c=b.mask,a.mask
a:ClearAllPoints()
if not c then
a:SetTexture(e.WHITE,"CLAMPTOBLACKADDITIVE","CLAMPTOBLACKADDITIVE")
a:SetAllPoints(b.holder)
return
end
local b=(f-2*g)*(c.scale or 1)/b.holder:GetScale()
a:SetAtlas(c.atlas,false,nil,nil,"CLAMPTOBLACKADDITIVE","CLAMPTOBLACKADDITIVE")
a:SetPoint("CENTER",d,"CENTER",0,0)
a:SetSize(b,b)
end

a.Debug.experimental("a ring inside a masked look: a ring whose mask is re-textured after its init, under an aura's"
.." button too (FR-10: only adding a mask is recorded)","I")



local function p(a,b,d)
local c=a.art
if not(c and c.opening)then return b.inset+(a.swipeInset or 0)*(d-2*b.inset)end
return g(a,b,d,c.opening)
end



local function f(c,a,f)
for b,a in ipairs(c.rings)do a.holder:Hide()end
c.art:Hide()
if not a.ring then
c.stateRing.holder:Hide()
return
end
local b=a.style and b.framing(a.style,f,a.scale,a.onBar)or{inset=0,look={}}
local g=b.look
k(c.stateRing,c.frame,p(g,b,f),
d.lineWidth(a.ringSize or 3,a.scale),{colour={e.rgba(a.ringColour or"#ffffff")}})
o(c.stateRing,c.frame,g,f,b.inset)
end

function b.apply(c,a,h,g)
if a.ringOnly then return f(c,a,math.min(g.w,g.h))end
local i=a.style
local l=math.min(g.w,g.h)
local b=b.framing(i,l,a.scale,a.onBar)
local f,h=b.look,c.frame



local q=a.colour and{e.rgba(a.colour)}or nil

local m,j=0,0
for d,b in ipairs(f.rings or{})do
local a=n(b,i,a.scale)
j=j+1
k(r(c,j),h,m,a,q and b.takesState and{colour=q}or b,
i)
m=m+a
end
for a=j+1,#c.rings do c.rings[a].holder:Hide()end

local e=a.ring and{colour={e.rgba(a.ringColour or"#ffffff")}}
if e then
k(c.stateRing,h,p(f,b,l),d.lineWidth(a.ringSize or 3,a.scale),e,
i)
o(c.stateRing,h,f,l,b.inset)
else
c.stateRing.holder:Hide()
end

if f.art then
local a,c,d=c.art,f.art.inset,g.w-2*b.inset
a:SetAtlas(f.art.atlas)
a:ClearAllPoints()
a:SetPoint("TOPLEFT",h,"TOPLEFT",b.inset-c[1]*d,-(b.inset-c[3]*d))
a:SetPoint("BOTTOMRIGHT",h,"BOTTOMRIGHT",-(b.inset-c[2]*d),b.inset-c[4]*d)
a:Show()
else
c.art:Hide()
end
end

function b.feed()end
