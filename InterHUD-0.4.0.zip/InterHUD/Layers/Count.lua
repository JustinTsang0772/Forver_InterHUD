




local a,d=...
local c,a=d.Layers,d.TextColours


local b,e,f=a.placeFields("BOTTOMRIGHT")
local b=c.registerPart("count",{label="Stack count",rung="text",serves={aura=true},fields={
{name="fromOne",type="boolean",default=false,label="Counts from 1"},
{name="colour",type="colour",default="#ffffff",label="Colour"},
a.fontField(),
a.sizeField(12),b,e,f,
},changes={{name="colour",type="colour",label="Colour"}}})



b.buttonText=function()return true end



function b.routes(a,b)
if a~="present"then return{}end
local a=c.sideRoutes(a,{"applicationCount"})
a[1].shape=b.fromOne and"fromOne"or nil
return a
end



function b.colourByCount()return true end

function b.handedColours(b,d,e)
local c=c.recordOf(b,d)
return a.mapOf(b,d,c,e,c.fromOne and 1 or 2)
end

function b.create(b)
local b=CreateFrame("Frame",nil,b)
local a=a.fontString(b)
a:SetWordWrap(false)
return{frame=b,fs=a}
end

function b.apply(c,b,e,f)
local f=b.fontSize or 12
a.place(c.fs,c.frame,b.point or"BOTTOMRIGHT",b.x,b.y)
if b.style then d.Media.setFont(c.fs,b.style,f)else c.fs:SetFont(STANDARD_TEXT_FONT,f,"OUTLINE")end

c.fs:SetTextColor(d.Media.rgba(b.colour or"#ffffff"))
c.fromOne=b.fromOne
c.colours=a.coloursFor(e,b)
a.rehand(c,e)
end


function b.feed(b,a)
if a.stacks==nil then return end
local c=b.fromOne and 1 or 2
b.fs:SetText(a.stacks and a.stacks>=c and tostring(a.stacks)or"")
end

function b.handOver(b,c,d)a.handCount(b,c,d)end
