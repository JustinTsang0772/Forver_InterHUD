




local a,c=...
local a,g,h,b,i=c.Schema,c.Layers,c.Media,c.Art,c.Styles


local function n(b,a)
for b,d in ipairs(b.groups)do
c.try("effect hand-off "..b,a.AddAuraAssignedAnimation,a,d)
end
end



local function k(a)
local d=CreateFrame("Frame",nil,a)
local a=CreateFrame("Frame",nil,d)
a:SetAllPoints()
a:SetAlpha(0)
local b=a:CreateAnimationGroup()
local c=b:CreateAnimation("Alpha")
c:SetFromAlpha(1)
c:SetToAlpha(1)
return{frame=d,fx=a,anim=b,life=c,groups={b},on={}}
end


local function l(a)
for b,a in ipairs(a.groups)do a:Stop()end
for c,b in ipairs(a.groups)do
if a.on[b]then b:Play()end
end
end



local f=g.registerEffect("pop",{label="Pop",fields={a.overField(),a.styleField("pop")}})




local e={atlas="ArtifactsFX-YellowRing",file="Interface\\Buttons\\UI-ActionButton-Border",side="front",
layer="OVERLAY",add=true,desat=true,from=0.9,to=2.2,dur=0.45,a=1}
local j={atlas="AftLevelup-WhiteStarBurst",file="Interface\\Cooldown\\star4",side="front",
layer="BACKGROUND",add=true,desat=true,from=1.2,to=3.5,dur=0.45,a=1,spin=-0.5}

local d,m=1.08,0.6
local o={file=b.MEDIA.."Disc-Dark",side="back",layer="BACKGROUND",sub=-1,dark=true,
from=2.6*0.55,to=2.6*0.95,dur=0.6*1.1,a=0.75,slow=true}
local p={file=b.MEDIA.."Rune-Ring",side="back",layer="ARTWORK",add=true,from=1.05,to=2.6,
dur=0.62,a=1,spin=0.55}
local d={file=b.MEDIA.."Rune-Ring",side="back",layer="BACKGROUND",dark=true,
from=1.05*d,to=2.6*d,dur=0.62,a=m,spin=0.55}
local m={file=b.MEDIA.."Spark",side="front",layer="OVERLAY",add=true,from=1.2,to=2.2,
dur=0.35,a=0.8,colour={1,1,1}}
local p={ring=e,star=j,disc=o,rune=p,runeDark=d,spark=m}
local q={"ring","star","disc","rune","runeDark","spark"}

local o={none={},ring={"ring"},star={"star"},both={"ring","star"},
rune={"disc","rune","runeDark","spark"}}
local j=0.01

local function r(c,a)
local c=c:CreateTexture(nil,a.layer,nil,a.sub or 0)
if a.atlas and b.hasAtlas(a.atlas)then c:SetAtlas(a.atlas)else c:SetTexture(a.file)end
c:SetBlendMode(a.add and"ADD"or"BLEND")
c:SetDesaturated(a.desat and true or false)
c:SetAlpha(0)
c:Hide()
local d=c:CreateAnimationGroup()
d:SetToFinalAlpha(true)
local a={tex=c,group=d,spec=a}
a.wait=b.anim(d,"Alpha")
a.wait:SetFromAlpha(0)
a.wait:SetToAlpha(0)
a.grow=b.anim(d,"Scale")
a.grow:SetSmoothing("OUT")
a.grow:SetScaleFrom(1,1)
a.fade=b.anim(d,"Alpha")
a.fade:SetToAlpha(0)
a.turn=b.anim(d,"Rotation")
a.turn:SetSmoothing("OUT")
a.move=b.anim(d,"Translation")
a.move:SetSmoothing("OUT")
return a
end


local d={0,0,0}
local function s(a,g,e,h,f,i)
local b,c=a.spec,a.tex
local d=b.dark and d or b.colour or h
c:SetVertexColor(d[1],d[2],d[3])
c:ClearAllPoints()
c:SetPoint("CENTER",g,"CENTER",0,0)
local d=e*b.from*i
c:SetSize(d,d)
local c=b.to/b.from
a.grow:SetScaleTo(c,c)
a.move:SetOffset(0,e*(b.rise or 0))
a.fade:SetFromAlpha(b.a)
a.fade:SetSmoothing(b.slow and"IN"or"NONE")
a.turn:SetDegrees(math.deg(b.spin or 0))
local b,c=math.max((b.delay or 0)*f,j),b.dur*f
a.wait:SetDuration(b)
for d,a in ipairs({a.grow,a.fade,a.turn,a.move})do
a:SetStartDelay(b)
a:SetDuration(c)
end
return b+c
end





local m=4
local function t(a)
local a={scaleG=a:CreateAnimationGroup(),moveG=a:CreateAnimationGroup(),scale={},move={}}
for c=1,m do
a.scale[c]=b.anim(a.scaleG,"Scale",c)
a.move[c]=b.anim(a.moveG,"Translation",c)
end
return a
end
local function d(a,d,b,c,e,f)
local a=a.scale[d]
a:SetScaleFrom(1,1)
a:SetScaleTo(c/b,c/b)
a:SetDuration(e)
a:SetSmoothing(f)
end
local function e(a,b,c,d,e,f)
local a=a.move[b]
a:SetOffset(c,d)
a:SetDuration(e)
a:SetSmoothing(f)
end

local function u(a,f,c,b,k)
local h,i,g=0,0,0
if f=="grow"then
d(a,1,1,c,0.12*b,"OUT")
d(a,2,c,1,0.25*b,"IN_OUT")
h,g=2,0.37*b
elseif f=="hop"then
local c=k*(c-1)*0.8
e(a,1,0,c,0.12*b,"OUT")
e(a,2,0,-c,0.2*b,"IN")
i,g=2,0.32*b
elseif f=="shake"or f=="shakeV"then
local c=k*(c-1)*0.3
local c,d=f=="shake"and c or 0,f=="shakeV"and c or 0
e(a,1,c,d,0.04*b,"NONE")
e(a,2,-2*c,-2*d,0.07*b,"NONE")
e(a,3,2*c,2*d,0.07*b,"NONE")
e(a,4,-c,-d,0.05*b,"NONE")
i,g=4,0.23*b
elseif f=="bounce"then
local e,f=1-(c-1)*0.25,1+(c-1)*0.15
d(a,1,1,c,0.12*b,"OUT")
d(a,2,c,e,0.12*b,"IN_OUT")
d(a,3,e,f,0.1*b,"IN_OUT")
d(a,4,f,1,0.08*b,"IN")
h,g=4,0.42*b
end
for b=h+1,m do d(a,b,1,1,j,"NONE")end
for b=i+1,m do e(a,b,0,0,j,"NONE")end
return{[a.scaleG]=h>0 or nil,[a.moveG]=i>0 or nil},g
end



function f.shape(a,b)
return b and a.style.motion~="none"and"moves"or nil
end
c.Debug.experimental("a pop handed to an aura's button whole: a dozen groups, the rune circle's back parts a level"
.." under the button's (AU-7: T 70374, by eye)","T")





function f.create(a,e,d,c)
local a=k(a)
a.flash=b.plainFlash(a.fx)
a.edge=b.edgeFlash(a.fx)
a.front=CreateFrame("Frame",nil,a.fx)
a.front:SetAllPoints()
a.back=CreateFrame("Frame",nil,a.fx)
a.back:SetAllPoints()
a.groups[#a.groups+1]=a.flash.group
for c,b in ipairs(a.edge or{})do a.groups[#a.groups+1]=b.group end
a.parts={}
for c,b in ipairs(q)do
local c=p[b]
local c=r(c.side=="back"and a.back or a.front,c)
a.parts[b]=c
a.groups[#a.groups+1]=c.group
end
if d.shape=="moves"and c then
a.motion=t(c.frame)
a.groups[#a.groups+1]=a.motion.scaleG
a.groups[#a.groups+1]=a.motion.moveG
end
return a
end

function f.apply(a,d,c,e)
local d=d.style
a.fx:SetFrameLevel(c.level+1)
a.front:SetFrameLevel(c.level+2)
a.back:SetFrameLevel(math.max(c.backLevel or 0,0))
local h,i,k=h.rgba(d.colour)
local m,g,l={h,i,k},1/math.max(d.speed,0.1),e.h
local e={}
a.on=e
e[a.anim]=true
local c=0
if a.motion then
local a,b=u(a.motion,d.motion,d.size,g,l)
for a in pairs(a)do e[a]=true end
c=b
end

local f=d.flash
if f=="edge"and not a.edge then f="plain"end
for b,a in ipairs(a.edge or{})do a.tex:SetShown(f=="edge")end
a.flash.tex:SetShown(f=="plain")
if f=="edge"then
b.styleEdge(a.edge,l,h,i,k,g)
for b,a in ipairs(a.edge)do e[a.group]=true end
c=math.max(c,b.EDGE_LENGTH*g)
elseif f=="plain"then
c=math.max(c,b.stylePlain(a.flash,h,i,k,0.8,g))
e[a.flash.group]=true
end
local f={}
for b,a in ipairs(o[d.burst]or o.none)do f[a]=true end
for h,b in pairs(a.parts)do
b.tex:SetAlpha(0)
b.tex:SetShown(f[h]==true)
if f[h]then
c=math.max(c,s(b,b.spec.side=="back"and a.back or a.front,l,m,g,d.reach))
e[b.group]=true
end
end
a.length=math.max(c,j)
a.life:SetDuration(a.length)
end

f.play,f.handOver=l,n
function f.feed()end



local d=g.registerEffect("flash",{label="Flash",fields={a.overField(),a.styleField("flash")}})
i.kind("flash","plain",{label="Plain flash"})
i.kind("flash","edge",{label="Blizzard's edge flash"})


local function e(a)
local a=i.kindOf("flash",a)==i.get("flash","edge")and"edge"or"plain"
if a=="edge"and not b.hasAtlas(b.EDGE_ATLAS)then a="plain"end
return a
end

function d.shape(a)return e(a.style)end

function d.create(a,c)
local a=k(a)
a.look=e(c.style)
if a.look=="edge"then a.edge=b.edgeFlash(a.fx)end
if a.edge then
for c,b in ipairs(a.edge)do a.groups[#a.groups+1]=b.group end
else
a.flash=b.plainFlash(a.fx)
a.groups[#a.groups+1]=a.flash.group
end
for c,b in ipairs(a.groups)do a.on[b]=true end
return a
end

function d.apply(a,c,d,g)
a.fx:SetFrameLevel(d.level+1)
local d,e,f=h.rgba(c.style.colour)
local c
if a.edge then
b.styleEdge(a.edge,g.h,d,e,f,1)
c=b.EDGE_LENGTH
else
c=b.stylePlain(a.flash,d,e,f,0.8,1)
end
a.length=c
a.life:SetDuration(c)
end
d.play,d.handOver=l,n
function d.feed()end











local function d(a)
local a=a and a.says
if a==""then return"Left empty, it shows nothing: the game hides this cast's name."end
if type(a)=="string"then return"Left empty, it shows \""..a.."\"."end
if a==false then return"Left empty, it shows the spell's name."end
return"Left empty, it shows the spell's name and \"!\". A source with no spell shows nothing."
end
local e,f=1,0.35
local i=40
local m,j=1.6,0.15
c.Debug.experimental("the text effect's Pops in: a Scale on a frame inside the translating riser, in a fight (FR-9"
.." proves the rise and the fade only and warns against nesting a Scale or Translation under it; FR-19: each"
.." region scales about its own centre)","I")
local n,o=c.TextColours.nudgeFields()
local a=g.registerEffect("text",{label="Text",plainMoments=true,fields={
a.overField(),
{name="text",type="string",max=64,label="Text",help=d(nil),



helpFrom=function(c,b)
if type(b)~="table"or b[1]~="sources"or b[3]~="events"then return d(nil)end
local c=c.sources and c.sources[b[2]]
local a=c and a.variantOf(c)
return d(a and a.events and a.events[b[4]]or nil)
end},
{name="colour",type="colour",default="#ffd100",label="Colour"},
c.TextColours.fontField(),

c.TextColours.sizeField(),
{name="starts",type="choice",choices={"above","middle","below"},default="above",
labels={above="Above it",middle="On it",below="Below it"},group="place",label="Starts"},
n,o,

{name="travels",type="choice",choices={"up","down","left","right","none"},default="up",
labels={up="Up",down="Down",left="Left",right="Right",none="Stays still"},group="motion",
label="Travels"},
{name="distance",type="percent",default=i,min=0,max=400,
under={"travels",{"up","down","left","right"}},group="motion",label="Distance",
help="How far it travels, as a share of the height of what it plays over (its \"Over\" setting)."},
{name="pace",type="choice",choices={"slows","steady","quickens"},default="slows",
labels={slows="Slows down",steady="Steady",quickens="Speeds up"},
under={"travels",{"up","down","left","right"}},group="motion",label="Pace"},
{name="lasts",type="number",default=e,min=0.3,max=5,step=0.1,unit="s",
group="motion",label="Lasts",help="How long it stays on screen, the fade included."},

{name="holds",type="number",default=f,min=0,max=5,step=0.05,unit="s",
group="motion",label="Fades after",help="How long it shows in full before it starts to fade. The fade"
.." takes the rest of \"Lasts\"; set longer than \"Lasts\", it fades only at the very end."},
{name="popsIn",type="boolean",default=false,group="motion",label="Pops in",
help="It starts larger and quickly settles to its size."},
}})

function a.create(a)
local a=k(a)
a.riser=CreateFrame("Frame",nil,a.fx)
a.riser:SetAllPoints()


a.spot=CreateFrame("Frame",nil,a.riser)
a.spot:SetSize(1,1)
a.fs=c.TextColours.fontString(a.spot)
a.fs:SetWordWrap(false)
local c=a.riser:CreateAnimationGroup()
a.rise=b.anim(c,"Translation")
a.fade=b.anim(c,"Alpha")
a.fade:SetFromAlpha(1)
a.fade:SetToAlpha(0)
local d=a.spot:CreateAnimationGroup()
a.pop=b.anim(d,"Scale")
a.pop:SetSmoothing("OUT")
a.pop:SetDuration(j)
a.pop:SetScaleTo(1,1)
a.popGroup=d
a.groups[#a.groups+1]=c
a.groups[#a.groups+1]=d
for c,b in ipairs(a.groups)do a.on[b]=true end
return a
end



local function d(a)
if a.words~=nil then return a.words end
if type(a.says)=="string"then return a.says end
if a.says==false then return a.name or""end
return a.name and(a.name.."!")or""
end


local j={above={"TOP","BOTTOM",2},middle={"CENTER","CENTER",0},below={"BOTTOM","TOP",-2}}

local k={up={0,1},down={0,-1},left={-1,0},right={1,0},none={0,0}}
local n={slows="OUT",steady="NONE",quickens="IN"}
function a.apply(a,b,g,l)
a.fx:SetFrameLevel(g.level+1)
h.setFont(a.fs,b.style,c.TextColours.sizeOf(b))
a.fs:SetTextColor(h.rgba(b.colour or"#ffd100"))
a.words,a.says=b.text,g.says
a.fs:SetText(d(a))
local c=j[b.starts]or j.above
a.spot:ClearAllPoints()
a.spot:SetPoint("CENTER",a.riser,c[1],b.x or 0,(b.y or 0)+c[3])
a.fs:ClearAllPoints()
a.fs:SetPoint(c[2],a.spot,"CENTER",0,0)
local d=k[b.travels]or k.up
local g=l.h*(b.distance or i)/100
local c=b.lasts or e

local e=math.min(b.holds or f,c-0.05)
a.rise:SetOffset(d[1]*g,d[2]*g)
a.rise:SetSmoothing(n[b.pace]or"OUT")
a.rise:SetDuration(c)
a.fade:SetStartDelay(e)
a.fade:SetDuration(c-e)
local d=b.popsIn and m or 1
a.pop:SetScaleFrom(d,d)
a.on[a.popGroup]=b.popsIn==true
a.length=c
a.life:SetDuration(c)
end
a.play=l

function a.feed(b,a)
if a.name==nil then return end
local a=a.name
if c.isSecret(a)or type(a)~="string"or a==""then a=nil end
b.name=a
b.fs:SetText(d(b))
end

g.registerEffect("sound",{label="Sound",
fields={{name="sound",type="sound",label="Sound"}}})
