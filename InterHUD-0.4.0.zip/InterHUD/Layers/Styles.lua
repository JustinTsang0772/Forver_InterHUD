




local a,c=...
local b=c.Schema

local a={}
c.Styles=a

local d,e={},{}



local function g(b,a)return a.ownStyle==true end





local f={{name="preset",type="id",label="Preset"}}
local function h(b,a)
if a.ownStyle==true then return f end
end
local function i(a)
if a=="preset"then
return"is taken only by a style set on an element, a layer, an effect or a special; Global's and a preset's"
.." never follow a preset."
end
return"isn't a field here."
end





local function j(f)
return function(b,a,c)
if b.preset==nil then return end
local e={}
for a in pairs(b)do
if a~="preset"then e[#e+1]=a end
end
if#e>0 and a.mode=="edit"then
a:problem(c,"follows a preset; it takes no settings beside it.")
return
elseif#e>0 then
for c,a in ipairs(e)do b[a]=nil end
if a:strict()then
a:note(c,"follows its preset; its own settings are left out.")
else
a.dropped=a.dropped+1
end
end
local e=a.vars.presets

if e==nil and a.mode=="edit"then
a:problem(c,"names a preset that can't be checked here.")
return
end
if e==nil then return end
for c,a in ipairs(e and e[f]or{})do
if a.id==b.preset then return end
end
local d=string.format("names no %s preset %q",d[f].label,b.preset)
if a.mode=="edit"then
a:problem(c,d..".")
return
end
b.preset=nil
if a:strict()then
a:note(c,d.."; left out.")
else
a.dropped=a.dropped+1
end
end
end





function a.asOwn(d,e,f)
local g=a.recordOf(d)
local a=c.copy(e or{})
a.preset=nil

local d=setmetatable({ownStyle=true},{__index=f})
local e,i,h=b.frame(g,a,d)
if f and a.kind~=nil then
for b,d in ipairs(e)do
if d.name=="kind"then
local b=false
for d,c in ipairs(c.Clean.choicesOf(d,a,h))do b=b or c==a.kind end
if not b then a.kind=nil end
end
end
e=b.frame(g,a,d)
end
for e,b in ipairs(e)do
if a[b.name]==nil and b.keep and b.keep(a,d)then a[b.name]=c.Clean.defaultOf(b,a,d)end
end
return a
end









local f={}
function a.part(a,c)
assert(not d[a],"style part declared twice: "..a)
d[a]=c
e[a]={}
f[#f+1]=a
local d={}
if c.kinds then
b.choiceSet("style:"..a,{},c.default)
local f=b.choicesOf("style:"..a)

local h=f
if c.offers then
h=function(g,d)
local b={}
for g,f in ipairs(f(g,d))do
if c.offers(e[a][f],d)then b[#b+1]=f end
end
return b
end
end
d[1]={name="kind",type="choice",choicesFrom=h,
labels=b.choiceLabels("style:"..a),keep=g,
defaultFrom=function()return b.choiceDefault("style:"..a)end,
label=c.label}
end
for b,a in ipairs(c.fields or{})do
if c.kinds and not a.everyKind then a.under={"kind",{}}end

if a.key then a.keep=g end
d[#d+1]=a
end


b.record(c.record or("style:"..a),{
fields=d,
after=c.kinds and{"kind"}or nil,

variantOf=c.kinds and function(c)return c.kind or b.choiceDefault("style:"..a)end or nil,
extra=not c.record and h or nil,
unknown=not c.record and i or nil,
})
if not c.record then b.rule("style:"..a,"preset",j(a))end
end

function a.recordOf(a)
local b=d[a]
return b and b.record or("style:"..a)
end

function a.isLook(a)
local a=d[a]
return a~=nil and a.record~=nil
end



function a.kind(a,c,f)
local d=assert(d[a],"no style part "..tostring(a))
assert(d.kinds and not e[a][c],a..": kind registered twice, or the part has none: "..c)
e[a][c]=f
b.choiceSet("style:"..a,{c},nil,{[c]=f.label})
b.variant("style:"..a,c,f.fields,f)
local d=b.get("style:"..a)
for b in pairs(f.uses or{})do
local a=assert(d.byName[b],a.."."..c.." uses no setting "..b)
local a=a.under[2]
a[#a+1]=c
end
return f
end

function a.spec(a)return d[a]end


function a.ranked()
local a,b={},{}
for c,d in ipairs(f)do
a[c]=d
b[d]=c
end
table.sort(a,function(a,c)
local d,e=d[a].rank or math.huge,d[c].rank or math.huge
if d~=e then return d<e end
return b[a]<b[c]
end)
return a
end





local f={WARRIOR=78,PALADIN=635,HUNTER=3044,ROGUE=1752,PRIEST=585,SHAMAN=8042,
MAGE=133,WARLOCK=686,DRUID=8921}
local g=8690
local h=36
function a.sampleSpell()
local a=UnitClass and select(2,UnitClass("player"))
a=type(a)=="string"and f[a]
if a then
local d,b=c.try("GetSpellTexture",C_Spell.GetSpellTexture,a)
if d and b~=nil and not c.isSecret(b)then return a end
end
return g
end






function a.sample(e)
local b=d[e]and d[e].sample
if not b then return nil end
local a={id="sample-"..e:lower(),baseSize=h,
sources={{id="spell",kind="spell",spells={a.sampleSpell()},layers=c.copy(b.layers),
events=b.events and c.copy(b.events)}}}
local b={picks={spell={state=b.state or"ready",facts=b.facts and c.copy(b.facts)or{}}},
plays=b.plays and{source="spell",event=b.plays}or nil}
return a,b
end

function a.get(a,b)
return e[a]and e[a][b]
end


function a.kindOf(c,d)
return a.get(c,d and d.kind)or a.get(c,b.choiceDefault("style:"..c))
end



local e={{kind="icon"}}
local c={point="CENTER"}
local function f(a)
return{layers=e,events={comesReady={effects={{id=a,kind=a}}}},state="ready",
plays="comesReady"}
end
a.part("border",{label="Border",kinds=true,default="line",rank=10,
help="Every icon's and bar's border.",
sample={layers=e,state="ready"},


offers=function(b,a)return b.rings~=nil or not(a.layer and a.layer.kind=="bar")end,fields={
{name="colour",type="colour",default="#000000",label="Colour"},
{name="thickness",type="number",default=2,min=1,max=8,step=1,unit="px",label="Thickness"},
}})


a.part("sweep",{label="Sweep",rank=15,help="Every icon's cooldown or duration sweep.",
sample={layers=e,state="coolingDown"},fields={
{name="colour",type="colour",default="#000000a3",label="Colour"},
{name="edge",type="boolean",default=false,label="Edge line"},
{name="edgeColour",type="colour",default="#ffffff",under={"edge",true},label="Edge colour"},
{name="edgeScale",type="number",default=1,min=0.5,max=2,step=0.1,unit="x",
under={"edge",true},label="Edge width"},
{name="gcdColour",type="colour",default="#00000099",label="GCD sweep colour"},
}})
a.part("glow",{label="Glow",kinds=true,default="soft",rank=30,help="Every glow.",
sample={layers={{kind="icon",glows={{id="glow",shown=true}}}},state="ready"},fields={
{name="colour",type="colour",default="#ffcc40",label="Colour"},
{name="speed",type="number",default=0.5,min=0.2,max=2,step=0.1,unit="x",label="Speed"},
{name="low",type="number",default=0.25,min=0,max=1,step=0.05,label="Faintest"},
{name="reach",type="number",default=0.2,min=0.1,max=0.5,step=0.05,label="Reach"},
{name="lap",type="number",default=1.6,min=0.6,max=4,step=0.1,unit="s",label="Lap time"},
}})


local function g(a)
return function(b,c)return b.motion~="none"and c.motion==a end
end
a.part("pop",{label="Pop",rank=50,help="Every pop.",sample=f("pop"),limits={
{setting="motion",cant=g("button"),
text="Motion effects don't play on a buff's or debuff's icon, due to addon limitations."},
{setting="motion",cant=g("still"),
text="Motion effects don't play when a totem ends early or runs out, due to addon limitations."},
},fields={
{key=true,name="flash",type="choice",choices={"none","plain","edge"},default="edge",
labels={none="None",plain="Plain flash",edge="Blizzard's edge flash"},label="Flash on pop",

help="Its own flash, apart from the Flash style."},
{key=true,name="burst",type="choice",choices={"none","ring","star","both","rune"},
default="both",labels={none="None",ring="Ring",star="Star",both="Ring and star",
rune="Rune circle"},label="Burst"},
{key=true,name="motion",type="choice",choices={"none","grow","bounce","hop","shake","shakeV"},
default="shakeV",labels={none="None",grow="Grow",bounce="Bounce",hop="Hop",
shake="Shake side to side",shakeV="Shake up and down"},label="Motion"},
{name="colour",type="colour",default="#ffd966",label="Colour"},
{name="size",type="number",default=1.6,min=1.1,max=1.8,step=0.05,unit="x",label="Size"},
{name="speed",type="number",default=1,min=0.5,max=2,step=0.1,unit="x",label="Speed"},
{name="reach",type="number",default=1,min=0.6,max=1.3,step=0.05,label="Reach"},
}})
a.part("flash",{label="Flash",kinds=true,default="edge",rank=40,help="Every flash.",
sample=f("flash"),fields={
{name="colour",type="colour",default="#ffffff",everyKind=true,label="Colour"},
}})

b.choiceSet("media:font",{})
a.part("font",{label="Font",rank=70,
help="Every text unless it sets its own. Size: not the icon's numbers, which have their own.",
sample={layers={{kind="text",content="name",position=c}},
state="ready"},fields={
{key=true,name="face",type="choice",choicesFrom=b.choicesOf("media:font"),open=true,
labels=b.choiceLabels("media:font"),
defaultFrom=function()return b.choiceDefault("media:font")end,label="Face"},
{name="outline",type="choice",choices={"none","outline","thick"},default="outline",
labels={none="None",outline="Outline",thick="Thick outline"},label="Outline"},
{name="shadow",type="boolean",default=true,label="Shadow"},


{name="size",type="number",default=12,min=6,max=48,step=1,unit="pt",label="Size"},
}})
a.part("barTexture",{label="Bar texture",rank=80,help="Every bar's fill.",

sample={layers={{kind="bar",value="time",fills=true,length=140,thickness=14,
position=c}},state="ready"},fields={
{key=true,name="texture",type="choice",choicesFrom=b.choicesOf("media:bar"),open=true,

defaultFrom=function()return"Blizzard"end,label="Texture"},
}})




local function c(d,c)
local g,f={"overlay",true},{"ring",true}
b.record("buttonCues",{fields={{name=d,type="record",record="buttonCue:"..d,label=c.label}}})
a.part(d,{label=c.label,help=c.help,rank=c.rank,record="buttonCue:"..d,

sample={layers=e,state="ready",facts={[d]=true}},
fields={
{key=true,name="tint",type="colour",default=c.tint or"#ffffff",label="Tint"},
{name="desaturated",type="boolean",default=false,label="Desaturated"},
{name="overlay",type="boolean",default=c.overlay~=nil,label="Overlay"},
{name="overlayColour",type="colour",default=c.overlay or"#00000080",under=g,
label="Overlay colour"},

{name="ring",type="boolean",default=c.ring~=nil,label="Ring inside"},
{name="ringColour",type="colour",default=c.ring or"#ffffff",under=f,label="Ring colour"},
{name="ringSize",type="number",default=c.ringSize or 3,min=1,max=6,step=1,unit="px",under=f,
label="Ring thickness"},
}})


b.record("layerCue:"..d,{fields={
{name="enabled",type="boolean",default=true,label="On"},
b.styleField(d,nil,"buttonCue:"..d),
}})
end
c("outOfRange",{label="Out of range",rank=60,tint="#ff4d4df2",
help="An icon while your target is out of its range."})
c("notEnoughPower",{label="Not enough power",rank=61,tint="#3333ff99",overlay="#3373ff26",
ring="#3373ff59",ringSize=2,help="An icon while you're short of its cost."})
c("notUsable",{label="Not usable",rank=62,tint="#666666",
help="A cooldown's icon while it can't be cast now (a stance, combat)."})




function a.cueFields()
local e={}
for f,c in ipairs(a.ranked())do
if a.isLook(c)then
local f={}
for d,a in ipairs(b.sourceKeys())do
local a=b.source(a)
local b=a.facts[c]
if b and b.look==c then f[a.layerKind or a.kind]=true end
end
e[#e+1]={name=c,type="record",record="layerCue:"..c,serves=f,
label=d[c].label.." look"}
end
end
return e
end
