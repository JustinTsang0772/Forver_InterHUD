



local a,b=...
local d,e,o,g,a=b.Schema,b.Layers,b.Styles,b.Media,b.Art



local c=e.registerPart("glow",{label="Glow",rung="glow",repeats=true,shown=false,
fields={d.styleField("glow")}})

e.attach("bar","glows","glow",{list=true,label="Glows"})









local function h(a,b)
local a=CreateFrame("Frame",nil,a)
a:SetAllPoints()
b.levelled[#b.levelled+1]=a
return a
end

local function f(b,a,c)
local a=a:CreateAnimationGroup()
if c then a:SetLooping(c)end
b.groups[#b.groups+1]=a
return a
end


local d=d.field("style:glow","colour").default
local function k(b,c,a)
local c=c.colour==d
b:SetDesaturated(not c)
if c then b:SetVertexColor(1,1,1,a[4])else b:SetVertexColor(a[1],a[2],a[3],a[4])end
end


local d=16
local function l(b,c,e)
local c=h(c,b)
local b=c:CreateTexture(nil,"OVERLAY")
b:SetAllPoints()
b:SetTexture(a.MEDIA.."Glow-Inner")
b:SetTextureSliceMargins(d,d,d,d)
b:SetTextureSliceMode(a.STRETCHED)
b:SetBlendMode("ADD")
return{frame=c,tex=b,alpha=e or 1}
end
local function m(b,a)
b.tex:SetVertexColor(a[1],a[2],a[3],a[4]*b.alpha)
end
local function n(e,f,a,c)
local b=math.min(a.w,a.h)
if b<=0 then return end
local b=math.min(math.max(b*(c or 0.2),1),b*0.45)
local c=b/d
local b=e.frame
b:SetScale(c)
b:SetSize(a.w/c,a.h/c)
b:ClearAllPoints()
b:SetPoint("CENTER",f.pulse,"CENTER",0,0)
end


local function i(a,d,b,c,e)
a:ClearAllPoints()
a:SetPoint("CENTER",d.pulse,"CENTER",0,0)
a:SetSize(b.w*c,b.h*(e or c))
end

local function p(b,c,a,d,e,f,g)
b:ClearAllPoints()
b:SetPoint("TOPLEFT",c.pulse,"TOPLEFT",-d*a.w,e*a.h)
b:SetPoint("BOTTOMRIGHT",c.pulse,"BOTTOMRIGHT",f*a.w,-g*a.h)
end

b.Debug.experimental("glows handed to an aura's button: flipbooks, the proc glow's burst aimed at the loop's frame"
.." too, the soft rim's SetScale, each new look's groups (AU-7 covers one plain pulse)","I")

b.Debug.experimental("Blizzard's art glows over the border (proc, assisted highlight, the Cooldown Manager's two):"
.." never seen over a red state border in game","I")


local function d(b,a,c)
for b,c in pairs(c or{})do a[b]=c end
a.key=b
return o.kind("glow",b,a)
end






local j={{1,0},{0,-1},{-1,0},{0,1}}
local q=0.001
b.Debug.experimental("a travelling spark's eight legs (two of them zero long on a ring look) and its rim's mask"
.." re-textured after the init, on a masked look","I")
d("spark",{label="Travelling spark",uses={colour=true,lap=true,reach=true},steady=true,
build=function(b)
b.soft=l(b,b.pulse,0.45)
local c=b.soft.frame:CreateMaskTexture()
c:SetTexture(g.WHITE,"CLAMPTOBLACKADDITIVE","CLAMPTOBLACKADDITIVE")
c:SetAllPoints(b.soft.frame)
b.soft.tex:AddMaskTexture(c)
b.soft.mask=c
b.sparks={}

local c=CreateFrame("Frame",nil,b.frame)
c:SetAllPoints()
b.overBorder=c
for d,g in ipairs({"TOPLEFT","BOTTOMRIGHT"})do
local c=c:CreateTexture(nil,"OVERLAY",nil,1)
c:SetTexture(a.MEDIA.."Spark")
c:SetBlendMode("ADD")
local f=f(b,c,"REPEAT")
local e={}
for b=1,8 do e[b]=a.anim(f,"Translation",b)end
b.sparks[d]={tex=c,steps=e,corner=g,dir=d==1 and 1 or-1}
end
end,
style=function(b,c,a)
m(b.soft,a)
for c,b in ipairs(b.sparks)do

b.tex:SetVertexColor(a[1]*0.5+0.5,a[2]*0.5+0.5,a[3]*0.5+0.5,a[4])
end
end,
fit=function(a,b,h)
n(a.soft,a,b,h.reach)
local e=math.min(b.w,b.h)

local c,d=a.soft.mask,a.shapeMask
c:ClearAllPoints()
if d and d.atlas then
local e=a.soft.frame:GetScale()
c:SetAtlas(d.atlas,false,nil,nil,"CLAMPTOBLACKADDITIVE","CLAMPTOBLACKADDITIVE")
c:SetPoint("CENTER",a.pulse,"CENTER",0,0)
c:SetSize(b.w*(d.scale or 1)/e,b.h*(d.scale or 1)/e)
else
c:SetTexture(g.WHITE,"CLAMPTOBLACKADDITIVE","CLAMPTOBLACKADDITIVE")
c:SetAllPoints(a.soft.frame)
end
local c=math.min((a.cornerShare or 0)*e,e/2)
local i,k=b.w-2*c,b.h-2*c
local l=2*(i+k)+4*c*math.sqrt(2)
for d,b in ipairs(a.sparks)do
b.tex:SetSize(e*0.5,e*0.5)
b.tex:ClearAllPoints()

b.tex:SetPoint("CENTER",a.pulse,b.corner,c*b.dir,0)
for f,m in ipairs(b.steps)do
local a=j[math.floor((f+1)/2)]
local d,e,g
if f%2==1 then
d,e=a[1]*i,a[2]*k
g=math.abs(d)+math.abs(e)
else

local b=j[f/2%4+1]
d,e=(a[1]+b[1])*c,(a[2]+b[2])*c
g=c*math.sqrt(2)
end
m:SetOffset(d*b.dir,e*b.dir)
m:SetDuration(l>0 and math.max(h.lap*g/l,q)or q)
end
end
end,
})


local q="UI-CooldownManager-ActiveGlow"
local j=1.07
b.Debug.experimental("the outer halo's breathing as two ordered Scale steps, repeating (the game's pulse's"
.." form, the second step a ratio; FR-9, FR-19), until seen smooth in game","C")
d("halo",{label="Outer halo",uses={colour=true,speed=true,low=true},
atlases={q},
build=function(c)
local b=c.pulse:CreateTexture(nil,"OVERLAY")
b:SetAtlas(q)
b:SetDesaturated(true)
b:SetBlendMode("ADD")


local d=f(c,b,"REPEAT")
local a,d=a.anim(d,"Scale",1),a.anim(d,"Scale",2)
a:SetScaleFrom(1,1)
a:SetScaleTo(j,j)
d:SetScaleFrom(1,1)
d:SetScaleTo(1/j,1/j)
a:SetSmoothing("IN_OUT")
d:SetSmoothing("IN_OUT")
c.halo,c.breath=b,{a,d}
end,
style=function(b,c,a)
b.halo:SetVertexColor(a[1],a[2],a[3],a[4])
for b,a in ipairs(b.breath)do a:SetDuration(c.speed)end
end,
fit=function(c,a)
local b=math.min(a.w,a.h)*0.24
p(c.halo,c,a,b/a.w,b/a.h,b/a.w,b/a.h)
end,
})


local q=d("soft",{label="Soft inner",uses={colour=true,speed=true,low=true,
reach=true},
build=function(a)a.soft=l(a,a.pulse)end,
style=function(a,c,b)m(a.soft,b)end,
fit=function(a,b,c)n(a.soft,a,b,c.reach)end,
})


local j=0.15
d("heartbeat",{label="Heartbeat",uses={colour=true,speed=true,low=true,reach=true},
build=function(b)
b.soft=l(b,b.pulse,0.6)
local c=h(b.frame,b)
local c=c:CreateTexture(nil,"OVERLAY")
c:SetTexture(a.MEDIA.."Glow-Outer")
c:SetBlendMode("ADD")
c:SetAlpha(0)
local e=f(b,c,"REPEAT")
local d=a.anim(e,"Scale")
d:SetScaleFrom(0.9,0.9)
d:SetScaleTo(1.65,1.65)
d:SetSmoothing("OUT")
local a,e=a.anim(e,"Alpha"),a.anim(e,"Alpha")
a:SetFromAlpha(0)
a:SetToAlpha(0.9)
a:SetSmoothing("OUT")
e:SetFromAlpha(0.9)
e:SetToAlpha(0)
e:SetSmoothing("OUT")
b.ring,b.beat=c,{d,a,e}
end,
style=function(a,c,b)
m(a.soft,b)
a.ring:SetVertexColor(b[1],b[2],b[3],b[4])
local b=c.speed*2
local c,d,a=a.beat[1],a.beat[2],a.beat[3]
c:SetDuration(b)
d:SetDuration(b*j)
a:SetStartDelay(b*j)
a:SetDuration(b*(1-j))
end,
fit=function(a,b,c)
n(a.soft,a,b,c.reach)

i(a.ring,a,b,1/0.68)
end,
})




local j,l="UI-HUD-ActionBar-Proc-Start-Flipbook","UI-HUD-ActionBar-Proc-Loop-Flipbook"
local m=0.7
d("proc",{label="Blizzard's proc glow",uses={colour=true},steady=true,over=true,
atlases={j,l},
build=function(b)
local d=h(b.pulse,b)
local c=d:CreateTexture(nil,"OVERLAY")
c:SetAtlas(l)
local e=a.flipBook(c,6,5,30,1,"REPEAT")
b.loop=c


if b.underButton then
b.groups[#b.groups+1]=e
return
end
local c=b.pulse:CreateTexture(nil,"OVERLAY")
c:SetAtlas(j)
local f=a.flipBook(c,6,5,30,m,nil,b.pulse)
local a=f:CreateAnimation("Alpha")
a:SetTarget(d)
a:SetFromAlpha(0)
a:SetToAlpha(0)
a:SetDuration(m)
b.groups[#b.groups+1]=f
b.groups[#b.groups+1]=e
b.start=c
end,
style=function(a,b,c)
k(a.loop,b,c)
if a.start then k(a.start,b,c)end
end,

fit=function(a,b)
i(a.loop,a,b,1.4)
if a.start then i(a.start,a,b,150/45)end
end,
})



local function j(d,b,c)
return{
build=function(b)
local c=b.pulse:CreateTexture(nil,"ARTWORK")
c:SetAtlas(d)
local a=a.flipBook(c,6,5,30,1,"REPEAT")
b.groups[#b.groups+1]=a
b.ants=c
end,
style=function(b,d,a)
if c then b.ants:SetVertexColor(a[1],a[2],a[3],a[4])else k(b.ants,d,a)end
end,
fit=function(a,c)b(a.ants,a,c)end,
}
end
local k,l="RotationHelper_Ants_Flipbook","VisualAlert_Ants_Flipbook"
d("ants",{label="Assisted highlight",uses={colour=true},steady=true,over=true,
atlases={k}},
j(k,function(a,b,c)i(a,b,c,66/45)end))

local function i(a,b,c)p(a,b,c,8/32,8/32,9/32,9/32)end
d("cdmAnts",{label="Cooldown Manager ants",uses={colour=true},steady=true,over=true,
atlases={l}},
j(l,i,true))



local j="UI-CooldownManager-VisualAlert-Glow"
d("cdmGlow",{label="Cooldown Manager glow",uses={colour=true,speed=true,low=true},over=true,
atlases={j},
build=function(a)
local b=a.pulse:CreateTexture(nil,"ARTWORK")
b:SetAtlas(j)
a.alert=b
end,
style=function(b,c,a)b.alert:SetVertexColor(a[1],a[2],a[3],a[4])end,
fit=function(a,b)i(a.alert,a,b)end,
})





local i,j=0.55,0.6
d("darkPulse",{label="Dark pulse",uses={},steady=true,
build=function(a)
local b=a.pulse:CreateTexture(nil,"ARTWORK")
b:SetColorTexture(0,0,0,1)
b:SetAllPoints(a.pulse)
b:SetAlpha(0)
local d=a.pulse:CreateMaskTexture()
b:AddMaskTexture(d)
local c=f(a,b,"BOUNCE")
local c=c:CreateAnimation("Alpha")
c:SetFromAlpha(0)
c:SetToAlpha(i)
c:SetDuration(j)
c:SetSmoothing("IN_OUT")
a.dark,a.darkMask=b,d
end,
style=function()end,
fit=function(c,d)
local a,b=c.darkMask,c.shapeMask
a:ClearAllPoints()
if b and b.atlas then
a:SetAtlas(b.atlas,false,nil,nil,"CLAMPTOBLACKADDITIVE","CLAMPTOBLACKADDITIVE")
a:SetPoint("CENTER",c.pulse,"CENTER",0,0)
a:SetSize(d.w*(b.scale or 1),d.h*(b.scale or 1))
else
a:SetTexture(g.WHITE,"CLAMPTOBLACKADDITIVE","CLAMPTOBLACKADDITIVE")
a:SetAllPoints(c.pulse)
end
end,
})
b.Debug.experimental("the dark pulse as a glow look: a black wash's alpha bounced 0 to 0.55 in the picture's shape,"
.." on a totem element's Expiring under its curve gate (the totem bar's look, TO-3; as a glow, unplayed)","I")


function c.kindOf(b)
local b=o.kindOf("glow",b)
for c,b in ipairs(b.atlases or{})do
if not a.hasAtlas(b)then return q end
end
return b
end

function c.routes(a,b)
local a=e.sideRoutes(a,{"shownAnimation"})

local b=c.kindOf(b.style).key
for c,a in ipairs(a)do a.shape=b end
return a
end


function c.create(b,e,a)
local b=CreateFrame("Frame",nil,b)
local a={frame=b,levelled={},groups={},underButton=a and a.underButton}
a.pulse=h(b,a)
local d=f(a,a.pulse,"BOUNCE")
local b=d:CreateAnimation("Alpha")
b:SetFromAlpha(1)
b:SetSmoothing("IN_OUT")
a.anim,a.fade=d,b
a.look=c.kindOf(e.style)
a.look.build(a)
return a
end

local function k(a)
for b,a in ipairs(a.groups)do
a:Stop()
a:Play()
end
end

function c.apply(a,f,i,c)

local b=i.level+e.RUNGS.border-e.RUNGS.glow+2


local d=a.look.over and b or i.level+1
for b,a in ipairs(a.levelled)do a:SetFrameLevel(d)end

if a.overBorder then a.overBorder:SetFrameLevel(b)end
local d,j=f.style,a.look
local b={g.rgba(d.colour)}
a.fade:SetDuration(d.speed or 1)
a.fade:SetToAlpha(j.steady and 1 or d.low or 1)
j.style(a,d,b)

local b=e.part("border").glowInset(f,c)

a.cornerShare,a.shapeMask=e.part("border").glowShape(f,c)
local e,f,g,h=b,b,b,b
if type(b)=="table"then e,f,g,h=b[1],b[2],b[3],b[4]end
local b=a.pulse
b:ClearAllPoints()
b:SetPoint("TOPLEFT",a.frame,"TOPLEFT",e,-g)
b:SetPoint("BOTTOMRIGHT",a.frame,"BOTTOMRIGHT",-f,h)
local b=e~=0 or f~=0 or g~=0 or h~=0
j.fit(a,b and{x=c.x,y=c.y,w=c.w-e-f,h=c.h-g-h}or c,d)

if not i.underButton then k(a)end
end

function c.feed()end

c.shown=k


function c.handOver(c,a)
for c,d in ipairs(c.groups)do
b.try("glow hand-off "..c,a.AddAuraShownAnimation,a,d)
end
end
