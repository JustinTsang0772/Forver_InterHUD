

local b,a=...
local c,f=a.Layers,a.Media

local a=c.registerPart("mark",{label="Mark",rung="lines",repeats=true,idWord="mark",
serves={swing=true},fromLayer={"grows","fills"},
fields={
{name="from",type="choice",choices={"end","start"},default="end",
labels={["end"]="Its end",start="Its start"},label="Measured from"},
{name="seconds",type="number",default=0.5,min=0,max=10,step=0.1,unit="s",label="Seconds"},
{name="shape",type="choice",choices={"line","zone"},default="line",
labels={line="Line",zone="Zone"},label="Shape",
help="A zone is shaded from the mark to the end it is measured from."},
{name="colour",type="colour",default="#ffffffcc",label="Colour"},

{name="thickness",type="number",default=2,min=1,max=8,step=1,unit="px",
under={"shape","line"},label="Thickness"},
},
changes={{name="colour",type="colour",label="Colour"}}})
c.attach("bar","marks","mark",{list=true,max=8,label="Marks",under={"value","time"}})


function a.routes(a)
if a~=nil then return{}end
return{{holder="layer"}}
end

function a.create(a)
local a=CreateFrame("Frame",nil,a)
local b=a:CreateTexture(nil,"OVERLAY")
b:Hide()
return{frame=a,tex=b,length=false}
end


local function e(b,a)
return b.fills and a or 1-a
end




local function d(a)
local b,c=a.tex,a.length
local d=a.seconds
if not c or c<=0 or d>c then return b:Hide()end
local c=a.from=="start"and d/c or 1-d/c
local c=e(a,c)
local d=c
if a.zone then d=e(a,a.from=="start"and 0 or 1)end
if d<c then c,d=d,c end
local e,g,h=a.frame,a.w,a.h
local i=a.grows=="up"or a.grows=="down"
local f=a.grows=="left"or a.grows=="down"
local g=i and h or g
local c,h=c*g,d*g
if not a.zone then
c=math.max(0,math.min(g-a.line,c-a.line/2))
h=c+a.line
end
b:ClearAllPoints()
if i then

local d=f and"TOP"or"BOTTOM"
local f=f and-1 or 1
b:SetPoint(d.."LEFT",e,d.."LEFT",0,f*c)
b:SetPoint(d.."RIGHT",e,d.."RIGHT",0,f*c)
b:SetHeight(math.max(h-c,a.line))
else
local d=f and"RIGHT"or"LEFT"
local f=f and-1 or 1
b:SetPoint("TOP"..d,e,"TOP"..d,f*c,0)
b:SetPoint("BOTTOM"..d,e,"BOTTOM"..d,f*c,0)
b:SetWidth(math.max(h-c,a.line))
end
b:Show()
end

function a.apply(a,b,g,e)
a.from,a.seconds,a.zone=b.from,b.seconds or 0,b.shape=="zone"
a.grows,a.fills=b.grows or"right",b.fills==true
a.w,a.h=e.w,e.h
a.line=c.lineWidth(b.thickness or 2,b.scale)
a.tex:SetColorTexture(f.rgba(b.colour or"#ffffffcc"))
d(a)
end


function a.feed(a,b)
if b.length==nil or b.length==a.length then return end
a.length=b.length
d(a)
end
