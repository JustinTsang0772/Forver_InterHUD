


local b,a=...
local d,b,f,e=a.Layers,a.TextColours,a.Schema,a.Media


local c=d.register("icon",{label="Icon",onButton=true,
serves={spell=true,aura=true,totem=true,weaponEnchant=true,reagent=true,breath=true,
cast=true},
fields={

{name="picture",type="integer",min=1,control="fileId",label="Picture",
help="A texture's file ID, or From a spell… for a spell's picture. Empty: the source's own picture."},



{name="tint",type="colour",default="#ff4d4d00",label="Tint"},
{name="desaturated",type="boolean",default=false,label="Desaturated"},

{name="overlay",type="boolean",default=false,label="Overlay"},
{name="overlayColour",type="colour",default="#00000080",label="Overlay colour"},
},
changes={
{name="tint",type="colour",label="Tint"},
{name="desaturated",type="boolean",label="Desaturated"},
{name="overlay",type="boolean",label="Overlay"},
{name="overlayColour",type="colour",label="Overlay colour"},
},
})


local g,l=e.knownFile,e.drawable

local function h(b,a)
local a=a.vars.before
for c,a in ipairs(a and type(a.sources)=="table"and a.sources or{})do
for c,a in ipairs(type(a)=="table"and type(a.layers)=="table"and a.layers or{})do
if type(a)=="table"and a.id==b.id then return a.picture==b.picture end
end
end
return false
end

f.rule("layer","picture",function(a,b,c)
if a.kind~="icon"or a.picture==nil or not b:strict()then return end
if b.mode=="edit"and h(a,b)then return end
if g(a.picture)then return end
b:problem((c==""and""or c..".").."picture","is "..a.picture
..", a file this game doesn't have.")
end)

local g="#ffffff"



local function h(a)
local b,c,d,a=e.rgba(a or g)
a=a or 1
return 1-a*(1-b),1-a*(1-c),1-a*(1-d),1
end



function c.buttonCue(a)
local b={}
local c,d,e=h(a.tint)
local c=c<1 or d<1 or e<1
if c or a.overlay then
b.tint=c and a.tint or g
b.overlay=a.overlay and true or false
if a.overlay then b.overlayColour=a.overlayColour end
end
if a.desaturated then b.desaturated=true end
if a.ring then b.border={ring=true,ringColour=a.ringColour,ringSize=a.ringSize}end
return next(b)and b or nil
end



local function i(b,a)return a.kind~="cast"end
d.registerPart("sweep",{label="Sweep",enabled=i,fields={



{name="darkens",type="boolean",
defaultFrom=function(b,a)return a.kind=="aura"or a.kind=="totem"end,
label="Darkens as time runs out"},

f.styleField("sweep"),
},changes={{name="colour",type="colour",label="Colour"},
{name="edgeColour",type="colour",label="Edge colour"}}})





local f={spell=true,totem=true,weaponEnchant=true,breath=true,aura=true,cast=true}

local m=b.fontField(f)

local function j(b,a)return a.kind=="aura"end
local k=b.sizeField(nil,f)
k.defaultFrom=function(a,b)return j(a,b)and 12 or 16 end
local j,n,o=b.placeFields(function(a,b)return j(a,b)and"TOPLEFT"or"CENTER"end,f)
local f=d.registerPart("time",{label="Time",enabled=i,
fields={{name="colour",type="colour",serves=f,label="Colour"},b.tenthsField(f),m,
k,j,n,o},
changes={{name="colour",type="colour",serves=f,label="Colour"}}})
f.buttonText=function()return true end


function f.colourByTime()return true end



function c.routes(a)
return d.sideRoutes(a,{"icon","durationCooldown"})
end




local function f(a)
a:SetSnapToPixelGrid(false)
a:SetTexelSnappingBias(0)
end
a.Debug.experimental("an icon's picture, overlay and mask unsnapped, so no sliver shows past its swipe"
.." (ShamanForever's cropIconExact)","C")



function c.create(a,b,c)
local a=CreateFrame("Frame",nil,a)
local b=a:CreateTexture(nil,"ARTWORK")
b:SetTexCoord(0.07,0.93,0.07,0.93)
f(b)
local c=a:CreateMaskTexture()
f(c)
b:AddMaskTexture(c)

local d=a:CreateTexture(nil,"ARTWORK",nil,2)
f(d)
d:AddMaskTexture(c)
d:Hide()
local e=CreateFrame("Cooldown",nil,a,"CooldownFrameTemplate")
e:SetDrawEdge(false)
return{frame=a,tex=b,mask=c,overlay=d,cd=e}
end

local i=a.Media.WHITE
a.Debug.experimental("a border look changed on an aura: the icon's mask re-textured under the button after its init"
.." (FR-10: only adding a mask is recorded)","I")


local function j(a,b,e)
local b=d.part("border").frameSwipe(a.cd,a.frame,b,e)
local d,g=b and b.inset or 0,b and b.look or{}
local f,b,c=a.frame,a.tex,a.mask
b:ClearAllPoints()
b:SetPoint("TOPLEFT",f,"TOPLEFT",d,-d)
b:SetPoint("BOTTOMRIGHT",f,"BOTTOMRIGHT",-d,d)
a.overlay:ClearAllPoints()
a.overlay:SetAllPoints(b)
local a=g.mask
c:ClearAllPoints()
if a then
c:SetAtlas(a.atlas,false,nil,nil,"CLAMPTOBLACKADDITIVE","CLAMPTOBLACKADDITIVE")
local a=(math.min(e.w,e.h)-2*d)*(a.scale or 1)
c:SetPoint("CENTER",b,"CENTER",0,0)
c:SetSize(a,a)
else
c:SetTexture(i,"CLAMPTOBLACKADDITIVE","CLAMPTOBLACKADDITIVE")
c:SetAllPoints(b)
end
end







local function f(b)
if b.cdText==nil then
local c=b.cd.GetCountdownFontString
local d,e=false,nil
if c then d,e=a.try("countdown text",c,b.cd)end
b.cdText=d and e or false
end
return b.cdText
end
local function i(c,d)
if d==nil and not c.cdColoured then return end
local b=f(c)

if b and d and not c.cdColoured and c.cdOwn==nil then
local g,b,d,e,f=a.try("countdown colour",b.GetTextColor,b)
if g and not(a.isSecret(b)or a.isSecret(d)or a.isSecret(e)or a.isSecret(f))and type(b)=="number"then
c.cdOwn={b,d,e,f or 1}
end
end
if b and d then
b:SetTextColor(e.rgba(d))
elseif b then
local a=c.cdOwn
if a then b:SetTextColor(a[1],a[2],a[3],a[4])else b:SetTextColor(e.rgba(g))end
end
c.cdColoured=d~=nil or nil
end






local function g(g,c)
local d=f(g)
if not d then return end
local f=c.fontSize or 16
if c.style then
e.setFont(d,c.style,f)
else
local a,b,e,c=a.try("countdown font",d.GetFont,d)
d:SetFont(a and type(b)=="string"and b or STANDARD_TEXT_FONT,f,a and c or"OUTLINE")
end
b.place(d,g.cd,c.point or"CENTER",c.x,c.y)
end




local function k(e,c,d)
d=d or 0
local f=(c or d>0)and((c and(c.at..":"..c.colour)or"").."/"..d)or nil
if f==e.cdBreak then return end

local b=f and b.timeFormatter(d,c)or nil
if a.try("countdown break",e.cd.SetCountdownFormatter,e.cd,b or nil)then e.cdBreak=f end
end

a.Debug.experimental("the game's own countdown format restored with SetCountdownFormatter(nil) once Ready soon's"
.." breakpoint colour is off (the API documents the formatter as nilable; untried in game; a refusal would leave the"
.." last colour on the icon)","I")
a.Debug.experimental("a sweep's colour and edge line (SetSwipeColor, SetDrawEdge, SetEdgeColor, SetEdgeScale) on a"
.." cooldown handed to an aura's button, and by state in combat (untested in game)","I")



local function e(b,c)
local c=c.picture
if c==b.picture then return end
b.picture=c
if c then
b.tex:SetTexture(l(c))
elseif a.isSecret(b.fed)or b.fed~=nil then
b.tex:SetTexture(b.fed)
end
end


function c.apply(b,c,f,l)
j(b,c,l)
e(b,c)
b.cd:SetFrameLevel(f.level+d.RUNGS.swipe)
b.tex:SetDesaturated(c.desaturated and true or false)
b.tex:SetVertexColor(h(c.tint))
if c.overlay then b.overlay:SetColorTexture(a.Media.rgba(c.overlayColour or"#00000080"))end
b.overlay:SetShown(c.overlay and true or false)
local d,c=c.sweep or{},c.time or{}

b.cd:SetDrawSwipe(d.enabled~=false and d.shown~=false)
b.cd:SetReverse(d.darkens and true or false)
local e=d.style or{}
b.cd:SetSwipeColor(a.Media.rgba(e.colour or"#000000a3"))
b.cd:SetDrawEdge(e.edge and true or false)
if e.edge then
b.cd:SetEdgeColor(a.Media.rgba(e.edgeColour or"#ffffff"))
b.cd:SetEdgeScale(e.edgeScale or 1)
end
b.cd:SetHideCountdownNumbers(c.enabled==false or c.shown==false)
b.timed=d.enabled~=false and d.shown~=false or c.enabled~=false and c.shown~=false
g(b,c)
i(b,c.colour)
k(b,f and f.colours,c.tenthsBelow)
end



function c.feed(b,c)
if a.isSecret(c.icon)or c.icon then
b.fed=c.icon
if not b.picture then b.tex:SetTexture(c.icon)end
elseif c.icon==false then
b.fed=nil
if not b.picture then b.tex:SetTexture(nil)end
end


if c.duration and b.timed then
b.cd:SetCooldownFromDurationObject(c.duration,true)
elseif c.duration~=nil then
b.cd:Clear()
end
end


function c.handOver(a,b,c)
local c=c and c.sockets or{"icon","durationCooldown"}
if d.inList(c,"icon")then b:SetIcon(a.tex)end
if d.inList(c,"durationCooldown")then b:SetDurationCooldown(a.cd)end
end
