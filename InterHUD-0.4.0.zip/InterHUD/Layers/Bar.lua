
















local a,b=...
local e=b.Schema
local a=b.Layers
local d=b.Media

local i=20
local j=8

local f={power=true,health=true}
local c={combo=true}

local h={power=true,health=true,combo=true}

local e=a.register("bar",{label="Bar",onButton=true,
serves={spell=true,aura=true,totem=true,weaponEnchant=true,breath=true,threat=true,cast=true,
power=true,combo=true,health=true,fiveSecondRule=true,swing=true,range=true},
fields={


{name="value",type="choice",labels={time="Time",stacks="Stacks",full="Full",amount="Amount",
points="Combo points"},
label="Value",choicesFrom=function(b,a)
if a.kind=="aura"then return{"time","stacks"}end
if a.kind=="threat"or a.kind=="range"then return{"full"}end
if f[a.kind]then return{"amount"}end
if c[a.kind]then return{"points"}end
return{"time"}
end,
defaultFrom=function(b,a)
return(a.kind=="threat"or a.kind=="range")and"full"or f[a.kind]and"amount"or c[a.kind]and"points"
or"time"
end},
{name="segments",type="integer",default=3,min=1,max=i,
under={"value",{"stacks","points"}},label="Segments"},
{name="fills",type="boolean",default=false,under={"value","time"},label="Fills up"},

{name="runOut",type="choice",choices={"empty","full"},default="empty",serves={swing=true},
under={"value","time"},labels={empty="Empty",full="Full"},label="When its time runs out"},

{name="smooth",type="boolean",default=true,under={"value","amount"},label="Smooth",
help="The fill glides to each new amount instead of jumping to it."},


{name="grows",type="choice",choices={"right","left","up","down"},default="right",
labels={right="Right",left="Left",up="Up",down="Down"},label="Grows"},


{name="length",type="number",min=1,max=1024,softMax=300,step=0.5,label="Length",
help=e.EMPTY_SIZE},
{name="thickness",type="number",min=1,max=1024,softMax=100,step=0.5,label="Thickness",
help=e.EMPTY_SIZE},

e.styleField("barTexture","Texture"),
{name="colour",type="colour",default="#ffd140",label="Colour"},

{name="stepsColour",type="choice",default="whole",serves=h,
choicesFrom=function(b,a)
return c[a.kind]and{"whole","parts"}or{"whole","blend","parts"}
end,
labels={whole="The whole bar",blend="The whole bar, blended",parts="Its own stretch of the bar"},
label="A step colours",
shownIf=function(b,a)return type(a)=="table"and type(a.colourSteps)=="table"
and#a.colourSteps>0 end},
},

changes={{name="colour",type="colour",label="Colour"}},
})



a.registerPart("background",{label="Background",fields={
{name="colour",type="colour",default="#00000080",label="Colour"},
},changes={{name="colour",type="colour",label="Colour"}}})
a.attach("bar","background","background")



a.registerPart("spark",{label="Spark",enabled=false,
serves={spell=true,totem=true,weaponEnchant=true,breath=true,cast=true,fiveSecondRule=true,
swing=true},
fields={
{name="colour",type="colour",default="#ffffffe6",label="Colour"},
{name="thickness",type="number",default=2,min=1,max=8,step=1,unit="px",label="Thickness"},
},changes={{name="colour",type="colour",label="Colour"}}})
a.attach("bar","spark","spark",{under={"value","time"}})


a.registerPart("segmentLines",{label="Segment lines",serves={aura=true,combo=true},fields={
{name="colour",type="colour",default="#000000e6",label="Colour"},

{name="thickness",type="number",default=2,min=1,max=8,step=1,unit="px",label="Thickness"},
},changes={{name="colour",type="colour",label="Colour"}}})
a.attach("bar","segmentLines","segmentLines",{under={"value",{"stacks","points"}}})







local g={

{key="incomingHeals",label="Incoming heals",colour="#a8ffb4a6"},
{key="shields",label="Shields",colour="#e8f4ffb3"},
{key="healAbsorbs",label="Heal absorbs",colour="#b0202099",back=true},

{key="cost",label="Cost",colour="#a9c2ffb3",back=true,serves={power=true},on=false,
help="The cost of the spell you are casting, drawn over the bar."},
}
for c,b in ipairs(g)do
a.registerPart(b.key,{label=b.label,serves=b.serves or{health=true},enabled=b.on,fields={
{name="colour",type="colour",default=b.colour,label="Colour",help=b.help},
},changes={{name="colour",type="colour",label="Colour"}}})
a.attach("bar",b.key,b.key,{under={"value","amount"}})
end
local function l(a)return type(a)=="table"and a.enabled~=false end







a.registerPart("colourStep",{label="Colour step",repeats=true,idWord="step",serves=h,fields={
{name="share",type="percent",default=50,min=1,max=100,serves=f,label="From",
help="This colour is used from this share of the maximum up, until a higher step takes over."},
{name="points",type="integer",default=3,min=1,max=10,serves=c,label="From",
help="This colour is used from this many combo points up, until a higher step takes over."},
{name="colour",type="colour",default="#ff4040",label="Colour"},
},changes={{name="colour",type="colour",label="Colour"}}})
a.attach("bar","colourSteps","colourStep",{list=true,max=j,label="Colour steps",
under={"value",{"amount","points"}}})


local function h(a)
local b=a.stepsColour or"whole"
if type(a.colourSteps)~="table"or b=="blend"or(b=="whole"and a.value~="amount")then
return 0
end
local b=0
for c,a in ipairs(a.colourSteps)do
if type(a)=="table"and a.enabled~=false then b=b+1 end
end
return math.min(b,j)
end



local f={right={"HORIZONTAL",false},left={"HORIZONTAL",true},up={"VERTICAL",false},
down={"VERTICAL",true}}
local function k(a)return f[a or"right"][1]=="VERTICAL"end


local function c(a,b)
return{style=a.style,size=a.fontSize or(a.style and a.style.size)or 12,justify=a.justify or b,
x=a.x or 0}
end
function e.finish(d,a,b)

local b,d=a.length or b.elementSize,a.thickness or b.elementSize
if k(a.grows)then a.width,a.height=d,b else a.width,a.height=b,d end
a.timeFont=nil
local b=a.time
if type(b)=="table"and b.enabled==true and b.shown~=false
and(b.content==nil or b.content=="time")then
a.timeFont=c(b,"RIGHT")
return
end
for d,b in ipairs(type(a.texts)=="table"and a.texts or{})do
if b.enabled~=false and b.shown~=false and(b.content==nil or b.content=="time")then
a.timeFont=c(b,"CENTER")
return
end
end
end






b.Debug.experimental("a stacks bar handed to an aura's button as its application bar, 0 to its segments (AU-3,"
.." AU-38: ShamanForever's charge bar)","T")
function e.routes(c,b)
local d=b.value=="stacks"
local e=d and"applicationBar"or"durationBar"
local e=a.sideRoutes(c,{e})
local f=b.grows or"right"
local a=d and("stacks:"..b.segments)or b.value=="points"and("points:"..b.segments)
or(b.fills and"fills"or"drains")

if b.value=="amount"then
a="amount"
for d,c in ipairs(g)do
if l(b[c.key])then a=a.."+"..c.key end
end
end

local b=c==nil and(b.value=="amount"or b.value=="points")and h(b)or 0
if b>0 then a=a.."+bands"..b end
for c,b in ipairs(e)do
b.shape=a..(f~="right"and(":"..f)or"")
end
return e
end

local h=Enum.StatusBarTimerDirection

local l=a.curve({0,0,0.05,1})

local c="Interface\\Buttons\\WHITE8x8"


local function m(a,b)
a:SetAlpha(b:EvaluateRemainingDuration(l))
end





b.Debug.experimental("a stacks bar's segment lines inside the bar's own frame, over its fill (ShamanForever's ticks:"
.." AU-3), under the button","I")

b.Debug.experimental("an Amount bar's overlays (health's, power's Cost): StatusBars of ours anchored to its Lua-fed"
.." fill's edge (GetStatusBarTexture) and Incoming heals' on each way it grows, fed secret amounts, the bar clipping"
.." them (FR-41: EllesmereUI's on Forever, in its own frames; ours unseen in a fight: EP-68)","C")
local function n(e,a)
if type(a)~="string"or not a:find("^amount%+")then return nil end
local b={}
for g,f in ipairs(g)do
if a:find("+"..f.key,1,true)then
local a=CreateFrame("StatusBar",nil,e)
a:SetStatusBarTexture(c)
d.exactFill(a)
a:SetMinMaxValues(0,1)
a:SetValue(0)
b[f.key]=a
end
end
if next(b)==nil then return nil end
e:SetClipsChildren(true)
return b
end






b.Debug.experimental("a bar's bands: a StatusBar per colour step the bar's whole size inside a clip (SetClipsChildren)"
.." over its stretch, each fed the same amount and range, secret or plain, the bar's own fill drawn at alpha 0"
.." (UN-3 for each bar; FR-41 for a clip on a Lua-fed bar; the clipped copies unseen in game)","I")
b.Debug.experimental("the whole bar by step on a secret level: each band's alpha from a Step curve on"
.." UnitPowerPercent or UnitHealthPercent, 1 from its step's share to the next step's, sampled at every read (A6,"
.." UN-3, UN-4: an under-N% alpha T 70338, T 70450; neighbours never both or neither at a cut unrecorded: FR-42)",
"I")
local function o(e,a)
local a=type(a)=="string"and tonumber(a:match("%+bands(%d+)"))
if not a then return nil end
local f={}
for g=1,a+1 do
local b=CreateFrame("Frame",nil,e)
b:SetClipsChildren(true)
local a=CreateFrame("StatusBar",nil,b)
a:SetAllPoints(e)
a:SetStatusBarTexture(c)
d.exactFill(a)
a:SetMinMaxValues(0,1)
a:SetValue(0)
f[g]={clip=b,bar=a}
end
return f
end
function e.create(a,e,b)
local a=CreateFrame("StatusBar",nil,a)
local e=a:CreateTexture(nil,"BACKGROUND")
e:SetAllPoints()

d.exact(e)
a:SetStatusBarTexture(c)
d.exactFill(a)
a:SetMinMaxValues(0,1)
a:SetValue(0)
local f=o(a,b and b.shape)
local g=n(a,b and b.shape)
local b=CreateFrame("Frame",nil,a)
b:SetAllPoints(a)
local c={}
for a=1,i-1 do
c[a]=b:CreateTexture(nil,"OVERLAY")
c[a]:Hide()
end
local d=b:CreateTexture(nil,"OVERLAY",nil,1)
d:Hide()
return{frame=a,bar=a,bg=e,ticks=b,lines=c,overlays=g,bands=f,
spark=d}
end


local function i(b,c,d)
local a=(c and c.level or 0)+a.RUNGS.lines
if d=="bands"then return a end
if b.bands then a=a+1 end
if d=="overlays"then return a end
return a+(b.overlays and 1 or 0)
end





local c={right="RIGHT",left="LEFT",up="TOP",down="BOTTOM"}
local function n(g,f)
local b,e=g.spark,f.spark
if not(f.value=="time"and type(e)=="table"and e.enabled==true and e.shown~=false)then
return b:Hide()
end
local c=c[f.grows]or"RIGHT"
local g=g.bar:GetStatusBarTexture()
local a=a.lineWidth(e.thickness or 2,f.scale)
b:ClearAllPoints()
if c=="RIGHT"or c=="LEFT"then
b:SetPoint("TOP",g,"TOP"..c,0,0)
b:SetPoint("BOTTOM",g,"BOTTOM"..c,0,0)
b:SetWidth(a)
else
b:SetPoint("LEFT",g,c.."LEFT",0,0)
b:SetPoint("RIGHT",g,c.."RIGHT",0,0)
b:SetHeight(a)
end
b:SetColorTexture(d.rgba(e.colour or"#ffffffe6"))
b:Show()
end

local function o(b,c,l,j)
local f=(c.value=="stacks"or c.value=="points")and c.segmentLines or nil
local g=type(f)=="table"and f.enabled~=false and f.shown~=false
local h=g and c.segments or 1
local e=a.lineWidth(g and f.thickness or 2,c.scale)
local d,f,g,m=d.rgba(g and f.colour or"#000000")
b.ticks:SetFrameLevel(i(b,l,"lines"))
local i=k(c.grows)
for c,a in ipairs(b.lines)do
if c<h then
a:ClearAllPoints()

if i then
local c=j.h*c/h
a:SetPoint("BOTTOMLEFT",b.ticks,"BOTTOMLEFT",0,c-e/2)
a:SetPoint("BOTTOMRIGHT",b.ticks,"BOTTOMRIGHT",0,c-e/2)
a:SetHeight(e)
else
local c=j.w*c/h
a:SetPoint("TOPLEFT",b.ticks,"TOPLEFT",c-e/2,0)
a:SetPoint("BOTTOMLEFT",b.ticks,"BOTTOMLEFT",c-e/2,0)
a:SetWidth(e)
end
a:SetColorTexture(d,f,g,m)
a:Show()
else
a:Hide()
end
end
end




local c={
right={forward={"TOPLEFT","TOPRIGHT","BOTTOMLEFT","BOTTOMRIGHT"},
back={"TOPRIGHT","TOPRIGHT","BOTTOMRIGHT","BOTTOMRIGHT"}},
left={forward={"TOPRIGHT","TOPLEFT","BOTTOMRIGHT","BOTTOMLEFT"},
back={"TOPLEFT","TOPLEFT","BOTTOMLEFT","BOTTOMLEFT"}},
up={forward={"BOTTOMLEFT","TOPLEFT","BOTTOMRIGHT","TOPRIGHT"},
back={"TOPLEFT","TOPLEFT","TOPRIGHT","TOPRIGHT"}},
down={forward={"TOPLEFT","BOTTOMLEFT","TOPRIGHT","BOTTOMRIGHT"},
back={"BOTTOMLEFT","BOTTOMLEFT","BOTTOMRIGHT","BOTTOMRIGHT"}},
}

local function p(a,e,j,h,b)
local c,f=f[b],c[b]
local k=a.bar:GetStatusBarTexture()
local j=i(a,j,"overlays")
local i=a.overlays.incomingHeals
for g,b in ipairs(g)do
local a=a.overlays[b.key]
if a then
local g=e[b.key]or{}
d.setBar(a,e.style)
a:SetOrientation(c[1])
a:SetReverseFill(c[2]~=(b.back==true))
a:SetRotatesTexture(c[1]=="VERTICAL")
a:SetStatusBarColor(d.rgba(g.colour or b.colour))
a:SetFrameLevel(j)


local d=(b.key=="shields"and i and(e.incomingHeals or{}).shown~=false)
and i:GetStatusBarTexture()or k
local b=b.back and f.back or f.forward
a:ClearAllPoints()
a:SetPoint(b[1],d,b[2],0,0)
a:SetPoint(b[3],d,b[4],0,0)
if c[1]=="VERTICAL"then a:SetHeight(h.h)else a:SetWidth(h.w)end
a:SetShown(g.shown~=false)
end
end
end






local function q(a,b)
if b then return a.points or 3 end
return a.share or 50
end

local k,g={},0
local function r(d,a)
if not(C_CurveUtil and C_CurveUtil.CreateColorCurve and CreateColor)then return nil end
local b=k[d]
if b then return b end
if g>=32 then k,g={},0 end
b=C_CurveUtil.CreateColorCurve()
if Enum.LuaCurveType then b:SetType(Enum.LuaCurveType.Linear)end
for c=0,a.n do
b:AddPoint(c==0 and 0 or a.at[c]/100,CreateColor(a.r[c],a.g[c],a.b[c],a.a[c]))
end
local c=a.n
if a.at[c]<100 then b:AddPoint(1,CreateColor(a.r[c],a.g[c],a.b[c],a.a[c]))end
k[d],g=b,g+1
return b
end



local k,g={},0
local function s(d,c)
local f=d*1000+(c or 999)
local e=k[f]
if e==nil then
if g>=128 then k,g={},0 end
local b={}
if d>0 then b[1],b[2]=0,0 end
b[#b+1],b[#b+2]=d/100,1
if c then b[#b+1],b[#b+2]=c/100,0 end

if(c or d)<100 then b[#b+1],b[#b+2]=1,c and 0 or 1 end
e=a.curve(b,"Step")or false
k[f],g=e,g+1
end
return e or nil
end
local function k(b,f)
local h=(b.amount or b.points)and type(f.colourSteps)=="table"and f.colourSteps or nil
local a=b.steps
if not a then
if not(h and#h>0)then return nil end
a={at={},r={},g={},b={},a={},frac={}}
b.steps=a
end
local g=b.points~=nil
local c,e=a.at,0
local i=(f.stepsColour or"whole")..f.colour
c[0]=0
a.r[0],a.g[0],a.b[0],a.a[0]=d.rgba(f.colour)
for b,f in ipairs(h or{})do
if type(f)=="table"and f.enabled~=false and f.shown~=false and e<j then
local g=q(f,g)
local b=e+1
while b>1 and c[b-1]>g do b=b-1 end
if c[b-1]==g and b>1 then
b=b-1
else
e=e+1
for b=e,b+1,-1 do
c[b],a.r[b],a.g[b],a.b[b],a.a[b]=c[b-1],a.r[b-1],a.g[b-1],a.b[b-1],a.a[b-1]
end
end
c[b]=g
a.r[b],a.g[b],a.b[b],a.a[b]=d.rgba(f.colour or"#ff4040")
end
end
a.n=e
a.blend=f.stepsColour=="blend"and not g
a.parts=f.stepsColour=="parts"
local d=g and b.points or 100
for b=1,e do
a.frac[b]=math.max(0,math.min(1,(g and c[b]-1 or c[b])/d))
i=i..":"..c[b]..string.format("%02x%02x%02x%02x",a.r[b]*255,a.g[b]*255,a.b[b]*255,
a.a[b]*255)
end
a.curve=e>0 and a.blend and r(i,a)or nil
a.lit=nil
if b.bands and not a.parts then
a.lit=a.windows or{}
a.windows=a.lit
for b=0,e do a.lit[b]=s(c[b],b<e and c[b+1]or nil)or false end
end
return a
end


local c=1e-6
local function g(b,d)
local e,a=b.at,0
while a<b.n and d+c>=e[a+1]do a=a+1 end
return a
end

local function q(a,d)
local c,b=a.at,g(a,d)
if a.blend and b<a.n then
local c=(d-c[b])/(c[b+1]-c[b])
return a.r[b]+(a.r[b+1]-a.r[b])*c,a.g[b]+(a.g[b+1]-a.g[b])*c,
a.b[b]+(a.b[b+1]-a.b[b])*c,a.a[b]+(a.a[b+1]-a.a[b])*c
end
return a.r[b],a.g[b],a.b[b],a.a[b]
end

local function r(a,b,c,d)
a:SetStatusBarColor(b(c,d):GetRGBA())
end

local function s(a,b,c,d)
a:SetAlpha(b(c,d))
end







b.Debug.experimental("a blended bar's colour on a secret level: UnitPowerPercent and UnitHealthPercent through a"
.." Linear colour curve at each read, the colour's GetRGBA into SetStatusBarColor (UN-3, UN-4: GetRGB on power and"
.." health T 70450; GetRGBA with its alpha and rage or energy through it unseen: EP-15; the engine's colour"
.." object a read unmeasured)","I")
local j="bar colour steps"
local function t(a,e)
local f,c=a.bands,a.level
local d=e.n
if d>0 and b.isSecret(c)and a.sample then
local c=true
for d=0,d do
local e=e.lit[d]
c=c and e and b.try(j,s,f[d+1].clip,a.sample,a.by,e)
end
if c then return end
end
local b=(d>0 and not b.isSecret(c)and type(c)=="number")and g(e,c)or 0
for a=0,d do f[a+1].clip:SetAlpha(a==b and 1 or 0)end
end
local function g(c)
local a=c.steps
if not a or a.parts then return end
if a.lit then return t(c,a)end
local d,e=c.bar,c.level
if a.n>0 and b.isSecret(e)then
if a.curve and c.sample and b.try(j,r,d,c.sample,c.by,a.curve)then
return
end
elseif a.n>0 and type(e)=="number"then
d:SetStatusBarColor(q(a,e))
return
end
d:SetStatusBarColor(a.r[0],a.g[0],a.b[0],a.a[0])
end


local function j(b,m,n,a,j)
local c,k=b.steps,f[j]
local o=c and c.n or 0
local l=c and c.parts
local p=k[1]=="VERTICAL"
local h=p and a.h or a.w
for e,a in ipairs(b.bands)do
local e=e-1
local a,f=a.clip,a.bar
if e>o then
a:Hide()
else
local g=(e==0 or not l)and 0 or c.frac[e]*h
local h=(e==o or not l)and h or c.frac[e+1]*h
a:ClearAllPoints()
if j=="right"then
a:SetPoint("TOPLEFT",b.bar,"TOPLEFT",g,0)
a:SetPoint("BOTTOMRIGHT",b.bar,"BOTTOMLEFT",h,0)
elseif j=="left"then
a:SetPoint("TOPRIGHT",b.bar,"TOPRIGHT",-g,0)
a:SetPoint("BOTTOMLEFT",b.bar,"BOTTOMRIGHT",-h,0)
elseif j=="up"then
a:SetPoint("BOTTOMLEFT",b.bar,"BOTTOMLEFT",0,g)
a:SetPoint("TOPRIGHT",b.bar,"BOTTOMRIGHT",0,h)
else
a:SetPoint("TOPLEFT",b.bar,"TOPLEFT",0,-g)
a:SetPoint("BOTTOMRIGHT",b.bar,"TOPRIGHT",0,-h)
end
a:SetFrameLevel(i(b,n,"bands"))
f:SetFrameLevel(i(b,n,"bands"))
d.setBar(f,m.style)
f:SetOrientation(k[1])
f:SetReverseFill(k[2])
f:SetRotatesTexture(p)
if c then f:SetStatusBarColor(c.r[e],c.g[e],c.b[e],c.a[e])
else f:SetStatusBarColor(d.rgba(m.colour))end
if l then a:SetAlpha(1)end
a:SetShown(h>g)
end
end
end




b.Debug.experimental("a bar growing left, up or down: upright on an aura's button is AU-8's (T, set out of combat);"
.." turned at initializeFrame, in combat on a Grows edit, our own bar upright (a cooldown's, CD-5's route) and"
.." reverse fill on either are untried","I")
function e.apply(a,c,h,i)
a.fills=c.fills
a.runOut=c.runOut
a.stacks=c.value=="stacks"and c.segments or nil
a.full=c.value=="full"or nil
a.amount=c.value=="amount"or nil
a.points=c.value=="points"and c.segments or nil
a.smooth=c.smooth~=false
d.setBar(a.bar,c.style)
local e=f[c.grows]and c.grows or"right"
local f=f[e]
if a.grows~=e then
a.bar:SetOrientation(f[1])
a.bar:SetReverseFill(f[2])
a.grows=e
end

a.bar:SetRotatesTexture(f[1]=="VERTICAL")
local f=c.background or{}
if f.enabled~=false and f.shown~=false then
local b,c,d,e=b.Media.rgba(f.colour or"#00000080")
a.bg:SetColorTexture(b,c,d,e)
a.bg:Show()
else
a.bg:Hide()
end
a.bar:SetStatusBarColor(d.rgba(c.colour))
local b=k(a,c)
if a.bands then

local b,d,f=d.rgba(c.colour)
a.bar:SetStatusBarColor(b,d,f,0)
j(a,c,h,i,e)
end
if b then g(a)end
if a.overlays then p(a,c,h,i,e)end
o(a,c,h,i)
n(a,c)

if a.full then
a.bar:SetMinMaxValues(0,1)
a.bar:SetValue(1)
a.bar:SetAlpha(1)
end
end




local f=Enum.StatusBarInterpolation


b.Debug.experimental("an Amount bar eased by ExponentialEaseOut at each power or health event, its range set with"
.." the same interpolation (UN-3 saw the call accepted, not the ease drawn: EP-15)","I")
local function c(a,c,d,e)
if b.isSecret(c)or c then
a:SetMinMaxValues(0,c,e)
elseif c==false then
a:SetMinMaxValues(0,1,f.Immediate)
end
if b.isSecret(d)or d then
a:SetValue(d,e)
elseif d==false then
a:SetValue(0,f.Immediate)
end
end


local function i(b,h,a)
local d=a.max
local e=(a.snap or not b.smooth)and f.Immediate or f.ExponentialEaseOut
c(h,d,a.amount,e)
if b.bands then
for f=1,#b.bands do c(b.bands[f].bar,d,a.amount,e)end
end
if b.steps then
if a.percent~=nil then b.level=a.percent end
if a.sample~=nil then b.sample,b.by=a.sample,a.by end
g(b)
end
local b=b.overlays
if not b then return end
if b.incomingHeals then c(b.incomingHeals,d,a.heals,e)end
if b.shields then
if b.incomingHeals then
c(b.shields,d,a.absorbs,e)
else
c(b.shields,d,a.absorbsAlone,e)
end
end
if b.healAbsorbs then c(b.healAbsorbs,d,a.healAbsorbs,e)end
if b.cost then c(b.cost,d,a.cost,e)end
end






local function c(a,d,c)
if b.isSecret(c)or c then
a:SetMinMaxValues(0,d)
a:SetValue(c)
elseif c==false then
a:SetMinMaxValues(0,d)
a:SetValue(0)
end
end
local function f(a,d,b)
local b=b.amount
c(d,a.points,b)
if a.bands then
for d=1,#a.bands do c(a.bands[d].bar,a.points,b)end
end
if a.steps then
if b~=nil then a.level=b end
g(a)
end
end

function e.feed(a,c)
local d=a.bar
if a.full then return end
if a.amount then return i(a,d,c)end
if a.points then return f(a,d,c)end
if c.channel~=nil then a.channel=c.channel end

if a.spark and c.duration~=nil then a.spark:SetAlpha(c.duration and 1 or 0)end
if c.full~=nil then
d:SetMinMaxValues(0,1)
d:SetValue(c.full and 1 or 0)
d:SetAlpha(1)
return
end

if a.stacks then
if c.stacks~=nil or c.duration==false then
d:SetMinMaxValues(0,a.stacks)
d:SetValue(c.stacks or 0)
d:SetAlpha(1)
end
return
end
local e=a.fills
if a.channel then e=not e end
if c.duration then
d:SetTimerDuration(c.duration,Enum.StatusBarInterpolation.Immediate,
e and h.ElapsedTime or h.RemainingTime)
if l and not e and not b.try("bar alpha",m,d,c.duration)then d:SetAlpha(1)end
elseif c.duration==false then
local b=e
if a.runOut~=nil then b=a.runOut=="full"end
d:SetMinMaxValues(0,1)
d:SetValue(b and 1 or 0)
d:SetAlpha(1)
end
end

function e.handOver(a,b,c)
if a.stacks then

b:SetApplicationBar(a.bar,{minApplications=0,maxApplications=a.stacks})
return
end
b:SetDurationBar(a.bar,{interpolation=Enum.StatusBarInterpolation.Immediate,
direction=c.shape:match("^fills")and h.ElapsedTime or h.RemainingTime})
end


b.Schema.rule("layer","a bar's sides",function(b,d,c)
if b.kind~="bar"then return end
for e,a in ipairs({"width","height"})do
if b[a]~=nil then
d:problem((c==""and""or c..".")..a,"A bar has no "..(a=="width"and"Width"or"Height")
..": set its Length (along the way it grows) or its Thickness.",function()b[a]=nil end)
end
end
end)
