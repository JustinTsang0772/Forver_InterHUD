





local a,b=...
local j,h=b.Layers,b.Media

local a={}
b.TextColours=a



function a.sizeField(a,b)
return{name="fontSize",type="number",default=a,min=6,max=48,softMax=48,step=1,unit="pt",
serves=b,group="font",label="Size"}
end


function a.fontField(c)
local a=b.Schema.styleField("font","Font")
a.ownSize,a.serves,a.group=true,c,"font"
return a
end

function a.sizeOf(a)
return a.fontSize or(a.style and a.style.size)or 12
end

a.PLACES={"TOPLEFT","TOPRIGHT","CENTER","BOTTOMLEFT","BOTTOMRIGHT"}
local c={TOPLEFT="Top left",TOPRIGHT="Top right",CENTER="Centre",BOTTOMLEFT="Bottom left",
BOTTOMRIGHT="Bottom right"}
function a.nudgeFields(a)
return{name="x",type="number",default=0,min=-200,max=200,step=0.5,control="edit",
serves=a,group="place",label="X"},
{name="y",type="number",default=0,min=-200,max=200,step=0.5,control="edit",
serves=a,group="place",label="Y"}
end
function a.placeFields(b,d)
local c={name="point",type="choice",choices=a.PLACES,labels=c,serves=d,
group="place",label="Anchor"}
if type(b)=="function"then c.defaultFrom=b else c.default=b end
local a,b=a.nudgeFields(d)
return c,a,b
end

local c={LEFT="LEFT",TOPLEFT="LEFT",BOTTOMLEFT="LEFT",RIGHT="RIGHT",TOPRIGHT="RIGHT",
BOTTOMRIGHT="RIGHT"}
function a.sideOf(a)return c[a]or"CENTER"end


local d={TOPLEFT={1,-1},TOPRIGHT={-1,-1},BOTTOMLEFT={1,1},BOTTOMRIGHT={-1,1}}
local e={0,0}
function a.place(c,f,b,g,h,i)
local d=not i and d[b]or e
c:ClearAllPoints()
c:SetPoint(b,f,b,d[1]+(g or 0),d[2]+(h or 0))
c:SetJustifyH(a.sideOf(b))
end



function a.fontString(a)
local a=a:CreateFontString(nil,"OVERLAY")
a:SetFont(STANDARD_TEXT_FONT,12,"OUTLINE")
return a
end


local function c(d)
local b,a={},{}
return function(a)return b[a]end,function(c,e)
b[c]=e
a[#a+1]=c
if#a>d then b[table.remove(a,1)]=nil end
end
end



local function f(d,a,c)
for e,c in ipairs(c)do
local d,a=b.try(d,a.FormatNumber,a,c[1])
if not d or c[2]and(type(a)~="string"or b.isSecret(a)or a:lower()~=c[2]:lower())then
return false
end
end
return a
end
local function g()return C_StringUtil and C_StringUtil.CreateNumericRuleFormatter end


b.Debug.experimental("a count from 1 by a formatter handed with the button's count (AU-10: ShamanForever's)","T")
local d
function a.fromOneFormatter()
if d~=nil or not g()then return d end
local a=C_StringUtil.CreateNumericRuleFormatter()
a:SetBreakpoints({{threshold=0,format=""},{threshold=1,format="%d"}})
d=f("count formatter",a,{{0,""},{1,"1"},{2,"2"},{3,"3"},{255,"255"}})
return d
end






local function d(a)return"|cff"..a:sub(2,7)end
function a.mapKey(b)
local a={b.from}
for c,b in ipairs(b.stops)do a[#a+1]=b.at.."="..b.colour end
return table.concat(a,":")
end

function a.colourRuns(b)
local a={}
for d,c in ipairs(b.stops)do
local d=b.stops[d+1]

if not(d and d.at<=b.from)then
local b=math.max(c.at,b.from)
if not(a[#a]and a[#a].colour==c.colour)then a[#a+1]={from=b,colour=c.colour}end
end
end
return a
end
local i,k=c(16)
function a.formatterFor(e)
local h=a.mapKey(e)
local c=i(h)
if c~=nil or not g()then return c end
local g=a.colourRuns(e)
local a={{threshold=0,format=""}}
for c,b in ipairs(g)do a[#a+1]={threshold=b.from,format=d(b.colour).."%d|r"}end
c=C_StringUtil.CreateNumericRuleFormatter()
if b.try("count formatter",c.SetBreakpoints,c,a)then
local a={}
for b=0,math.max(e.stops[#e.stops].at+2,5)do
local c=""
for e,a in ipairs(g)do
if b>=a.from then c=d(a.colour)..b.."|r"end
end
a[#a+1]={b,c}
end
c=f("count formatter",c,a)
else
c=false
end
k(h,c)
return c
end



b.Debug.experimental("an aura's countdown text with our formatter (SetDurationText's textFormatter: D)","I")


local function i(b)
local a=Enum.NumericRuleFormatRounding.Up
local c={
{threshold=0,format="%d",step=1,rounding=a},
{threshold=59.0001,format="%dm",rounding=a,components={{div=60,step=1,rounding=a}}},
{threshold=3540.0001,format="%dh",rounding=a,components={{div=3600,step=1,rounding=a}}},
}
if b then
c[1].format=d(b.colour).."%d|r"
table.insert(c,2,{threshold=b.at,format="%d",step=1,rounding=a})
end
return c
end
local e
function a.countdownFormatter()
if e~=nil or not g()then return e end
local a=C_StringUtil.CreateNumericRuleFormatter()
a:SetBreakpoints(i())
e=f("countdown formatter",a,{{0},{2.5},{59},{61},{3601}})
return e
end




b.Debug.experimental("a time text in tenths: a 0.1 step rule in its formatter, on a duration text binding (TO-14: the"
.." binding, T 70425; a swing's countdown by eye), on a buff's handed duration text and on a cooldown's numbers"
.." (both unseen)","C")
local function k(e,a)
local g=Enum.NumericRuleFormatRounding.Up
local c={0}
if e<59.0001 then c[#c+1]=e end
if a and a.at>0 and a.at<59.0001 and a.at~=e then c[#c+1]=a.at end
table.sort(c)
local b={}
for f,c in ipairs(c)do
local f=c<e
local e=f and"%.1f"or"%d"
if a and c<a.at then e=d(a.colour)..e.."|r"end
b[#b+1]={threshold=c,format=e,step=f and 0.1 or 1,rounding=g}
end
local a=i()
b[#b+1],b[#b+2]=a[2],a[3]
return b
end
local l,m=c(16)
function a.timeFormatter(d,e)
d=d or 0
if d<=0 then return e and a.countdownBreak(e)or a.countdownFormatter()end
local h=d..":"..(e and(e.at..":"..e.colour)or"")
local c=l(h)
if c~=nil or not g()then return c or a.countdownFormatter()end
c=C_StringUtil.CreateNumericRuleFormatter()
if b.try("tenths formatter",c.SetBreakpoints,c,k(d,e))then
c=f("tenths formatter",c,{{0},{d/2},{d+1},{61},{3601}})
else
c=false
end
m(h,c)
return c or a.countdownFormatter()
end


function a.tenthsField(a)
return{name="tenthsBelow",type="number",min=0,max=60,step=1,unit="s",serves=a,
defaultFrom=function(b,a)return a.kind=="swing"and 60 or 0 end,
label="Tenths below",
help="Show tenths decimal place when the time value is less than this many seconds. 0 means never show tenths."}
end


local e,k=c(16)
function a.countdownBreak(c)
local d=c.at..":"..c.colour
local a=e(d)
if a~=nil or not g()then return a end
a=C_StringUtil.CreateNumericRuleFormatter()
if b.try("countdown formatter",a.SetBreakpoints,a,i(c))then
a=f("countdown formatter",a,{{0},{c.at+1,tostring(math.ceil(c.at+1))},{61},{3601}})
else
a=false
end
k(d,a)
return a
end






a.PERCENT=Enum.DurationTextBindingProperty and Enum.DurationTextBindingProperty.RemainingPercent
function a.curveKey(a)return a.now..":"..a.late..":"..tostring(a.share)end
local c,e=c(16)
function a.curveFor(b)
if not(C_CurveUtil and C_CurveUtil.CreateColorCurve and CreateColor)then return nil end
local d=a.curveKey(b)
local a=c(d)
if a then return a end
a=C_CurveUtil.CreateColorCurve()
if Enum.LuaCurveType then a:SetType(Enum.LuaCurveType.Step)end
local f,c=CreateColor(h.rgba(b.late)),CreateColor(h.rgba(b.now))
if b.share and b.late~=b.now then
a:AddPoint(0,f)
a:AddPoint(b.share,c)
else
a:AddPoint(0,c)
a:AddPoint(100,c)
end
e(d,a)
return a
end




function a.mapOf(d,e,f,c,g)
if not c.stretches then return nil end
local a,b={},false
for g,c in ipairs(c.stretches)do
local d=(j.recordOf(c.view or d,e)or f).colour or"#ffffff"
a[g]={at=c.lo or 0,colour=d}
b=b or d~=a[1].colour
end
if not b then return nil end
return{from=g,stops=a}
end





local d=setmetatable({},{__mode="k"})
function a.coloursFor(a,b)
local a=a.colours
if not(a and b and b.greyed)then return a end
local b=d[a]
if not b then
local c=h.greyOf
if a.now then
b={now=c(a.now),late=c(a.late),share=a.share}
else
local d={}
for b,a in ipairs(a.stops)do d[b]={at=a.at,colour=c(a.colour)}end
b={from=a.from,stops=d}
end
d[a]=b
end
return b
end


local function d(d,b,c)
local c=c and c.tenths and c.tenths>0 and("/"..c.tenths)or""
if b and b.now then return a.curveKey(b)..c end
if b then return a.mapKey(b)end
return tostring(d.shape)..c
end


local function f(b,c)
if c then
local a=a.formatterFor(c)
if a then return a end
end
return(b.shape=="fromOne"or b.shape=="stacks:fromOne")and a.fromOneFormatter()or nil
end




function a.handCount(b,c,e)
local f=f(e,b.colours)
c:SetApplicationCount(b.fs,f and{formatter=f}or nil)
b.handedTo,b.handedBy,b.handedKey=c,a.handCount,d(e,b.colours)
b.handedSite="count rehand"
end

function a.handTime(b,f,h)
local c=b.colours
local e=a.timeFormatter(b.tenths)
local e=e and{textFormatter=e}or{}
local g=c and c.now and a.PERCENT and a.curveFor(c)
if g then e.textColor={curve=g,property=a.PERCENT}end
f:SetDurationText(b.fs,next(e)and e or nil)
b.handedTo,b.handedBy,b.handedKey=f,a.handTime,d(h,c,b)
b.handedSite="text rehand"
end


function a.rehand(c,e)
local a=c.handedBy==a.handTime and c or nil
if c.handedTo and c.handedKey~=d(e,c.colours,a)then
b.try(c.handedSite,c.handedBy,c,c.handedTo,e)
end
end

