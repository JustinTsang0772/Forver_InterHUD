



local a,c=...
local d,b,g=c.Layers,c.Art,c.Media

local a={one="One picture",sides="Pair, left and right",topBottom="Pair, above and below"}
local e={pulse="Pulse",breathe="Breathe",none="None"}






local a=d.register("spellAlert",{label="Spell Alert",
serves={spell=true,aura=true,totem=true,weaponEnchant=true,reagent=true,breath=true,
cast=true},
fields={
{name="picture",type="choice",choices=b.ALERT_KEYS,labels=b.ALERT_LABELS,default="genericArc1",
offered=b.alertPresent,control="picture",label="Picture"},
{name="arrangement",type="choice",choices={"one","sides","topBottom"},default="sides",
labels=a,label="Arrangement"},

{name="spread",type="number",default=205,min=0,max=1024,softMax=512,step=0.5,label="Gap",
help="Between the pair's inner edges.",under={"arrangement",{"sides","topBottom"}}},

{name="rotate",type="integer",default=0,min=0,max=270,step=90,label="Rotate"},
{name="blend",type="choice",choices={"normal","additive"},default="normal",
labels={normal="Normal",additive="Additive"},label="Blend"},

{name="colour",type="colour",default="#ffffff",label="Colour"},
{name="motion",type="choice",choices={"pulse","breathe","none"},default="pulse",
labels=e,label="Motion"},
},


changes={{name="colour",type="colour",label="Colour"}},
})

a.softSize=512


local e={side={102.5,205},top={205,102.5}}
local function f(a)
local a=b.alert(a.picture)
return a and a.shape or"side"
end
function a.pictureSize(a)
local b=e[f(a)]
return a.width or b[1],a.height or b[2]
end

function a.finish(c,b)
b.width,b.height=a.pictureSize(b)
end




local function i(e,f,g)
local a,b,c,d={0,0},{0,1},{1,0},{1,1}
for e=1,g do a,b,c,d=b,d,a,c end
if e then a,c,b,d=c,a,d,b end
if f then a,b,c,d=b,a,d,c end
return{a[1],a[2],b[1],b[2],c[1],c[2],d[1],d[2]}
end




function a.layout(c)
local a,b=a.pictureSize(c)
local d=c.spread or 205
local g=c.arrangement or"sides"
local h=math.floor((c.rotate or 0)/90+0.5)%4
if h%2==1 then a,b=b,a end
local c,e,f
if g=="one"then
c,e,f={{0,0,false,false}},a,b
elseif g=="topBottom"then
local g=(d+b)/2
c,e,f={{0,g,false,false},{0,-g,false,true}},a,2*b+d
else
local g=(d+a)/2
c,e,f={{-g,0,false,false},{g,0,true,false}},2*a+d,b
end
local d={w=e,h=f,pics={}}
for e,c in ipairs(c)do
d.pics[e]={x=c[1],y=c[2],w=a,h=b,coords=i(c[3],c[4],h)}
end
return d
end


function a.box(b)
local a=a.layout(b)
return a.w,a.h
end


local e={sides={"Left picture","Right picture"},topBottom={"Top picture","Bottom picture"}}
function a.pieces(b)
local c=e[b.arrangement or"sides"]
if not c then return nil end
local b=a.layout(b)
local d={}
for e,a in ipairs(b.pics)do
d[e]={x=b.w/2+a.x-a.w/2,y=b.h/2-a.y-a.h/2,w=a.w,h=a.h,
label=c[e]}
end
return d
end







function a.routes(b,a)
local b=d.sideRoutes(b,{"shownAnimation"})
local a=(a.arrangement or"sides")..":"..(a.motion or"pulse")
for c,b in ipairs(b)do b.shape=a end
return b
end
c.Debug.experimental("the art layer's pictures on a buff's button (Present's, a gate's), their motion handed to it as"
.." shown animations (AU-7 and AU-38 prove a glow's, FR-10 art under the button; a Scale or an Alpha on a texture"
.." there is new, and a shown animation may replay at a full refresh)","I")





c.Debug.experimental("the art's pulse as the game's two ordered Scale steps, repeating (Blizzard's form, run on"
.." our textures: FR-9, FR-19), until seen smooth in game; Breathe is the motion if it still hitches","C")
local d=1.08
local function e(a,c)
if c=="none"then return nil end
local a=a:CreateAnimationGroup()
if c=="breathe"then
a:SetLooping("BOUNCE")
local a=b.anim(a,"Alpha")
a:SetFromAlpha(1)
a:SetToAlpha(0.55)
a:SetDuration(0.8)
a:SetSmoothing("IN_OUT")
else
a:SetLooping("REPEAT")
local a,b=b.anim(a,"Scale",1),b.anim(a,"Scale",2)
a:SetScaleFrom(1,1)
a:SetScaleTo(d,d)
b:SetScaleFrom(1,1)
b:SetScaleTo(1/d,1/d)
for b,a in ipairs({a,b})do
a:SetDuration(0.5)
a:SetSmoothing("IN_OUT")
end
end
return a
end


function a.create(a,b)
local c=CreateFrame("Frame",nil,a)
local a={frame=c,pics={},groups={}}
local d=b.arrangement=="one"and 1 or 2
for d=1,d do
local c=c:CreateTexture(nil,"ARTWORK")
a.pics[d]=c
local b=e(c,b.motion or"pulse")
if b then a.groups[#a.groups+1]=b end
end
return a
end

local function e(a)
for b,a in ipairs(a.groups)do
if not a:IsPlaying()then a:Play()end
end
end



function a.apply(d,c,h)
local i=a.layout(c)
local f=b.alertDrawn(c.picture)
local g,j,k,l=g.rgba(c.colour or"#ffffff")
for b,a in ipairs(d.pics)do
local b=i.pics[b]
a:ClearAllPoints()
if b and f then
a:SetPoint("CENTER",d.frame,"CENTER",b.x,b.y)
a:SetSize(b.w,b.h)
a:SetTexture(f.id)
a:SetTexCoord(unpack(b.coords))
a:SetVertexColor(g,j,k,l or 1)
a:SetBlendMode(c.blend=="additive"and"ADD"or"BLEND")
a:Show()
else
a:Hide()
end
end
if not h.underButton then e(d)end
end



function a.families()
local a,d={},{}
for c,a in ipairs(b.ALERTS)do
if b.alertPresent(a.key)then
local c=d[a.family]
if not c then
c={key=a.family,label=b.FAMILY_LABELS[a.family],pictures={}}
d[a.family]=c
end
c.pictures[#c.pictures+1]={key=a.key,file=a.id,name=a.name,shape=a.shape}
end
end
for c,b in ipairs(b.FAMILIES)do
if d[b]then a[#a+1]=d[b]end
end
return a
end
function a.familyOf(a)
local a=b.alert(a)
return a and a.family
end


c.Schema.caveat("art picture missing",{
text="This picture isn't on this client: the nearest one it has shows instead.",
at=function(a)return c.Schema.isPath(a,"sources","*","layers","*","picture")end,
applies=function(a,c)
local a=a.sources and a.sources[c[2]]
local a=a and a.layers and a.layers[c[4]]
return a~=nil and a.kind=="spellAlert"and not b.alertPresent(a.picture)
end,
})


function a.feed()end


function a.shown(a)
e(a)
end


function a.handOver(b,a)
for b,d in ipairs(b.groups)do
c.try("art hand-off "..b,a.AddAuraShownAnimation,a,d)
end
end
