

local a,d=...
local b=d.Layers



local a=b.registerPart("gcdSweep",{label="GCD sweep",rung="gcdSweep",rides=true,
serves={spell=true}})



function a.routes(a)
return b.sideRoutes(a)
end


function a.create(a)
local b=CreateFrame("Frame",nil,a)
local a=CreateFrame("Cooldown",nil,b,"CooldownFrameTemplate")
a:SetDrawEdge(false)
a:SetDrawBling(false)
a:SetHideCountdownNumbers(true)
return{frame=b,cd=a}
end

function a.apply(a,c,e,f)
b.part("border").frameSwipe(a.cd,a.frame,c,f)
a.cd:SetFrameLevel(e.level+1)
a.cd:SetDrawSwipe(true)

a.cd:SetSwipeColor(d.Media.rgba(c.sweep and c.sweep.gcdColour or"#00000099"))
end

function a.feed(b,a)
if a.gcd then
b.cd:SetCooldownFromDurationObject(a.gcd,true)
elseif a.gcd==false then
b.cd:Clear()
end
end
