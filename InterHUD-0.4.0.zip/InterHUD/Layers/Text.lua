




local a,d=...
local c=d.Layers
local h=d.Media
local b=d.TextColours






local l={time="Time",name="Name",stacks="Stack count",count="Count",custom="Custom",
amount="Amount",percent="Percent",max="Maximum",missing="Missing health",shields="Shields",
range="Range"}


local e={power={"amount","percent","max","custom"},
health={"amount","percent","max","missing","shields","custom"}}
local g={combo=true}
local m={"amount","percent","max","missing","shields"}
local q={amount=true,percent=true,max=true,missing=true,shields=true}


local j={name="A bar growing up or down has no room for a name: pick another Content, or make the bar grow"
.." left or right."}
local i={up=true,down=true}

local function f(b)
local a={name="content",type="choice",labels=l,label="Content",
choicesFrom=function(b,a)
if a.kind=="reagent"then return{"count","name","custom"}end
if a.kind=="threat"then return{"custom"}end
if a.kind=="range"then return{"range","custom"}end
if e[a.kind]then return e[a.kind]end
if a.kind=="fiveSecondRule"or a.kind=="swing"then return{"time","custom"}end
if g[a.kind]then return{"amount","max","custom"}end
local b=a.layer
if type(b)=="table"and b.kind=="bar"and i[b.grows]then
return a.kind=="aura"and{"time","stacks","custom"}or{"time","custom"},j
end
if a.kind=="aura"then return{"time","name","stacks","custom"}end
return{"time","name","custom"}
end}
if not b then
a.defaultFrom=function(b,a)
return a.kind=="reagent"and"count"or a.kind=="threat"and"custom"
or a.kind=="range"and"range"
or(e[a.kind]or g[a.kind])and"amount"or"time"
end
end
return a
end

local function e()
return{name="words",type="string",max=64,under={"content","custom"},label="Words"}
end


local function g()
local a=b.tenthsField()
a.under={"content","time"}
return a
end


local function n()
return{name="fromOne",type="boolean",default=false,under={"content","stacks"},
label="Counts from 1"}
end



local function j()return{name="colour",type="colour",default="#ffffff",label="Colour"}end


local function o()
return{f(true),e(),{name="colour",type="colour",label="Colour"}}
end





d.Debug.experimental("a text cut at its Max width with the client's ellipsis","I")
local function k(a)
return{name="maxWidth",type="number",min=1,max=1024,step=0.5,unit="px",label="Max width",
help=a or"Empty: as long as its words."}
end

local a=c.register("text",{label="Text",ownBox=true,
serves={spell=true,aura=true,totem=true,weaponEnchant=true,reagent=true,breath=true,
cast=true,power=true,combo=true,health=true,fiveSecondRule=true,swing=true,range=true},

fields={f(),e(),n(),g(),j(),b.fontField(),b.sizeField(),k()},
changes=o(),
})


function a.box(a)
return a.maxWidth,nil
end


function a.line(a)
return b.sizeOf(a)
end



local p,r=b.nudgeFields()
local f=c.registerPart("barText",{label="Text",rung="text",repeats=true,idWord="text",
fromLayer={"grows","timeFont"},fields={
f(),
e(),
n(),
g(),
j(),
b.fontField(),
b.sizeField(),
k("Empty: as long as its words. A name stops short of the bar's time text, where the bar has one."),
{name="justify",type="choice",choices={"LEFT","CENTER","RIGHT"},default="CENTER",
labels={LEFT="Left",CENTER="Centre",RIGHT="Right"},group="place",label="Side"},
p,r,
},changes=o()})






local function n(a,b,c)
local a={name="content",type="choice",choices=a,labels=l,label="Content"}
if not c then a.default=b end
return a
end
local l,o={"name","custom"},{"time","custom"}


local r={spell=true,aura=true,totem=true,weaponEnchant=true,breath=true,cast=true}

local s={spell=true,aura=true,totem=true,weaponEnchant=true,breath=true,cast=true,
fiveSecondRule=true,swing=true}
local function p(f,h,i,a,m,p,q,s)
local d,t=b.nudgeFields()
d.default=q
local b={
n(a,m),
e(),
j(),
b.fontField(),
b.sizeField(),
k(a==l and"Empty: as long as its words; it stops short of the bar's time."or nil),
{name="justify",type="choice",choices={"LEFT","CENTER","RIGHT"},default=p,
labels={LEFT="Left",CENTER="Centre",RIGHT="Right"},group="place",label="Side"},
d,t,
}

if a==o then table.insert(b,3,g())end
return c.registerPart(f,{label=h,labelFrom=i,rung="text",enabled=false,
serves=s or r,
fromLayer={"grows","timeFont"},fields=b,
changes={n(a,nil,true),e(),{name="colour",type="colour",label="Colour"}}})
end
local j=p("barName","Name text",nil,l,"name","LEFT",4)
local e=p("barTime","Time",nil,o,"time","RIGHT",-4,s)

c.attach("bar","nameText","barName",{under={"grows",{"right","left"}}})
c.attach("bar","time","barTime")
c.attach("bar","texts","barText",{list=true,max=8,label="Texts"})
d.Schema.rule("layer","no name upright",function(a,c,b)
local a=a.kind=="bar"and i[a.grows]and a.nameText
if type(a)=="table"and a.enabled==true then
c:problem((b==""and""or b..".").."nameText.enabled",
"A bar growing up or down has no room for a name: switch its Name text off first.",
function()a.enabled=nil end)
end
end)





local k={time={"durationText"},stacks={"applicationCount"}}
local function g(e,b,f)
local a=b.content
local d=k[a]

if b~=f then d=c.partSockets(e,f,d)end
local c=c.sideRoutes(e,d,k[a]~=nil)
for d,c in ipairs(c)do c.shape=a=="stacks"and b.fromOne and"stacks:fromOne"or a end
return c
end
function a.routes(b,a)return g(b,a,a)end


local k={time=true,stacks=true}
function a.buttonText(a)return a.content==nil or k[a.content]==true end
f.buttonText=a.buttonText

function a.missingNoun(a)return a.content=="stacks"and"stacks"or"time"end
f.missingNoun=a.missingNoun
f.routes=g


e.buttonText=function(a)return a.content==nil or a.content=="time"end
e.missingNoun=function()return"time"end
e.routes=g
function j.routes(b,c,a)
if i[a.grows]then return{}end
return g(b,c,a)
end


function a.colourByTime(a)return type(a)=="table"and(a.content==nil or a.content=="time")end

function a.create(a)
local a=CreateFrame("Frame",nil,a)

local b=b.fontString(a)
b:SetWordWrap(false)

return{frame=a,fs=b,values={}}
end


function a.handedColours(f,e,d)
local a=c.recordOf(f,e)
if a.content=="stacks"then return b.mapOf(f,e,a,d,a.fromOne and 1 or 2)end
if a.content~="time"then return nil end
local b=a.colour or"#ffffff"
local f=b

if d.share and d.late and e.holder=="button"then f=(c.recordOf(d.late,e)or a).colour or b end
return{now=b,late=f,share=d.share}
end


function a.colourByCount(a)return type(a)=="table"and a.content=="stacks"end






d.Debug.experimental("a level as text: a secret amount or maximum through AbbreviateNumbers into SetText, a percent"
.." into SetFormattedText's %.0f (FR-27 drew both through SetFormattedText's %s and string.format's %d in a fight;"
.." these two calls unseen: the power source's own test)","I")
d.Debug.experimental("shields as text: UnitGetTotalAbsorbs, secret, through C_StringUtil.TruncateWhenZero into SetText,"
.." blank at none (FR-40: the docs and EllesmereUI's absorb text on Forever; unseen: EP-65)","D")
local function i(b,c,a)
if not(d.isSecret(a)or a)then
b:SetText("")
elseif c=="percent"then
b:SetFormattedText("%.0f%%",a)
elseif c=="shields"and C_StringUtil and C_StringUtil.TruncateWhenZero then
b:SetText(C_StringUtil.TruncateWhenZero(a))
else
b:SetText(AbbreviateNumbers(a))
end
end


local function n(c,d,a)
if a.shape=="stacks"or a.shape=="stacks:fromOne"then
b.handCount(c,d,a)
else
b.handTime(c,d,a)
end
end






local function k(b)
if not(C_DurationUtil and C_DurationUtil.CreateDurationTextBinding)then return nil end
local a=C_DurationUtil.CreateDurationTextBinding()
a:SetFontString(b)
a:SetZeroDurationText("")
return a
end


local l={up={LEFT="BOTTOM",CENTER="CENTER",RIGHT="TOP"},
down={LEFT="TOP",CENTER="CENTER",RIGHT="BOTTOM"}}

local function o(a,b)
if not a.measure then
a.measure=a.frame:CreateFontString(nil,"OVERLAY")
a.measure:Hide()
end
h.setFont(a.measure,b.style or{},b.size)
a.measure:SetText("0:00")
return a.measure:GetStringWidth()
end

local function p(b,a,c,d)
if b=="LEFT"then return a end
if b=="RIGHT"then return c+a-d end
return(c-d)/2+a
end



local g=4
local function r(d,a,c)
if a.maxWidth then return a.maxWidth end
local b=a.timeFont
if not(a.justify and a.content=="name"and b and c and c.w)or l[a.grows]then return 0 end
local e,c=c.w,o(d,b)
local b=p(b.justify,b.x or 0,e,c)
local f=b+c
local c=a.x or 0
local d
if a.justify=="LEFT"then
d=b>c and b-g-c
elseif a.justify=="RIGHT"then
d=f<e+c and e+c-f-g
else
local a=e/2+c
d=(b>a and 2*(b-g-a))or(f<a and 2*(a-f-g))
end
return d and math.max(1,d)or 0
end
local function o(c,d,a,e)
h.setFont(c,a.style,b.sizeOf(a))

if a.justify then
local e=l[a.grows]
b.place(c,d,e and e[a.justify]or a.justify,a.x,a.y)
else
b.place(c,d,a.position and a.position.point or"CENTER",0,0,true)
end

c:SetWidth(e)
c:SetTextColor(h.rgba(a.colour or"#ffffff"))
end

function a.apply(a,c,f,j)
local g=f.shape=="time"
local h=not f.underButton
if g and h and not a.binding then a.binding=k(a.fs)end
local e=a.fs
if(c.content=="time")~=g then
if not a.alt then
a.alt=b.fontString(a.frame)
a.alt:SetWordWrap(false)
if not g and h then a.binding=k(a.alt)end
end
e=a.alt
end
a.fs:SetShown(e==a.fs)
if a.alt then a.alt:SetShown(e==a.alt)end
a.shown=e
o(e,a.frame,c,r(a,c,j))
a.content,a.fromOne=c.content,c.fromOne


if c.content=="custom"then
e:SetText(c.words or"")
elseif c.content=="name"and(d.isSecret(a.name)or a.name~=nil)then
e:SetText(a.name)
elseif c.content=="range"then
e:SetText(a.range or"")
elseif c.content=="count"and a.count~=nil then
e:SetText(a.count or"")
elseif c.content=="stacks"and a.stacks~=nil and not f.underButton then
e:SetText(a.stacks or"")
elseif q[c.content]then
i(e,c.content,a.values[c.content])
end


local d=c.tenthsBelow or 0
if a.binding and a.boundTenths~=d then
local b=b.timeFormatter(d)
if b then a.binding:SetFormatter(b)end
a.boundTenths=d
end
a.tenths=d
local c=b.coloursFor(f,c)
a.colours=c

local c=a.binding and c and c.now and b.PERCENT and b.curveFor(c)
if c then
a.binding:SetTextColorCurve(c,b.PERCENT)
a.curved=true
elseif a.curved then
a.binding:ClearTextColorCurve()
a.curved=nil
end

b.rehand(a,f)
end

local c=c.emptyDuration

function a.feed(a,b)
if a.binding then
if b.duration then
a.binding:SetDuration(b.duration)
a.binding:SetEnabled(true)
elseif b.duration==false then
a.binding:SetDuration(c())
end
end
local c=a.shown or a.fs


local e=b.name
if d.isSecret(e)or e then
a.name=e
if a.content=="name"then c:SetText(e)end
elseif e==false then
a.name=nil
if a.content=="name"then c:SetText("")end
end

if b.range~=nil then
a.range=b.range or nil
if a.content=="range"then c:SetText(b.range or"")end
end
if b.stacks~=nil then

local d=a.fromOne and 1 or 2
a.stacks=b.stacks and b.stacks>=d and tostring(b.stacks)or false
if a.content=="stacks"then c:SetText(a.stacks or"")end
end
if b.count~=nil then
a.count=b.count and tostring(b.count)or false
if a.content=="count"then c:SetText(a.count or"")end
end
local f=a.values
for e=1,#m do
local e=m[e]
local b=b[e]
if d.isSecret(b)or b~=nil then
f[e]=b
if a.content==e then i(c,e,b)end
end
end
end



function a.handOver(a,b,c)n(a,b,c)end

for c,b in ipairs({f,j,e})do
b.create,b.apply,b.feed,b.handOver=a.create,a.apply,a.feed,a.handOver

b.handedColours,b.colourByCount,b.colourByTime=a.handedColours,a.colourByCount,a.colourByTime
end
