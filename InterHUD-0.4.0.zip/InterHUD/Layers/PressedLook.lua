




local a,j=...
local b=j.Schema
local e=j.Layers
local d=j.Styles
local n=j.Media

local a={{kind="icon"}}

d.part("pressed",{label="Pressed",title="Pressed look",kinds=true,default="edge",rank=20,
help="The pressed look on spell icons, where it is switched on.",
sample={layers=a,state="ready",facts={pressed=true}},fields={
{name="colour",type="colour",default="#ffe08a",label="Colour"},
{name="strength",type="number",default=0.35,min=0.1,max=1,step=0.05,label="Strength"},
{name="size",type="number",default=2,min=1,max=10,step=1,unit="px",label="Thickness"},
}})
d.kind("pressed","none",{label="None"})
d.kind("pressed","edge",{label="Edge glow",uses={colour=true,strength=true}})

d.kind("pressed","blizzard",{label="Blizzard's",art={atlas="UI-HUD-ActionBar-IconFrame-Down",
inset={0,1/45,0,0}}})
d.kind("pressed","classic",{label="Classic",art={file="Interface\\Buttons\\UI-Quickslot-Depress",
inset={0,0,0,0}}})
d.kind("pressed","solid",{label="Solid colour",uses={colour=true,strength=true}})
d.kind("pressed","border",{label="Border",uses={colour=true,size=true}})




local a=e.registerPart("pressed",{label="Pressed look",rung="pressed",rides=true,
shown=false,lookShown=true,serves={spell=true},fields={b.styleField("pressed")}})


e.attach("icon","sweep","sweep")
e.attach("icon","gcdSweep","gcdSweep")
e.attach("icon","time","time")
e.attach("icon","count","count")
e.attach("icon","border","border")
e.attach("icon","pressed","pressed")

b.extendVariant("layer","icon",d.cueFields())
e.attach("icon","glows","glow",{list=true,label="Glows"})

function a.routes(a)
return e.sideRoutes(a)
end


function a.create(a)
local c=CreateFrame("Frame",nil,a)
local a=CreateFrame("Frame",nil,c)
a:SetAllPoints()
local d=a:CreateTexture(nil,"OVERLAY")
local e=a:CreateMaskTexture()
d:AddMaskTexture(e)
local b={}
for c=1,4 do
b[c]=a:CreateTexture(nil,"OVERLAY")
b[c]:SetTexture(n.WHITE)
end
return{frame=c,fx=a,tex=d,mask=e,lines=b}
end

function a.apply(h,k,a,i)
h.fx:SetFrameLevel(a.level+1)
local a=k.framedBy and e.part("border").framing(k.framedBy,math.min(i.w,i.h),k.scale)
local a,m=a and a.inset or 0,a and a.look or{}
local c,b,g,l=h.fx,h.tex,h.mask,k.style
local f=d.kindOf("pressed",l)
local i=i.w-2*a

g:ClearAllPoints()
if m.mask then
g:SetAtlas(m.mask.atlas,false,nil,nil,"CLAMPTOBLACKADDITIVE","CLAMPTOBLACKADDITIVE")
g:SetPoint("CENTER",c,"CENTER",0,0)
g:SetSize(i*(m.mask.scale or 1),i*(m.mask.scale or 1))
else
g:SetTexture(n.WHITE,"CLAMPTOBLACKADDITIVE","CLAMPTOBLACKADDITIVE")
g:SetPoint("TOPLEFT",c,"TOPLEFT",a,-a)
g:SetPoint("BOTTOMRIGHT",c,"BOTTOMRIGHT",-a,a)
end
b:ClearAllPoints()
for b,a in ipairs(h.lines)do
a:ClearAllPoints()
a:Hide()
end
local g,m,n=n.rgba(l.colour)
if f==d.get("pressed","none")then
b:Hide()
return
end
if f==d.get("pressed","edge")then
b:SetTexture(j.Art.MEDIA.."Pressed-Edge")
b:SetVertexColor(g,m,n,l.strength)
b:SetPoint("TOPLEFT",c,"TOPLEFT",a,-a)
b:SetPoint("BOTTOMRIGHT",c,"BOTTOMRIGHT",-a,a)
b:Show()
return
end
if f.art then
local d=f.art.inset
if f.art.atlas then b:SetAtlas(f.art.atlas)else b:SetTexture(f.art.file)end
b:SetVertexColor(1,1,1,1)
b:SetPoint("TOPLEFT",c,"TOPLEFT",a-d[1]*i,-(a-d[3]*i))
b:SetPoint("BOTTOMRIGHT",c,"BOTTOMRIGHT",-(a-d[2]*i),a-d[4]*i)
b:Show()
elseif f==d.get("pressed","solid")then
b:SetColorTexture(g,m,n,l.strength)
b:SetPoint("TOPLEFT",c,"TOPLEFT",a,-a)
b:SetPoint("BOTTOMRIGHT",c,"BOTTOMRIGHT",-a,a)
b:Show()
else
b:Hide()
local d=e.lineWidth(l.size,k.scale)
local b,a=h.lines,a
b[1]:SetPoint("TOPLEFT",c,"TOPLEFT",a,-a);b[1]:SetPoint("TOPRIGHT",c,"TOPRIGHT",-a,-a)
b[1]:SetHeight(d)
b[2]:SetPoint("BOTTOMLEFT",c,"BOTTOMLEFT",a,a);b[2]:SetPoint("BOTTOMRIGHT",c,"BOTTOMRIGHT",-a,a)
b[2]:SetHeight(d)
b[3]:SetPoint("TOPLEFT",c,"TOPLEFT",a,-a-d);b[3]:SetPoint("BOTTOMLEFT",c,"BOTTOMLEFT",a,a+d)
b[3]:SetWidth(d)
b[4]:SetPoint("TOPRIGHT",c,"TOPRIGHT",-a,-a-d)
b[4]:SetPoint("BOTTOMRIGHT",c,"BOTTOMRIGHT",-a,a+d)
b[4]:SetWidth(d)
for b,a in ipairs(b)do
a:SetVertexColor(g,m,n,1)
a:Show()
end
end
end

function a.feed()end
