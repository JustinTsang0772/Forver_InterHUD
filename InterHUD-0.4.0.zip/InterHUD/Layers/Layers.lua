

local a,g=...
local d=g.Schema

local a={}
g.Layers=a

local c,e,i={},{},{}






local function f(a,b)
return{name=a,type="keys",minItems=1,maxItems=8,failsRecord=true,label=b}
end
function a.register(a,b)
assert(not c[a],"layer kind registered twice: "..a)
c[a]=b
b.kind=a
b.parts={}
d.variant("layer",a,b.fields,{serves=b.serves})
local c={f("while","While"),f("unless","Unless"),
{name="shown",type="boolean",label="Shown"},
{name="opacity",type="percent",label="Opacity"}}
for b,a in ipairs(b.changes or{})do c[#c+1]=a end

d.record("look:"..a,{fields=c,unknown=d.notByLook})
d.extendVariant("layer",a,{{name="looks",type="list",record="look:"..a,maxItems=32,
label="Looks"}})
return b
end












function a.partLabel(a,b)
local a=e[a]
return a.labelFrom and a.labelFrom(b or{})or a.label
end

function a.registerPart(c,a)
assert(not e[c],"part kind registered twice: "..c)
e[c]=a
a.kind=c
local b={}
if a.repeats then
b[#b+1]={name="id",type="id",label="Id"}


b[#b+1]={name="name",type="string",max=48,label="Name"}
end
local e=a.enabled
if e==nil then e=true end
if a.switch~=false then
local a={name="enabled",type="boolean",label="On"}
if type(e)=="function"then a.defaultFrom=e else a.default=e end
b[#b+1]=a
end
b[#b+1]={name="shown",type="boolean",default=a.shown~=false,label="Shown"}
for c,a in ipairs(a.fields or{})do b[#b+1]=a end
d.record("part:"..c,{fields=b,idSpace=a.repeats and"element"or nil,
madeId=a.repeats and function()return a.idWord or c end or nil,
context=function(b,a)a.ownStyle=true end})
local b={{name="shown",type="boolean",label="Shown"}}
for c,a in ipairs(a.changes or{})do b[#b+1]=a end
d.record("partLook:"..c,{fields=b,unknown=d.notByLook})
return a
end






function a.attach(g,h,b,a)
a=a or{}
local i,c=assert(c[g],"no layer kind "..g),assert(e[b],b)
local e,f
if a.list then
e={name=h,type="list",record="part:"..b,maxItems=a.max or 16,default={},
label=a.label or c.label}
f={name=h,type="map",record="partLook:"..b,ref="part",
label=a.label or c.label}
else
e={name=h,type="record",record="part:"..b,label=a.label or c.label}
f={name=h,type="record",record="partLook:"..b,label=a.label or c.label}
end
e.serves,e.partKind,e.repeats,e.partUnder=c.serves,b,a.list or nil,a.under
f.serves,f.partKind,f.repeats,f.partUnder=c.serves,b,a.list or nil,a.under
if not a.label then e.labelFrom,f.labelFrom=c.labelFrom,c.labelFrom end
d.extendVariant("layer",g,{e})
d.record("look:"..g,{fields={f}})
d.moveLast("layer",g,"looks")
i.parts[#i.parts+1]={key=h,kind=b,list=a.list or nil,
max=a.list and(a.max or 16)or nil}
end


function a.registerEffect(a,b)
assert(not i[a],"effect kind registered twice: "..a)
i[a]=b
d.variant("effect",a,b.fields)
return b
end

function a.get(a)return c[a]end
function a.part(a)return e[a]end
function a.effect(a)return i[a]end

function a.specOf(a)
if a.effect then return i[a.kind]end
if a.partKey then return e[a.kind]end
return c[a.kind]
end


function a.partsOf(a)return c[a]and c[a].parts or{}end












































function a.sideRoutes(a,b,c)
if a==nil then return{{holder="layer"}}end
if a=="missing"then
if c then return{}end
return{{holder="missing",state="missing"}}
end
if b then return{{holder="button",state="present",sockets=b}}end
return{{holder="present",state="present"}}
end







function a.toPixels(b,c)
local a=a.truePixel()/(c or 1)
return math.floor(b/a+0.5)*a
end

function a.onPixels(e,f,g,h,b)
local c,d=a.toPixels(e,b),a.toPixels(f,b)
local e,f=a.toPixels(e+g,b),a.toPixels(f+h,b)
local a=a.truePixel()/(b or 1)
if g>0 and e-c<a then e=c+a end
if h>0 and f-d<a then f=d+a end
return c,d,e-c,f-d
end

function a.boxSize(c,b)
b=b or c.rootScale
return math.max(a.toPixels(c.baseSize,b),a.truePixel()/(b or 1))
end





local f={TOPLEFT={0,0},TOP={0.5,0},TOPRIGHT={1,0},LEFT={0,0.5},CENTER={0.5,0.5},
RIGHT={1,0.5},BOTTOMLEFT={0,1},BOTTOM={0.5,1},BOTTOMRIGHT={1,1}}
a.OFFSETS=f

a.SIDES={width=true,height=true,length=true,thickness=true}




local b={x=0,y=0}



local h={w=setmetatable({},{__mode="k"}),h=setmetatable({},{__mode="k"}),
pieces=setmetatable({},{__mode="k"})}
local function k(d,a)
if b.src==nil then return d.box(a)end
local b,c=h.w[a],h.h[a]
if b==nil then
b,c=d.box(a)
b,c=b or false,c or false
h.w[a],h.h[a]=b,c
end
return b or nil,c or nil
end

local function j(d)
local c=c[d.kind]
if not(c and c.pieces)then return nil end
local a
if b.src==nil then
a=c.pieces(d)
else
a=h.pieces[d]
if a==nil then
a=c.pieces(d)or false
h.pieces[d]=a
end
end
return a and#a>0 and a or nil
end


function a.withDrag(a,c,d,e,f,h,i)
local j,k,l,m=b.src,b.id,b.x,b.y
b.src,b.id,b.x,b.y=a,c,d,e
local a,c,d,e,f=g.try("layer drag",f,h,i)
b.src,b.id,b.x,b.y=j,k,l,m
return a,c,d,e,f
end



local function l(h,e,b,c,f)
local g=e.to
if g==nil or c==nil or f>#c then return 0,0,b,b end
for i,d in ipairs(c)do
if d.id==g and d~=h then
local b,c,f,g=a.rect(d,b,c,f+1)

local a=e.piece and j(d)
local a=a and a[e.piece]
if a then return b+a.x,c+a.y,a.w,a.h end
return b,c,f,g
end
end
return 0,0,b,b
end


function a.rect(a,e,j,m)
local g=c[a.kind]
local c,d
if g and g.box then c,d=k(g,a)end
local h=a.position

if g and g.ownBox then c,d=c or e,d or e end
c,d=c or a.width or e,d or a.height or e
local g,i=h.x,h.y

if b.src~=nil and a.id==b.id and a.source==b.src then
g,i=b.x,b.y
elseif a.fill then
return(e-c)/2,(e-d)/2,c,d
end
local e,j,k,l=l(a,h,e,j,m or 1)
local a,b=f[h.toPoint]or f.CENTER,f[h.point]or f.CENTER
local a,e=e+a[1]*k+g,j+a[2]*l-i
return a-b[1]*c,e-b[2]*d,c,d
end



function a.pieces(b,d)
local c=j(b)
if c then return c end
local c,d,a,b=a.rect(b,d)
return{{x=0,y=0,w=a,h=b}}
end


function a.anchoredTo(a,e)
local f={}
local c={}
for b,a in ipairs(a)do
if a.id~=nil and c[a.id]==nil then c[a.id]=b end
end
for g,b in ipairs(a)do
local b,d=b,0
while g~=e and b and d<#a do
local c=type(b.position)=="table"and c[b.position.to]
if not c then break end
if c==e then
f[g]=true
break
end
b,d=a[c],d+1
end
end
return f
end

function a.layersOf(a)
if type(a)~="table"then return{}end
if a.layers then return a.layers end
local b={}
for c,a in ipairs(type(a.sources)=="table"and a.sources or{})do
for c,a in ipairs(type(a)=="table"and type(a.layers)=="table"and a.layers or{})do
if type(a)=="table"then b[#b+1]=a end
end
end
return b
end

function a.kindLabel(a)
local b=a and c[a.kind]
return b and b.label or tostring(a and a.kind)
end


function a.nameOf(e,b)
if not b then return""end
if b.name then return b.name end
local c=a.kindLabel(b)
local a,d=0,0
for e,c in ipairs(e or{})do
if c.kind==b.kind then
a=a+1
if c==b or(c.id~=nil and c.id==b.id)then d=a end
end
end
return a>1 and(c.." "..d)or c
end


function a.drawnRectInto(c,d,e,b)
local d,e,f,g=a.rect(c,d,e)
b.x,b.y,b.w,b.h=a.onPixels(d,e,f,g,c.scale)
return b
end
local function k(b,c,d)return a.drawnRectInto(b,c,d,{})end




function a.area(b,d,e)
local e,g,h,d=a.rect(b,d,e)
local a=c[b.kind]
local a=a and a.line and a.line(b)
if a and a<d then

local b=f[b.position and b.position.point]or f.CENTER
return e,g+b[2]*(d-a),h,a
end
return e,g,h,d
end








function a.bounds(c,e,g,b,n)
local i,m=c.baseSize,c.allLayers or c.layers
local d,h,j,k=math.huge,math.huge,-math.huge,-math.huge
for b,l in ipairs(c.layers)do
if not e or a.ownsLayer(c,l)then
local b,c,e,f
if n then b,c,e,f=a.rect(l,i,m)else b,c,e,f=a.area(l,i,m)end
if g then b,c,e,f=a.onPixels(b,c,e,f,g)end
d,h=math.min(d,b),math.min(h,c)
j,k=math.max(j,b+e),math.max(k,c+f)
end
end
b=b or{}
if d==math.huge then
local a=g and a.boxSize(c,g)or i
b.x,b.y,b.w,b.h=0,0,a,a
else
b.x,b.y,b.w,b.h=d,h,j-d,k-h
end
return b
end





function a.ownsLayer(a,b)
return a.run==nil or b.source==a.run
end
function a.ownsEffect(a,b)
local b=b.at or{}
if a.host then return b.customState~=nil end
if a.run==nil then return true end
return b.customState==nil and b.source==a.run
end



function a.place(b,c,a)
assert(c~=nil,"LYR.place: no frame to place on")
b:ClearAllPoints()
b:SetPoint("TOPLEFT",c,"TOPLEFT",a.x,-a.y)
b:SetSize(a.w,a.h)
end






local b,h,f=10,12,200
a.BASE_LEVEL=b+f
function a.level(a,c)
return b+(c and 0 or f)+a*h
end

function a.below(a)return d.alertFlag(a,"below")end

function a.levelOf(b,c)return a.level(c,a.below(b))end








a.RUNGS={picture=0,gcdSweep=1,lines=1,look=2,swipe=3,glow=4,border=6,borderCopy=7,
pressed=8,text=10}





g.Debug.experimental("an aura layer's parts with no socket (a border, a bar's name text) on its own button, over it"
.." (a clip draws its children at its one level: FR-38)","I")
function a.partSockets(d,a,b)
if d~="present"or not(c[a.kind]and c[a.kind].onButton)then return b end
return b or{}
end








g.Debug.experimental("each aura clip (Present's, Missing's, another aura's side for a copy or an effect) just under its"
.." lowest part, so its layers draw at their listed place (FR-38: a clip's children drawn at its level)","I")
function a.clipLevel(b)
local a
for c,b in ipairs(b)do
if b.level and(not a or b.level<a)then a=b.level end
end
return a and a-1
end




function a.onButtonPresent(b,c)
for b,a in ipairs(a.parts({layers={b},baseSize=c},"present"))do
if a.underButton then return true end
end
return false
end

function a.inList(a,b)
for c,a in ipairs(a)do
if a==b then return true end
end
return false
end


a.MULTI={shownAnimation=true,assignedAnimation=true}










function a.parts(d,h,f)
f=f or{}
local g={}
local j=a.truePixel()
local function i(b,d,e,f,h,i,k)
local c=#g+1
g[c]={n=c,layer=d,partKey=i,item=k,kind=h,holder=b.holder,state=b.state,
sockets=b.sockets,shape=b.shape,rect=e,level=f+(a.RUNGS[b.rung]or 0),pixel=j,
underButton=(b.holder=="button"or b.holder=="expiring")or nil}
return g[c]
end
for g,b in ipairs(d.layers)do
if a.ownsLayer(d,b)and(not f.only or f.only[g])
and not(f.dropHidden and b.shown==false)then
local c=c[b.kind]
local j=k(b,d.baseSize,d.allLayers or d.layers)
local k=a.levelOf(d,g)
local d
if c.routes then
for c,a in ipairs(c.routes(h,b,b))do
local a=i(a,g,j,k,b.kind)
d=d or a
end
end
local function l(c,e,l,m)
if not(c.routes and type(e)=="table"and e.enabled~=false)then return end
if f.dropHidden and e.shown==false then return end
local d=h==nil and c.rides and b.kind=="icon"and d and d.n or nil
for e,b in ipairs(c.routes(h,e,b))do
i(b,g,j,k+(a.RUNGS[c.rung]or 0),c.kind,l,m).rides=d
end
end
for c,a in ipairs(c.parts)do
local c=e[a.kind]
if a.list then
for b,d in ipairs(b[a.key]or{})do l(c,d,a.key,b)end
else
l(c,b[a.key],a.key)
end
end
end
end
return g
end



function a.recordOf(b,a)
if a.effect then return b.effects[a.effect]end
local b=b.layers[a.layer]
if not a.partKey then return b end
local b=b and b[a.partKey]
if a.item and type(b)=="table"then b=b[a.item]end
return b
end













local n,o={"present","missing"},{false}

local function p(a,b)
if a.fact~=nil or a.customState~=nil or not b then return nil end
return b.says
end
function a.effectParts(b,e,d,c)
local h={}

local g={}
for b,a in ipairs(d)do
if a.layer and not a.partKey and not g[a.layer]and(e or a.holder=="button")then g[a.layer]=a end
end
local j
for a,b in ipairs(b.layers)do
if b.kind=="icon"and g[a]then j=g[a]break end
end
local m=b.baseSize
local d=a.boxSize(b)
local q={x=0,y=0,w=d,h=d}


local function l(d,c)
local e=not a.ownsLayer(b,c)
local f=b.plainRuns and b.plainRuns[c.source]or false
return{rect=k(c,m,b.allLayers or b.layers),level=a.levelOf(b,d),layer=d,
run=e and c.source or nil,plain=e and f or nil,owner=c.source,
ownerPlain=f}
end
for m,f in ipairs(b.effects or{})do
local i=i[f.kind]
local d=f.at or{}
if i.create and(c==nil or c[d.event])and a.ownsEffect(b,f)then
local c={}
local k=f.over
if k then
for a,d in ipairs(k)do
for a,b in ipairs(b.layers)do
if b.id==d then c[#c+1]=g[a]or l(a,b)end
end
end
elseif j then
c[1]=j
elseif b.host then
for b,a in ipairs(b.layers)do
if a.kind=="icon"then
c[1]=l(b,a)
break
end
end
end


if#c==0 and not k then c[1]=false end
local j=b.variant and b.variant.events and b.variant.events[d.event]
for g,c in ipairs(c)do
c=c or nil
local g=c and c.run~=nil


local l=e and c~=nil and(not g or c.plain)
local r=a.effectMoves({plain=e,event=d.fact==nil and d.customState==nil and j or nil,
target=c and{cross=g,plain=c.plain}or nil})

local s=(c and c.level or a.levelOf(b,1))-1
local k=nil
if l then k=g and{run=c.run,layer=c.layer}or c.n end


local g=c and c.owner~=b.run and c.owner or nil
local l=(e and g and not c.ownerPlain)and n or o
for n,l in ipairs(l)do
h[#h+1]={effect=m,kind=f.kind,event=d.event,fact=d.fact,item=d.item,
customState=d.customState,rect=c and c.rect or q,pixel=a.truePixel(),
level=a.levelOf(b,#b.layers+m),backLevel=s,target=k,
onLayer=c and c.layer or nil,onRun=g,side=l or nil,
holder=e and"host"or"button",sockets=not e and{"assignedAnimation"}or nil,
underButton=not e or nil,shape=i.shape and i.shape(f,r)or nil,

says=p(d,j)}
end
end
end
end
return h
end








function a.effectMoves(a)
if not a.plain then return false,"button"end
if a.event and a.event.still then return false,"still"end
local a=a.target
if not a then return false,"none"end
if a.cross and not a.plain then return false,"button"end
return true
end


function a.allParts(c,d,e,b)
local b=a.parts(c,d,b)
for c,a in ipairs(a.effectParts(c,d==nil,b,e))do
a.n=#b+1
b[a.n]=a
end
return b
end




local c={rect=true,cell=true,expire=true,pixel=true,colours=true,moment=true,moments=true,
late=true}
local function b(a)
if type(a)~="table"then return a end
local d={}
for a,e in pairs(a)do
if not c[a]then d[a]=b(e)end
end
return d
end
a.structureOf=b

local function d(a,b)
if a==b then return true end
if type(a)~="table"or type(b)~="table"then return false end
for a,e in pairs(a)do
if not c[a]and not d(e,b[a])then return false end
end
for b in pairs(b)do
if not c[b]and a[b]==nil then return false end
end
return true
end
a.sameStructure=d



function a.curve(a,c)
if not(C_CurveUtil and C_CurveUtil.CreateCurve)then return nil end
local b=C_CurveUtil.CreateCurve()
if c and Enum.LuaCurveType then b:SetType(Enum.LuaCurveType[c])end
for c=1,#a,2 do b:AddPoint(a[c],a[c+1])end
return b
end








g.Debug.experimental("a gate key that changes a look: two copies under complementary curves, one lit at a time"
.." (A6 for each curve; the complement unrecorded, the soonclip probe unrun)","I")
local c={}
function a.lastCurve(b,f,g)
if not b or b<=0 then return nil end
local d=(f and"held"or"last")..(g and":off"or"")
c[d]=c[d]or{}
local e=c[d][b]
if e==nil then
local f=f and{0,1,b,1,b+0.05,0}or{0,0,0.05,1,b,1,b+0.05,0}
if g then
for a=2,#f,2 do f[a]=1-f[a]end
end
e=a.curve(f)or false
c[d][b]=e
end
return e or nil
end








local g=1e-6
local c={[true]={},[false]={}}
function a.levelCurve(b,d)
local e=c[d==true]
local c=e[b]
if c==nil then
local f,d=d and 0 or 1,d and 1 or 0
local d=b>=100 and{0,d,1,f}or{0,f,b/100+g,d,1,d}
c=a.curve(d,"Step")or false
e[b]=c
end
return c or nil
end






local c,b
local function d()
local a=GetTime()
if c~=a then c,b=a,nil end
end
function a.repixeled()c=nil end
function a.truePixel()
d()
if b then return b end
b=1
if PixelUtil and PixelUtil.GetPixelToUIUnitFactor then
b=PixelUtil.GetPixelToUIUnitFactor()/UIParent:GetEffectiveScale()
end
return b
end


function a.round(b,a)return math.floor(b/a+0.5)*a end


local b
function a.emptyDuration()
if not b then b=C_DurationUtil.CreateDuration()end
return b
end




function a.lineWidth(c,b)
b=b or 1
local d=a.truePixel()
local a=math.floor(c*b+0.5)
if c>0 and a<1 then a=1 end
return a*d/b
end



function a.pixel(a)
if PixelUtil and PixelUtil.GetNearestPixelSize then
return PixelUtil.GetNearestPixelSize(1,a:GetEffectiveScale(),1)
end
return 1
end
