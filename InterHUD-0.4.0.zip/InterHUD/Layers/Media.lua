


local a,c=...
local j=c.Schema

local a={}
c.Media=a

local d="Interface\\Buttons\\WHITE8x8"
a.WHITE=d


local i={
{"game",nil,"Game font"},
{"Friz Quadrata TT","Fonts\\FRIZQT__.TTF"},
{"Arial Narrow","Fonts\\ARIALN.TTF"},
{"Morpheus","Fonts\\MORPHEUS.TTF"},
{"Skurri","Fonts\\SKURRI.TTF"},
}
local k={
{"Flat",d},
{"Blizzard","Interface\\TargetingFrame\\UI-TargetingFrame-BarFill"},
{"Blizzard Raid Bar","Interface\\RaidFrame\\Raid-Bar-Hp-Fill"},
{"Blizzard Character Skills Bar","Interface\\PaperDollInfoFrame\\UI-Character-Skills-Bar"},
{"Blizzard Cooldown Bar","UI-HUD-CoolDownManager-Bar",atlas=true},
}
local e,f={},{}
local function b(d,a,e)
local b,c={},{}
for d,a in ipairs(a)do
b[#b+1]=a[1]
c[a[1]]=a[3]
e[a[1]]=a
end
j.choiceSet(d,b,a[1][1],c)
end
b("media:font",i,e)
b("media:bar",k,f)


local b=_G.LibStub and _G.LibStub("LibSharedMedia-3.0",true)
local l={font="media:font",statusbar="media:bar"}



local m={statusbar={["Texture Not Found"]=true}}
local function g(a)return type(a)=="string"and a:lower():gsub("/","\\")or nil end
local h={font={},statusbar={}}
for b,a in ipairs(i)do if a[2]then h.font[g(a[2])]=true end end
for b,a in ipairs(k)do if not a.atlas then h.statusbar[g(a[2])]=true end end
local function i(a)
local d,h,i={},h[a],m[a]or{}
for j,c in ipairs(b:List(a))do
local e=(a=="font"and e[c])or(a=="statusbar"and f[c])
local a=not e and g(b:Fetch(a,c,true))
if not i[c]and not(a and h[a])then d[#d+1]=c end
end
j.choiceSet(l[a],d)
end
if b then
i("font")
i("statusbar")
b.RegisterCallback(a,"LibSharedMedia_Registered",function(b,a)
if l[a]then i(a)end
end)
end


function a.font(a)
local c=e[a]
if c and c[2]then return c[2]end
local a=b and a and a~="game"and b:Fetch("font",a,true)
return a or STANDARD_TEXT_FONT
end


function a.bar(e)
local a=f[e]
if a and a.atlas then
if c.Art.hasAtlas(a[2])then return a[2],true end
return d,false
end
if a then return a[2],false end
local a=b and e and b:Fetch("statusbar",e,true)
return a or d,false
end

local f={none="",outline="OUTLINE",thick="THICKOUTLINE"}


function a.setFont(b,d,e)

local f=f[d.outline]or""
local a,c=c.try("font",b.SetFont,b,a.font(d.face),e,f)
if not a or c==false then b:SetFont(STANDARD_TEXT_FONT,e,f)end
if d.shadow then
b:SetShadowColor(0,0,0,1)
b:SetShadowOffset(1,-1)
else
b:SetShadowOffset(0,0)
end
end


function a.exact(a)
a:SetSnapToPixelGrid(false)
a:SetTexelSnappingBias(0)
end




c.Debug.experimental("a bar's fill unsnapped from the pixel grid, as Blizzard's own bars' (the stepping and the"
.." uneven border by eye: unseen in game)","C")
function a.exactFill(b)
local b=b:GetStatusBarTexture()
if b then a.exact(b)end
end


function a.setBar(b,c)

b:SetStatusBarTexture((a.bar(c.texture)))
a.exactFill(b)
end


function a.rgba(a)
local b,c,d=tonumber(a:sub(2,3),16),tonumber(a:sub(4,5),16),tonumber(a:sub(6,7),16)
local a=#a==9 and tonumber(a:sub(8,9),16)or 255
return b/255,c/255,d/255,a/255
end


function a.greyRGB(a,b,c,d)
local a=0.3*a+0.59*b+0.11*c
return a,a,a,d
end
function a.greyOf(b)
local a,c,d,b=a.greyRGB(a.rgba(b or"#ffffff"))
a=math.floor(a*255+0.5)
return string.format("#%02x%02x%02x%02x",a,a,a,math.floor((b or 1)*255+0.5))
end





local function e(b)
local a=C_UIFileAsset and C_UIFileAsset.IsKnownFile
if not a then return true end
local a,b=pcall(a,b)
return not a or b==true
end

local f=64
local b,d={},0
function a.knownFile(a)
if b[a]==nil then
if d>=f then b,d={},0 end
b[a],d=e(a),d+1
end
return b[a]
end

function a.drawable(b)
return a.knownFile(b)and b or c.Sources.UNSET_ICON
end
