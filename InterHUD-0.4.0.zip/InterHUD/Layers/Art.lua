


local a,d=...

local b={}
d.Art=b

b.MEDIA="Interface\\AddOns\\"..a.."\\Art\\"
b.STRETCHED=Enum.UITextureSliceMode and Enum.UITextureSliceMode.Stretched or 0


function b.hasAtlas(a)
return C_Texture~=nil and C_Texture.GetAtlasInfo~=nil and C_Texture.GetAtlasInfo(a)~=nil
end


function b.anim(b,a,c)
local b=b:CreateAnimation(a)
b:SetOrder(c or 1)
if a=="Scale"or a=="Rotation"then b:SetOrigin("CENTER",0,0)end
return b
end






function b.flipBook(d,c,g,h,e,a,f)
local b=(f or d):CreateAnimationGroup()
if a then b:SetLooping(a)end
local a=b:CreateAnimation("FlipBook")
a:SetFlipBookRows(c)
a:SetFlipBookColumns(g)
a:SetFlipBookFrames(h)
a:SetFlipBookFrameWidth(0)
a:SetFlipBookFrameHeight(0)
a:SetDuration(e)
local c=b:CreateAnimation("Alpha")
c:SetFromAlpha(1)
c:SetToAlpha(1)
c:SetDuration(e)
if f then
a:SetTarget(d)
c:SetTarget(d)
end
d:SetAlpha(0)
b.flip,b.show=a,c
return b
end



local c="UI-HUD-ActionBar-GCD-Flipbook"
b.EDGE_ATLAS,b.EDGE_LENGTH=c,0.75
function b.edgeFlash(d)
if not b.hasAtlas(c)then return nil end
local e={}
for f,g in ipairs({1,1.15})do
local a=d:CreateTexture(nil,"OVERLAY",nil,2)
a:SetAtlas(c)
a:SetDesaturated(true)
a:SetBlendMode("ADD")
a:SetPoint("CENTER",d,"CENTER",0,1)

a:SetSize(1,1)
e[f]={tex=a,group=b.flipBook(a,11,2,22,b.EDGE_LENGTH),grow=g}
end
return e
end


function b.styleEdge(a,d,e,f,g,c)
for h,a in ipairs(a)do
local d=d*a.grow
a.tex:SetSize(d,d)
a.tex:SetVertexColor(e*0.6+0.4,f*0.6+0.4,g*0.6+0.4)
a.group.flip:SetDuration(b.EDGE_LENGTH*c)
a.group.show:SetDuration(b.EDGE_LENGTH*c)
end
end



function b.plainFlash(a)
local a=a:CreateTexture(nil,"OVERLAY")
a:SetAllPoints()
a:SetTexture(d.Media.WHITE)
a:SetBlendMode("ADD")
a:SetAlpha(0)
local c=a:CreateAnimationGroup()
c:SetToFinalAlpha(true)
local d,b=b.anim(c,"Alpha",1),b.anim(c,"Alpha",2)
d:SetFromAlpha(0)
b:SetToAlpha(0)
b:SetSmoothing("OUT")
return{tex=a,group=c,fadeIn=d,fadeOut=b}
end


function b.stylePlain(a,d,e,f,c,b)
a.tex:SetVertexColor(d,e,f)
a.fadeIn:SetToAlpha(c)
a.fadeIn:SetDuration(0.06*b)
a.fadeOut:SetFromAlpha(c)
a.fadeOut:SetDuration(0.3*b)
return 0.36*b
end








local a,c="side","top"
b.ALERTS={
{"genericArc1",450917,"Generic arc 1","generic",a},{"genericArc2",450918,"Generic arc 2","generic",a},
{"genericArc3",450919,"Generic arc 3","generic",a},{"genericArc4",450920,"Generic arc 4","generic",a},
{"genericArc5",450921,"Generic arc 5","generic",a},{"genericArc6",450922,"Generic arc 6","generic",a},
{"genericTop1",450923,"Generic top 1","generic",c},{"genericTop2",450924,"Generic top 2","generic",c},
{"bloodSurge",449487,"Blood Surge","warrior",a},{"suddenDeath",449493,"Sudden Death","warrior",a},
{"swordAndBoard",449494,"Sword and Board","warrior",a},{"ragingBlow",962497,"Raging Blow","warrior",a},
{"ultimatum",627610,"Ultimatum","warrior",c},
{"artOfWar",450913,"Art of War","paladin",a},{"daybreak",459313,"Daybreak","paladin",a},
{"grandCrusader",450925,"Grand Crusader","paladin",a},{"handOfLight",459314,"Hand of Light","paladin",c},
{"denounce",511469,"Denounce","paladin",c},
{"thrillOfTheHunt1",1029138,"Thrill of the Hunt 1","hunter",a},
{"thrillOfTheHunt2",1029139,"Thrill of the Hunt 2","hunter",a},
{"thrillOfTheHunt3",1029140,"Thrill of the Hunt 3","hunter",a},
{"lockAndLoad",450926,"Lock and Load","hunter",c},{"masterMarksman",450928,"Master Marksman","hunter",c},
{"focusFire",450916,"Focus Fire","hunter",c},
{"banditsGuile",1030393,"Bandit's Guile","rogue",a},{"sliceAndDice",450931,"Slice and Dice","rogue",c},
{"surgeOfLight",450933,"Surge of Light","priest",a},
{"surgeOfDarkness",592058,"Surge of Darkness","priest",a},
{"shadowWordInsanity",656728,"Shadow Word: Insanity","priest",a},
{"serendipity",469752,"Serendipity","priest",c},{"shadowOfDeath",627609,"Shadow of Death","priest",c},
{"echoOfTheElements",1057288,"Echo of the Elements","shaman",a},
{"maelstromWeapon",450927,"Maelstrom Weapon","shaman",c},
{"maelstromWeapon1",1028136,"Maelstrom Weapon 1","shaman",c},
{"maelstromWeapon2",1028137,"Maelstrom Weapon 2","shaman",c},
{"maelstromWeapon3",1028138,"Maelstrom Weapon 3","shaman",c},
{"maelstromWeapon4",1028139,"Maelstrom Weapon 4","shaman",c},
{"fulmination",467696,"Fulmination","shaman",c},{"highTide",2851788,"High Tide","shaman",c},
{"arcaneMissiles",449486,"Arcane Missiles","mage",a},
{"arcaneMissiles1",1027131,"Arcane Missiles 1","mage",a},
{"arcaneMissiles2",1027132,"Arcane Missiles 2","mage",a},
{"arcaneMissiles3",1027133,"Arcane Missiles 3","mage",a},
{"hotStreak",449490,"Hot Streak","mage",a},{"brainFreeze",449488,"Brain Freeze","mage",a},
{"frozenFingers",449489,"Frozen Fingers","mage",c},{"impact",457658,"Impact","mage",c},
{"nightfall",449492,"Nightfall","warlock",a},{"moltenCore",458741,"Molten Core","warlock",a},
{"moltenCoreGreen",801268,"Molten Core, green","warlock",a},
{"impEmpowerment",449491,"Imp Empowerment","warlock",a},
{"impEmpowermentGreen",801267,"Imp Empowerment, green","warlock",a},
{"demonicCoreVertical",2888300,"Demonic Core, side","warlock",a},
{"backlash",460830,"Backlash","warlock",c},{"backlashGreen",801266,"Backlash, green","warlock",c},
{"demonicCore",2851787,"Demonic Core","warlock",c},
{"omenOfClarity",510823,"Omen of Clarity","druid",a},{"eclipseMoon",450914,"Eclipse, moon","druid",a},
{"eclipseSun",450915,"Eclipse, sun","druid",a},{"naturesGrace",450929,"Nature's Grace","druid",a},
{"toothAndClaw",774420,"Tooth and Claw","druid",a},
{"furyOfStormrage",460831,"Fury of Stormrage","druid",c},
{"shootingStars",463452,"Shooting Stars","druid",c},
{"berserk",510822,"Berserk","druid",c},{"predatorySwiftness",898423,"Predatory Swiftness","druid",c},
{"predatorySwiftnessGreen",1518303,"Predatory Swiftness, green","druid",c},
{"killingMachine",458740,"Killing Machine","deathKnight",a},
{"suddenDoom",450932,"Sudden Doom","deathKnight",a},{"bloodBoil",511104,"Blood Boil","deathKnight",a},
{"darkTransformation",461878,"Dark Transformation","deathKnight",c},
{"rime",450930,"Rime","deathKnight",c},{"necropolis",511105,"Necropolis","deathKnight",c},
{"monkOx",623950,"Ox","monk",a},
{"monkOx2",1028091,"Ox 2","monk",a},{"monkOx3",1028092,"Ox 3","monk",a},
{"monkSerpent",623951,"Serpent","monk",a},{"monkTiger",623952,"Tiger","monk",a},
{"darkTiger",603338,"Dark tiger","monk",a},{"whiteTiger",603339,"White tiger","monk",a},
{"blackoutKick",1001511,"Blackout Kick","monk",a},{"tigerPalm",1001512,"Tiger Palm","monk",a},
}
b.FAMILIES={"generic","warrior","paladin","hunter","rogue","priest","shaman","mage","warlock","druid",
"deathKnight","monk"}
b.FAMILY_LABELS={generic="Generic",warrior="Warrior",paladin="Paladin",hunter="Hunter",rogue="Rogue",
priest="Priest",shaman="Shaman",mage="Mage",warlock="Warlock",druid="Druid",
deathKnight="Death knight",monk="Monk"}
b.ALERT_KEYS,b.ALERT_LABELS={},{}
local c={}
for d,a in ipairs(b.ALERTS)do
local a={key=a[1],id=a[2],name=a[3],family=a[4],shape=a[5],n=d}
b.ALERTS[d]=a
c[a.key]=a
b.ALERT_KEYS[d],b.ALERT_LABELS[a.key]=a.key,a.name
end

function b.alert(a)return c[a]end


local a
local function e()
if a then return a end
a={}
local c=C_UIFileAsset and C_UIFileAsset.IsKnownFile
for d,b in ipairs(b.ALERTS)do
local d,e=true,true
if c then d,e=pcall(c,b.id)end
a[b.key]=d and e==true
end
return a
end
function b.alertPresent(a)return e()[a]==true end




function b.alertDrawn(a)
local d=e()
local a=c[a]or c.genericArc1
if d[a.key]then return a,false end
local a={
function(b)return b.family==a.family and b.shape==a.shape end,
function(b)return b.family=="generic"and b.shape==a.shape end,
function(b)return b.shape==a.shape end,
}
for a,c in ipairs(a)do
for b,a in ipairs(b.ALERTS)do
if d[a.key]and c(a)then return a,true end
end
end
return nil,true
end


d.Debug.register("spell alert art",function()
local d,a,c=e(),{},0
for e,b in ipairs(b.ALERTS)do
if d[b.key]then c=c+1 else a[#a+1]=b.key.." "..b.id end
end
if#a==0 then return{}end
return{"spell alert art: "..c.." of "..#b.ALERTS.." on this client",
"  missing: "..table.concat(a,", ")}
end)
