




local a,c=...
local d,b,f,m,j=c.Store,c.Blueprints,c.Spells,c.Window,c.Schema

local a={}
c.NewModel=a

local function g(a)return tostring(a):lower()end


a.WORDS={
title="New",

tabs={element="Elements",alert="Spell Alerts",group="Groups",collection="Collections",scratch="From scratch"},
premadesLead="Pre-mades:",
add="Add to HUD",
onHud="on HUD",
pickOne="Pick something to see it.",

scratchLine="All Elements use one or more Sources. Pick one to start with.",
scratchAlert="Spell Alert sources",
scratchElement="Start from a source type",
holds="What it holds",
members="Its elements",
into="Adds into:",
notInGroup="Not in a group",
newGroup="New group…",
search="Search",
noneForYou="None for you yet.",
nothingFound="Nothing found.",
yourRace="Your race",
anyClass="Any class",
otherRaces="Other races",
openIt="Open it ›",
ownLayout="Standard",
allClasses="All classes",
showDrafts="Show drafts",
waysHint={alert="Spell Alerts are still experimental."},
}

function a.added(a,b)
if b then return"Added "..a.." to "..b.."."end
return"Added "..a.."."
end

function a.leftOutWords(a)return"Left out, another class's: "..table.concat(a,", ").."."end




a.BADGES={{"draft","Draft","DRAFT. May not look or function as intended! Most drafts are AI-generated."
.." These are developer aids not intended for real use."},
{"experimental",c.Sources.EXPERIMENTAL.word,c.Sources.EXPERIMENTAL.tip}}

function a.badgeTip(b,c)
local a=a.BADGES[c]
if a[1]=="experimental"and type(b.experimental)=="table"then
local a=#b.experimental>1
return(a and"EXPERIMENTAL. Uses source types still under construction and/or not yet fully tested: "
or"EXPERIMENTAL. Uses a source type still under construction and/or not yet fully tested: ")
..table.concat(b.experimental,", ").."."
end
return a[3]
end


function a.playerClass()
local b,a=UnitClass("player")
return a
end



function a.className(a)

local b=C_CreatureInfo and C_CreatureInfo.GetClassInfo
for c=1,b and 13 or 0 do
local c,b=pcall(b,c)
if c and type(b)=="table"and b.classFile==a and b.className then return b.className end
end
for b=1,GetNumClasses and GetNumClasses()or 0 do
local b,c=GetClassInfo(b)
if c==a and b then return b end
end
return type(a)=="string"and(a:sub(1,1)..a:sub(2):lower())or a
end


function a.playerRace()
if not UnitRace then return nil end
local a,c,b=UnitRace("player")
return b,a
end


function a.raceName(a)
if not(a and C_CreatureInfo and C_CreatureInfo.GetRaceInfo)then return nil end
local a=C_CreatureInfo.GetRaceInfo(a)
return a and a.raceName or nil
end


local function n(b)
local a,c={},{}
local function d(b)
for d,b in ipairs(f.listOf(b))do
if not c[b]then
c[b]=true
a[#a+1]=b
end
end
end
for b,a in ipairs(b.sources or{})do d(a.spells)end
return a
end



local function h(a)
local b,c,d={},{},nil
for e,a in ipairs(a)do
local a=f.nameOf(a)
if not a then
d=true
elseif not c[a]then
c[a]=true
b[#b+1]=a
end
end
return b,d
end


local function o(a)
local a=a.sources and a.sources[1]
local b=a and c.Sources.get(a.kind)
return b and b.icon and b.icon(a)or nil
end


local function i(b,a)
if a==""then return 1 end
if g(b.label):find(a,1,true)then return 1 end
for c,b in ipairs(b.names)do
if g(b):find(a,1,true)then return 2 end
end
for c,b in ipairs(b.spells)do
if tostring(b):find(a,1,true)then return 2 end
end
end



local e,k={},-1
local function p(c)
local a=b.premadeKeys()
if k~=#a then
wipe(e)
for a,c in ipairs(a)do
local a=b.premade(c).variantOf
if a then
e[a]=e[a]or{}
table.insert(e[a],c)
end
end
k=#a
end
return e[c]
end


local function k(c)
local c=b.premade(c)
local d=c.layout and b.layout(c.layout)
if not c.variantOf then return d and d.label or a.WORDS.ownLayout end
local a=b.premade(c.variantOf).label
local a=c.label:sub(1,#a+2)==a..": "and c.label:sub(#a+3)or nil
if not a or a==""or(d and a==d.word)then return d and d.label or c.label end
return a:sub(1,1):upper()..a:sub(2)
end















local e={}
f.onChange("new page items",function()wipe(e)end)
local function l(c)
local a=e[c]
if a then
if a.unnamed then a.names,a.unnamed=h(a.spells)end
return a
end
local d=b.premade(c)
local f=n(d.record)
local g,h=h(f)
a={key=c,label=d.label,class=d.class,races=d.races,spells=f,
names=g,unnamed=h,sourceIcon=o(d.record),
alert=m.isAlert(d.record)or nil,draft=b.isDraft(c)or nil,experimental=b.experimentalSources(c),
line=d.line,variantOf=d.variantOf}
local b=not d.variantOf and p(c)
if b then
a.layouts={{key=c,label=k(c)}}
for c,b in ipairs(b)do a.layouts[#a.layouts+1]={key=b,label=k(b)}end
end
e[c]=a
return a
end


local function m(a,b)
return b~=false or not a.draft
end







local e={}
local function h(a)return type(a)=="table"and a.premade or a end
local function k(c)
local a=e[c]
if a then return a end
local d=b.premadeGroup(c)
a={key="group/"..c,group=c,label=d.label,class=d.class,line=d.line,members={},
spells={},names={}}
local f={}
for d,c in ipairs(d.members)do
local c=h(c)
a.members[d]=c
if b.isDraft(c)then a.draft=true end
for c,b in ipairs(b.experimentalSources(c)or{})do
if not f[b]then
f[b]=true
a.experimental=a.experimental or{}
a.experimental[#a.experimental+1]=b
end
end
end
e[c]=a
return a
end
a.groupItem=k


local o={}
local function n(d)
local a=o[d]
if a then return a end
local e=c.Collections
local c=e.get(d)
a={key="collection/"..d,collection=d,label=c.label,class=c.class,line=c.line,
counts=e.counts(d),spells={},names={}}
local f={}
for d,c in ipairs(e.members(c))do
if b.isDraft(c.premade)then a.draft=true end
for c,b in ipairs(b.experimentalSources(c.premade)or{})do
if not f[b]then
f[b]=true
a.experimental=a.experimental or{}
a.experimental[#a.experimental+1]=b
end
end
end
o[d]=a
return a
end
a.collectionItem=n

function a.item(a)
local b=a:match("^group/(.+)$")
if b then return k(b)end
local b=a:match("^collection/(.+)$")
if b then return n(b)end
return l(a)
end



function a.groupMembers(d)
local e,a,c=a.playerClass(),{},{}
for f,d in ipairs(k(d).members)do
local b=b.premade(d).class
if b and b~=e then c[#c+1]=d else a[#a+1]=d end
end
return a,c
end


a.TAB_ORDER={"element","alert","group","collection","scratch"}
function a.tabs()
local b={}
for d,c in ipairs(a.TAB_ORDER)do b[d]={key=c,label=a.WORDS.tabs[c]}end
return b
end
local function p(a)
if a=="elements"then return"element"end
if a=="alerts"then return"alert"end
if a==""then return nil end
return a
end
a.tabOf=p

function a.sections(f,j,o,e,d)
f=g(strtrim(f or""))
j=j or a.playerClass()
d=d or{}
e=p(e)
if o==nil then o=a.playerRace()end
local a={class={},race={},general={},otherClasses={},otherRaces={}}

local h={}
local function p(b)
if b.class then return b.class==j and a.class or a.otherClasses end
if b.races then
local c=false
for b,a in ipairs(b.races)do c=c or a==o end
return c and a.race or a.otherRaces
end
return a.general
end
if e==nil or e=="element"or e=="alert"then
for c,a in ipairs(b.premadeKeys())do
local b=b.premade(a)
local a=l(a)
local c=(e=="alert"and not a.alert)or(e=="element"and a.alert)
or(d.class and b.class and b.class~=d.class)
local c=not c and i(a,f)
if c and m(a,d.drafts)then
h[a]=c
local b=p(b)
b[#b+1]=a
end
end
elseif e=="group"then
for c,e in ipairs(b.premadeGroupKeys())do
local c=k(e)
local b=b.premadeGroup(e)
if(not b.class or b.class==j)and not(d.class and b.class and b.class~=d.class)
and i(c,f)and m(c,d.drafts)then
h[c]=i(c,f)
local a=b.class and a.class or a.general
a[#a+1]=c
end
end
elseif e=="collection"then
for c,b in ipairs(c.Collections.keys())do
local b=n(b)
if not(d.class and b.class~=d.class)and i(b,f)
and m(b,d.drafts)then
h[b]=i(b,f)
local a=b.class==j and a.class or a.otherClasses
a[#a+1]=b
end
end
end
local function c(a,b)
if h[a]~=h[b]then return h[a]<h[b]end
if g(a.label)~=g(b.label)then return g(a.label)<g(b.label)end
return a.key<b.key
end
for d,b in ipairs({"class","race","general","otherRaces"})do table.sort(a[b],c)end
table.sort(a.otherClasses,function(a,b)
if a.class~=b.class then return tostring(a.class)<tostring(b.class)end
return c(a,b)
end)
return a
end



function a.classChoices()
local c={{false,a.WORDS.allClasses}}
local d,f,e=a.playerClass(),{},{}
for c,a in ipairs(b.premadeKeys())do
local a=b.premade(a).class
if a and not f[a]then
f[a]=true
if a~=d then e[#e+1]=a end
end
end
table.sort(e,function(b,c)return a.className(b)<a.className(c)end)
if f[d]then c[#c+1]={d,a.className(d)}end
for d,b in ipairs(e)do c[#c+1]={b,a.className(b)}end
return c
end

function a.startClass()
local a=a.playerClass()
for d,c in ipairs(b.premadeKeys())do
if b.premade(c).class==a then return a end
end
return false
end


a.MINE,a.OTHERS={"class","race","general"},{"otherClasses","otherRaces"}
function a.premades(b,c,d,e)
local d=a.sections(b,c,e,d)
local b,c={},{}
for c,a in ipairs(a.MINE)do
for c,a in ipairs(d[a])do b[#b+1]=a end
end
for b,a in ipairs(a.OTHERS)do
for b,a in ipairs(d[a])do c[#c+1]=a end
end
return b,c
end


function a.count(b,c)
local a=0
for d,c in ipairs(c)do a=a+#b[c]end
return a
end




function a.headings()
local c={
{key="class",title=function()return a.className(a.playerClass())end,list="class",openFirst=true},
{key="race",title=function()return select(2,a.playerRace())or a.WORDS.yourRace end,list="race",
openFirst=true},
{key="general",title=function()return a.WORDS.anyClass end,list="general",openFirst=true},
}
local f,d,e=a.playerClass(),{},{}
for c,a in ipairs(b.premadeKeys())do
local a=b.premade(a).class
if a and a~=f and not e[a]then
e[a]=true
d[#d+1]=a
end
end
table.sort(d,function(b,c)return a.className(b)<a.className(c)end)
for d,b in ipairs(d)do
c[#c+1]={key="class:"..b,title=function()return a.className(b)end,list="otherClasses",
class=b,other=true}
end
c[#c+1]={key="otherRaces",title=function()return a.WORDS.otherRaces end,list="otherRaces",
other=true}
return c
end


function a.headingCount(a)return#a end

function a.headingItems(c,a)
if not a.class then return c[a.list]end
local b={}
for d,c in ipairs(c[a.list])do
if c.class==a.class then b[#b+1]=c end
end
return b
end




local e={at=nil,gen=0,elements={},groups={}}
local g=0
c.onChanged(function()g=g+1 end,"new page on-HUD counts")
local function i(a,b)
wipe(b)
for c,a in ipairs(a or{})do
local a=a.origin
if type(a)=="table"and a.kind=="premade"and a.id then b[a.id]=(b[a.id]or 0)+1 end
end
end

function a.onHud(b,c)
local a=GetTime()
if e.at~=a or e.gen~=g then
local b=d.profile()or{}
i(b.elements,e.elements)
i(b.groups,e.groups)
e.at,e.gen=a,g
end
return(c and e.groups or e.elements)[b]or 0
end

local function g(b)
local a=b.spells[1]
return a and(select(2,f.highest(a))or C_Spell.GetSpellTexture(a))or b.sourceIcon
or c.Kit.art("iconUnknown")
end
a.iconOf=g



function a.row(b,d)
if b.group then
return{label=b.label,icon=c.Kit.art("iconGroup"),note="",draft=b.draft,
experimental=b.experimental,group=b.group,onHud=a.onHud(b.group,true)}
end
if b.collection then
return{label=b.label,icon=c.Kit.art("iconCollections"),note="",draft=b.draft,
experimental=b.experimental,collection=b.collection,onHud=0}
end
local c=""
if d and b.races then c=a.raceName(b.races[1])or""end
return{label=b.label,icon=g(b),note=c,draft=b.draft,experimental=b.experimental,
onHud=a.onHud(b.key)}
end






function a.detail(e)
local d={label=e.label,line=e.line,draft=e.draft,experimental=e.experimental}
if e.group then
d.kind="group"
local c=b.premadeGroup(e.group)
local f,e=a.playerClass(),{}
for d,a in ipairs(c.members)do
local c=h(a)
local b=b.premade(c)
e[d]={key=c,label=b.label,icon=g(l(c)),off=type(a)=="table"and a.off or nil,
left=(b.class and b.class~=f)or nil}
end
d.members=e
elseif e.collection then
d.kind="collection"
local c=c.Collections
local c=c.get(e.collection)
d.counts=e.counts
d.groups={}
local function f(c)
local a={}
for d,c in ipairs(c or{})do
local b=b.premade(c.premade)
a[d]=b and b.label or c.premade
end
return a
end
for b,a in ipairs(c.groups or{})do
d.groups[#d.groups+1]={name=a.name or a.id,members=f(a.members)}
end
if c.loose and#c.loose>0 then d.groups[#d.groups+1]={name=a.WORDS.notInGroup,members=f(c.loose)}end
d.specials=e.counts.specials
else
d.kind=e.alert and"alert"or"element"
d.spells=e.names
end
return d
end




function a.previewOf(a)
if a.group or a.collection then return nil end
local e=c.Clean.clean("element",b.makePremade(a.key,a.key),"load")
local d=e and c.Resolve.element(e,d.profile())
if not d then return nil end

local b,a=pcall(c.Preview.showcasePicks,d,b.premade(a.key))
a=b and type(a)=="table"and a or{}

a.allKnown=true
return d,a
end



a.NEW_GROUP="\1new"
function a.intoChoices()
local b={{false,a.WORDS.notInGroup}}
for c,a in ipairs((d.profile()or{}).groups or{})do b[#b+1]={a.id,a.name or a.id}end
b[#b+1]={a.NEW_GROUP,a.WORDS.newGroup}
return b
end


function a.into(a)
return a and d.group(a)and a or nil
end


function a.refusal(a)
if d.full("elements")then return"A profile holds at most "..j.field("profile","elements").maxItems
.." elements: delete one to make another."end
if a and d.full("members",a)then return"This group is full: take an element out first."end
end



function a.ways(a)
if a then
local a={}
for d,b in ipairs(c.AlertWhen.MODES)do
local c=c.AlertWhen.KINDS[b[1]]
a[#a+1]={key=b[1],label=b[2],kind=c.kind,unit=c.unit}
end
return a
end
return c.AddViews.kinds()
end

function a.way(b,c)
for b,a in ipairs(a.ways(b))do
if a.key==c then return a end
end
end






local function g(a)
local b,c=pcall(c.Placement.landing,a)
if b then a.position=c end
end

local function k(a,b)
local b,c=pcall(c.Placement.groupLanding,a,b)
if b then a.position=c end
end



function a.premadePlan(c,f)
local e=b.premade(c)
if not e then return nil,{{kind="refuse",path="",text="No such pre-made: "..tostring(c)}}end
local b=b.makePremade(c,d.freeId(e.record.id))
local a=not e.loose and a.into(f)or nil
if not a then g(b)end
return{call="addElementTo",record=b,group=a}
end

function a.run(b)
if b.call=="addGroup"then return(a.makePremadeGroup(nil,b))end
local a,c=d[b.call](b.record,b.group)
if not a then return nil,c end
return b.record.id
end
function a.makePremade(b,c)
local b,c=a.premadePlan(b,c)
if not b then return nil,c end
return a.run(b)
end


local function e(a)return nil,{{kind="refuse",path="",text=a}}end

local function l(c,e)
local a=d.freeId(c)
local b=2
while e[a]do
local e="-"..b
a=d.freeId(c:sub(1,32-#e)..e)
b=b+1
end
e[a]=true
return a
end






function a.groupPlan(f)
local g=b.premadeGroup(f)
if not g then return e("No such pre-made group: "..tostring(f))end
local h,m=a.groupMembers(f)
if#h==0 then return e("None of its elements are for your class.")end
if d.full("groups")then
return e("A profile holds at most "..j.field("profile","groups").maxItems
.." groups: delete one to make another.")
end
local i=j.field("profile","elements").maxItems
local d=#((d.profile()or{}).elements or{})
if i and d+#h>i then
return e("A profile holds at most "..i.." elements: this group needs room for "..#h..".")
end
local d=j.field("group","members").maxItems
if d and#h>d then return e("A group holds at most "..d.." elements.")end
local e,i={},{}
for b,a in ipairs(g.members)do
if type(a)=="table"and a.off then i[a.premade]=true end
end
local d={}
for a,b in pairs(g)do

if a~="label"and a~="line"and a~="class"and a~="general"and a~="members"then d[a]=c.copy(b)end
end
d.id=l(f,e)
d.name=a.groupName(g.label)
d.origin={kind="premade",id=f,name=g.label}
local a={}
for d,c in ipairs(h)do
local b=b.makePremade(c,l(b.premade(c).record.id,e))
if i[c]then b.enabled=false end
a[d]=b
end
k(d,a)
return{call="addGroup",group=d,records=a,left=m}
end



function a.makePremadeGroup(e,b)
local c
if not b then b,c=a.groupPlan(e)end
if not b then return nil,c end
local a,c=d.addGroup(b.group)
if not a then return nil,c end
for f,e in ipairs(b.records)do
a,c=d.addElementTo(e,b.group.id)
if not a then
d.deleteGroup(b.group.id,true)
return nil,c
end
end
return b.group.id,nil,b.left
end








function a.emptyPlan(b,e,h,i)
local c,b=c.AddViews.sourceRecord(b,e,i)
if not c then return nil,{{kind="refuse",path="",text="That can't be watched."}}end
local d=d.freeId(b and b:lower():gsub("[^%w]+","-")or"element")
local b={id=d,name=b~=f.label(f.firstOf(c.spells))and b or nil,sources={c}}
local a=a.into(h)
if not a then g(b)end
return{call="addElementTo",record=b,group=a}
end
function a.makeEmpty(b,d,e,f)
local b,d=a.emptyPlan(b,d,e,f)
if not b then return nil,d end
local a,b=a.run(b)
if not a then return nil,b end
local b=c.Form.view(a)
local b=b and b.sources[1]
return a,nil,b and("source:"..b.id)or"general"
end




function a.makeAlert(g,e,h)
local b=f.label(e)
local b={id=d.freeId(b and(b:lower():gsub("[^%w]+","-").."-alert")or"alert"),
name=b and(b.." alert")or"New alert"}
local a,b=a.run({call="addElementTo",record=b})
if not a then return nil,b end
local b,c=c.AlertWhen.write(a,g,e,{exact=h})
if not b then
d.removeElement(a)
return nil,c
end
return a,nil,"general"
end



function a.groupName(a)
a=a or"Group"
local c={}
for b,a in ipairs((d.profile()or{}).groups or{})do c[a.name or a.id]=true end
if not c[a]then return a end
local b=2
while c[a.." "..b]do b=b+1 end
return a.." "..b
end



function a.makeGroup(c)
local b=d.freeId("group")
local a={id=b,name=c or a.groupName()}
k(a,{})
local a,c=d.addGroup(a)
if not a then return nil,c end
return b
end



function a.groupRefusal(a)
if a==""then return"A group needs a name."end
local b=a:lower()
for c,a in ipairs((d.profile()or{}).groups or{})do
if(a.name or a.id):lower()==b then return"Another group is named that."end
end
end
a.GROUP_ASK="Name for the new group:"
