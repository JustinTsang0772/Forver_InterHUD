






local a,f=...
local a,e,w,k,O,G=f.Kit,f.NewModel,f.Window,f.Preview,f.Layers,f.Ticker
local P=f.Combat


local p={}
f.New=p
local j=e.WORDS


local function x(a,b)
f.PageElement.select(a,b)
w.select("element",a)
return a
end



function p.askGroup(b,c)
a.askInline(b,e.GROUP_ASK,e.groupName(),function(a)
a=strtrim(a)
local b=e.groupRefusal(a)
if b then return b end
local a,b=e.makeGroup(a)
if not a then return b and b[1]and b[1].text or"The group can't be made."end
if c then c(a)else w.select("group",a)end
end)
end



local u,F=a.PAGE_TITLE_H,a.PAGE_TITLE_GAP
local o,Q,R,y=24,12,2,26
local H,z=110,8
local q,h,r,A,g,i,l,I=232,8,130,4,18,4,4,20
local S=1.5



local n={class=nil}
local E=f.Store
local function B()return E.ui().showDrafts==true end


local function C(a,b)
a.error=b and b[1]and b[1].text or nil
if a.error then a:refresh()end
end



local function d(d,c)
local a={items={},n=0}
function a.reset()a.n=0 end
function a.take(e)
a.n=a.n+1
local b=a.items[a.n]
if not b then
b=d(e)
a.items[a.n]=b
end
if not c then b:Show()end
return b
end
function a.hideRest()
for b=a.n+1,#a.items do
if c then a.items[b]:hide()else a.items[b]:Hide()end
end
end
return a
end



local function T(f,g,e)
local b=CreateFrame("Frame",nil,f.content)
b.ground=a.panel(b,nil,nil,nil,"card")
b.ground:cover(b,1)

local c=CreateFrame("Frame",nil,b)
c:SetPoint("TOPLEFT",h,-h)
c:SetPoint("TOPRIGHT",-h,-h)
c:SetHeight(r)
c.ground=a.panel(c,"shade","panelEdge")
c.ground:cover(c,1)
c.stage=CreateFrame("Frame",nil,c)
c.stage:SetPoint("TOPLEFT")
c.stage:SetSize(1,1)
b.area=c


b.previews=d(function()return k.new(c.stage,true)end,true)
b.hint=a.fontString(c,"label")
a.tint(b.hint,"help")
b.hint:SetPoint("CENTER")
b.hint:SetText(j.pickOne)
b.add=a.button(b,j.add,110,22)
b.add:SetPoint("TOPLEFT",c,"BOTTOMLEFT",0,-A-2)
b.add:SetScript("OnClick",function()e.add()end)

b.use=a.button(b,"Use as a new profile",150,22)
b.use:SetPoint("TOPLEFT",c,"BOTTOMLEFT",0,-A-2)
b.use:SetScript("OnClick",function()e.use()end)
b.addTo=a.button(b,"Add to my profile",150,22)
b.addTo:SetPoint("TOPLEFT",b.use,"BOTTOMLEFT",0,-4)
b.addTo:SetScript("OnClick",function()e.addTo()end)
b.back=a.button(b,"Switch back",110,22)
b.back:SetScript("OnClick",function()e.back()end)
b.name=a.fontString(b,"listTop")
a.tint(b.name,"gold")
b.name:SetJustifyH("LEFT")
b.name:SetWordWrap(true)
b.marks=a.fontString(b,"tag")
a.tint(b.marks,"tagText")
b.marks:SetJustifyH("LEFT")
b.line=a.fontString(b,"label")
a.tint(b.line,"help")
b.line:SetJustifyH("LEFT")
b.line:SetWordWrap(true)
b.spells=a.fontString(b,"small")
a.tint(b.spells,"link")
b.spells:SetJustifyH("LEFT")
b.spells:SetWordWrap(true)
b.note=a.fontString(b,"small")
a.tint(b.note,"help")
b.note:SetJustifyH("LEFT")
b.note:SetWordWrap(true)
b.labels=d(function(b)
local b=a.fontString(b,"small")
a.tint(b,"off")
b:SetJustifyH("LEFT")
return b
end)
b.chips=d(function(b)return a.chip(b)end)


b.members=d(function(b)
local b=CreateFrame("Button",nil,b)
b:SetHeight(I)
b.icon=b:CreateTexture(nil,"ARTWORK")
b.icon:SetSize(16,16)
b.icon:SetPoint("LEFT",2,0)
a.cropIcon(b.icon)
b.text=a.fontString(b,"label")
b.text:SetPoint("LEFT",b.icon,"RIGHT",6,0)
b.text:SetPoint("RIGHT",-2,0)
b.text:SetJustifyH("LEFT")
b.text:SetWordWrap(false)
b:SetScript("OnClick",function(a)if a.click then a.click()end end)
b:SetScript("OnEnter",function(b)if b.click then a.tint(b.text,"goldLight")end end)
b:SetScript("OnLeave",function(b)a.tint(b.text,b.dim and"off"or b.click and"gold"or"help")end)
return b
end)

b.holds=a.textLink(b,"",function()
g.holdsOpen=not g.holdsOpen
f:refresh()
end,true)
b.lines=d(function(b)
local b=a.fontString(b,"small")
a.tint(b,"help")
b:SetJustifyH("LEFT")
b:SetWordWrap(true)
return b
end)
b.h=r+2*h
return b
end



local function U(d,g)
local c=d.stage
local e,i=d:GetWidth()-12,r-12
if e<=0 then e=q-2*h-12 end
local h,b,a=8,0,0
for d,c in ipairs(g)do
b=b+c.b.w+(d>1 and h or 0)
a=math.max(a,c.b.h)
end
if b<=0 or a<=0 then return end
local f=UIParent:GetEffectiveScale()/d:GetEffectiveScale()
local j=math.min(1,e/(b*f),i/(a*f))
local f=f*j
c:SetScale(f)
local e,f=e/f,i/f
c:ClearAllPoints()
c:SetPoint("CENTER",d,"CENTER",0,0)
c:SetSize(e,f)
local d=e/2-b/2
for e,b in ipairs(g)do
local a=f/2-a/2+(a-b.b.h)/2
b.box:ClearAllPoints()
b.box:SetPoint("TOPLEFT",c,"TOPLEFT",d-b.b.x,-(a-b.b.y))
d=d+b.b.w+h
end
end


local function J(f,d,c,b,h)
local a=c
for e,d in ipairs(d)do
local e=d:GetWidth()
if a>c and a+e>h then
a,b=c,b+g+i
end
d:ClearAllPoints()
d:SetPoint("TOPLEFT",f,"TOPLEFT",a,-b)
a=a+e+i
end
return b+g
end

a.registerPage("new",{build=function(c)
if n.class==nil then n.class=e.startClass()end



local d={tab="scratch",query="",intoId=false,picked=nil,picks={},added=nil,holdsOpen=false}
c.newState=d
local function k()return d.tab end

local function s()
if k()=="alert"then return nil end
if d.intoPicked then return d.intoId and e.into(d.intoId)or nil end
return e.into(c.target)
end


local function D()
if k()=="group"or k()=="collection"then return nil end
return e.refusal(s())
end
local function t()return D()==nil end

local b={}
local function i()
b.class,b.drafts=n.class,B()
return b
end


local g={}
local function b(c)
local f,b=GetTime(),i()
local a=g[c]
if not(a and a.query==d.query and a.at==f and a.class==b.class and a.drafts==b.drafts)then
a={query=d.query,at=f,class=b.class,drafts=b.drafts,
value=e.sections(d.query,nil,nil,c,b)}
g[c]=a
end
return a.value
end
local function K()return b(k())end
local function L(a)
local a=b(a)
return e.count(a,e.MINE)+e.count(a,e.OTHERS)
end
local function v()return d.picked and e.item(d.picked)or nil end
local function M(a)
if d.picked==a then return end
d.picked,d.picks,d.event,d.holdsOpen=a,{},nil,false
c:refresh()
end



local b=CreateFrame("Frame",nil,c.area)
b.text=a.fontString(b,"greeting")
b.text:SetPoint("TOPLEFT",16,-14)
b.text:SetShadowOffset(1,-1)
b.text:SetText(j.title)
b.flourish=a.flourish(b)
b.flourish:Hide()
b.tabs={}
for e,f in ipairs(e.tabs())do


local g=f.key=="scratch"
local e=a.tab(b,g and"listTop"or"label")
e.key=f.key
e:SetHeight(o)
e.text:SetText(g and("+ "..f.label)or f.label)

e.n=a.fontString(e,"small")
a.tint(e.n,"dimText")
e.n:SetPoint("LEFT",e.text,"RIGHT",4,0)
e:SetScript("OnClick",function()
if d.tab==f.key then return end
d.tab,d.picked,d.picks,d.event=f.key,nil,{},nil
c:scrollBy(-c.scroll:GetVerticalScroll())
c:refresh()
end)
e.simLabel=f.label
b.tabs[#b.tabs+1]=e
end

b.premadesWord=a.fontString(b,"dim")
b.premadesWord:SetText(j.premadesLead)

b.edge=b:CreateTexture(nil,"ARTWORK")
a.fill(b.edge,"tabOnEdge")
b.edge:SetHeight(1)


local g=a.dropdown(b,"",nil,function()return s()or false end,function(a)
if a==e.NEW_GROUP then
p.askGroup(b.intoRow.dropdown,function(a)
d.intoId,d.intoPicked=a,true
c:refresh()
end)
return true
end
d.intoId,d.intoPicked=a,true
c:refresh()
return true
end,{choices=e.intoChoices,width=150})
g:EnableMouse(false)
g.intoText=a.fontString(g,"label")
g.intoText:SetText(j.into)
b.intoRow=g

local i=a.searchBox(b,function(a)
d.query=a
c:refresh()
end,{hint=j.search})
i:EnableMouse(false)
c.searchBox=i
local m={}
local function N(d,e)
local a=a.dropdown(b,"",nil,function()return n[d]end,function(a)
n[d]=a
c:refresh()
return true
end,{choices=e,width=H})
a:EnableMouse(false)
return a
end
m.class=N("class",e.classChoices)


m.drafts=a.checkbox(b,j.showDrafts,e.BADGES[1][3],B,function(a)
E.editUI(function(b)b.showDrafts=a or nil end)
c:refresh()
end)
m.drafts:EnableMouse(false)
m.drafts.check.simLabel=j.showDrafts
a.setFont(m.drafts.check.Text,"label")
c.filterBar=m

local function E(a,c,d)
a:ClearAllPoints()
a:SetPoint("TOPLEFT",b,"TOPLEFT",0,d)
a:SetSize(c,y)
a.refresh(c)
end
local F=u+o+4+y+F
local function N()
local d=b:GetWidth()or 0
if d<=0 then return end
if c.fixed and c.fixed.height~=F then c:setPinHeight(F)end
b.flourish:ClearAllPoints()
b.flourish:SetPoint("TOPLEFT",0,-u+18)
b.flourish:SetPoint("TOPRIGHT",0,-u+18)
b.flourish.refresh(d)


local f,h=4,-(u+2)
local e=k()
local c={}
for b,a in ipairs(b.tabs)do if a.key=="scratch"then c[#c+1]=a end end
for b,a in ipairs(b.tabs)do if a.key~="scratch"then c[#c+1]=a end end
for d,c in ipairs(c)do
local d=c.key~="scratch"and L(c.key)or nil
c.n:SetText(d and tostring(d)or"")
local d=d and(c.n:GetStringWidth()+4)or 0
c:SetWidth(c.text:GetStringWidth()+d+2*Q)

c.text:ClearAllPoints()
c.text:SetPoint("CENTER",-d/2,1)
a.paintTab(c,c.key==e)
if c.key=="scratch"then
for b=1,3 do a.fill(c.edges[b],"accent")end
a.tint(c.text,c.key==e and"goldLight"or"listTopText")
end
c:ClearAllPoints()
c:SetPoint("TOPLEFT",b,"TOPLEFT",f,h)
f=f+c:GetWidth()+R
if c.key=="scratch"then
b.premadesWord:ClearAllPoints()
b.premadesWord:SetPoint("LEFT",b,"TOPLEFT",f+14,h-o/2)
f=f+14+b.premadesWord:GetStringWidth()+6
end
end
b.edge:ClearAllPoints()
b.edge:SetPoint("TOPLEFT",0,h-o+1)
b.edge:SetPoint("TOPRIGHT",0,h-o+1)

local c=h-o-6
local f=t()and e~="alert"and e~="group"and e~="collection"
g:SetShown(f)
local a=d-4
if f then
E(g,d,c)
g.dropdown:ClearAllPoints()
g.dropdown:SetPoint("TOPRIGHT",b,"TOPRIGHT",-4,c)
g.intoText:ClearAllPoints()
g.intoText:SetPoint("RIGHT",g.dropdown,"LEFT",-6,0)
a=a-150-6-g.intoText:GetStringWidth()-z
end

local f,g=m.drafts,m.class
f:SetShown(e~="scratch")
g:SetShown(e~="scratch")
E(f,d,c)
E(g,d,c)
local h=f.check:GetWidth()+6+f.check.Text:GetStringWidth()

local j=c-(g.dropdown:GetHeight()>0 and g.dropdown:GetHeight()or y)/2
f.check:ClearAllPoints()
f.check:SetPoint("RIGHT",b,"TOPRIGHT",-(d-a)-h+f.check:GetWidth(),j)
a=a-h-z
g.dropdown:ClearAllPoints()
g.dropdown:SetPoint("TOPRIGHT",b,"TOPRIGHT",-(d-a),c)
a=a-H-z
i:ClearAllPoints()
i:SetPoint("TOPLEFT",b,"TOPLEFT",4,c)
i:SetPoint("RIGHT",b,"RIGHT",-(d-a),0)
i:SetShown(e~="scratch")
i.refresh(math.max(a-4,40))


i.box:SetWidth(math.max(a-12,60))
i.box:ClearAllPoints()
i.box:SetPoint("LEFT",i,"TOPLEFT",4,-m.class.dropdown:GetHeight()/2)
end
b:HookScript("OnSizeChanged",N)
c.titleRow=b
c:pin(b,F,N)
c:text(function()return D()or""end,function()return D()~=nil end)
c:callout(function()return c.error or""end,function()return c.error~=nil end)


local g
local b
local i={}

function i.add()
local a=v()
if not a then return end
if a.group then
local d,b,f=e.makePremadeGroup(a.group)
if d then
local b={}
for a,c in ipairs(f)do b[a]=e.item(c).label end
c.error=nil
c.sayAdded(d,a.label,true,#b>0 and e.leftOutWords(b)or nil)
c:refresh()
else
C(c,b)
end
return
end
local b,d=e.makePremade(a.key,s())
if b then
c.error=nil

c.sayAdded(b,a.label,nil,nil,(f.Store.groupOf(b)))
c:refresh()
else
C(c,d)
end
end
function i.use()
local a=v()
if not(a and a.collection)then return end
f.PageCollections.use(a.collection,a.class==e.playerClass())
c:refresh()
end
function i.addTo()
local b=v()
if not(b and b.collection)then return end
a.showPopup("COLLECTION_ADD",f.PageCollections.addWords(b.collection),{run=function()
f.PageCollections.add(b.collection)
c:refresh()
end})
end
function i.back()
local a=f.PageCollections.result
if a and a.back then
f.Store.useProfile(a.back)
f.PageCollections.result={text="Back on \""..a.back.."\"."}
c:refresh()
end
end
b=T(c,d,i)
c.pane=b

local function y(e,b)
d.event={key=b.key,owner=b.owner,word=b.word,t0=GetTime()}
local b=b.play or{}
f.try("new pane event",e.play,e,b.source,b.event,b.at)
G.subscribe(0,"new pane event",function()
if not d.event or GetTime()-d.event.t0>=S then
d.event=nil
G.unsubscribe(0,"new pane event")
a.repaint()
end
end)
c:refresh()
end

local function i()
local k=v()
local o=q-2*h
b.previews.reset();b.labels.reset();b.chips.reset();b.members.reset();b.lines.reset()
local p=P.inCombat()
b.hint:SetShown(k==nil)
b.add:SetShown(k~=nil and not k.collection)
b.use:SetShown(k~=nil and k.collection~=nil)
b.addTo:SetShown(k~=nil and k.collection~=nil)
b.back:Hide()
b.holds:Hide()
b.name:Hide();b.marks:Hide();b.line:Hide();b.spells:Hide();b.note:Hide()
if not k then
b.area:Show()
b.previews.hideRest();b.labels.hideRest();b.chips.hideRest();b.members.hideRest();b.lines.hideRest()
b.h=r+2*h
return
end
local i=e.detail(k)

b.area:SetShown(i.kind~="collection")

local g,v={},nil
local function m(c)
local a,e=e.previewOf(c)
if not a then return nil end
if c==k then v=e end
local b=b.previews.take(b.area)

local e=f.copy(e or{})
if c==k then
for a,b in pairs(d.picks)do e[a]=f.copy(b)end
end
f.try("new pane preview",b.show,b,a,e)
g[#g+1]={box=b.box,b=O.bounds(a)}
return a,b
end
local s,u
if i.kind=="group"then
for b,a in ipairs(i.members)do
if not a.left and not a.off then m(e.item(a.key))end
end
elseif i.kind~="collection"then
s,u=m(k)
end
U(b.area,g)
b.previews.hideRest()
local g=h+r+A+2+22+l
if i.kind=="collection"then
local a=k.class==e.playerClass()
b.use:SetText(a and"Use as a new profile"or"Make as a new profile")
local c=f.PageCollections.buildable(k.collection)
b.use:setEnabled(c and not p)
b.addTo:setEnabled(c and a and not p)
b.use:ClearAllPoints()
b.use:SetPoint("TOPLEFT",h,-h)
g=h+22+4+22+l+2
end

b.add:setEnabled(t()and not(i.kind=="group"and f.Store.full("groups")))

b.name:ClearAllPoints()
b.name:SetPoint("TOPLEFT",h,-g)
b.name:SetWidth(o)
b.name:SetText(i.label)
b.name:Show()
g=g+b.name:GetStringHeight()+l
local m={}
if i.draft then m[#m+1]=e.BADGES[1][2]:upper()end
if i.experimental then m[#m+1]=e.BADGES[2][2]:upper()end
if#m>0 then
b.marks:ClearAllPoints()
b.marks:SetPoint("TOPLEFT",h,-g)
b.marks:SetText(table.concat(m," · "))
b.marks:Show()
g=g+14+l
end
local function m(a,b)
if not b or b==""then return end
a:ClearAllPoints()
a:SetPoint("TOPLEFT",h,-g)
a:SetWidth(o)
a:SetText(b)
a:Show()
g=g+a:GetStringHeight()+l
end
m(b.line,i.line)
if i.kind=="collection"then
m(b.spells,f.PageCollections.countWords(k.collection))
local c=k.class==e.playerClass()
if not f.PageCollections.buildable(k.collection)then m(b.note,"Couldn't be built.")
elseif not c then m(b.note,"Only a "..e.className(k.class).." can add it.")
elseif p then m(b.note,"Collections can't be used in combat.")end

local c=f.PageCollections.result
if c then
m(b.note,c.text)
if c.back then
b.back:ClearAllPoints()
b.back:SetPoint("TOPLEFT",h,-g)
b.back:Show()
g=g+22+l
end
end

b.holds.say((d.holdsOpen and"– "or"+ ")..j.holds)
b.holds:ClearAllPoints()
b.holds:SetPoint("TOPLEFT",h,-g)
b.holds:Show()
g=g+a.LINK_H+2
if d.holdsOpen then
for d,c in ipairs(i.groups)do
local b=b.lines.take(b)
b:ClearAllPoints()
b:SetPoint("TOPLEFT",h+6,-g)
b:SetWidth(o-6)
b:SetText(a.colorCode("goldLight")..c.name.."|r · "..table.concat(c.members,", "))
g=g+b:GetStringHeight()+l
end
end
elseif i.kind=="group"then

local e=b.labels.take(b)
e:ClearAllPoints()
e:SetPoint("TOPLEFT",h,-g)
e:SetText(j.members)
g=g+14
for i,e in ipairs(i.members)do
local b=b.members.take(b)
b:ClearAllPoints()
b:SetPoint("TOPLEFT",h,-g)
b:SetWidth(o)
b.icon:SetTexture(e.icon)
b.icon:SetDesaturated((e.off or e.left)and true or false)
b.text:SetText(e.label..(e.off and(" "..a.colorCode("dimText").."off|r")or"")
..(e.left and(" "..a.colorCode("dimText").."not your class|r")or""))
b.dim=e.off or e.left

b.click=function()
d.tab,d.query="element",""
if c.searchBox then c.searchBox.box:SetText("")end
local a=f.Blueprints.premade(e.key)
if a and a.class then n.class=a.class end
M(e.key)
end
a.tint(b.text,b.dim and"off"or"gold")
g=g+I
end
else
if i.spells and#i.spells>0 and table.concat(i.spells,", ")~=i.label then
m(b.spells,table.concat(i.spells,", "))
end


if s then
local e=f.copy(v or{})
for a,b in pairs(d.picks)do e[a]=f.copy(b)end
local a=f.ElementModel.chipsFor(s,e)
local function i(e,c,f)
if#c==0 then return end
local a=b.labels.take(b)
a:ClearAllPoints()
a:SetPoint("TOPLEFT",h,-g)
a:SetText(e)
g=g+14
local a={}
for e,c in ipairs(c)do
local b=b.chips.take(b)
b:say(c.label,c.picked and not d.event or false,false,function()f(c)end)
a[#a+1]=b
end
g=J(b,a,h,g,q-h)+l
end
local function j(a)
d.picks[a]=d.picks[a]or f.copy(e[a]or{facts={}})
d.picks[a].facts=d.picks[a].facts or{}
return d.picks[a]
end
for a,b in ipairs(a.sources)do
local a={}
for c,b in ipairs(b.states)do a[#a+1]=b end
for c,b in ipairs(b.facts)do a[#a+1]=b end
i(b.label,a,function(a)
local f,e=a.key:match("^(%a+):[^/]+/(.+)$")
local b=j(b.id)
if f=="state"then b.state=e else b.facts[e]=not a.picked or nil end
d.event=nil
c:refresh()
end)
end
i("Game",a.game,function(a)
d.picks.game=d.picks.game or f.copy(e.game or{})
d.picks.game[a.key:match("^game:(.+)$")]=not a.picked or nil
c:refresh()
end)
if#a.events>0 and u then
local c=b.labels.take(b)
c:ClearAllPoints()
c:SetPoint("TOPLEFT",h,-g)
c:SetText("Events")
g=g+14
local c={}
for e,a in ipairs(a.events)do
local b=b.chips.take(b)
local d=d.event and d.event.key==a.key
b:say(a.label,d and true or false,true,function()y(u,a)end)
c[#c+1]=b
end
g=J(b,c,h,g,q-h)+l
end
end
end
b.labels.hideRest();b.chips.hideRest();b.members.hideRest();b.lines.hideRest()
b.h=g+h
end
b.refresh=function()f.try("new pane",i)end
c:side(b,q,function()return b.h end,function()return k()~="scratch"end,{right=true})



g=CreateFrame("Frame",nil,c.scroll)
g:SetPoint("BOTTOMLEFT",c.scroll,"BOTTOMLEFT",8,8)
g:SetPoint("BOTTOMRIGHT",c.scroll,"BOTTOMRIGHT",-8,8)
g:SetHeight(40)
g:SetFrameLevel(a.overPreviews(c.scroll))
g:EnableMouse(true)

local b=g:CreateTexture(nil,"BACKGROUND",nil,-8)
b:SetAllPoints()
a.fill(b,"panelFill",1)
a.panel(g,nil,nil,nil,"card"):cover(g,1)
local b=g:CreateTexture(nil,"BORDER",nil,2)
b:SetAllPoints()
a.fill(b,"accent",0.22)
local b=g:CreateTexture(nil,"ARTWORK")
b:SetWidth(4)
b:SetPoint("TOPLEFT",1,-1)
b:SetPoint("BOTTOMLEFT",1,1)
a.fill(b,"accent")
local b=CreateFrame("Frame",nil,g)
b:SetAllPoints()
g.said=a.fontString(b,"listTop")
a.tint(g.said,"gold")
g.said:SetPoint("LEFT",16,0)
g.open=a.textLink(b,j.openIt,function()
if d.added and d.added.group then w.select("group",d.added.id)
elseif d.added then x(d.added.id,"general")end
end,true)
g.open:SetPoint("LEFT",g.said,"RIGHT",14,0)
local l=b:CreateAnimationGroup()
local h=l:CreateAnimation("Alpha")
h:SetFromAlpha(0.2)
h:SetToAlpha(1)
h:SetDuration(0.35)

local h=g:CreateAnimationGroup()
local i=h:CreateAnimation("Alpha")
i:SetFromAlpha(1)
i:SetToAlpha(0)
i:SetStartDelay(5)
i:SetDuration(0.6)
local function i()
h:Stop()
g:Hide()
d.added=nil
end
h:SetScript("OnFinished",i)
g:SetScript("OnEnter",function()h:Stop()g:SetAlpha(1)end)
g:SetScript("OnLeave",function()if g:IsShown()then h:Play()end end)
local b=CreateFrame("Button",nil,b)
b:SetSize(18,18)
b:SetPoint("RIGHT",-10,0)
b.tex=b:CreateTexture(nil,"OVERLAY")
b.tex:SetAllPoints()
b.tex:SetTexture(a.art("close"))
b.tex:SetVertexColor(a.rgba("gold"))
local m=b:CreateTexture(nil,"HIGHLIGHT")
m:SetAllPoints()
a.fill(m,"lit")
b:SetScript("OnClick",i)
b.simRole,b.simLabel="button","Dismiss"
g.dismiss=b
g:Hide()
c.addedNotice=g


function c.sayAdded(i,b,j,c,a)
d.added={id=i,label=b,group=j}
local a=a and f.Store.group(a)
g.said:SetText(e.added(b,a and(a.name or a.id))..(c and(" "..c)or""))
g:Show()
g:SetAlpha(1)
l:Stop()
h:Stop()
l:Play()
h:Play()
end
c.onShow=function()
c.error,d.added,d.query,d.picked,d.picks,d.event=nil,nil,"",nil,{},nil

f.PageCollections.result=nil
g:Hide()
d.tab,p.start=p.start or"scratch",nil
d.intoId,d.intoPicked=false,false
if c.searchBox then c.searchBox.box:SetText("")end
end




local b=function()return t()and k()~="scratch"end
c:block({key="list",shown=b})
c:anchor("search")

local function b()return n.class~=false and n.class~=e.playerClass()end
local function h()return b()or B()end




local g=e.BADGES
local function i(c,d)
c.badges=c.badges or{}
local b=c.badges[d]
if b then return b end
b=CreateFrame("Button",nil,c)
b:EnableMouse(true)
b:SetScript("OnClick",function()if c.Click then c:Click()end end)
b.text=b:CreateFontString(nil,"OVERLAY",a.font("tag"))
b.text:SetPoint("LEFT")
b.text:SetWordWrap(false)
if g[d][1]=="draft"then a.tint(b.text,"help",0.8)else a.tint(b.text,"tagText")end

function b.say(a)
b.text:SetText(a:upper())
b:SetSize(b.text:GetStringWidth(),14)
end
b:SetScript("OnEnter",function(b)a.note(b,b.tip)end)
b:SetScript("OnLeave",function()a.note()end)
b.simLabel="badge"
c.badges[d]=b
return b
end
local function l(c)
if c.onhud then return c.onhud end
local b=a.fontString(c,"small")
a.tint(b,"off")
b:SetPoint("RIGHT",-6,0)
b:SetWordWrap(false)
c.onhud=b
return b
end
local function m(b)
if b.sel then return b.sel end
b.sel=b:CreateTexture(nil,"BACKGROUND")
b.sel:SetAllPoints()
a.fill(b.sel,"accent",0.16)
b.accent=b:CreateTexture(nil,"ARTWORK")
b.accent:SetWidth(3)
b.accent:SetPoint("TOPLEFT")
b.accent:SetPoint("BOTTOMLEFT")
a.fill(b.accent,"accent")
return b.sel
end
local function n(a)
local b=a.refresh
a.refresh=function(c)
b(c)
for b,a in ipairs(a.rows)do
if a:IsShown()then
local c=a.text


for d,g in ipairs(g)do
local f=a.item[g[1]]~=nil
local b=f and i(a,d)or a.badges and a.badges[d]
if b then
b:SetShown(f)
if f then
b.say(g[2])
b.tip=e.badgeTip(a.item,d)
b:ClearAllPoints()
b:SetPoint("LEFT",c,"RIGHT",c==a.text and 8 or 6,0)
c=b
end
end
end
if c~=a.text then
a.note:ClearAllPoints()
a.note:SetPoint("LEFT",c,"RIGHT",8,0)
end
local b=a.item.onHud or 0
local c=b>0 and l(a)or a.onhud
if c then
c:SetShown(b>0)
if b>0 then
c:SetText(j.onHud..(b>1 and(" · "..b)or""))
a.note:SetPoint("RIGHT",c,"LEFT",-8,0)
end
end
local b=a.item.key==d.picked
local c=b and m(a)or a.sel
if c then
c:SetShown(b)
a.accent:SetShown(b)
end
end
end
end
end
local function m(b,a)
local a=e.row(b,a)


return{a.label,icon=a.icon,note=a.note,noteAfter=true,draft=a.draft,
experimental=a.experimental,
onHud=a.onHud,key=b.key,click=function()M(b.key)end}
end



local function l()return d.query~=""or b()end
local function g(b,c)
if l()then return false end
if c then return a.isFolded("new:fold:"..b)end
return not a.isFolded("new:open:"..b)
end

local function b(d,h,i,f,k)
local function j()return#i()>0 end
local b=a.row(c.content,32)
b.hit=CreateFrame("Button",nil,b)
b.hit:SetAllPoints()
b.mark=a.foldMark(b.hit,9,2)
b.mark:place(9,12)
b.text=a.fontString(b.hit,"subhead")
b.text:SetPoint("BOTTOMLEFT",22,7)
b.note=a.fontString(b.hit,"small")
b.note:SetPoint("BOTTOMLEFT",b.text,"BOTTOMRIGHT",10,1)
a.tint(b.note,"help")
b.rule=b:CreateTexture(nil,"ARTWORK")
a.fill(b.rule,"white")
b.rule:SetGradient("HORIZONTAL",a.colorObj("rule",0.30),a.colorObj("rule",0))
b.rule:SetHeight(1)
b.rule:SetPoint("BOTTOMLEFT",0,3)
b.rule:SetPoint("BOTTOMRIGHT",0,3)
b.hit:SetScript("OnClick",function()
if l()then return end
local b=g(d,f)
if f then a.setFolded("new:fold:"..d,not b)
else a.setFolded("new:open:"..d,b)end
c:refresh()
end)
b.key=d
c:addRow(a.finishRow(b,function()
b.text:SetText(type(h)=="function"and h()or h)
b.note:SetText("("..e.headingCount(i())..")")
b.mark:show(true)
b.mark:set(g(d,f))
end),j)
local a=a.linkList(c.content,function()
local a={}
for c,b in ipairs(i())do a[#a+1]=m(b,k)end
return a
end)
n(a)
c:addRow(a,function()return j()and not g(d,f)end)
end

for f,a in ipairs(e.headings())do
b(a.key,a.title,function()return e.headingItems(K(),a)end,a.openFirst,a.other)
if a.key=="general"then
c:text(j.noneForYou,function()
return d.query==""and not h()and e.count(K(),e.MINE)==0
end)
c:text(j.nothingFound,function()
return(d.query~=""or h())and L(k())==0
end)
end
end


c:endBlock()



c:block({key="scratch",title=j.scratchElement,shown=function()return t()and k()=="scratch"end})
c:hint(j.scratchLine,4)
local function b(b)
return function()
local g={}
for h,d in ipairs(e.ways(b))do


local h=f.Sources
g[#g+1]={d.label,icon=a.art(b and"iconAlerts"or"iconNew"),
tag=b and h.EXPERIMENTAL.word or f.AddViews.kindTag(d),
tagTip=b and h.EXPERIMENTAL.tip or f.AddViews.kindTip(d),
click=function(a)


if not b and not f.AddViews.searchable(d)then
local a,b,d=e.makeEmpty(d,nil,s())
if a then x(a,d)else C(c,b)end
return
end
f.AddViews.pickFor(a,{at="new",kind=d,alert=b,group=s()},
function(a)x(a.opened.id,a.opened.entry)end)
end}
end
return g
end
end
c:linkList(b(false))

c:block({key="scratchAlert",title=j.scratchAlert,shown=function()return t()and k()=="scratch"end})
c:hint(j.waysHint.alert,4)
c:linkList(b(true))
c:endBlock()
end})
