



local a,b=...
local a,c=b.Kit,b.Slash




local f={
{"Made by","Inter"},
{"Origins","Grew out of ShamanForever. Thanks to everyone who played it and sent feedback."},
{"Libraries","LibStub, CallbackHandler, LibSharedMedia, LibDataBroker, LibDBIcon"},
{"Art",{"Blizzard's UI art and icons.",
"Paintings, all public domain:\nAurora Borealis by Frederic Edwin Church\n"
.."Mountain Landscape with Lightning by Francisque Millet\nVesuvius from Portici by Joseph Wright of Derby\nBreaking Wave by Ivan Aivazovsky\n"
.."The Chasm of the Colorado by Thomas Moran",
"Corner ornament from Wikimedia Commons, CC0."}},
}


local e={}
for b,a in ipairs(c.LIST)do
if a.about~=false then e[#e+1]={c.typed(a),a.says}end
end




local d={}
b.PageAbout=d
d.credits=f
d.links={
feedback={
{"CurseForge","https://www.curseforge.com/wow/addons/interhud/","comment on CurseForge"},
{"Discord","https://discord.gg/VaXH8CQZFG","post on Discord"},
},
}

local c=420


function d.link(b)
for c,a in ipairs(d.links.feedback)do
if a[1]==b then return a[2]end
end
return""
end



local f,g=20,8
local function q(e,c,h,d)
local b=a.row(e.content,28)
b.key=CreateFrame(d and"Button"or"Frame",nil,b)
if d then
b.key:SetScript("OnClick",d)
local d=b.key:CreateTexture(nil,"HIGHLIGHT")
d:SetAllPoints()
a.fill(d,"lit")
b.key.simRole,b.key.simLabel="button",c
end
b.key:SetPoint("LEFT",4,0)
b.key:SetHeight(f)
b.key.ground=b.key:CreateTexture(nil,"BACKGROUND")
b.key.ground:SetAllPoints()
a.gradient(b.key.ground,"keyHigh","keyLow")
b.key.edge=a.panel(b.key,"keyHigh","keyEdge","BORDER")
b.key.edge.fill:SetAlpha(0)
b.key.edge:cover(b.key,1)

b.key.foot=b.key:CreateTexture(nil,"ARTWORK")
b.key.foot:SetHeight(2)
b.key.foot:SetPoint("BOTTOMLEFT",1,1)
b.key.foot:SetPoint("BOTTOMRIGHT",-1,1)
a.fill(b.key.foot,"keyEdge")
b.command=a.fontString(b.key,"key")
b.command:SetPoint("CENTER",0,1)
b.command:SetText(c)
b.key:SetWidth(a.textWidth("key",c)+2*g)
b.text=a.fontString(b,"label")
b.text:SetPoint("LEFT",a.metric("form","labelW"),0)
b.text:SetPoint("RIGHT",-4,0)
b.text:SetJustifyH("LEFT")
b.text:SetText(h)
return e:addRow(a.finishRow(b,function()end))
end


local function f(a)
if type(a)=="table"then return table.concat(a,"\n\n")end
return a
end


local function r(d,c,e)
local b=a.row(d.content,26)
b.label=a.label(b,c)
a.tint(b.label,"help")
local c=a.metric("form","labelW")
b.text=a.fontString(b,"label")
b.text:SetPoint("TOPLEFT",c,-6)
b.text:SetJustifyH("LEFT")
b.text:SetJustifyV("TOP")

b.label:ClearAllPoints()
b.label:SetPoint("TOPLEFT",b.text,"TOPLEFT",4-c,0)

b.height=function()return math.max(26,b.text:GetStringHeight()+12)end
return d:addRow(a.finishRow(b,function(a)
b.text:SetWidth(math.max(a-c-8,100))
b.text:SetText(f(e))
end))
end


local function s(d,e,f)
local b=a.row(d.content,28)
b.label=a.label(b,e)
b.box=a.copyBox(b,f,c)
b.box:SetPoint("LEFT",a.metric("form","labelW"),0)
b.box.simLabel=e
return d:addRow(a.finishRow(b,function(d)
b.box:SetWidth(math.max(math.min(c,d-a.metric("form","labelW")-a.EDGE),120))
end))
end


local function t(b)
local a={}
for c,b in ipairs(b)do
if b[2]~=""then a[#a+1]=b end
end
return a
end


local function u(b)
local a={}
for b,c in ipairs(b)do a[b]=c[3]end
if#a<2 then return a[1]or""end
return table.concat(a,", ",1,#a-1).." or "..a[#a]
end





local c=b.Roadmap
local k=b.Window


local f,j,h,i,l=10,12,36,20,24
local m=13
local g=h+6
local n=3
d.state={tab="new"}


function d.openFeedback()
k.select("page","about")
local a=a.window():page()
if a and a.goTo then a:goTo("feedback")end
end


function d.openRoadmap(a)
d.state.tab=a
k.showUnder("roadmap","page:about")
end


local function v(a)
if a>0 then return"… and "..a.." more, see all ›"end
return"See all ›"
end





local o=6
local function p(b,e,j)
local b=CreateFrame("Button",nil,b)
b.ground=a.panel(b,nil,nil,nil,"card")
b.ground:cover(b,1)
local k=b:CreateTexture(nil,"HIGHLIGHT")
k:SetPoint("TOPLEFT",1,-1)
k:SetPoint("BOTTOMRIGHT",-1,1)
a.fill(k,"lit")
b.title=a.fontString(b,"heading")
b.title:SetPoint("BOTTOMLEFT",b,"TOPLEFT",f+4,-(h-7))
b.title:SetText(e.title and e.title()or e.label)
b.tab=e.tab
b.dot=b:CreateTexture(nil,"ARTWORK")
b.dot:SetSize(7,7)
b.dot:SetPoint("LEFT",b.title,"RIGHT",7,0)
a.fill(b.dot,"gold")
b.note=a.fontString(b,"small")
a.tint(b.note,"help")
b.note:SetPoint("BOTTOMRIGHT",b,"TOPRIGHT",-f-4,-(h-8))
b.rule=b:CreateTexture(nil,"ARTWORK")
a.fill(b.rule,"white")
b.rule:SetGradient("HORIZONTAL",a.colorObj("rule",0.45),a.colorObj("rule",0))
b.rule:SetHeight(1)
b.rule:SetPoint("TOPLEFT",f,-(h-3))
b.rule:SetPoint("TOPRIGHT",-f,-(h-3))
if e.summary then
b.summary=a.fontString(b,"small")
a.tint(b.summary,"text")
b.summary:SetJustifyH("LEFT")
b.summary:SetWordWrap(true)
b.summary:SetMaxLines(o)
b.summary:SetPoint("TOPLEFT",f+2,-g-3)
b.summary:SetPoint("RIGHT",b,"RIGHT",-f,0)
end
b.chips,b.words={},{}
for c=1,j do
local d=a.tag(b)
d:EnableMouse(false)
d:SetPoint("TOPLEFT",f+2,-g-2-(c-1)*i)
b.chips[c]=d
local a=a.fontString(b,"small")
a:SetJustifyH("LEFT")
a:SetWordWrap(e.wrap~=nil)
if e.wrap then a:SetMaxLines(e.wrap)end
b.words[c]=a
end
b.go=a.fontString(b,"link")
b.go:SetPoint("BOTTOMRIGHT",-f-2,8)
b:SetScript("OnEnter",function()a.tint(b.title,"goldLight")end)
b:SetScript("OnLeave",function()a.tint(b.title,a.fontColor("heading"))end)
b:SetScript("OnClick",function()d.openRoadmap(e.tab)end)
b.simRole,b.simLabel="button",e.label
b.height=g+j*i+l
function b.paint()
b.dot:SetShown(c.unseen(e.tab))
b.note:SetText(e.note and e.note()or"")
local c=e.lines()
b.go:SetText(v(math.max(#c-j,0)))
local d=0
if b.summary then
local a,c=a.wordLines("small",e.summary()or"",b:GetWidth()-2*f-2,o)
b.summary:SetText(a)
d=i+(c-1)*m+6
end
for h=1,j do
local c=c[h]
local j,h=b.chips[h],b.words[h]
j:SetShown(c~=nil and c[1]~=nil)
h:SetShown(c~=nil)
if c then
if c[1]then j.say(c[1])end
h:ClearAllPoints()
if c[1]then
j:SetPoint("TOPLEFT",f+2,-g-2-d)
h:SetPoint("LEFT",j,"RIGHT",6,0)
else
h:SetPoint("TOPLEFT",f+2,-g-3-d)
end
h:SetPoint("RIGHT",b,"RIGHT",-f,0)
local g,j=c[2],1
if e.wrap and not c[1]then
g,j=a.wordLines("small",c[2],b:GetWidth()-2*f-2,e.wrap)
end
h:SetText(g)
d=d+i+(j-1)*m
end
end
if e.wrap then b.height=g+math.max(d,i)+l end
end
return b
end


local b={}
for c,a in ipairs(c.GROUPS)do b[a.key]=a.label end
local f={
new={tab="new",label="What's new",wrap=2,

title=function()
local a=c.latest()
return a and("What's new in "..a.version)or"What's new"
end,
note=function()
local a=c.latest()
return(a and a.date and a.date~="")and a.date or""
end,
summary=function()
local a=c.latest()
return a and a.summary
end,
lines=function()
local b=c.latest()
local a={}
for c,b in ipairs(b and c.highlights(b)or{})do a[#a+1]={nil,(b[3]==1 and"• "or"")..b[2]}end
return a
end},
coming={tab="coming",label="What's coming",
lines=function()
local a={}
for d,c in ipairs(c.coming)do a[#a+1]={b[c.when],c.title}end
return a
end},
issues={tab="issues",label="Known issues",
note=function()return#c.issues>0 and(#c.issues.." open")or""end,
lines=function()
local a={}
for c,b in ipairs(c.issues)do a[#a+1]={nil,b.title}end
return a
end},
}


local function g(d)
if not c.has("new")then return end
local b=a.row(d.content,1)
b.card=p(b,f.new,n)
b.card:SetPoint("TOPLEFT")

b.height=function()return b.card.height+j end
b.cards={b.card}
return d:addRow(a.finishRow(b,function(a)

b.card:SetWidth(a)
b.card.paint()
b.card:SetHeight(b.card.height)
b.card.ground:cover(b.card,1)
end))
end


local function h(d)
local b=a.row(d.content,1)
b.cards={}
for d,a in ipairs({"coming","issues"})do
if c.has(a)then b.cards[#b.cards+1]=p(b,f[a],n)end
end
if#b.cards==0 then return end
b.height=b.cards[1].height
return d:addRow(a.finishRow(b,function(e)
local c=#b.cards
local d=math.floor((e-(c-1)*j)/c)
for b,a in ipairs(b.cards)do
a:ClearAllPoints()
a:SetPoint("TOPLEFT",(b-1)*(d+j),0)

a:SetSize(b==c and e-(b-1)*(d+j)or d,a.height)
a.ground:cover(a,1)
a.paint()
end
end))
end


local function f(b,c)
local c="about:open:"..c
b.isFolded=function()return not a.isFolded(c)end
b.onFold=function(b)a.setFolded(c,not b)end
end

a.registerPage("about",{build=function(b)
b.noFoldAll=true
b:header({crest="logo",height=120,title="InterHUD",
note=function()return"Version "..a.versionWords()end})
g(b)
h(b)

if c.has("new")or c.has("coming")or c.has("issues")then b:flourish()end

local a=t(d.links.feedback)
if#a>0 then
b:block({key="feedback",title="Feedback"})
b:anchor("feedback")
b:text("Ideas, requests or problems: "..u(a)..".")
for c,a in ipairs(a)do s(b,a[1],a[2])end
end
local a=b:block({key="commands",title="Commands",card=true,
summary=#e.." slash commands"})
f(a,"commands")
for c,a in ipairs(e)do q(b,a[1],a[2],a.open)end
b:endBlock()
local a=b:block({key="credits",title="Credits",card=true,summary="Made by Inter"})
f(a,"credits")
for c,a in ipairs(d.credits)do r(b,a[1],a[2])end
b:endBlock()
end})





local e,j,f=34,12,10
local g={}



local h,m=14,4
local n={"•","–"}
local function o(b,d,e)
b.lines=b.lines or{}
if not b.lines[d]then
local c={text=a.fontString(b,"label"),mark=a.fontString(b,"label")}
c.text:SetJustifyH("LEFT")
c.text:SetJustifyV("TOP")
if e then
a.tint(c.text,e)
a.tint(c.mark,e)
end
b.lines[d]=c
end
return b.lines[d]
end


local function l(b,d,i,c,k,a)
local e=c
for j,e in ipairs(d)do
local a=o(b,j,a)
local f,g=e[1],e[1]*h
a.mark:SetShown(f>0)
a.mark:ClearAllPoints()
if f>0 then
a.mark:SetText(n[f])
a.mark:SetPoint("TOPLEFT",b,"TOPLEFT",i+g-h+2,-c)
end
a.text:Show()
a.text:ClearAllPoints()
a.text:SetPoint("TOPLEFT",b,"TOPLEFT",i+g,-c)
a.text:SetWidth(math.max(k-g,60))
a.text:SetText(e[2])
c=c+a.text:GetStringHeight()+(j<#d and m or 0)
end
for a=#d+1,#(b.lines or{})do
b.lines[a].text:Hide()
b.lines[a].mark:Hide()
end
return c-e
end



local function h(d,c,k)
local b=CreateFrame("Button",nil,d.content)
local h=#(c.words or{})>0
b:SetSize(400,e)

local i=b:CreateTexture(nil,"HIGHLIGHT")
i:SetPoint("TOPLEFT",0,-1)
i:SetPoint("BOTTOMRIGHT",0,2)
a.fill(i,"lit")
b.arrow=a.arrow(b,"right",j,"ARTWORK")
b.arrow:SetPoint("TOPLEFT",f,-(e-j)/2)
b.arrow:SetShown(h)
b:EnableMouse(h)
b.title=a.fontString(b,"label")
b.title:SetPoint("TOPLEFT",f+20,-(e-14)/2)
b.title:SetJustifyH("LEFT")
b.title:SetWordWrap(false)
b.title:SetText(c.title)
b.wordsH=0
b.rule=b:CreateTexture(nil,"ARTWORK")
a.fill(b.rule,"rule",0.25)
b.rule:SetHeight(1)
b.rule:SetPoint("BOTTOMLEFT",0,0)
b.rule:SetPoint("BOTTOMRIGHT",0,0)
b.rule:SetShown(not k)
b:SetScript("OnClick",function()
g[c.key]=not g[c.key]
d:refresh()
end)
b.simLabel=c.title
if h then b.simRole="button"end

b.height=function()
if not g[c.key]or b.wordsH==0 then return e end
return e+b.wordsH+f
end
return d:addRow(a.finishRow(b,function(h)
local d=g[c.key]and true or false
a.setArrow(b.arrow,d and"down"or"right")
b.title:SetPoint("RIGHT",b,"RIGHT",-f,0)
b.wordsH=l(b,d and c.words or{},f+20,e-4,math.max(h-2*f-20,100),
"help")

b:SetHeight(b.height())
end))
end



local function g(c,d)
local b=a.row(c.content,24)
b.lineH=16
b.height=function()return b.lineH+8 end
return c:addRow(a.finishRow(b,function(a)
b.lineH=l(b,{d},16,4,math.max(a-24,100),"help")
end))
end


local e={}
local function f(d,b,h,f)
local f=d:block({key="v-"..b.key,title=b.version,card=true,shown=f,
note=(b.date and b.date~="")and b.date or nil,summary=b.summary})
f.isFolded=function()
if e[b.key]==nil then return h>1 end
return e[b.key]
end
f.onFold=function(a)e[b.key]=a end


if b.summary and b.summary~=""then
local b=a.text(d.content,b.summary,true)
b.text:SetFontObject(a.font("label"))
a.tint(b.text,"text")
d:addRow(b)
end
for c,a in ipairs(c.KINDS)do
local b=b[a.key]or{}
if#b>0 then
d:subhead(a.label)
for b,a in ipairs(b)do g(d,a)end
end
end
end

a.registerPage("roadmap",{build=function(b)
b.noFoldAll=true
local function e(a)return function()return d.state.tab==a end end
b:plainTitle({title="Recent and upcoming changes",icon=a.art("iconAbout")})

if#c.TABS==0 then return end
b:tabs(c.TABS,function()return d.state.tab end,function(a)
d.state.tab=a
c.open(a)
end)
b.onShow=function()

if not c.has(d.state.tab)and c.TABS[1]then d.state.tab=c.TABS[1].key end
c.open(d.state.tab)
end

b.back={text="Back to About",click=function()k.select("page","about")end}

for a,c in ipairs(c.versions)do f(b,c,a,e("new"))end

for a,d in ipairs(c.GROUPS)do
local a={}
for c,b in ipairs(c.coming)do
if b.when==d.key then a[#a+1]=b end
end
if#a>0 then
b:block({key="coming-"..d.key,title=d.label,shown=e("coming")})
for c,d in ipairs(a)do h(b,d,c==#a)end
end
end

if c.has("issues")then
b:block({key="issues",shown=e("issues")})
for a,d in ipairs(c.issues)do h(b,d,a==#c.issues)end
b:endBlock()
end
b:endBlock()
end})
