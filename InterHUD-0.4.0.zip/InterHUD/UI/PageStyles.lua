


local a,d=...
local b,p,c,q,g,a=d.Kit,d.Store,d.Styles,d.Preview,d.StyleArea,d.StyleModel


local i="settings"
local function r()return i=="settings"end
local function j()return i=="styles"end



local o,k,s,t=16,116,100,1.36

local l,u=24,6

local v=22



local e={}
local function h(b)
local a=a.target(b,e[b])
e[b]=a
return a
end

b.confirm("RESET_STYLE","%s","Reset",function(b)a.reset(b.part,b.look)end)



local f,m=0,nil
d.onChanged(function(a)
if a~="profile"and a~="profiles"then return end
f=f+1
local a=m
m=nil
if a and a.dialog:IsShown()and a.dialog.which=="INTERHUD_DELETE_PRESET"and a.dialog.data==a.data then
a.dialog:Hide()
end
end,"page styles popups")

local function w(a)
local b=f
return function(...)
if f==b then return a(...)end
end
end
local function x()
local a=f
return function()return f==a end
end


b.confirm("DELETE_PRESET","%s","Delete",function(b)
if b.asked~=f then return end
if a.deletePreset(b.part,b.id,b.keep)and e[b.part]==b.id then e[b.part]=nil end
end)


local y=b.saidOf



local function n(c,d,h)
local function i(e)
return function()
local f={part=c,id=d,keep=e,asked=f}
local a=b.showPopup("DELETE_PRESET",a.deleteText(c,d,e),f)
m=a and{dialog=a,data=f}or nil
end
end
local f={
rename=function()
b.askInline(h,a.renamePrompt(c,d),a.presetName(c,d),w(function(b)
local a,b=a.renamePreset(c,d,b)
if not a then return y(b)end
end))
end,
duplicate=function()
local f=p.preset(c,d)
g.askPresetName(h,c,f and f.name,function(b)return a.duplicatePreset(c,d,b)end,
function(a)
e[c]=a
b.repaint()
end,x())
end,
}
local e={}
for c,b in ipairs(a.presetMenu(c,d))do
e[c]={text=b.label,click=f[b.key]or i(a.deleteKeeps(b.key))}
end
return e
end



local function m(c,d)
local c=b.row(c.content,l)
c.chips,c.dots={},{}
local f=1
c.height=function()return f*l end
local function i(a)
if not c.chips[a]then c.chips[a]=b.chip(c)end
return c.chips[a]
end

local function j(c,a)
local d=n(d,a,c)
local a={}
for b,c in ipairs(d)do a[b]={value=b,label=c.text}end
if#a>0 then b.openMenu(c,a,function(a)d[a].click()end)end
end
local function k(a)
if not c.dots[a]then
c.dots[a]=b.dots(c,function()return n(d,h(d),c.dots[a])end)
c.dots[a]:SetFrameLevel(c.chips[a]:GetFrameLevel()+2)
end
return c.dots[a]
end
local function m(a)
return function()
e[d]=a
b.repaint()
end
end
local function n(c)
g.askPresetName(c,d,nil,function(b)return a.newPreset(d,b)end,function(a)
e[d]=a
b.repaint()
end)
end
return b.finishRow(c,function(g)
local e={}
for b,a in ipairs(a.chips(d,h(d)))do

local c=a.kind=="new"and function()n(c.chips[b])end or m(a.id)
e[b]={a.label,a.picked,c,a.id}
end
local b,g,h=4,0,(g or c.width)-b.EDGE
f=1
for a,d in ipairs(e)do
local a=i(a)
local e=d[4]~=nil
a:say(d[1],d[2],nil,d[3],e and function()j(a,d[4])end or nil)

if e and d[2]then a:SetWidth(a:GetWidth()+v)end
if b+a:GetWidth()>h and b>4 then b,g,f=4,g+l,f+1 end
a:ClearAllPoints()
a:SetPoint("TOPLEFT",c,"TOPLEFT",b,-(g+2))
b=b+a:GetWidth()+u
end
for a=1,#e do
local d=e[a][4]~=nil and e[a][2]
if d or c.dots[a]then
local b=k(a)
b:SetShown(d)
b:ClearAllPoints()
b:SetPoint("RIGHT",c.chips[a],"RIGHT",-2,0)
end
end
for a=#e+1,#c.chips do
c.chips[a]:Hide()
if c.dots[a]then c.dots[a]:Hide()end
end
end)
end






local function l(j,l,m)
local e=l[1]
local r,f,i=a.sample(m)
if not i then return end
for b,a in ipairs(l)do a.keepRight=k+o end
local c=CreateFrame("Button",nil,e)

local n=i.baseSize or 40
for b,a in ipairs(i.sources or{})do

for b,a in ipairs(a.layers or{})do n=math.max(n,a.width or a.length or 0)end
end
c:SetSize(k,e.height)
c:SetPoint("TOPRIGHT",e,"TOPRIGHT",-o,0)
local d=q.new(c,true)
d.box:SetPoint("CENTER",c,"CENTER",0,0)
local k=math.min(t,(k-10)/n)
d.box:SetScale(k)

local n=f.plays and b.LINK_H+4 or 0
local o=(i.baseSize or 40)*k+8

local function p()
local b=0
for c,a in ipairs(l)do
if a:IsShown()then b=b+(type(a.height)=="function"and a.height()or a.height or 0)end
end
return b
end

local function q()
c:SetHeight(math.max(o,math.min(s,p()-n)))
end

local l=b.row(j.content,1)
l.height=function()return math.max(o+n-p(),0)end
j:addRow(b.finishRow(l,function()end),function()return l.height()>0 and e:IsShown()end)
c.preview=d
if f.plays then

local function a()
local a=type(f.plays)=="table"and f.plays or{source="spell",event=f.plays}
d:play(a.source,a.event)
end
c:SetScript("OnClick",a)
c.play=b.textLink(c,"Play",a,true)

c.play:SetPoint("TOP",c,"CENTER",0,-(i.baseSize or 40)*k/2-4)
end
g.afterRefresh(j,e,function()
q()
local a,b=a.sampleView(m,h(m),r,f,i)
if not a then return end
c.view,c.picks=a,b
d:show(c.view,c.picks)
end)


local a=0
c:SetScript("OnUpdate",function(e,b)
a=a+b
if a<0.25 then return end
a=0
if c.view and d:ranOut()then d:show(c.view,c.picks)end
end)
e.sample=c
return c
end


local function n(d,e)
local c=a.setting(e)
local function f()return a.settingValue(e)end
local function g(b)return a.setSetting(e,b)end
if c.widget=="slider"then
d:addRow(b.fieldRow(d.content,{label=c.label,field=c.field,widget="slider",unit=c.unit},f,
g))
return
end
if c.widget=="toggle"then
d:addRow(b.fieldRow(d.content,{label=c.label,field=c.field,widget="toggle"},f,g))
return
end
d:addRow(b.fieldRow(d.content,{label=c.label,field=c.field,widget="choice"},f,g,
{choices=function()return c.choices end}))
end



local f,k={},{}



function g.show(a,g)
i="styles"
if not d.Window.select("page","styles")then return end
e[a]=g
local b=b.window():page()
if not b then return end
local a=(c.isLook(a)and"look:"or"style:")..a
if f[a]then b:scrollTo(f[a],function()b:flash(k[a])end)end
end


function g.showStyles()
i="styles"
return d.Window.select("page","styles")
end

b.registerPage("styles",{settings=true,build=function(c)
c:plainTitle({title=a.PAGE.title,icon=b.art("iconGlobal"),switch=d.Window.onSwitch,
button={title=a.EXPLORER.title,line=a.EXPLORER.line,click=function()d.Gallery.open()end}})
c.tabButtons=c:tabs(a.TABS,function()return i end,function(a)i=a end)
c.onShow=function()wipe(e)end


for b,a in ipairs(a.SETTINGS)do
c:block({key=a.key,title=a.title,card=true,shown=r})
for b,a in ipairs(a.rows)do
if a.kind=="minimap"then
c:checkbox(a.label,nil,d.Minimap.shown,d.Minimap.setShown)
else
n(c,a.name)
if a.hint then c:hint(a.hint)end

if a.refused then
local a=a.refused
c:hint(function()return a()or""end,nil,function()return a()~=nil end)
end
end
end
end



local function e(e)
local d,i=e.part,e.title
local b=c:block({key=e.key,title=i,card=true,shown=j,
link={text=a.RESET,shown=function()return a.canReset(e,h(d))end,
click=function()b.showPopup("RESET_STYLE",a.resetConfirm(i),{part=d})end}})
if e.help then c:hint(e.help,4)end
f["style:"..d],k["style:"..d]=b.headFrame,c:addRow(m(c,d))
c:anchor("style:"..d)
for b,e in ipairs({"editing","owners","followers","users"})do
local function b()return a.note(d,h(d),e)end
c:hint(function()return b()or""end,4,function()return b()~=nil end)
end
local b=g.add(c,{part=d,path={d},rows=e.rows,
view=function()return a.view(d,h(d))end,
own=function()return nil end,
write=function(b,c)return a.write(d,h(d),b,c)end,
vars=function()return{everywhere=true}end})
local a={}

for c=1,table.maxn(b)do
if b[c]then a[#a+1]=b[c]end
end
if#a>0 then l(c,a,d)end
end
local d
for b,a in ipairs(a.sections())do
if a.part=="pressed"then d=a else e(a)end
end



c:section(a.LOOKS_TITLE,j)
if d then e(d)end
for e,d in ipairs(a.lookSections())do
local e,h=d.part,d.title
local b=c:block({key=d.key,title=h,card=true,shown=j,
link={text=a.RESET,shown=function()return a.canReset(d,nil,true)end,
click=function()b.showPopup("RESET_STYLE",a.resetConfirm(h),{part=e,look=true})end}})
f["look:"..e]=b.headFrame
k["look:"..e]=d.help and c:hint(d.help,4)or b.headFrame
c:anchor("look:"..e)
local b=g.add(c,{part=e,path={e},rows=d.rows,view=a.looks,
own=function()return nil end,
write=function(b,c)return a.writeLook(b,c)end,
vars=function()return{everywhere=true}end})
local a={}

for c=1,table.maxn(b)do
if b[c]then a[#a+1]=b[c]end
end
if#a>0 then l(c,a,e)end
end
c:endBlock()
end})
