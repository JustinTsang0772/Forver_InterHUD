







local a,b=...
local c,d,e,h,i=b.Kit,b.Form,b.Schema,b.Spells,b.Store

local a={}
b.AddViews=a

function a.offers(a)
a=a or""
return a=="add:source"or a:match("^add:layer:")~=nil or a:match("^add:effect:")~=nil
end


a.WORDS={
source="Add source",sourceFull="An element has at most sixteen sources.",
sourceWhat="What this element watches.",
layer="Add layer",layerWhere="Each is placed where most elements want it; adjust it after.",
effect="Add effect",moment="When",
}
local f=a.WORDS


local g={}
local function j(a)
g[a]=g[a]or{}
return g[a]
end
a.draftOf=j

local function g(a,b)return a.selected()==b end
local function k(a,c,d)
return b.PageElement.act(a.page.target,c,d)
end





a.KIND_ORDER={"spell","aura:player","dispel:player","combo","health:player","power:player",
"fiveSecondRule","cast:player","swing","range","weaponEnchant","totem","reagent","breath","threat"}





function a.kinds()
local d,g={},{}
for a,b in ipairs(a.KIND_ORDER)do g[b]=a end
for h,f in ipairs(e.sourceKeys())do
local c=e.source(f)
local e=c.add and b.Sources.get(c.kind)
if c.add and c.add.listed~=false and not(c.add.whenLearned and not e.learned({}))then
d[#d+1]={key=f,kind=c.kind,unit=c.unit,label=c.add.label,note=c.add.note,
anyUnit=c.add.anyUnit or nil,experimental=b.Sources.experimental(c.kind)or nil,
pickLater=(e.target or e.nothingToPick)and not e.unpickedInChoices or nil,
rank=g[f]or(#a.KIND_ORDER+h)}
end
end
table.sort(d,function(a,b)return a.rank<b.rank end)
return d
end


function a.kindTag(a)return a.experimental and b.Sources.EXPERIMENTAL.word or nil end
function a.kindTip(a)return a.experimental and b.Sources.EXPERIMENTAL.tip or nil end



function a.searchable(a)
local a=b.Sources.get(a.kind)
if a.nothingToPick then return false end
return a.addChoices~=nil or a.target==nil or a.target.field=="spells"
end





local l=30
function a.spellsFor(d,c)


local e=b.Sources.get(d.kind)
if e and e.addChoices then return e.addChoices(c,l)end
if not a.searchable(d)then return{}end
local e={}
local a=b.SpellTable
local g=c and c~=""and c:lower()or nil
for a,b in pairs(a and a.families or{})do
local f
if d.kind=="spell"then
f=b.kind=="spell"
else
local a=d.unit=="target"and"target"or"player"
f=b.auras~=nil and b.auras[a]~=nil
end
if f and h.known(a)then
local b=h.label(a)
if not g or b:lower():find(g,1,true)or tostring(a)==c then
local d,c=h.highest(a)
e[#e+1]={id=a,name=b,icon=c}
end
end
end
table.sort(e,function(a,b)return a.name<b.name end)
return e
end



function a.sourceRecord(d,e,i)
local f=b.Sources.get(d.kind)
local c,g
if e==nil then
if not d.pickLater then return nil end
c,g={kind=d.kind},d.label
elseif f and f.addRecord then
c,g=f.addRecord(e)
if not c then return nil end
c=b.copy(c)
else
c={kind=d.kind,spells={e}}
end
if d.unit and d.unit~="player"then c.unit=d.unit end
if d.anyUnit and type(e)=="number"then
local a=a.unitOfPick(d,e)
c.unit=a~="player"and a or nil
end
if i and type(c.spells)=="table"then c.exact={e}end
return c,g or h.label(e)
end


function a.unitOfPick(a,c)
local a=b.Sources.picksOf(a.kind)
if not(a and a.unitFor)then return"player"end
local b=b.GameData.byId(c)
return a.unitFor(b and b.watch and b.watch.auras or{})
end



function a.addSource(b,c,d)
local a=a.sourceRecord(c,d)
if not a then return false end
return k(b,"addSource",{kind=a.kind,source=a})
end


function a.roomForSource(b)
local a=e.field("element","sources")
return#(b.sources or{})<(a and a.maxItems or 16)
end



function a.pickFor(e,a,d)
c.openPicker(e,{
read=function(c)return b.PickerModel.picker(a,c)end,
pick=function(c)
local a=b.PickerModel.pick(a,c)
if a.ok and d then d(a)end
return a.ok,a.line
end,
})
end

local function n(e,h)
local function d()
local b=h.view()
return b~=nil and a.roomForSource(b)
end
e:block({key="add:source",title=f.source,shown=function()
return g(h,"add:source")
end})
e:hint(function()
if not d()then return f.sourceFull end
return f.sourceWhat
end,4)

e:linkList(function()
local f={}
for g,d in ipairs(a.kinds())do

f[#f+1]={d.label,icon=c.art("iconNew"),tag=a.kindTag(d),tagTip=a.kindTip(d),
click=function(c)

if not a.searchable(d)then
a.addSource(h,d,nil)
return
end
a.pickFor(c,{at="addSource",id=e.target,kind=d},function(a)
b.PageElement.answer(e.target,a)
end)
end}
end
return f
end,nil,d)
end




local function h(a)return a~=nil and a.alert==true end



a.LAYERS={
{key="icon",label="Icon",line=function(b,a)
return h(a)and"The spell's icon, at the centre."or"The spell's icon, filling the element."
end,record=function()return{kind="icon"}end},
{key="timeBar",label="Time bar",line="Duration shown as a bar.",
record=function()
return{kind="bar",value="time",thickness=8,position={point="TOP",toPoint="BOTTOM",y=-2}}
end},

{key="amountBar",label="Bar",line="The amount shown as a bar.",
record=function()
return{kind="bar",value="amount",thickness=8,position={point="TOP",toPoint="BOTTOM",y=-2}}
end},


{key="pointsBar",label="Bar",line="Your combo points shown as a bar in segments.",
record=function()
return{kind="bar",value="points",segments=5,thickness=8,
position={point="TOP",toPoint="BOTTOM",y=-2}}
end},
{key="stacksBar",label="Charges or stacks bar",line="A count shown as a bar in segments.",
record=function()
return{kind="bar",value="stacks",segments=3,thickness=8,
position={point="TOP",toPoint="BOTTOM",y=-2}}
end},


{key="strip",label="Strip",line="A solid bar coloured by its state, under the icon.",
record=function()
return{kind="bar",value="full",thickness=4,position={point="TOP",toPoint="BOTTOM",y=-2}}
end},


{key="text",label="Text",line="Customisable words or numbers.",record=function(b,a)

if a=="reagent"then return{kind="text"}end

if a=="fiveSecondRule"or a=="swing"then return{kind="text",content="time"}end
if a=="range"then return{kind="text",content="range"}end

if a=="power"or a=="combo"or a=="health"then
return{kind="text",content="amount"}
end
return{kind="text",content="custom",words="Text"}
end},



{key="spellAlert",label="Spell Alert",line="A large picture round the centre of the screen, as the game shows.",alert=true,
offered=function(a)
return not h(a)and b.Art.alertDrawn("genericArc1")~=nil
end,
record=function(b)
local a={kind="spellAlert"}
for b,c in ipairs(b and b.stateOrder or{})do
if b>1 then
a.looks=a.looks or{}
a.looks[#a.looks+1]={["while"]=c,shown=false}
end
end
return a
end},
}




local function l(a,c)
if i.groupOf(a)then return b.ElementModel.WORDS.alertGroup end
for c,a in ipairs(c.effects or{})do
if a.kind~="sound"then return b.ElementModel.WORDS.alertSounds end
end
end



local function h(g,h)
local c=d.view(g)
local f,j
for b,a in ipairs(c and c.sources or{})do
if a.id==h then f,j=a,b end
end
if not f then return{}end
local e=e.variantOf(f)
local h={}
for k,a in ipairs(a.LAYERS)do
local e=a.record(e,f.kind)
local f=type(a.line)=="function"and a.line(f.kind,c)or a.line
if a.offered==nil or a.offered(c)then
local c=a.alert and l(g,c)
local b=i.wouldEditElement(g,function(c)
local a=c.sources[j]
a.layers=type(a.layers)=="table"and a.layers or{}
local b=b.copy(e)
b.id=d.freeId(c,e.kind)
a.layers[#a.layers+1]=b
end)
if b or c then
h[#h+1]={key=a.key,kind=e.kind,label=a.label,note=f,layer=e,
greyed=c~=nil or nil,reason=c}
end
end
end
return h
end


local function l()return{}end
function a.layerOffers(c,a)
local d=b.ElementModel.kept(c,"layerOffers",l)
if not d then return h(c,a)end
local b=d[a]
if b==nil then
b=h(c,a)
d[a]=b
end
return b
end



local function h(d,a)
local d=CreateFrame("Frame",nil,d)
d:SetSize(34,34)
local function e(b,e,f,g,h,i)
local a=d:CreateTexture(nil,"OVERLAY")
a:SetPoint("TOPLEFT",b,-e)
a:SetSize(f,g)
c.fill(a,h,i)
return a
end
local function f(e,f,b)
local a=d:CreateTexture(nil,"ARTWORK")
a:SetPoint("TOPLEFT",e,-f)
a:SetSize(b,b)
c.cropIcon(a)
a:SetTexture(c.art("iconNew"))
return a
end
if a=="spellAlert"then

local b=b.Art.alertDrawn("genericArc1")
for e,f in ipairs({4,20})do
local a=d:CreateTexture(nil,"ARTWORK")
a:SetPoint("TOPLEFT",f,-1)
a:SetSize(10,32)
if b then
a:SetTexture(b.id)
if e==2 then a:SetTexCoord(1,0,0,1)end
else
c.cropIcon(a)
a:SetTexture(c.art("iconNew"))
end
end
elseif a=="sound"then
local a=d:CreateTexture(nil,"ARTWORK")
a:SetPoint("TOPLEFT",5,-5)
a:SetSize(24,24)
c.setArt(a,"sound")
elseif a=="timeBar"or a=="stacksBar"or a=="strip"or a=="amountBar"or a=="pointsBar"then

e(1,12,32,10,"shade")
if a=="strip"then
e(2,13,30,8,"accent")
elseif a=="timeBar"or a=="amountBar"then
e(2,13,20,8,"accent")
else
e(2,13,9,8,"accent")
e(12,13,9,8,"accent")
end
elseif a=="text"then

local a=c.fontString(d,"heading")
a:SetPoint("CENTER",0,0)
a:SetText("12")
else
local b=f(3,3,28)
if a=="icon"then
d.icon=b
elseif a=="words"then

b:SetAlpha(0.35)
local a=c.fontString(d,"label")
a:SetPoint("TOP",b,"TOP",0,-3)
a:SetText("Go!")
elseif a=="flash"then
e(3,3,28,28,"white",0.45)
end
end
return d
end


local o=44
local function m(a,g,e,b,i)
local d=c.row(a,o)
local a=CreateFrame("Button",nil,d)
a:SetPoint("TOPLEFT",0,-2)
a:SetPoint("BOTTOMRIGHT",0,2)
a:EnableMouse(true)
a.ground=c.panel(a,"shade","panelEdge")
a.ground:cover(a,1)
local f=a:CreateTexture(nil,"HIGHLIGHT")
f:SetAllPoints()
c.fill(f,"lit")
a.picture=h(a,g)
a.picture:SetPoint("LEFT",6,0)
a.text=c.fontString(a,"label")
a.text:SetPoint("TOPLEFT",a.picture,"TOPRIGHT",10,-2)
a.text:SetText(e)
a.line=c.fontString(a,"small")
c.tint(a.line,"help")
a.line:SetPoint("TOPLEFT",a.text,"BOTTOMLEFT",0,-3)
a.line:SetText(type(b)=="function"and b()or b)
a:SetScript("OnClick",function()i()end)
a.simRole,a.simLabel="button",e
d.button,d.label=a,a.text
return c.finishRow(d,function(c)
if type(b)=="function"then a.line:SetText(b())end
d:SetWidth(math.min(c,420))
end)
end

local function o(c,h,d)
local i=d:match("^add:layer:(.+)$")
c:block({key=d,title=f.layer,shown=function()return g(h,d)end})
c:hint(f.layerWhere,4)
for d,e in ipairs(a.LAYERS)do
local function d()
for b,a in ipairs(a.layerOffers(c.target,i))do
if a.key==e.key then return a end
end
end
local a=e.line
if type(a)=="function"then a=function()
local a=d()
return a and a.note or""
end end
local a=m(c.content,e.key,e.label,a,function()
local a=d()
if a and not a.greyed then k(h,"addLayer",{sourceKey="source:"..i,kind=a.kind,layer=a.layer})end
end)
c:addRow(a,function()return d()~=nil end)
b.StyleArea.afterRefresh(c,a,function()
local d=d()
a:SetAlpha(d and d.greyed and 0.45 or 1)

local a=a.button.picture.icon
if a then a:SetTexture(b.Window.iconOf(c.target))end
end)
c:hint(function()
local a=d()
return a and a.reason or""
end,4,function()
local a=d()
return a~=nil and a.reason~=nil
end)
end
end





function a.moments(a,c)
local d=d.view(a)
local g=b.ElementModel
local a={}
if not d then return a end
for f,b in ipairs(d.sources or{})do
if b.id==c then
local f=e.variantOf(b)
for h,e in ipairs(f.eventOrder)do
if not f.offersEvent or f.offersEvent(b,e)then
a[#a+1]={owner=c,word=e,label=g.eventWords(d,c,e)}
end
end
for i,h in ipairs(f.factOrder)do
local f=f.facts[h]
if f.read=="lua"then
local b=e.isListFact(f)and(type(b.facts)=="table"and b.facts[h]or{})or{{id=h}}
for b,e in ipairs(b)do
for f,b in ipairs({"enters","leaves"})do
local c=c.."."..e.id
a[#a+1]={owner=c,word=b,label=g.eventWords(d,c,b)}
end
end
end
end
return a
end
end
for e,b in ipairs({"enters","leaves"})do
a[#a+1]={owner=c,word=b,label=g.eventWords(d,c,b)}
end
return a
end


local function h(f,g,h)
local a={}
for e,c in ipairs(e.variantKeys("effect"))do
local e=b.Layers.effect(c)
local b=i.wouldEditElement(f,function(e)
local a=d.view(f)
local b=b.ElementModel.at(a,"event:"..g.."/"..h)
if not b then return end
local a=d.read(e,b.path)
if type(a)~="table"then
d.setAt(e,b.path,{})
a=d.read(e,b.path)
end
a.effects=type(a.effects)=="table"and a.effects or{}
a.effects[#a.effects+1]={kind=c,id=d.freeId(e,c)}
end)
if b then a[#a+1]={kind=c,label=e and e.label or c}end
end
return a
end

function a.effectKinds(e,c,d)
local b=b.ElementModel.kept(e,"effectKinds",l)
if not b then return h(e,c,d)end
local a=b[c]
if a==nil then
a={}
b[c]=a
end
local b=a[d]
if b==nil then
b=h(e,c,d)
a[d]=b
end
return b
end

local p={pop="The icon grows and settles.",flash="A flash over the icon.",
text="A word or two rises over the icon. You write them next.",
sound="You pick its sound next: none plays by default."}

local q={sound="sound",flash="flash",text="words"}
local function d(d,l,h)
local n=h:match("^add:effect:(.+)$")
local function i()
local a=a.moments(d.target,n)
local b=j(d.target).moment
for c,a in ipairs(a)do
if a.owner.."/"..a.word==b then return a end
end
return a[1]
end
d:block({key=h,title=f.effect,shown=function()return g(l,h)end})
d:dropdown(f.moment,nil,function()
local a=i()
return a and(a.owner.."/"..a.word)
end,function(a)
j(d.target).moment=a
c.repaint()
return true
end,nil,{dense=true,choices=function()
local b={}
for c,a in ipairs(a.moments(d.target,n))do b[#b+1]={a.owner.."/"..a.word,a.label}end
return b
end})
for e,c in ipairs(e.variantKeys("effect"))do
local b=b.Layers.effect(c)
local e=q[c]or"icon"
d:addRow(m(d.content,e,b and b.label or c,p[c]or"",function()
local a=i()
if a then k(l,"addEffect",{owner=a.owner,event=a.word,kind=c})end
end),function()
local b=i()
if not b then return false end
for b,a in ipairs(a.effectKinds(d.target,b.owner,b.word))do
if a.kind==c then return true end
end
return false
end)
end
end



function a.build(a,b,c)
b.page=a
a:lazy(function()return g(b,"add:source")end,function()n(a,b)end)
for e,c in ipairs(c or{})do
if c:match("^add:layer:")then
a:lazy(function()return g(b,c)end,function()o(a,b,c)end)
elseif c:match("^add:effect:")then
a:lazy(function()return g(b,c)end,function()d(a,b,c)end)
end
end
end
