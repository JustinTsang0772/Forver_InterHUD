


local b,a=...
local f,d,g,k=a.Store,a.Debug,a.Events,a.Combat

local h={}
a.Tooltips=h










d.experimental("spell IDs on the game's tooltips: AddTooltipPostCall's insecure post-call adding a line, the ID"
.." read from each type's data (no row; C: EllesmereUI, Auctionator on Forever)","C")


local l,m="Spell ID","Use spell ID"
local n="spell id tooltip"

local b=false
local i=false


local function c(b)
if b==nil or a.isSecret(b)or type(b)~="number"or b<=0 then return nil end
return b
end


local function o(b,d,e,f)
local c=b:IsForbidden()
if a.isSecret(c)or c then return end
local a=e(d)
if a then b:AddDoubleLine(f,tostring(a),1,0.82,0,1,1,1)end
end


local function j(a)return c(a.id)end






d.experimental("the tooltipShowAuraSpellIDs CVar showing aura IDs in combat (no row; C: EllesmereUI sets it, and"
.." its saved record holds a write accepted on the Forever beta)","C")
local d="tooltipShowAuraSpellIDs"

local function p()
return C_CVar~=nil and C_CVar.GetCVar~=nil and C_CVar.SetCVar~=nil and C_CVar.GetCVar(d)~=nil
end



local function e(a)
if not p()then return end
k.whenUnlocked("aura ids cvar",function()C_CVar.SetCVar(d,a)end)
end

local function k(a)
if C_CVar~=nil and C_CVar.GetCVar~=nil and C_CVar.GetCVar(d)=="1"then return nil end
return c(a.id)
end

local function d(b)
local b=b.lines
if b==nil or a.isSecret(b)or type(b)~="table"then return nil end
local b=b[1]
if b==nil or a.isSecret(b)or type(b)~="table"then return nil end
return c(b.tooltipID)
end

local function p(a)
local a=c(a.id)
if not a then return nil end
local b,a=C_Item.GetItemSpell(a)
return c(a)
end


local d={Spell=j,UnitAura=k,PetAction=j,Macro=d,Item=p}
local c={Item=function()return C_Item and C_Item.GetItemSpell end}
local j={Item=m}

local function k(d,e)
return function(f,c)
if not b or c==nil then return end
a.try(n,o,f,c,d,e)
end
end

local function m()
if i then return end
local b=Enum and Enum.TooltipDataType
if not(TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and b)then return end
i=true
for a,d in pairs(d)do
local b=b[a]
if b~=nil and(not c[a]or c[a]())then
TooltipDataProcessor.AddTooltipPostCall(b,k(d,j[a]or l))
end
end
end


local function c()
local a=b
b=f.ready()and f.settings().spellIdTooltips==true

if b and not a then
m()
e("1")
elseif a and not b then
e("0")
end
end

a.onChanged(function(a)
if a=="settings"or a=="profile"then c()end
end,"tooltips")



local function a()
if b then e("1")end
end
g.on("PLAYER_ENTERING_WORLD","tooltips",function()g.atFrameEnd("tooltips cvar",a)end)

function h.on()return b end
