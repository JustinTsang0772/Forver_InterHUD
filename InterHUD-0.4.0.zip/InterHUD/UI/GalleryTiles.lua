













local a,d=...
local e,c,o,x,y,f,g,k,r,s,z=d.Kit,d.Gallery,d.Preview,d.Resolve,
d.Clean,d.Schema,d.Styles,d.Store,d.Form,d.Media,d.Spells

local b={}
d.GalleryTiles=b



local p,q=4,16
local h,n,t=30,8,3

local j=14
local function i(a)
local a=a and a.captionLines
return a and(a*j+2)or h
end
local A="Interface\\FriendsFrame\\InformationIcon"



local l=CreateFrame("Frame")
l:Hide()
local a={}
b.made=0
local m,j,h=nil,0,0
local function B()
if m~=c.paintN then
m,j,h=c.paintN,p,q
end
end



local p=64
local function m(b)return table.remove(a,b)end
local function C(d,e)
local f=d:match("^[^:]*")
local c
for a,b in ipairs(a)do
if b==e then return m(a)end
end
for b,a in ipairs(a)do
if a.shape==d then return m(b)end
if not c and a.shape and a.shape:match("^[^:]*")==f then c=b end
end
if c then return m(c)end
if b.made<p then
if j<=0 then return nil end
j=j-1
b.made=b.made+1
return o.new(l,true)
end
if#a>0 then return m(#a)end
return nil
end
local j
local function p(c)
local b=c.preview
if not b then return end

j(c,false)
c.preview,c.sig,c.last=nil,nil,b
b:hide()
b.box:SetParent(l)
b.box:ClearAllPoints()
a[#a+1]=b
end


local m={}
local function o(a)
m[a]=m[a]or{}
return m[a]
end
function c.onTabHidden(a)
for b,a in ipairs(o("gallery:"..a))do p(a)end
end




local a,l=pcall(function()return l.GetAnimationGroups~=nil end)
local p=a and l
d.Debug.experimental("the Gallery's Pause effects: each tile's animations paused by a walk of its frames "
.."(GetAnimationGroups, AnimationGroup:Pause; untested in game)","D")
local function l(a,b)
for c,a in ipairs({a:GetAnimationGroups()})do b(a)end
for c,a in ipairs({a:GetRegions()})do
if a.GetAnimationGroups then
for c,a in ipairs({a:GetAnimationGroups()})do b(a)end
end
end
for c,a in ipairs({a:GetChildren()})do l(a,b)end
end
function j(a,b)
if not(a.preview and p)then return end
if b and not a.paused then
a.paused={}
l(a.preview.box,function(b)
if b:IsPlaying()then
b:Pause()
a.paused[#a.paused+1]=b
end
end)
elseif not b and a.paused then
for b,a in ipairs(a.paused)do a:Play()end
a.paused=nil
end
end




local function l(a)return a.spec.part or a.section.part end


local function u(a,b)
return f.get(g.recordOf(a)).byName[b]
end
local function v(a)
if a.defaultFrom then return a.defaultFrom()end
return a.default
end


local function p()return 1/c.scale()end



local function q(a)return g.sample(a)end
b.sampleOf=q


function b.layersOf(b)
local a={}
for c,b in ipairs(b and b.sources or{})do
for c,b in ipairs(b.layers or{})do a[#a+1]=b end
end
return a
end


function b.picks(b,c)
local a={game={},held={}}
local b=b and b.sources and b.sources[1]
for e,c in pairs(c or{})do
if e=="first"then
if b then a[b.id or b.kind]={state=c,facts={}}end
elseif e~="facts"then
a[e]=type(c)=="table"and{state=c.state,facts=d.copy(c.facts or{})}or{state=c,facts={}}
end
end
if b and c and c.facts then
local b=b.id or b.kind
a[b]=a[b]or{facts={}}
for c in pairs(c.facts)do a[b].facts[c]=true end
end
return a
end

function b.firstId(a)
local a=a and a.sources and a.sources[1]
return a and(a.id or a.kind)
end




local a
d.onChanged(function()a=nil end,"gallery profile")
function b.profile(c)
local b=k.profile()
if not(c and b)then return b end
if not a then
a={}
for b,c in pairs(b)do a[b]=c end
a.buttonCues=nil
end
return a
end



function b.styleOf(b)
local a={}
for b,c in pairs(b.section.values)do a[b]=c end
for b,c in pairs(b.spec.style or{})do a[b]=c end
return a
end


local function D(c,a,b)
local a=a.under
if not a then return true end
local b=b[a[1]]
if a[1]=="kind"and b==nil then b=f.choiceDefault("style:"..c)end
if a[2]==true then return b==true end
for c,a in ipairs(a[2])do
if a==b then return true end
end
return false
end
local function w(c,a)
local d={kind=a.kind}
for e,b in ipairs((f.frame(g.recordOf(c),a,{})))do
if a[b.name]~=nil and D(c,b,a)then d[b.name]=a[b.name]end
end
return d
end



function b.styleRecord(h)
local e=l(h)
local a,i=q(e)
if not a then return nil end
a.baseSize=c.SIZES[c.sizeOf(h.section.tab)]or 40
if a.sources and a.sources[1]then a.sources[1].spells={c.sampleSpell()}end
local c=b.styleOf(h)
if not g.isLook(e)then
f.eachStyleSlot("element",a,{},function(a,f,b)
if a.style==e then b[a.name]=d.copy(c)end
end)
end
return a,i.picks and d.copy(i.picks)or b.picks(a,{first=i.state}),b.profile(g.isLook(e))
end




local q={0.04,0.045,0.06}
local function D(a,d,e)
local f=c.backdropOf(a.section.tab)
local b
for c,a in ipairs(c.BACKDROPS)do
if a.key==f then b=a end
end
if not(b and b.file)then
a.back:SetTexture(nil)
a.back:SetColorTexture(q[1],q[2],q[3],1)
a.back:SetVertexColor(1,1,1,1)
return
end
a.back:SetTexture(b.file,"REPEAT","REPEAT")
a.back:SetHorizTile(true)
a.back:SetVertTile(true)
a.back:SetTexCoord(0,d/128,0,e/128)
local b=b.shade or 1
a.back:SetVertexColor(b,b,b,1)
end


function b.sampleWords(a)
if a=="number"then return"12"end
if a=="time"then return"1:24"end
return z.nameOf(c.sampleSpell())or"Earth Shock"
end
local function q()return b.sampleWords(c.state.text)end


local z={"outline","shadow","size"}
local function E(a)
local b=b.styleOf(a)

for c,a in ipairs(z)do
if b[a]==nil then b[a]=v(u("font",a))end
end
a.words=a.words or e.fontString(a.stage,"label")
a.words:ClearAllPoints()
a.words:SetPoint("CENTER",a.stage,"CENTER",0,0)
s.setFont(a.words,b,(b.size or 12)*p())
a.words:SetTextColor(s.rgba(b.colour or"#ffffff"))
a.words:SetText(q())
return true
end


local function s(a)
B()
local e=c.stamp..":"..a.section.stamp

if a.section.kind=="font"then
if a.sig==e then return true end
if h<=0 then return false end
h=h-1
E(a)
a.sig=e
return true
end
if a.preview and a.sig==e then return true end
if not a.preview then
local b=C(a.shape,a.last)
if not b then return false end
a.preview=b
b.box:SetParent(a.stage)
b.box:ClearAllPoints()
b.box:SetPoint("CENTER",a.stage,"CENTER",0,0)
end
if h<=0 then return false end
h=h-1
local f=a.preview
j(a,false)
local g,h,k=a.section.record(a)
a.firstId=b.firstId(g)

local i=c.tabSpec(a.section.tab)
if g and i and i.decorate then i.decorate(g,h,a)end
local g=g and y.clean("element",g,"load")
if not(g and k)then
f:hide()
a.sig=e
return true
end

if a.spec.held and a.firstId then
local b=h[a.firstId]or{facts={}}
b.facts=b.facts or{}
b.facts.pressed=true
h[a.firstId]=b
end
f.box:SetScale(p())

h.allKnown=true
d.try("gallery tile "..a.spec.key,f.show,f,x.element(g,k),h)
f.shape,a.sig=a.shape,e
if c.state.paused and b.pauses(a.section.tab)then j(a,true)end
return true
end


function b.pauses(a)
local a=c.tabSpec(a)
for b,a in ipairs(a and a.bar or{})do
if a=="pause"then return true end
end
return false
end


function b.replay(a)
if(c.state.paused and b.pauses(a.section.tab))or not(a.preview and a.spec.plays)then return end

local b=a.spec.plays
if type(b)=="table"then
d.try("gallery replay "..a.spec.key,a.preview.play,a.preview,b.source,b.event)
else
d.try("gallery replay "..a.spec.key,a.preview.play,a.preview,a.firstId or"spell",b)
end
end


function c.replayTab(c,d,e)
local a=0
for f,c in ipairs(o("gallery:"..tostring(c)))do
if c.spec.plays and c.preview then
a=a+1
if a%e==d then b.replay(c)end
end
end
end


function c.onPause(a)
for c,d in pairs(m)do
if b.pauses(c)then
for c,b in ipairs(d)do j(b,a)end
end
end
end






local a,h=0,nil
d.onChanged(function(b)
if b~="profile"and b~="profiles"then return end
a=a+1
local a=h
h=nil
if a and a.dialog:IsShown()and a.dialog.which=="INTERHUD_GALLERY_USE"and a.dialog.data==a.data then
a.dialog:Hide()
end
end,"gallery popups")
e.confirm("GALLERY_USE","%s","Use",function(b)
if b.asked==a then b.run()end
end)

local function j(a)
return a.spec.caption or a.spec.key
end



local function q(a,b)
if a.type=="choice"then return a.labels and a.labels[b]or tostring(b)end
if a.type=="boolean"then return b and"On"or"Off"end
if a.type=="number"then return(a.unit and e.unitFormat(a.unit,a.step)or e.plainFormat(a.step))(b)end
return tostring(b)
end


local function m(b,c,d)
local a={}
for e,b in ipairs((f.frame(g.recordOf(b),c,{})))do
if c[b.name]~=nil and not(d and d[b.name]~=nil)and b.name~="kind"then
a[#a+1]=b.label.." "..q(b,c[b.name])
end
end
if#a==0 then return""end
if#a==1 then return", with "..a[1]end
return", with "..table.concat(a,", ",1,#a-1).." and "..a[#a]
end



local function q(c)
local a,d=l(c),c.spec
local e=g.spec(a).label:lower()
if d.use=="look"then
return string.format("Use the default %s style as Global's? Every element changes with it.",e),
function()r.resetFactLook(a)end
end
local b=w(a,b.styleOf(c))
return string.format("Use %s as Global's %s%s? Every element following Global changes with it.",j(c),
e,m(a,b,d.style)),function()r.setStyle({a},b)end
end


local x=e.saidOf


local function r(c)
local d,f=l(c),c.spec
local b=w(d,b.styleOf(c))
local f=j(c)..m(d,b,f.style)
local g,h=g.spec(d).label,a
e.askInline(c,string.format("Name for the new %s preset (%s):",g,f),
k.freePresetName(d,j(c))or"",function(c)
if a~=h then return end
local a,b=k.newPreset(d,c,b)
if not a then return x(b)end
end)
end


function b.menu(c)
local d,b=c.spec,{}
local g=l(c)
if d.use==false or not g then return b end
b[#b+1]={text="Use as Global",click=function()
local b,c=q(c)
local a={run=c,asked=a}
local b=e.showPopup("GALLERY_USE",b,a)
h=b and{dialog=b,data=a}or nil
end}
if d.save~=false and d.use~="look"and#k.presets(g)<f.PRESETS_MAX then
b[#b+1]={text="Save as preset",click=function()r(c)end}
end
return b
end
b.useAsGlobal=q
b.saveAsPreset=r

local function g(c)
local a=b.menu(c)
if#a==0 then return end
local b={}
for a,c in ipairs(a)do b[a]={value=a,label=c.text}end
e.openMenu(c,b,function(b)a[b].click()end)
end



local function j(a,f,d)
local a=CreateFrame("Button",nil,a)
a.section,a.spec=f,d
a.shape=(d.part or f.part or f.key)..":"..tostring(d.style and d.style.kind or d.key)
a:RegisterForClicks("LeftButtonUp","RightButtonUp")
a.ground=e.panel(a,nil,"fieldEdge")
a.ground:cover(a,1)
a.back=a:CreateTexture(nil,"BACKGROUND",nil,1)
a.back:SetPoint("TOPLEFT",1,-1)
local f=i(d)
a.back:SetPoint("BOTTOMRIGHT",-1,f)
a.stage=CreateFrame("Frame",nil,a)

a.stage:SetClipsChildren(true)
a.stage:SetPoint("TOPLEFT",1,-1)
a.stage:SetPoint("BOTTOMRIGHT",-1,f)
a.caption=e.fontString(a,"small")
a.caption:SetPoint("TOPLEFT",a,"BOTTOMLEFT",4,f-2)
a.caption:SetPoint("BOTTOMRIGHT",d.info and-18 or-4,2)
a.caption:SetJustifyV("MIDDLE")
a.caption:SetWordWrap(true)
a.caption:SetMaxLines(d.captionLines or 2)
a.caption:SetText(d.caption or"")
a.simRole,a.simLabel="button",d.caption
if d.info then
a.info=CreateFrame("Frame",nil,a)
a.info:SetSize(14,14)
a.info:SetPoint("BOTTOMRIGHT",-3,2)
a.info:EnableMouse(true)
local b=a.info:CreateTexture(nil,"ARTWORK")
b:SetAllPoints()
b:SetTexture(A)
e.setTip(a.info,d.caption,d.info)
end
if d.mark then

local b=CreateFrame("Frame",nil,a)
b:SetAllPoints(a.stage)
b:SetFrameLevel(e.overPreviews(c.window().frame))
a.mark=e.fontString(b,"dim")
a.mark:SetPoint("TOPLEFT",4,-3)
a.mark:SetText(d.mark)
end
if#b.menu(a)>0 then
a.dots=e.dots(a,function()return b.menu(a)end)
a.dots:SetPoint("TOPRIGHT",-t,-t)
a.dots:SetFrameLevel(e.overPreviews(c.window().frame))
a.dots:SetAlpha(0.6)
end
a:SetScript("OnClick",function(a,c)
if c=="RightButton"then g(a)else b.replay(a)end
end)
a:SetScript("OnEnter",function(a)
if a.dots then a.dots:SetAlpha(1)end
b.replay(a)
end)
a:SetScript("OnLeave",function(a)
if a.dots then a.dots:SetAlpha(0.6)end
end)
return a
end


local function k(a,b)
local d=p()
if a.kind=="bar"then
local a=c.BAR_SIZES[c.sizeOf(a.tab)]or c.BAR_SIZES[2]
return math.ceil(a[1]*d+48),math.ceil(a[2]*d+44)+i(b)
elseif a.kind=="font"then
return 190,58+i(b)
end
local a=(c.SIZES[c.sizeOf(a.tab)]or 40)*d
local c=math.max(math.ceil(a*2.2),104)
return b.wide and(2*c+n)or c,math.max(math.ceil(a*2),80)+i(b)
end



function b.grid(d,f,l,b)
local a=e.row(d.content,1)
local h=1
a.height=function()return h end
a.tiles={}
local g=o(d.key)
for c,b in ipairs(l)do
local b=j(a,f,b)
a.tiles[c]=b
g[#g+1]=b
end
f.grids[#f.grids+1]=a
d:addRow(e.finishRow(a,function(l)
local d,g,e=0,0,0
local j,m=false,c.isShown()
for c,b in ipairs(a.tiles)do
local c,f=k(f,b.spec)
if d>0 and d+c>l then d,g,e=0,g+e+n,0 end
b:ClearAllPoints()
b:SetPoint("TOPLEFT",a,"TOPLEFT",d,-g)
b:SetSize(c,f)

b.caption:SetWidth(c-(b.info and 22 or 8))
D(b,c-2,f-i(b.spec)-2)

if m and not s(b)then j=true end
d,e=d+c+n,math.max(e,f)
end
h=g+e+(b and b.foot or 4)
a:SetHeight(h)

if j then c.repaint()end
end),b and b.shown)
return a
end


local g={}



function b.section(f,d)
local e={key=d.key,part=d.part,kind=d.kind or"icon",tab=d.tab,values={},
stamp=0,grids={}}
e.record=d.record or b.styleRecord
local function a()
e.stamp=e.stamp+1
c.repaint()
end
e.changed=a

function e.set(b,c)
e.values[b]=c
a()
return true
end
local a=f:block({key=d.key,title=d.title,card=true,link=d.controls and{
text="Reset",tip="Back to the starting values.",
shown=function()return next(e.values)~=nil end,
click=function()
wipe(e.values)
a()
end}or nil})
a.isFolded=function()return g[d.key]==true end
a.onFold=function(a)g[d.key]=a or nil end

f:anchor(d.key)
if d.help then f:hint(d.help,4)end
for a,b in ipairs(d.controls or{})do

local a=type(b)=="table"and b or u(d.part,b)
assert(a,"gallery: no setting "..tostring(b).." on "..tostring(d.part))
local b=a.name
local function c()
local b=e.values[b]
if b==nil then return v(a)end
return b
end
local function d(a)return e.set(b,a)end
local b={dense=true}
if a.type=="colour"then
f:color(a.label,nil,c,d,nil,b)
elseif a.type=="number"then
b.min,b.max,b.step,b.unit=a.min,a.max,a.step,a.unit
f:slider(a.label,nil,c,d,nil,b)
elseif a.type=="boolean"then

f:checkbox(a.label,nil,c,d,nil,b)
elseif a.type=="choice"then
b.choices={}
for d,c in ipairs(a.choices)do b.choices[d]={c,a.labels and a.labels[c]or c}end
f:dropdown(a.label,nil,c,d,nil,b)
end
end
c.sections=c.sections or{}
c.sections[#c.sections+1]=e
return e
end


function c.resetTab(b)
for c,a in ipairs(c.sections or{})do
if a.tab==b then
wipe(a.values)
a.stamp=a.stamp+1
end
end
end


function b.kindTiles(b,d,e)
local c={}
local g=f.choiceLabels("style:"..b)
for f,a in ipairs(f.choicesOf("style:"..b)({},{}))do
if not(d and d[a])then
local a={key=b..":"..a,caption=g[a]or a,style={kind=a}}
for b,c in pairs(e or{})do a[b]=c end
c[#c+1]=a
end
end
return c
end
