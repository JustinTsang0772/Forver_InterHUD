



local a,d=...
local t,b,e,n,u,p=d.Kit,d.Form,d.Schema,d.Resolve,d.Check,d.Store

local c={}


local function x()
local a=p.profile()
return a and a.buttonCues
end
d.ElementModel=c




































local a={

quick="Pre-made quick settings",general="General",structure="Sources & Layers",

layersNote="Layers higher in this list are drawn on top of the ones below them, and a look higher under a layer"
.." wins over the looks below it. A layer moves only within its source's block; drag the strip on a block's"
.." left to move the whole source.",
drawnUnder="Drawn under %s, though listed above.",
sources="Sources",customStates="Custom states",usedByNote="used by ",
addSource="Add source",addLayer="Add layer",addEffect="Add effect",addLook="Add look",
lastWhile="A look needs a While: add another, then remove this one.",
addCustomState="Add custom state",newCustomState="New custom state…",customStateName="Custom state %d",layers="Layers",events="Events",

noLayers="No layers.",noLayersWide="No layers. Its states may be used by other layers and custom states.",


buttonCues="Button cues: ",
cueBorrowed="A look here uses it, even switched off.",
while_="While",unless="Unless",addUnless="+ Unless",
thisSource="This source",game="The game",facts="Facts",look="Look: ",
customState="Custom state: ",all="All of these",any="Any of these",none="None of these",
holdFor="Holds for",after="After",usedBy="Used by ",backTo="Back to ",
sets="What it sets",whenItShows="When it shows",otherwise="Otherwise",

shown="Shown",opacity="Opacity",full="Full",
restOfTime="the rest of the time",
cantHoldWith="Can't hold with ",
backLayer="Back to the layer's: ",backGroup="Back to the group's: ",andMore="and %d more",
unlessMoves="With Unless it applies after the button cues, in list order.",
anyLua="Any joins only keys InterHUD reads in combat.",
rangesFull="A buff or debuff can have %d stack ranges for now.",
cellCap="%d different displays, the most a buff or debuff can have for now.",
alertGroup="Spell Alerts sit round the character, never in a group",
alertSounds="Cannot add Spell Alert to this source.",
customStateFirst="Pick a key first: a new custom state starts from the keys picked.",
removeSpell="Remove %s from this source?",lastSpell="Remove %s? It is this source's only spell: without it the source watches nothing.",
ownPicture="The source's own",backOwnPicture="Back to the source's own picture",
autoIcon="Automatic",backAutoIcon="Back to the automatic icon",
noCustomStates="No custom states yet.",
remove="Remove",rename="Rename",duplicate="Duplicate",resetPremade="Reset to pre-made",

eventTakes="This removes its %s.",them="them",

layerType="Layer type",source="Source",sourceType="Source type",

custom="Custom",

thisId="This ID only",matches="Matches %s.",matchesAlone="Matches this ID alone.",
addSpell="+ Add spell",

fromItsSpells="None picked, so it shows once you know one of its own spells: %s.",

looks="Looks",picture="Picture",sizeAndPlace="Size and place",
onThe="On the %s",partPlace="%s place",cuesTitle="Button cues",globalLook="Global's look",ownLook="its own look",
hidden="hidden",shownWord="shown",notWord="not %s",

when="When",changes="What this look currently changes",
changesNothing="This look doesn't change anything yet. Set something below.",
everything="Everything this look can change",
borrowsLook="This look sets nothing itself. It uses %s for this button cue.",showInPreview="Show in preview",
layer="Layer",

reads="What layers can read from this source",on="On",
factOff="%s is switched off for this source, so no layer reacts to it. Tick On to use it again.",
wholeElement="These settings show or hide the whole element. To hide only one layer, add a look to that layer.",
cantWait="In combat, InterHUD can't watch %s, so this state can't use After or play effects.",
rangeName="Range name",itemName="%s name",rangeGoes="This also removes its %s range (%s), as nothing else uses it.",

lookOf="the %s's look %s",partInUse="In use by %s: remove %s anyway?",
lookGoes="Any look that sets nothing else goes with it.",stateNamed="the custom state %s",cuesOf="the %s's button cues",

startsSeconds="%s starts this many seconds before the end.",
startsShare="%s starts when this much of the duration is left.",atOrUnder="%s holds at this many or fewer.",
setOnSource="%s (%s), set on its source",
orFewer="%s or fewer",exactly="exactly %s",alsoUsedBy="This setting is shared. Changing it also changes %s.",newRange="New %s range…",
}
c.WORDS=a
local _={"One","Two","Three","Four","Five","Six","Seven","Eight","Nine","Ten"}

local function j(a)
if a==nil then return{}end
if type(a)=="table"then return a end
return{a}
end
local h=b.extend




local q={}



c.narrowCheck=false
d.onChanged(function(a,b)
if a=="ui"then return end
if a=="element"and b then
q[b]=nil
if c.narrowCheck then
for b,a in pairs(q)do a.survived=true end
end
return
end
wipe(q)
end,"element model")


d.Spells.onChange("element model",function()
for b,a in pairs(q)do wipe(a.memo)end
end)
local function f(a)
local a=p.element(a)
if not a then return nil end
local b=n.element(a,p.profile())
return{rec=a,view=b,index=e.keyIndex(b),memo={}}
end
local function l(b)
local a=q[b]
if not a then
a=f(b)
if a then q[b]=a end
end
return a
end
function c.view(a)local a=a and l(a)return a and a.view end


local function f(a,b)
if a==b then return true end
if type(a)=="function"and type(b)=="function"then return true end
if type(a)~="table"or type(b)~="table"then return false end
for a,c in pairs(a)do
if not f(c,b[a])then return false end
end
for b in pairs(b)do
if a[b]==nil then return false end
end
return true
end



local function g(b,a,d,g,...)
if not rawequal(p.element(b),a.rec)then
c.narrowCheck(b,a.rec,p.element(b))
return
end
local e={rec=a.rec,view=a.view,index=a.index,memo={}}
q[b]=e
local g,e=pcall(g,e,...)
q[b]=a
if g and not f(a.memo[d],e)then c.narrowCheck(b,a.memo[d],e)end
end
local function y(d,b,e,...)
local a=l(d)
if not a then return nil end
if a.memo[b]==nil then
a.memo[b]=e(a,...)
elseif a.survived and c.narrowCheck then
g(d,a,b,e,...)
end
return a.memo[b]
end


function c.kept(a,b,c,...)
local a=l(a)
if not a then return nil end
if a.memo[b]==nil then a.memo[b]=c(a,...)end
return a.memo[b]
end



local K={}

local r,B={},{}

local m,i={},{}
c.NEW_LOOK,c.NEW_STATE="new:look","new:customState"


local D={}
function c.version(a)return D[a]or 0 end

local function E(a,b)
for c,a in ipairs(a.sources or{})do
if a.id==b then return a,c end
end
end
local function g(a,b)
for c,a in ipairs(a and a.layers or{})do
if a.id==b then return a,c end
end
end
local function f(a,b)
for c,a in ipairs(a.customStates or{})do
if a.id==b then return a,c end
end
end



local function L(d,b,a)
local g,c=b:match("^([^%.]+)%.(.+)$")
if g then
local d,g=E(d,g)
local h=d and e.variantOf(d)
if not h then return nil end
local i=e.CHANGE_EVENTS[a]
if not i then return nil end
local j=d.facts or{}
local f=h.facts[c]
if f and not e.isListFact(f)then
return{owner=b,word=a,decl=i,moment="plain",src=d,si=g,fact=c,
path={"sources",g,"facts",c,"events",a},label=f.label}
end
for k,f in ipairs(h.factOrder)do
local h=h.facts[f]
if e.isListFact(h)then
for j,e in ipairs(type(j[f])=="table"and j[f]or{})do
if e.id==c then
return{owner=b,word=a,decl=i,moment="plain",src=d,si=g,fact=f,item=c,
path={"sources",g,"facts",f,j,"events",a},label=e.name or h.label}
end
end
end
end
return nil
end
local c,g=E(d,b)
if c then
local d=e.variantOf(c)
local e=d and d.events[a]
if not e then return nil end
return{owner=b,word=a,decl=e,moment=d.moment or"plain",src=c,si=g,
path={"sources",g,"events",a},label=e.label}
end
local c,d=f(d,b)
local e=c and e.CHANGE_EVENTS[a]
if not e then return nil end
return{owner=b,word=a,decl=e,moment="plain",cond=c,ci=d,
path={"customStates",d,"events",a},label=c.name or c.id}
end
function c.at(b,a)
if type(a)~="string"or not b then return nil end
local a,c=a:match("^(%a+):?(.*)$")
if a=="quick"or a=="general"or a=="structure"or a=="customStates"then
return{kind=a,path={}}
end
if a=="source"then
local b,c=E(b,c)
return b and{kind=a,src=b,si=c,path={"sources",c}}
end
if a=="layer"or a=="look"then
local c,e,f=c:match("^([^/]+)/([^/]+)/?(%d*)$")
local b,d=E(b,c)
local c,e=g(b,e)
if not c then return nil end
local b={kind=a,src=b,si=d,layer=c,li=e,path={"sources",d,"layers",e}}
if a=="look"then
b.k=tonumber(f)
b.look=b.k and c.looks and c.looks[b.k]
if not b.look then return nil end
b.path=h(b.path,"looks")
b.path=h(b.path,b.k)
end
return b
end
if a=="customState"then
local b,c=f(b,c)
return b and{kind=a,cond=b,ci=c,path={"customStates",c}}
end
if a=="event"then
local c,d=c:match("^(.+)/([^/]+)$")
local b=c and L(b,c,d)
return b and{kind=a,event=b,path=b.path,src=b.src,si=b.si,cond=b.cond,ci=b.ci}
end
if a=="add"then
local c,b=c:match("^(%a+):?(.*)$")
return{kind=a,what=c,target=b~=""and b or nil,path={}}
end
end

local function f(b)
local a=d.Sources.get(b.kind)
local a=a and a.idWord
if type(a)=="function"then a=a(b)end
return a or b.kind
end

function c.sourceName(a,b)return e.sourceName(a.sources,b)end
local v=c.sourceName
local z


local function g(a)
local b=a.what=="item"and a.item and not a.item.name and z(a.fact,a.item,true)
if b and type(a.fact)=="table"and a.fact.saidAlone then return(b:gsub("^%l",string.upper))end
return b and((a.label or a.word).." ("..b..")")or a.label
end






function c.keyWords(h,f,b,c)
local a,d=e.splitKey(b)
if d==e.GAME then
local a=e.gameFactSpec(a)
return a and a.label or b
end
if d then
local e=f.sources[d]
local f=e and e.words[a]
local a=f and g(f)or a
if c and c.id==d then return a end
return e and(a.." ("..v(h,e.rec)..")")or b
end
local c=c and f.sources[c.id]
local c=c and c.words[a]
if c and c.what~="event"then return g(c)or a end
local c=f.customStates[a]
if c then return c.rec.name or a end
return b
end
local C=c.keyWords



local function aa(a,b)
local c,d=a.spec.states,a.spec.offersState
for e,b in ipairs(type(b)=="table"and b or{b})do
if c and c[b]and not(d and not d(a.rec,b))then return b end
end
end

local function U(c,b)
local a={}
for d,b in ipairs(type(b)=="table"and b or{b})do
if c.words[b]then a[#a+1]=c.words[b].label end
end
if#a==0 then return nil end
local b=table.remove(a)
return#a>0 and(table.concat(a,", ").." or "..b)or b
end
local function o(b,a,d)
local a,c=e.splitKey(a)
if c==e.GAME then return{what="game",word=a}end
local c=c and b.sources[c]or(d and b.sources[d.id])
local d=c and c.words[a]
if d and d.what~="event"then return d,c end
local b=b.customStates[a]
if b then return{what="customState",word=a,on=b.rec.enabled~=false,cond=b},nil end
end


local function H(a,c)
local b=b.pathList(c)
local a=a
for c,b in ipairs(b)do
if type(a)~="table"then return nil end
if a[b]==nil and a[1]~=nil then
local c
for d,a in ipairs(a)do
if type(a)=="table"and a.id==b then c=a end
end
a=c
else
a=a[b]
end
end
return a
end
c.leafValue=H



function c.keysWords(e,f,b,g,d)
local h,i=j(b["while"]),j(b.unless)
local c=0
local function b(b)
local a={}
for h,b in ipairs(b)do
c=c+1
if d or c<=3 then a[#a+1]=C(e,f,b,g)end
end
return a
end
local b,e=b(h),b(i)
local b=#b>0 and(a.while_.." "..table.concat(b," and "))or""
if#e>0 then b=b..(b~=""and", unless "or"Unless ")..table.concat(e," or ")end
if c>3 and not d then b=b.." "..a.andMore:format(c-3)end
return b
end




function c.picks(f)
local a=c.view(f)
if not a then return{}end


local b=K[f]or{game={},held={},allKnown=true}
K[f]=b
local c
for g,f in ipairs(a.sources or{})do
local e=e.variantOf(f)
local g=b[f.id]or{facts={}}
b[f.id]=g
if e and(g.state==nil or not e.states[g.state])then

local b,a=pcall(d.Preview.typicalPick,a,f.id)
g.state=b and type(a)=="table"and e.states[a.state]and a.state
or(e.stateOrder or{})[1]
c=c or{}
c[f.id]=true
end
end

if c then
local e={}
for b,a in ipairs(a.sources or{})do
if not c[a.id]then e[a.id]=true end
end
d.try("element preview picks",d.Preview.drawing,a,b,e,nil,d.Preview.premadeSay(a))
end
return b
end
local function I(b,a)
a.holds=a.holds or n.holds(a.view,c.picks(b))
return a.holds
end

local function G(a,d,b,c)
local c=c and d.sources[c.id]
for d,b in ipairs(j(b["while"]))do
if not a(n.canonical(b,c))then return false end
end
for d,b in ipairs(j(b.unless))do
if a(n.canonical(b,c))then return false end
end
return true
end

local function J(e,a,c,b)
for d,c in ipairs(j(c["while"]))do
local d=o(a,c,b)
if d and d.on==false then return C(e,a,c,b).." is switched off."end
end
end


local function A(a)
local a=a.compiled
local b={}
for c,a in pairs(a and a.states or{})do
for c,a in ipairs(a)do b[a]=true end
end
return b
end

local function M(a,d)
local a=a.compiled
local c={}
for e,b in ipairs(a and a.factOrder or{})do
local d=d and d.facts[b]
if a.global[b]and not a.borrowed[b]and a.factOn[b]and d and d.look then
c[#c+1]=b
end
end
return c
end
local function w(d,c)
local b={}
for d,a in ipairs(M(d,c))do b[#b+1]=c.facts[a].label end
if#b==0 then return nil end
return a.buttonCues..table.concat(b,", ")
end





d.Debug.experimental("the Layers pane's drawn lines: a clip's layers drawn at its lowest one's place (FR-38,"
.." LYR.clipLevel)","I")
local function k(a,c,e)
local b=a.enabled~=false and d.Layers.get(a.kind)
for b,a in ipairs(b and b.routes and b.routes(c,a,a)or{})do
if a.holder==e then return true end
end
return false
end

local function s(a,b,c)
return d.Sources.clipAura(d.Sources.restsOn(a,c),b.id)
end
local function P(g)
local l={}
local h
for f,c in ipairs(g.view.sources or{})do
local e=e.variantOf(c)
local m=e and e.read=="clip"
local i=c.layers or{}

local e,j,f={},{},{}
for f,b in ipairs(c.enabled~=false and i or{})do
if b.enabled~=false then
local a
if m then
a=k(b,"present","present")and"present"or nil
else
h=h or d.Keys.compile(g.view)
a=s(h,c,b)
end

if a or not m or k(b,"present","button")then
e[f]=a or false
if a then j[a]=j[a]or f end
end
end
end
for a in pairs(e)do f[a]=e[a]and j[e[a]]or a end
for d,h in pairs(e)do
local e={}
for a=d-1,f[d]+1,-1 do
if f[a]and f[a]>f[d]then e[#e+1]=b.layerName(g.view,i[a])end
end
if h and#e>0 then
l["layer:"..c.id.."/"..i[d].id]=a.drawnUnder:format(table.concat(e,", "))
end
end
end
return l
end



local function N(c)
local e=d.Spells
local b=e.firstOf(c.spells)
local a=b and select(2,e.highest(b))
if b and not a then
local b=e.icon(b)
a=not d.isSecret(b)and b or nil
end
if not a then
local b=d.Sources.get(c.kind)
if b and b.icon then a=b.icon(c)end
end
return a
end



local function Q(b,a)
for d,c in ipairs(a.eventOrder)do
if not a.offersEvent or a.offersEvent(b,c)then return true end
end
for c,b in ipairs(a.factOrder)do
if a.facts[b].read=="lua"then return true end
end
return false
end


local function F(a,b,f,d)
local a={}
local function c(c,d,b)
if type(b)=="table"and type(b.effects)=="table"and#b.effects>0 then
a[#a+1]={owner=c,word=d,effects=b.effects}
end
end
if d then
for b,a in ipairs({"enters","leaves"})do c(d.id,a,(d.events or{})[a])end
return a
end
for d,a in ipairs(f.eventOrder)do c(b.id,a,(b.events or{})[a])end
local d=b.facts or{}
for g,a in ipairs(f.factOrder)do
local f=f.facts[a]
if e.isListFact(f)then
for d,a in ipairs(type(d[a])=="table"and d[a]or{})do
for e,d in ipairs({"enters","leaves"})do c(b.id.."."..a.id,d,(a.events or{})[d])end
end
elseif type(d[a])=="table"then
for f,e in ipairs({"enters","leaves"})do c(b.id.."."..a,e,(d[a].events or{})[e])end
end
end
return a
end
c.eventsWithEffects=F



function c.playArgs(a,b)
local c,d=tostring(a):match("^([^%.]+)%.(.+)$")
if c then return c,b,{fact=d}end
return a,b,nil
end


function c.eventWords(a,b,c)
local a=L(a,b,c)
if not a then return""end
if a.cond then return"When it "..a.decl.label:lower()end
if a.fact then return"When "..a.label.." "..a.decl.label:lower()end
return"When "..(a.decl.holds or a.decl.label:lower())
end
local function g(b)
local a={}
for c,b in ipairs(b)do
local c=d.Layers.effect(b.kind)
a[#a+1]=c and c.label or tostring(b.kind)
end
return table.concat(a,", ")
end


function c.learned(a)
if a==nil or a.kind==nil then return true end
local a,b=pcall(n.kindLearned,a)
return not a or b~=false
end



function c.elementLearned(a)
local a,b=pcall(n.youKnow,a)
return not a or b~=false
end





local function R(a)
a.children=a.children or{}
return a
end


local function S(d,a)
local c=b.layerKindLabel(a):lower()
local a=" "..b.layerName(d,a):lower():gsub("%A+"," ").." "
if a:find(" "..c.." ",1,true)then return nil end
return c
end


local function O(c)
local b=b.unitNote(c)
local d=d.Sources.get(c.kind)
local a
if d and d.noteWord then a=d.noteWord(c)or nil else a=f(c)end
if a and b then return a.." "..b end
return a or b
end


local function s(f,h,b,i,j)
local d=false
for b,a in ipairs(b.effects)do d=d or a.enabled~=false end
local e="event:"..b.owner.."/"..b.word
j(h,{key=e,type="event",
label=c.eventWords(f,b.owner,b.word),note=g(b.effects),
greyed=not d or nil,
actions={{op="remove",label=a.remove,args={key=e}}}},i)
end

local function g(b)
local a=a.while_.." "
return b:sub(1,#a)==a and b:sub(#a+1)or b
end

local function V(c,d,e)
local a={}
local function b(f,g,h)
local b={}
for e,a in ipairs(j(e[f]))do b[#b+1]=C(c,d,a,nil)end
if#b>0 then a[#a+1]=h..table.concat(b,g)end
end
b("all"," and ","")
b("any"," or ","")
b("none"," or ","not ")
return#a>0 and table.concat(a,", ")or nil
end

local function T(h,f,i)
local d={}
for e,a in ipairs(e.pointersTo(f.rec,i.id))do
local a=a.path:match("^(sources%[%d+%]%.layers%[%d+%]%.looks%[%d+%])")
local a=a and c.keyOfPath(f.view,b.pathList(a))
if a then d[#d+1]=g(c.title(h,a))end
end
return#d>0 and(a.usedByNote..table.concat(d,", "))or nil
end

local function W(a)return#b.quickRows(a.view)>0 end
function c.tree(i,f)
local d=l(i)
if not d then return{name="",nodes={}}end
local g,k=d.view,d.index
local n=I(i,d)
local function l(a,b)
local a=f and f(a)
if a==nil then return b or false end
return a
end
local h={}
local o=y(i,"drawn",P)
local function f(b,a,c)
a.depth=c
b[#b+1]=R(a)
return a
end
if y(i,"hasQuick",W)then f(h,{key="quick",type="quick",label=a.quick},0)end
f(h,{key="general",type="general",label=a.general},0)
f(h,{key="structure",type="structure",label=a.structure},0)

f(h,{key="sub:sources",type="sub",label=a.sources},0)


f(h,{key="add:source",type="add",label=a.addSource,
adds={{op="open",label=a.addSource,args={key="add:source"}}}},0)
for d=#(g.sources or{}),1,-1 do
local d=g.sources[d]
local m=e.variantOf(d)or{facts={},events={},factOrder={},eventOrder={},states={}}
local e="source:"..d.id
local h=f(h,{key=e,type="section",label=d.name or b.sourceWords(d),
note=not d.name and O(d)or nil,
icon=N(d),drawn=o[d.id],
on=d.enabled~=false,drag="sources",folds=true,folded=l(e),
unlearned=not c.learned(d)or nil,
actions={{op="remove",label=a.remove,args={key=e}}}},0)
if b.premadeHas(i,d.id)then
table.insert(h.actions,1,{op="resetPremade",label=a.resetPremade,args={key=e}})
end
if#(d.layers or{})==0 then
f(h.children,{key="line:layers:"..d.id,type="line",label=a.noLayers,
wide=a.noLayersWide},1)
else
f(h.children,{key="sub:layers:"..d.id,type="sub",label=a.layers},1)
end
for e=#(d.layers or{}),1,-1 do
local e=d.layers[e]
local j="layer:"..d.id.."/"..e.id

local p=#(e.looks or{})>0
local h=f(h.children,{key=j,type="layer",label=b.layerName(g,e),
note=S(g,e),glyph=e.kind,drawn=o[j],
on=e.enabled~=false,drag="layers:"..d.id,folds=p or nil,
folded=p and l(j)or false,
actions={{op="remove",label=a.remove,args={key=j}}}},1)
if b.premadeHas(i,e.id)then
table.insert(h.actions,1,{op="resetPremade",label=a.resetPremade,args={key=j}})
end
local i=A(e)
local b=d.id.."/"..e.id
local function l(j,e,l)
local i=J(g,k,e,d)
local c=c.keysWords(g,k,e,d,true)
f(h.children,{key="look:"..b.."/"..j,type="look",
label=c,
greyed=i~=nil or nil,reason=i,
lit=not i and G(n,k,e,d)or nil,drag="looks:"..b..":"..l,
actions={{op="remove",label=a.remove,args={key="look:"..b.."/"..j}}}},2)
end


local c=e.looks or{}
for a=#c,1,-1 do
if not i[a]then l(a,c[a],"flag")end
end
local d=w(e,m)
if d then
f(h.children,{key="global:"..b,type="global",label=d},2)
end
for a=#c,1,-1 do
if i[a]then l(a,c[a],"state")end
end
f(h.children,{key="add:look:"..b,type="add",label=a.addLook,
adds={{op="draftLook",label=a.addLook,args={key=j}}}},2)
end
f(h.children,{key="add:layer:"..d.id,type="add",label=a.addLayer,
adds={{op="open",label=a.addLayer,args={key="add:layer:"..d.id}}}},1)
local b=F(g,d,m)
if#b>0 then f(h.children,{key="sub:events:"..d.id,type="sub",label=a.events},1)end
for b,a in ipairs(b)do s(g,h.children,a,1,f)end
if Q(d,m)then
f(h.children,{key="add:effect:"..d.id,type="add",label=a.addEffect,
adds={{op="open",label=a.addEffect,args={key="add:effect:"..d.id}}}},1)
end
end
local c=g.customStates or{}

local e=f(h,{key="customStates",type="section",label=a.customStates,glyph="customState",
folds=#c>0 or nil,pick=false,
folded=#c>0 and l("customStates")or false},0)
for c,b in ipairs(c)do
local c="customState:"..b.id
local a=f(e.children,{key=c,type="customState",label=b.name or b.id,
note=V(g,k,b),used=T(i,d,b),on=b.enabled~=false,
lit=b.enabled~=false and n(b.id)or nil,
actions={{op="remove",label=a.remove,args={key=c}}}},1)
for c,b in ipairs(F(g,nil,nil,b))do s(g,a.children,b,2,f)end
end
f(e.children,{key="add:customState",type="add",label=a.addCustomState,
adds={{op="draftCustomState",label=a.addCustomState,args={}}}},1)
return{name=b.nameOf(g),nodes=h}
end


function c.visible(b)
local a={}
local function c(b)
for d,b in ipairs(b)do
a[#a+1]=b
if not b.folded then c(b.children)end
end
end
c(b.nodes or{})
return a
end




function c.words(c,a,d)
if type(a)=="boolean"then return a and"on"or"off"end
if a==nil then return c.widget=="colour"and"the game's own"or"none"end
if(c.widget=="choice"or c.widget=="picture")and c.field then
local c,b=b.choices(c,d)
return b[a]or tostring(a)
end
if c.widget=="colour"then return tostring(a):upper()end
if type(a)=="number"and c.unit then return t.unitFormat(c.unit,c.field and c.field.step or 1)(a)end
if type(a)=="table"then return tostring(#a)end
return tostring(a)
end
local ab=c.words


local function s(b)
local a={}
for b,c in ipairs(j(b))do a[b]=tostring(c)end
return table.concat(a,", ")
end





local function t(h,i)
local e=d.Spells
local c=b.read(h,b.up(i))
c=type(c)=="table"and c or{}
local f=d.Sources.get(c.kind)
local f=f~=nil and rawget(f,"matches")~=nil
local k=d.Sources.exactSet(c.exact)or{}
local g={}
for h,b in ipairs(j(b.read(h,i)))do
local i,h=e.family(b)
local j,i=e.highest(b)
local c=f and d.Sources.matchesOf(c,b)
g[#g+1]={id=b,label=e.label(b)or tostring(b),idText=tostring(b),
icon=i or h and h.icon or nil,exact=k[b]or nil,
note=f and not c and a.thisId or nil,
tip=c and a.matches:format(table.concat(c,", "))or f and a.matchesAlone or nil}
end
return g
end


local w={"sources",1}


local function k(f,i,c)
local g=c.field or{}
local h=b.read(i,c.path)

local f=g.help
if type(g.helpFrom)=="function"then f=g.helpFrom(i,c.path)or f end
local f={type="field",key=c.key,path=c.path,label=c.label,help=f,widget=c.widget,
unit=c.unit,value=h,min=g.min,max=g.max,step=g.step or(g.type=="integer"and 1 or nil),
softMin=g.softMin,softMax=g.softMax,optional=b.optional(g)or nil,depth=c.depth,form=c,
tip=g.tip}
if c.widget=="choice"or c.widget=="multi"then
local a,d=b.choices(c,i)
f.choices={}
for b,a in ipairs(a)do f.choices[b]={a,d[a]}end

if c.widget=="multi"and g.ref=="layer"and h==nil then
local a=b.overDefault(c,i)
f.value=a and{a}or nil
end
if c.widget=="choice"then
local a=g.pickSpell
if a and h==a.value then
local b=b.read(i,b.up(c.path))
f.value=b and b[a.field]or h
end
if f.value==nil then f.value=b.NONE end
end
elseif c.widget=="spells"then

f.text,f.entries=s(h),t(i,c.path)
if#f.entries<(g.maxItems or e.MAX_SPELLS)then f.add=a.addSpell end
f.widened=b.widenedLine(i,c.path)
elseif c.widget=="spell"or c.widget=="edit"or c.widget=="fileId"then
f.text=h==nil and""or tostring(h)
if c.widget=="spell"then f.note=h and d.Spells.label(h)or""end


if c.widget=="fileId"then
local e=c.path[1]=="menuIcon"
if h==nil then

local b=b.read(i,e and w or b.up(c.path,3))
local b=type(b)=="table"and d.Spells.label(d.Spells.firstOf(b.spells))
f.hint=b or(e and a.autoIcon or a.ownPicture)
else
f.set,f.resetTip,f.reset=true,e and a.backAutoIcon or a.backOwnPicture,c.path
end
end
elseif c.widget=="text"then
f.text,f.maxBytes=h or"",g.type=="string"and(g.max or 64)or nil


if c.path and#c.path==1 and c.path[1]=="name"and(h==nil or h=="")then f.hint=b.nameOf(i)end
elseif c.widget=="slider"and f.optional then
f.fallback=b.inForce(c,i)
elseif c.widget=="colour"and f.optional then

f.noneIsWhite=true
if f.value==nil then f.value="#ffffff"end
end
if e.caveatCanSit(c.path,c.vars)then
local a={}
for b,c in ipairs(b.caveats(c,i))do a[b]=c.text end
f.caveats=#a>0 and table.concat(a," ")or nil
end
f.shown=b.shown(c,i)
return f
end
c.fieldRow=k



local s,W
function c.offers(e,a,c)
if not a then return false end
if c==b.NONE then c=nil end
local d=a.value
if d==b.NONE then d=nil end
if c==d then return true end

if a.op=="setQuickChoice"and c=="custom"then return false end
if a.op=="draftSet"then return true end
if a.op then return s[a.op]~=nil and W(e,a,c)end
return b.accepts(e,a.path,c)
end



function c.listed(d,a,c)
if not a then return false end
if c==b.NONE then c=nil end
local d=a.value
if d==b.NONE then d=nil end
if c==d then return true end
if a.op=="setQuickChoice"and c=="custom"then return false end
return not a.op or s[a.op]~=nil or a.op=="draftSet"
end

function c.offersInList(c,a,d)
return a~=nil and b.offersInList(c,a,d,a.value)
end



local function t(c,e,f,a,g,h)
local i=j(b.read(c,a))
local d={}
for b,a in ipairs(i)do d[b]={key=a,label=C(c,e,a,h)}end
return{type="keys",key=f,path=a,label=g,keys=d,menu=b.pathString(b.up(a)),
field=a[#a]}
end


local function w(h,e,a)
local f,c={},nil
for g,a in ipairs(a)do
local g
if a.heading then
g={type="heading",key=a.key,label=a.label,depth=a.depth,form=a,shown=b.shown(a,e)}
elseif a.widget=="keys"then
g=t(e,l(h).index,a.key,a.path,a.label,nil)
else
g=k(h,e,a)
end
if a.style then
local i=b.pathKey(a.style.path)
if not(c and c.key=="style:"..i)then

local d,g=d.StyleModel,b.own(h,a.style.path)
local h=d.pick(a.style.part,g,b.styleParent())
local j=d.links(a.style.part,g,b.styleParent())
c={type="style",key="style:"..i,part=a.style.part,path=a.style.path,rows={},
own=g,label=d.PICK_LABEL,picked=h.picked,choices=h.choices,resetTip=d.RESET_TIP,
save=j.save and d.SAVE_LABEL or nil,edit=j.edit,
line=d.followLine(a.style.part,g,b.read(e,a.style.path),b.styleVars(e,a.style.path))}
f[#f+1]=c
end
c.rows[#c.rows+1]=g
else
c=nil
f[#f+1]=g
end
end
return f
end


local function Q(b)
local c=A(b)
local a={}
for b in ipairs(b.looks or{})do
if c[b]then a[#a+1]=b end
end
for b in ipairs(b.looks or{})do
if not c[b]then a[#a+1]=b end
end
return a
end


local function R(b,c,d)
b.why=b.why or{}
local a=b.why[c]
if not a then
a={}
n.lookAt(c,d,a)
b.why[c]=a
end
return a
end






local function X(j,k,g,f,c)
local d={}
for a,b in ipairs(g.looks or{})do
local a=b["while"]
if type(a)=="table"and#a==1 then a=a[1]end
if type(a)=="string"and b.unless==nil and n.valuesOf(b)==nil then d[a]=true end
end
local e,i={},{}
for a,c in ipairs(c)do
local d=c.path[#f+1]
local a=i[d]
if not a then
local c=g[d]
local f=h(f,d)
a={key=b.pathKey(f),part=d,actions={},form={},
on={value=not(type(c)=="table"and c.enabled==false),path=h(f,"enabled")}}
i[d]=a
e[#e+1]=a
end
if c.heading and#c.path==#f+1 then a.title=c.label else a.form[#a.form+1]=c end
end
for e,c in ipairs(e)do


if not d[c.part]then
for b,a in ipairs(c.form)do a.partOn=c.on.path end
end
c.rows=w(j,k,b.headingsLast(c.form))
c.form=nil
if d[c.part]then table.insert(c.rows,1,{type="line",key="borrowed",text=a.cueBorrowed})end
end
return e
end


local function Y(c)
return{key="source",label=a.source,name=c.name or b.sourceWords(c),
note=not c.name and O(c)or nil,icon=N(c),open="source:"..c.id}
end


local function S(a)
if#a<2 then return a[1]or""end
return table.concat(a,", ",1,#a-1).." and "..a[#a]
end

local function f(a)
return(tostring(a or""):gsub("^%u%l",string.lower))
end



local function T(c,l,m,h,n,i)
local c,k={},{}
local function g(a)
if not k[a]then k[a],c[#c+1]=true,a end
end
for c,b in ipairs(e.frame("look:"..m.kind,h,{}))do
local c=h[b.name]
if c~=nil and b.name~="while"and b.name~="unless"then
if b.partKind then

local e=true
local c=b.type=="map"and c or{c}
for b,a in pairs(type(c)=="table"and c or{})do
for a,b in pairs(type(a)=="table"and a or{})do
if not(a=="shown"and b==false)then e=false end
end
end
local b=f(d.Layers.partLabel(b.partKind))
g(e and(b.." "..a.hidden)or b)
elseif b.name=="shown"then
g(c and a.shownWord or a.hidden)
elseif b.type=="boolean"then
g(c and f(b.label)or a.notWord:format(f(b.label)))
elseif b.type=="percent"then
g(f(b.label).." "..tostring(c).."%")
else
g(f(b.label))
end
end
end
if#c==0 and h.unless==nil then
local c=j(h["while"])
local c=#c==1 and o(l,c[1],n)
if c and c.what=="fact"and c.fact and c.fact.look then
local c=type(i)=="table"and i[c.word]
return b.ownStyle(type(c)=="table"and c.style or nil)and a.ownLook or a.globalLook
end
end
return#c>0 and table.concat(c,", ")or nil
end

local function O(a,b,f,d,e,g)
local c=c.keysWords(a,b,d,e,true)
local a=T(a,b,f,d,e,g)
return a and(c..": "..a)or c
end
c.lookSentence=O

local function P(c)
for c,b in ipairs(e.fieldsOf("layer",c.kind)or{})do
if b.name=="picture"then return a.picture end
end
return b.layerKindLabel(c)
end



local function Z(i,c,f)
local h,g=c.view,c.index
local d,e=f.layer,f.src
local f=b.read(c.rec,f.path)
local l=I(i,c)
local i=A(d)
local j=e.id.."/"..d.id
local b={}
local function k(i,a)
local c=J(h,g,a,e)
local j="look:"..j.."/"..i
local i=type(f)=="table"and type(f.looks)=="table"and f.looks[i]or a
b[#b+1]={type="link",key=j,label=O(h,g,d,i,e,f),op="open",
args={key=j},look=true,lit=not c and G(l,g,a,e)or nil,
dim=c~=nil or nil,
note=c}
end

local c=d.looks or{}
for a=#c,1,-1 do
if not i[a]then k(a,c[a])end
end
local d=#b
for a=#c,1,-1 do
if i[a]then
if d>0 and#b==d then b[#b+1]={type="rule",key="band"}end
k(a,c[a])
end
end
b[#b+1]={type="link",key="addLook",label="+ "..a.addLook,op="draftLook",
args={key="layer:"..j}}
return b
end





local function ac(k,m,g)
local i,o=m.view,m.index
local f,l=g.layer,g.src
local j,q,p=b.varsAt(i,g.path)
local q={}
b.addRows(q,"layer",f,p,g.path,0)
local r,j,s={},{},{}
local t={}
for b,a in ipairs(d.Styles.cueFields())do t[a.name]=true end
for a,b in ipairs(q)do
local a=b.path[#g.path+1]
local c=(d.Layers.SIDES[a]or a=="position")and j
or t[a]and s or r

local d=#b.path==#g.path+1
if not(d and a=="name")and not(d and a=="position"and b.heading)then c[#c+1]=b end
end


local q,t={},{}
for b,a in ipairs(j)do
local b=d.Layers.SIDES[a.path[#g.path+1]]and q or t
b[#b+1]=a
end
j=q
for b,a in ipairs(t)do j[#j+1]=a end

local q=d.Layers.get(f.kind)and d.Layers.get(f.kind).softSize
for b,a in ipairs(q and j or{})do
local b=a.path[#a.path]
if#a.path==#g.path+1 and d.Layers.SIDES[b]and a.field and a.field.softMax then
local b={}
for a,c in pairs(a.field)do b[a]=c end
b.softMax=q
a.field=b
end
end
local q=I(k,m)
local v=R(m,f,q)
local t={}
for b,a in ipairs(n.leafPaths(f))do t[a]=true end
local n=l.id.."/"..f.id
local function u(a)
if a.type~="field"then return end
local d={}
for b=#g.path+1,#a.path do d[#d+1]=tostring(a.path[b])end
local d=table.concat(d,".")

local e,g,h=d:match("^(%a+)%.(%d+)%.(.+)$")
if e and type(f[e])=="table"then
local a=f[e][tonumber(g)]
if a and a.id then d=e.."."..a.id.."."..h end
end
if not t[d]then return end
a.tags={}

local e=Q(f)
for g=#e,1,-1 do
local e=e[g]
local f=f.looks[e]
if b.read(f,b.pathList(d))~=nil then
a.tags[#a.tags+1]={key="look:"..n.."/"..e,label=c.keysWords(i,o,f,l),
wins=v[d]==e or nil,holds=G(q,o,f,l)or nil}
end
end
end
local c={{key="looks",title=a.looks,group=true,rows=Z(k,m,g)},
{key="layer",title=P(f),group=true,rows=w(k,i,b.headingsLast(r))}}
if#j>0 then
c[#c+1]={key="place",title=a.sizeAndPlace,group=true,
rows=w(k,i,b.headingsLast(j))}
end
local m,j,n={},{},{}
for e,c in ipairs(b.partSections(f,p,g.path,l))do


local d=d.Layers.part(c.kind)
if d and d.lookShown then
for b=#c.rows,1,-1 do
local a=c.rows[b]
if#a.path==#c.path+1 and a.path[#a.path]=="shown"then table.remove(c.rows,b)end
end
end


for d,b in ipairs(c.rows)do
if b.heading and b.group=="place"and b.parent==nil then b.label=a.partPlace:format(c.title)end
end
local d=b.read(i,c.on)
local b={key=c.key,title=c.title,part=c.kind,on={value=d~=false,path=c.on},
rows=w(k,i,b.headingsLast(c.rows)),actions={}}
if c.item then
local c={path=g.path,list=c.partKey,item=c.item}
b.actions={{op="renamePart",label=a.rename,args=c,ask=true},
{op="duplicatePart",label=a.duplicate,args=c},
{op="removePart",label=a.remove,args=c}}
end

if c.partKey=="pressed"then j[#j+1]=b
elseif c.item then
n[c.partKey]=n[c.partKey]or{}
table.insert(n[c.partKey],b)
else m[#m+1]=b end
end
for b,a in ipairs(X(k,i,f,g.path,s))do j[#j+1]=a end
if#m>0 then
c[#c+1]={key="group:parts",title=a.onThe:format(b.layerKindLabel(f):lower()),
group=true,rows={}}
for b,a in ipairs(m)do c[#c+1]=a end
end


for h,a in ipairs(d.Layers.partsOf(f.kind))do
local h=n[a.key]or{}
local b=a.list and b.canAddPart(i,g.path,a.key)
if#h>0 or b then
local e=e.field("layer",a.key,f.kind)
local b=b and{type="button",key="add:"..a.key,
label="+ Add "..d.Layers.partLabel(a.kind):lower(),op="addPart",args={path=g.path,list=a.key}}
c[#c+1]={key="group:"..a.key,title=e and e.label or a.key,group=true,
rows={b or nil}}
for b,a in ipairs(h)do c[#c+1]=a end
end
end
if#j>0 then
c[#c+1]={key="group:cues",title=a.cuesTitle,group=true,rows={}}
for b,a in ipairs(j)do c[#c+1]=a end
end
for b,a in ipairs(c)do
for b,a in ipairs(a.rows)do
u(a)
for b,a in ipairs(a.rows or{})do u(a)end
end
end
local e="layer:"..l.id.."/"..f.id
local d={{op="rename",label=a.rename,args={key=e},ask=true}}
if b.premadeHas(k,f.id)then
d[#d+1]={op="resetPremade",label=a.resetPremade,args={key=e}}
end
d[#d+1]={op="remove",label=a.remove,args={key=e}}
return{title=b.layerName(i,f),intro={{key="kind",label=a.layerType,
value=b.layerKindLabel(f)},Y(l)},
on={value=f.enabled~=false,path=h(g.path,"enabled")},actions=d,
sections=c}
end




local function Q(a)
return#(a.setting or{})>1 and not a.together
end

local function g(a)return type(a)=="table"and a.max==1 end
local function X(i,c,m,o,d,j,g)
local f=c.view
local e=e.variantOf(f.sources[m])
local j={"sources",m,"facts",o,j}
local c={}
local l={}
for b,a in ipairs(d.setting or{})do l[a.name]=true end
local n={}
local q,r,p=b.varsAt(f,j)
local q,r,m=b.varsAt(f,{"sources",m})
b.addRows(n,"factItem:"..e.key..":"..o,g,p or m,j,0,nil,nil,function(a)
return not(l[a.name]or a.name=="name")
end)
local m=g.name or d.label
if Q(d)then
local e
for b,a in ipairs(d.setting)do
if g[a.name]~=nil and not e then e=a end
end
e=e or d.setting[1]
local l={}
for b,a in ipairs(d.setting)do l[#l+1]={a.name,a.label}end
c[#c+1]={type="field",key=b.pathKey(j)..".rule",path=j,widget="choice",
label=m,choices=l,value=e.name,op="setRule"}

local j
for d,b in ipairs(n)do
local d=b.path[#b.path]
if d==e.name then
if e.type=="list"then
for j=1,2 do
local a=k(i,f,b)
a.key,a.path=a.key.."."..j,h(b.path,j)
a.widget,a.value="edit",type(g[d])=="table"and g[d][j]or nil
a.text=a.value and tostring(a.value)or""
a.label=j==1 and e.label or""
c[#c+1]=a
end
else
local a=k(i,f,b)
a.label=""
c[#c+1]=a
end
elseif d=="name"then
j=k(i,f,b)
j.label=a.rangeName
end
end
c[#c+1]=j
else


local g
for b,e in ipairs(n)do
local b=k(i,f,e)
if l[e.path[#e.path]]and d.together then

c[#c+1]=b
elseif l[e.path[#e.path]]then
b.label=m

local e=d.setting[1]
b.help=e.help or(e.unit=="s"and a.startsSeconds or e.type=="percent"and a.startsShare
or a.atOrUnder):format(d.label)
c[#c+1]=b
else

b.label=a.itemName:format(m)
g=b
end
end
c[#c+1]=g
end
return c
end


function z(g,b,h)
local c={}


if g.together then
for d,a in ipairs(g.setting)do
local b=b[a.name]
if b~=nil and b~=a.default then
c[#c+1]=f(a.label)..(a.type=="boolean"and""
or(" "..(a.labels and a.labels[b]or tostring(b))))
end
end
return#c>0 and table.concat(c,", ")or nil
end
for d,e in ipairs(g.setting or{})do
local d=b[e.name]
if d~=nil then
local b
if type(d)=="table"then
b=d[1]==d[2]and a.exactly:format(tostring(d[1]))or tostring(d[1]).." to "..tostring(d[2])
else
local c=e.type=="percent"and"%"or e.unit and(" "..e.unit)or""
b=tostring(d)..c
if e.said then b=e.said:format(b)
elseif Q(g)then b=f(e.label).." "..b
elseif h and c~=""then b="last "..b
elseif h then b=a.orFewer:format(b)end
end
c[#c+1]=b
end
end
return#c>0 and table.concat(c,", ")or nil
end


local function Y(d,f)
local d,j=d.view,d.index
local f={}
e.eachRef(d,function(e,h,i,l,k,g)
if e~="keys"then return end
local e=g.layer and g.source and j.sources[g.source.id]
local l=n.canonical(h,e)
local h=k:match("^(sources%[%d+%]%.layers%[%d+%]%.looks%[%d+%])")
local e,i
if h then
local f=b.pathList(h)
e=c.keyOfPath(d,f)
local h=b.read(d,b.up(f,2))
local f=b.read(d,f)
if e and h and f then
i=a.lookOf:format(b.layerName(d,h),c.keysWords(d,j,f,g.source))
end
else
local c=tonumber(k:match("^customStates%[(%d+)%]"))
local b=c and d.customStates and d.customStates[c]
if b then
e,i,h="customState:"..b.id,a.stateNamed:format(b.name or b.id),
"customStates["..c.."]"
end
end
if e and i then
local a=f[l]or{}
f[l]=a
local b=false
for c,a in ipairs(a)do b=b or a.key==e end
if not b then a[#a+1]={key=e,label=i,path=h}end
end
end)


for g,c in ipairs(d.sources or{})do
local g=e.variantOf(c)
for h,e in ipairs(g and c.layers or{})do
for h,g in ipairs(M(e,g))do
local g=c.id.."."..g
f[g]=f[g]or{}
table.insert(f[g],{key="layer:"..c.id.."/"..e.id,
label=a.cuesOf:format(b.layerName(d,e))})
end
end
end
return f
end


local R,J={"while","unless"},{"all","any","none"}
local function G(a,b,e,f)
local c,d={},{}
for g,f in ipairs(f or R)do
for f,b in ipairs(j(b[f]))do
local b,a=o(a.index,b,e)
if b and b.what=="item"and a and not d[a.rec.id.."."..b.word]then
d[a.rec.id.."."..b.word]=true
for e,d in ipairs(a.spec.factOrder)do
if a.spec.facts[d]==b.fact then
local e=type(a.rec.facts)=="table"and a.rec.facts[d]or{}
for f,e in ipairs(type(e)=="table"and e or{})do
if e.id==b.word then c[#c+1]={e=b,s=a,word=d,n=f,item=e}end
end
end
end
end
end
end
return c
end




local function R(d,e,b,f)
local c={}
local h=y(d,"uses",Y,d)
for i,b in ipairs(b)do
if g(b.e.fact)then

if#(b.e.fact.setting or{})>0 then
c[#c+1]={type="link",key="setOn:"..b.s.rec.id.."."..b.e.word,op="open",
label=a.setOnSource:format(b.e.label or b.e.fact.label,z(b.e.fact,b.item,true)or""),
args={key="source:"..b.s.rec.id}}
end
else
for b,a in ipairs(X(d,e,b.s.i,b.word,b.e.fact,b.n,b.item))do c[#c+1]=a end
local d={}
for b,a in ipairs(h[b.s.rec.id.."."..b.e.word]or{})do
if a.path~=f then d[#d+1]=a.label end
end
if#d>0 then
c[#c+1]={type="line",key="alsoUsed:"..b.s.rec.id.."."..b.e.word,
text=a.alsoUsedBy:format(S(d))}
end
end
end
return c
end


local function Z(a,d)
local b={}
for c,a in ipairs(a)do
local c=false
for b,a in pairs(type(a.item.events)=="table"and a.item.events or{})do
if type(a)=="table"and type(a.effects)=="table"and#a.effects>0 then c=true end
end
if not a.e.fact.default and not c and#e.pointersTo(d,a.e.word,a.s.rec.id)==0 then b[#b+1]=a end
end
return b
end
local function ad(d,c,a)
return R(d,c,G(c,a.look,a.src),b.pathString(a.path))
end




local function ae(e,h,b)
local d,i=b.src,b.si
local b=h.index.sources[d.id]
local c={}
if not b then return c end
local l=y(e,"uses",Y,e)
local j=type(d.facts)=="table"and d.facts or{}
for f,b in ipairs(b.order)do
if b.what~="event"then



local f=b.holds or""
local g=b.what=="item"and g(b.fact)
local k=b.what=="item"and not g and b.item and z(b.fact,b.item,true)
if k then f=f:gsub("%.$","").." ("..k..")."end
local k=l[d.id.."."..b.word]or{}
c[#c+1]={type="heading",key="readsHead:"..b.word,label=b.label}

c[#c+1]={type="line",key="reads:"..b.word,full=true,text=f}


local d=g and j[b.fact.word]
for d,a in ipairs(type(d)=="table"and d or{})do
if a.id==b.word then
for d,a in ipairs(X(e,h,i,b.fact.word,b.fact,d,a))do



local d=a.path[#a.path]=="name"
if a.widget~="choice"and not d and not Q(b.fact)and not b.fact.together then
a.label=b.fact.setting[1].label
end
if not d then c[#c+1]=a end
end
end
end
for e,d in ipairs(k)do
c[#c+1]={type="link",key="reads:"..b.word..":"..e,label=a.usedBy..d.label,
op="open",args={key=d.key}}
end
local d=j[b.word]
if b.what=="fact"and type(d)=="table"and d.enabled==false then
c[#c+1]={type="field",key="factOn:"..b.word,widget="toggle",label=a.on,
path={"sources",i,"facts",b.word,"enabled"},value=false,
help=a.factOff:format(b.label)}
end
end
end
return c
end






local function Q(y,p,f)
local m,q=p.view,p.index
local i,o,l,s=f.layer,f.src,f.look,f.k
local g,v,z=b.varsAt(m,f.path)
local v="look:"..o.id.."/"..i.id.."/"..s
local g,C=h(f.path,"while"),h(f.path,"unless")
local g={t(m,q,"while",g,a.while_,o)}
local w=l.unless~=nil


local B=g[1].keys
if#B==1 and not w then B[1].greyed=true end
local r=r[y]and r[y][v]
if w or r then
g[#g+1]=t(m,q,"unless",C,a.unless,o)
end
local t=A(i)
if t[s]then
if not(w or r)then
g[#g+1]={type="link",key="addUnless",label=a.addUnless,op="addUnless",
args={key=v}}
end
elseif not(w or r)then
g[#g+1]={type="link",key="addUnless",label=a.addUnless,op="addUnless",
args={key=v}}
end
if r and not w and t[s]then
g[#g+1]={type="line",key="unlessMoves",text=a.unlessMoves}
end
for b,a in ipairs(ad(y,p,f))do g[#g+1]=a end

g[#g+1]={type="button",key="showInPreview",label=a.showInPreview,op="showInPreview",
args={key=v}}

local t={}
for b,a in ipairs(u.lookFields(p.rec,(b.pathString(f.path):gsub("%.looks%[%d+%]$","")),s,
x()))do
t[a.path]=a
end
local r={}
local u="look:"..i.kind
b.addRows(r,u,l,z,f.path,0)
for c,a in ipairs(e.frame(u,l,z))do
if a.type=="map"then
for g,c in ipairs(type(i[a.name])=="table"and i[a.name]or{})do
local e=h(h(f.path,a.name),c.id)
local d={key=b.pathKey(e),path=e,heading=true,depth=0,
label=b.partTitle(c,g,d.Layers.partLabel(a.name=="glows"and"glow"or"barText"))}
r[#r+1]=d
b.addRows(r,a.record,l[a.name]and l[a.name][c.id],z,e,1,d)
end
end
end

local e=q.sources[o.id]
local d={}
for b,a in ipairs(j(l["while"]))do d[n.canonical(a,e)]=true end
local j=n.lookAt(i,d)
local d={}
for c,e in ipairs(r)do
local c={}
for a=#f.path+1,#e.path do c[#c+1]=tostring(e.path[a])end
local f=table.concat(c,".")
local h=t[f]
if e.heading then
d[#d+1]=e
elseif h then
local c=k(y,m,e)
local g=b.read(l,b.pathList(f))
local j=H(j,f)
c.value=g
if g==nil then c.value=j end
if c.widget=="choice"and c.value==nil then c.value=b.NONE end
c.set=g~=nil or nil
if g~=nil then
c.follows="own"
local b=H(i,f)
c.resetTip=a.backLayer..ab(e,b,m)
c.reset=c.path
end
c.greyed=h.status=="greyed"or nil
c.reason=h.line
d[#d+1]=c
end
end

local e={}
for b,a in ipairs(d)do
if a.heading then
local b=d[b+1]
if b and not b.heading and(b.depth or 0)>(a.depth or 0)then
e[#e+1]={type="heading",key=a.key,label=a.label,depth=a.depth,path=a.path}
end
else
e[#e+1]=a
end
end


local d,h={},false
local j=P(i)
for b,a in ipairs(e)do
local b={}
for a,c in pairs(a)do b[a]=c end
if a.type=="heading"then
if(a.depth or 0)==0 then j=a.label end
b.shown=false
else
b.shown=a.set and a.shown~=false or false
b.label=j.." · "..tostring(a.label or"")
h=h or b.shown
end
d[#d+1]=b
end
local j=b.read(p.rec,b.up(f.path,2))
local k=type(j)=="table"and type(j.looks)=="table"and j.looks[s]or l
local j=not h and T(m,q,i,k,o,j)
table.insert(d,1,{type="line",key="nothing",shown=not h,full=true,
text=j and a.borrowsLook:format(j)or a.changesNothing})

local d={{key="keys",title=a.when,group=true,rows=g},

{key="sets",title=a.changes,group=true,holds=true,rows=d},
{key="all",title=a.everything,group=true,holds=true,rows={}},
{key="own",title=P(i),group=true,rows={}}}
local h,j={},{}
local g=d[4]
for b,a in ipairs(e)do
if a.type=="heading"and(a.depth or 0)==0 then
g={key="part:"..a.key,title=a.label,rows={}}
local a=a.path and a.path[#f.path+1]=="pressed"and j or h
a[#a+1]=g
else
g.rows[#g.rows+1]=a
end
end
if#d[4].rows==0 then table.remove(d,4)end
if#h>0 then
d[#d+1]={key="group:parts",title=a.onThe:format(b.layerKindLabel(i):lower()),
group=true,rows={}}
for b,a in ipairs(h)do d[#d+1]=a end
end
if#j>0 then
d[#d+1]={key="group:cues",title=a.cuesTitle,group=true,rows={}}
for b,a in ipairs(j)do d[#d+1]=a end
end
local e="layer:"..o.id.."/"..i.id

return{title=c.keysWords(m,q,l,o,true),
intro={{key="layer",label=a.layer,name=b.layerName(m,i),open=e}},
actions={{op="remove",label=a.remove,args={key=v}}},
sections=d}
end


local function P(i,m,g)
local j=m.view
local c=g.src
local e,l,f=b.varsAt(j,g.path)
local e={}
b.addRows(e,"source",c,f,g.path,0)

for a=#e,1,-1 do
if#e[a].path==#g.path+1 and e[a].path[#e[a].path]=="name"then table.remove(e,a)end
end

local l=d.Sources.get(c.kind)
local f={}
if d.Sources.unset(c)and l and l.target then
f[1]={type="line",key="pick",text=l.target.pick}
for b,a in ipairs(e)do
if a.path[#a.path]==l.target.field then f[#f+1]=k(i,j,a)end
end
for b,a in ipairs(e)do
if a.path[#a.path]~=l.target.field then f[#f+1]=k(i,j,a)end
end
else
f=w(i,j,b.headingsLast(e))
end

if d.Sources.experimental(c.kind)then
table.insert(f,1,{type="line",key="experimental",text=d.Sources.EXPERIMENTAL.tip})
end
local e={{key="settings",rows=f}}
local d=ae(i,m,g)
if#d>0 then e[#e+1]={key="reads",title=a.reads,group=true,rows=d}end
local f="source:"..c.id
local d={{op="rename",label=a.rename,args={key=f},ask=true}}
if b.premadeHas(i,c.id)then
d[#d+1]={op="resetPremade",label=a.resetPremade,args={key=f}}
end
d[#d+1]={op="remove",label=a.remove,args={key=f}}
return{title=v(j,c),
intro={{key="kind",label=a.sourceType,value=b.sourceTypeLabel(c)}},
on={value=c.enabled~=false,path=h(g.path,"enabled")},actions=d,
sections=e}
end


local function g(i,e,j,f,c)
local g,k=e.view,e.index
local f=h(h(j.path,"effects"),f)
local l,m,e=b.varsAt(g,f)
local l={}
b.addRows(l,"effect",c,e,f,0,nil,nil,function(a)return a.type=="keys"end)
local e={}
if j.moment~="engine"then
e[#e+1]=t(g,k,"while",h(f,"while"),a.while_,nil)
if c.unless~=nil or(r[i]and r[i]["effect:"..tostring(c.id)])then
e[#e+1]=t(g,k,"unless",h(f,"unless"),a.unless,nil)
else
e[#e+1]={type="link",key="addUnless",label=a.addUnless,op="addUnless",
args={key="effect:"..tostring(c.id)}}
end
end
for b,a in ipairs(w(i,g,b.headingsLast(l)))do e[#e+1]=a end
local b=d.Layers.effect(c.kind)
return{key="effect:"..tostring(c.id),title=b and b.label or tostring(c.kind),rows=e,
on={value=c.enabled~=false,path=h(f,"enabled")},
actions={{op="remove",label=a.remove,args={key="effect:"..tostring(c.id)}}}}
end
local function T(f,e,d)
local d=d.event
local h=b.read(e.view,h(d.path,"effects"))or{}
local b={}

if d.item and d.src then
local a=e.index.sources[d.src.id]
local a=a and R(f,e,G(e,{all={d.src.id.."."..d.item}},nil,J),"")or{}
if#a>0 then b[#b+1]={key="item",rows=a}end
end
for a,c in ipairs(h)do b[#b+1]=g(f,e,d,a,c)end
b[#b+1]={key="add",rows={{type="link",key="addEffect",label="+ "..a.addEffect,
op="open",args={key="add:effect:"..d.owner,event=d.word}}}}
return{title=c.eventWords(e.view,d.owner,d.word),sections=b}
end


local function H(d,a)
local b={}
for c,a in ipairs(a.sources)do
if a.spec.moment~="engine"then
for e,c in ipairs(a.spec.eventOrder)do
b[#b+1]={a.rec.id.."."..c,v(d,a.rec)..": "..a.spec.events[c].label}
end
end
end
return b
end
i.holdEvents=H

local function X(j,k,d)
local g,l=k.view,k.index
local f,q=d.cond,d.ci
local i=d.path
local d,m,n=b.varsAt(g,i)
local d={}
local m={}
b.addRows(m,"customState",f,n,i,0,nil,nil,function(a)return a.type=="keys"end)
for b,a in ipairs(w(j,g,m))do d[#d+1]=a end
d[#d+1]=t(g,l,"all",h(i,"all"),a.all,nil)
d[#d+1]=t(g,l,"any",h(i,"any"),a.any,nil)
d[#d+1]=t(g,l,"none",h(i,"none"),a.none,nil)
for b,a in ipairs(R(j,k,G(k,f,nil,J),b.pathString(i)))do
d[#d+1]=a
end

local m={{b.NONE,"None"}}
for b,a in ipairs(H(g,l))do m[#m+1]=a end
local n=type(f.hold)=="table"and f.hold.after~=nil and f.hold or nil


local p=u.summary({index=e.keyIndex(k.rec),summaries={}},f.id)

local o
if p.secret then
if not n then m={m[1]}end
local c,b=e.splitKey(p.secretKey or"")
local b=b and l.sources[b]
o=a.cantWait:format(b and v(g,b.rec)or tostring(c))
end
d[#d+1]={type="field",key="hold.after",path=h(i,"hold"),widget="choice",
label=a.after,choices=m,value=n and n.after or b.NONE,op="setHold"}
if o then d[#d+1]={type="line",key="noWait",text=o}end
if n then
d[#d+1]={type="field",key="hold.seconds",path=h(h(i,"hold"),"seconds"),
widget="slider",label=a.holdFor,value=n.seconds,min=0.5,max=60,softMax=20,step=0.5,
unit="s"}
end
local l=B[j]and B[j][f.id]
local m={}
if l and c.at(g,l)then
m[1]={type="link",key="back",label=a.backTo..c.title(j,l),op="open",
args={key=l}}
end

local l={}
for e,d in ipairs(e.pointersTo(k.rec,f.id))do
local d=d.path:match("^(sources%[%d+%]%.layers%[%d+%]%.looks%[%d+%])")
local b=d and c.keyOfPath(g,b.pathList(d))
if b then l[#l+1]={type="link",key="used:"..b,label=a.usedBy..c.title(j,b),op="open",
args={key=b}}end
end
d[#d+1]={type="link",key="addEffect",label="+ "..a.addEffect,op="open",
args={key="add:effect:"..f.id}}
local b={}
if#m>0 then b[1]={key="back",rows=m}end
b[#b+1]={key="customState",rows=d}
if#l>0 then b[#b+1]={key="used",rows=l}end
local c=q
return{title=a.customState..(f.name or f.id),on={value=f.enabled~=false,
path=h(i,"enabled")},actions={{op="remove",label=a.remove,
args={key="customState:"..f.id}}},sections=b}
end



local function g(g,h)
local f,o=h.view,h.index
local i={}
b.addRows(i,"element",f,{},{},0,nil,nil,function(a)
return a.name=="while"or a.name=="unless"or a.name=="otherwise"or a.name=="opacity"
or a.name=="onlyWhileYouKnow"
end)
local m=w(g,f,b.headingsLast(i))
if f.alert then
for a,b in ipairs(m)do
if b.key=="name"then
table.insert(m,a+1,{type="alertWhen",key="alertWhen",label="Alert when"})
break
end
end
end





local i={{type="line",key="wholeElement",text=a.wholeElement,full=true}}
local j=f.groupArrangement~=nil
local p=j
for b,a in ipairs(e.SHOWING)do
if h.rec[a]~=nil then p=false end
end
local function l(a)
local b=e.field("element",a)
local a=k(g,f,{key=a,path={a},field=b,label=b.label,widget="percent",
unit="%",depth=0,vars={}})
a.set,a.reset,a.resetTip=nil,nil,nil
return a
end
local q=l("otherwise")
local l=j and l("opacity")or{type="line",key="shownAt",text=a.full}
local r=j and math.floor((b.groupValue(g,"opacity")or 100)+0.5).."%"
if j and h.rec.opacity~=nil then
l.set,l.reset,l.resetTip=true,{"opacity"},a.backGroup..r
end
local b={type="table",key="showing",columns={a.when,a.opacity},rows={
{type="tableRow",key="row:shown",label=a.shown,cells={
{t(f,o,"while",{"while"},a.while_:lower(),nil),
t(f,o,"unless",{"unless"},a.unless:lower(),nil)},
{l}}},
{type="tableRow",key="row:otherwise",label=q.label,cells={
{{type="line",key="restOfTime",text=a.restOfTime}},{q}}}}}
if j then
if p then
b.follows="group"
else
b.set,b.follows=true,"own"
b.resetTip,b.reset=a.backGroup..c.showingWords(g)
..(h.rec.opacity~=nil and(", at "..r)or""),"showing"
end
end
i[#i+1]=b
local b=e.field("element","onlyWhileYouKnow")
local b=k(g,f,{key="onlyWhileYouKnow",path={"onlyWhileYouKnow"},field=b,
label=b.label,widget="spells",depth=0,vars={}})


if#b.entries==0 then
local c,e={},{}
for b,a in ipairs(n.youKnowFrom(f))do
local a=d.Spells.label(a)or tostring(a)
if not e[a]then
e[a]=true
c[#c+1]=a
end
end
if#c>0 then
b.widened,b.help=a.fromItsSpells:format(table.concat(c,", ")),nil
end
end
i[#i+1]=b
return{title=a.general,sections={{key="general",rows=m},
{key="showing",title=a.whenItShows,rows=i}}}
end

function c.showingWords(a)
local c=l(a)
local b=b.groupValue(a,"while")
local a={}
for d,b in ipairs(j(b))do a[#a+1]=C(c.view,c.index,b,nil)end
return#a>0 and table.concat(a," and ")or"Always"
end




local function t(d,e,c)
if c.choice then
local d={}
for a,b in ipairs(c.choice.choices or{})do d[a]={"c"..a,b.label}end
d[#d+1]={"custom",a.custom}
local a=b.quickMatch(e.rec,c.choice)
return{type="field",key=c.key,path=c.itemPath,label=c.label,help=c.help,widget="choice",
choices=d,value=a and("c"..a)or"custom",op="setQuickChoice",depth=0,form=c,shown=true}
end
local a=k(d,e.view,c)
a.help=c.help or a.help
a.op=c.op
return a
end
local function k(e,f)
local g=f.view
local c=d.Notes and d.Notes.LIST["quick-settings"]
local d={key="quick",rows={{type="note",key="card",note="quick-settings",title=c and c.title,
text=c and c.text}}}
local c={d}
for b,a in ipairs(b.quickSections(g))do
local b=d
if a.title~=nil or#c>1 then
b={key="quick:"..a.key,title=a.title,rows={}}
c[#c+1]=b
end
for c,a in ipairs(a.rows)do b.rows[#b.rows+1]=t(e,f,a)end
end
local d={}
if b.premadeOf(e)then d[1]={op="resetPremade",label=a.resetPremade,args={}}end
return{title=a.quick,actions=d,sections=c}
end


local function t(e,c,b)
local c=d.AddViews
local d={}
if b.what=="layer"and c and c.layerOffers then
for c,a in ipairs(c.layerOffers(e,b.target))do
d[#d+1]={type="link",key="kind:"..a.kind,label=a.label,note=a.note,greyed=a.greyed,
reason=a.reason,op="addLayer",args={sourceKey="source:"..b.target,kind=a.kind,layer=a.layer}}
end
end
local a=({layer=a.addLayer,effect=a.addEffect,source=a.addSource,
customState=a.addCustomState,look=a.addLook})[b.what]or""
return{title=a,add={what=b.what,target=b.target},sections={{key="add",rows=d}}}
end


function c.title(a,e)
local d=l(a)
local a=d and c.at(d.view,e)
if not a then return""end
if a.kind=="look"then return c.keysWords(d.view,d.index,a.look,a.src)end
if a.kind=="layer"then return b.layerName(d.view,a.layer)end
if a.kind=="source"then return v(d.view,a.src)end
if a.kind=="customState"then return a.cond.name or a.cond.id end
if a.kind=="event"then return c.eventWords(d.view,a.event.owner,a.event.word)end
return""
end

function c.keyOfPath(b,a)
local b=b.sources and b.sources[a[2]]
local c=b and b.layers and b.layers[a[4]]
if not(c and a[5]=="looks")then return nil end
return"look:"..b.id.."/"..c.id.."/"..a[6]
end

local function w(d,e,f)
if f==c.NEW_LOOK or f==c.NEW_STATE then
local a=f==c.NEW_LOOK and i.lookPane(e,d)or i.statePane(e,d)
a.key=f
return a
end
local b=c.at(d.view,f)
local c
if f=="quick"then c=k(e,d)
elseif not b or f=="general"then c=g(e,d)
elseif b.kind=="source"then c=P(e,d,b)
elseif b.kind=="layer"then c=ac(e,d,b)
elseif b.kind=="look"then c=Q(e,d,b)
elseif b.kind=="event"then c=T(e,d,b)
elseif b.kind=="customState"then c=X(e,d,b)
elseif b.kind=="add"then c=t(e,d,b)
elseif b.kind=="customStates"then c={title=a.customStates,sections={}}
elseif b.kind=="structure"then
c={title=a.structure,help=a.layersNote,tree=true,sections={}}
else c=g(e,d)end
c.key=(b and f~="general")and f or(f=="quick"and"quick"or"general")
return c
end

function c.pane(a,b)return y(a,"pane:"..tostring(b),w,a,b)end

function c.paneRow(a,e,b,d)
local a=c.pane(a,e)
for c,a in ipairs(a and a.sections or{})do
if d==nil or a.key==d then
for d,c in ipairs(a.rows)do
if c.key==b then return c,a end
for d,c in ipairs(c.rows or{})do
if c.key==b then return c,a end

for d,c in ipairs(c.cells or{})do
for d,c in ipairs(c)do
if c.key==b then return c,a end
end
end
end
for d,c in ipairs(c.items or{})do
for d,c in ipairs(c.rows or{})do
if c.key==b then return c,a end
end
end
end
end
end
end


local function g(d,a,e)
if a==c.NEW_LOOK or a==c.NEW_STATE then return i.entry(d,e,a)end
if a=="quick"and#b.quickRows(d.view)>0 then return a end
if a=="general"or a=="structure"or a=="customStates"then return a end
local b=c.at(d.view,a)
if b then return a end
return"general"
end

function c.entry(a,b)return y(a,"entry:"..tostring(b),g,b,a)or"general"end




local function g(a,c)
if a.newItem then return a.newItem(c)end
local b=a.setting and#a.setting==1 and a.setting[1]
if b and b.type=="integer"and#c>0 then
local a=b.default or b.min or 1
for d,c in ipairs(c)do a=math.max(a,c[b.name]or a)end
return{[b.name]=math.min(a+1,b.max or a+1)}
end

if e.isRangeFact(a)then

if#c==0 and a.first then return{atLeast=a.first}end
local b=1
for c,a in ipairs(c)do
for d,c in ipairs({"atLeast","atMost"})do b=math.max(b,a[c]or 1)end
if type(a.between)=="table"then b=math.max(b,a.between[2]or 1)end
end
return{atLeast=math.min(b+1,a.setting[1].max or 255)}
end
local b={}
for c,a in ipairs(a.setting or{})do
if a.default~=nil then b[a.name]=a.default end
end
if next(b)==nil and a.setting and a.setting[1]then
local a=a.setting[1]
b[a.name]=a.min or 1
end
return b
end

local function X(b,d,c)
b.facts=type(b.facts)=="table"and b.facts or{}
local a=b.facts[c]
if a==nil then

a={}
local b=d.default and d.default(b)
if b then
b.id=c
a[1]=b
end
end
local f={}
for b,a in ipairs(a)do if a.id then f[a.id]=true end end
local d=g(d,a)
local e=2
d.id=c
while f[d.id]do
d.id=c.."-"..e
e=e+1
end
a[#a+1]=d
b.facts[c]=a
return d
end


local function w(a,f,c,g,h,i,e,k)
local a=d.copy(a)
local d=X(a.sources[f],g,h)
local b=b.read(a,b.pathList(i))
if type(b)=="table"then
local a={}
for c,b in ipairs(j(b[e]))do a[#a+1]=b end
a[#a+1]=k and d.id or(c.."."..d.id)
b[e]=a
end
return u.displaysOver(a,c,1,x())
end






local function t(a,c)
return h(b.pathList(a),c)
end
function c.keyMenu(c,h,f)
local g=l(c)
if not g then return{sections={}}end
local h=tostring(h or"")

local i=g.rec
local c=b.pathList(h)
if c[#c-1]=="looks"and b.read(i,c)==nil then
i=d.copy(i)
local a=b.read(i,b.up(c,2))
if type(a)=="table"then
a.looks=type(a.looks)=="table"and a.looks or{}
a.looks[#a.looks+1]={}
h=b.pathString(b.extend(b.up(c,2),"looks")).."["..#a.looks.."]"
end
end
local p=u.keysFor(i,h,f,nil,x())
local n,l=g.view,g.index
local k
local c=h:match("^(sources%[%d+%])%.layers")
if c then k=b.read(n,b.pathList(c))end
local d,m={},{}
for c,b in ipairs(p)do
local e=d[b.section]
if not e then
local c
if b.section=="own"then c=a.thisSource
elseif b.section=="game"then c=a.game
elseif b.section=="customStates"then c=a.customStates
else
local a=l.sources[b.section]
c=a and v(n,a.rec)or b.section
end
e={title=c,items={},submenu=b.section~="own"and b.section~="customStates"or nil,
section=b.section}
d[b.section]=e
m[#m+1]=e
end
local d={key=b.key,label=b.label,greyed=b.status=="greyed"or nil,reason=b.line}

local c=o(l,b.key,k)
local g=c and c.what=="item"and c.item and z(c.fact,c.item,true)
if g then d.label=b.label.." ("..g..")"end

if f=="any"and not d.greyed then
if c and(c.class=="clip"or c.class=="cell"or c.class=="gate")then
d.greyed,d.reason=true,a.anyLua
end
end
e.items[#e.items+1]=d
end

if f~="any"then
for c,b in ipairs(l.sources)do
local g=(k and b.rec.id==k.id)and d.own or d[b.rec.id]
for c,d in ipairs(g and b.spec.factOrder or{})do
local c=b.spec.facts[d]
if e.isListFact(c)and(c.max or 1)>1 then
local j=type(b.rec.facts)=="table"and type(b.rec.facts[d])=="table"and b.rec.facts[d]or{}
local e={key="",label=a.newRange:format((c.label:lower():gsub("s$",""))),op="newRange",
source=b.rec.id,fact=d}
if#j>=c.max then
e.greyed,e.reason=true,(c.full or a.rangesFull):format(c.max)
elseif d=="stacks"and w(i,b.i,b.rec.id,c,d,h,f,
k~=nil and k.id==b.rec.id)then
e.greyed,e.reason=true,a.cellCap:format(u.MAX_DISPLAYS)
end
g.items[#g.items+1]=e
end
end
end
end

local c={}
for b,a in ipairs(m)do
if a.section=="own"then c[#c+1]=a end
end
for a=#l.sources,1,-1 do
local a=d[l.sources[a].rec.id]
if a then c[#c+1]=a end
end
if d.game then c[#c+1]=d.game end
local d=d.customStates or{title=a.customStates,items={},section="customStates"}

if not(f=="all"or f=="any"or f=="none")then
if#j(b.read(g.rec,t(h,f)))>0 then
d.items[#d.items+1]={key="",label=a.newCustomState,op="newCustomState"}
elseif#j(g.rec.customStates)==0 then
d.note=a.noCustomStates
end
end
c[#c+1]=d
return{sections=c}
end




local function g(b,a,d)
local c
if not b then c=a and a[1]and a[1].text or"That can't be done."end
return{ok=b and true or false,line=c,select=d}
end
local function k(a,b,c)
local a,b=p.editElement(a,b)
return g(a,b,a and c or nil)
end


local function P(c,d,a)
if#a==0 then b.setAt(c,d,nil)return end
b.setAt(c,d,#a==1 and a[1]or a)
end


local function T(a)return{["while"]=a}end





local function ab(a,c)
if not c or a.view.name~=nil then return c end
local e=a.view.sources and a.view.sources[1]
if not(e and d.Spells.firstOf(e.spells))then return c end
local d=b.nameOf(a.view)
return function(a)
c(a)
if a.name==nil and b.nameOf(a)~=d then a.name=d end
end
end


local function Y(c,a)
return function(c)
if a.kind=="look"then
local b=b.read(c,b.up(a.path,2))
if b and type(b.looks)=="table"then
table.remove(b.looks,a.k)
if#b.looks==0 then b.looks=nil end
end
elseif a.kind=="source"then e.removeId(c,a.src.id)
elseif a.kind=="layer"then e.removeId(c,a.layer.id)
elseif a.kind=="customState"then e.removeId(c,a.cond.id)
elseif a.kind=="item"then e.removeId(c,a.item,a.srcId)
elseif a.kind=="effect"then e.removeId(c,a.id)
elseif a.kind=="event"then

local d=b.read(c,a.path)
for b,a in ipairs(type(d)=="table"and type(d.effects)=="table"and d.effects or{})do
if a.id then e.removeId(c,a.id)end
end
d=b.read(c,a.path)
if type(d)=="table"then d.effects=nil end
end
end
end

local function Q(d,a)
local b=a:match("^item:(.+)$")
if b then
local a,b=b:match("^([^%.]+)%.(.+)$")
return a and{kind="item",srcId=a,item=b}
end
local b=a:match("^effect:(.+)$")
if b then return{kind="effect",id=b}end
return c.at(d.view,a)
end

local function ac(c,a)
if a.kind=="item"then
local b=c.index.sources[a.srcId]
local b=b and b.words[a.item]
return b and b.label or a.item,e.pointersTo(c.rec,a.item,a.srcId)
end
if a.kind=="event"then

local d={}
for b,a in ipairs(b.read(c.view,h(a.path,"effects"))or{})do
for b,a in ipairs(a.id and e.pointersTo(c.rec,a.id)or{})do d[#d+1]=a end
end
return nil,d
end
local a=a.kind=="source"and a.src.id or a.kind=="layer"and a.layer.id
or a.kind=="customState"and a.cond.id or a.kind=="effect"and a.id
if not a then return nil,{}end
return nil,e.pointersTo(c.rec,a)
end
local function w(a,b,c)
return(_[a]or tostring(a)).." "..(a==1 and b or c)
end

local function R(f,a)
local b,c,d,e=0,0,0,0
for f,a in ipairs(a or{})do
local a=a.path

if a:match("%.looks%[%d+%]")then b=b+1
elseif a:match("^customStates%[%d+%]")and not a:match("effects")then c=c+1
elseif a:match("effects%[%d+%]")then d=d+1
elseif a:match("^quick")then e=e+1 end
end
local a={}
if b>0 then a[#a+1]=w(b,"look","looks")end
if c>0 then a[#a+1]=w(c,"custom state","custom states")end
if d>0 then a[#a+1]=w(d,"effect","effects")end
if e>0 then a[#a+1]=w(e,"quick setting","quick settings")end
if#a==0 then return nil end
local a=#a==1 and a[1]or(table.concat(a,", ",1,#a-1).." and "..a[#a])
a=a:sub(1,1)..a:sub(2):lower()
return a.." "..((b+c+d+e)==1 and"uses"or"use").." "..f.."."
end
function c.removalLine(k,j)
local g=l(k)
if not g then return nil end
g.id=k
local e=Q(g,j)
if not e then return nil end
local i,l=ac(g,e)
if e.kind~="item"then i=c.title(k,j)end
if i==""or i==nil then i=j:match(":(.+)$")or j end

if e.kind=="event"then
local c={}
for b,a in ipairs(b.read(g.view,h(e.path,"effects"))or{})do
local b=d.Layers.effect(a.kind)
c[#c+1]=b and b.label or tostring(a.kind)
end
if#c==0 then return nil end
local c=#c==1 and c[1]or(table.concat(c,", ",1,#c-1).." and "..c[#c])
local b=R(a.them,l)
return a.eventTakes:format(c)..(b and(" "..b)or"")
end
local b=R(i,l)

local c,h,i=e.look,e.src,nil
if e.kind=="customState"then c,h,i=e.cond,nil,J end
if(e.kind=="look"or e.kind=="customState")and c then
local h=G(g,c,h,i)
if#h>0 then
local d=d.copy(g.rec)
Y(g,e)(d)
local c={}
for d,b in ipairs(Z(h,d))do
c[#c+1]=a.rangeGoes:format(f(b.e.fact.label):gsub("s$",""),
z(b.e.fact,b.item,false)or b.e.label)
end
if#c>0 then b=(b and(b.." ")or"")..table.concat(c," ")end
end
end
return b
end


function c.partRemovalLine(f,g)
local f=l(f)
local i=f and type(g)=="table"and b.read(f.rec,g.path)
local h=type(i)=="table"and i[g.list]
local h=type(h)=="table"and h[g.item]
if type(h)~="table"or not h.id then return nil end
local j=g.list
for b,a in ipairs(d.Layers.partsOf(i.kind))do
if a.key==g.list then j=d.Layers.partLabel(a.kind)end
end
local j=b.partTitle(h,g.item,j)
local k=e.pointersTo(f.rec,h.id)
if#k==0 then return nil end
local g,i,l={},{},{}
for d,h in ipairs(k)do
local e=h.path:match("^(sources%[%d+%]%.layers%[%d+%]%.looks%[%d+%])")
local d=e and b.pathList(e)
local j=d and b.read(f.view,d)
local k=d and b.read(f.view,b.up(d,2))
if j and k then
if not l[e]then
l[e]=true
g[#g+1]=a.lookOf:format(b.layerName(f.view,k),
c.keysWords(f.view,f.index,j,f.view.sources[d[2]]))
end
else
i[#i+1]=h
end
end
local b=R(j,i)
if b then g[#g+1]=(b:gsub(" uses? .*$","")):lower()end
local b=a.partInUse:format(S(g),j)
local c=d.copy(f.rec)
local function d(b)
local a=0
for c,b in ipairs(b.sources or{})do
for c,b in ipairs(type(b.layers)=="table"and b.layers or{})do
a=a+(type(b.looks)=="table"and#b.looks or 0)
end
end
return a
end
e.removeId(c,h.id)
if d(c)<d(f.rec)then b=b.." "..a.lookGoes end
return b
end


local function _(b,a,d)
local a=c.at(b.view,a)
if not a then return nil end
if a.kind=="source"then
local b=#b.view.sources
local c=math.max(1,math.min(b,b+1-d))
return function(b)
local b=b.sources
local a=table.remove(b,a.si)
table.insert(b,c,a)
end
end
if a.kind=="layer"then
local b=#a.src.layers
local c=math.max(1,math.min(b,b+1-d))
return function(b)
local b=b.sources[a.si].layers
local a=table.remove(b,a.li)
table.insert(b,c,a)
end
end
if a.kind=="look"then
local c=A(a.layer)
local b={}
for d in ipairs(a.layer.looks)do
if(c[d]~=nil)==(c[a.k]~=nil)then b[#b+1]=d end
end

local c=b[math.max(1,math.min(#b,#b+1-d))]
return function(b)
local b=b.sources[a.si].layers[a.li].looks
local a=table.remove(b,a.k)
table.insert(b,c,a)
end
end
end


local f={}


local function w(d,c,a)
if type(a)~="string"or not a:match("^#%x%x%x%x%x%x00$")then return a end
local b=b.read(d.rec,type(c)=="table"and c or b.pathList(c))
if type(b)=="string"and not b:match("^#%x%x%x%x%x%x00$")then return a end
return a:sub(1,7).."ff"
end



local function R(a,b)
if#b~=1 or a.view.groupArrangement==nil then return false end
local c=false
for e,d in ipairs(e.SHOWING)do
if a.rec[d]~=nil then return false end
if b[1]==d then c=true end
end
return c
end
local function S(c,f)
for e,a in ipairs(e.SHOWING)do f[a]=d.copy(b.groupValue(c,a))end
end
function f.set(c,d,a)
local e=type(a.path)=="table"and a.path or b.pathList(a.path)
if R(d,e)then
return k(c,function(b)
S(c,b)
b[e[1]]=a.value
end)
end
return g(b.set(c,a.path,w(d,a.path,a.value),a.copyFrom))
end
function f.reset(a,d,c)
if c.path=="showing"then
return k(a,function(a)for c,b in ipairs(e.SHOWING_ALL)do a[b]=nil end end)
end
return g(b.set(a,c.path,nil))
end

function f.setText(f,a,d)
local a=tostring(d.text or"")
local e=d.widget
local c
if e=="spells"then
local b={}
for a in a:gmatch("%d+")do b[#b+1]=tonumber(a)end
if#b==0 then return g(false,{{text="A spell's ID, not its name: 8042 for Earth Shock."}})end
c=b
elseif e=="text"then
c=a~=""and a or nil
else
if a==""then c=nil else c=tonumber(a)end
if a~=""and c==nil then return g(false)end
end
return g(b.set(f,d.path,c))
end
function f.switch(d,e,a)
local c=c.at(e.view,a.key)
local c=a.path or(c and h(c.path,"enabled"))
if not c then return g(false)end
return g(b.set(d,c,a.on and true or false))
end


local function w(b)
local c={}
for b,a in ipairs(type(b.customStates)=="table"and b.customStates or{})do
if a.name then c[a.name]=true end
end
local b=1
while c[a.customStateName:format(b)]do b=b+1 end
return a.customStateName:format(b)
end
function f.addKey(a,g,c)
local f=t(c.path,c.field)
local e=b.up(f)
local h=f[#f]
local i=b.read(g.rec,e)
if i==nil and e[#e-1]=="looks"then
local f=b.up(e,2)
local i=T(c.key)
local j="flag"
for b,a in ipairs(u.keysFor(g.rec,b.pathString(e),h,nil,x()))do
if a.key==c.key then j=a.band or"flag"end
end
local e=b.read(g.view,f)
local h=#(e.looks or{})+1
if j=="state"then
local b=A(e)
h=1
for a in ipairs(e.looks or{})do if b[a]then h=a+1 end end
end
local j=b.read(g.view,b.up(f,2))
local g=k(a,function(a)
local a=b.read(a,f)
a.looks=type(a.looks)=="table"and a.looks or{}
table.insert(a.looks,h,i)
end)

if g.ok then
local a=b.read(p.element(a),f)
local b={["while"]={c.key}}
for a,c in pairs(i)do if a~="while"then b[a]=c end end
for a,c in ipairs(a and a.looks or{})do
if d.equal(c,b)then g.select="look:"..j.id.."/"..e.id.."/"..a end
end
end
return g
end
if i==nil and e[1]=="customStates"then
local d
local a=k(a,function(a)
d=b.freeId(a,"customState")
a.customStates=type(a.customStates)=="table"and a.customStates or{}
a.customStates[#a.customStates+1]={id=d,name=w(a),[h]=c.key}
end)
if a.ok then a.select="customState:"..d end
return a
end

local d=#e==0 and R(g,f)
return k(a,function(e)
if d then S(a,e)end
local d={}
for b,a in ipairs(j(b.read(e,f)))do d[#d+1]=a end
d[#d+1]=c.key
P(e,f,d)
if h=="unless"and r[a]then
wipe(r[a])
D[a]=(D[a]or 0)+1
end
end)
end


local function T(a,c,d,b,f)
local c=G(a,c,d,f)
if#c==0 then return b end
return function(a)
b(a)
for c,b in ipairs(Z(c,a))do e.removeId(a,b.e.word,b.s.rec.id)end
end
end
function f.removeKey(h,d,c)
local e=t(c.path,c.field)


local f=b.pathList(c.path)
if c.field=="while"and f[#f-1]=="looks"then
local b=b.read(d.rec,f)
local d=type(b)=="table"and j(b["while"])or{}
if#d==1 and d[1]==c.key and b.unless==nil then
return g(false,{{text=a.lastWhile}})
end
end

local f=R(d,e)
local a=function(a)
if f then S(h,a)end
local d={}
for b,a in ipairs(j(b.read(a,e)))do
if a~=c.key then d[#d+1]=a end
end
P(a,e,d)
end
local c=b.pathList(c.path)
local b=c[5]=="looks"and b.read(d.view,c)
if type(b)=="table"then a=T(d,b,d.view.sources[c[2]],a)end
return k(h,a)
end
function f.addUnless(a,b,c)
r[a]=r[a]or{}
r[a][c.key]=true
D[a]=(D[a]or 0)+1
wipe(b.memo)
return{ok=true}
end

function f.addLook(i,d,e)
local a=c.at(d.view,e.layerKey)
if not a then return g(false)end
return f.addKey(i,d,{path=b.pathString(h(h(a.path,"looks"),#(a.layer.looks or{})+1)),
field="while",key=e.key})
end



function f.addSource(c,b,a)
local f=d.Sources.get(a.kind)
if not f then return g(false)end
local b=d.copy(a.source or{kind=a.kind})
b.kind=a.kind
if a.spells then b.spells=a.spells end
local g
local a=k(c,function(c)
c.sources=type(c.sources)=="table"and c.sources or{}
local h={}
for a in pairs(e.keyIndex(c).ids)do h[a]=true end
local d=f.idWord
if type(d)=="function"then d=d(b)end
b.id=e.partId(d or a.kind,h)
g=b.id


c.sources[#c.sources+1]=b
end)
if a.ok then a.select="source:"..g end
return a
end
function f.addLayer(f,a,e)
local a=c.at(a.view,e.sourceKey)
if not a then return g(false)end
local c
local b=k(f,function(f)
local a=f.sources[a.si]
a.layers=type(a.layers)=="table"and a.layers or{}
c=b.freeId(f,e.kind)
local b=d.copy(e.layer or{})
b.kind,b.id=e.kind,c
a.layers[#a.layers+1]=b
end)
if b.ok then b.select="layer:"..a.src.id.."/"..c end
return b
end
function f.addEffect(c,e,a)
local e=L(e.view,a.owner,a.event)
if not e then return g(false)end
local g
local b=k(c,function(f)
local c=b.read(f,e.path)
if type(c)~="table"then
b.setAt(f,e.path,{})
c=b.read(f,e.path)
end
c.effects=type(c.effects)=="table"and c.effects or{}
g=b.freeId(f,a.kind)
local b=d.copy(a.effect or{})
b.kind,b.id=a.kind,g
c.effects[#c.effects+1]=b
end)
if b.ok then b.select="event:"..a.owner.."/"..a.event end
return b
end

function f.newCustomState(i,f,d)
local l=t(d.path,d.field)
local m=b.up(l)
local n={}
for b,a in ipairs(j(b.read(f.rec,l)))do n[#n+1]=a end
local h

local d=b.pathString(l):match("^(sources%[%d+%])%.layers")
local j=d and b.read(f.rec,b.pathList(d))
local d={}
for b,a in ipairs(n)do
local b,c=e.splitKey(a)
if not c and j and f.index.sources[j.id]and f.index.sources[j.id].words[b]then
d[#d+1]=j.id.."."..b
else
d[#d+1]=a
end
end
local c=m[#m-1]=="looks"and c.keyOfPath(f.view,m)or nil
if#d==0 then return g(false,{{text=a.customStateFirst}})end
local a=k(i,function(a)
h=b.freeId(a,"customState")
a.customStates=type(a.customStates)=="table"and a.customStates or{}
a.customStates[#a.customStates+1]={id=h,name=w(a),all=#d==1 and d[1]or d}
P(a,l,{h})
end)
if a.ok then
a.select="customState:"..h
if c then
B[i]=B[i]or{}
B[i][h]=c
end
end
return a
end
function f.addCustomState(d,c,a)
return f.addKey(d,c,{path=b.pathString({"customStates",#(c.rec.customStates or{})+1}),field="all",
key=a.key or(a.keys and a.keys[1])})
end
function f.move(c,a,b)
local b=_(a,b.key,b.index)
if not b then return g(false)end
return k(c,ab(a,b))
end

function f.rename(f,c,d)
local a=Q(c,d.key or"")
if not a then return g(false)end
local d=tostring(d.name or""):match("^%s*(.-)%s*$")
d=d~=""and d or nil
if a.kind=="item"then
local c=c.index.sources[a.srcId]
local e
for d,b in ipairs(c and c.spec.factOrder or{})do
for d,f in ipairs(type(c.rec.facts)=="table"and type(c.rec.facts[b])=="table"and c.rec.facts[b]or{})do
if f.id==a.item then e={"sources",c.i,"facts",b,d,"name"}end
end
end
return e and g(b.set(f,e,d))or g(false)
end
if a.kind~="layer"and a.kind~="source"then return g(false)end
return g(b.set(f,h(a.path,"name"),d))
end
function f.remove(e,c,a)
local a=Q(c,a.key)
if not a then return g(false)end
local d
if a.kind=="look"then d="layer:"..a.src.id.."/"..a.layer.id
elseif a.kind=="layer"then d="source:"..a.src.id
elseif a.kind=="source"or a.kind=="customState"then d="general"end
local b=Y(c,a)
if a.kind=="look"then b=T(c,a.look,a.src,b)
elseif a.kind=="customState"then b=T(c,a.cond,nil,b,J)end
return k(e,b,d)
end


function f.newRange(d,c,a)
local h=f.addItem(d,c,{source=a.source,fact=a.fact})
if not h.ok then return h end
c=l(d)
local h=c and c.index.sources[a.source]
local h=h and type(h.rec.facts)=="table"and h.rec.facts[a.fact]
local h=type(h)=="table"and h[#h]
if not h then return g(false)end
local b=b.pathList(a.path)
local b=b[1]=="sources"and b[3]=="layers"and c.view.sources[b[2]]
local b=b and b.id==a.source and h.id or(a.source.."."..h.id)
local b=f.addKey(d,c,{path=a.path,field=a.field,key=b})
if not b.ok then k(d,function(b)e.removeId(b,h.id,a.source)end)end
return b
end

function f.addItem(c,b,a)
local b,d=E(b.view,a.source)
local b=b and e.variantOf(b)
local b=b and b.facts[a.fact]
if not b then return g(false)end
return k(c,function(c)X(c.sources[d],b,a.fact)end)
end


s={}

function s.setRule(e,f)
local c=f.path
return function(a)
local d=b.read(a,c)
if type(d)~="table"then
b.setAt(a,c,{})
d=b.read(a,c)
end
local a
local g=b.read(e.view,c)
for d,b in ipairs(e.index.sources)do
if b.i==c[2]then a=b.spec.facts[c[4]]end
end
local b
for c,a in ipairs(a and a.setting or{})do
if d[a.name]~=nil then b=d[a.name]end
d[a.name]=nil
end

for c,a in ipairs(b==nil and type(g)=="table"and a and a.setting or{})do
if b==nil then b=g[a.name]end
end
local b=type(b)=="table"and b[1]or b or 2
for c,a in ipairs(a and a.setting or{})do
if a.name==f.value then
local c=a.type=="list"and a.item and a.item.max or a.max or 255
d[a.name]=a.type=="list"and{math.min(b,c),math.min(b+1,c)}or math.min(b,c)
end
end
end
end

function s.setHold(c,a)
local c=a.path
return function(d)
local e=b.read(d,c)
if a.value==nil or a.value==b.NONE then
b.setAt(d,c,nil)
return
end
b.setAt(d,c,{after=a.value,seconds=type(e)=="table"and e.seconds or 5})
end
end

function s.setQuickLook(c,a)
return function(c)b.setLookField(c,a.path,a.value)end
end

function s.setQuickPointer(c,a)
return function(c)b.writeQuickPointer(c,a.path,a.value)end
end

function s.setQuickChoice(c,a)
return function(d)
local c=b.read(d,a.path)
local a=type(a.value)=="string"and tonumber(a.value:match("^c(%d+)$"))or nil
local a=type(c)=="table"and a and type(c.choices)=="table"and c.choices[a]or nil
for c,a in ipairs(a and a.writes or{})do b.applyQuickWrite(d,a)end
end
end
for a,b in pairs(s)do
f[a]=function(a,c,d)return k(a,b(c,d))end
end

function W(d,c,e)
local a=l(d)
if not a then return false end
a.dry=a.dry or{}
local b=c.op.."|"..b.pathString(c.path).."|"..tostring(e)
if a.dry[b]==nil then a.dry[b]=p.wouldEditElement(d,s[c.op](a,{path=c.path,value=e}))end
return a.dry[b]
end

function f.pictureFrom(c,d,a)
if type(a.icon)~="number"then return g(false)end
return g(b.set(c,a.path,a.icon))
end


function f.addSpell(f,h,a)
if type(a.spell)~="number"then return g(false)end
local c,e={},false
for d,b in ipairs(d.Spells.listOf(b.read(h.view,a.path)))do
e=e or b==a.spell
c[d]=b
end
if not e then c[#c+1]=a.spell end
return k(f,function(e)
b.setAt(e,a.path,c)
if not a.exact then return end
local f=b.extend(b.up(a.path),"exact")
local c={}
for a,b in ipairs(d.Spells.listOf(b.read(e,f)))do c[a]=b end
for c,b in ipairs(c)do
if b==a.spell then return end
end
c[#c+1]=a.spell
b.setAt(e,f,c)
end)
end

function f.removeSpell(e,f,c)
local a={}
for d,b in ipairs(d.Spells.listOf(b.read(f.view,c.path)))do
if b~=c.spell then a[#a+1]=b end
end

return k(e,b.writer(c.path,#a>0 and a or nil))
end
function f.addPart(c,d,a)
local a,b=b.addPart(c,a.path,a.list)
return g(a,b)
end
function f.removePart(c,d,a)return g(b.removePart(c,a.path,a.list,a.item))end
function f.duplicatePart(c,d,a)return g(b.duplicatePart(c,a.path,a.list,a.item))end
function f.renamePart(c,d,a)return g(b.renamePart(c,a.path,a.list,a.item,a.name))end
function f.resetPremade(d,e,a)
local a=a.key and c.at(e.view,a.key)
local a=a and(a.layer and a.layer.id or a.src and a.src.id)or nil
return g(b.resetToPremade(d,a))
end

function c.act(a,c,d)
local b=l(a)
local c=f[c]
if not(b and c)then return{ok=false,line="That can't be done."}end
local a=c(a,b,d or{})
if type(a)~="table"then a=g(a)end

return a
end
c["do"]=c.act


function c.ask(g,f,e)
e=e or{}
if f=="remove"or f=="removePart"then
local a
if f=="remove"then a=c.removalLine(g,e.key)else a=c.partRemovalLine(g,e)end
return{ok=true,line=a,asks=a~=nil}
end
local c=l(g)
if not c then return{ok=false}end

if f=="removeSpell"then
local b=d.Spells.listOf(b.read(c.view,e.path))
local c=d.Spells.label(e.spell)or tostring(e.spell)
local a=(#b<=1 and a.lastSpell or a.removeSpell):format(c)
return{ok=true,line=a,asks=true}
end
if f=="set"then
local a=b.accepts(g,e.path,e.value)
return{ok=a}
end
return{ok=true}
end






function c.pick(e,b,d)
local a=c.picks(e)
local c,b,f=tostring(b):match("^(%a+):([^/]+)/?(.*)$")
if c=="state"and a[b]then a[b].state=f
elseif c=="fact"and a[b]then a[b].facts[f]=d and true or nil
elseif c=="game"then a.game[b]=d and true or nil
elseif c=="held"then a.held[b]=d and true or nil end
local b=q[e]
if b then
b.holds,b.why=nil,nil
wipe(b.memo)
end
return a
end


function c.lookPicks(d,a)
local f=l(d)
local b=f and c.at(f.view,a)
if not(b and b.kind=="look")then return{}end
local a,e={},{}
local function g(c,d)
local b,c=o(f.index,c,b.src)
if not b then return end
if b.what=="game"then a[#a+1]={chip="game:"..b.word,on=d}
elseif b.what=="customState"then a[#a+1]={chip="held:"..b.word,on=d}
elseif c and b.what=="state"then
if d then a[#a+1]={chip="state:"..c.rec.id.."/"..b.word,on=true}
else
e[c.rec.id]=e[c.rec.id]or{s=c,words={}}
e[c.rec.id].words[b.word]=true
end
elseif c and(b.what=="fact"or b.what=="item")then
local e=d and aa(c,b.within)
if e then table.insert(a,1,{chip="state:"..c.rec.id.."/"..e,on=true})end
a[#a+1]={chip="fact:"..c.rec.id.."/"..b.word,on=d}
end
end
for b,a in ipairs(j(b.look["while"]))do g(a,true)end
for b,a in ipairs(j(b.look.unless))do g(a,false)end


local d=c.picks(d)
for b,c in pairs(e)do
local d=d[b]and d[b].state
for c,a in ipairs(a)do
local a,c=a.chip:match("^state:([^/]+)/(.+)$")
if a==b then d=c end
end
if c.words[d]then
for e,d in ipairs(c.s.spec.stateOrder or{})do
if not c.words[d]then
a[#a+1]={chip="state:"..b.."/"..d,on=true}
break
end
end
end
end
return a
end
function f.showInPreview(a,d,b)
for d,b in ipairs(c.lookPicks(a,b.key))do c.pick(a,b.chip,b.on)end
return{ok=true}
end


local function s(a,c)
local b={}
e.eachRef(a,function(d,e,f,g,h,a)
if d~="keys"then return end
local a=a.layer and a.source and c.sources[a.source.id]
b[n.canonical(e,a)]=true
end)
return b
end

local function h(a,b)return c.chipsFor(a.view,c.picks(b),I(b,a),a.index)end
function c.chips(a)
local b=l(a)
if not b then return{sources={},game={},customStates={},events={}}end
return y(a,"chips",h,a)
end

function c.chipsFor(d,b,h,g)
g=g or e.keyIndex(d)
h=h or n.holds(d,b)
b.game,b.held=b.game or{},b.held or{}
local i=s(d,g)
local f={sources={},game={},customStates={}}
for a=#(d.sources or{}),1,-1 do
local a=d.sources[a]
local g=g.sources[a.id]
if g then
local d={id=a.id,label=v(d,a),states={},facts={},
unlearned=not c.learned(a)or nil}
b[a.id]=b[a.id]or{state=(g.spec.stateOrder or{})[1],facts={}}
b[a.id].facts=b[a.id].facts or{}
for e,c in ipairs(g.spec.stateOrder or{})do
local e=g.spec.offersState
if not e or e(a,c)then
d.states[#d.states+1]={key="state:"..a.id.."/"..c,label=g.words[c].label,
picked=b[a.id]and b[a.id].state==c or nil}
end
end

local j={}
for b,a in ipairs(a.layers or{})do
for b,a in ipairs(M(a,g.spec))do j[a]=true end
end

local c={}
for d,b in ipairs(g.spec.factOrder)do
if e.isListFact(g.spec.facts[b])then
local a=type(a.facts)=="table"and a.facts[b]or{}
for b,a in ipairs(type(a)=="table"and a or{})do
if g.words[a.id]then c[#c+1]=g.words[a.id]end
end
elseif g.words[b]then
c[#c+1]=g.words[b]
end
end
for e,c in ipairs(c)do
if(c.what=="fact"or c.what=="item")and c.on~=false then
local e=a.id.."."..c.word
local f=c.item and c.item.events or(type(a.facts)=="table"and type(a.facts[c.word])=="table"
and a.facts[c.word].events)
local g=false
for b,a in pairs(type(f)=="table"and f or{})do
if type(a)=="table"and type(a.effects)=="table"and#a.effects>0 then g=true end
end
if i[e]or j[c.word]or g then
d.facts[#d.facts+1]={key="fact:"..a.id.."/"..c.word,label=c.label,
picked=b[a.id]and b[a.id].facts[c.word]or nil,lit=h(e)or nil}
end
end
end
f.sources[#f.sources+1]=d
end
end
for c,a in ipairs(e.gameFacts())do
if i["game."..a]then
f.game[#f.game+1]={key="game:"..a,label=e.gameFactSpec(a).label,picked=b.game[a]or nil}
end
end
for c,a in ipairs(d.customStates or{})do
f.customStates[#f.customStates+1]={key="held:"..a.id,label=a.name or a.id,
picked=b.held[a.id]or nil}
end

f.events={}
for a=#(d.sources or{}),1,-1 do
local b=d.sources[a]
local a=e.variantOf(b)
if a then
for e,a in ipairs(F(d,b,a))do
local e,g,h=c.playArgs(a.owner,a.word)
f.events[#f.events+1]={key="event:"..a.owner.."/"..a.word,source=b.id,owner=a.owner,
word=a.word,label=c.eventWords(d,a.owner,a.word),play={source=e,event=g,at=h}}
end
end
end
for a,b in ipairs(d.customStates or{})do
for e,a in ipairs(F(d,nil,nil,b))do
f.events[#f.events+1]={key="event:"..a.owner.."/"..a.word,owner=a.owner,word=a.word,
label=(b.name or b.id)..": "..c.eventWords(d,a.owner,a.word),
play={event=a.word,at={customState=b.id}}}
end
end
return f
end

function c.previewArgs(a)
return c.view(a),c.picks(a)
end











a.newLookOn="New look on %s"
a.newLookIntro="Pick when this look applies and, if you like, a first change. Nothing is saved until you press Make look."
a.newStateIntro="A custom state holds when the keys you pick hold. Any look on this element can then use it as a key."
a.startWith,a.nothingYet,a.hiddenStart="Start with","Nothing yet","Hidden"
a.makeLook,a.makeCustomState,a.cancel="Make look","Make custom state","Cancel"
a.pickFirst,a.onlyWhile,a.alreadyIn="Pick at least one key first.","Holds only while %s.","Already in %s."
a.holdsWhile,a.keys,a.useOn,a.noLayer="It holds while","Keys","Use it in a look on","None"
a.afterEvent="For a time after an event"


a.anyLine="It holds when at least one of the keys holds. Keys the game shows itself in combat, such as a buff's"
.." or a debuff's, can't be used this way, so they aren't listed."
a.afterLine="It holds for the number of seconds you set after the event you pick. Keys the game shows itself in"
.." combat can't be used with it."
a.drawnOne="%s is shown by the game itself in combat, so %s can't use it."
a.drawnMany="%s are shown by the game itself in combat, so %s can't use them."

a.anyUses,a.afterUses='"'..a.any..'"','"'..a.afterEvent..'"'
a.wayRefused="The keys picked can't hold this way."
a.cantMake="These keys can't make it as they are: change a key or the way it holds."
a.noEvents="None of this element's sources has an event it can wait for."
a.holdsSentence,a.holdsAfter="Holds while %s","Holds for %s s after %s"
local D={{"all",a.all},{"any",a.any,a.anyLine},{"none",a.none},
{"after",a.afterEvent,a.afterLine}}


local function s(a)
if#a==0 then return nil end
if#a==1 then return a[1]end
local b={}
for a,c in ipairs(a)do b[a]=c end
return b
end
local function h(a,b)return m[a]and m[a][b]end

function i.redraft(a)
local a=q[a]
if not a then return end
a.memo["pane:"..c.NEW_LOOK],a.memo["entry:"..c.NEW_LOOK]=nil,nil
a.memo["pane:"..c.NEW_STATE],a.memo["entry:"..c.NEW_STATE]=nil,nil
end


local function t(b,c,d,e,...)
local a=b.work
if not(a and a.c==c and a.sig==d)then
a=e(c,b,...)
a.c,a.sig=c,d
b.work=a
end
return a
end

local function n(b,a)
local a=a and c.at(b.view,a.layer)
return a and a.kind=="layer"and a or nil
end


local function q(a,c)
for b=#a,1,-1 do
if not c(a[b])then table.remove(a,b)end
end
end
function i.prune(b,a)
local a=m[a]
if not a or a.pruned==b then return end
a.pruned=b
local e=b.index
local d=a.look
local f=d and n(b,d)
if d and not f then a.look=nil end
if f then
local function a(a)return o(e,a,f.src)~=nil end
q(d["while"],a)
q(d.unless,a)
end
local a=a.state
if a then
q(a.keys,function(a)return o(e,a,nil)~=nil end)
local c=a.useOn and c.at(b.view,a.useOn)
if not(c and c.kind=="layer")then a.useOn=nil end
local c
for d,b in ipairs(H(b.view,e))do c=c or b[1]==a.after end
if not c then a.after=nil end
end
end
function i.entry(d,a,b)
i.prune(d,a)
if b==c.NEW_LOOK then return n(d,h(a,"look"))and b or"general"end
return h(a,"state")and b or"general"
end

function c.draftBack(b,a)
local b=h(b,"look")
if a==c.NEW_LOOK and b then return b.layer end
if a==c.NEW_STATE then return"customStates"end
return"general"
end

function c.closeDrafts()wipe(m)end



local function E(b,c,d)
local a={}
for c,b in ipairs(u.keysFor(b,c,d,nil,x()))do a[b.key]=b end
return a
end

local function F(a)return a~=nil and(a.class=="clip"or a.class=="cell"or a.class=="gate")end
local function G(b,c)
return(#b==1 and a.drawnOne or a.drawnMany):format(table.concat(b,", "),c)
end





local function I(b,j,c,i,k,p,l)
local f,g=b.view,b.index

local m,n={},{}
for a in pairs(i)do
local a,b=o(g,a,c)
if a and b and a.what=="state"then m[b.rec.id]=a end
if a and b and a.within then n[b.rec.id]=a end
end
local b={}
local function h(d,h,f)
local j,i=j[h],i[h]
if k and k[h]and not i then
d.chips[#d.chips+1]={key=h,label=f,greyed=true}
d.said(f,a.alreadyIn:format(p))
return
end
if not(i or j)then return end
local b,g=o(g,h,c)
local c=b and b.what=="item"and b.item and z(b.fact,b.item,true)
if c then f=f.." ("..c..")"end
local c=not i and j.status=="greyed"and j.line or nil
local j,k=c and g and m[g.rec.id],c and g and n[g.rec.id]
if c and l and F(b)then c=false
elseif j and b.what=="state"then c=a.cantHoldWith..j.label.."."
elseif k and b.what=="state"and not e.holdsWithin(k.within,b.word)then
c=a.cantHoldWith..k.label.."."
elseif j and b.within and not e.holdsWithin(b.within,j.word)and U(g,b.within)then
c=a.onlyWhile:format(U(g,b.within))
end
d.chips[#d.chips+1]={key=h,label=f,on=i or nil,greyed=c~=nil or nil}
if c==false then d.drawn[#d.drawn+1]=f elseif c then d.said(f,c)end
end

local function i(a,b,c)
local a={key=a,title=b,icon=c,chips={},lines={},drawn={}}
local b,c={},{}
function a.said(d,a)
if not b[a]then b[a],c[#c+1]={},a end
table.insert(b[a],d)
end
function a.finish()
for d,c in ipairs(c)do a.lines[#a.lines+1]=table.concat(b[c],", ")..": "..c end
if#a.drawn>0 then a.lines[#a.lines+1]=G(a.drawn,l)end
a.said,a.finish,a.drawn=nil,nil,nil
return a
end
return a
end
local function d(d)
local e=c~=nil and d.rec.id==c.id
local c=v(f,d.rec)
local c=i(d.rec.id,e and(a.thisSource..": "..c)or c,N(d.rec))
for b,a in ipairs(d.order)do
if a.what~="event"then h(c,e and a.word or(d.rec.id.."."..a.word),a.label or a.word)end
end
if#c.chips>0 then b[#b+1]=c.finish()end
end
local c=c and g.sources[c.id]
if c then d(c)end
for a=#g.sources,1,-1 do
if g.sources[a]~=c then d(g.sources[a])end
end
local c=i("game",a.game)
for b,a in ipairs(e.gameFacts())do h(c,"game."..a,e.gameFactSpec(a).label)end
if#c.chips>0 then b[#b+1]=c.finish()end
local c=i("customStates",a.customStates)
for b,a in ipairs(f.customStates or{})do h(c,a.id,a.name or a.id)end
if#(f.customStates or{})==0 then c.note=a.noCustomStates end
b[#b+1]=c.finish()
return b
end

local function y(a,b)return u.refusedAt(a,b,x())end
local function z(b)
local a={}
for c,b in ipairs(b)do a[b]=true end
return a
end



local function q(g,c)
local h="look:"..g.layer.kind
local i={}
local function f(b,a,d,e)
if c[a]then i[#i+1]={key=b,label=e,path=a,value=d}end
end
local c=e.field(h,"shown")
if c then f("hidden","shown",false,a.hiddenStart)end
c=e.field(h,"opacity")
if c then f("opacity","opacity",40,c.label.." 40%")end
c=e.field(h,"desaturated")
if c then f("desaturated","desaturated",true,c.label)end
for c,a in ipairs(type(g.layer.glows)=="table"and g.layer.glows or{})do
f("glow:"..a.id,"glows."..a.id..".shown",true,b.partTitle(a,c,d.Layers.partLabel("glow")))
end
return i
end




local function J(a,c,e)
local d=d.copy(a.rec)
local a=b.read(d,e.path)
a.looks=type(a.looks)=="table"and a.looks or{}
a.looks[#a.looks+1]={["while"]=s(c["while"]),unless=s(c.unless)}
local b=b.pathString(e.path)
local f={}
for b,a in ipairs(u.lookFields(d,b,#a.looks,x()))do
if a.status=="offered"then f[a.path]=true end
end
local a=b..".looks["..#a.looks.."]"
return{trial=d,path=a,starts=q(e,f),
refused=#c["while"]+#c.unless>0 and y(d,a)}
end
local q
local function u(f,e,d,h,c)
local b=d.status
local g=q(d)
if not(b and b.c==e and b.sig==g)then
b={c=e,sig=g}
d.status=b
end
b[c]=b[c]or E(f.trial,f.path,c)
local f=c=="while"and"unless"or"while"
local a=I(e,b[c],h.src,z(d[c]),z(d[f]),
c=="while"and a.unless or a.while_)

for b,a in ipairs(a)do
if#a.lines>0 then a.lines={}end
end
return a
end

function q(a)
return a.layer.."|"..table.concat(a["while"],",").."|"..table.concat(a.unless,",")
end

local function x(c,a)
local d={["while"]=s(c["while"]),unless=s(c.unless)}
for e,a in ipairs(a.starts)do
if a.key==c.start then
b.setAt(d,b.pathList(a.path),a.value)
return d,a.key
end
end
return d,nil
end


function i.lookPane(c,d)
i.prune(d,c)
local c=h(c,"look")
local e=n(d,c)
local l,v=d.view,d.index
local m={type="line",key="intro",text=a.newLookIntro,full=true}
local j={type="line",key="sentence",text="",full=true,strong=true,shown=false}
local g={type="keyChips",key="while",op="draftKey",args={draft="look",field="while"},
groups={}}
local n={type="link",key="addUnless",label=a.addUnless,op="draftUnless",args={}}
local o={type="heading",key="unlessHead",label=a.unless,depth=0,shown=false}
local k={type="keyChips",key="unless",op="draftKey",args={draft="look",field="unless"},
groups={},shown=false}
local p={type="keyChips",key="start",op="draftStart",args={},
groups={{key="start",chips={},lines={}}}}
local h={type="line",key="need",text=a.pickFirst,full=true}
local i,r={},a.newLookOn:format("")
if e then
local f=t(c,d,q(c),J,e)
local t,q=x(c,f)
local s=b.layerName(l,e.layer)
r=a.newLookOn:format(s)
i[1]={key="layer",label=a.layer,name=s,open=c.layer}
local i=#c["while"]+#c.unless>0
j.text=i and O(l,v,e.layer,t,e.src,b.read(d.rec,e.path))or""
j.shown,m.shown,h.shown=i,not i,not i
g.groups=u(f,d,c,e,"while")

g.groups[#g.groups].link={label=a.newCustomState,op="draftStateFromLook",args={}}
if c.unlessAsked or#c.unless>0 then
k.groups,k.shown,o.shown,n.shown=u(f,d,c,e,"unless"),true,
true,false
end
if f.refused then h.text,h.shown=a.cantMake,true end
local b=p.groups[1].chips
for c,a in ipairs(f.starts)do b[#b+1]={key=a.key,label=a.label,on=q==a.key or nil}end
b[#b+1]={key="none",label=a.nothingYet,on=q==nil or nil}
end
return{title=r,intro=i,sections={
{key="sentence",rows={m,j}},
{key="when",title=a.when,group=true,rows={g,n,o,k}},
{key="start",title=a.startWith,group=true,rows={p}},
{key="make",rows={h,{type="button",key="make",label=a.makeLook,op="makeLook",args={}},
{type="link",key="cancel",label=a.cancel,op="cancelDraft",args={draft="look"}}}}}}
end


local function u(b,a,c)
local b={id=c,name=a.name or w(b),[a.mode=="after"and"all"or a.mode]=s(a.keys)}
if a.mode=="after"and a.after then b.hold={after=a.after,seconds=a.seconds}end
return b
end
local function s(a)
return a.mode.."|"..tostring(a.after).."|"..table.concat(a.keys,",")
end


local function L(f,e)
local c=d.copy(f.rec)
c.customStates=type(c.customStates)=="table"and c.customStates or{}
local j=b.freeId(c,"customState")
local b=u(c,e,j)
c.customStates[#c.customStates+1]=b
local h="customStates["..#c.customStates.."]"
local g=e.mode=="after"and"all"or e.mode
local i=e.mode=="any"and a.anyUses or e.mode=="after"and a.afterUses or nil
local d=H(f.view,f.index)
local i={cond=b,events=d,
groups=I(f,E(c,h,g),nil,z(e.keys),nil,nil,i),ways={}}
if#e.keys>0 then
i.refused=y(c,h)
local g={}
for b,a in ipairs(e.keys)do
local b=o(f.index,a,nil)
if F(b)then g[#g+1]=C(f.view,f.index,a,nil)end
end
for f,b in ipairs(D)do
if b[1]~=e.mode and not(b[1]=="after"and#d==0)then
local d={mode=b[1],keys=e.keys,after=d[1]and d[1][1],seconds=e.seconds}
c.customStates[#c.customStates]=u(c,d,j)
if y(c,h)then
local c=b[1]=="any"and a.anyUses or b[1]=="after"and a.afterUses
i.ways[b[1]]=c and#g>0 and G(g,c)or a.wayRefused
end
end
end
end
return i
end



local y={mode="all",keys={},seconds=5}
function i.statePane(j,g)
i.prune(g,j)
local c=h(j,"state")or y
local f,n=g.view,g.index
local d=h(j,"state")and t(c,g,s(c),L)or{cond={},groups={},events={},
ways={}}
local i=c.mode=="after"
local k=e.field("customState","name")

local l={}
for e,b in ipairs(D)do
local a=b[1]=="after"and#d.events==0 and h(j,"state")~=nil and a.noEvents
or d.ways[b[1]]
l[#l+1]={key=b[1],chips={{key=b[1],label=b[2],on=c.mode==b[1]or nil,
greyed=a and true or nil}},lines={a or b[3]or nil}}
end

local h,e={{b.NONE,a.noLayer}},{}
for c,a in ipairs(f.sources or{})do
for c,a in ipairs(a.layers or{})do
local a=b.layerName(f,a)
e[a]=(e[a]or 0)+1
end
end
for a,c in ipairs(f.sources or{})do
for a,d in ipairs(c.layers or{})do
local a=b.layerName(f,d)
if e[a]>1 then a=a.." ("..v(f,c)..")"end
h[#h+1]={"layer:"..c.id.."/"..d.id,a}
end
end
local m={}
for a,b in ipairs(d.events)do m[a]=b end
local j
for b,a in ipairs(d.events)do
if a[1]==c.after then j=a[2]end
end
local f=V(f,n,d.cond)
local e=""
if i and j then
e=a.holdsAfter:format(tostring(c.seconds),j)..(f and(", while "..f)or"")
elseif f and not i then
e=a.holdsSentence:format(f)
end
return{title=a.newCustomState:gsub("…$",""),sections={
{key="name",rows={{type="line",key="intro",text=a.newStateIntro,full=true},
{type="field",key="name",widget="text",label=k and k.label or"Name",
path={"draft","name"},textOp="draftSet",text=c.name or"",hint=w(g.rec),
maxBytes=k and k.max or 64}}},
{key="holds",title=a.holdsWhile,group=true,rows={
{type="keyChips",key="ways",op="draftMode",args={},groups=l}}},
{key="keys",title=a.keys,group=true,rows={
{type="keyChips",key="keys",op="draftKey",args={draft="state"},groups=d.groups},
{type="field",key="after",widget="choice",label=a.after,path={"draft","after"},
op="draftSet",choices=m,value=c.after or b.NONE,shown=i},
{type="field",key="seconds",widget="slider",label=a.holdFor,path={"draft","seconds"},
op="draftSet",value=c.seconds,min=0.5,max=60,softMax=20,step=0.5,unit="s",shown=i}}},
{key="make",rows={{type="line",key="sentence",text=e,full=true,strong=true,
shown=e~=""},
{type="field",key="useOn",widget="choice",label=a.useOn,path={"draft","useOn"},
op="draftSet",choices=h,value=c.useOn or b.NONE},
{type="line",key="need",text=d.refused and a.cantMake or a.pickFirst,full=true,
shown=e==""or d.refused or false},
{type="button",key="make",label=a.makeCustomState,op="makeCustomState",args={}},
{type="link",key="cancel",label=a.cancel,op="cancelDraft",args={draft="state"}}}}}}
end


function f.draftLook(a,d,b)
local d=c.at(d.view,b.key)
if not(d and d.kind=="layer")then return g(false)end
m[a]=m[a]or{}
m[a].look={layer=b.key,["while"]={},unless={}}
i.redraft(a)
return{ok=true,select=c.NEW_LOOK}
end
function f.draftCustomState(a,b,d)
m[a]=m[a]or{}
m[a].state={mode="all",keys={},seconds=5}
i.redraft(a)
return{ok=true,select=c.NEW_STATE}
end

function f.draftStateFromLook(a,b,d)
i.prune(b,a)
local d=h(a,"look")
local f=n(b,d)
if not f then return g(false)end
local g=b.index.sources[f.src.id]
local b={}
for c,a in ipairs(d["while"])do
local c,d=e.splitKey(a)
b[#b+1]=(not d and g and g.words[c])and(f.src.id.."."..c)or a
end
m[a].state={mode="all",keys=b,seconds=5,useOn=d.layer,fromLook=true}
i.redraft(a)
return{ok=true,select=c.NEW_STATE}
end

function f.draftKey(d,b,a)
local b=h(d,a.draft)
local b=b and(a.draft=="state"and b.keys or b[a.field])
if type(b)~="table"or a.key==nil then return g(false)end
local c
for b,d in ipairs(b)do
if d==a.key then c=b end
end
if c then table.remove(b,c)else b[#b+1]=a.key end
i.redraft(d)
return{ok=true}
end
function f.draftUnless(a,b,c)
local b=h(a,"look")
if not b then return g(false)end
b.unlessAsked=true
i.redraft(a)
return{ok=true}
end
function f.draftStart(a,c,b)
local c=h(a,"look")
if not c then return g(false)end
c.start=b.key~="none"and b.key or nil
i.redraft(a)
return{ok=true}
end

function f.draftMode(c,d,b)
local a=h(c,"state")
local b=b.mode or b.key
if not(a and(b=="all"or b=="any"or b=="none"or b=="after"))then return g(false)end
a.mode=b
if a.mode=="after"and a.after==nil then
local b=H(d.view,d.index)[1]
a.after=b and b[1]
end
i.redraft(c)
return{ok=true}
end

function f.draftSet(f,a,d)
local c=h(f,"state")
local e=c and type(d.path)=="table"and d.path[2]
local a=d.value
if a==b.NONE then a=nil end
if e=="name"then
local a=tostring(d.text or a or""):match("^%s*(.-)%s*$")
c.name=a~=""and a or nil
elseif e=="seconds"and type(a)=="number"then c.seconds=a
elseif e=="after"then c.after=a
elseif e=="useOn"then c.useOn=a
else return g(false)end
i.redraft(f)
return{ok=true}
end

function f.makeLook(l,r,c)
i.prune(r,l)
local c=h(l,"look")
local f=n(r,c)
if not f then return g(false)end
if#c["while"]+#c.unless==0 then return g(false,{{text=a.pickFirst}})end
local h=x(c,t(c,r,q(c),J,f))
local g=#(f.layer.looks or{})+1
local a=#c["while"]==1 and#c.unless==0 and c["while"][1]
local a=a and not select(2,e.splitKey(a))and o(r.index,a,f.src)
if a and a.what=="state"then
local b=A(f.layer)
g=1
for a in ipairs(f.layer.looks or{})do if b[a]then g=a+1 end end
end
local a=k(l,function(a)
local a=b.read(a,f.path)
a.looks=type(a.looks)=="table"and a.looks or{}
table.insert(a.looks,math.min(g,#a.looks+1),h)
end)
if not a.ok then return a end
m[l].look=nil

local e=b.read(p.element(l),f.path)
local b
for e,a in ipairs(e and e.looks or{})do
if d.equal(j(a["while"]),c["while"])and d.equal(j(a.unless),c.unless)and b~=g then b=e end
end
a.select=b and("look:"..f.src.id.."/"..f.layer.id.."/"..b)or c.layer
return a
end


function f.makeCustomState(e,d,f)
i.prune(d,e)
local d=h(e,"state")
if not d then return g(false)end
if#d.keys==0 and not(d.mode=="after"and d.after)then return g(false,{{text=a.pickFirst}})end
local f
local a=k(e,function(a)
f=b.freeId(a,"customState")
a.customStates=type(a.customStates)=="table"and a.customStates or{}
a.customStates[#a.customStates+1]=u(a,d,f)
end)
if not a.ok then return a end
m[e].state=nil
local b=l(e)
local b=d.useOn and b and c.at(b.view,d.useOn)
if b and b.kind=="layer"then
local b=h(e,"look")
if not(b and d.fromLook and b.layer==d.useOn)then
b={layer=d.useOn,unless={}}
m[e].look=b
end
b["while"]={f}
i.redraft(e)
a.select=c.NEW_LOOK
else
a.select="customState:"..f
end
return a
end

function f.cancelDraft(e,f,d)
local a=m[e]
local b=a and a[d.draft]
if not b then return{ok=true,select="general"}end
a[d.draft]=nil
i.redraft(e)
if d.draft=="look"then return{ok=true,select=n(f,b)and b.layer or"general"}end
return{ok=true,select=b.fromLook and a.look and c.NEW_LOOK or"customStates"}
end


d.onChanged(function(b,a)
if b=="element"and a and not p.element(a)then
K[a],r[a],B[a],m[a]=nil,nil,nil,nil
end

if b=="profile"then wipe(m)end
end,"element model picks")
