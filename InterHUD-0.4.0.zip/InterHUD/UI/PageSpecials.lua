



local b,a=...
local b,e,c=a.Kit,a.Window,a.Specials


local d=28

local function g(a,b)return a.." "..b..(a==1 and""or"s")end


local f={word=a.Sources.EXPERIMENTAL.word,
tip="EXPERIMENTAL. This special is still under construction and/or is not yet fully tested."}

local function h(a)
local a=CreateFrame("Button",nil,a)
a:SetHeight(d-2)
a:EnableMouse(true)
local d=a:CreateTexture(nil,"HIGHLIGHT")
d:SetAllPoints()
b.fill(d,"white",0.05)
a.icon=a:CreateTexture(nil,"ARTWORK")
a.icon:SetSize(20,20)
a.icon:SetPoint("LEFT",4,0)
b.cropIcon(a.icon)
a.text=b.fontString(a,"label")
a.text:SetPoint("LEFT",a.icon,"RIGHT",8,0)
a.text:SetJustifyH("LEFT")
a.text:SetWordWrap(false)
a.tag=b.tag(a,14)
a.tag:SetPoint("LEFT",a.text,"RIGHT",8,0)
a.tag.say(f.word)
a.tag:SetScript("OnEnter",function(a)b.note(a,f.tip)end)
a.tag:SetScript("OnLeave",function()b.note()end)

a.tag.click=function()if a.item then e.select("special",a.item.key)end end
a.note=b.fontString(a,"dim")
a.switch=b.pillSwitch(a,function()return a.item and a.item.state=="on"end,
function(b)return a.item and c.setOn(a.item.key,b)end,"On","Switch it on or off.",nil,true)
a.switch:SetPoint("RIGHT",-8,0)
a:SetScript("OnClick",function(a)
if a.item then e.select("special",a.item.key)end
end)
return a
end

local function i(a)
local a=b.row(a.content,d)
local e,f={},0
a.empty=b.fontString(a,"small")
b.tint(a.empty,"help")
a.empty:SetPoint("TOPLEFT",4,-6)
a.empty:SetText("No specials yet.")
a.height=function()return math.max(f,1)*d end
a.rows=e
return b.finishRow(a,function()
local c=c.list()
f=#c
a.empty:SetShown(f==0)
for f,c in ipairs(c)do
local a=e[f]or h(a)
e[f]=a
a.item=c
a:ClearAllPoints()
a:SetPoint("TOPLEFT",0,-(f-1)*d)
a:SetPoint("TOPRIGHT",0,-(f-1)*d)
a.icon:SetTexture(c.icon or b.art("iconUnknown"))
local d=c.state~="on"
a.icon:SetDesaturated(d)
a.text:SetText(c.label)
b.tint(a.text,d and"off"or"text")
a.tag:SetShown(c.experimental==true)
a.note:ClearAllPoints()
a.note:SetPoint("LEFT",c.experimental and a.tag or a.text,"RIGHT",10,0)
a.note:SetText(c.state=="never"and"Not for this class"or"")
a.switch:SetShown(c.state~="never")
a.switch:show(c.state=="on")
a:Show()
end
for a=f+1,#e do e[a]:Hide()end
end)
end

b.registerPage("specials",{build=function(a)
a:plainTitle({title="Specials",icon=e.SPECIALS_ICON,
note=function()return g(#c.list(),"special")..". Click one to open its settings page."end})
a:block({key="list"})
a:addRow(i(a))
end})



local function g(b)
for c,a in ipairs(c.list())do
if a.key==b then return a.state end
end
end
for a,d in ipairs(c.keys())do
local a=c.get(d)

b.setPageBack(a.page or d,{text="Back to Specials",click=function()e.select("specials","specials")end})
if a.experimental then b.setPageTag(a.page or d,f)end
if a.bannerPage then
b.registerPage(a.page or d,{build=function(b)
b:header({title=a.label or d,icon=a.icon,switch={title=a.label,
get=function()return g(d)=="on"end,
set=function(a)return c.setOn(d,a)end}})
end})
end
end
