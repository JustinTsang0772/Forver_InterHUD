



local a,e=...
local d,j,g,r,c,l,u=e.Kit,e.Store,e.Share,e.Clean,e.Combat,e.Window,e.SFImport


local b={frames={},boxes={}}
e.PageShare=b

b.COMBAT="Import and export wait until combat ends."
b.IMPORTED="Imported into this profile."
b.FULL="The box is full."
b.SF_HINT="Coming from ShamanForever add-on? This InterHUD import field accepts ShamanForever exports too."
b.SF_OFF="Both HUDs draw until ShamanForever is off: turn it off in the AddOns list, then reload."
b.SF_KEYS="Totem keys: bind them again in Key Bindings."
local a={tab="profiles",text="",model=nil,choices={},result=nil,exportKind="profile",
picked={},exported=""}
b.state=a

local function i()return c.inCombat()end












local f,m=2048,5
local k=f-m
b.PASTE_CAP,b.HELD_PAST=f,k
e.Debug.experimental("a paste taken in through OnChar while the box keeps its first "..f.." bytes, the "
.."text past that held whole and shown as a line (C: EllesmereUI's import box)","C")


local function p(a)
local a=tostring(a):reverse():gsub("(%d%d%d)","%1,"):reverse()
return(a:gsub("^,",""))
end


local n,o
local function h(a)
if#a<=k then return a,false end
if a~=n then
n,o=a,p(select(2,a:gsub("[^\128-\191]",""))).." characters pasted."
end
return o,true
end
b.pasteShown=h





local function n(g,a,c)
local f=f
a:SetMaxBytes(f)


local i,e,b,j={},0,nil,0
local function l()
if b then return end
local b,c=h(c.text())
if a:GetText()~=b then a:SetText(b)end
j=#a:GetText()
d.tint(a,c and"help"or"text")
end
local function d()
if not b then return end
b=nil
local d,g=table.concat(i,"",1,e),e
wipe(i)
e=0
local b=a:GetText()
local h=select(2,h(c.text()))
local e,i
local m=f>0 and#b>f-m
if g>0 and(#d>#b or(#d==#b and not m))then

e=d
elseif g==1 and not h and#b>k then

e=c.text()
c.full()
elseif m and(g==0 or#d>=#b or#b-j<#d)then



e,i=c.text(),true
if g==0 or#d>=#b then
f=0
a:SetMaxBytes(0)
end
elseif h then

e=d
else
e=b
end
c.changed(e)
l()
if i then c.cut()end
end
local function f()
if b then
if b.fresh then b.fresh=false else d()end
end
if not(b or a:HasFocus())then g:SetScript("OnUpdate",nil)end
end
local function k()
if not b then
b={}
g:SetScript("OnUpdate",f)
end
b.fresh=true
end
a:SetScript("OnChar",function(b,a)
e=e+1
i[e]=a
k()
end)
a:SetScript("OnTextChanged",function(a,c)
if not c then
if not b then j=#a:GetText()end
return
end
k()
end)
a:SetScript("OnEditFocusGained",function(a)
g:SetScript("OnUpdate",f)

if select(2,h(c.text()))then a:HighlightText()end
end)
return l,d
end



local h,k=6,14
local function p(a,g,f)
local e=d.row(a.content,g)
e.ground=d.field(e)
local c=CreateFrame("ScrollFrame",nil,e)
c:SetPoint("TOPLEFT",h,-h)
c:SetPoint("BOTTOMRIGHT",-k,h)
local a=CreateFrame("EditBox",nil,c)
a:SetMultiLine(true)
a:SetAutoFocus(false)

a:SetMaxLetters(0)
a:SetMaxBytes(0)
a:SetFontObject(d.font("code"))
a:SetJustifyV("TOP")
a:SetSize(e.width-h-k,g-2*h)
c:SetScrollChild(a)
local function j()return c:GetVerticalScrollRange()end
local g=d.scrollBar(e,{
offset=function()return c:GetVerticalScroll()end,
range=j,
view=function()return c:GetHeight()end,
scrollTo=function(a)c:SetVerticalScroll(math.max(0,math.min(a,j())))end,
})
g:SetPoint("TOPRIGHT",-4,-h)
g:SetPoint("BOTTOMRIGHT",-4,h)
c:SetScript("OnScrollRangeChanged",function()g:paint()end)
c:SetScript("OnVerticalScroll",function()g:paint()end)
c:EnableMouseWheel(true)
c:SetScript("OnMouseWheel",function(b,a)
c:SetVerticalScroll(math.max(0,math.min(c:GetVerticalScroll()-a*40,j())))
end)

if a:HasScript("OnCursorChanged")then
a:SetScript("OnCursorChanged",function(d,e,a,f,b)
local d,e=c:GetVerticalScroll(),c:GetHeight()
a=-a
if a<d then
c:SetVerticalScroll(a)
elseif a+b>d+e then
c:SetVerticalScroll(math.min(a+b-e,j()))
end
end)
end
a:SetScript("OnEscapePressed",function(a)a:ClearFocus()end)
a:SetScript("OnEnter",function()e.ground:lit(true)end)
a:SetScript("OnLeave",function()e.ground:lit(false)end)

e:EnableMouse(true)
e:SetScript("OnMouseDown",function()if not i()then a:SetFocus()end end)
if f and f.readOnly then
a:SetScript("OnTextChanged",function(a,b)
if b then
a:SetText(f.readOnly())
a:HighlightText()
end
end)
a:SetScript("OnEditFocusGained",function(a)a:HighlightText()end)
elseif f and f.paste then
e.show,e.settle=n(e,a,f.paste)
end
e.box,e.scroll,e.bar=a,c,g
b.boxes[#b.boxes+1]=a
return d.finishRow(e,function(d)

local b=i()
a:EnableMouse(not b)
e:EnableMouse(not b)
a:SetAlpha(b and 0.5 or 1)
if b and a:HasFocus()then a:ClearFocus()end
a:SetWidth(math.max(d-h-k,40))
c:UpdateScrollChildRect()
g:paint()
if e.show then e.show()end
if f and f.refresh then f.refresh(a)end
end)
end


local f=620
local function n(b,c,e,g)
local a=d.row(b.content,20)
a.text=d.fontString(a,"small")
a.text:SetPoint("TOPLEFT",4,-2)
a.text:SetJustifyH("LEFT")
a.text:SetSpacing(3)

a.height=function()return a.text:GetStringHeight()+10 end
return b:addRow(d.finishRow(a,function(b)
a.text:SetWidth(math.max(math.min(b-8,f),40))
d.tint(a.text,e)
a.text:SetText(table.concat(c(),"\n"))
end),g)
end



local function q()return a.model~=nil and a.model.stop~=nil end
local function f()return a.model~=nil and a.model.stop==nil end



local h=50
local function o(a)
a=a or{}
local b={}
for c=1,math.min(#a,h)do b[c]=(r.format(a[c]):gsub("|","||"))end
if#a>h then b[#b+1]="…and "..(#a-h).." more."end
return b
end
local function h(b)return function()return o(a.model and a.model[b])end end
local function k(b)
return function()return f()and#(a.model[b]or{})>0 end
end
local function m(b)return function()return f()and a.model.kind==b end end
local function r()return g.presetLines(a.model,a.choices.styles)end



local function s(h)
local b,f=a.model,{}

local d=b and g.newNames(b,a.choices,j.ready()and j.profile()or nil)or{}
for c,b in ipairs(b and b.arrivals or{})do
local c=(b.kind=="group"and"Group "or"")..b.label
..(h and b.label~=b.id and(" ("..b.id..")")or"")
local d=b.kind=="element"and d[b.id]or nil
if b.clash then
if b.replaces and a.choices.replace then
c=c..", replacing yours"

if b.leaving then
local a={}
for d,b in ipairs(b.leaving)do
local c=j.element(b)
a[d]=c and e.Form.nameOf(e.Resolve.element(c,j.profile()))or b
end
c=c.."; "..g.andList(a)..(#a==1 and" leaves"or" leave")
.." it, staying where "..(#a==1 and"it is"or"they are")
end
elseif h then
c=c..", as "..(d and(d.." ("..b.newId..")")or b.newId)
d=nil
end
end
if d then c=c..", as "..d end
if b.sound then c=c..(b.missing and", a sound missing here"or", plays a sound")end
f[#f+1]=c
end
return f
end

local function t()
for b,a in ipairs(a.model and a.model.arrivals or{})do
if a.replaces then return true end
end
return false
end

local function v()
a.model=g.check(a.text)

a.choices,a.result=a.model.shamanForever and{use=true}or{},nil
end


local function w(b)
local c={}
for d,b in ipairs(b and b.arrivals or{})do
for b,a in ipairs(b.kind=="group"and b.replaces and a.choices.replace and b.leaving or{})do
c[a]=l.placeFor(a,nil)
end
end
return c
end

local function x(e)


local c,f=a.model,a.choices.use
a.choices.places=w(c)
local g,d=g.apply(c,a.choices)
if g then
a.result={tint="help",text=c.kind=="profile"
and("Imported as the profile \""..c.profileName.."\""..(f and", now in use."or"."))
or b.IMPORTED}

if c.shamanForever then
a.result.text=a.result.text
.."\n"..b.SF_OFF
local c=c.profile and c.profile.specials and c.profile.specials.totemBar
if c and c.enabled then a.result.text=a.result.text.."\n"..b.SF_KEYS end
end
for c,b in ipairs(o(d))do a.result.text=a.result.text.."\n"..b end
a.model=nil
else
a.result={tint="callout",text=table.concat(o(d),"\n")}
end
e:refresh()
end

local function o(c)
c:block({key="import",shown=function()return a.tab=="import"end})
local j=p(c,150,{paste={
text=function()return a.text end,
changed=function(d)
if d==a.text then return end
a.text,a.full=d,nil

if a.model or a.result then
a.model,a.result=nil,nil
c:refresh()
elseif b.frames.check then
b.frames.check.refresh()
end
end,
cut=function()
a.result={tint="callout",text=u.CUT}
c:refresh()
end,
full=function()
a.full=true
c:refresh()
end,
}})

c:hint("Paste an InterHUD export, then Check.",4)

c:hint(b.SF_HINT,4,
function()return e.NewModel.playerClass()=="SHAMAN"end)
c:addRow(j)
b.frames.paste,b.frames.pasteRow=j.box,j

c:hint(b.FULL,4,function()return a.full==true end)
b.frames.check=c:buttons({
{text="Check",width=110,click=function()
j.settle()
v()
c:refresh()
end,tip="Read it and show what it would do. Nothing changes yet.",
enabled=function()return not i()and a.text:find("%S")~=nil end},
{text="Clear",width=110,
click=function()
a.text,a.model,a.result,a.full="",nil,nil,nil
c:refresh()
end,enabled=function()return a.text~=""end},
})

c:callout(function()return a.model and a.model.stop and(a.model.stop:gsub("|","||"))or""end,q)

c:callout(function()return a.model and a.model.opening or""end,
function()return f()and a.model.opening~=nil end)
c:callout(function()return a.model and a.model.lands or""end,f)
local j=function()return f()and#a.model.arrivals>0 end
local e={
{"Arriving",function()return s(false)end,"text",j},

{"Style presets",r,"help",function()return m("elements")()and#r()>0 end},
{"Refused",h("refused"),"callout",k("refused")},
{"Changed or left out",h("notes"),"help",k("notes")},
{"Sounds",h("sounds"),"help",k("sounds")},
}

n(c,h("refused"),"callout",function()return q()and#a.model.refused>0 end)
for b,a in ipairs(e)do
c:subhead(a[1],nil,a[4])
n(c,a[2],a[3],a[4])
end
c:subhead("Choices",nil,f)

local l=d.metric("form","checkBox")+9

local function e(b)
return function(d)
a.choices[b]=d or nil
c:refresh()
end
end
c:checkbox("Replace mine with the same id",nil,function()return a.choices.replace end,e("replace"),
function()return f()and t()end)
c:hint("Off, they arrive beside yours under a new id.",l,
function()return f()and t()end)


c:checkbox("Take my styles",nil,function()return not a.choices.styles end,
function(a)return e("styles")(not a)end,m("elements"))
c:checkbox("Take my styles",nil,function()return a.choices.styles end,e("styles"),m("profile"))
c:hint("Off: it keeps the styles it came with.",l,f)
c:checkbox("Use it for this character",nil,function()return a.choices.use end,e("use"),
m("profile"))

local function e()return f()and a.model.ok and g.overCap(a.model,a.choices)or nil end
c:callout(function()return e()or""end,function()return e()~=nil end)
b.frames.import=c:buttons({
{text="Import",width=110,click=function()x(c)end,tip="Out of combat only.",
enabled=function()return not i()and f()and a.model.ok and not e()end},
},f)
c:callout(function()return a.result and a.result.text or""end,
function()return a.result~=nil end)
c:endBlock()



local a=c:block({key="importDetail",title="In detail",card=true,
shown=function()return a.tab=="import"and f()end})
a.isFolded=function()return not d.isFolded("share:open:detail")end
a.onFold=function(a)d.setFolded("share:open:detail",not a)end
for b,a in ipairs({
{"Arriving",function()return s(true)end,"help",j},
{"Spells",h("spells"),"help",k("spells")},
{"Known limits",h("caveats"),"help",k("caveats")},
})do
c:subhead(a[1],nil,a[4])
n(c,a[2],a[3],a[4])
end
c:endBlock()
end




local function h()
local b,c={},nil
for e,a in ipairs(l.entries())do
if a.kind=="group"then
c={kind="group",id=a.id,label=a.label,members={},icon=d.art("iconGroup")}
b[#b+1]=c
elseif a.kind=="loose"or a.kind=="alerts"then
c=nil
b[#b+1]={kind="loose",label=a.label,
icon=d.art(a.kind=="alerts"and"iconAlerts"or"iconLoose")}
elseif a.kind=="element"then

b[#b+1]={kind="element",id=a.id,label=a.label,indent=true,icon=l.iconOf(a.id),
off=(a.off or a.unlearned)and true or nil}
if c then c.members[#c.members+1]=a.id end
end
end
return b
end

local function k(b)
if#b==0 then return false end
for c,b in ipairs(b)do
if not a.picked[b]then return false end
end
return true
end

local function m()
local b={}
for d,c in ipairs(h())do
if c.kind=="element"and a.picked[c.id]then b[#b+1]=c.id end
end
return b
end


local f=24
local function n(i,j)
local c=d.row(i.content,f)
local e,g={},0
local l=d.metric("form","checkBox")
local function m(g)
if e[g]then return e[g]end
local b=CreateFrame("Button",nil,c)
b:SetHeight(f-2)
b:SetPoint("TOPLEFT",0,-(g-1)*f)
b:SetPoint("TOPRIGHT",0,-(g-1)*f)
b:EnableMouse(true)
b.check=d.checkBox(b,l)
b.check:EnableMouse(false)
b.icon=b:CreateTexture(nil,"ARTWORK")
b.icon:SetSize(20,20)
b.icon:SetPoint("LEFT",b.check,"RIGHT",6,0)
d.cropIcon(b.icon)
b.text=d.fontString(b,"label")
b.text:SetPoint("LEFT",b.icon,"RIGHT",8,0)
b:SetScript("OnClick",function(b)
local b=b.item
if b.kind=="group"then
local c=not k(b.members)
for d,b in ipairs(b.members)do a.picked[b]=c or nil end
elseif b.kind=="element"then
a.picked[b.id]=not a.picked[b.id]or nil
end
i:refresh()
end)
e[g]=b
return b
end
c.height=function()return math.max(g,1)*f end
c.empty=d.fontString(c,"small")
d.tint(c.empty,"help")
c.empty:SetPoint("TOPLEFT",4,-4)
c.empty:SetText("No elements yet.")
b.frames.picker=e
return i:addRow(d.finishRow(c,function()
local b=h()
g=#b
c.empty:SetShown(g==0)
for c,b in ipairs(b)do
local c=m(c)
c.item=b
c.check:SetShown(b.kind~="loose")
c.check:ClearAllPoints()

c.check:SetPoint("LEFT",b.indent and 24 or 3,0)
c.icon:SetTexture(b.icon)
c.icon:SetDesaturated(b.off or false)
c.check:setChecked(b.kind=="group"and k(b.members)or b.kind=="element"and a.picked[b.id])
c.text:SetText(b.label)
d.tint(c.text,b.off and"off"or b.kind=="element"and"text"or b.kind=="loose"and"help"
or"listTopText")
c:EnableMouse(b.kind~="loose")
c.simLabel=b.label
c:Show()
end
for a=g+1,#e do e[a]:Hide()end
end),j)
end

local function f()
local c,d
if a.exportKind=="profile"then
c,d=g.exportProfile()
else
c,d=g.exportElements(m())
end
b.showExport(c,d)
end



function b.showExport(c,e)
a.exported,a.exportWhy=c or"",e
a.tab="export"
local a=b.frames.copy
if c and a then
a:SetText(c)
end
local d=d.window()and d.window().pages.profiles
if d then d:refresh()end
if c and a then
a:SetCursorPosition(0)
a:SetFocus()
a:HighlightText()

if d then d:bringIntoView(b.frames.copyRow,30)end
end
end




function b.exportElement(c)
if i()or not j.element(c)then return false end
a.exportKind="elements"
wipe(a.picked)
a.picked[c]=true
l.select("page","profiles")
local a,c=g.exportElements({c})
b.showExport(a,c)
return a~=nil
end

local function j(c)
c:block({key="export",shown=function()return a.tab=="export"end})
c:dropdown("Export",nil,function()return a.exportKind end,function(b)
a.exportKind=b
a.exported,a.exportWhy="",nil
c:refresh()
end,nil,{choices={{"elements","Elements"},{"profile","The whole profile"}}})
local d=function()return a.exportKind=="elements"end
c:hint("A group's box picks all its elements; the group goes with them.",4,d)
n(c,d)
c:buttons({
{text="All",width=80,click=function()
for c,b in ipairs(h())do
if b.kind=="element"then a.picked[b.id]=true end
end
c:refresh()
end},
{text="None",width=80,click=function()
wipe(a.picked)
c:refresh()
end},
},d)
b.frames.export=c:buttons({
{text="Export",width=110,click=f,tip="Out of combat only.",
enabled=function()
return not i()and(a.exportKind=="profile"or#m()>0)
end},
})
c:callout(function()return a.exportWhy or""end,function()return a.exportWhy~=nil end)
local d=function()return a.exported~=""end
local a=p(c,150,{readOnly=function()return a.exported end,
refresh=function(b)if b:GetText()~=a.exported then b:SetText(a.exported)end end})
c:addRow(a,d)
b.frames.copy,b.frames.copyRow=a.box,a
c:hint("Press Ctrl+C to copy it, then paste it where you share it.",4,d)
c:endBlock()
end


b.TABS={{key="import",label="Import",icon="Interface\\Icons\\INV_Scroll_03",
line="An element or a profile."},
{key="export",label="Export",icon="Interface\\Icons\\INV_Letter_15",
line="Elements or a profile."}}


function b.build(c)
c:callout(b.COMBAT,function()
return i()and a.tab~="profiles"
end)
o(c)
j(c)
end



local f={profile=true,profiles=true,element=true,group=true}
e.onChanged(function(b)

local c=b=="styles"and a.model and a.model.presets and#a.model.presets>0
if(f[b]or c)and a.model and not a.model.stop then
a.model,a.choices=nil,{}
a.result={tint="help",text=g.STALE}
end
end,"share page")


c.onStart("share page",function()
for b,a in ipairs(b.boxes)do
if a:HasFocus()then a:ClearFocus()end
end
d.repaint()
end)
c.onEnd("share page",d.repaint)
