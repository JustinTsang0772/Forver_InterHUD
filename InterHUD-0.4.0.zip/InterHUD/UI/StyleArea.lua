


local b,a=...
local d,e,h,c=a.Kit,a.Form,a.Store,a.StyleModel

local b={}
a.StyleArea=b


local r=0.45

local s,t=20,14

local function o(b)
local a={}
for b,c in pairs(b or{})do a[b]=c end
return a
end


function b.afterRefresh(a,b,c)
for d=#a.items,1,-1 do
local a=a.items[d]
if a.frame==b then
local b=a.refresh
a.refresh=function(a)
if b then b(a)end
c(a)
end
return
end
end
end


local f=d.saidOf




function b.askPresetName(g,a,h,i,b,e)
d.askInline(g,c.newPresetPrompt(a),c.newPresetName(a,h),function(a)
if e and not e()then return end
local a,c=i(a)
if not a then return f(c)end
if b then b(a)end
end)
end



function b.openStyles(a,c)
if b.show then b.show(a,c)end
end












function b.add(f,a)
local g,i=a.part,a.path
local j=a.opts or{}
local function l()return a.view()or{}end
local function h()return a.own()end
local function k()return e.read(l(),i)end
local function m()return a.vars and a.vars()or{}end
local function p()return a.shown==nil or a.shown()end
local l=a.parent~=nil
local function n()return l and p()and(a.picking==nil or a.picking())end
local q
for b,a in ipairs(a.rows)do
if a.field and a.field.name=="kind"and#a.path==#i+1 then q=a.vars end
end

if l then

local l=o(j)
local function e()return c.pick(g,h(),a.parent())end
l.choices=function()return e().choices end
local e=d.dropdown(f.content,c.PICK_LABEL,nil,function()return e().picked end,function(b)
return(a.write(i,c.pickValue(g,b,k(),q)))
end,l)
d.marks(e,l)


function e.wantMarks()return h()~=nil and{reset=true}or{}end
local o=e.refresh
e.refresh=function(b)
o(b)
if h()==nil then return e.paintMarks(nil)end
e.paintMarks({set=true,reset=function()a.write(i,nil)end,
tip=c.RESET_TIP})
end
e.styleArea=a
f:addRow(e,n,l)


local e=d.row(f.content,s)
e.isLinks=true
e.save=d.textLink(e,c.SAVE_LABEL,function(c)
b.askPresetName(c,g,nil,function(b)return a.save(b,k())end)
end,true)
local function i()return c.links(g,h(),a.parent())end
e.edit=d.textLink(e,"",function()
local a=i().edit
if a then b.openStyles(a.part,a.id)end
end,true):leaves()
local a=d.metric(j.dense and"pane"or"form","labelW")
f:addRow(d.finishRow(e,function()
local b=a
local function c(a,c)
a:SetShown(c)
if not c then return end
a:ClearAllPoints()
a:SetPoint("LEFT",e,"LEFT",b,0)
b=b+a:GetWidth()+t
end
local a=i()
c(e.save,a.save)
if a.edit then e.edit.say(a.edit.label)end
c(e.edit,a.edit~=nil)
end),n,j)


f:hint(function()return c.followLine(g,h(),k(),m())or""end,nil,function()
return n()and c.followLine(g,h(),k(),m())~=nil
end,j)
end



local function n(a)
return function(d,n)
local e=a.field and a.field.name
if not(d and e and#a.path==#i+1 and c.limited(g,e))then return end
local function a()return c.rowLimit(g,e,k(),m(),l,h())end
if l then b.afterRefresh(f,d,function()d:SetAlpha(a().grey and r or 1)end)end
f:hint(function()return a().line or""end,nil,function()
return(n==nil or n())and a().line~=nil
end,j)
end
end

local g,j={},{}
for i,d in ipairs(a.rows)do
if a.row then
g[i]=a.row(d,n(d))
else
local function k()
g[i]=b.fieldRow(f,a,d,p,
l and function()return c.ownStyle(h())end or nil,n(d))
end

local a=d.under and j[e.pathKey(d.under.path)]
if a then f:sub(a,nil,k)else k()end
j[d.key]=g[i]
end
end
return g
end


function b.fieldRow(c,b,a,h,i,j)
local function g()return b.view()or{}end
local function f()return h()and e.shown(a,g())end
if a.heading then
c:subhead(a.label,nil,f)
return nil
end
local function k()
local b=e.read(g(),a.path)
if a.widget=="choice"and b==nil then return e.NONE end
return b
end
local function l(c)
if a.widget=="choice"and c==e.NONE then c=nil end
return(b.write(a.path,c,b.path))
end
local h=o(b.opts)
if a.widget=="choice"then
h.choices=function()
local b,c=e.choices(a,g())
local a={}
for d,b in ipairs(b)do a[d]={b,c[b]}end
return a
end
end
local b=d.fieldRow(c.content,a,k,l,h)
if not b then return nil end
if i then
d.marks(b,h)
function b.wantMarks()return nil end
local a=b.refresh
b.refresh=function(c)
a(c)
b.paintMarks({set=i()})
end
end
b.formRow=a
c:addRow(b,f)
if j then j(b,f)end
if a.field and a.field.help then c:hint(a.field.help,nil,f)end
if a.widget=="sound"then c:hint(d.SOUND_NOTE,nil,f)end
return b
end




local d={}
a.onChanged(function()wipe(d)end,"style area specials")
function b.special(g,c,a,f)
f=f or{}
g:block({key=a.key,title=a.title,card=true,shown=f.shown})
return b.add(g,{part=a.part,path=a.style.path,rows=a.rows,
view=function()
d[c]=d[c]or e.specialView(c)or{}
return d[c]
end,
own=function()return e.read(h.special(c),a.style.path)end,
write=function(a,b,d)return e.setSpecial(c,a,b,d)end,
save=function(b,d)
return e.saveAsPreset({kind="special",key=c},a.part,a.style.path,b,d)
end,
parent=function()return"Global"end,
shown=f.shown})
end
