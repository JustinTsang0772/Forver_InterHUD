





































local b,a=...
local a=a.Kit


function a.gradient(b,d,e,c)
a.fill(b,"white")
b:SetGradient("VERTICAL",a.colorObj(e,c),a.colorObj(d,c))
end


function a.setArrow(b,c)
if c=="up"or c=="down"then
b:SetTexture(a.art("arrowDown"))
if c=="up"then b:SetTexCoord(0,1,1,0)else b:SetTexCoord(0,1,0,1)end
else
b:SetTexture(a.art("arrowRight"))
if c=="left"then b:SetTexCoord(1,0,0,1)else b:SetTexCoord(0,1,0,1)end
end
end
function a.arrow(b,d,c,e)
local b=b:CreateTexture(nil,e or"ARTWORK")
b:SetSize(c,c)
a.setArrow(b,d)
b:SetVertexColor(a.rgba("gold"))
return b
end





function a.edge(b,e)
local c=a.theme.frame
if c then
local d=CreateFrame("Frame",nil,b)
d:SetAllPoints()
d:SetFrameLevel(a.overPreviews(b))
local d=a.edgeArt(d,b,c,"OVERLAY")
local a=c.out or 0
b:SetClampRectInsets(-a,a,a,-a)
b:HookScript("OnSizeChanged",function(c,a,b)d.lay(a,b)end)
local function a()
d.lay(b:GetSize())
return c.inset
end
return a(),a
end
local c={}
local function d(d)
local a={}
for c=1,4 do
local b=b:CreateTexture(nil,e or"BORDER")
d(b,c)
a[c]=b
end
c[#c+1]=a
end
local e=function(b)a.fill(b,"frameDark")end
d(e)

d(function(b,c)
if c==1 then a.fill(b,"metalHigh")
elseif c==2 then a.fill(b,"metalLow")
else a.gradient(b,"metalHigh","metalLow")end
end)
d(e)
local function d()
local a=a.linePx(b,1)
for b,a in ipairs({{0,a},{a,3*a},{4*a,a}})do
local b,a,c=c[b],a[1],a[2]
for a=1,4 do b[a]:ClearAllPoints()end
b[1]:SetPoint("TOPLEFT",a,-a);b[1]:SetPoint("TOPRIGHT",-a,-a);b[1]:SetHeight(c)
b[2]:SetPoint("BOTTOMLEFT",a,a);b[2]:SetPoint("BOTTOMRIGHT",-a,a);b[2]:SetHeight(c)
b[3]:SetPoint("TOPLEFT",a,-a-c);b[3]:SetPoint("BOTTOMLEFT",a,a+c);b[3]:SetWidth(c)
b[4]:SetPoint("TOPRIGHT",-a,-a-c);b[4]:SetPoint("BOTTOMRIGHT",-a,a+c);b[4]:SetWidth(c)
end
return 5*a
end
return d(),d
end

function a.edgeOut()
return a.theme.frame and a.theme.frame.out or 0
end



function a.field(c,d,e)
local b=a.panel(c,"fieldFill","fieldEdge")
if a.theme.field.sunken then a.gradient(b.fill,"fieldTop","fieldBottom")end
if d then b:place(1,d,e)else b:cover(c,1)end
function b:lit(b)
for c=1,4 do a.fill(self.edges[c],b and"fieldEdgeLit"or"fieldEdge")end
end
return b
end




a.EDIT_INSET=6
function a.editBox(b,d,c,e)
local b=CreateFrame("EditBox",nil,b,"InputBoxTemplate")
local c=c or 20
b:SetSize(d,c)
b:SetAutoFocus(false)
a.setFont(b,e or"field")
b:SetTextInsets(a.EDIT_INSET,a.EDIT_INSET,0,0)
for b,a in ipairs({b.Left,b.Middle,b.Right})do a:SetHeight(c)end

b.Left:ClearAllPoints()
b.Left:SetPoint("LEFT",b,"LEFT",0,0)
return b
end


function a.button(b,c,d,e)
local b=CreateFrame("Button",nil,b,"UIPanelButtonTemplate")
b:SetSize(d or 140,e or 22)
b:SetMotionScriptsWhileDisabled(true)
b:SetNormalFontObject(a.font("button"))
b:SetHighlightFontObject(a.font("button"))
b:SetDisabledFontObject(a.font("buttonOff"))
b:SetText(c or"")
b.text=b:GetFontString()
b.text:SetWordWrap(false)
function b.say(a)b:SetText(a)end
function b:setEnabled(a)self:SetEnabled(a and true or false)end
return b
end


local e=40
function a.tile(b,c)
local b=CreateFrame("Button",nil,b)
b:EnableMouse(true)
b.ground=a.panel(b,nil,nil,nil,"card")
b.ground:cover(b,1)
b.on=b:CreateTexture(nil,"BORDER",nil,2)
b.on:SetAllPoints()
a.fill(b.on,"accent",0.16)
b.bar=b:CreateTexture(nil,"ARTWORK")
b.bar:SetWidth(3)
b.bar:SetPoint("TOPLEFT",1,-1)
b.bar:SetPoint("BOTTOMLEFT",1,1)
a.fill(b.bar,"accent")
b.on:Hide()
b.bar:Hide()
local d=b:CreateTexture(nil,"HIGHLIGHT")
d:SetAllPoints()
a.fill(d,"lit")
local d=c.iconSize or e
b.icon=b:CreateTexture(nil,"ARTWORK")
b.icon:SetSize(d,d)

if c.wrap then b.icon:SetPoint("TOPLEFT",d<e and 12 or 16,-12)
else b.icon:SetPoint("LEFT",d<e and 12 or 16,0)end
a.cropIcon(b.icon)
b.icon:SetTexture(c.icon)
local f=b:CreateTexture(nil,"BORDER",nil,3)
f:SetPoint("TOPLEFT",b.icon,-1,1)
f:SetPoint("BOTTOMRIGHT",b.icon,1,-1)
a.fill(f,"heroEdge")
local f=c.font or"heading"
b.title=a.fontString(b,f)
b.title:SetPoint("TOPLEFT",b.icon,"TOPRIGHT",d<e and 10 or 14,-1)
b.title:SetPoint("RIGHT",-12,0)
b.title:SetJustifyH("LEFT")
b.title:SetWordWrap(false)
b.title:SetText(c.title)
b.line=a.fontString(b,"small")
a.tint(b.line,"help")
b.line:SetPoint("TOPLEFT",b.title,"BOTTOMLEFT",0,-6)
b.line:SetPoint("RIGHT",-12,0)
b.line:SetJustifyH("LEFT")
b.line:SetWordWrap(c.wrap and true or false)
b.line:SetText(c.line)

function b.needed()

local a=(d<e and 12 or 16)+d+(d<e and 10 or 14)+12
b.line:SetWidth(math.max(b:GetWidth()-a,40))
b.line:SetText(b.line:GetText())
return math.max(d+24,12+b.title:GetStringHeight()+6+b.line:GetStringHeight()+12)
end
b:SetScript("OnEnter",function()a.tint(b.title,"goldLight")end)
b:SetScript("OnLeave",function()a.tint(b.title,a.fontColor(f))end)
b:SetScript("OnClick",c.click)

b.simRole,b.simLabel="button",c.title
return b
end


function a.segment(b,d)
local b=CreateFrame("Button",nil,b)
b:EnableMouse(true)
b.ground=a.panel(b,"segmentFill","fieldEdge")
b.ground:cover(b,1)
b.on=b:CreateTexture(nil,"ARTWORK")
b.on:SetPoint("TOPLEFT",1,-1)
b.on:SetPoint("BOTTOMRIGHT",-1,1)
a.fill(b.on,"segmentOn")
local c=b:CreateTexture(nil,"HIGHLIGHT")
c:SetPoint("TOPLEFT",1,-1)
c:SetPoint("BOTTOMRIGHT",-1,1)
a.fill(c,"lit")
b.text=a.fontString(b,d or"label")
b.text:SetPoint("CENTER")
return b
end
function a.paintSegment(b,c)
b.on:SetShown(c and true or false)
b.simState=c and"on"or nil
a.tint(b.text,c and"listOn"or"listSub")
for d=1,4 do a.fill(b.ground.edges[d],c and"accent"or"fieldEdge")end
end



function a.tab(b,c)
local b=CreateFrame("Button",nil,b)
b:EnableMouse(true)
b.fill=b:CreateTexture(nil,"BACKGROUND")
b.edges={}
for c=1,3 do
b.edges[c]=b:CreateTexture(nil,"BORDER")
local a,b=b.edges[c],c==2
if c==1 then
a:SetPoint("TOPLEFT")
a:SetPoint("TOPRIGHT")
a:SetHeight(1)
else
a:SetPoint(b and"TOPLEFT"or"TOPRIGHT")
a:SetPoint(b and"BOTTOMLEFT"or"BOTTOMRIGHT")
a:SetWidth(1)
end
end
b.fill:SetPoint("TOPLEFT",1,-1)
b.lit=b:CreateTexture(nil,"HIGHLIGHT")
b.lit:SetPoint("TOPLEFT",1,-1)
a.fill(b.lit,"lit")

b.seam=b:CreateTexture(nil,"ARTWORK")
b.seam:SetPoint("BOTTOMLEFT",1,0)
b.seam:SetPoint("BOTTOMRIGHT",-1,0)
b.seam:SetHeight(1)
a.fill(b.seam,"tabCard")
b.text=a.fontString(b,c or"label")
b.text:SetPoint("CENTER",0,1)
return b
end
function a.paintTab(c,b)
b=b and true or false
c.simState=b and"on"or nil
a.fill(c.fill,b and"tabCard"or"tabOff")
for d=1,3 do a.fill(c.edges[d],b and"tabOnEdge"or"tabOffEdge")end
c.seam:SetShown(b)
c.lit:SetShown(not b)

local d=b and 0 or 1
c.fill:SetPoint("BOTTOMRIGHT",-1,d)
c.lit:SetPoint("BOTTOMRIGHT",-1,d)
a.tint(c.text,b and"listOn"or"listSub")
end




local d=30
function a.bigTab(b,c)
local b=a.tab(b,"listTop")
b.text:ClearAllPoints()
b.icon=b:CreateTexture(nil,"ARTWORK")
b.icon:SetSize(d,d)
b.icon:SetPoint("TOPLEFT",14,-12)
a.cropIcon(b.icon)
b.icon:SetTexture(c.icon)
b.text:SetPoint("TOPLEFT",b.icon,"TOPRIGHT",12,0)
b.text:SetText(c.title)
b.line=a.fontString(b,"small")
b.line:SetPoint("TOPLEFT",b.text,"BOTTOMLEFT",0,-4)
b.line:SetJustifyH("LEFT")
b.line:SetWordWrap(true)
b.line:SetText(c.line or"")
b.accent=b:CreateTexture(nil,"ARTWORK",nil,2)
b.accent:SetPoint("TOPLEFT",1,-1)
b.accent:SetPoint("TOPRIGHT",-1,-1)
b.accent:SetHeight(3)
a.fill(b.accent,"accent")
if c.click then b:SetScript("OnClick",c.click)end
b.simRole,b.simLabel="button",c.title
function b.wrap(a)b.line:SetWidth(math.max(a-14-d-12-12,40))end
function b:paint(c,b)
b=b or{}
a.paintTab(self,c)
a.fill(self.fill,c and(b.on or"tabCard")or(b.off or"tabOff"))
a.fill(self.seam,b.on or"tabCard")
if b.edge then
for d,c in ipairs(self.edges)do a.fill(c,b.edge)end
end
a.tint(self.text,c and"gold"or"help")
a.tint(self.line,c and"listSub"or"link")
self.accent:SetShown(c)
end
return b
end


function a.glyph(b,d,c,e,f)
local b=b:CreateTexture(nil,f or"ARTWORK")
b:SetSize(c,c)
b:SetTexture(a.art(d))
b:SetVertexColor(a.rgba(e or"rule"))
return b
end




local c=4
function a.ghostPlus(b,d)
local b=CreateFrame("Button",nil,b)
b:SetSize(d,d)
b:SetHitRectInsets(-c,-c,-c,-c)
b.ground=a.panel(b,"shade","rule")
b.ground:cover(b,1)
b.plus=a.glyph(b,"glyphPlus",d-3,"rule","OVERLAY")
b.plus:SetPoint("CENTER")
local function c()
a.fill(b.ground.fill,"shade",0.35)
for c,b in ipairs(b.ground.edges)do a.fill(b,"rule",0.4)end
b.plus:SetVertexColor(a.rgba("rule",0.85))
end
c()
b:SetScript("OnEnter",function()
a.fill(b.ground.fill,"gold",0.14)
for c,b in ipairs(b.ground.edges)do a.fill(b,"gold")end
b.plus:SetVertexColor(a.rgba("gold"))
end)
b:SetScript("OnLeave",c)
b:SetScript("OnClick",function(a)if a.click then a.click(a)end end)
function b.say()end
return b
end





local e=6
function a.edgeHandle(c,d)
local b=CreateFrame("Button",nil,c)
b:EnableMouse(true)
b:SetWidth(e)
b:SetPoint("TOP",c,"TOPRIGHT",0,0)
b:SetPoint("BOTTOM",c,"BOTTOMRIGHT",0,0)
b:SetFrameLevel(c:GetFrameLevel()+10)
b.line=b:CreateTexture(nil,"OVERLAY")
b.line:SetPoint("TOP")
b.line:SetPoint("BOTTOM")
b.line:SetWidth(1)
a.fill(b.line,"fieldEdgeLit")
b.line:Hide()
b:SetScript("OnEnter",function()b.line:Show()end)
b:SetScript("OnLeave",function()if not b.dragging then b.line:Hide()end end)
local function a(a)
local b=type(d.most)=="function"and d.most()or d.most
return math.floor(math.min(math.max(a,d.least),math.max(b,d.least))+0.5)
end
local function e()
local e=GetCursorPosition()
local a=a(b.startW+(e-b.startX)/c:GetEffectiveScale())
if a~=b.now then
b.now=a
d.drag(a)
end
end
b:SetScript("OnMouseDown",function(a,b)
if b~="LeftButton"then return end
a.dragging=true
a.startX,a.startW,a.now=GetCursorPosition(),c:GetWidth(),nil
a:SetScript("OnUpdate",e)
end)
local function e()
b:SetScript("OnUpdate",nil)
b.dragging=nil
if not b:IsMouseOver()then b.line:Hide()end
d.release(b.now or a(b.startW))
end
b:SetScript("OnMouseUp",function()if b.dragging then e()end end)
c:HookScript("OnHide",function()if b.dragging then e()end end)
return b
end


function a.foldMark(c,d,e)
local b={}
for e,d in ipairs({{d,e},{e,d}})do
local c=c:CreateTexture(nil,"ARTWORK")
a.fill(c,"rule")
c:SetSize(d[1],d[2])
b[e]=c
end
function b:set(a)self[2]:SetShown(a and self[1]:IsShown())end
function b:place(b,d)
for a=1,2 do
self[a]:ClearAllPoints()
self[a]:SetPoint("CENTER",c,"BOTTOMLEFT",b,d)
end
end
function b:show(a)
self[1]:SetShown(a)
if not a then self[2]:Hide()end
end
return b
end




local c=1.5
local d={"GetNormalTexture","GetPushedTexture","GetHighlightTexture","GetCheckedTexture",
"GetDisabledCheckedTexture"}
function a.checkBox(a,b)
local a=CreateFrame("CheckButton",nil,a,"UICheckButtonTemplate")
a:SetSize(b,b)
local b=math.floor(b*c+0.5)
for d,c in ipairs(d)do
local a=a[c](a)
if a then
a:ClearAllPoints()
a:SetPoint("CENTER")
a:SetSize(b,b)
end
end
function a:setChecked(a)self:SetChecked(a and true or false)end
function a:isChecked()return self:GetChecked()end
return a
end




local c=22


local g,h=4,6
local k=3

local n=2
function a.sliderBar(b,m,e)
e=e or{}
local b=CreateFrame("Frame",nil,b)
b:SetHeight(c)
b.min,b.max,b.step,b.value=0,1,1,0
local j=e.steppers~=false
local d,c
if j then
d=CreateFrame("Frame",nil,b,"MinimalSliderWithSteppersTemplate")
d:SetPoint("TOPLEFT",-g,0)
d:SetPoint("BOTTOMRIGHT",h,0)
c=d.Slider
b.back,b.forward=d.Back,d.Forward
else
c=CreateFrame("Slider",nil,b,"MinimalSliderTemplate")
c:SetAllPoints()
end
b.hit,b.thumb=c,c:GetThumbTexture()

local function f(a)
a=b.min+math.floor((a-b.min)/b.step+0.5)*b.step
if b.step<1 then a=tonumber(string.format("%.4f",a))end
return math.min(math.max(a,b.min),b.max)
end


if e.mark then
b.mark=c:CreateTexture(nil,"ARTWORK",nil,7)
a.fill(b.mark,"sliderMark")
b.thumb:SetDrawLayer("OVERLAY")
end
local function i()
if not b.mark then return end
local g=(b.w or 0)-(j and(2*19-g-h)or 0)
local d=b.thumb:GetWidth()
local f=b.max-b.min
local d=d/2+math.max(g-d,0)*(f>0 and(e.mark-b.min)/f or 0)
b.mark:ClearAllPoints()
b.mark:SetPoint("CENTER",c,"LEFT",d,0)
b.mark:SetSize(a.linePx(c,1),17+k*2)
end


local a=false
local function o(b)
a=true
c:SetValue(b)
a=false
end


local g,j,h,k=false,-math.huge,0,false
local function l()
g=false
j=GetTime()
k=true
m(b.value)
end
local function m(d,c)
if a then return end
c=f(c)
if c==b.value then return end
b.value=c
if e.onMove then e.onMove(c)end
if b.dragging and GetTime()-j<h then g=true else l()end
end
if d then
d:RegisterCallback(MinimalSliderWithSteppersMixin.Event.OnValueChanged,m,b)
else
c:SetScript("OnValueChanged",m)
end
local function m()
b:SetScript("OnUpdate",nil)
b.dragging=nil

if g then l()elseif e.onRelease then e.onRelease()end
end

c:HookScript("OnMouseDown",function(d,a)
if(a and a~="LeftButton")or not c:IsEnabled()then return end
b.dragging=true
h=0
b:SetScript("OnUpdate",function(b,a)

if k then
k=false
h=(a or 0)*n
end
if g and GetTime()-j>=h then l()end
end)
end)
c:HookScript("OnMouseUp",function()if b.dragging then m()end end)
c:HookScript("OnHide",function()if b.dragging then m()end end)

function b:setWidth(a)
self.w=a
self:SetWidth(a)
i()
end
function b:setRange(b,e,g)
self.min,self.max,self.step=b,e,g or 1
self.value=f(self.value)
a=true
if d then
d:Init(self.value,b,e,math.max(math.floor((e-b)/self.step+0.5),1))
else
c:SetMinMaxValues(b,e)
c:SetValueStep(self.step)
c:SetValue(self.value)
end
a=false
i()
end
function b:setValue(a)

if self.dragging then return end
self.value=f(a)
o(self.value)
end

function b:pick(a)c:SetValue(f(a))end

b.repixel=i
return b
end



local b,f,m=5,14,16


function a.scrollBar(d,c)
local g,i,j=b,f,f
local e=CreateFrame("Frame",nil,d)
e:SetWidth(c.arrows and i or g)
local d=CreateFrame("Button",nil,e)
d:EnableMouse(true)
local h=c.arrows and j+2 or 0
d:SetPoint("TOP",0,-h)
d:SetPoint("BOTTOM",0,h)
d:SetWidth(g)
local b=CreateFrame("Button",nil,d)
b:SetWidth(g)
b:EnableMouse(true)
e.track,e.thumb=d,b
local g=d:CreateTexture(nil,"BACKGROUND")
g:SetAllPoints()
a.fill(g,"track")
b.tex=b:CreateTexture(nil,"ARTWORK")
b.tex:SetAllPoints()
a.fill(b.tex,"thumb")
local function g(c)a.fill(b.tex,c and"accent"or"thumb")end
b:SetScript("OnEnter",function()g(true)end)
b:SetScript("OnLeave",function(a)if not a.grab then g(false)end end)

local function k(e)
local f,a=GetCursorPosition()
a=a/d:GetEffectiveScale()
local a=(d:GetTop()-a-e)/math.max(d:GetHeight()-b:GetHeight(),1)
c.scrollTo(math.min(math.max(a,0),1)*c.range())
end
local function l()
b:SetScript("OnUpdate",nil)
b.grab=nil
g(false)
end
b:SetScript("OnMouseDown",function(a)
local c,b=GetCursorPosition()
a.grab=a:GetTop()-b/a:GetEffectiveScale()
a:SetScript("OnUpdate",function()k(a.grab)end)
end)
b:SetScript("OnMouseUp",l)
b:SetScript("OnHide",function(a)if a.grab then l()end end)
d:SetScript("OnClick",function()k(b:GetHeight()/2)end)
if c.arrows then
local function b(d,g,h)
local b=CreateFrame("Button",nil,e)
b:SetSize(i,j)
b:SetPoint(g)
b:EnableMouse(true)
b.arrow=a.arrow(b,d,f)
b.arrow:SetAllPoints()
b.arrow:SetVertexColor(a.rgba("thumbMetal"))
b:SetScript("OnEnter",function()b.arrow:SetVertexColor(a.rgba("thumbLit"))end)
b:SetScript("OnLeave",function()b.arrow:SetVertexColor(a.rgba("thumbMetal"))end)
b:SetScript("OnClick",function()c.scrollTo(c.offset()+h*(c.step or 32))end)
return b
end
e.up,e.down=b("up","TOP",-1),b("down","BOTTOM",1)
end
function e:paint()
local a=(not c.active or c.active())and c.range()or 0
self:SetShown(a>0)
if a<=0 then return end
local e=c.view()
local f=math.max(e-2*h,1)
local e=math.max(f*e/(e+a),m)
b:ClearAllPoints()
b:SetPoint("TOP",d,"TOP",0,-(f-e)*math.min(c.offset()/a,1))
b:SetHeight(e)
end
return e
end
