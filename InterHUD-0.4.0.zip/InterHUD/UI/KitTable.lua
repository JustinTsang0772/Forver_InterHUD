



local b,a=...
local b=a.Kit
















local i,e,j,n,s,t=18,22,3,4,10,12
local q,w,u,x,y=0.42,150,240,170,140

local function a(a)return b.theme.metric[(a and a.dense)and"pane"or"form"]end

local function o(a)
a:SetScript("OnEnter",function(a)if a.tip then b.note(a,a.tip)end end)
a:SetScript("OnLeave",function()b.note()end)
end


local function h(d,a)
local c={spec=a,chips={},lines=1}
c.glue=b.fontString(d,"dim")
c.glue:SetText(a.glue or"")
c.plus=b.textLink(d,"+",function(b)a.add(b)end)
c.plus.simLabel="+ "..(a.name or a.glue or"")
return c
end


local function z(j,c,a,h,m,k)
c.glue:ClearAllPoints()
c.glue:SetPoint("LEFT",j,"TOPLEFT",a,-(k+e/2))
local a=c.spec.list()or{}
local d,f,i=h,0,1
for l,g in ipairs(a)do
local a=c.chips[l]
if not a then
a=b.tag(j)
o(a)
c.chips[l]=a
end
a.tip=g.greyed and g.reason or nil
a.text:SetAlpha(g.greyed and 0.6 or 1)
if g.greyed then
a.say(g.label)
a.click=nil
else
a.say(g.label.."  ×")
local b=l
a.click=function()c.spec.remove(b)end
end
if d>h and d+a:GetWidth()>m then d,f,i=h,f+e,i+1 end
a:ClearAllPoints()
a:SetPoint("LEFT",j,"TOPLEFT",d,-(k+f+e/2))
a:Show()
d=d+a:GetWidth()+n
end
for a=#a+1,#c.chips do c.chips[a]:Hide()end
if d>h and d+c.plus:GetWidth()>m then d,f,i=h,f+e,i+1 end
c.plus:ClearAllPoints()
c.plus:SetPoint("LEFT",j,"TOPLEFT",d,-(k+f+e/2))
return i*e
end

function b.table(d,c,g)
g=g or{}
local f=a(g)
local a=b.row(d,i+f.row)
a.kitTable=true
local n,o,k={},{},{}
for c,d in ipairs(c.columns)do
n[c]=b.fontString(a,"dim")
n[c]:SetText(d)
end
a.setBar=b.setBar(a)
a.resetMark=b.resetMark(a)
for i,e in ipairs(c.rows)do
local d={label=b.fontString(a,f.label),cells={},titles={}}
d.label:SetJustifyH("LEFT")
d.label:SetText(e.label)

for c,e in ipairs(c.columns)do
d.titles[c]=b.fontString(a,"dim")
d.titles[c]:SetText(e)
d.titles[c]:Hide()
end
for f,e in ipairs(e.cells)do
local c={spec=e}
if e.text then
c.fs=b.fontString(a,"dim")
c.fs:SetJustifyH("LEFT")
elseif e.keys then
c.lines={}
for b,d in ipairs(e.keys)do c.lines[b]=h(a,d)end
elseif e.slider then
local d=e.slider
c.row=b.slider(a,nil,nil,d.get,d.set,{min=d.min,max=d.max,step=d.step,unit=d.unit,
dense=g.dense,bare=true})
if d.marks then c.bar,c.mark=b.setBar(c.row),b.resetMark(a)end
end
d.cells[f]=c
end
k[i]=d
end

local function v(d,e,f)
local c=o[d]
if not c then
c=a:CreateTexture(nil,"ARTWORK")
b.fill(c,"rule",0.2)
o[d]=c
end
c:ClearAllPoints()
c:SetPoint("TOPLEFT",a,"TOPLEFT",4,-e)
c:SetSize(math.max(f-4,1),b.linePx(a,1))
c:Show()
end
local r=i+f.row
a.height=function()return r end
return b.finishRow(a,function(d)
d=d or a.width
local g=d-b.EDGE
local l,b=f.labelW,#c.columns
local d,p,m
local function h()
d=g-l
p=math.floor(math.min(u,math.max(w,d*q)))
m=b>1 and(d-p-s*(b-1))/(b-1)or 0
end
h()
if b>1 and m<x then
local a=0
for c,b in ipairs(k)do a=math.max(a,b.label:GetStringWidth())end
l=math.min(l,math.ceil(a)+18)
h()
end
local q=b>1 and m<y
local c=c.marks and c.marks()
a.setBar:SetShown(c~=nil and c.set and true or false)
local h=a.resetMark
h.tip,h.click=c and c.tip,c and c.reset
h:SetShown(c~=nil and c.reset~=nil)
h:ClearAllPoints()
h:SetPoint("RIGHT",a,"TOPLEFT",g,-i/2)

local c=0
for b,a in ipairs(n)do c=math.max(c,a:GetStringWidth())end
local w=t+math.ceil(c)+10
local c,d={},{}
if q then
for a=1,b do c[a],d[a]=w,math.max(g-w,40)end
d[b]=math.min(d[b],u)
else
for a=1,b-1 do c[a],d[a]=l+(a-1)*(m+s),m end
c[b],d[b]=g-p,p
end
for d,b in ipairs(n)do
b:ClearAllPoints()
b:SetPoint("LEFT",a,"TOPLEFT",c[d],-i/2)
b:SetShown(not q)
end

local m=0
for b,a in ipairs(k)do
for b,a in ipairs(a.cells)do
for b,a in ipairs(a.lines or{})do m=math.max(m,a.glue:GetStringWidth())end
end
end

local function n(b,e,g)
if b.lines then
local f,g=0,g+j
for h,b in ipairs(b.lines)do
local a=z(a,b,c[e],c[e]+(m>0 and m+6 or 0),c[e]+d[e],g)
f,g=f+a,g+a
end
return f+2*j
elseif b.fs then
local a=b.spec.text
if type(a)=="function"then a=a()end
b.fs:SetText(a or"")
b.fs:SetWidth(d[e])
return math.max(f.row,math.ceil(b.fs:GetStringHeight())+8)
end
return f.row
end

local function m(b,f,h)
if b.fs then
b.fs:ClearAllPoints()
b.fs:SetPoint("LEFT",a,"TOPLEFT",c[f],h)
elseif b.row then

local g=d[f]
if b.mark then
local e=b.spec.slider.marks()
b.bar:SetShown(e~=nil and e.set and true or false)
b.mark.tip,b.mark.click=e and e.tip,e and e.reset
b.mark:SetShown(e~=nil and e.reset~=nil)
g=g-b.mark:GetWidth()-2
b.mark:ClearAllPoints()
b.mark:SetPoint("RIGHT",a,"TOPLEFT",c[f]+d[f],h)
end
b.row:ClearAllPoints()
b.row:SetPoint("LEFT",a,"TOPLEFT",c[f],h)
b.row:SetWidth(g)
b.row.refresh(g)
end
end

local c=(q and not h:IsShown())and 0 or i
local b,d=c,1
if c>0 then v(d,b,g)else d=0 end
for h,c in ipairs(k)do
c.label:ClearAllPoints()
if q then
c.label:SetPoint("LEFT",a,"TOPLEFT",4,-(b+e/2))
c.label:SetWidth(g-8)
b=b+e
for d,f in ipairs(c.cells)do
local g=n(f,d,b)
m(f,d,-(b+g/2))
local c=c.titles[d]
c:ClearAllPoints()
c:SetPoint("LEFT",a,"TOPLEFT",t,f.lines and-(b+j+e/2)or-(b+g/2))
c:Show()
b=b+g
end
else
local d=f.row+2*j
for a,c in ipairs(c.cells)do d=math.max(d,n(c,a,b))end
local e=-(b+d/2)
c.label:SetPoint("LEFT",a,"TOPLEFT",4,e)
c.label:SetWidth(l-8)
for a,b in ipairs(c.cells)do
m(b,a,e)
c.titles[a]:Hide()
end
b=b+d
end
if h<#k then
d=d+1
v(d,b,g)
end
end
for a=d+1,#o do o[a]:Hide()end
r=b+j
a:SetHeight(r)
end)
end
