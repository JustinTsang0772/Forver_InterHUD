







local a,r=...
local c=r.Kit

local a={}
r.StructurePane=a

local z,h,G=8,1,4
local n=16
local l=26
local H,P=8,6
local A,B,C=16,14,6
local I,s=15,6
local t=20
local Q=8
local R=4
local S,m=30,8
local T={icon="glyphIcon",bar="glyphBar",text="glyphText",spellAlert="glyphSpellAlert"}

local function o()return r.PageElement end


local function d(a)
local a=CreateFrame("Frame",nil,a)
a:SetSize(H,12)
a:EnableMouse(true)
for b=0,5 do
local a=a:CreateTexture(nil,"ARTWORK")
c.fill(a,"rule",0.7)
a:SetSize(2,2)
a:SetPoint("TOPLEFT",(b%2)*4+1,-(math.floor(b/2)*4+1))
end
return a
end



local function N(a,b,e)
local a=CreateFrame("Button",nil,a)
a.lit=a:CreateTexture(nil,"HIGHLIGHT")
a.lit:SetAllPoints()
c.fill(a.lit,"white",0.04)
a.grip=d(a)
a.glyph=c.glyph(a,"glyphIcon",B)

a.name=CreateFrame("Button",nil,a)
a.name:SetScript("OnClick",function()if a.key then b(a.key)end end)

a.name:SetScript("OnEnter",function()if a.hover then c.tint(a.text,a.hover)end end)
a.name:SetScript("OnLeave",function()if a.rest then c.tint(a.text,a.rest)end end)
a.text=a:CreateFontString(nil,"OVERLAY",c.font("listEntry"))
a.text:SetJustifyH("LEFT")
a.text:SetJustifyV("TOP")
a.text:SetWordWrap(true)

a.note=a:CreateFontString(nil,"OVERLAY",c.font("small"))
a.note:SetJustifyH("LEFT")
a.note:SetJustifyV("TOP")
a.note:SetWordWrap(true)
c.tint(a.note,"off")

a.icon=a:CreateTexture(nil,"ARTWORK")
a.icon:SetSize(A,A)
a.icon:SetTexCoord(0.07,0.93,0.07,0.93)
a.plus=c.ghostPlus(a,I)
a.switch=c.pillSwitch(a,function()return a.on end,function(b)
if a.key then e("switch",{key=a.key,on=b})end
end,"On",nil,nil,true)
a.mark=c.unlearnedMark(a,14)

a.band=a:CreateTexture(nil,"ARTWORK")
c.fill(a.band,"rule",0.3)
a.band:SetHeight(1)

a.rule=a:CreateTexture(nil,"ARTWORK")
c.fill(a.rule,"treeCardEdge")
a.rule:SetPoint("TOPLEFT",0,0)
a.rule:SetPoint("TOPRIGHT",0,0)
a.rule:SetHeight(1)
a:SetScript("OnClick",function()if a.clickKey and not c.justDragged(a)then b(a.clickKey)end end)
return a
end


local function u(a)
a.grip:Hide()
a.glyph:Hide()
a.plus:Hide()
a.switch:Hide()
a.mark:Hide()
a.band:Hide()
a.rule:Hide()
a.note:Hide()
a.icon:Hide()
a.name:Hide()
a.clickKey=nil
a:EnableMouse(false)
a.lit:Hide()
end



local function U(a,e)
local b=CreateFrame("Frame",nil,a)
b:SetFrameLevel(a:GetFrameLevel())
b.panel=c.panel(b,"treeCard","treeCardEdge")
b.panel:cover(b,1)
local a=CreateFrame("Frame",nil,b)
b.strip=a
a:SetPoint("TOPLEFT",h,-h)
a:SetPoint("BOTTOMLEFT",h,h)
a:SetWidth(n)
a.fill=a:CreateTexture(nil,"BACKGROUND",nil,2)
a.fill:SetAllPoints()
c.gradient(a.fill,"treeHead","treeCard")
a.lit=a:CreateTexture(nil,"HIGHLIGHT")
a.lit:SetAllPoints()
c.fill(a.lit,"white",0.06)
a.edge=a:CreateTexture(nil,"ARTWORK")
c.fill(a.edge,"treeCardEdge")
a.edge:SetPoint("TOPRIGHT")
a.edge:SetPoint("BOTTOMRIGHT")
a.edge:SetWidth(1)
b.grip=d(a)
b.grip:EnableMouse(false)
b.grip:SetPoint("TOP",a,"TOP",0,-(l-12)/2)
a:RegisterForDrag("LeftButton")
a:SetScript("OnDragStart",function()if b.payload then c.dragStart(b,e(b))end end)
a:SetScript("OnDragStop",function()c.dragStop()end)
b:HookScript("OnHide",function()
local a=c.dragging()
if a and a.frame==b then c.dragCancel()end
end)
return b
end

function a.new(e)
local b=CreateFrame("Frame",nil,e.content)
b:SetSize(300,1)
b.h=1
b.rows,b.blocks,b.zones={},{},{}

b.help=b:CreateFontString(nil,"OVERLAY",c.font("small"))
b.help:SetJustifyH("LEFT")
b.help:SetPoint("TOPLEFT",0,0)
c.tint(b.help,"help")

b.walk,b.found={},{}
local function v()return e.target end
local function O(a)o().select(v(),a)end
local function V(a,b)o().act(v(),a,b)end
local function f(a,b)o().drop(v(),a,b)end
local function d(a)e:scrollBy(a)end


local function J(a)
if not a.dragSpec then

a.dragSpec={payload=function()return a.payload end,label=function()return a.dragLabel end,
icon=function()return a.dragIcon end,scroll={frame=e.scroll,by=d}}
end
return a.dragSpec
end
local function W(a,d,e,f,g)
if not a.dragSpec then c.draggable(a,J(a))end
local b=a.payload
if not b then
b={}
a.payload=b
end
b.band,b.key=d,e
a.dragLabel,a.dragIcon=f,g
end



local d=0
local function K()
d=d+1
local a=b.zones[d]
if not a then
a=CreateFrame("Frame",nil,b)
a.frames={}
c.dropZone(a,{rows=function()return a.frames end,drop=f,clip=e.scroll,
accepts=function(b)return type(b)=="table"and b.band==a.band end})
b.zones[d]=a
end
for b=#a.frames,1,-1 do a.frames[b]=nil end
return a
end
local function L(a,b)
a.band=b
a:ClearAllPoints()
a:SetPoint("TOPLEFT",a.frames[1],"TOPLEFT")
a:SetPoint("BOTTOMRIGHT",a.frames[#a.frames],"BOTTOMRIGHT")
a:Show()
end

local function M(a,b)
if#a==0 then return end
local c=K()
for b=1,#a do
c.frames[b]=a[b]
a[b]=nil
end
L(c,b)
end



local a,e
local function f(d,e,f)
a=a+1
local c=b.walk[a]or{}
b.walk[a]=c
c.e,c.kind,c.band=d,e,f or false
if d.drag then b.found[d.drag]=(b.found[d.drag]or 0)+1 end
return c
end
local function X(i)
local b,c=b.walk,b.found
for a in pairs(c)do c[a]=nil end
a,e=0,nil
local d,g,h=false,false,nil
for b,a in ipairs(i)do
local b=a.node and a.node.type
if a.kind=="heading"then
e=nil
if a.drag=="sources"then e=f(a,"block")end
elseif a.kind=="add"then
if a.key=="add:source"then h=a end
elseif e and b=="layer"then
d,g=false,false
f(a,"layer")
elseif e and(b=="look"or b=="global")then

local c=b=="look"and type(a.drag)=="string"and a.drag:find(":state$")~=nil
local e=c and d and not g
if e then g=true end
if not c then d=true end
f(a,b,e)
elseif e and b=="line"then
f(a,"line")
end
end
for a=a+1,#b do b[a].e=nil end
for a=1,a do
local a=b[a]
a.movable=a.e.drag~=nil and(c[a.e.drag]or 0)>=2
end
return a,h
end



local f,j,w
local e,g,a=0,0,0
local i,D,p,x,q,k
local E,F={},{}


local function y()
g=g+1
local c=b.rows[g]or N(b,O,V)
b.rows[g]=c
local a=i and b.blocks[a]or b
if c:GetParent()~=a then c:SetParent(a)end
return c
end

local function V(d)
local a=y()
a.key=d.key
u(a)
local f=c.fontSize("listEntry")
local g=(l-f)/2
local o=g+f/2
local f=m
if d.icon then
a.icon:SetTexture(d.icon)
a.icon:SetDesaturated(p and true or false)
a.icon:ClearAllPoints()
a.icon:SetPoint("LEFT",a,"TOPLEFT",f,-o)
a.icon:Show()
f=f+A+C
end
local i=6
if d.unlearned then
a.mark:ClearAllPoints()
a.mark:SetPoint("RIGHT",a,"TOPRIGHT",-i,-o)
a.mark:Show()
i=i+14+s
end
local m=d.text or""
if d.note and d.note~=""then
m=m.." "..(p and d.note or(c.colorCode("help")..d.note.."|r"))
end
local i=math.max(j-f-i,20)
a.text:SetFontObject(c.font("listEntry"))
local m=c.wrapText(a.text,m,i)
a.text:ClearAllPoints()
a.text:SetPoint("TOPLEFT",a,"TOPLEFT",f,-g)
a.name:ClearAllPoints()
a.name:SetPoint("TOPLEFT",a,"TOPLEFT",f-2,-(g-2))
a.name:SetSize(math.min(a.text:GetStringWidth(),i)+4,m+4)
a.name:Show()
local d=w==d.key
a.rest=d and"white"or p and"off"or"gold"
a.hover=not d and"goldLight"or nil
c.tint(a.text,a.hover and a.name:IsMouseOver()and a.hover or a.rest)
local c=math.max(l,m+2*g)
a:SetHeight(c)
a:SetWidth(j)
a:ClearAllPoints()
a:SetPoint("TOPLEFT",b,"TOPLEFT",h+n,-e)
a:Show()
e=e+c
k=true
end

local function N(g,d)
local a=y()
a.key=d
u(a)
a.rule:SetShown(d~=nil and k)
local f=d and"listEntry"or"small"
local d=d and l or t
a.text:SetFontObject(c.font(f))
local g=c.wrapText(a.text,g,math.max(j-m-6,20))
local f=(d-c.fontSize(f))/2
a.text:ClearAllPoints()
a.text:SetPoint("TOPLEFT",a,"TOPLEFT",m,-f)
a.rest,a.hover="off",nil
c.tint(a.text,"off")
local c=math.max(d,g+2*f)
a:SetHeight(c)
a:SetWidth(j)
a:ClearAllPoints()
a:SetPoint("TOPLEFT",b,"TOPLEFT",h+n,-e)
a:Show()
e=e+c
k=true
end
local function A()
M(F,q)
q=nil
end
local function O()
A()
if not i then return end
local c=i.e
M(E,x)

local c=c.node and c.node.drawn
if c then N(c)end
local a=b.blocks[a]
a:ClearAllPoints()
a:SetPoint("TOPLEFT",b,"TOPLEFT",0,-D)
a:SetSize(f,e-D+G)
a:Show()
e=e+G+z
i,x=nil,nil
end
local function G(a)return J(a)end
local function J(d,f)
O()
a=a+1
local c=b.blocks[a]or U(b,G)
b.blocks[a]=c
local a=d.e
i,D,k=d,e,false
e=e+h
p=a.off or a.unlearned

local b=f>=2
c.grip:SetShown(b)
c.strip:EnableMouse(b)
c.strip.lit:SetShown(b)
if b then
local b=c.payload or{}
c.payload=b
b.band,b.key="sources",a.key
c.dragLabel,c.dragIcon=a.text,a.icon
else
c.payload=nil
end
V(a)
end

local function D(o)
local d=o.e
local v=d.node or{}
local r=o.kind
local g=r=="layer"
if g then A()end
local a=y()
a.key=d.key
u(a)
local u=p or d.off or d.unlearned or d.dim
local y=o.band and R or 0

local G=g and m or S
local J=r~="global"and o.movable
local i=G+(r~="global"and H+P or 0)
local z=g and T[d.glyph]or nil
if z then i=i+B+C end
local t=g and l or t
local f=c.fontSize("listEntry")
local l=(t-f)/2+y
local p=l+f/2
local f=6
if g and d.plus then
a.plus.click=d.plus
a.plus.simLabel="+ "..(d.text or"")
a.plus:ClearAllPoints()
a.plus:SetPoint("RIGHT",a,"TOPRIGHT",-f,-p)
a.plus:Show()
f=f+I+s
end
if g and v.on~=nil then
a.on=v.on
a.switch:show(v.on and true or false)
a.switch:ClearAllPoints()
a.switch:SetPoint("RIGHT",a,"TOPRIGHT",-f,-p)
a.switch:Show()
f=f+a.switch:GetWidth()+s
end
if d.unlearned then
a.mark:ClearAllPoints()
a.mark:SetPoint("RIGHT",a,"TOPRIGHT",-f,-p)
a.mark:Show()
f=f+14+s
end

local m=d.text or""
if d.note and d.note~=""then
m=m.." "..(u and d.note or(c.colorCode("help")..d.note.."|r"))
end

if r=="look"and not u then m=m:gsub("(%b())",c.colorCode("help").."%1|r")end
local D=math.max(j-i-f,20)
a.text:SetFontObject(c.font("listEntry"))
local s=c.wrapText(a.text,m,D)
local t=math.max(t+y,s+2*l-y)

local v=g and v.drawn or nil
if v then
local b=c.wrapText(a.note,v,D)
a.note:ClearAllPoints()
a.note:SetPoint("TOPLEFT",a,"TOPLEFT",i,-(l+s+2))
a.note:Show()
t=math.max(t,l+s+2+b+4)
end
a:SetHeight(t)
a:ClearAllPoints()
a:SetPoint("TOPLEFT",b,"TOPLEFT",h+n,-e)
a:SetWidth(j)
a.rule:SetShown(g and k)
if g then k=true end
if o.band then
a.band:ClearAllPoints()
a.band:SetPoint("TOPLEFT",a,"TOPLEFT",i,-1)
a.band:SetPoint("TOPRIGHT",a,"TOPRIGHT",-f,-1)
a.band:Show()
end
a.text:ClearAllPoints()
a.text:SetPoint("TOPLEFT",a,"TOPLEFT",i,-l)
if J then
a.grip:ClearAllPoints()
a.grip:SetPoint("LEFT",a,"TOPLEFT",G,-p)
a.grip:Show()
W(a.grip,d.drag,d.key,d.text,nil)
end
if g then
x=d.drag
E[#E+1]=a
elseif J then
if q~=d.drag then
A()
q=d.drag
end
F[#F+1]=a
end
if z then
a.glyph:SetTexture(c.art(z))
a.glyph:SetVertexColor(c.rgba("rule",u and 0.5 or 1))
a.glyph:ClearAllPoints()
a.glyph:SetPoint("LEFT",a,"TOPLEFT",i-B-C,-p)
a.glyph:Show()
end

local b=r~="global"and m~=""
local f=b and w==d.key
if b then
a.name:ClearAllPoints()
a.name:SetPoint("TOPLEFT",a,"TOPLEFT",i-2,-(l-2))
a.name:SetSize(math.min(a.text:GetStringWidth(),D)+4,s+4)
a.name:Show()
end

a.rest=f and"white"or u and"off"or d.lit and"listOn"or"listSub"
a.hover=b and not f and"gold"or nil

c.tint(a.text,a.hover and a.name:IsMouseOver()and a.hover or a.rest)
a:Show()
e=e+t
end

local function p(d)
local a=y()
a.key=nil
u(a)
a.text:SetFontObject(c.font("listEntry"))
local h=c.wrapText(a.text,"+ "..(d.text or""),math.max(f-2*m,20))
local g=(t-c.fontSize("listEntry"))/2
a.text:ClearAllPoints()
a.text:SetPoint("TOPLEFT",a,"TOPLEFT",0,-g)
a.clickKey=d.key
a:EnableMouse(true)
a.lit:Show()
a.rest=w==d.key and"white"or"accent"
c.tint(a.text,a.rest)
local c=math.max(t,h+2*g)
a:SetHeight(c)
a:SetWidth(math.min(a.text:GetStringWidth()+8,f))
a:ClearAllPoints()
a:SetPoint("TOPLEFT",b,"TOPLEFT",0,-e)
a:Show()
e=e+c+z
end

function b.refresh(k)
f=k or 300
j=f-2*h-n
local h=v()
local j=h and o().entriesOf(h,true)or{}
w=h and o().selected(h)
local j,k=X(j)
local l=b.walk
e,g,a,d=0,0,0,0
i,x,q=nil,nil,nil
local h=h and r.ElementModel.pane(h,"structure")
local h=h and h.help
b.help:SetShown(h~=nil)
if h then e=c.wrapText(b.help,h,f)+Q end
local c=0
for a=1,j do
if l[a].kind=="block"then c=c+1 end
end
for a=1,j do
local a=l[a]
if a.kind=="block"then
J(a,c)
elseif a.kind=="line"then

N(a.e.text or"",a.e.key)
else
D(a)
end
end
O()
for a=a+1,#b.blocks do b.blocks[a]:Hide()end

if a>0 then
local c=K()
for a=1,a do c.frames[a]=b.blocks[a]end
L(c,"sources")
end
if k then p(k)end
for a=g+1,#b.rows do b.rows[a]:Hide()end
for a=d+1,#b.zones do b.zones[a]:Hide()end
b.h=math.max(e-z,1)
b:SetHeight(b.h)
end
b.height=function()return b.h end
return b
end
