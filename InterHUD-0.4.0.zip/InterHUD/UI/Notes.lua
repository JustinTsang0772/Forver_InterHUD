



local a,b=...
local c=b.Store

local a={}
b.Notes=a



local b={

["quick-settings"]={rev=2,small=true,title="Pre-made Quick Settings are under construction",
text="Pre-made elements are intended to ship with their own set of quick settings, which act as shortcuts to"
.." the full element settings. This system is not fully built yet."},
}
a.LIST=b


function a.shown(a)
local d=b[a]
if not d then return false end
local b=c.ui().notesDismissed
return not(b and b[a]and b[a].rev==d.rev)
end

function a.dismiss(d)
local b=b[d]
if not b then return end
c.editUI(function(a)
a.notesDismissed=a.notesDismissed or{}
a.notesDismissed[d]={rev=b.rev}
end)
end


function a.spec(c,d)
local b=b[c]
return{title=b.title,text=b.text,sign="— Inter",small=b.small,close=function()
a.dismiss(c)
if d then d()end
end}
end
