





local a,b=...

local c,g=b.Kit,b.Debug
local f={}
b.DebugWindow=f

local k,o,d=500,560,12
local e,i,l=20,120,9
local j=92

local a
local m={}
local h=false



local function p(a)
local a=a=="errors"and g.errorLines()or g.part(a)
local b={}
for c,a in ipairs(a)do
b[c]=c==1 and(a:match("^[^:]+:%s*(.*)$")or a)or a:gsub("^  ","")
end
return b
end


local n=""
local function q()
if InCombatLockdown()or not(UpdateAddOnMemoryUsage and GetAddOnMemoryUsage)then return nil end
UpdateAddOnMemoryUsage()
local c,a=pcall(GetAddOnMemoryUsage,"InterHUD")
if not c or type(a)~="number"or b.isSecret(a)then return nil end
return string.format("memory %.1f MB",a/1024)
end
local function r(c)
local a=#b.errorLines()
if c then n=q()or""end
return{
g.header(),
string.format("profile %q; %s; %s",tostring(b.Store.profileName()),
b.Combat.inCombat()and"in combat"or"not in combat",
a==0 and"no errors"or(a==1 and"1 error"or a.." errors")),
n,
}
end


local function n(d,b)
local a={name=b}
a.head=CreateFrame("Button",nil,d)
a.head:SetHeight(e)
a.mark=c.foldMark(a.head,l,1)
a.mark:place(l/2+2,e/2)
a.label=c.fontString(a.head,"label")
a.label:SetPoint("LEFT",l+8,0)
a.label:SetText(b=="hud"and"HUD"or b:sub(1,1):upper()..b:sub(2))
a.first=c.fontString(a.head,"small")
a.first:SetPoint("LEFT",i,0)
a.first:SetPoint("RIGHT",-4,0)
a.first:SetJustifyH("LEFT")
a.first:SetWordWrap(false)
a.first:SetMaxLines(1)
a.first:SetHeight(e)
a.lit=a.head:CreateTexture(nil,"HIGHLIGHT")
a.lit:SetAllPoints()
c.fill(a.lit,"lit")
a.detail=c.fontString(d,"small")
a.detail:SetJustifyH("LEFT")
a.detail:SetJustifyV("TOP")
a.head:SetScript("OnClick",function()
m[b]=not f.isFolded(b)
f.refresh()
end)
return a
end

function f.isFolded(a)return m[a]~=false end


local function b(a)
local b=p(a.name)
a.empty=#b==0
a.first:SetText(b[1]or"")
a.detail:SetText(table.concat(b,"\n"))
a.many=#b>1
end

local function l(a,b)
return a.many or c.textWidth("small",a.first:GetText()or"")>b-i-4
end
local function m()
local d,b=a.content,0
local g=a.scroll:GetWidth()
d:SetWidth(g)
for h,a in ipairs(a.sections)do

local h=not a.empty and l(a,g)
local f=h and not f.isFolded(a.name)
a.head:SetShown(not a.empty)
a.detail:SetShown(f)
if not a.empty then
a.head:ClearAllPoints()
a.head:SetPoint("TOPLEFT",d,"TOPLEFT",0,-b)
a.head:SetWidth(g)
a.mark:show(h)
a.mark:set(not f)

a.first:SetShown(not f)
end
if f then
a.detail:ClearAllPoints()
a.detail:SetPoint("TOPLEFT",d,"TOPLEFT",i,-b-(e-c.fontSize("small"))/2)
a.detail:SetWidth(g-i-4)

a.detail:SetText(a.detail:GetText())
b=b+math.max(e,a.detail:GetStringHeight()+(e-c.fontSize("small"))+4)
elseif not a.empty then
b=b+e
end
end
d:SetHeight(math.max(b,1))
a.bar:paint()
end

function f.refresh(c)
if not(a and a.frame:IsShown())then return end
local c=r(c)
for b=1,3 do a.summary[b]:SetText(c[b])end
for c,a in ipairs(a.sections)do b(a)end
m()
if a.copying then a.box:SetText(table.concat(g.lines(),"\n"))end
end


local function m(b,e)
local a=CreateFrame("ScrollFrame",nil,b)
a:SetPoint("TOPLEFT",d,-j)
a:SetPoint("BOTTOMRIGHT",-d-12,d)
a:SetScrollChild(e)
local function e()return a:GetVerticalScrollRange()end
local b=c.scrollBar(b,{
offset=function()return a:GetVerticalScroll()end,
range=e,
view=function()return a:GetHeight()end,
scrollTo=function(b)a:SetVerticalScroll(math.max(0,math.min(b,e())))end,
})
b:SetPoint("TOPRIGHT",-d+4,-j)
b:SetPoint("BOTTOMRIGHT",-d+4,d)
a:SetScript("OnScrollRangeChanged",function()b:paint()end)
a:SetScript("OnVerticalScroll",function()b:paint()end)
a:EnableMouseWheel(true)
a:SetScript("OnMouseWheel",function(c,b)
a:SetVerticalScroll(math.max(0,math.min(a:GetVerticalScroll()-b*40,e())))
end)
return a,b
end

local function i(b)
a.copying=b
a.scroll:SetShown(not b)
a.bar:SetShown(not b)
a.copyScroll:SetShown(b)
a.copyBar:SetShown(b)
a.copy.say(b and"Back"or"Copy")
if b then
a.box:SetText(table.concat(g.lines(),"\n"))
a.box:SetFocus()
a.box:HighlightText()
else
a.box:ClearFocus()
end
end

local function b()
local b=CreateFrame("Frame","InterHUDDebug",UIParent)
b:SetSize(k,o)
b:SetPoint("CENTER",280,0)
b:SetFrameStrata("DIALOG")
b:SetToplevel(true)
b:SetClampedToScreen(true)
b:SetMovable(true)
b:EnableMouse(true)

b:EnableMouseWheel(true)
b:SetScript("OnMouseWheel",function()end)
b:RegisterForDrag("LeftButton")
b:SetScript("OnDragStart",b.StartMoving)
b:SetScript("OnDragStop",b.StopMovingOrSizing)
c.panel(b):cover(b,c.linePx(b,1))
UISpecialFrames[#UISpecialFrames+1]="InterHUDDebug"
a={frame=b,summary={},sections={}}

local e=c.fontString(b,"heading")
e:SetPoint("TOPLEFT",d,-d)
e:SetText("InterHUD debug")
local e=c.button(b,"Close",70,22)
e:SetPoint("TOPRIGHT",-d,-d+2)
e:SetScript("OnClick",function()b:Hide()end)
a.copy=c.button(b,"Copy",70,22)
a.copy:SetPoint("RIGHT",e,"LEFT",-6,0)
a.copy:SetScript("OnClick",function()i(not a.copying)end)
local l=c.button(b,"Refresh",70,22)
l:SetPoint("RIGHT",a.copy,"LEFT",-6,0)
l:SetScript("OnClick",function()f.refresh(true)end)
local e=c.checkBox(b,14)
local i=c.fontString(b,"small")
i:SetPoint("RIGHT",l,"LEFT",-10,0)
i:SetText("Each second")
e:SetPoint("RIGHT",i,"LEFT",-6,0)

e:SetHitRectInsets(0,-(i:GetStringWidth()+6),0,0)
e:SetScript("OnClick",function()
h=not h
e:setChecked(h)
end)
e:setChecked(h)
for e=1,3 do
local b=c.fontString(b,"small")
b:SetPoint("TOPLEFT",d,-d-22-(e-1)*16)
b:SetPoint("RIGHT",-d,0)
b:SetJustifyH("LEFT")
b:SetWordWrap(false)
a.summary[e]=b
end
local e=b:CreateTexture(nil,"ARTWORK")
c.fill(e,"rule")
e:SetHeight(1)
e:SetPoint("TOPLEFT",d,-j+6)
e:SetPoint("TOPRIGHT",-d,-j+6)

a.content=CreateFrame("Frame",nil,b)
a.content:SetSize(k-2*d-12,1)
a.scroll,a.bar=m(b,a.content)
for c,b in ipairs(g.partNames())do
a.sections[#a.sections+1]=n(a.content,b)
end
a.sections[#a.sections+1]=n(a.content,"errors")


local e=CreateFrame("EditBox",nil,b)
e:SetMultiLine(true)
e:SetAutoFocus(false)
e:SetMaxLetters(0)
e:SetMaxBytes(0)
e:SetFontObject(c.font("code"))
e:SetWidth(k-2*d-12)
e:SetScript("OnTextChanged",function(a,b)
if b then
a:SetText(table.concat(g.lines(),"\n"))
a:HighlightText()
end
end)
e:SetScript("OnEditFocusGained",function(a)a:HighlightText()end)
e:SetScript("OnEscapePressed",function(a)a:ClearFocus()end)
a.box=e
a.copyScroll,a.copyBar=m(b,e)
a.copyScroll:Hide()
a.copyBar:Hide()


local c=0
b:SetScript("OnUpdate",function(d,b)
if not h then return end
c=c+b
if c<1 then return end
c=0
if not a.copying then f.refresh()end
end)
b:SetScript("OnShow",function()c=0 end)
b:Hide()
end

function f.toggle()
if not a then b()end
local b=a.frame
if b:IsShown()then
b:Hide()
return
end
b:Show()
if a.copying then i(false)end
f.refresh(true)
end
