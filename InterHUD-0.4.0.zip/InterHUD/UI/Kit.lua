


local b,c=...
local d=c.Store
local i=c.Layers
local h=c.Media
local l=c.Combat

local a={}
c.Kit=a

























local b="Interface\\AddOns\\"..b.."\\Art\\"
a.theme={
color={
accent={0.88,0.66,0.29,1},
gold={1,0.82,0,1},
goldLight={1,0.93,0.6,1},
rule={0.85,0.71,0.42,1},

panelFill={31/255,27/255,21/255,1},
panelEdge={59/255,43/255,26/255,1},
windowBg={23/255,19/255,15/255,1},
listBg={0,0,0,0.22},


treeCard={31/255,27/255,21/255,1},
treeCardEdge={59/255,43/255,26/255,1},
treeHead={0.31,0.257,0.205,1},


cardHead={0.235,0.196,0.16,1},
shade={0.09,0.075,0.06,1},
link={0.70,0.68,0.64,1},
help={0.80,0.78,0.74,1},
off={0.5,0.5,0.5,1},
white={1,1,1,1},
swatchEdge={1,1,1,0.6},
callout={0.95,0.59,0.24,1},

noteFill={0.133,0.11,0.09,1},
noteEdge={0.29,0.227,0.149,1},
attention={0.95,0.59,0.24,1},
attentionText={0.97,0.77,0.54,1},


parchment={1,1,1,1},
parchmentEdge={0.35,0.24,0.10,1},
parchmentCorner={0.33,0.20,0.07,0.8},
letterText={0.29,0.17,0.02,1},
letterTitle={0.16,0.09,0,1},
letterLink={0.48,0.23,0,1},

keyHigh={0.165,0.133,0.106,1},
keyLow={0.07,0.055,0.043,1},
keyEdge={0.42,0.34,0.21,1},
keyText={0.95,0.90,0.77,1},

statFill={0.114,0.094,0.078,1},
dropLine={0.95,0.95,0.95,1},
track={1,1,1,0.06},
thumb={0.88,0.66,0.29,0.55},
knobRim={0.25,0.16,0.05,1},
knobOnLow={0.72,0.47,0.12,1},
knobOnHigh={1,0.9,0.55,1},
knobOffLow={0.36,0.36,0.36,1},
knobOffHigh={0.8,0.8,0.8,1},
knobShine={1,1,1,0.45},
logoShadow={0,0,0,0.7},


frameDark={0.02,0.015,0.01,1},
metalHigh={0.66,0.53,0.32,1},
metalLow={0.29,0.22,0.12,1},
frameTint={1,0.92,0.80,1},
titleHigh={0.14,0.11,0.08,1},
titleLow={0.05,0.04,0.03,1},
lit={1,1,1,0.12},
shine={1,1,1,0.08},


fieldFill={0.02,0.018,0.015,0.96},
fieldTop={0,0,0,0.95},
fieldBottom={0.07,0.058,0.045,0.95},
fieldEdge={0.38,0.31,0.20,1},
fieldEdgeLit={0.85,0.70,0.40,1},
menuFill={0.07,0.06,0.045,0.98},
menuPick={0.88,0.66,0.29,0.22},

groove={0,0,0,0.55},

cardTop={0.17,0.137,0.102,1},
cardBottom={0.098,0.08,0.062,1},
cardShine={1,0.86,0.56,0.10},
ornament={0.85,0.71,0.42,1},


heroFill={0.5,0.5,0.5,1},
heroEdge={92/255,71/255,43/255,1},
heroShade={0,0,0,0.55},
heroText={0.80,0.74,0.66,1},

bandWarnFill={0.30,0.19,0.04,0.96},
bandWarnEdge={0.95,0.59,0.24,1},
bandOffFill={0.32,0.04,0.03,0.96},
bandOffEdge={0.9,0.25,0.15,1},

error={0.9,0.25,0.15,1},

listSub={0.9,0.88,0.84,1},
listOn={1,0.84,0.5,1},
thumbMetal={0.80,0.56,0.33,1},
sliderMark={0.85,0.71,0.42,0.55},
thumbLit={1,0.80,0.52,1},

artRest={0.88,0.88,0.88,1},
artLit={1,1,1,1},


tagFill={0.88,0.66,0.29,0.14},
tagEdge={0.62,0.47,0.22,1},
tagText={0.95,0.80,0.52,1},
linkTagFill={0.02,0.018,0.015,0.6},
linkTagLit={0.88,0.66,0.29,0.22},


chipLabel={0.90,0.76,0.45,1},
lineText={0.91,0.79,0.54,1},
lineLink={0.88,0.66,0.29,1},

setHere={0.88,0.66,0.29,1},
resetMark={0.88,0.66,0.29,0.9},
resetMarkLit={1,0.84,0.5,1},
sectionTitle={0.95,0.75,0.35,1},

segmentFill={0.03,0.025,0.02,0.95},
segmentOn={0.88,0.66,0.29,0.28},

tabCard={0.075,0.062,0.05,1},
tabCardEdge={0.62,0.47,0.22,1},
tabOnEdge={0.62,0.47,0.22,1},
tabOff={0.03,0.025,0.02,1},
tabOffEdge={0.30,0.22,0.12,1},
dots={0.75,0.68,0.58,1},

text={1,1,1,1},
headingText={1,0.82,0,1},
titleText={1,0.82,0,1},
windowTitleText={1,0.82,0,1},
buttonText={1,0.82,0,1},
buttonOffText={0.5,0.5,0.5,1},
linkText={1,0.82,0,1},
listTopText={1,0.82,0,1},

dimText={0.60,0.585,0.55,1},
},


font={
label={base="GameFontHighlight",size=12,color="text"},
small={base="GameFontHighlightSmall",size=11,color="text"},
dim={base="GameFontDisableSmall",size=11,color="dimText"},
heading={base="GameFontNormalLarge",size=16,color="headingText"},

bannerName={base="GameFontNormalLarge",size=18,color="headingText"},

section={base="GameFontNormalLarge",size=20,color="headingText"},
title={base="GameFontNormalHuge",size=22,color="titleText"},
link={base="GameFontNormalSmall",size=11,color="linkText"},
code={base="ChatFontSmall",size=12,color="text"},
windowTitle={base="GameFontNormal",size=15,color="windowTitleText"},
button={base="GameFontNormal",size=12,color="buttonText"},
buttonOff={base="GameFontDisable",size=12,color="buttonOffText"},
field={base="GameFontHighlight",size=12,color="text"},
listTop={base="GameFontNormal",size=12,color="listTopText"},
band={base="GameFontHighlight",size=16,color="text"},
listSub={base="GameFontHighlight",size=12,color="listSub"},

listEntry={base="GameFontHighlightSmall",size=11,color="text"},
listHeading={base="GameFontNormalSmall",size=10,color="linkText"},
tag={base="GameFontHighlightSmall",size=10,color="tagText"},

sectionSmall={base="GameFontNormal",size=14,color="sectionTitle"},

subhead={base="GameFontNormal",size=14,color="sectionTitle"},



formSection={base="GameFontNormalLarge",size=16,color="headingText"},
formHeading={base="GameFontNormalLarge",size=14,color="headingText"},
formPart={base="GameFontNormal",size=13,color="sectionTitle"},
formSubhead={base="GameFontNormal",size=13,color="sectionTitle"},
formLabel={base="GameFontHighlight",size=11,color="text"},
formField={base="GameFontHighlight",size=11,color="text"},
paneTitle={base="GameFontNormalLarge",size=16,color="headingText"},
paneSection={base="GameFontNormalLarge",size=15,color="headingText"},
paneHeading={base="GameFontNormalLarge",size=13,color="headingText"},
panePart={base="GameFontNormal",size=12,color="sectionTitle"},
paneSubhead={base="GameFontNormal",size=11,color="sectionTitle"},
paneLabel={base="GameFontHighlight",size=11,color="text"},
paneField={base="GameFontHighlight",size=11,color="text"},

hint={base="GameFontHighlightSmall",size=10,color="dimText"},

letter={base="QuestFont",size=13,color="letterText",shadow=false},
letterTitle={base="QuestTitleFont",size=18,color="letterTitle",shadow=false},

letterSmall={base="QuestFont",size=12,color="letterText",shadow=false},

letterTitleSmall={base="QuestFont",size=13,color="letterTitle",bold=true},

greeting={base="GameFontNormalHuge",size=24,color="titleText"},
stat={base="GameFontNormalLarge",size=18,color="text"},
key={base="ChatFontSmall",size=12,color="keyText"},
},

metric={

list={width=265,row=21,heading=21,tag=15},











form={row=24,check=24,labelW=175,field=19,box=19,checkBox=15,swatch=17,dropdownW=260,
fieldMin=180,fieldMax=300,colGap=8,head=30,bigHead=34,partHead=28,subheadH=30,hintFoot=8,
gap=8,
title="formSection",section="formSection",heading="formHeading",part="formPart",
subhead="formSubhead",label="formLabel",fieldFont="formField",hint="hint"},
pane={row=24,check=24,labelW=128,field=19,box=19,checkBox=15,swatch=17,dropdownW=170,
fieldMin=140,fieldMax=300,colGap=8,head=26,bigHead=30,partHead=28,subheadH=30,hintFoot=6,
gap=8,
title="paneTitle",section="paneSection",heading="paneHeading",part="panePart",
subhead="paneSubhead",label="paneLabel",fieldFont="paneField",hint="hint"},


banner={top=18},



sidebar={top=28,topStep=30,topIcon=20,group=18,groupFont="listHeading",row=22,rowStep=22,
icon=16,foot=24,footStep=26},
},
art={


logo=b.."Logo",
logoSmall=b.."LogoSmall",


banner=b.."Banner.jpg",
bannerCrop={1400,260,2048,512},

check=b.."Check",
close=b.."Close",
arrowRight=b.."ArrowRight",
arrowDown=b.."ArrowDown",
thumb=b.."Thumb",

markOff=b.."MarkOff",
markUnlearned=b.."MarkUnlearned",

glyphIcon=b.."Glyph-Icon",
glyphBar=b.."Glyph-Bar",
glyphText=b.."Glyph-Text",
glyphSpellAlert=b.."Glyph-Alert",
glyphCustomState=b.."Glyph-CustomState",
glyphPlus=b.."Glyph-Plus",

reset=b.."Reset",
white=h.WHITE,
round="Interface\\CharacterFrame\\TempPortraitAlphaMask",

iconNew="Interface\\Icons\\Spell_ChargePositive",

iconElements=b.."Elements",
iconGroup="Interface\\Icons\\INV_Misc_Bag_10",
iconLoose="Interface\\Icons\\INV_Misc_Gem_01",

iconAlerts="Interface\\Icons\\Spell_Nature_Lightning",
iconGlobal="Interface\\Icons\\Trade_Engineering",
iconProfiles="Interface\\Icons\\INV_Misc_Note_01",
iconShare="Interface\\Icons\\INV_Scroll_03",
iconAbout="Interface\\Icons\\INV_Misc_Book_09",

iconCollections="Interface\\Icons\\INV_Box_01",
iconUnlock="Interface\\Icons\\INV_Misc_Key_03",
iconUnknown="Interface\\Icons\\INV_Misc_QuestionMark",

iconPremade="Interface\\Icons\\INV_Box_01",
iconEmpty="Interface\\Icons\\INV_Fabric_Linen_01",
grip="Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-",

sound={atlas="voicechat-icon-speaker"},


parchment=b.."Parchment.jpg",
parchmentCrop={512,512,512,512},
corner=b.."Themes\\forever\\Corner",
flourish=b.."Flourish",

iconPreview="Interface\\Icons\\Spell_Holy_MindVision",
},

fillArt={
heroFill={file=b.."Banner.jpg",cover={1400,260,2048,512}},
},

frame={file="Interface\\DialogFrame\\UI-DialogBox-Gold-Border",size=24,out=6,inset=5,
tint="frameTint"},


switch={
groove={"Minimal_SliderBar_Left","_Minimal_SliderBar_Middle","Minimal_SliderBar_Right"},
ring="common-radiobutton-circle",gem="common-radiobutton-dot",
normal={w=44,h=24,groove=16,endW=10,knob=24},
small={w=30,h=16,groove=11,endW=7,knob=16},
},

panel={
header={ornament={file=b.."Themes\\forever\\Corner",size=24,inset=4,alpha=0.55,
corners={TOPLEFT=true,TOPRIGHT=true,BOTTOMLEFT=true,BOTTOMRIGHT=true}}},
},
field={},
}

local e={}
local function f(d)
local c=a.theme.font[d]
if not c then error("Kit: no font token "..tostring(d),3)end
local b=e[d]or CreateFont("InterHUDKit_"..d)
e[d]=b
b:CopyFontObject(c.base)
local d,e,f=b:GetFont()
if d then b:SetFont(d,c.size or e,f)end
b:SetTextColor(a.rgba(c.color or"text"))


if c.bold then
b:SetShadowOffset(1,0)
b:SetShadowColor(a.rgba(c.color or"text"))
else
if c.shadow==false then b:SetShadowOffset(0,0)else b:SetShadowOffset(1,-1)end
b:SetShadowColor(0,0,0,1)
end
return b
end

function a.useTheme(b)
a.theme=b
for a in pairs(e)do f(a)end
end


function a.rgba(b,c)
local a=a.theme.color[b]
if not a then error("Kit: no colour token "..tostring(b),2)end
return a[1],a[2],a[3],c or a[4]
end

local g={0,1,0,1}
function a.fill(b,d,e)
local c=a.theme.fillArt[d]
if not c then
b:SetVertexColor(1,1,1,1)
b:SetColorTexture(a.rgba(d,e))
return
end
local f=c.tile and"REPEAT"or nil
b:SetTexture(c.file,f,f)
b:SetHorizTile(c.tile and true or false)
b:SetVertTile(c.tile and true or false)
b:SetTexCoord(unpack(c.coords or g))
b:SetVertexColor(a.rgba(d,e))
end
function a.tint(b,c,d)b:SetTextColor(a.rgba(c,d))end
function a.colorObj(b,c)return CreateColor(a.rgba(b,c))end

function a.colorCode(b)
local a,b,c=a.rgba(b)
return string.format("|cff%02x%02x%02x",math.floor(a*255+0.5),math.floor(b*255+0.5),
math.floor(c*255+0.5))
end

function a.font(a)
return(e[a]or f(a)):GetName()
end

function a.fontSize(b)
local a=a.theme.font[b]
if not a then error("Kit: no font token "..tostring(b),2)end
if a.size then return a.size end
return select(2,(e[b]or f(b)):GetFont())
end
function a.fontColor(b)return a.theme.font[b].color or"text"end
function a.art(b)return a.theme.art[b]end

function a.setArt(b,c)
local a=a.art(c)
if type(a)=="table"then b:SetAtlas(a.atlas)else b:SetTexture(a)end
end
function a.metric(b,c)
local a=a.theme.metric[b]
local a=a and a[c]
if a==nil then error("Kit: no metric "..tostring(b).."."..tostring(c),2)end
return a
end


function a.setFont(b,c)
b:SetFontObject(a.font(c))
a.tint(b,a.fontColor(c))
end
function a.fontString(c,b,d)
local c=c:CreateFontString(nil,d or"OVERLAY",a.font(b))
a.tint(c,a.fontColor(b))
return c
end


local b
function a.textWidth(c,d)
if not b then
local a=CreateFrame("Frame",nil,UIParent)
a:Hide()
b=a:CreateFontString(nil,"OVERLAY")
end
b:SetFontObject(a.font(c))
b:SetText(d)
return b:GetStringWidth()
end




function a.wordLines(f,c,g,e)
local b,d={},{}
for a in tostring(c or""):gmatch("%S+")do d[#d+1]=a end
local c=1
while c<=#d and#b<e do
local e=d[c]
c=c+1
while c<=#d and a.textWidth(f,e.." "..d[c])<=g do
e=e.." "..d[c]
c=c+1
end
b[#b+1]=e
end
if c<=#d and#b>0 then

local c=b[#b]
while a.textWidth(f,c.."…")>g and c:find(" ")do c=c:gsub("%s+%S+$","")end
b[#b]=c.."…"
end
return table.concat(b,"\n"),#b
end







local g,f={},false
local n=2
local function j()
f=false
local e,d=false,false
for b,a in pairs(g)do
a.wait=a.wait-1
if a.wait>0 then
e=true
else
g[b]=nil
if b:IsVisible()and b.wrapped==a then
local c=b:GetStringHeight()
if math.abs(c-a.h)>1 then

local e=b.realHeight and b.realHeight.text==a.text and b.realHeight.width==a.width
b.realHeight={text=a.text,width=a.width,h=c}
d=d or not e
end
end
end
end
if e then
f=true
c.Events.atFrameEnd("kit settle text",j)
end
if d then a.repaint()end
end

a.WRAP_SPARE=3
local k=a.WRAP_SPARE
function a.wrapText(a,d,e,l)


a:SetWordWrap(false)
a:SetWidth(0)
a:SetText(d)
local h,m=a:GetStringWidth(),a:GetStringHeight()
local i=m
local b=a.realHeight
b=b and b.text==d and b.width==e and b.h or nil


if h+k>e or b then
a:SetWordWrap(true)
a:SetWidth(e)
a:SetText(d)
i=b or a:GetStringHeight()
else






a:SetWordWrap(not l)
a:SetWidth(l and h+k or e)
a:SetText(d)
end
local b={text=d,width=e,h=i,wait=n}
a.wrapped=b
g[a]=b
if not f then
f=true
c.Events.atFrameEnd("kit settle text",j)
end
return i,h,m
end



a.WIDTH,a.LIST_W=884,220
a.DEFAULT_W,a.DEFAULT_H=1036,860







a.OVER_PREVIEWS=1000
function a.overPreviews(b,c)return b:GetFrameLevel()+a.OVER_PREVIEWS+(c or 0)end


function a.parseColor(a)
if type(a)~="string"or not(a:match("^#%x%x%x%x%x%x$")or a:match("^#%x%x%x%x%x%x%x%x$"))then return end
return h.rgba(a)
end
local function b(a)return math.max(0,math.min(255,math.floor(a*255+0.5)))end

function a.colorString(c,d,e,a,f)
local c=string.format("#%02x%02x%02x",b(c),b(d),b(e))
if f or a==nil or b(a)==255 then return c end
return c..string.format("%02x",b(a))
end


function a.setTip(c,b,a,d)
if not a then return end
c:SetScript("OnEnter",function(c)
if d=="above"then
GameTooltip:SetOwner(c,"ANCHOR_NONE")
GameTooltip:ClearAllPoints()
GameTooltip:SetPoint("BOTTOMLEFT",c,"TOPLEFT",0,2)
else
GameTooltip:SetOwner(c,d or"ANCHOR_RIGHT")
end
GameTooltip:SetText(type(b)=="function"and b()or b)
GameTooltip:AddLine(type(a)=="function"and a()or a,1,1,1,true)
GameTooltip:Show()
end)
c:SetScript("OnLeave",function()GameTooltip:Hide()end)
end



local f,e=260,6
local b
function a.note(c,d)
if not c then
if b then b:Hide()end
return
end
if not b then
b=CreateFrame("Frame",nil,UIParent)
b:SetFrameStrata("TOOLTIP")
a.panel(b,"menuFill","fieldEdgeLit"):cover(b,1)
b.text=a.fontString(b,"small")
b.text:SetPoint("TOPLEFT",e,-e)
b.text:SetJustifyH("LEFT")
b.text:SetSpacing(2)
end
b.text:SetWidth(f)
b.text:SetText(d)
local a=math.min(b.text:GetStringWidth(),f)
b.text:SetWidth(a+1)
b:SetSize(a+1+2*e,b.text:GetStringHeight()+2*e)
b:SetScale(c:GetEffectiveScale()/UIParent:GetEffectiveScale())
b:ClearAllPoints()
b:SetPoint("BOTTOMLEFT",c,"TOPLEFT",0,4)
b:Show()
end

l.onStart("kit note",function()a.note()end)

function a.noteText()return b and b:IsShown()and b.text:GetText()or nil end


function a.linePx(b,c)
local a=math.floor(c*b:GetEffectiveScale()/UIParent:GetEffectiveScale()+0.5)
if c>0 and a<1 then a=1 end
return a*i.pixel(b)
end

function a.cropIcon(a)a:SetTexCoord(0.08,0.92,0.08,0.92)end


function a.disc(c,b,d)
local b=c:CreateTexture(nil,b,nil,d)
local c=c:CreateMaskTexture()
c:SetTexture(a.art("round"),"CLAMPTOBLACKADDITIVE","CLAMPTOBLACKADDITIVE")
c:SetAllPoints(b)
b:AddMaskTexture(c)
return b
end



local b,f=0.0625,1-0.0625
function a.edgeArt(g,h,d,i,j)
local e={}
local function c()
local b=g:CreateTexture(nil,i or"BORDER",nil,j)
b:SetTexture(d.file,"REPEAT","REPEAT")
b:SetVertexColor(a.rgba(d.tint or"white"))
e[#e+1]=b
return b
end
local a,d=d.size,d.out or 0
local i,j,k,l=c(),c(),c(),c()
for e,c in ipairs({{i,"TOPLEFT",0.5078125,-1,1},{j,"TOPRIGHT",0.6328125,1,1},
{k,"BOTTOMLEFT",0.7578125,-1,-1},{l,"BOTTOMRIGHT",0.8828125,1,-1}})do
c[1]:SetSize(a,a)
c[1]:SetPoint(c[2],h,c[2],c[4]*d,c[5]*d)
c[1]:SetTexCoord(c[3],c[3]+0.109375,b,f)
end
local c,f,g,h=c(),c(),c(),c()
c:SetPoint("TOPLEFT",i,"BOTTOMLEFT");c:SetPoint("BOTTOMLEFT",k,"TOPLEFT");c:SetWidth(a)
f:SetPoint("TOPRIGHT",j,"BOTTOMRIGHT");f:SetPoint("BOTTOMRIGHT",l,"TOPRIGHT");f:SetWidth(a)
g:SetPoint("TOPLEFT",i,"TOPRIGHT");g:SetPoint("TOPRIGHT",j,"TOPLEFT");g:SetHeight(a)
h:SetPoint("BOTTOMLEFT",k,"BOTTOMRIGHT");h:SetPoint("BOTTOMRIGHT",l,"BOTTOMLEFT");h:SetHeight(a)
local i={pieces=e}

function i.lay(e,i)
local e=math.max(e+2*d-2*a,1)/a
local a=math.max(i+2*d-2*a,1)/a
c:SetTexCoord(0.0078125,b,0.0078125,a,0.1171875,b,0.1171875,a)
f:SetTexCoord(0.1328125,b,0.1328125,a,0.2421875,b,0.2421875,a)
g:SetTexCoord(0.2578125,e,0.3671875,e,0.2578125,b,0.3671875,b)
h:SetTexCoord(0.3828125,e,0.4921875,e,0.3828125,b,0.4921875,b)
end
function i.shown(a)
for c,b in ipairs(e)do b:SetShown(a)end
end
return i
end



local e={{"TOPLEFT",0,1,0,1},{"TOPRIGHT",1,0,0,1},{"BOTTOMLEFT",0,1,1,0},
{"BOTTOMRIGHT",1,0,1,0}}
function a.ornaments(c,g,b)
local f={}
for d,e in ipairs(e)do
local d=e[1]
if b.corners[d]then
local c=c:CreateTexture(nil,"ARTWORK",nil,7)
c:SetTexture(b.file)
c:SetSize(b.size,b.size)
c:SetPoint(d,g,d,(d:find("LEFT")and 1 or-1)*b.inset,(d:find("TOP")and-1 or 1)*b.inset)
c:SetTexCoord(e[2],e[3],e[4],e[5])
c:SetVertexColor(a.rgba(b.tint or"ornament",b.alpha))
c.corner=d
f[#f+1]=c
end
end
return f
end



function a.cornerRoom(c,b)
local a=a.theme.panel[c]
local a=a and a.ornament
if not a then return b end

return math.max(a.inset+a.size+8,b)
end



function a.coverCoords(a,c,d)
local a,b,e,f=a[1],a[2],a[3],a[4]
if c<=0 or d<=0 then return 0,a/e,0,b/f end
if c/d<a/b then
local c=b*c/d
return(a-c)/e,a/e,0,b/f
end
local c=a*d/c
local b=(b-c)/2
return 0,a/e,b/f,(b+c)/f
end





local b={}
b.__index=b
function a.panel(c,e,f,g,d)
local b=setmetatable({fill=c:CreateTexture(nil,g or"BACKGROUND"),edges={},extras={},
fillToken=e or"panelFill"},b)
a.fill(b.fill,b.fillToken)
for d=1,4 do
b.edges[d]=c:CreateTexture(nil,"BORDER")
a.fill(b.edges[d],f or"panelEdge")
end
local a=d and a.theme.panel[d]
if a then b:dress(c,a)end
return b
end
function b:dress(c,b)
local d=self.extras
if b.ground then a.gradient(self.fill,b.ground[1],b.ground[2])end
if b.shine then
local c=c:CreateTexture(nil,"BORDER",nil,1)
a.fill(c,b.shine)
c:SetHeight(1)
c:SetPoint("TOPLEFT",self.fill,"TOPLEFT",1,-1)
c:SetPoint("TOPRIGHT",self.fill,"TOPRIGHT",-1,-1)
d[#d+1]=c
end
if b.edge then

local c=CreateFrame("Frame",nil,c)
c:SetAllPoints(self.fill)
local a=a.edgeArt(c,c,b.edge,"BORDER",2)
c:SetScript("OnSizeChanged",function(d,b,c)a.lay(b,c)end)
a.lay(1,1)
self.edgeHolder=c
for a=1,4 do self.edges[a]:SetAlpha(0)end
end
if b.ornament then
self.ornaments=a.ornaments(c,self.fill,b.ornament)
for b,a in ipairs(self.ornaments)do d[#d+1]=a end
end
end

function b:place(c,d,e)
local b,a=self.fill,self.edges
b:ClearAllPoints()
b:SetPoint("TOPLEFT",d[1],d[2],d[3],d[4])
b:SetPoint("BOTTOMRIGHT",e[1],e[2],e[3],e[4])
for b=1,4 do a[b]:ClearAllPoints()end
a[1]:SetPoint("TOPLEFT",b);a[1]:SetPoint("TOPRIGHT",b);a[1]:SetHeight(c)
a[2]:SetPoint("BOTTOMLEFT",b);a[2]:SetPoint("BOTTOMRIGHT",b);a[2]:SetHeight(c)
a[3]:SetPoint("TOPLEFT",b);a[3]:SetPoint("BOTTOMLEFT",b);a[3]:SetWidth(c)
a[4]:SetPoint("TOPRIGHT",b);a[4]:SetPoint("BOTTOMRIGHT",b);a[4]:SetWidth(c)
self:setShown(true)
end
function b:setShown(a)
self.fill:SetShown(a)
for b=1,4 do self.edges[b]:SetShown(a)end
for c,b in ipairs(self.extras)do b:SetShown(a)end
if self.edgeHolder then self.edgeHolder:SetShown(a)end
end

function b:cover(a,b)
self:place(b,{a,"TOPLEFT",0,0},{a,"BOTTOMRIGHT",0,0})
end

function b:fitArt(c,d)
local b=a.theme.fillArt[self.fillToken]
if b and b.cover then self.fill:SetTexCoord(a.coverCoords(b.cover,c,d))end
end


a.EDGE=4






a.LINK_H=18
local e,f=8,6
a.LINK_PAD_X,a.LINK_PAD_Y=e,f
function a.textLink(b,g,c,d)
local b=CreateFrame("Button",nil,b)
if d then b:SetHitRectInsets(-e,-e,-f,-f)end
b.text=b:CreateFontString(nil,"OVERLAY",a.font("small"))
b.text:SetPoint("LEFT")
b:SetScript("OnClick",c)
b:SetMotionScriptsWhileDisabled(true)
local c,d="link","gold"
function b:rested()a.tint(self.text,self:IsEnabled()and c or"dimText")end
b:SetScript("OnEnter",function()if b:IsEnabled()then a.tint(b.text,d)end end)
b:SetScript("OnLeave",function()b:rested()end)
a.tint(b.text,c)

function b:setEnabled(a)
self:SetEnabled(a and true or false)
self:rested()
end
function b:leaves()
c,d="linkText","goldLight"
self:rested()
return self
end
function b.say(c)
b.text:SetText(c)
b:SetSize(b.text:GetStringWidth()+2,a.LINK_H)
end
b.say(g)
return b
end



function a.linkTag(b)
a.fill(b.ground.fill,"linkTagFill")
for c,b in ipairs(b.ground.edges)do a.fill(b,"accent")end
a.tint(b.text,"accent")
b:HookScript("OnEnter",function()
a.fill(b.ground.fill,"linkTagLit")
a.tint(b.text,"gold")
end)
b:HookScript("OnLeave",function()
a.fill(b.ground.fill,"linkTagFill")
a.tint(b.text,"accent")
end)
return b
end


a.fmt={
pct=function(a)return string.format("%.0f%%",a*100)end,
times=function(a)return string.format("%.2fx",a)end,
int=function(a)return string.format("%d",a)end,
px=function(a)return string.format("%d px",a)end,
secs=function(a)return string.format("%.1f s",a)end,
}


function a.stepDecimals(a)
local a=string.format("%.4f",a or 1):gsub("0+$",""):match("%.(%d+)$")
return a and#a or 0
end


function a.unitFormat(b,c)
local a="%."..a.stepDecimals(c).."f"..((b=="%"or b=="x")and""or" ")
..(b:gsub("%%","%%%%"))
return function(b)return string.format(a,b)end
end


function a.plainFormat(b)
local a="%."..a.stepDecimals(b).."f"
return function(b)
local a=string.format(a,b)
if a:find("%.")then a=a:gsub("0+$",""):gsub("%.$","")end
return a
end
end




local function b()return d.ui()end

local function h(a,b)
for c,a in ipairs(a or{})do
if a==b then return true end
end
return false
end
local function f(b,c)
local a={}
for d,b in ipairs(b or{})do
if b~=c then a[#a+1]=b end
end
return a
end


local g,e=200,64
a.KEY_MAX=e

function a.isFolded(a)return h(b().folded,a)end
function a.setFolded(b,c)
if#b>e then error("Kit: a fold key over "..e.." characters: "..b,2)end

if b:find("|",1,true)then error("Kit: a fold key with a |: "..b,2)end
if a.isFolded(b)==(c and true or false)then return true end
return d.editUI(function(d)
local a=f(d.folded,b)
if c then
while#a>=g do table.remove(a,1)end
a[#a+1]=b
end
d.folded=#a>0 and a or nil
end)
end

function a.setFoldedAll(b,e)
return d.editUI(function(c)
local a=c.folded or{}
for c,b in ipairs(b)do a=f(a,b)end
if e then
for c,b in ipairs(b)do a[#a+1]=b end
while#a>g do table.remove(a,1)end
end
c.folded=#a>0 and a or nil
end)
end


function a.windowScaleRange()
local a=c.Schema.field("uiState","windowScale")
return a.min,a.max,a.step
end
local function e(b)
if type(b)~="number"then return end
local a,d,c=a.windowScaleRange()
b=a+math.floor((b-a)/c+0.5)*c
return tonumber(string.format("%.4f",math.min(math.max(b,a),d)))
end
function a.windowScale()return e(b().windowScale or 1)or 1 end
function a.setWindowScale(a)
a=e(a)
if not a then return false end
return d.editUI(function(b)b.windowScale=a~=1 and a or nil end)
end


function a.listWidthRange()
local a=c.Schema.field("uiState","listWidth")
return a.min,a.max
end
local function e(b)
if type(b)~="number"then return end
local a,c=a.listWidthRange()
return math.floor(math.min(math.max(b,a),c)+0.5)
end
function a.listWidth()return e(b().listWidth)or a.LIST_W end
function a.setListWidth(b)
b=e(b)
if not b then return false end
return d.editUI(function(c)c.listWidth=b~=a.LIST_W and b or nil end)
end


function a.contentsWidthRange()
local a=c.Schema.field("uiState","contentsWidth")
return a.min,a.max
end
local function c(b)
if type(b)~="number"then return end
local a,c=a.contentsWidthRange()
return math.floor(math.min(math.max(b,a),c)+0.5)
end
function a.contentsWidth()return c(b().contentsWidth)or a.metric("list","width")end
function a.setContentsWidth(b)
b=c(b)
if not b then return false end
local a=a.metric("list","width")
return d.editUI(function(c)c.contentsWidth=b~=a and b or nil end)
end
