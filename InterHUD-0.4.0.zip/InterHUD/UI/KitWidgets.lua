









local a,h=...
local a=h.Kit
local k=h.Ticker
local b=h.Sounds


local function d(b)return a.theme.metric[(b and b.dense)and"pane"or"form"]end
local i=a.WIDTH-a.LIST_W-64
local j=600




function a.fieldSpan(b,e,f)

b.hasField=true
local c=d(f)
local d=(e or b.width or i)-c.labelW-a.EDGE
local a=math.min(d-a.rowMarksRoom(b,e,f)-(b.keepRight or 0),c.fieldMax)
if a<c.fieldMin then a=math.min(c.fieldMin,d)end
return math.max(a,40)
end



function a.row(a,b)
local a=CreateFrame("Frame",nil,a)
a:SetSize(i,b)
a.height,a.width=b,i
return a
end


local function e(a,c)
a.refresh=function(b)
if b then a.width=b end
c(a.width)
end
return a
end
a.finishRow=e

function a.label(b,c,f,e)
b:EnableMouse(true)
a.setTip(b,c,f,"above")
local a=a.fontString(b,d(e).label)
a:SetPoint("LEFT",4,0)
a:SetWidth(d(e).labelW-8)
a:SetJustifyH("LEFT")
a:SetText(c)

b.rowLabel=a
return a
end



function a.checkbox(b,f,h,g,i,c)
local d=d(c)
local c=a.row(b,d.check)
local b=a.checkBox(c,d.checkBox)
b:SetPoint("LEFT",3,0)
a.setFont(b.Text,d.label)
b.Text:ClearAllPoints()
b.Text:SetPoint("LEFT",b,"RIGHT",6,0)
b.Text:SetText(f)
b:SetHitRectInsets(0,-(b.Text:GetStringWidth()+8),0,0)

b:SetScript("OnClick",function()
i(not(g()and true or false))
c.refresh()
end)
a.setTip(b,f,h)
c.check,c.tail=b,b.Text
c.says=function()return g()and f or nil end
return e(c,function()b:setChecked(g()and true or false)end)
end


local n,l=0.12,0.24
local g={}
local function f(a,b,c)return a+(b-a)*c end


local c={}
local function o()
local b,d=GetTime(),false
for a in pairs(c)do
local b=math.min((b-a.t0)/a.dur,1)
if a.dur==l then a.shake=math.sin(b*math.pi*2)*(1-b)
else a.at=f(a.from,a.goal,b)end
if b>=1 then
a.shake,c[a]=nil,nil
a.at=a.goal
else
d=true
end
a:paint()
end
if not d then k.unsubscribe(0,"kit switches")end
end
local function m(a,b)
a.from,a.t0,a.dur,a.shake=a.at,GetTime(),b,nil
c[a]=true
k.subscribe(0,"kit switches",o)
end

function g:show(b)
local d=b and 1 or 0
if self.text then
self.text:SetText(b and"On"or"Off")
a.tint(self.text,b and"gold"or"off")
end
if d==self.goal and self.at~=nil then
if not c[self]then self:paint()end
return
end
self.goal=d

if self.at==nil or self.instant or not self:IsVisible()then
self.at,c[self],self.shake=d,nil,nil
self:paint()
else
m(self,n)
end
end
function g:nudge()
if self:IsVisible()and not c[self]then m(self,l)end
end

local function c(b,c,e,f,h,d)
local b=CreateFrame("Button",nil,b)
for a,c in pairs(g)do b[a]=c end
function b.flip()
local a=c()and true or false
e(not a)
local c=c()and true or false
b:show(c)
if c==a then b:nudge()end
end
b:SetScript("OnClick",b.flip)
a.setTip(b,f,h)
b:HookScript("OnEnter",function(a)a.hover=true;if a.at then a:paint()end end)
b:HookScript("OnLeave",function(a)a.hover=nil;if a.at then a:paint()end end)
if d then

b.text=b:CreateFontString(nil,"OVERLAY",d)
b.text:SetPoint("LEFT",b,"RIGHT",6,0)
b:SetHitRectInsets(0,-44,0,0)
end
return b
end


local k={
normal={w=70,h=31,fillIn=8,fillH=15,knob=21},
small={w=34,h=18,fillIn=4,fillH=9,knob=13},
}
local function g(c,b)
local c,d=c and"knobOnLow"or"knobOnHigh",c and"knobOffLow"or"knobOffHigh"
local d,e,g=a.rgba(d)
local a,c,h=a.rgba(c)
return CreateColor(f(d,a,b),f(e,c,b),f(g,h,b),1)
end
local function f(a)
local c,b=a.at,a.dims
local d=b.w-2*b.fillIn-b.fillH
local d=b.fillIn+b.fillH/2+d*c+(a.shake or 0)*4
a.knob:ClearAllPoints()
a.knob:SetPoint("CENTER",a,"LEFT",d,0)
a.fill:SetWidth(math.max(d-b.fillIn,0.01))
a.fill:SetShown(c>0)
a.knobFace:SetGradient("VERTICAL",g(true,c),g(false,c))
a.groove:lit(a.hover)
end

local function g(b)
local c,d=b.at,b.dims
local e=d.w-d.knob
local e=d.knob/2+e*c+(b.shake or 0)*3
b.knob:ClearAllPoints()
b.knob:SetPoint("CENTER",b,"LEFT",e,0)
local f=(d.groove-d.fillH)/2
b.band:SetWidth(math.max(e-(f+d.fillH/2),0.01))
b.cap:SetShown(c>0)
b.band:SetShown(c>0)
b.cap:SetAlpha(math.min(c*3,1))
b.band:SetAlpha(math.min(c*3,1))
b.gemOn:SetAlpha(c)
b.gemOff:SetAlpha(1-c)
b.ring:SetVertexColor(a.rgba(b.hover and"artLit"or"artRest"))
end
local function l(b,e,c)
b.dims=c
b:SetSize(c.w,c.h)
b.paint=g
local d=CreateFrame("Frame",nil,b)
d:SetPoint("LEFT")
d:SetPoint("RIGHT")
d:SetHeight(c.groove)
local f,h,g=d:CreateTexture(nil,"BORDER"),d:CreateTexture(nil,"BORDER"),
d:CreateTexture(nil,"BORDER")
f:SetAtlas(e.groove[1])
h:SetAtlas(e.groove[2])
g:SetAtlas(e.groove[3])
f:SetSize(c.endW,c.groove)
g:SetSize(c.endW,c.groove)
f:SetPoint("LEFT")
g:SetPoint("RIGHT")
h:SetPoint("TOPLEFT",f,"TOPRIGHT")
h:SetPoint("BOTTOMRIGHT",g,"BOTTOMLEFT")

c.fillH=c.groove-6
local f=(c.groove-c.fillH)/2
b.cap=a.disc(d,"ARTWORK",0)
b.cap:SetSize(c.fillH,c.fillH)
b.cap:SetPoint("LEFT",d,"LEFT",f,0)
b.band=d:CreateTexture(nil,"ARTWORK",nil,1)
b.band:SetHeight(c.fillH)
b.band:SetPoint("LEFT",d,"LEFT",f+c.fillH/2,0)
for c,b in ipairs({b.cap,b.band})do
a.fill(b,"white")
b:SetGradient("VERTICAL",a.colorObj("knobOnLow"),a.colorObj("knobOnHigh"))
end

b.knob=CreateFrame("Frame",nil,b)
b.knob:SetSize(c.knob,c.knob)
b.knob:SetFrameLevel(d:GetFrameLevel()+2)

b.ring=b.knob:CreateTexture(nil,"ARTWORK")
b.ring:SetAtlas(e.ring)
b.ring:SetAllPoints()
b.gemOff=b.knob:CreateTexture(nil,"OVERLAY",nil,0)
b.gemOff:SetAtlas(e.gem)
b.gemOff:SetAllPoints()
b.gemOff:SetDesaturated(true)
b.gemOff:SetVertexColor(0.7,0.7,0.7,1)
b.gemOn=b.knob:CreateTexture(nil,"OVERLAY",nil,1)
b.gemOn:SetAtlas(e.gem)
b.gemOn:SetAllPoints()
return b
end

function a.pillSwitch(b,e,g,h,i,j,d)
local b=c(b,e,g,h,i,j)
local c=a.theme.switch
if c then return l(b,c,c[d and"small"or"normal"])end
local c=k[d and"small"or"normal"]
b.dims=c
b:SetSize(c.w,c.h)
b.paint=f
local d=(c.h-c.fillH)/2-2
b.groove=a.field(b,{b,"TOPLEFT",c.fillIn-2,-d},{b,"BOTTOMRIGHT",-c.fillIn+2,d})
b.fill=b:CreateTexture(nil,"ARTWORK")
a.gradient(b.fill,"knobOnHigh","knobOnLow")
b.fill:SetPoint("LEFT",b,"LEFT",c.fillIn,0)
b.fill:SetHeight(c.fillH)
b.knob=a.disc(b,"OVERLAY",0)
b.knob:SetSize(c.knob,c.knob)
a.fill(b.knob,"knobRim")
b.knobFace=a.disc(b,"OVERLAY",1)
b.knobFace:SetSize(c.knob-2,c.knob-2)
b.knobFace:SetPoint("CENTER",b.knob)
a.fill(b.knobFace,"white")
local d=a.disc(b,"OVERLAY",2)
d:SetSize(c.knob/2,c.knob/3)
d:SetPoint("TOP",b.knob,"TOP",0,-2)
a.fill(d,"knobShine")
return b
end


function a.switch(b,c,h,f,i,g)
local b=a.row(b,d(g).row)
b.label=a.label(b,c,h,g)
local a=a.pillSwitch(b,f,i,c,h,a.font("label"))
a:SetPoint("LEFT",b,"LEFT",d(g).labelW,0)
b.switch,b.tail=a,a.text
b.says=function()return f()and c or nil end
return e(b,function()a:show(f()and true or false)end)
end






local r="%-?%d*%.?%d+"
local c,s,f=56,8,8





local function v(d,g,h,i)
local e,b="0",0
for c=0,9 do
local a=a.textWidth(d,tostring(c))
if a>b then e,b=tostring(c),a end
end
local b=0
for f,c in ipairs({h,i})do
b=math.max(b,a.textWidth(d,(g(c):gsub("%d",e))))
end
local a=math.ceil(b+2*a.EDIT_INSET)
if a<=c then return c end
return a+f
end

local function c(c,a,b)
for b,a in ipairs({b,a})do
local b=tonumber(c(a):match(r)or"")
if b and a~=0 then
local b=math.abs(b-a*100)<math.abs(b-a)and 100 or 1
local a=c(a):match("%d%.(%d+)")
return b,a and#a or 0
end
end
return 1,0
end

function a.slider(g,k,n,l,o,b)
local f,h,m=b.min,b.max,b.step or 1
local t,u=math.max(b.softMin or f,f),math.min(b.softMax or h,h)
local p=b.fallback
local function q()return l()or(p and p())or f end
local i=b.format or(b.unit and a.unitFormat(b.unit,m))or a.plainFormat(m)
local j=d(b)
local d=a.row(g,j.row)

if not b.bare then d.label=a.label(d,k,n,b)end

local n,k=1,a.stepDecimals(m)
if b.format then n,k=c(i,f,h)end
local c

local g=a.sliderBar(d,function(a)

if a~=l()then o(a)end
c:ClearFocus()
d.refresh()
end,{onMove=function(a)if not c:HasFocus()then c:SetText(i(a))end end,
onRelease=function()d.refresh()end})
g:SetPoint("LEFT",d,"LEFT",b.bare and 0 or j.labelW,0)
g:setRange(t,u,m)
local m=v(j.fieldFont,i,f,h)
c=a.editBox(d,m,j.box,j.fieldFont)
c:SetPoint("LEFT",g,"RIGHT",s,0)
c:SetMaxLetters(8)
c:SetJustifyH("CENTER")
c:SetScript("OnEditFocusGained",function(b)
local a=string.format("%."..k.."f",q()*n)
if k>0 then a=a:gsub("0+$",""):gsub("%.$","")end
b:SetText(a)
b:HighlightText()
end)
c:SetScript("OnEditFocusLost",function(a)
a:HighlightText(0,0)
a:SetText(i(q()))
end)
c:SetScript("OnEscapePressed",function(a)a:ClearFocus()end)
c:SetScript("OnEnterPressed",function(b)
local c=b:GetText():gsub(",",".")
local a=tonumber(c:match(r)or"")
if p and c:match("^%s*$")then

if l()~=nil then o(nil)end
elseif a then
local b=10^k
a=math.floor(a*b+0.5)/b/n

local a=tonumber(string.format("%."..(k+(n==100 and 2 or 0)).."f",a))
a=math.min(math.max(a,f),h)
if a~=l()then o(a)end
end
b:ClearFocus()
d.refresh()
end)
d.slider,d.box,d.tail=g,c,c
return e(d,function(e)

local a=b.bare and(e or d.width)or a.fieldSpan(d,e,b)

g:setWidth(math.max(a-s-m,b.bare and 60 or 80))

local a=q()
g:setValue(math.min(math.max(a,t),u))
if not c:HasFocus()then c:SetText(i(a))end
end)
end






function a.textbox(b,h,i,g,j,c)
c=c or{}
local f=d(c)
local b=a.row(b,f.row)
b.label=a.label(b,h,i,c)
local d=a.editBox(b,c.width or f.dropdownW,f.box,f.fieldFont)
d:SetPoint("LEFT",b,"LEFT",f.labelW,0)
d:SetMaxLetters(c.maxLetters or 64)


if c.maxBytes then d:SetMaxBytes(c.maxBytes+1)end
d:SetScript("OnEnterPressed",function(a)a:ClearFocus()end)
b.tail=d
if c.unit then
b.unit=a.fontString(b,f.label)
b.unit:SetPoint("LEFT",d,"RIGHT",6,0)
b.unit:SetText(c.unit)
b.tail=b.unit
end

if c.action then
local a=a.button(b,c.action.text,c.action.width or 110,f.box)
a:SetPoint("LEFT",b.tail,"RIGHT",8,0)
a:SetScript("OnClick",function(a)c.action.click(a)end)
b.action,b.tail=a,a
end
if c.note then
b.note=b:CreateFontString(nil,"OVERLAY",a.font("small"))
b.note:SetPoint("LEFT",b.tail,"RIGHT",8,0)
b.note:SetWordWrap(false)
a.tint(b.note,"help")
b.tail=b.note
end


local h

local function i()
if b.refused==nil then return end
b.refused=nil
a.repaint()
end
d:SetScript("OnEscapePressed",function(a)
i()
a:SetText(g()or"")
a:ClearFocus()
end)
d:SetScript("OnEditFocusLost",function(e)
e:HighlightText(0,0)
local d=strtrim(e:GetText())
if d==b.refused then return end
i()
if d~=(g()or"")and not j(d)and c.keep and c.keep(d)then
b.refused,h=d,g()or""
a.repaint()
return
end
e:SetText(g()or"")
end)
b.box=d

if c.hint then
b.hint=a.fontString(b,f.fieldFont)
b.hint:SetPoint("LEFT",d,"LEFT",6,0)
b.hint:SetPoint("RIGHT",d,"RIGHT",-6,0)
b.hint:SetJustifyH("LEFT")
b.hint:SetWordWrap(false)
a.tint(b.hint,"off")
local function a()b.hint:SetShown(not d:HasFocus()and d:GetText()==""and b.hint:GetText()~="")end
d:HookScript("OnEditFocusGained",function()b.hint:Hide()end)
d:HookScript("OnEditFocusLost",a)
b.showHint=a
end



local f=not(c.width or c.unit or c.note)
return e(b,function(e)
if f then
d:SetWidth(math.max(a.fieldSpan(b,e,c)-(b.action and b.action:GetWidth()+8 or 0),40))
end
if b.refused and(g()or"")~=h then b.refused=nil end
if not d:HasFocus()then d:SetText(b.refused or g()or"")end
if b.hint then
b.hint:SetText(c.hint()or"")
b.showHint()
end
if b.note then
local a=c.note
b.note:SetText(type(a)=="function"and a()or a)
end
end)
end







local function k(e,b,d)
local function f()return type(b.choices)=="function"and b.choices()or b.choices end
local c=CreateFrame("DropdownButton",nil,e,"WowStyle1DropdownTemplate")
c:SetSize(b.width or d.dropdownW,d.field)
c.Text:SetFontObject(a.font(d.fieldFont))


c.Text:ClearAllPoints()
c.Text:SetPoint("LEFT",8,0)
c.Text:SetPoint("RIGHT",c.Arrow,"LEFT")


local d=a.fontColor(d.fieldFont)
function c:OnButtonStateChanged()
WowStyle1DropdownMixin.OnButtonStateChanged(self)
a.tint(self.Text,self:IsEnabled()and d or"off")
end
c:OnButtonStateChanged()



c:SetupMenu(function(c,d)
d:AddMenuAcquiredCallback(function(a)a:SetScale(c:GetEffectiveScale())end)
local g,c=b.get and b.get(),0
for f,a in ipairs(f())do
if b.multi then
c=c+1
local c=a[1]
d:CreateCheckbox(a[2],function()return b.multi.has(c)end,function()
b.multi.toggle(c)
e.refresh()
end)
elseif a[1]==g or not b.offered or b.offered(a[1])then
c=c+1
local c=a[1]
d:CreateRadio(a[2],function()return b.get()==c end,function()
b.set(c)
e.refresh()
end)
end
end
if c>a.MENU_ROWS then d:SetScrollMode(a.MENU_ROWS*a.MENU_ROW_H)end
end)
c:RegisterCallback(DropdownButtonMixin.Event.OnMenuOpen,function()
a.closeMenu()
a.closeAsk()
a.closePicker()
end,c)

c:HookScript("OnHide",function(a)a:CloseMenu()end)
local function a()
if b.multi then return c:OverrideText(b.multi.words())end
local a,b=b.get(),nil
for d,c in ipairs(f())do
if c[1]==a then
b=c[2]
break
end
end
c:OverrideText(b or(a~=nil and tostring(a))or"")
end
return c,a
end






function a.dropdown(c,g,h,i,j,b)
b=b or{}
local f=d(b)
local c=a.row(c,f.row)
c.label=a.label(c,g,h,b)
local d,g=k(c,{get=i,set=j,choices=b.choices,offered=b.offered,
width=b.width,multi=b.multi},f)
d:SetPoint("LEFT",c,"LEFT",f.labelW,0)
c.dropdown,c.tail=d,d

return e(c,function(e)
if not b.width then d:SetWidth(a.fieldSpan(c,e,b))end
g()
end)
end





local f,g=40,4
function a.picturePicker(c,h,j,i,n,b)
b=b or{}
local d=d(b)
local c=a.row(c,d.row)
c.label=a.label(c,h,j,b)
c.label:ClearAllPoints()
c.label:SetPoint("LEFT",c,"TOPLEFT",4,-d.row/2)
local h,j
local function l()return b.families and b.families()or{}end
local function m()
local a=i()
if a~=j then h,j=nil,a end
local c=l()
local b=h or(b.familyOf and b.familyOf(a))
for c,a in ipairs(c)do
if a.key==b then return a end
end
return c[1]
end
local b,j=k(c,{get=function()
local a=m()
return a and a.key
end,set=function(b)
h=b
a.repaint()
end,choices=function()
local a={}
for c,b in ipairs(l())do a[#a+1]={b.key,b.label}end
return a
end},d)
b:SetPoint("LEFT",c,"TOPLEFT",d.labelW,-d.row/2)
c.dropdown=b
local h,l={},1
local function o(d)
local b=h[d]
if b then return b end
b=CreateFrame("Button",nil,c)
b:SetSize(f,f)
b:EnableMouse(true)
b.ground=a.panel(b,"shade","panelEdge")
b.ground:cover(b,1)
b.pic=b:CreateTexture(nil,"ARTWORK")
b.pic:SetPoint("CENTER")
local e=b:CreateTexture(nil,"HIGHLIGHT")
e:SetAllPoints()
a.fill(e,"lit")
b.ring={}
for d=1,4 do
local c=b:CreateTexture(nil,"OVERLAY")
c:SetColorTexture(a.rgba("gold"))
b.ring[d]=c
end
b.ring[1]:SetPoint("TOPLEFT");b.ring[1]:SetPoint("TOPRIGHT");b.ring[1]:SetHeight(2)
b.ring[2]:SetPoint("BOTTOMLEFT");b.ring[2]:SetPoint("BOTTOMRIGHT");b.ring[2]:SetHeight(2)
b.ring[3]:SetPoint("TOPLEFT");b.ring[3]:SetPoint("BOTTOMLEFT");b.ring[3]:SetWidth(2)
b.ring[4]:SetPoint("TOPRIGHT");b.ring[4]:SetPoint("BOTTOMRIGHT");b.ring[4]:SetWidth(2)
b:SetScript("OnClick",function(a)
if a.key~=nil and a.key~=i()then n(a.key)end
c.refresh()
end)
b.simRole="button"
h[d]=b
return b
end
local function k(b)
return math.max(1,math.floor((b-d.labelW-a.EDGE+g)/(f+g)))
end
c.height=function()return d.row+4+l*(f+g)end
return e(c,function(e)
j()
local j=m()
local b=j and j.pictures or{}
local k=k(e)
l=math.max(1,math.ceil(#b/k))
local i=i()
for h,e in ipairs(b)do
local b=o(h)
b.key,b.simLabel=e.key,e.name
local h,k=(h-1)%k,math.floor((h-1)/k)
b:ClearAllPoints()
b:SetPoint("TOPLEFT",c,"TOPLEFT",d.labelW+h*(f+g),
-(d.row+4+k*(f+g)))
b.pic:SetTexture(e.file)
local c=f-6
if e.shape=="top"then b.pic:SetSize(c,c/2)else b.pic:SetSize(c/2,c)end
local c=e.key==i
for b,a in ipairs(b.ring)do a:SetShown(c)end
b.simState=c and"selected"or nil
a.setTip(b,e.name,j.label)
b:Show()
end
for a=#b+1,#h do h[a]:Hide()end
c:SetHeight(c.height())
end)
end


a.LIST_X=28




local f=3
function a.color(c,i,j,k,l,b)
b=b or{}
local g=b.opaque
local d=d(b)
local c=a.row(c,d.check)
c.label=a.label(c,i,j,b)
local b=CreateFrame("Button",nil,c)
b:SetSize(d.swatch,d.swatch)
b:SetPoint("LEFT",c,"LEFT",d.labelW,0)
a.panel(b,"shade","swatchEdge"):cover(b,1)
b.swatch=b:CreateTexture(nil,"ARTWORK")
b.swatch:SetPoint("TOPLEFT",2,-2)
b.swatch:SetPoint("BOTTOMRIGHT",-2,2)


b.cells={}
local d=(d.swatch-4)/f
for c=0,f-1 do
for e=0,f-1 do
local a=b:CreateTexture(nil,"ARTWORK",nil,-1)
a:SetSize(d,d)
a:SetPoint("TOPLEFT",b.swatch,"TOPLEFT",c*d,-e*d)
a.light=(c+e)%2==0
b.cells[#b.cells+1]=a
end
end
b:SetScript("OnClick",function()
local b=k()
local d,f,i,j=a.parseColor(b)


if not d then d,f,i,j=1,1,1,1 end

local e=b
local function k()
local d,f,i=ColorPickerFrame:GetColorRGB()
local b=not g and ColorPickerFrame:GetColorAlpha()or nil
local j,k,m=a.parseColor(e)

local j=not j or a.colorString(d,f,i,nil,true)~=a.colorString(j,k,m,nil,true)
if j and b and b<0.5/255 then
b=1

local a=ColorPickerFrame.Content
if a and a.ColorPicker then
h.try("colour picker opacity",a.ColorPicker.SetColorAlpha,a.ColorPicker,1)
end
end
local a=a.colorString(d,f,i,b,g)
if a==e then return end
e=a
l(a)
c.refresh()
end
ColorPickerFrame:SetupColorPickerAndShow({
r=d,g=f,b=i,opacity=j,hasOpacity=not g,
swatchFunc=k,opacityFunc=k,
cancelFunc=function()
l(b)
c.refresh()
end,
})
end)
a.setTip(b,i,j)
c.swatchButton,c.tail=b,b
return e(c,function()
local c,e,f,d=a.parseColor(k())
local g=c==nil or(d or 1)<1
for c,b in ipairs(b.cells)do
if b.light then a.fill(b,"off")else a.fill(b,"white",0.85)end
b:SetShown(g)
end
if c then b.swatch:SetColorTexture(c,e,f,d)end
b.swatch:SetShown(c~=nil)
end)
end


a.SOUND_NOTE="Full sound library is under construction."




function a.sound(f,g,h,d,i,c)
c=c or{}
local j=c.choices or function()
local a={{false,"None"}}
local e={}
for d,c in ipairs(b.names())do
a[#a+1]={c,b.choiceLabel(c)}
e[c]=true
end

local c=d()
if c and not e[c]then a[#a+1]={c,b.choiceLabel(c)or c}end
return a
end
local c=a.dropdown(f,g,h,function()return d()or false end,function(a)
i(a or nil)
if a then b.play(a)end
end,{choices=j,width=200,offered=c.offered,dense=c.dense})
local a=a.button(c,"Play",60,22)
a:SetPoint("LEFT",c.dropdown,"RIGHT",8,0)
a:SetScript("OnClick",function()b.play(d())end)
c.play,c.tail=a,a
local f=c.refresh
return e(c,function(c)
f(c)
a:setEnabled(b.playable(d()))
end)
end





function a.fieldRow(e,c,f,g,b)
b=b or{}
local d,h=c.field,c.widget
local i=d and d.tip
if b.unit==nil then b.unit=c.unit end
if h=="toggle"then return a.checkbox(e,c.label,i,f,g,b)end
if h=="choice"then return a.dropdown(e,c.label,i,f,g,b)end
if h=="percent"then
b.min,b.max,b.step=0,100,1
return a.slider(e,c.label,i,f,g,b)
end
if h=="slider"then
b.min,b.max,b.step=d.min,d.max,d.step or(d.type=="integer"and 1 or nil)
b.softMin,b.softMax=d.softMin,d.softMax
return a.slider(e,c.label,i,f,g,b)
end
if h=="colour"then return a.color(e,c.label,i,f,g,b)end
if h=="sound"then return a.sound(e,c.label,i,f,g,b)end

if h=="picture"then return a.picturePicker(e,c.label,i,f,g,b)end
end


function a.buttons(b,c)
local b=a.row(b,32)
local f=0
b.buttons={}
for g,c in ipairs(c)do
local e=c.width or 140
local d=a.button(b,c.text,e,22)
d:SetPoint("LEFT",f,0)
d:SetScript("OnClick",function(a)c.click(a);b.refresh()end)
a.setTip(d,c.text,c.tip)
b.buttons[g]=d
f=f+e+6
end
return e(b,function()
for c,a in ipairs(c)do
if a.enabled then b.buttons[c]:setEnabled(a.enabled())end
end
end)
end



function a.text(b,c,d)
local b=a.row(b,20)
b.text=b:CreateFontString(nil,"OVERLAY",a.font("small"))
a.tint(b.text,"help")
b.text:SetPoint("TOPLEFT",4,-4)
b.text:SetJustifyH("LEFT")
b.text:SetSpacing(2)
b.height=function()return b.text:GetStringHeight()+12 end
return e(b,function(a)
b.text:SetWidth(d and a-8 or math.min(a-8,j))
b.text:SetText(type(c)=="function"and c()or c)
end)
end




function a.subhead(b,f,g,c)
local b=a.row(b,d(c).subheadH)
b.text=a.fontString(b,d(c).subhead)
b.text:SetPoint("BOTTOMLEFT",4,7)
b.note=a.fontString(b,d(c).hint)
b.note:SetPoint("BOTTOMLEFT",b.text,"BOTTOMRIGHT",10,1)
b.rule=b:CreateTexture(nil,"ARTWORK")
a.fill(b.rule,"white")
b.rule:SetGradient("HORIZONTAL",a.colorObj("rule",0.30),a.colorObj("rule",0))
b.rule:SetHeight(1)
b.rule:SetPoint("BOTTOMLEFT",0,3)
b.rule:SetPoint("BOTTOMRIGHT",0,3)
local function a(a)if type(a)=="function"then return a()end return a end
return e(b,function()
b.text:SetText(a(f)or"")
b.note:SetText(a(g)or"")
end)
end




function a.hint(b,f,c,g)
local b=a.row(b,18)
b.isHint=true
c=c or d(g).labelW
b.text=a.fontString(b,d(g).hint)
b.text:SetPoint("TOPLEFT",c,-1)
b.text:SetJustifyH("LEFT")
b.text:SetSpacing(2)

local a=d(g).hintFoot
b.stack=a-2
b.height=function()return b.text:GetStringHeight()+a end
return e(b,function(a)
b.text:SetWidth(math.max(math.min(a-c-8,j),40))
b.text:SetText(type(f)=="function"and f()or f)
end)
end



function a.callout(b,f,g,d)
local b=a.row(b,40)
local c=CreateFrame("Frame",nil,b)
c:SetPoint("TOPLEFT")
local d=d=="note"
local h=a.panel(c,d and"noteFill"or"callout",d and"noteEdge"or"callout")
if not d then h.fill:SetAlpha(0.08)end
b.kind=d and"note"or"warning"
b.text=c:CreateFontString(nil,"OVERLAY",a.font("label"))
b.text:SetPoint("TOPLEFT",12,-10)
b.text:SetJustifyH("LEFT")
local d=0
if g then
b.link=a.textLink(c,g.text,g.click,true)
b.link:SetPoint("TOPLEFT",b.text,"BOTTOMLEFT",0,-6)
d=a.LINK_H+6
end
b.height=function()return b.text:GetStringHeight()+d+30 end
return e(b,function(a)
local a=math.min(a,j+24)
b.text:SetWidth(a-24)
b.text:SetText(type(f)=="function"and f()or f)
c:SetSize(a,b.text:GetStringHeight()+d+20)
h:cover(c,1)
end)
end









local p,m,k,j=520,22,64,14

function a.letterLink(b,c)
return"|Hihud:"..b.."|h"..a.colorCode("letterLink")..c.."|r|h"
end
function a.parchment(b,c)
local f=c.small
local h,l=f and 18 or 26,f and 12 or 18
local i,q=f and"letterSmall"or"letter",f and"letterTitleSmall"or"letterTitle"
local b=a.row(b,80)
local d=CreateFrame("Frame",nil,b)
b.box=d
local g=a.panel(d,"parchment","parchmentEdge")
d.ground=g.fill
g.fill:SetTexture(a.art("parchment"))
g.fill:SetVertexColor(a.rgba("parchment"))
a.ornaments(d,g.fill,{file=a.art("corner"),size=f and 16 or 20,inset=4,
tint="parchmentCorner",corners={TOPLEFT=true,BOTTOMRIGHT=true}})
if c.crest then
b.crest=d:CreateTexture(nil,"ARTWORK")
b.crest:SetTexture(a.art("logo"))
b.crest:SetSize(k,k)
b.crest:SetPoint("TOPLEFT",h,-l+4)
end

local n=h+(b.crest and k+j or 0)
local j=c.align or"LEFT"
local function o(b)
local a=a.fontString(d,b)
a:SetJustifyH(j)
a:SetSpacing(f and 2 or 3)
return a
end
if c.title then b.title=o(q)end
b.text=o(i)


if c.links and d.SetHyperlinksEnabled then
d:SetHyperlinksEnabled(true)
d:SetScript("OnHyperlinkClick",function(b,a)
local a=type(a)=="string"and a:match("^ihud:(.+)$")
if a and c.links[a]then c.links[a]()end
end)
end
if c.sign then
b.sign=a.fontString(d,i)
b.sign:SetText(c.sign)
end
if c.buttons then
b.buttons,b.buttonW={},{}
for c,e in ipairs(c.buttons)do
b.buttonW[c]=e.width or 140
local a=a.button(d,e.text,b.buttonW[c],m)
a:SetScript("OnClick",function()e.click();b.refresh()end)
b.buttons[c]=a
end
end
if c.copy then
b.copyLabel=a.fontString(d,"letter")
b.copyLabel:SetText(c.copy.label)
b.copy=a.copyBox(d,c.copy.value,260)
b.copy.simLabel=c.copy.label
end
if c.close then
b.close=CreateFrame("Button",nil,d)
b.close:SetSize(16,16)
b.close:SetPoint("TOPRIGHT",-8,-8)
b.close.x=b.close:CreateTexture(nil,"OVERLAY")
b.close.x:SetAllPoints()
b.close.x:SetTexture(a.art("close"))
b.close.x:SetVertexColor(a.rgba("letterLink"))
b.close:SetScript("OnClick",function()c.close()end)
b.close:SetScript("OnEnter",function()b.close.x:SetVertexColor(a.rgba("letterTitle"))end)
b.close:SetScript("OnLeave",function()b.close.x:SetVertexColor(a.rgba("letterLink"))end)
b.close.simRole,b.close.simLabel="button","Dismiss"
end
local q=80
b.height=function()return q end
local function o(a)if type(a)=="function"then return a()end return a end
local s=b.sign and a.textWidth(i,c.sign)or 0

return e(b,function(e)

local i=j=="CENTER"and math.min(e,p)or e
local r=i-h-n
d:ClearAllPoints()
d:SetPoint("TOPLEFT",j=="CENTER"and math.floor((e-i)/2)or 0,0)
local e=-l
local function j(b,c,d)
b:ClearAllPoints()
b:SetPoint("TOPLEFT",n,e)
e=e-a.wrapText(b,c,r)-d
end
if b.title then
local a=o(c.title)or""
b.title:SetShown(a~="")
if a~=""then j(b.title,a,f and 5 or 8)end
end
j(b.text,o(c.text)or"",0)
local o=b.sign~=nil
local j,p=nil,0
for d,a in ipairs(b.buttons or{})do
local c=c.buttons[d]
local c=not c.shown or c.shown()
a:SetShown(c)
if c then
a:ClearAllPoints()
if j then a:SetPoint("LEFT",j,"RIGHT",6,0)
else a:SetPoint("TOPLEFT",n,e-12)end
p=p+(j and 6 or 0)+b.buttonW[d]
j=a
end
end
if j then
e=e-12

if o and p+16+s<=r then
b.sign:ClearAllPoints()
b.sign:SetPoint("RIGHT",d,"TOPRIGHT",-h,e-m/2)
o=false
end
e=e-m
end
if b.copy then
e=e-12

local a=b.copyLabel:GetStringWidth()
local a=math.floor((i-a-10-260)/2)
b.copyLabel:ClearAllPoints()
b.copyLabel:SetPoint("LEFT",d,"TOPLEFT",a,e-10)
b.copy:ClearAllPoints()
b.copy:SetPoint("LEFT",b.copyLabel,"RIGHT",10,0)
e=e-20
end
if o then
e=e-(f and 4 or 8)
b.sign:ClearAllPoints()
b.sign:SetPoint("TOPRIGHT",d,"TOPRIGHT",-h,e)
e=e-b.sign:GetStringHeight()
end
local c=math.floor(-e+l)
if b.crest then c=math.max(c,k+2*l-4)end
d:SetSize(i,c)
g:cover(d,1)
g.fill:SetTexCoord(a.coverCoords(a.art("parchmentCrop"),i-2,c-2))
q=c+12
end)
end


local b,f=18,230
function a.flourish(c)
local b=a.row(c,b)
b.left=b:CreateTexture(nil,"ARTWORK")
b.right=b:CreateTexture(nil,"ARTWORK")
for c,b in ipairs({b.left,b.right})do
b:SetTexture(a.art("flourish"))
b:SetVertexColor(a.rgba("rule",0.85))
b:SetHeight(12)
end
b.right:SetTexCoord(1,0,0,1)
return e(b,function(c)
local a=math.max(math.min(f,math.floor(c/2)-8),0)
b.left:SetWidth(a)
b.right:SetWidth(a)

local a,c=math.floor(c/2),math.floor(a*8.5/256+0.5)
b.left:ClearAllPoints()
b.left:SetPoint("RIGHT",b,"LEFT",a+c,0)
b.right:ClearAllPoints()
b.right:SetPoint("LEFT",b,"LEFT",a-c,0)
end)
end






local f,g,h=26,5,2
function a.linkList(b,j,k)
local c=a.row(b,f)
local d,b,i={},0,f
c.empty=c:CreateFontString(nil,"OVERLAY",a.font("small"))
a.tint(c.empty,"help")
c.empty:SetPoint("TOPLEFT",4,-6)
c.empty:SetText(k or"")
local function k(e)
local b=d[e]
if b then return b end
b=CreateFrame("Button",nil,c)
b:SetHeight(f-2)
b:EnableMouse(true)

b.icon=b:CreateTexture(nil,"ARTWORK")
b.icon:SetSize(20,20)
b.icon:SetPoint("LEFT",4,0)
a.cropIcon(b.icon)
b.text=a.fontString(b,"listTop")
b.text:SetPoint("TOPLEFT",b,"TOPLEFT",32,-g)
b.text:SetWordWrap(false)
b.note=a.fontString(b,"dim")
b.note:SetPoint("TOPLEFT",b.text,"BOTTOMLEFT",0,-h)
b.note:SetPoint("RIGHT",b,"RIGHT",-6,0)
b.note:SetWordWrap(true)
b.note:SetJustifyH("LEFT")

b.tag=a.tag(b,14)
b.tag:SetPoint("TOPRIGHT",b,"TOPRIGHT",-6,-(g+1))
b.tag.click=function()if b.Click then b:Click()end end
b.tag:SetScript("OnEnter",function(b)if b.tip then a.note(b,b.tip)end end)
b.tag:SetScript("OnLeave",function()a.note()end)
b.tag:Hide()
local c=b:CreateTexture(nil,"HIGHLIGHT")
c:SetAllPoints()
a.fill(c,"white",0.05)
b:SetScript("OnEnter",function(b)if not b.item.off then a.tint(b.text,"goldLight")end end)
b:SetScript("OnLeave",function(b)a.tint(b.text,b.item.off and"off"or"listTopText")end)
b:SetScript("OnClick",function(a)if a.item.click then a.item.click(a)end end)
d[e]=b
return b
end
c.height=function()return i end
c.rows=d
return e(c,function(e)
local j=j()
b=#j
c.empty:SetShown(b==0)
local e=0
for b,c in ipairs(j)do
local b=k(b)
b.item=c
b.icon:SetTexture(c.icon)
b.icon:SetDesaturated(c.off and true or false)
b.text:SetText(c[1])
a.tint(b.text,c.off and"off"or"listTopText")
if c.tag then
b.tag.say(c.tag)
b.tag.tip=c.tagTip
b.tag:EnableMouse(c.tagTip~=nil)
end
b.tag:SetShown(c.tag~=nil)


local d=c.note~=nil and c.note~=""
local i=c.noteAfter and true or false
b.note:SetText(d and c.note or"")
b.note:SetShown(d)
b.note:ClearAllPoints()
if i then
b.note:SetPoint("LEFT",b.text,"RIGHT",8,0)
else
b.note:SetPoint("TOPLEFT",b.text,"BOTTOMLEFT",0,-h)
b.note:SetPoint("RIGHT",b,"RIGHT",-6,0)
end
b.note:SetWordWrap(not i)
local a=g+b.text:GetStringHeight()
if d and not i then a=a+h+b.note:GetStringHeight()end
a=math.max(f-2,a+g)
b:ClearAllPoints()
b:SetPoint("TOPLEFT",0,-e)
b:SetPoint("TOPRIGHT",0,-e)
b:SetHeight(a)
b:Show()
e=e+a+2
end
for a=b+1,#d do d[a]:Hide()end
i=math.max(e,f)
end)
end





local f=20
function a.entryList(c,g,b)
local i=d(b)
local c=a.row(c,f)
if b and b.label then
c.label=a.label(c,b.label,nil,b)
c.label:ClearAllPoints()
c.label:SetPoint("TOPLEFT",4,-3)

c.labelTop=-3
end
local d,b={},0
local function j(e)
local b=d[e]
if b then return b end
b=CreateFrame("Frame",nil,c)
b:SetHeight(f)
b:EnableMouse(true)
b.icon=b:CreateTexture(nil,"ARTWORK")
b.icon:SetSize(16,16)
b.icon:SetPoint("LEFT",0,0)
a.cropIcon(b.icon)
b.text=a.fontString(b,"small")
b.text:SetPoint("LEFT",b.icon,"RIGHT",6,0)
b.text:SetWordWrap(false)
b.id=a.fontString(b,"dim")
b.id:SetPoint("LEFT",b.text,"RIGHT",6,0)
b.note=a.fontString(b,"dim")
b.note:SetPoint("LEFT",b.id,"RIGHT",6,0)
b.tag=a.tag(b,14)
b.tag:EnableMouse(false)
b.remove=a.textLink(b,"×",function()if b.item and b.item.remove then b.item.remove()end end,true)
b.remove:SetPoint("RIGHT",-4,0)
b.remove.simLabel="Remove"
b:SetScript("OnEnter",function(a)
if not(a.item and a.item.tip)then return end
GameTooltip:SetOwner(a,"ANCHOR_RIGHT")
GameTooltip:SetText(a.item.label or"")
GameTooltip:AddLine(a.item.tip,1,1,1,true)
GameTooltip:Show()
end)
b:SetScript("OnLeave",function()GameTooltip:Hide()end)
d[e]=b
return b
end
c.add=a.textLink(c,"",function(b)
local a=g()
if a.add and a.add.click then a.add.click(b)end
end,true)
c.height=function()return(b+1)*f end
c.rows=d
return e(c,function(k)
local e=g()
local h=e.entries or{}
b=#h
local g=i.labelW
for e,d in ipairs(h)do
local b=j(e)
b.item=d
b:ClearAllPoints()
b:SetPoint("TOPLEFT",c,"TOPLEFT",g,-(e-1)*f)
b:SetPoint("RIGHT",c,"LEFT",math.max((k or 300)-8,g+120),0)
b.icon:SetTexture(d.icon or a.art("iconUnknown"))
b.text:SetText(d.label or"")
b.id:SetText(d.idText or"")
b.note:SetText(d.note or"")
b.tag:SetShown(d.tag~=nil)
if d.tag then
b.tag.say(d.tag)
b.tag:ClearAllPoints()
b.tag:SetPoint("LEFT",d.note and b.note or b.id,"RIGHT",6,0)
end
b:Show()
end
for a=b+1,#d do d[a]:Hide()end
c.add.say(e.add and e.add.text or"")
c.add:SetShown(e.add~=nil)
c.add:ClearAllPoints()
c.add:SetPoint("TOPLEFT",c,"TOPLEFT",g,-b*f-1)
end)
end



function a.copyBox(d,b,e)
local function c()return type(b)=="function"and b()or b end
local a=a.editBox(d,e,20)
a:SetText(c())
a:SetCursorPosition(0)
a:SetScript("OnTextChanged",function(a,b)
if b then
a:SetText(c())
a:HighlightText()
end
end)
a:SetScript("OnEditFocusGained",function(a)a:HighlightText()end)
a:SetScript("OnEscapePressed",function(a)a:ClearFocus()end)
return a
end




local h,f=320,24
function a.searchBox(b,g,d)
d=d or{}
local c=a.row(b,f+12)
local b=CreateFrame("EditBox",nil,c,"SearchBoxTemplate")
b:SetSize(d.width or h,f)
b:SetPoint("LEFT",4,0)
b:SetMaxLetters(d.maxLetters or 48)
b:SetFontObject(a.font("field"))
for b,a in ipairs({b.Left,b.Middle,b.Right})do a:SetHeight(f)end
b.Instructions:SetText(d.hint or"Search")
b.simLabel="Search"
b.clearButton.simRole,b.clearButton.simLabel="button","Clear search"
local function a()
b:SetText("")
g("")
end

b:HookScript("OnTextChanged",function(c,a)if a then g(b:GetText())end end)
b:HookScript("OnEscapePressed",a)

b.clearButton:HookScript("OnClick",function()g("")end)
c.box,c.label=b,b.Instructions
c.clear=a
function c.query()return b:GetText()end
return e(c,function()end)
end




function a.dragGhost(c)
local b=CreateFrame("Frame",nil,UIParent)
b:SetFrameStrata("TOOLTIP")
b:SetSize(180,24)
b:SetAlpha(0.9)
b.icon=b:CreateTexture(nil,"ARTWORK")
b.icon:SetSize(20,20)
b.icon:SetPoint("LEFT",2,0)
a.cropIcon(b.icon)
b.text=b:CreateFontString(nil,"OVERLAY",a.font("label"))
b.text:SetPoint("LEFT",b.icon,"RIGHT",6,0)
b:Hide()
b:SetScript("OnUpdate",function(a)
local d,e=GetCursorPosition()
local b=UIParent:GetEffectiveScale()
a:ClearAllPoints()

a:SetPoint("TOPLEFT",UIParent,"BOTTOMLEFT",d/b+12,e/b-14)
c()
end)
return b
end

function a.dropLine(b)
local b=b:CreateTexture(nil,"OVERLAY",nil,7)
a.fill(b,"dropLine")
b:SetHeight(2)
b:Hide()
return b
end



function a.dropIndex(b,c)
local d,a=GetCursorPosition()
a=a/UIParent:GetEffectiveScale()
for b,d in ipairs(b)do
if a>d-c[b]/2 then return b end
end
return#b+1
end


function a.placeDropLine(b,a,c)
b:ClearAllPoints()
if#a==0 then
b:Hide()
return false
end
if c<=#a then
b:SetPoint("BOTTOMLEFT",a[c],"TOPLEFT",0,0)
b:SetPoint("BOTTOMRIGHT",a[c],"TOPRIGHT",0,0)
else
b:SetPoint("TOPLEFT",a[#a],"BOTTOMLEFT",0,0)
b:SetPoint("TOPRIGHT",a[#a],"BOTTOMRIGHT",0,0)
end
b:Show()
return true
end


function a.tag(b,c)
local b=CreateFrame("Button",nil,b)
b:EnableMouse(true)
b.ground=a.panel(b,"tagFill","tagEdge")
b.ground:cover(b,1)
b.text=b:CreateFontString(nil,"OVERLAY",a.font("tag"))
b.text:SetPoint("CENTER",0,0)
b.text:SetWordWrap(false)
a.tint(b.text,"tagText")
b:SetScript("OnClick",function(a)if a.click then a.click()end end)
function b.say(a)
b.text:SetText(a)
b:SetSize(b.text:GetStringWidth()+8,c or 14)
end
return b
end


function a.greyTag(b)
a.fill(b.ground.fill,"track")
for c,b in ipairs(b.ground.edges)do a.fill(b,"off",0.6)end
a.tint(b.text,"help",0.8)
end


function a.draftTag(b,c)
local b=a.tag(b,14)
a.greyTag(b)
b.say("Draft")
b.tip=c
b:SetScript("OnEnter",function(b)a.note(b,b.tip)end)
b:SetScript("OnLeave",function()a.note()end)
return b
end



local c=110
function a.badge(b)
local b=CreateFrame("Frame",nil,b)
b:SetHeight(14)
b:EnableMouse(true)
b.ground=b:CreateTexture(nil,"ARTWORK")
b.ground:SetAllPoints()
a.fill(b.ground,"accent",0.85)
b.text=b:CreateFontString(nil,"OVERLAY",a.font("small"))
b.text:SetPoint("LEFT",4,0)
b.text:SetPoint("RIGHT",-4,0)
b.text:SetWordWrap(false)
a.tint(b.text,"shade")
b.simLabel="badge"
function b.say(a,d)
b.text:SetText(a)
b.tip="Only while you know "..a
b:SetWidth(d or math.min(b.text:GetStringWidth()+8,c))
end
b:SetScript("OnEnter",function(b)a.note(b,b.tip)end)
b:SetScript("OnLeave",function()a.note()end)
return b
end


function a.unlearnedMark(b,c)
local b=CreateFrame("Frame",nil,b)
b:SetSize(c or 14,c or 14)
b:EnableMouse(true)
b.icon=b:CreateTexture(nil,"OVERLAY")
b.icon:SetAllPoints()
b.icon:SetTexture(a.art("markUnlearned"))
b.icon:SetVertexColor(a.rgba("off"))
b.simLabel="not learned"
b:SetScript("OnEnter",function(b)a.note(b,"Not learned: your character doesn't know its spell yet.")end)
b:SetScript("OnLeave",function()a.note()end)
return b
end


function a.dots(b,d)
local b=CreateFrame("Button",nil,b)
b:SetSize(20,16)
b:EnableMouse(true)
b.simLabel="⋯"
for c=1,3 do
local b=b:CreateTexture(nil,"ARTWORK")
a.fill(b,"dots")
b:SetSize(2,2)
b:SetPoint("CENTER",(c-2)*4,0)
end
local c=b:CreateTexture(nil,"HIGHLIGHT")
c:SetAllPoints()
a.fill(c,"lit")
b:SetScript("OnClick",function(b)
if a.menuOwner()==b then return a.closeMenu()end
local c=d()
local d={}
for a,b in ipairs(c)do d[a]={value=a,label=b.text}end
a.openMenu(b,d,function(a)c[a].click()end)
end)
b:SetScript("OnHide",function(b)if a.menuOwner()==b then a.closeMenu()end end)
return b
end








local n,f=2,15
local j,o,c=18,9,3
local k=24


function a.marksStart(c,f,e)
local b=d(e)
if c.hasField then return b.labelW+a.fieldSpan(c,f,e)+b.colGap end
if c.play then return b.labelW+c.dropdown:GetWidth()+8+c.play:GetWidth()+b.colGap end
if c.swatchButton then return b.labelW+b.swatch+b.colGap end
if c.check and c.check.Text then
return math.max(b.labelW,3+b.checkBox+6+c.check.Text:GetStringWidth()+b.colGap)
end
return b.labelW
end

local p="changed while"
local function l()return a.textWidth("dim",p)+5 end

local h,b={},0
local function g(d)
local e=a.fontSize("tag").."|"..d
local c=h[e]
if not c then
if b>=200 then wipe(h);b=0 end
c=a.textWidth("tag",d)+8
h[e],b=c,b+1
end
return c
end



function a.marksFit(d,a,h)
local b=d and d.tags
if not b or#b==0 then return 0 end
if d.reset then a=a+f+4+c end
a=a+l()
local d=0
for a,b in ipairs(b)do d=d+g(b.text)+(a>1 and c or 0)end
if a+d<=h then return#b end
local d,f=0,0
for e=1,#b do
local b=g(b[e].text)+(e>1 and c or 0)
if a+d+b+c+k>h then break end
d,f=d+b,e
end
return f
end


local h=170

local m={}
function a.marksNeed(b)
if not b then return 0 end
local d=b.tags or m
local e=b.reset and f+4 or 0
if#d>0 then
local a=0
for b,d in ipairs(d)do a=a+g(d.text)+(b>1 and c or 0)end
if a>h then a=g(d[1].text)+c+k end
e=e+(b.reset and c or 0)+l()+a
end
return e
end



function a.rowMarksRoom(b,c,f)
local e=b.colNeed and b.colNeed()or 0
if e<=0 then return 0 end
local d=d(f)
c=c or b.width or i
if not b.hasField then

return a.marksStart(b,c,f)+e<=c-a.EDGE and e+d.colGap or 0
end
local a=c-d.labelW-a.EDGE
if a-e-d.colGap<d.fieldMin then return 0 end
return e+d.colGap
end
local function q(a)return"Set differently while "..a..". Click to see and change it there."end
local function r(b)
b:SetScript("OnEnter",function(b)a.note(b,b.tip)end)
b:SetScript("OnLeave",function()a.note()end)
end

function a.setBar(c)
local b=c:CreateTexture(nil,"ARTWORK")
a.fill(b,"setHere")
b:SetWidth(n)
b:SetPoint("TOPLEFT",c,"TOPLEFT",-6,-5)
b:SetPoint("BOTTOMLEFT",c,"BOTTOMLEFT",-6,5)
b:Hide()
return b
end
function a.resetMark(b)
local b=CreateFrame("Button",nil,b)
b:SetSize(f+4,f+4)
b:EnableMouse(true)
b.simLabel="↺"
b.icon=b:CreateTexture(nil,"ARTWORK")
b.icon:SetTexture(a.art("reset"))
b.icon:SetSize(f,f)
b.icon:SetPoint("CENTER")
b.icon:SetVertexColor(a.rgba("resetMark"))
b:SetScript("OnEnter",function(b)
b.icon:SetVertexColor(a.rgba("resetMarkLit"))
if b.tip then a.note(b,b.tip)end
end)
b:SetScript("OnLeave",function(b)
b.icon:SetVertexColor(a.rgba("resetMark"))
a.note()
end)
b:SetScript("OnClick",function(a)if a.click then a.click()end end)
b:Hide()
return b
end
a.RESET_W=f+4
function a.marks(b,n)
b.setBar=a.setBar(b)
local i=a.resetMark(b)
b.resetMark=i

b.rowTags={}
b.rowLead=a.fontString(b,"dim")
b.rowLead:SetText(p)
b.rowLead:Hide()
local g=a.tag(b)
r(g)
g:Hide()
b.moreTag=g
b.inlineTags=0

local h=a.row(b:GetParent(),j+o)
h.isHint=true
b.tagRow=h
b.tagMarks={}
b.tagLead=a.fontString(h,"dim")
b.tagLead:SetText("changed while")
b.tagLead:Hide()
local k=1
h.height=function()return k*j+o end
e(h,function(f)
local e=d(n).labelW
local g=(f or 0)-a.EDGE
b.tagLead:ClearAllPoints()
b.tagLead:SetPoint("LEFT",h,"TOPLEFT",e,-j/2)
local a,f=e+b.tagLead:GetStringWidth()+5,0
k=1
for i,d in ipairs(b.tagMarks)do
if d:IsShown()then
if a+d:GetWidth()>g and a>e+b.tagLead:GetStringWidth()+5 then
a,f,k=e,f+j,k+1
end
d:ClearAllPoints()
d:SetPoint("LEFT",h,"TOPLEFT",a,-(f+j/2))
a=a+d:GetWidth()+c
end
end
end)
local function k(c,d,e)
local b=c[d]
if not b then
b=a.tag(e)
r(b)
c[d]=b
end
return b
end
local d

function b.layoutMarks(e)
local j=d or m
local o=a.rowMarksRoom(b,e,n)>0
local d=a.marksStart(b,e or b.width,n)
local n=(e or b.width)-a.EDGE
i:ClearAllPoints()
if j.reset then
i:SetPoint("LEFT",b,"LEFT",d,0)
d=d+f+4+c
end
local e=j.tags or m
local a=o and a.marksFit(j,d-(j.reset and f+4+c or 0),n)or 0

b.rowLead:SetShown(a>0)
if a>0 then
b.rowLead:ClearAllPoints()
b.rowLead:SetPoint("LEFT",b,"LEFT",d,0)
d=d+l()
end
for a=1,a do
local b=k(b.rowTags,a,b)
b.say(e[a].text)

b:SetAlpha(e[a].dim and 0.55 or 1)
b.click,b.tip=e[a].click,q(e[a].text)
end
b.inlineTags=a
for f,e in ipairs(b.rowTags)do
e:ClearAllPoints()
if f<=a then
e:SetPoint("LEFT",b,"LEFT",d,0)
d=d+e:GetWidth()+c
end
e:SetShown(f<=a)
end
local c=a>0 and#e-a or 0
g:SetShown(c>0)
if c>0 then
local f={}
for a=a+1,#e do f[#f+1]=e[a].text end
g.say("+"..c)
g.click=e[a+1].click
g.tip="Also set differently while "..table.concat(f,", ")..". Click to see the first there."
g:ClearAllPoints()
g:SetPoint("LEFT",b,"LEFT",d,0)
end

local a=a==0 and#e>0
b.tagLead:SetShown(a)
h.has=a
if a then
for a,c in ipairs(e)do
local a=k(b.tagMarks,a,h)
a.say(c.text)
a:SetAlpha(c.dim and 0.55 or 1)
a.click,a.tip=c.click,q(c.text)
a:Show()
end
end
for a=a and#e+1 or 1,#b.tagMarks do b.tagMarks[a]:Hide()end
end
function b.paintMarks(a)
d=a
b.setBar:SetShown(a and a.set and true or false)
i.tip,i.click=a and a.tip,a and a.reset
i:SetShown(a~=nil and a.reset~=nil)
b.layoutMarks(b.width)
end


function b.colNeed()
if b.wantMarks then return a.marksNeed(b.wantMarks())end
return a.marksNeed(d)
end
return b
end






local function d(c,b,d)
local a={}
for d,c in ipairs(c)do
local b=b and b[c.key]
if b~=nil then
local b=c.words[b and"yes"or"no"]
a[#a+1]=#a==0 and b or(b:gsub("^%u",string.lower))
end
end
return#a>0 and table.concat(a,", ")or d
end
a.conditionWords=d
local l={{"any","Any"},{"yes","Yes"},{"no","No"}}
function a.conditions(c,g,k,h,i,b)
local f,j=b.facts,b.none or"Always"
local c=a.dropdown(c,g,k,function()return nil end,function()end,
{choices={},width=b.width,dense=b.dense})
local g=c.dropdown
local function k()
local a=d(f,h(),j)
if b.following and b.following()then return"Same as group: "..a end
return a
end
local function m()
local a={}
for c,b in ipairs(f)do a[#a+1]={key=b.key,label=b.label}end
local e
local g=b.group and b.group()
if g then
e={label="Same as group ("..d(f,g,j)..")",
checked=b.following and b.following()}
end
return{top=e,rows=a,options=l,
value=function(a)
local a=(h()or{})[a]
if a==nil then return"any"end
return a and"yes"or"no"
end,
pick=function(b,d)
local a
if d=="yes"then a=true elseif d=="no"then a=false end
if b==nil then i(nil)else i(b,a)end
c.refresh()
end,
topChecked=function()return b.following and b.following()end}
end


function g:OpenMenu()
if a.menuOwner()==self then return a.closeMenu()end
Menu.GetManager():CloseMenus()
a.openGrid(self,m())
end

g:HookScript("OnHide",function(b)if a.menuOwner()==b then a.closeMenu()end end)
c.says=function()return k()end
local a=c.refresh
return e(c,function(b)
a(b)
g:OverrideText(k())
end)
end




local f,d,c=20,8,9
local e={}

function e:say(f,b,e,g,h)
self.rightClick=h
self.text:SetText(f)
self.text:ClearAllPoints()
self.text:SetPoint("LEFT",d+(e and c+2 or 0),0)
self.mark:SetShown(e and true or false)
a.fill(self.ground.fill,b and"menuPick"or"fieldFill")
for c=1,4 do a.fill(self.ground.edges[c],b and"accent"or"fieldEdge")end
a.tint(self.text,b and"listOn"or"listSub")
self.simState=b and"on"or nil
self.click=g
self:SetWidth(self.text:GetStringWidth()+2*d+(e and c+2 or 0))
self:Show()
end
function a.chip(b)
local b=CreateFrame("Button",nil,b)
for a,c in pairs(e)do b[a]=c end
b:SetHeight(f)
b:EnableMouse(true)
b.ground=a.panel(b,"fieldFill","fieldEdge")
b.ground:cover(b,1)
local e=b:CreateTexture(nil,"HIGHLIGHT")
e:SetPoint("TOPLEFT",1,-1)
e:SetPoint("BOTTOMRIGHT",-1,1)
a.fill(e,"lit")
b.mark=b:CreateTexture(nil,"ARTWORK")
b.mark:SetTexture(a.art("thumb"))
b.mark:SetVertexColor(a.rgba("accent"))
b.mark:SetSize(c+3,c+3)
b.mark:SetPoint("LEFT",d-3,0)
b.text=b:CreateFontString(nil,"OVERLAY",a.font("small"))
b.text:SetWordWrap(false)
b:RegisterForClicks("LeftButtonUp","RightButtonUp")
b:SetScript("OnClick",function(a,b)
if b=="RightButton"then
if a.rightClick then a.rightClick()end
elseif a.click then
a.click()
end
end)
return b
end
