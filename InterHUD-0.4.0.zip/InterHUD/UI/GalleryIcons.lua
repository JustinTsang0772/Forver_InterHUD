



local b,a=...
local b,a,d,c,g=a.Gallery,a.GalleryTiles,a.Schema,a.Styles,a.StyleModel

local e="comesReady"



local f={"flash","burst","motion"}
local function h(f,g,b)
local c=d.get(c.recordOf("pop")).byName[b]
local d={}
for f,a in ipairs(c.choices)do
if a~="none"then
local f={flash="none",burst="none",motion="none"}
f[b]=a
d[#d+1]={key="pop:"..b..":"..a,caption=c.labels[a]or a,style=f,
plays=e,use=false,save=false}
end
end
f:subhead(c.label)
a.grid(f,g,d)
end


local function i()
local a={}
for e,b in ipairs(f)do a[b]=d.get(c.recordOf("pop")).byName[b].default end
return a
end
local d={
{"default","Default"},
{"soft","Soft",{flash="plain",burst="ring",motion="grow"}},
{"lively","Lively",{flash="edge",burst="rune",motion="bounce"}},
}
local function j(c,f)
c:subhead("Together")
local b={}
for c,a in ipairs(d)do
b[#b+1]={key="pop:"..a[1],caption=a[2],style=a[3]or i(),plays=e,
use=false,save=false}
end
a.grid(c,f,b)
end


local i={"outOfRange","notEnoughPower","notUsable"}
local function k(d)
local e=a.section(d,{key="looks",title=g.LOOKS_TITLE,tab="icons",
help="What an icon shows while each holds, at its default."})
local b={}
for d,a in ipairs(i)do
if c.spec(a)then
b[#b+1]={key="look:"..a,part=a,caption=c.spec(a).label,use="look",
save=false}
end
end
a.grid(d,e,b)
end



local function d(c,e)
if not b.state.countdown then return end
local d=a.firstId(c)
if d then e[d]={state="coolingDown",facts={}}end
for c,a in ipairs(a.layersOf(c))do
if a.kind=="icon"then
a.time=a.time or{}
a.time.enabled=true
if b.state.font then a.time.style={face=b.state.font}end
end
end
end

b.tab("icons",{label="Icons",rank=10,bar={"backdrop","sample","size","countdown","font","pause","reset"},
decorate=d,
parts={border="border",glow="glow",pop="pop",flash="flash",pressed="pressed",outOfRange="looks",
notEnoughPower="looks",notUsable="looks"},
build=function(b)


local function d(d,e)
local c=c.spec(d)
return a.section(b,{key=d,title=c.title or c.label,help=c.help,part=d,
tab="icons",controls=e})
end

local function g()
local a=a.kindTiles("border")
for a,b in ipairs(a)do
local a=c.get("border",b.style.kind)
if not(a and a.uses and a.uses.thickness)then b.mark="fixed"end
end
return a
end
local a={
border=function()a.grid(b,d("border",{"colour","thickness"}),g())end,
glow=function()a.grid(b,d("glow",{"colour","speed"}),a.kindTiles("glow"))end,
pop=function()
local a=d("pop",{"colour","size"})
for d,c in ipairs(f)do h(b,a,c)end
j(b,a)
end,
flash=function()
a.grid(b,d("flash",{"colour"}),a.kindTiles("flash",nil,{plays=e}))
end,
pressed=function()
a.grid(b,d("pressed",{"colour"}),a.kindTiles("pressed",{none=true},{held=true}))
end,
}
for c,b in ipairs(c.ranked())do
if a[b]then a[b]()end
end
k(b)
b:endBlock()
end})


local c=b.resetTab
function b.resetTab(a)
c(a)
if a=="icons"then b.state.countdown,b.state.font=false,nil end
end

