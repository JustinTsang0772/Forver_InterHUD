












local a,c=...
local b,o,A,p,h,B,i,d,t=c.Kit,c.Form,c.Preview,c.Layers,c.Store,
c.Resolve,c.Ticker,c.ElementModel,c.Check
local u=c.Combat

local q={}

c.Debug.experimental("the element banner's preview kept between draws: the game must show it as a fresh draw would"
.." after a chip's pick, an event's play and a countdown's end")
c.ElementBanner=q

local e,l,v=12,54,16
local C,D=210,8

local E,f,F,G=40,12,78,62
local j,m,w=200,140,18


local g,r,x,k,s,y,H=160,20,5,4,18,16,2
local I=1.5
local z=0.2

local J,K=0.5,1.0



local function L(a,c,d,e,f,g)
local b,d=b.wrapText(a,d,e,true)
a.shownH,a.wordW=b,d
a:ClearAllPoints()
a:SetPoint("TOPLEFT",c,"TOPLEFT",f,g)
end


local n=12
local function M(c)
local a=b.fontString(c,"link")
a:SetWidth(g-8)
a:SetJustifyH("LEFT")
a:SetJustifyV("TOP")

a.mark=b.unlearnedMark(c,n)
a.mark:Hide()

a.hit=CreateFrame("Frame",nil,c)
a.hit:EnableMouse(true)
a.hit:SetScript("OnEnter",function(a)
if a.full then b.note(a,a.full)end
end)
a.hit:SetScript("OnLeave",function()b.note()end)

a.hit:SetScript("OnMouseUp",function(a,b)
if b=="RightButton"and a.key and a.go then a.go(a.key)end
end)
return a
end


local function N(a)
local a=CreateFrame("Frame",nil,a)
a:SetHeight(s)
a.text=a:CreateFontString(nil,"OVERLAY",b.font("small"))
a.text:SetPoint("LEFT",0,0)
a.text:SetWordWrap(false)
b.tint(a.text,"lineText")
a.edit=b.textLink(a,"Edit ›",function()if a.click then a.click()end end,true)
a.edit:SetPoint("LEFT",a.text,"RIGHT",8,0)
b.tint(a.edit.text,"lineLink")
a.edit:SetScript("OnLeave",function()b.tint(a.edit.text,"lineLink")end)
return a
end


local function s(c)
local a={n=0,items={}}
function a.take(d)
a.n=a.n+1
local b=a.items[a.n]
if not b then
b=c(d)
a.items[a.n]=b
end
return b
end
function a.reset()a.n=0 end
function a.hideRest()
for b=a.n+1,#a.items do
a.items[b]:Hide()

if a.items[b].mark then a.items[b].mark:Hide()end
if a.items[b].hit then a.items[b].hit:Hide()end
end
end
return a
end

local a={}
a.__index=a

function q.new(h)
local d=CreateFrame("Frame")

local g=b.cornerRoom("header",e)

local i=g
local a=setmetatable({frame=d,hooks=h,height=l+m+2*e,picks={},
side=g,px=i},a)
a.ground=b.panel(d,"heroFill","heroEdge",nil,"header")
a.ground:cover(d,1)


d:HookScript("OnSizeChanged",function(d,b,c)a.ground:fitArt(b,c)end)

a.name=b.fontString(d,"bannerName")

local k=b.metric("banner","top")
a.name:SetPoint("TOPLEFT",g,-k)
a.name:SetPoint("RIGHT",d,"RIGHT",-g-110-E-f-F-f-G-f,0)
a.name:SetJustifyH("LEFT")
a.name:SetWordWrap(false)
a.name:SetShadowOffset(1,-1)

a.group=b.textLink(d,"",function()a:openGroup()end):leaves()
a.group:SetPoint("TOPLEFT",a.name,"BOTTOMLEFT",0,-2)
a.sub=d:CreateFontString(nil,"OVERLAY",b.font("small"))

a.sub:SetPoint("LEFT",a.group.text,"RIGHT",0,0)
a.sub:SetJustifyH("LEFT")
a.sub:SetWordWrap(false)
b.tint(a.sub,"heroText")
a.move=b.textLink(d,"Move to…",function()a:openMove()end)

a.move.simLabel="Move to…"

a.switch=b.pillSwitch(d,function()
local a=a.id and o.view(a.id)
return a and a.enabled
end,function(c)
if not a.id then return false end
local b
if not c then b=false end
return o.set(a.id,{"enabled"},b)
end,"On",nil,b.font("label"))
a.switch:SetPoint("TOPRIGHT",d,"TOPRIGHT",-g-28,-k)


a.delete=b.textLink(d,"Delete",function()if a.id then c.Window.askDeleteElement(a.id)end end,true)
a.delete:SetPoint("RIGHT",a.switch,"LEFT",-f,0)
a.move:SetPoint("RIGHT",a.delete,"LEFT",-f,0)
a.delete.simLabel="Delete"
a.delete:HookScript("OnEnter",function(a)
if not a:IsEnabled()then b.note(a,"Delete element: not in combat")end
end)
a.delete:HookScript("OnLeave",function()b.note()end)


a.duplicate=b.textLink(d,"Duplicate",function()if a.id then c.Window.duplicateElement(a.id)end end,true)
a.duplicate.simLabel="Duplicate"


a.export=b.textLink(d,"Export",function()if a.id then c.PageShare.exportElement(a.id)end end,true)
a.export.simLabel="Export"
a.export:HookScript("OnEnter",function(a)
if not a:IsEnabled()then b.note(a,"Export element: not in combat")end
end)
a.export:HookScript("OnLeave",function()b.note()end)
a:makePreview()
a:makeCosts()

a.chipScroll=CreateFrame("ScrollFrame",nil,d)
a.chipScroll:SetPoint("TOPLEFT",d,"TOPLEFT",i+j+v,-(e+l))
a.chipScroll:SetPoint("RIGHT",d,"RIGHT",-g,0)
a.chipScroll:SetHeight(1)
a.chipArea=CreateFrame("Frame",nil,a.chipScroll)
a.chipArea:SetSize(1,1)
a.chipScroll:SetScrollChild(a.chipArea)
a.chipOffset,a.chipRange,a.shownH=0,0,0
local c=CreateFrame("Frame",nil,d)
c:SetAllPoints(a.chipScroll)
c:SetFrameLevel(a.chipScroll:GetFrameLevel()+5)
a.chipBar=b.scrollBar(c,{
offset=function()return a.chipOffset end,
range=function()return a.chipRange end,
view=function()return a.shownH end,
scrollTo=function(b)a:scrollChips(b)end,
})
a.chipBar:SetPoint("TOPRIGHT",0,0)
a.chipBar:SetPoint("BOTTOMRIGHT",0,0)
a.chipScroll:EnableMouseWheel(true)
a.chipScroll:SetScript("OnMouseWheel",function(c,b)
if a.chipRange>0 then a:scrollChips(a.chipOffset-b*2*(r+x))end
end)


local function c(a)
local a=b.chip(a)
if h.go then
b.setTip(a,function()return a.text:GetText()end,function()return a.rightTip end)
local b=a:GetScript("OnEnter")
a:SetScript("OnEnter",function(a)if a.rightClick then b(a)end end)
end
return a
end
a.chips,a.labels,a.lines=s(c),s(M),s(N)
a.rule=a.chipArea:CreateTexture(nil,"ARTWORK")
b.fill(a.rule,"rule",0.35)
a.rule:SetHeight(1)

a.statesWord=b.fontString(a.chipArea,"link")
a.statesWord:SetText("States")
a.eventsWord=b.fontString(a.chipArea,"link")
a.eventsWord:SetText("Events")
return a
end




local s={4,7,10}
function a:makeCosts()
local a=CreateFrame("Frame",nil,self.frame)
a:SetSize(13,10)
a:SetPoint("BOTTOMRIGHT",self.frame,"BOTTOMRIGHT",-self.side,e-4)
for c,d in ipairs(s)do
local a=a:CreateTexture(nil,"ARTWORK")
b.fill(a,"heroText",0.55)
a:SetSize(3,d)
a:SetPoint("BOTTOMLEFT",(c-1)*5,0)
end
a:EnableMouse(true)
a:SetScript("OnEnter",function(c)
local a=self.id and self:costsText()
if a then b.note(c,a)end
end)
a:SetScript("OnLeave",function()b.note()end)
a.simLabel="Costs"
self.costs=a
end

local function s(b)
local a={}
for d,b in ipairs(b.sources or{})do
local c=c.Schema.variantOf(b)
if c and c.read=="clip"then a[#a+1]=b end
end
return a
end
function a:costsText()
local c=h.element(self.id)
local b=self.view
if not(c and b)then return nil end
local a={}
local e=s(b)
for g,f in ipairs(e)do
local c,g=pcall(t.displays,c,f.id,h.profile()and h.profile().buttonCues)
if c then
if#e>1 then a[#a+1]=d.sourceName(b,f)..":"end
a[#a+1]="Displays: "..g.." of "..t.MAX_DISPLAYS
end
end
return#a>0 and table.concat(a,"\n")or nil
end



function a:makePreview()
local c=self.frame
local a=CreateFrame("Frame",nil,c)
a:SetSize(j,m)
a:SetPoint("TOPLEFT",c,"TOPLEFT",self.px,-(e+l))
a.ground=b.panel(a,"shade","panelEdge")
a.ground:cover(a,1)
a.label=b.fontString(a,"dim")
a.label:SetPoint("TOPLEFT",6,-4)
a.label:SetPoint("RIGHT",-6,0)
a.label:SetJustifyH("LEFT")
a.label:SetWordWrap(false)
a.line=a:CreateTexture(nil,"OVERLAY")
b.fill(a.line,"accent")
a.line:SetPoint("BOTTOMLEFT",1,1)
a.line:SetHeight(2)
a.line:Hide()
a.stage=CreateFrame("Frame",nil,a)


local function c(d)
local c=CreateFrame("Frame",nil,a.stage)
c:SetFrameLevel(b.overPreviews(a.stage))
c.lines={}
for a=1,4 do
c.lines[a]=c:CreateTexture(nil,"OVERLAY")
b.fill(c.lines[a],d)
end
c:Hide()
return c
end
a.outline=c("accent")

local c=a.outline:CreateAnimationGroup()
local d=c:CreateAnimation("Alpha")
d:SetFromAlpha(1);d:SetToAlpha(1);d:SetDuration(J);d:SetOrder(1)
local d=c:CreateAnimation("Alpha")
d:SetFromAlpha(1);d:SetToAlpha(0);d:SetDuration(K);d:SetOrder(2)
c:SetScript("OnFinished",function()a.outline:Hide()end)
a.outline.fade=c
a.hit=CreateFrame("Button",nil,a)
a.hit:SetAllPoints()
a.hit:SetFrameLevel(b.overPreviews(a.stage,1))
a.hit:EnableMouse(true)
a.hit:SetScript("OnClick",function()self:pickAtCursor()end)
self.area=a

self.loop=function()self:tickCountdown()end
end




function a:tickCountdown()
if not self.frame:IsVisible()then
self.looping=false
return i.unsubscribe(z,self)
end

if self.event or not self.preview then return end
if self.preview:ranOut()then c.try("element banner countdown",self.preview.restart,self.preview)end
end




function a:playEvent(a)
self.event={key=a.key,owner=a.owner,word=a.word,source=a.source,label=a.label,t0=GetTime()}
i.subscribe(0,"element banner event",function()self:tickEvent()end)
self:paintPreview()
if self.preview and self.preview.play then
local a=a.play or{}
c.try("element banner event",self.preview.play,self.preview,a.source,a.event,a.at)
end
end
function a:endEvent()
if not self.event then return end
self.event=nil
i.unsubscribe(0,"element banner event")
self.area.line:Hide()
end
function a:tickEvent()
local a=self.event
if not a then return i.unsubscribe(0,"element banner event")end
local a=(GetTime()-a.t0)/I
if a>=1 or not self.frame:IsVisible()then
self:endEvent()
b.repaint()
return
end
self.area.line:SetWidth(math.max((j-2)*a,0.01))
self.area.line:Show()
end


q.learned=d.learned


local function q(f,d,c,b,g)
local a=c
for e,d in ipairs(d)do
local e=d:GetWidth()
if a>c and a+e>g then
a,b=c,b+r+H
end
d:ClearAllPoints()
d:SetPoint("TOPLEFT",f,"TOPLEFT",a,-b)
a=a+e+x
end
return b+r
end

function a:paint(b,a)
if b~=self.id then self:endEvent()end
self.id,self.view=b,a
if not a then return end

self.alert=a.alert==true
self.move:SetShown(not self.alert)
self.duplicate:ClearAllPoints()
self.duplicate:SetPoint("RIGHT",self.alert and self.delete or self.move,"LEFT",-f,0)
self.export:ClearAllPoints()
self.export:SetPoint("RIGHT",self.duplicate,"LEFT",-f,0)
self.name:SetText(o.nameOf(a))
self.sub:SetText(self:subtitle(a))
self.switch:show(a.enabled and true or false)
self.costs:SetShown(c.isDev and#s(a)>0)

self.delete:setEnabled(not u.inCombat())
self.export:setEnabled(not u.inCombat())
self:paintChips(a)
self:paintPreview()
self.height=e+l+math.max(m,self.shownH)+e
self.frame:SetHeight(self.height)

self.ground:fitArt(self.frame:GetWidth(),self.height)
end


function a:openGroup()
if self.alert then return c.Window.select("alerts","alerts")end
local a=self.id and h.groupOf(self.id)
if a then c.Window.select("group",a)else c.Window.select("loose","loose")end
end

function a:openMove()
if self.id then c.Window.moveMenu(self.move,self.id)end
end



function a:subtitle(f)
local a={}
local e=B.groupOf(h.profile()or{},self.id)
self.group.say(self.alert and"Spell Alert"or e and("In "..(e.name or e.id))or"Not in a group")
a[1]=""
local e=f.origin
if type(e)=="table"and e.name then
local d=e.kind=="premade"and"Pre-made"or"Blueprint"
a[#a+1]=d.." "..b.colorCode("goldLight")..e.name.."|r"

local c,d=c.Blueprints,c.NewModel.BADGES
if e.kind=="premade"and c.premade(e.id)and c.isDraft(e.id)then
a[#a+1]=b.colorCode("help")..d[1][2]:upper().."|r"
end
end

for e,d in ipairs(f.sources or{})do
if c.Sources.experimental(d.kind)then
a[#a+1]=b.colorCode("tagText")..c.Sources.EXPERIMENTAL.word:upper().."|r"
break
end
end
local b=#(f.sources or{})
if b>1 then a[#a+1]=b.." sources"end
if not d.elementLearned(f)then a[#a+1]="Not learned"end
if f.groupOn==false then a[#a+1]="Its group is off"end
return#a>1 and table.concat(a," · ")or""
end


function a:labelAt(d,c,e)
local a=self.labels.take(d)
L(a,d,c.label,g-8-(c.unlearned and n+4 or 0),2,-(e+4))
b.tint(a,(c.off or c.unlearned)and"off"or"white")
a:Show()

local b=a.hit
b:ClearAllPoints()
b:SetPoint("TOPLEFT",a,"TOPLEFT")
b:SetSize(g-8,math.max(a.shownH,1))
b.full=a.wordW and a.wordW+1>g-8-(c.unlearned and n+4 or 0)and c.label or nil
b.key,b.go=c.key,self.hooks.go
b:SetShown(b.full~=nil or(c.key~=nil and b.go~=nil))
a.mark:SetShown(c.unlearned and true or false)
if c.unlearned then
a.mark:ClearAllPoints()
a.mark:SetPoint("TOPLEFT",d,"TOPLEFT",g-8-n,-(e+4))
end
return a
end



function a:follow(b,a)
if not(b and a and self.id)then return end
if a:match("^event:")then
for c,b in ipairs(d.chips(self.id).events)do
if b.key==a then return self:playEvent(b)end
end
return
end
if a:match("^look:")then self:endEvent()end
end

function a:scrollChips(a)
self.chipOffset=math.max(0,math.min(a,self.chipRange))
self.chipScroll:SetVerticalScroll(self.chipOffset)
self.chipBar:paint()
end


function a:pick(a,c)
d.pick(self.id,a,c)
self.drawnView=nil
self:endEvent()
b.repaint()
end


function a:pickAll(a)
for b,a in ipairs(a or{})do d.pick(self.id,a.chip,a.on)end
self.drawnView=nil
self:endEvent()
b.repaint()
end

function a:paintChips(a)
local c=self.chipArea

local a=self.frame:GetWidth()
local a=(a>0 and a or 600)-(self.px+j+v)-self.side
local f=a-D
c:SetWidth(a)
self.chips.reset();self.labels.reset();self.lines.reset()
local a=0
local d=d.chips(self.id)
local e=self.hooks.go
local h=#d.sources>0 or#d.game>0
self.statesWord:SetShown(h)
if h then
self.statesWord:ClearAllPoints()
self.statesWord:SetPoint("TOPLEFT",c,"TOPLEFT",2,-2)
a=y
end
local i=self.event~=nil
local function h(d,h,b,j,l)
local j=self:labelAt(c,{label=d,key=b,unlearned=j},a)
local d={}
for f,a in ipairs(h)do
local c=self.chips.take(c)
local g=a.picked and not i
local f
if l then
f=function()self:pick(a.key,not a.picked)end
else
f=function()self:pick(a.key,true)end
end
c:say(a.label,g and true or false,false,f,e and b and function()e(b)end or nil)
c.rightTip="Right-click: open its source"
d[#d+1]=c
end
a=math.max(q(c,d,g,a,f),a+j.shownH+4)+k
end
for d,b in ipairs(d.sources)do
local d={}
for b,a in ipairs(b.states)do d[#d+1]=a end
h(b.label,d,"source:"..b.id,b.unlearned,nil)

if#b.facts>0 then
a=a-k
local d={}
for b,a in ipairs(b.facts)do
local b=self.chips.take(c)
b:say(a.label,a.picked and not i or false,false,function()self:pick(a.key,not a.picked)end)
d[#d+1]=b
end
a=q(c,d,g,a,f)+k
end
end
if#d.game>0 then h("Game",d.game,nil,nil,true)end

if#d.customStates>0 then h("Custom states",d.customStates,nil,nil,true)end

local d=d.events
self.rule:SetShown(#d>0)
self.eventsWord:SetShown(#d>0)
if#d>0 then
a=a+1
self.rule:ClearAllPoints()
self.rule:SetPoint("TOPLEFT",c,"TOPLEFT",0,-a)
self.rule:SetPoint("TOPRIGHT",c,"TOPRIGHT",0,-a)
a=a+k+3
self.eventsWord:ClearAllPoints()
self.eventsWord:SetPoint("TOPLEFT",c,"TOPLEFT",2,-(a+2))
a=a+y
local g={}
for d,a in ipairs(d)do
local c=self.chips.take(c)
local d=self.event and self.event.key==a.key
c:say(a.label,d and true or false,true,function()
self:playEvent(a)
b.repaint()
end,e and function()e(a.key)end or nil)
c.rightTip="Right-click: open its effects"
g[#g+1]=c
end
a=q(c,g,2,a,f)+k
end
self.chips.hideRest();self.labels.hideRest();self.lines.hideRest()
self.chipsH=a

c:SetHeight(math.max(a,1))
self.shownH=math.min(a,C)
self.chipScroll:SetHeight(math.max(self.shownH,1))
self.chipRange=a-self.shownH
self:scrollChips(self.chipOffset)
end


function a:paintPreview()
local f,e=self.view,self.area
if not f then return end

local a=self.event
for c=1,4 do b.fill(e.ground.edges[c],a and"accent"or"panelEdge")end
e.label:SetText(a and(a.label:gsub("^%l",string.upper))or"Preview")
b.tint(e.label,a and"accent"or"help")
if not self.preview then self.preview=A.new(e.stage,true)end
local b,d=d.previewArgs(self.id)
b=b or f






local e=e.stage:GetFrameLevel()
if a or self.drawnEvent or self.drawnView~=b or self.drawnPicks~=d or self.drawnLevel~=e then
c.try("element banner preview",self.preview.show,self.preview,b,d)
self.drawnView,self.drawnPicks,self.drawnEvent,self.drawnLevel=b,d,a~=nil,e
elseif self.preview:ranOut()then
c.try("element banner countdown",self.preview.restart,self.preview)
end
if self.preview.box then self:placeStage(self.preview.box,f)end
if not self.looping then
self.looping=true
i.subscribe(z,self,self.loop)
end
end



function a:placeStage(e,f)
local d=self.area
local b=d.stage
local g,h=j-12,m-w-8
local a=p.bounds(f)
local c=UIParent:GetEffectiveScale()/d:GetEffectiveScale()
local i=math.min(1,g/(a.w*c),h/(a.h*c))
local c=c*i
b:SetScale(c)
local g,h=g/c,h/c
b:ClearAllPoints()
b:SetPoint("CENTER",d,"CENTER",0,-(w-8)/2/c)
b:SetSize(g,h)
local a,c=g/2-(a.x+a.w/2),h/2-(a.y+a.h/2)
e:ClearAllPoints()
e:SetPoint("TOPLEFT",b,"TOPLEFT",a,-c)
self.origin={x=a,y=c}
self:placeOutline(f)
end

local function e(c,a,d,e,f,g,h)
c:ClearAllPoints()
c:SetPoint("TOPLEFT",a,"TOPLEFT",d.x+e,-(d.y+f))
c:SetSize(g,h)
local a=b.linePx(a,1)
local b=c.lines
for a=1,4 do b[a]:ClearAllPoints()end
b[1]:SetPoint("TOPLEFT",-a,a);b[1]:SetPoint("TOPRIGHT",a,a);b[1]:SetHeight(a)
b[2]:SetPoint("BOTTOMLEFT",-a,-a);b[2]:SetPoint("BOTTOMRIGHT",a,-a);b[2]:SetHeight(a)
b[3]:SetPoint("TOPLEFT",-a,a);b[3]:SetPoint("BOTTOMLEFT",-a,-a);b[3]:SetWidth(a)
b[4]:SetPoint("TOPRIGHT",a,a);b[4]:SetPoint("BOTTOMRIGHT",a,-a);b[4]:SetWidth(a)
c:Show()
end



function a:placeOutline(b)
local a=self.area.outline
local f=self.hooks.selected()or""
local c=d.at(b,f)
local d=c and c.kind=="layer"and c.layer
local c=tostring(self.id).."|"..f
if not d then
a.fade:Stop()
a:Hide()
self.flashed=c
return
end
local b,d,f,g=p.rect(d,b.baseSize,b.layers)
if c==self.flashed then

if a:IsShown()then e(a,self.area.stage,self.origin,b,d,f,g)end
return
end
self.flashed=c
e(a,self.area.stage,self.origin,b,d,f,g)
a:SetAlpha(1)
a.fade:Stop()
a.fade:Play()
end

function a:flashOutline()
self.flashed=nil
if self.view then self:placeOutline(self.view)end
end


function a:pickAtCursor()
local a,c=self.view,self.area.stage
if not(a and self.origin)then return end
local f,g=GetCursorPosition()
local d=c:GetEffectiveScale()
local c,e=c:GetLeft(),c:GetTop()
if not(c and e)then return end
local d,e=f/d-c-self.origin.x,e-g/d-self.origin.y
for c=#a.layers,1,-1 do
local c=a.layers[c]
local a,f,g,h=p.rect(c,a.baseSize,a.layers)
if c.enabled~=false and d>=a and d<=a+g and e>=f and e<=f+h then
self.hooks.select("layer:"..tostring(c.source).."/"..tostring(c.id))
self:flashOutline()
b.repaint()
return
end
end
end
