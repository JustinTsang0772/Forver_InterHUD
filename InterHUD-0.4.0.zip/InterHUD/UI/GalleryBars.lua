



local a,d=...
local a,b,c=d.Gallery,d.GalleryTiles,d.Schema


local e={name="colour",type="colour",default="#ffd140",label="Colour"}



local function f(c)
local d,f,g=b.styleRecord(c)
if not d then return nil end
local e=a.BAR_SIZES[a.sizeOf(c.section.tab)]or a.BAR_SIZES[2]
local a=b.layersOf(d)[1]
a.length,a.thickness=e[1],e[2]
a.colour=c.section.values.colour
return d,f,g
end

local function g()
local b={}
local d=c.choiceLabels("media:bar")
for c,a in ipairs(c.choicesOf("media:bar")())do
b[#b+1]={key="bar:"..a,caption=d[a]or a,style={texture=a}}
end
return b
end




local function h(c,d)
if a.state.animate then
local a=b.firstId(c)
if a then d[a]={state="coolingDown",facts={}}end
end
if not a.state.texts then return end
for c,b in ipairs(b.layersOf(c))do
if b.kind=="bar"then
local a=a.state.font and{face=a.state.font}or nil
b.texts={{id="name",content="name",justify="LEFT",style=a,fontSize=11,x=2},
{id="time",content="time",justify="RIGHT",style=a,fontSize=11,x=-2}}
end
end
end


a.tab("bars",{label="Bars",rank=20,bar={"backdrop","barSize","animate","texts","font","reset"},
parts={barTexture="barTexture"},decorate=h,
build=function(c)
local e=b.section(c,{key="barTexture",title="Bar texture",part="barTexture",tab="bars",
kind="bar",controls={e},record=function(a)return f(a)end})
b.grid(c,e,g())


local a=b.section(c,{key="barGlow",title="Glow on a bar",part="glow",tab="bars",
kind="bar",controls={"colour","speed"},record=function(g)
local c,e=b.sampleOf("barTexture")
if not c then return nil end
c.baseSize=40
if c.sources and c.sources[1]then c.sources[1].spells={a.sampleSpell()}end
local f=a.BAR_SIZES[a.sizeOf("bars")]or a.BAR_SIZES[2]
local a=b.layersOf(c)[1]
a.length,a.thickness=f[1],f[2]
a.glows={{id="glow",style=b.styleOf(g),shown=true}}
return c,e.picks and d.copy(e.picks)or b.picks(c,{first=e.state}),b.profile()
end})
b.grid(c,a,b.kindTiles("glow"))
c:endBlock()
end})


local d={name="colour",type="colour",default="#ffffff",label="Colour"}

local function e()
local b={}
local d=c.choiceLabels("media:font")
for c,a in ipairs(c.choicesOf("media:font")())do
b[#b+1]={key="font:"..a,caption=d[a]or a,style={face=a}}
end
return b
end

a.tab("fonts",{label="Fonts",rank=30,bar={"backdrop","text","reset"},parts={font="font"},
build=function(a)
local c=b.section(a,{key="font",title="Fonts",part="font",tab="fonts",kind="font",
controls={"outline","shadow",d,"size"}})
b.grid(a,c,e())
a:endBlock()
end})


local c=a.resetTab
function a.resetTab(b)
c(b)
if b=="bars"then a.state.texts,a.state.animate=false,false end
if b=="fonts"then a.state.text=a.freshState().text end
end
