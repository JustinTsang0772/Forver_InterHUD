


local a,e=...
local b,a,l=e.Kit,e.Store,e.Combat

local f={}
e.PageProfiles=f

local c=48
local m="\1same"

local function d(b)
for c,a in ipairs(a.profileNames())do
if a==b then return true end
end
return false
end


local function g(a,b)
if a==""then return"Type a name."end

if#a>c then return"That name is too long."end
if a:find("|",1,true)then return"A name can't hold the | character."end
if a~=b and d(a)then return"There is a profile named \""..a.."\" already."end
end
f.problem=g

local function d()return not l.inCombat()end
local n="Out of combat only: switching profiles, New, Copy, Reset and Delete all."



local h={}
local c




local function k(a,f,h,i,j,e)
b.askInline(a,f,h,function(a)
if e and not d()then return n end
local a=strtrim(a or"")
local b=g(a,i)
if b then return b end
if not j(a)then return"That name can't be used."end
end)

c=e and b.askOwner()==a and a or nil
end


function f.askNewProfile(b)
k(b,"Name for the new profile:","",nil,function(b)
local b=a.newProfile(b)
return b and a.useProfile(b)
end,true)
end


local function q(d)
local e,b=a.charKey(),{}
local c=false
for f,d in ipairs(a.profileUsers(d))do
if d==e then c=true else b[#b+1]=a.charLabel(d)end
end
local a={}
if c then a[1]="This character"end
for c=1,math.min(#b,2)do a[#a+1]=b[c]end
if#b>2 then a[#a+1]=(#b-2).." more"end
if#a==0 then return"Not used"end
if#a==1 then return a[1]end
return table.concat(a,", ",1,#a-1).." and "..a[#a]
end


local function p()
local d,b=a.charKey(),{}
for e,c in ipairs(a.profileUsers(a.profileName()))do
if c~=d then b[#b+1]=a.charLabel(c)end
end
if#b==0 then return nil end
return"Also used by "..table.concat(b,", ").."."
end


b.confirm("RESET_PROFILE","Reset the profile \"%s\"? Everything in it is removed, for every character using it.",
"Reset",
function()if d()then a.resetProfile()end end)
b.confirm("DELETE_PROFILE","Delete the profile \"%s\"? A character using it starts with an empty profile at its"
.." next login.","Delete",function(b)a.deleteProfile(b)end)

b.confirm("DELETE_PROFILE_UNUSED","Delete the profile \"%s\"?","Delete",function(b)a.deleteProfile(b)end)


local g="DELETE"
local function r()
local a=b.askText("Delete every profile, for every character? Type "..g.." to confirm.","",
function(b)
if not d()then return n end
if strtrim(b or""):upper()~=g then return"Type "..g.." to delete them all."end
if not a.deleteAllProfiles()then return"That can't be done now."end
end,"Delete all")
h.INTERHUD_TEXT=a
end


local o={}
local function i(c,a,e,f,g,h,i)
local a=b.dropdown(c.content,a,e,f,function(a)
if d()then g(a)end
end,{choices=h})
o[#o+1]=a.dropdown
local e=a.refresh
b.finishRow(a,function(b)
e(b)
local b=d()
a.dropdown:EnableMouse(b)
a.dropdown:SetAlpha(b and 1 or 0.5)
end)
return c:addRow(a,i)
end

f.choice=i

local function j()
local b={}
for c,a in ipairs(a.profileNames())do b[#b+1]={a,a}end
return b
end
f.names=j




local g,s=42,16
local function t(c)
local f=b.row(c.content,g)
local c,h={},0
local i={

{"Use",function(b)
if d()then a.useProfile(b)end
end},
{"Copy",function(b,c)
k(c,"Name for the copy of \""..b.."\":",b.." copy",nil,function(c)
local b=a.copyProfile(b,c)
return b and a.useProfile(b)
end,true)
end},
{"Rename",function(b,c)
k(c,"New name for \""..b.."\":",b,b,function(c)
return c==b or a.renameProfile(b,c)
end)
end},
{"Export ›",function(b)


local a=a.profileNamed(b)
if not a then return end
e.PageShare.state.exportKind="profile"
e.PageShare.showExport(e.Share.exportProfile(a,b))
end},
{"Delete",function(c)
b.showPopup(#a.profileUsers(c)>0 and"DELETE_PROFILE"or"DELETE_PROFILE_UNUSED",c,c)
end},
}
local function j(d)
if c[d]then return c[d]end
local a=CreateFrame("Frame",nil,f)
a:SetHeight(g)
a:SetPoint("TOPLEFT",0,-(d-1)*g)
a:SetPoint("TOPRIGHT",0,-(d-1)*g)
a.links={}
local e=4
for d=#i,1,-1 do
local f=i[d]
local c
c=b.textLink(a,f[1],function()f[2](a.profile,c)end,true)
c:SetPoint("RIGHT",-e,0)

e=e+c:GetWidth()+s
a.links[d]=c
end
a.name=b.fontString(a,"listTop")
a.name:SetPoint("BOTTOMLEFT",a,"LEFT",4,1)
a.name:SetPoint("RIGHT",-e,0)
a.name:SetJustifyH("LEFT")
a.name:SetWordWrap(false)
a.users=b.fontString(a,"dim")
a.users:SetPoint("TOPLEFT",a,"LEFT",4,-3)
a.users:SetPoint("RIGHT",-e,0)
a.users:SetJustifyH("LEFT")
a.users:SetWordWrap(false)
a.rule=a:CreateTexture(nil,"ARTWORK")
b.fill(a.rule,"rule",0.2)
a.rule:SetHeight(1)
a.rule:SetPoint("BOTTOMLEFT",0,0)
a.rule:SetPoint("BOTTOMRIGHT",0,0)
c[d]=a
return a
end
f.height=function()return math.max(h,1)*g end
f.rows=c
return b.finishRow(f,function()
local e,f=a.profileNames(),a.profileName()
h=#e
for g,e in ipairs(e)do
local c=j(g)
c.profile=e
c.name:SetText(e)
b.tint(c.name,e==f and"gold"or"listTopText")
c.users:SetText(q(e))

c.links[1]:SetShown(e~=f)
c.links[1]:setEnabled(d())
c.links[2]:setEnabled(d())
c.links[4]:setEnabled(d())

c.links[5]:SetShown(not a.usedHere(e))
c.rule:SetShown(g<h)
c:Show()
end
for a=h+1,#c do c[a]:Hide()end
end)
end

l.onStart("profiles page",function()
if c and b.askOwner()==c then b.closeAsk()end
c=nil
for b,a in pairs(h)do
if a and a:IsShown()and a.which==b then a:Hide()end
h[b]=nil
end
for b,a in ipairs(o)do a:CloseMenu()end
end)


local q={key="profiles",label="Profiles",icon=b.art("iconProfiles"),
line="Switch, copy, rename."}

b.registerPage("profiles",{settings=true,build=function(c)
c.noFoldAll=true
local g=e.PageShare
local function k()return a.talentGroups()==2 end
local function o()return g.state.tab=="profiles"end
c:plainTitle({title="Profiles & sharing",icon=b.art("iconProfiles"),
note=function()return a.ready()and("This character: "..tostring(a.profileName()))or""end,

button={title="Collections",line="Ready-made HUDs by class.",
click=function()e.Window.openNew(nil,"collection")end}})
local e={q}
for b,a in ipairs(g.TABS)do e[#e+1]=a end
g.frames.tabs=c:tabs(e,function()return g.state.tab end,function(a)g.state.tab=a end)
c:callout(n,function()return l.inCombat()and o()end)

c:block({key="char",title="This character",card=true,shown=o,
note=function()return a.charLabel(a.charKey())or""end,
link={text="Reset profile",enabled=d,
click=function()h.INTERHUD_RESET_PROFILE=b.showPopup("RESET_PROFILE",a.profileName())end}})
i(c,"Profile","The profile this character uses.",function()return a.profileFor(1)end,
function(b)a.useProfile(b,1)end,j,function()return not k()end)
i(c,"Primary spec","The profile for your primary talents.",
function()return a.profileFor(1)end,function(b)a.useProfile(b,1)end,j,k)
i(c,"Secondary spec","The profile for your secondary talents.",function()
local b=a.char()
return b and b.profiles and b.profiles[2]and a.profileFor(2)or m
end,function(b)a.useProfile(b~=m and b or nil,2)end,function()
local a={{m,"Same as primary"}}
for c,b in ipairs(j())do a[#a+1]=b end
return a
end,k)
c:hint("Switches as you change spec.",nil,k)
c:hint(function()return p()or""end,nil,function()return p()~=nil end)
c:block({key="all",title="All profiles",card=true,shown=o,
link={text="Delete all profiles",enabled=d,click=r}})
local a
a=c:buttons({{text="New profile",width=130,enabled=d,
click=function()f.askNewProfile(a.buttons[1])end}})

a.buttons[1]:SetPoint("LEFT",b.EDGE,0)
c:addRow(t(c))
c:endBlock()
g.build(c)
end})
