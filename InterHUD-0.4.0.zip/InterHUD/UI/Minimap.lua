


local e,a=...
local d,j,g,k,h=a.Store,a.Events,a.Kit,a.Window,a.Placement

local c={frames={}}
a.Minimap=c

local b="InterHUD"


local m="Interface\\AddOns\\"..e.."\\Art\\LogoMinimap"








local e={}
local f
local i

local function l()
if not f then return end
local a=d.ui().minimap
e.hide=a.hidden or nil
if a.angle~=i then e.minimapPos,i=a.angle,a.angle end
if a.hidden then f:Hide(b)else f:Show(b)end
end

local function n(b,a)
if a=="RightButton"then
h.setUnlocked(not h.unlocked())
else
k.toggle()
end
end

local function o(a)
local c,d,e=g.rgba("gold")
a:AddLine(b)
a:AddLine("Click: options",c,d,e)
a:AddLine(h.unlocked()and"Right-click: lock positioning"or"Right-click: unlock positioning",c,d,e)
end

local function h()
local a=_G.LibStub
local g=a and a("LibDataBroker-1.1",true)
local a=a and a("LibDBIcon-1.0",true)
if not(g and a)or a:IsRegistered(b)then return end
local g=g:NewDataObject(b,{type="launcher",text=b,icon=m,
OnClick=n,OnTooltipShow=o})
if not g then return end
local d=d.ui().minimap
e.hide,e.minimapPos,i=d.hidden or nil,d.angle,d.angle
a:Register(b,g,e)
f=a
c.frames.button=a:GetMinimapButton(b)
end


local function i()
local b=e.minimapPos
if not f or type(b)~="number"or a.isSecret(b)then return end
b=math.floor((b%360)*10+0.5)/10
if b==d.ui().minimap.angle then return end
d.editUI(function(a)
a.minimap=a.minimap or{}
a.minimap.angle=b
end)
end


function c.shown()return not d.ui().minimap.hidden end
function c.setShown(b)
return d.editUI(function(a)
a.minimap=a.minimap or{}
a.minimap.hidden=not b or nil
end)
end



local function d()
if not(Settings and Settings.RegisterCanvasLayoutCategory and Settings.RegisterAddOnCategory)then return end
local d=CreateFrame("Frame")
local e=g.fontString(d,"title")
e:SetPoint("TOPLEFT",16,-16)
e:SetText(b)
local f=g.fontString(d,"label")
f:SetPoint("TOPLEFT",e,"BOTTOMLEFT",0,-10)
f:SetText("Its options have a window of their own. /ihud opens it too.")
local e=g.button(d,"Open options",160,26)
e:SetPoint("TOPLEFT",f,"BOTTOMLEFT",0,-14)
e:SetScript("OnClick",function()


if SettingsPanel and SettingsPanel:IsShown()and not InCombatLockdown()then
if SettingsPanel.Close then SettingsPanel:Close(true)else HideUIPanel(SettingsPanel)end
end
k.open()
end)
local f,b=a.try("settings category",Settings.RegisterCanvasLayoutCategory,d,b)
if not(f and b)then return end
a.try("settings register",Settings.RegisterAddOnCategory,b)
c.category=b
c.frames.panel,c.frames.open=d,e
end


j.on("PLAYER_LOGIN","minimap",function()
h()
l()
d()
end)
j.on("PLAYER_LOGOUT","minimap",i)
a.onChanged(function(a)
if a=="ui"then l()end
end,"minimap")
