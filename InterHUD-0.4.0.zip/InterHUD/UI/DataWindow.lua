







local a,e=...
local c,i,h,k=e.Kit,e.GameData,e.Spells,e.Combat

local d={}
e.DataWindow=d


d.WORDS={
title="Game data",
kinds={{"all","All"},{"spell","Spells"},{"aura","Auras"},{"item","Items"}},
units={{"any","Anywhere"},{"player","On you"},{"target","On the target"},{"pet","On your pet"}},
pickOne="Pick a row to see it whole.",notInData="Not in the game data: the client's own.",
waits="The game data waits until combat ends.",close="Close",
what="What",class="Class",kind="Kind",cooldown="Cooldown",charges="Charges",ranks="Ranks",
members="Members",auras="Auras",dispels="Dispels",watchedBy="Watched by",spellbook="Spellbook",
races="Races",landsOn="Lands on, as cast",length="Lasts",from="From",flags="Flags",level="Level",
dispelType="Dispel type",
onUse="On use",shared="Shared cooldown",none="none",
family="A class's spell family",petFamily="A pet's spell family",racial="A racial",single="A spell",
item="An item",talent="a talent",cast="Cast",passive="Passive",aura="Aura",
known="In your spellbook",unknownBook="Not in your spellbook",inDoubt="Not read: a talent, a passive or a pet's",
on={player="you",target="an enemy",ally="a friend",pet="your pet"},
where={p="you",t="an enemy",a="a friend",e="a pet"},
fromWords={c="a class",p="a pet",i="an item",e="an enchant",s="a set",o="other"},
flagWords={i="an internal name",p="the placeholder icon"},
endless="never ends",seconds="%s s",rankLevel="%d (level %d)",
why={rank="rank %d",copy="a copy",aura="its aura",item="an item's",forever="Forever's own",
other="another's",camp="a camp's buff"},
}
local b=d.WORDS



local f=200
local function g()
local b,a=UnitClass("player")
return a
end

function d.list(a)
local c=e.PickerModel
local d={
{key="kind",value=a.kind or"all",choices=b.kinds},
{key="class",value=a.class or"any",choices=c.WORDS.classes},
{key="learned",value=a.learned or"all",choices=c.WORDS.learned},
}
if a.kind=="aura"then d[#d+1]={key="unit",value=a.unit or"any",choices=b.units}end
if k.inCombat()then return{chips=d,rows={},empty=b.waits}end
local b=a.class or"any"
local b={kind=a.kind~="all"and a.kind or nil,learned=a.learned=="learned"or nil,
class=b=="yours"and g()or b=="none"and"none"or nil,
unit=a.kind=="aura"and a.unit~="any"and a.unit or nil}
local g,h=i.search(a.words or"",b,{limit=f})
local b={}
local e=a.ref
for d,a in ipairs(g)do
local a=c.listRow(a)
a.picked=e~=nil and a.ref.id==e.id and a.ref.kind==e.kind or nil
b[d]=a
end
return{chips=d,rows=b,empty=#b==0 and c.WORDS.nothing or nil,
more=h>f and c.WORDS.more or nil}
end



local function g(a)return b.seconds:format(a)end
local function f(c,b,d)
local a={}
for d,c in ipairs(c or{})do a[d]=b and b(c)or tostring(c)end
return#a>0 and table.concat(a,d or", ")or nil
end
local function j(a)return a and e.NewModel.className(a)or nil end


local function l(a,c)
c(b.cooldown,a.cooldown and g(a.cooldown))
c(b.charges,a.charges and tostring(a.charges))
local d={}
for c,e in ipairs(a.ranks or{})do
local a=a.levels and a.levels[c]
d[c]=a and b.rankLevel:format(e,a)or tostring(e)
end
c(b.ranks,#d>1 and table.concat(d,", ")or nil)
local d={}

for c,b in ipairs(a.members or{})do
if b.id~=a.key and b.why~="rank"then d[#d+1]=b end
end
table.sort(d,function(a,b)return a.id<b.id end)
c(b.members,f(d,function(a)
local b=b.why[a.why]or tostring(a.why)
return a.id..": "..(a.why=="rank"and b:format(a.rank or 0)or b)
end,"\n"))
local d={}
for c,e in ipairs({"player","target","ally","pet"})do
local c=a.auras and a.auras[e]
if c and#c>0 then
d[#d+1]=b.on[e]..": "..f(c,function(c)
local d=false
for b,a in ipairs(a.endless or{})do d=d or a==c end
local a=a.durations and a.durations[c]
return d and(c.." ("..b.endless..")")or a and(c.." ("..g(a)..")")or tostring(c)
end)
end
end
c(b.auras,#d>0 and table.concat(d,"\n")or nil)
c(b.dispels,a.dispels and(f(a.dispels)..(a.dispelsOn and(", "..f(a.dispelsOn))or"")))
end



local function m(a)
if a.spellKind=="aura"then return nil end
if h.inBook(a.key)then return b.known end
if a.pet or a.talent or a.spellKind=="passive"then return b.inDoubt end
return b.unknownBook
end

function d.detail(d)
if not d then return nil end
local a=i.describe(d.key,d.kind=="item"and"item"or nil)
local e={}

local function c(b,a)
if a and a~=""then e[#e+1]={label=b,value=a}end
end
if not a then
local a=d.kind=="item"and i.byId(d.id,true)or i.byId(d.id)
c(b.what,b.notInData)
return{title=a.name or tostring(d.id),icon=a.icon,id=d.id,lines=e}
end
local i=a.row or{}
if a.kind=="family"then
c(b.what,(a.pet and b.petFamily or b.family)..(a.talent and(", "..b.talent)or""))
c(b.class,j(a.class))
c(b.kind,a.spellKind=="spell"and b.cast or a.spellKind=="aura"and b.aura or b.passive)
l(a,c)
c(b.spellbook,m(a))
elseif a.kind=="racial"then
c(b.what,b.racial)
c(b.kind,a.spellKind=="spell"and b.cast or b.passive)
c(b.races,f(a.races))
l(a,c)
c(b.spellbook,m(a))
elseif a.kind=="single"then
c(b.what,b.single)
c(b.from,b.fromWords[a.from])
c(b.class,j(a.class~=""and a.class or nil))
c(b.landsOn,b.where[a.where])
c(b.length,a.length and(a.length<0 and b.endless or g(a.length))or nil)
c(b.dispelType,a.dispel~=""and a.dispel or nil)
elseif a.kind=="item"then
c(b.what,b.item)
c(b.level,a.level and tostring(a.level))
c(b.onUse,a.spell and(a.spell..(h.nameOf(a.spell)and(" "..h.nameOf(a.spell))or"")))
c(b.shared,a.cooldown and(g(a.cooldown)..(a.category and(" ("..a.category..")")or"")))
end
local f={}
for a in tostring(a.flags or""):gmatch(".")do f[#f+1]=b.flagWords[a]end
c(b.flags,#f>0 and table.concat(f,", ")or nil)
local f={}
for b,a in ipairs(a.sources or{})do f[b]=a.label or a.key end
c(b.watchedBy,#f>0 and table.concat(f,", ")or b.none)
return{title=i.name or a.name or tostring(d.key),icon=i.icon or a.icon,id=d.id or d.key,
lines=e}
end



local o,l,p,g,j,f="InterHUDData",840,580,12,330,20
local m,q=110,6
local a
local h={words="",kind="all",class="any",learned="all",unit="any"}


local function n(b,e)
local a=CreateFrame("ScrollFrame",nil,b)
local d=CreateFrame("Frame",nil,a)
d:SetSize(e,1)
a:SetScrollChild(d)
local function e()return a:GetVerticalScrollRange()end
local b=c.scrollBar(b,{
offset=function()return a:GetVerticalScroll()end,
range=e,
view=function()return a:GetHeight()end,
scrollTo=function(b)a:SetVerticalScroll(math.max(0,math.min(b,e())))end,
})
b:SetPoint("TOPLEFT",a,"TOPRIGHT",4,0)
b:SetPoint("BOTTOMLEFT",a,"BOTTOMRIGHT",4,0)
a:SetScript("OnScrollRangeChanged",function()b:paint()end)
a:SetScript("OnVerticalScroll",function()b:paint()end)
a:EnableMouseWheel(true)
a:SetScript("OnMouseWheel",function(c,b)
a:SetVerticalScroll(math.max(0,math.min(a:GetVerticalScroll()-b*40,e())))
end)
return a,b,d
end

local function r(e)
local b=a.segs[e]
if b then return b end
b=c.segment(a.frame,"small")
b:SetHeight(f)
b:SetScript("OnClick",function(a)
h[a.chip]=a.value
d.refresh()
end)
a.segs[e]=b
return b
end

local function s(e)
local d,b=6,0
for g,e in ipairs(e)do
local g=-6
for h,f in ipairs(e.choices)do
b=b+1
local b=r(b)
b.chip,b.value=e.key,f[1]
b.text:SetText(f[2])
b:SetWidth(c.textWidth("small",f[2])+14)
b:ClearAllPoints()
b:SetPoint("TOPLEFT",a.box,"BOTTOMLEFT",g,-d)
c.paintSegment(b,e.value==f[1])
b:Show()
g=g+b:GetWidth()-(h<#e.choices and 1 or 0)
end
d=d+f+4
end
for b=b+1,#a.segs do a.segs[b]:Hide()end
return d
end

local function f(e)
local f=j-12
local b=0
for g,i in ipairs(e.rows)do
local e=a.rows[g]
if not e then
e=c.pickRow(a.listContent,function(a)
h.ref=a.ref
d.refresh()
end)
a.rows[g]=e
end
b=b+c.placePickRow(e,i,b,f)
end
for b=#e.rows+1,#a.rows do a.rows[b]:Hide()end
local c=e.empty or e.more
a.listNote:SetShown(c~=nil)
if c then
a.listNote:ClearAllPoints()
a.listNote:SetPoint("TOPLEFT",a.listContent,"TOPLEFT",6,-(b+4))
a.listNote:SetWidth(f-12)
a.listNote:SetText(c)
b=b+a.listNote:GetStringHeight()+8
end
a.listContent:SetSize(f,math.max(b,1))
a.listBar:paint()
end

local function r(d)
local b=a.lines[d]
if b then return b end
b={label=c.fontString(a.detail,"small"),value=c.fontString(a.detail,"small")}
c.tint(b.label,"help")
b.label:SetJustifyH("LEFT")
b.value:SetJustifyH("LEFT")
b.value:SetJustifyV("TOP")
a.lines[d]=b
return b
end
local function t()
local d=h.ref and d.detail(h.ref)
local f=a.detailScroll:GetWidth()
a.detail:SetWidth(f)
a.name:SetText(d and d.title or b.pickOne)
a.icon:SetShown(d~=nil)
a.copy:SetShown(d~=nil)
a.shownId=d and d.id or nil
if d then
a.icon:SetTexture(d.icon or c.art("iconUnknown"))
a.copy:SetText(tostring(d.id))
a.copy:HighlightText()
end
local e=0
for b,d in ipairs(d and d.lines or{})do
local b=r(b)
b.label:ClearAllPoints()
b.label:SetPoint("TOPLEFT",a.detail,"TOPLEFT",0,-e)
b.label:SetText(d.label)
b.value:ClearAllPoints()
b.value:SetPoint("TOPLEFT",a.detail,"TOPLEFT",m,-e)
b.value:SetWidth(f-m-4)
b.value:SetText(d.value)
b.label:Show()
b.value:Show()
e=e+math.max(b.value:GetStringHeight(),c.fontSize("small"))+q
end
for b=#(d and d.lines or{})+1,#a.lines do
a.lines[b].label:Hide()
a.lines[b].value:Hide()
end
a.detail:SetHeight(math.max(e,1))
a.detailBar:paint()
end

function d.refresh()
if not(a and a.frame:IsShown())then return end
local b=d.list(h)
local c=s(b.chips)
a.listScroll:ClearAllPoints()
a.listScroll:SetPoint("TOPLEFT",a.box,"BOTTOMLEFT",-6,-(c+4))
a.listScroll:SetPoint("BOTTOMLEFT",a.frame.foot,"TOPLEFT",g,g)
a.listScroll:SetWidth(j-12)
f(b)
t()
end



local m,f,q=24,20,12
local function r()
local a=CreateFrame("Frame",o,UIParent)


a:SetFrameStrata("DIALOG")
local d=a:CreateTexture(nil,"BACKGROUND",nil,1)
d:SetAllPoints()
c.fill(d,"windowBg")
local d,h=c.edge(a)
local d=a:CreateTexture(nil,"BACKGROUND",nil,2)
d:SetHeight(m)
c.gradient(d,"titleHigh","titleLow")
a.titleBar=d
local g=a:CreateTexture(nil,"BORDER")
g:SetPoint("TOPLEFT",d,"BOTTOMLEFT")
g:SetPoint("TOPRIGHT",d,"BOTTOMRIGHT")
c.fill(g,"metalLow")
a.title=c.fontString(a,"windowTitle")
a.title:SetText(b.title)
a.title:SetPoint("CENTER",d,"CENTER",0,0)
local e=c.button(a,"",f,f)
e:SetPoint("RIGHT",d,"RIGHT",-3,0)
e.x=e:CreateTexture(nil,"OVERLAY")
e.x:SetTexture(c.art("close"))
e.x:SetVertexColor(c.rgba("gold"))
e.x:SetPoint("CENTER")
e.x:SetSize(f-2,f-2)
e:SetScript("OnClick",function()a:Hide()end)
e.simLabel=b.close
a.foot=CreateFrame("Frame",nil,a)
a.foot:SetHeight(q)

local b=h()
d:SetPoint("TOPLEFT",b,-b)
d:SetPoint("TOPRIGHT",-b,-b)
g:SetHeight(c.linePx(a,1))
a.foot:SetPoint("BOTTOMLEFT",b,b)
a.foot:SetPoint("BOTTOMRIGHT",-b,b)
return a
end

local function f()
local b=r()
b:SetSize(l,p)
b:SetPoint("CENTER",120,0)
b:SetToplevel(true)
b:SetClampedToScreen(true)
b:SetMovable(true)
b:EnableMouse(true)

b:EnableMouseWheel(true)
b:SetScript("OnMouseWheel",function()end)
b:RegisterForDrag("LeftButton")
b:SetScript("OnDragStart",b.StartMoving)
b:SetScript("OnDragStop",b.StopMovingOrSizing)
a={frame=b,segs={},rows={},lines={}}

local f=CreateFrame("EditBox",nil,b,"SearchBoxTemplate")
f:SetSize(j-12,24)
f:SetPoint("TOPLEFT",b.titleBar,"BOTTOMLEFT",g,-10)
f:SetMaxLetters(48)
f:SetFontObject(c.font("field"))
f.Instructions:SetText(e.PickerModel.WORDS.hint)
f.simLabel="Search"
f:HookScript("OnTextChanged",function(a,b)
if b then
h.words=a:GetText()
d.refresh()
end
end)
f.clearButton:HookScript("OnClick",function()
h.words=""
d.refresh()
end)
a.box=f
a.listScroll,a.listBar,a.listContent=n(b,j-12)
a.listNote=c.fontString(a.listContent,"small")
c.tint(a.listNote,"help")
a.listNote:SetJustifyH("LEFT")

local f=g+j+12
a.icon=b:CreateTexture(nil,"ARTWORK")
a.icon:SetSize(32,32)
a.icon:SetPoint("TOPLEFT",b.titleBar,"BOTTOMLEFT",f,-10)
c.cropIcon(a.icon)
a.name=c.fontString(b,"listTop")
a.name:SetPoint("TOPLEFT",a.icon,"TOPRIGHT",8,0)
a.name:SetPoint("RIGHT",-g,0)
a.name:SetJustifyH("LEFT")
a.copy=c.copyBox(b,function()return tostring(a.shownId or"")end,120)
a.copy:SetPoint("TOPLEFT",a.icon,"TOPRIGHT",8,-16)
a.copy.simLabel="ID"
a.detailScroll,a.detailBar,a.detail=n(b,l-f-g-24)
a.detailScroll:SetPoint("TOPLEFT",a.icon,"BOTTOMLEFT",0,-14)
a.detailScroll:SetPoint("BOTTOMRIGHT",b.foot,"TOPRIGHT",-g-12,g)
b:SetScript("OnShow",function()d.refresh()end)

b:SetScript("OnHide",function()
local a=_G[c.WINDOW_NAME]
if not(a and a:IsShown())then i.release()end
end)



b:EnableKeyboard(true)
b:SetPropagateKeyboardInput(true)
b:SetScript("OnKeyDown",function(a,b)
if b~="ESCAPE"then return end
local b=_G[c.WINDOW_NAME]
if b and b:IsShown()and b:GetFrameLevel()>a:GetFrameLevel()then return end
if InCombatLockdown()then
a:Hide()
return
end
a:SetPropagateKeyboardInput(false)
a:Hide()
e.Events.atFrameEnd("data window escape",function()
if not InCombatLockdown()then a:SetPropagateKeyboardInput(true)end
end)
end)
b:Hide()
end

function d.isShown()return a~=nil and a.frame:IsShown()end

function d.frames()return a end

function d.toggle()
if d.isShown()then return a.frame:Hide()end
if k.inCombat()then return e.print(b.waits)end
if not a then f()end
a.frame:Show()
a.box:SetFocus()
end

k.onStart("data window",function()if d.isShown()then a.frame:Hide()end end)
