


local b,a=...
local b,c,k,e,l,d=a.Kit,a.Store,a.Resolve,a.Form,a.Schema,a.Window
local u=a.Combat



local n=14

local function h(a,b)return a.." "..b..(a==1 and""or"s")end

local function o(b)
local a=l.field("group","arrangement")
local b=k.group(b,c.profile()).arrangement
return a.labels and a.labels[b]or tostring(b)
end

local function p(b)
local a=0
for d,b in ipairs(b.members or{})do
if c.element(b)then a=a+1 end
end
return a
end



local g,i,j,f=nil,nil,nil,0
a.onChanged(function()f=f+1 end,"group pages")

a.Spells.onChange("group pages",function()f=f+1 end)
local function m()
local a=GetTime()
if not(g and i==a and j==f)then g,i,j=d.entries(),a,f end
return g
end



local function v()
local a=0
for c,b in ipairs(m())do
if b.kind=="element"and not b.alert then a=a+1 end
end
return a
end
local function w()return v()>0 end
local function x()return w()and"Every element is in a group."or"Nothing made yet."end


local function y()return d.looseEntries(m())end





local i,q,j=28,16,200



local function r(b,c,a)
b.refusal=not c and(a and a[1]and a[1].text or"That can't be done.")or nil
b:refresh()
return c
end
local function z(a)
a:callout(function()return a.refusal or""end,function()return a.refusal~=nil end)
a.onShow=function()a.refusal=nil end
end

local function A(c)
for d=0,1 do
for e=-1,1 do
local a=c:CreateTexture(nil,"ARTWORK")
b.fill(a,"dots")
a:SetSize(2,2)
a:SetPoint("CENTER",c,"LEFT",6+d*4,e*4)
end
end
end

local function t(f)
local a=CreateFrame("Button",nil,f)
a:SetHeight(i-2)
a:EnableMouse(true)
local g=a:CreateTexture(nil,"HIGHLIGHT")
g:SetAllPoints()
b.fill(g,"white",0.05)
local g=f.opts.fixed

if not g then A(a)end
a.icon=a:CreateTexture(nil,"ARTWORK")
a.icon:SetSize(20,20)
a.icon:SetPoint("LEFT",g and 4 or q,0)
b.cropIcon(a.icon)
a.text=b.fontString(a,"label")
a.text:SetPoint("LEFT",a.icon,"RIGHT",8,0)
a.text:SetJustifyH("LEFT")
a.text:SetWordWrap(false)
a.mark=b.unlearnedMark(a,14)
local function h()
local a=a.id and c.element(a.id)
return a~=nil and a.enabled~=false
end

a.switch=b.pillSwitch(a,h,function(b)return e.set(a.id,{"enabled"},b)end,"On",
"Switch this element on or off.",nil,true)
if f.opts.remove then

a.remove=b.textLink(a,"Take out",function()r(f.opts.page,d.moveElement(a.id))end,true)
a.remove:SetPoint("RIGHT",-6,0)
b.setTip(a.remove,"Take out","Out of the group, where it sits on the screen.")

a.remove:HookScript("OnEnter",function(a)b.tint(a.text,"gold")end)
a.remove:HookScript("OnLeave",function(a)a:rested()end)
a.switch:SetPoint("RIGHT",a.remove,"LEFT",-8,0)
else
a.switch:SetPoint("RIGHT",-8,0)
end
a.mark:SetPoint("RIGHT",a.switch,"LEFT",-8,0)
a.text:SetPoint("RIGHT",a.mark,"LEFT",-6,0)


a.menuAt=CreateFrame("Frame",nil,a)
a.menuAt:SetPoint("TOPLEFT",a.icon,"TOPLEFT",0,3)
a.menuAt:SetSize(j,i-2)
a.menuAt.deleteMenu=true
a:RegisterForClicks("LeftButtonUp","RightButtonUp")
a:SetScript("OnClick",function(a,c)
if c=="RightButton"then return d.rowMenu(a.menuAt)end
if not b.justDragged(a)then d.select("element",a.id)end
end)
if not g then
b.draggable(a,{payload=function()return a.id end,icon=function()return d.iconOf(a.id)end,
label=function()return a.text:GetText()end,scroll=f.opts.scroll})
end
return a
end


local function j()
local b={}
for c,a in ipairs(m())do
if a.kind=="element"then b[a.id]=a end
end
return b
end


local function g(e,f,h)
local a=e.model
if not a then return end
local b=a.groupId
local c,g=c.groupOf(f)
if c==nil and b==nil then return end
local a=a.ordered~=false and h or nil
if a and c==b and g<a then a=a-1 end

if c==b and(a==nil or a==g)then return end
r(e.opts.page,d.moveElement(f,b,a))
end





local function s(a,e)
local a=CreateFrame("Frame",nil,a)
a.opts,a.rows,a.h=e,{},i
a.empty=b.fontString(a,"small")
b.tint(a.empty,"help")

a.empty:SetPoint("LEFT",4,0)
a.zone=not e.fixed and b.dropZone(a,{
rows=function()
local b={}
for c=1,a.n or 0 do b[c]=a.rows[c]end
return b
end,
drop=function(b,c)g(a,b,c)end,


accepts=function(b)
if type(b)~="string"then return false end
local a=a.model and a.model.groupId
if a==nil then return c.groupOf(b)~=nil end
return c.groupOf(b)==a or not c.full("members",a)
end,
clip=e.clip,
})
function a:paint(a,g)
self.model=a
if self.zone then self.zone.spec.ordered=a.ordered end
local e=j()
local c=0
for a,f in ipairs(a.ids)do
local e=e[f]
if e then
c=c+1
local a=self.rows[c]or t(self)
self.rows[c]=a
a.id,a.menuAt.entry=f,e
a.icon:SetTexture(d.iconOf(f))
a.icon:SetDesaturated((e.off or e.unlearned)and true or false)
a.text:SetText(e.label)
b.tint(a.text,(e.off or e.unlearned)and"off"or"text")
a.mark:SetShown(e.unlearned and true or false)
a.switch:show(not e.off)
a:ClearAllPoints()
a:SetPoint("TOPLEFT",0,-(c-1)*i)
a:SetWidth(g)
a:Show()
end
end
for a=c+1,#self.rows do self.rows[a]:Hide()end
self.n=c
self.empty:SetText(a.empty or"")
self.empty:SetShown(c==0)
self.h=math.max(c,1)*i
self:SetSize(g,self.h)
end
return a
end


local function t(a)
return{frame=a.scroll,by=function(b)a:scrollBy(b)end}
end


local function B()
local a={}
for c,b in ipairs(y())do a[#a+1]=b.id end
return a
end



local j,g,C=38,10,10




local function D(a,c)
local a=CreateFrame("Frame",nil,a)
a.panel=b.panel(a,nil,nil,nil,"card")
a.head=CreateFrame("Button",nil,a)
a.head:SetPoint("TOPLEFT",g,-4)
a.head:SetPoint("TOPRIGHT",-g,-4)
a.head:SetHeight(j-10)
a.head.grip=CreateFrame("Frame",nil,a.head)
a.head.grip:SetSize(q,j-10)
a.head.grip:SetPoint("LEFT")
A(a.head.grip)
local e={payload=function()return a.model and a.model.groupId and{group=a.model.groupId}or nil end,
icon=function()return a.model and a.model.icon end,
label=function()return a.model and a.model.name or""end,scroll=t(c)}
b.draggable(a.head,e)
a.icon=a:CreateTexture(nil,"ARTWORK")
a.icon:SetSize(20,20)

a.icon:SetPoint("TOPLEFT",g+q,-9)
b.cropIcon(a.icon)
a.name=CreateFrame("Button",nil,a.head)
a.name:SetHeight(22)
a.name:SetPoint("LEFT",a.icon,"RIGHT",8,0)
a.name.text=b.fontString(a.name,"sectionSmall")
a.name.text:SetPoint("LEFT")
a.name:SetScript("OnEnter",function(a)b.tint(a.text,"goldLight")end)
a.name:SetScript("OnLeave",function(a)b.tint(a.text,b.fontColor("sectionSmall"))end)
b.draggable(a.name,e)
a.name:SetScript("OnClick",function(c)
if b.justDragged(c)then return end
local a=a.model and a.model.groupId
if a then d.select("group",a)else d.select("loose","loose")end
end)
a.note=b.fontString(a,"dim")
a.note:SetPoint("LEFT",a.name,"RIGHT",10,-1)


a.delete=b.textLink(a.head,"Delete",function(b)d.groupDeleteMenu(b,a.model and a.model.groupId)end,
true)
a.delete.simLabel="Delete"
a.delete:SetPoint("RIGHT",a.head,"RIGHT",0,0)
a.delete:HookScript("OnEnter",function(a)
if not a:IsEnabled()then b.note(a,"Delete group: not in combat")end
end)
a.delete:HookScript("OnLeave",function()b.note()end)

a.settings=b.textLink(a.head,"Group settings",function()
if a.model and a.model.groupId then d.select("group",a.model.groupId)end
end,true):leaves()
a.settings:SetPoint("RIGHT",a.delete,"LEFT",-16,0)
a.rule=a:CreateTexture(nil,"ARTWORK")
b.fill(a.rule,"white")
a.rule:SetGradient("HORIZONTAL",b.colorObj("rule",0.30),b.colorObj("rule",0))
a.rule:SetHeight(1)
a.rule:SetPoint("TOPLEFT",g,-(j-4))
a.rule:SetPoint("TOPRIGHT",-g,-(j-4))
a.list=s(a,{scroll=t(c),clip=c.scroll,page=c})
a.list:SetPoint("TOPLEFT",g,-j)
return a
end


local function q()
local d={}
for c,a in ipairs((c.profile()or{}).groups or{})do
d[#d+1]={groupId=a.id,name=a.name or a.id,icon=b.art("iconGroup"),
note=o(a).." · "..h(p(a),"element"),ids=a.members or{},
empty="Drag elements here."}
end
local a=B()
d[#d+1]={name="Not in a group",icon=b.art("iconLoose"),note=h(#a,"element"),
ids=a,ordered=false,empty=x()}
return d
end


local function A(e,b,a)
local d=type(b)=="table"and b.group
local f=(c.profile()or{}).groups or{}
local b
for a,c in ipairs(f)do if c.id==d then b=a end end
if not(b and a)then return end
local a=a>b and a-1 or a
if a==b then return end
r(e,c.moveGroup(d,a))
end

local function r(d)
local c=b.row(d.content,1)
c.cards={}
local a=1
c.height=function()return a end

b.dropZone(c,{
rows=function()
local b={}
for c,a in ipairs(c.cards)do
if a:IsShown()and a.model and a.model.groupId then b[#b+1]=a end
end
return b
end,
drop=function(a,b)A(d,a,b)end,
accepts=function(a)return type(a)=="table"and a.group~=nil end,
clip=d.scroll,
})
return b.finishRow(c,function(f)
local e=0
local b=q()
local i=u.inCombat()
for h,b in ipairs(b)do
local a=c.cards[h]or D(c,d)
c.cards[h]=a
a.model=b
local c=b.groupId~=nil
a.head.grip:SetShown(c)
a.settings:SetShown(c)
a.delete:SetShown(c)
a.delete:setEnabled(not i)
a.icon:SetTexture(b.icon)
a.name.text:SetText(b.name)

a.name:SetWidth(a.name.text:GetStringWidth()+2)
a.note:SetText(b.note)
a.list:paint(b,f-2*g)
local b=j+a.list.h+g
a:ClearAllPoints()
a:SetPoint("TOPLEFT",0,-e)
a:SetSize(f,b)
a.panel:place(d:pixels(1),{a,"TOPLEFT",0,0},{a,"BOTTOMRIGHT",0,0})
a:Show()
e=e+b+C
end
for a=#b+1,#c.cards do c.cards[a]:Hide()end
a=math.max(e-C,1)
end)
end


local g,j,q,A=60,12,32,10
local function C(f)
local e=b.row(f.content,g)
local function h(a)
a.font,a.iconSize="listTop",q
return b.tile(e,a)
end
e.newElement=h({icon=b.art("iconNew"),title="New element",line="Pre-made or your own.",
click=function()d.openNew()end})
e.newGroup=h({icon=b.art("iconGroup"),title="New group",line="Elements arranged together.",
click=function(b)a.New.askGroup(b)end})
f:add(b.finishRow(e,function(b)
local a={}
if not c.full("elements")then a[#a+1]=e.newElement end
if not c.full("groups")then a[#a+1]=e.newGroup end
e.newElement:SetShown(a[1]==e.newElement)
e.newGroup:SetShown(a[#a]==e.newGroup)

local b=(b-j)/2
for c,a in ipairs(a)do
a:SetSize(b,g)
a:ClearAllPoints()
a:SetPoint("TOPLEFT",(c-1)*(b+j),0)
end
end),g+A,nil,e.refresh)
end

b.registerPage("groups",{build=function(a)
local function d()return(c.profile()or{}).groups or{}end
a:plainTitle({title="Elements",icon=b.art("iconElements"),
note=function()return h(v(),"element")end})
z(a)
C(a)

a:hint("Drag an element to another group, or within one to reorder it. Drag a group by its heading to reorder "
.."the groups.",n,function()return w()or#d()>1 end)
a:addRow(r(a))
end})


local function g(c,d)
local a=b.row(c.content,i)
a.list=s(a,{fixed=true,page=c})
a.list:SetPoint("TOPLEFT")
a.height=function()return a.list.h end
c.list=a.list
return c:addRow(b.finishRow(a,function(b)a.list:paint(d(),b)end))
end



b.registerPage("loose",{build=function(a)
a:plainTitle({title="Not in a group",icon=b.art("iconLoose"),
note=function()return h(#y(),"element")end})
a:block({key="list"})
g(a,function()return{ids=B(),empty=x()}end)
end})



local function j()
local a={}
for c,b in ipairs(m())do
if b.kind=="element"and b.alert then a[#a+1]=b end
end
return a
end

b.registerPage("alerts",{build=function(a)
a:plainTitle({title="Spell Alerts",icon=b.art("iconAlerts"),
note=function()return h(#j(),"alert")end})
local b=a:buttons({{text="New alert",width=120,click=function()d.openNew(nil,"alerts")end,
enabled=function()return not c.full("elements")end,tip="A new Spell Alert at the screen's centre."}})
b.buttons[1]:SetPoint("LEFT",n,0)
a:hint("A large picture round the screen's centre, shown while a buff or spell calls for it.",n)
a:block({key="list"})
g(a,function()
local a={}
for c,b in ipairs(j())do a[#a+1]=b.id end
return{ids=a,empty="None yet."}
end)
end})





local function g(b,c)
local a={}
for b,c in ipairs(b)do a[b]=c end
a[#a+1]=c
return a
end
local function j(a,b,f,h,c)
for d,a in ipairs(l.fieldsOf(a))do

if a.type~="id"and a.type~="list"and not a.exportOnly and a.name~="enabled"then
local d=g(b,a.name)
local b=a.under and{path=g(b,a.under[1]),
values=type(a.under[2])=="table"and a.under[2]or{a.under[2]}}
local b={key=e.pathKey(d),path=d,field=a,label=a.label,depth=f,under=b,
parent=h,vars={}}
c[#c+1]=b
if a.type=="keys"then

b.widget="keys"
elseif a.type=="record"then
b.heading=true
j(a.record,d,f+1,b,c)
else
b.widget,b.unit=e.widgetOf(a),e.unitOf(a)
end
end
end
return c
end




local g={key="showing",columns={"When","Opacity"},rows={
{key="shown",label="Shown",cells={{"while","unless"},{"opacity"}}},
{key="otherwise",label="Otherwise",cells={{text="the rest of the time"},{"otherwise"}}}}}





local g={
{key="general",title="General",fields={"name"},top=true,fixed=true},
{key="showing",title="When it shows",fields={"opacity","while","unless","otherwise"},
table=g},
{key="arrangement",title="Arrangement",
fields={"arrangement","columns","growFrom","spacing","lineUpBy","align","keepSlots"}},
{key="place",title="Place and size",fields={"scale","position.point","position.x","position.y"}},
}


local m={
arrangement="With Free, each element stays where you put it.",
growFrom="Which part of the row or column stays in place when elements join or leave it, such as when you"
.." learn a spell or switch an element off.",
align="Where smaller elements sit beside larger ones.",
keepSlots="Elements switched off or not yet learned keep their space.",
}

local n="You can also drag the group while positioning is unlocked."




local function q()
local d,b={},{}
for b,a in ipairs(j("group",{},0,nil,{}))do d[a.key]=a end
for c,a in ipairs(g)do
b[#b+1]={key="card:"..a.key,card=a.key,heading=true,label=a.title,depth=0,vars={},
top=a.top,fixed=a.fixed}
local e={}
if a.table then
b[#b+1]={key=a.table.key,table=a.table,depth=0,vars={}}
for c,b in ipairs(a.table.rows)do
for c,b in ipairs(b.cells)do
for c,b in ipairs(b)do e[b]=a.table.key end
end
end
end
for a,c in ipairs(a.fields)do
local a=d[c]
if a then
a.depth,a.help,a.cell=0,m[c]or a.field.help,e[c]
b[#b+1]=a
end
end
end
return b
end


local r="These options set the default for elements in the group. Individual elements may override them."



local function m(d)
local a,b=0,0
for e,d in ipairs(d.members or{})do
local c=c.element(d)
if c then
a=a+1
local a=false
for d,b in ipairs(l.SHOWING_ALL)do
if c[b]~=nil then a=true end
end
if not a then b=b+1 end
end
end
return a,b
end



local function v(a,b)
if a==0 then return""end
if b==a then return a==1 and"Its one element uses these."or("All "..a.." elements use these.")end
if b==0 then
return a==1 and"Its one element sets some of its own."or("All "..a.." elements set some of their own.")
end
local a=a-b
return b..(b==1 and" element uses all of these; "or" elements use all of these; ")..a
..(a==1 and" sets some of its own."or" set some of their own.")
end




local g={grey="Greyed while you're dead or on a flight path.",
hide="Hidden while you're dead or on a flight path."}
local function w(b,d,e)
local b=k.group(b,c.profile())

if d==0 then return""end

if b.enabled==false then return"Hidden: the group is off."end
local c,d=b["while"],b.unless
local c=c~=nil and not(type(c)=="table"and#c==0)
local d=d~=nil and not(type(d)=="table"and#d==0)
local b=e>0 and(c or d)and(b.otherwise or 0)<=0
local a=g[a.Showing.rule()]
if b and a then return"Hidden the rest of the time. "..a end
if b then return"Hidden the rest of the time."end
return a or""
end


local g={}
local function j(a)
if g.gen~=f or g.id~=a.id then
local b,c=m(a)
g.gen,g.id=f,a.id
g.follow,g.result=v(b,c),w(a,b,c)
end
return g
end


local function m(a,c)
return function(b)
local b=b
for c=1,#a-1 do
if type(b[a[c]])~="table"then b[a[c]]={}end
b=b[a[c]]
end
b[a[#a]]=c
end
end

local function v(d,a)
local function l()
local a=d.target and c.group(d.target)
return a and k.group(a,c.profile())
end
local function f()return e.read(l(),a.path)end
local function g(b)return(c.editGroup(d.target,m(a.path,b)))end
local function c()return l()~=nil and e.shown(a,l())end
local b={unit=a.unit}
local h,i=a.field,a.widget

local j=h and not a.help and h.tip or nil
if a.card then
d:block({key=a.card,title=a.label,card=not a.fixed or nil})
elseif a.heading then
d:subhead(a.label,nil,c)
elseif i=="toggle"then
d:checkbox(a.label,j,f,g,c)
elseif i=="choice"then
b.choices=function()
local b,c=e.choices(a,l())
local a={}
for d,b in ipairs(b)do a[d]={b,c[b]}end
return a
end
d:dropdown(a.label,j,function()
local a=f()
if a==nil then return e.NONE end
return a
end,function(a)
if a==e.NONE then a=nil end
return g(a)
end,c,b)
elseif i=="percent"then
b.min,b.max,b.step=0,100,1
d:slider(a.label,j,f,g,c,b)
elseif i=="slider"then
b.min,b.max,b.step=h.min,h.max,h.step or(h.type=="integer"and 1 or nil)
d:slider(a.label,j,f,g,c,b)
elseif i=="edit"then
b.width=120
d:textbox(a.label,j,function()return f()==nil and""or tostring(f())end,function(a)
local a=tonumber(a)
return a~=nil and g(a)
end,c,b)
elseif i=="text"then
d:textbox(a.label,j,function()return f()or""end,function(a)
return g(a~=""and a or nil)
end,c,b)
end

if a.help and not a.heading then

d:hint(a.help,nil,c)
end
end



local function w(d,h,f)
local function g()
local a=d.target and c.group(d.target)
return a and k.group(a,c.profile())
end
local function i(f)
local function h()
local a=g()and e.read(g(),f.path)
if a==nil then return{}end
return type(a)=="table"and a or{a}
end
local function g(a)
return c.editGroup(d.target,m(f.path,#a>0 and a or nil))
end

local e={}
return{glue=f.label:lower(),name=f.label,list=function()
local a=h()
for a,b in ipairs(a)do
local c=l.gameFactSpec((b:match("^game%.(.+)$"))or"")
e[a]=e[a]or{}
e[a].label=c and c.label or b
end
for a=#a+1,#e do e[a]=nil end
return e
end,add=function(j)
local e,i={},{}
for b,a in ipairs(h())do i[a]=true end
for b,a in ipairs(a.Check.keysFor(c.group(d.target)or{},"",f.path[#f.path],true))do
if not i[a.key]then e[#e+1]={value=a.key,label=a.label}end
end
b.openMenu(j,e,function(b)
local a={}
for c,b in ipairs(h())do a[#a+1]=b end
a[#a+1]=b
g(a)
end)
end,remove=function(b)
local a={}
for c,d in ipairs(h())do if c~=b then a[#a+1]=d end end
g(a)
end}
end
local a={}
for j,h in ipairs(h.rows)do
local b={}
for h,a in ipairs(h.cells)do
if a.text then
b[h]={text=a.text}
elseif f[a[1]].widget=="keys"then
local c={}
for b,a in ipairs(a)do c[#c+1]=i(f[a])end
b[h]={keys=c}
else
local a=f[a[1]]
b[h]={slider={min=0,max=100,step=1,unit=a.unit,
get=function()return g()and e.read(g(),a.path)end,
set=function(b)return(c.editGroup(d.target,m(a.path,b)))end}}
end
end
a[j]={label=h.label,cells=b}
end
return d:addRow(b.table(d.content,{columns=h.columns,rows=a}),
function()return g()~=nil end)
end

b.registerPage("group",{settings=true,build=function(a)
local function e()return a.target and c.group(a.target)end
a:header({icon=b.art("iconGroup"),
title=function()local a=e()return a and(a.name or a.id)or""end,
note=function()
local a=e()
return a and(o(a).." · "..h(p(a),"element"))or""
end,

switch={title="On",
get=function()local a=e()return a~=nil and a.enabled~=false end,
set=function(b)
if not a.target then return false end
return(c.editGroup(a.target,function(a)
if b then a.enabled=nil else a.enabled=false end
end))
end}})


local f,g=a.headerCard,a.fixed
local f=b.textLink(f,"Delete",function()d.groupDeleteMenu(a.deleteLink,a.target)end,true)
f.simLabel="Delete"
f.deleteMenu=true
f:SetPoint("RIGHT",a.onSwitch,"LEFT",-12,0)
f:HookScript("OnEnter",function(a)
if not a:IsEnabled()then b.note(a,"Delete group: not in combat")end
end)
f:HookScript("OnLeave",function()b.note()end)
a.deleteLink=f

a.headerRoom=function()return f:GetWidth()+12 end
local h=g.refresh
g.refresh=function()
h()
f:setEnabled(not u.inCombat())
end
z(a)

local function h()
a:block({key="members",title="Elements",card=true})
local f=b.row(a.content,i)
f.list=s(f,{remove=true,scroll=t(a),clip=a.scroll,page=a})
f.list:SetPoint("TOPLEFT")
f.height=function()return f.list.h end
a:addRow(b.finishRow(f,function(b)
local a=e()
f.list:paint({groupId=a and a.id,ids=a and a.members or{},empty="No elements yet."},b)
end))
a:buttons({
{text="New element",width=130,click=function()d.openNew(a.target)end,
enabled=function()return not c.full("elements")and not c.full("members",a.target)end,
tip="A new element in this group."},
})
end


local function c(b)
return function()
local a=e()
return a and j(a)[b]or""
end
end
local function d()return e()~=nil end
local b=q()
local f={}
for b,a in ipairs(b)do f[a.key]=a end
local g=false
for i,b in ipairs(b)do
if b.card and not b.top and not g then
g=true
h()
end
if b.table then
w(a,b.table,f)
a:text(r,d)
a:text(c("follow"),function()
local a=e()
return a~=nil and j(a).follow~=""
end)
a:note(c("result"),function()
local a=e()
return a~=nil and j(a).result~=""
end)
elseif not b.cell then
v(a,b)
end
if b.key=="position.y"then a:text(n,d)end
end
a:endBlock()
end})



a.PageGroup={
rows=q,
writer=m,
note=function(a)return o(a).." · "..h(p(a),"element")end,


defaultLine=r,
follow=function(a)return j(a).follow end,

result=function(a)return j(a).result end,

dragLine=n,
}
