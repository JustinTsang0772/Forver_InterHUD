


local a,c=...
local g,d,b=c.Kit,c.Store,c.Collections

local a={}
c.PageCollections=a



local function c(a,b)return a.." "..b..(a==1 and""or"s")end
local function f(a)
local b=c(a.elements+a.alerts,"element")
if a.alerts>0 then b=b.." ("..c(a.alerts,"Spell Alert")..")"end
return{b,c(a.groups,"group")}
end

local function e(a)
local a=f(a)
return a[1].." and "..a[2]
end
a.heldWords=e


function a.countWords(a)
local a=b.counts(a)
local b=table.concat(f(a),", ")
if#a.specials>0 then b=b..", "..table.concat(a.specials,", ")end
return b
end


local c={}
local function h(a)
if c[a]==nil then
local d,b=pcall(b.check,a,"profile")
c[a]=d and b.ok and#(b.refused or{})==0 or false
end
return c[a]
end


a.result=nil
local function c(b,c)a.result={text=b,back=c}end

local function f(a)return a and a[1]and a[1].text or"That didn't work."end

function a.use(e,a)
local d=d.profileName()
local e,g,b=b.use(e,{switch=a})
if not e then
c(f(g))
elseif a then
c("Made the profile \""..b.."\" and switched to it. \""..tostring(d).."\" is on Profiles.",
d)
else
c("Made the profile \""..b.."\" (on Profiles).")
end
end

function a.add(a)
local g=b.counts(a)
local a,b=b.add(a)
if a then
c("Added "..e(g).." to \""..tostring(d.profileName()).."\".")
else
c(f(b))
end
end

g.confirm("COLLECTION_ADD","%s","Add",function(a)a.run()end)

function a.addWords(a)
local a=b.counts(a)
local b="Adds "..e(a).." to \""..tostring(d.profileName())
.."\". They may overlap what is there."
if#a.specials>0 then
b=b.." Its Specials settings ("..table.concat(a.specials,", ")..") replace yours."
end
return b
end


a.buildable=h
