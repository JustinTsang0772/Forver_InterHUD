


























local b,a=...
local c=a.Kit

local b={}
a.ContentsList=b

local m,w,N,G=6,12,14,11
local M,W=15,6
local i=10
local F,l,y=15,14,5
local O,t=28,6
local x,g=10,8
local q=t+i+4
local k,p=48,7
local d=18
local z=16
local H,P=3,14
local D={icon="glyphIcon",bar="glyphBar",text="glyphText",spellAlert="glyphSpellAlert",
customState="glyphCustomState"}

local function X(a)return c.metric("list",a)end

local function C(a,b)
local a=CreateFrame("Button",nil,a)
a:EnableMouse(true)
a.sel=a:CreateTexture(nil,"BACKGROUND",nil,2)
a.sel:SetAllPoints()
c.fill(a.sel,"accent",0.16)
a.bar=a:CreateTexture(nil,"ARTWORK")
a.bar:SetPoint("TOPLEFT",0,-3)
a.bar:SetPoint("BOTTOMLEFT",0,3)
a.bar:SetWidth(3)
c.fill(a.bar,"accent")
a.lit=a:CreateTexture(nil,"HIGHLIGHT")
a.lit:SetAllPoints()
c.fill(a.lit,"white",0.05)

a.head=a:CreateTexture(nil,"BACKGROUND",nil,1)
a.head:SetAllPoints()
c.gradient(a.head,"treeHead","treeCard")
a.head:Hide()
a.rule=a:CreateTexture(nil,"ARTWORK")
c.fill(a.rule,"rule",0.32)
a.rule:SetPoint("BOTTOMLEFT",0,0)
a.rule:SetPoint("BOTTOMRIGHT",0,0)
a.rule:SetHeight(1)
a.rule:Hide()

a.guide=a:CreateTexture(nil,"ARTWORK")
c.fill(a.guide,"rule",0.22)
a.guide:SetWidth(1)
a.guide:Hide()

a.band=a:CreateTexture(nil,"ARTWORK")
c.fill(a.band,"rule",0.3)
a.band:SetHeight(1)
a.band:Hide()

a.fold=c.arrow(a,"down",i)
a.fold:SetVertexColor(c.rgba("rule"))
a.fold:Hide()
a.foldHit=CreateFrame("Button",nil,a)
a.foldHit:SetSize(i+8,d)
a.foldHit:SetScript("OnClick",function(a)if a.click then a.click()end end)
a.foldHit:Hide()

a.icon=a:CreateTexture(nil,"ARTWORK")
a.icon:SetSize(F,F)
a.icon:SetTexCoord(0.07,0.93,0.07,0.93)
a.icon:Hide()
a.iconEdge=c.panel(a,"shade","rule","BORDER")
a.iconEdge:place(1,{a.icon,"TOPLEFT",-1,1},{a.icon,"BOTTOMRIGHT",1,-1})
for b,a in ipairs(a.iconEdge.edges)do c.fill(a,"rule",0.35)end
a.iconEdge.fill:Hide()
function a.iconEdge:show(a)for c,b in ipairs(self.edges)do b:SetShown(a)end end
a.iconEdge:show(false)
a.glyph=c.glyph(a,"glyphIcon",l)
a.glyph:Hide()
a.text=a:CreateFontString(nil,"OVERLAY",c.font("listEntry"))
a.text:SetJustifyH("LEFT")
a.text:SetJustifyV("TOP")
a.text:SetWordWrap(true)
a.text:SetSpacing(2)

a.lead=a:CreateFontString(nil,"OVERLAY",c.font("listEntry"))
a.lead:SetText("+")
a.lead:Hide()

a.badge=c.badge(a)
a.mark=c.unlearnedMark(a,N)

a.off=a:CreateTexture(nil,"OVERLAY")
a.off:SetSize(G,G)
a.off:SetTexture(c.art("markOff"))
a.off:SetVertexColor(c.rgba("off"))
a.off:Hide()

a.plus=c.ghostPlus(a,M)
a.plus:Hide()
a:RegisterForClicks("LeftButtonUp","RightButtonUp")
a:SetScript("OnClick",function(a,d)
if d=="RightButton"then
if b and a.entry and a.entry.actions then b(a.entry,a)end
return
end
if a.click and not c.justDragged(a)then a.click()end
end)
return a
end


local function E(b)
local a=CreateFrame("Frame",nil,b)
a:SetFrameLevel(b:GetFrameLevel())
a.panel=c.panel(a,"treeCard","treeCardEdge")
a.panel:cover(a,1)
return a
end


local function Y(a,b)
if a.kind=="add"then return a.text..(a.note and((a.sep or" ")..a.note)or"")end

if a.node and a.node.type=="look"and not b then
return(a.text:gsub("(%b())",c.colorCode("help").."%1|r"))
end

if a.note and a.note~=""and b then return a.text..(a.sep or" ")..a.note end
if a.note and a.note~=""then return a.text..(a.sep or" ")..c.colorCode("help")..a.note.."|r"end
return a.text
end

function b.new(r,I,Q,h,R)
local b=CreateFrame("Frame")
local d={frame=b,height=0,rows={},cards={},offset=0,shownH=0}
local a=c.panel(b,"panelFill","panelEdge",nil,"card")
a:cover(b,1)

local a=CreateFrame("ScrollFrame",nil,b)
a:SetPoint("TOPLEFT",1,-1)
a:SetPoint("BOTTOMRIGHT",-1,1)
local j=CreateFrame("Frame",nil,a)
j:SetSize(1,1)
a:SetScrollChild(j)
d.scroll,d.inner=a,j
local function f()return math.max(0,d.height-d.shownH)end
local e=CreateFrame("Frame",nil,a)
e:SetAllPoints()
e:SetFrameLevel(j:GetFrameLevel()+5)
local e=c.scrollBar(e,{
offset=function()return d.offset end,
range=f,
view=function()return d.shownH end,
scrollTo=function(a)d:scrollTo(a)end,
})
e:SetPoint("TOPRIGHT",-2,-4)
e:SetPoint("BOTTOMRIGHT",-2,4)
d.bar=e
function d:scrollTo(b)
self.offset=math.max(0,math.min(b,f()))
a:SetVerticalScroll(self.offset)
e:paint()
end
a:EnableMouseWheel(true)
a:SetScript("OnMouseWheel",function(b,a)
if f()>0 then d:scrollTo(d.offset-a*k)
elseif h then h(a)end
end)

function d:fit(c)
local a=self.barRoom
self.shownH=c

if(self.height>c)~=a and self.width then b.refresh(self.width)end
self:scrollTo(self.offset)
local b=I()
if b~=self.keptFor then
self.keptFor=b
for d,a in ipairs(self.rows)do
if a:IsShown()and a.click and a.entry.key==b then
local a,b=a.y,a:GetHeight()
if a<self.offset then self:scrollTo(a-m)
elseif a+b>self.offset+c then self:scrollTo(a+b-c+m)end
end
end
end
end

function b.refresh(b,f)
local L=I()
local k=m
local n,o=0,0
local f=f and d.lastEntries or r()
d.lastEntries=f

d.width=b
d.barRoom=d.height>d.shownH and d.shownH>0
local u=b-2*m-(d.barRoom and p or 0)
j:SetWidth(b-2)

local h,p

local r,s=false,false

local v,S,A,T,U
local function B()
if not h then return end
h:ClearAllPoints()
h:SetPoint("TOPLEFT",j,"TOPLEFT",m-1,-(p-1))
h:SetSize(u,k-p+g)
h:Show()
k=k+g+x
h=nil
end
for a,b in ipairs(f)do
n=n+1
local a=d.rows[n]or C(j,R)
d.rows[n]=a
a.entry=b
local e,f,g,x=b.kind=="heading",b.kind=="add",b.kind=="sub",b.kind=="line"
if e or(f and b.top)or(g and(b.depth or 0)==0)then B()end

local B=type(b.drag)=="string"and b.drag:find("^looks:")~=nil
local C=B and b.drag:find(":state$")~=nil
if not B and not b.dim then r,s=false,false end
local J=C and r and not s
if b.dim or(B and not C)then r=true end
if J then s=true end

local B=g and h==nil and(b.depth or 0)==0 and n>1
a.band:SetShown(J or B)
if e then
o=o+1
h=d.cards[o]or E(j)
d.cards[o]=h
p=k
end
local n=h~=nil and not e
local o=(e and b.pick)or(not e and not g and not x and(not f or b.key~=nil))
local C=e and b.toggle~=nil and not b.pick
local V=b.toggle~=nil and not C
local d=e and"listTop"or g and"listHeading"or"listEntry"
local K=c.fontSize(d)

a.text:SetFontObject(c.font(d))
a.text:SetJustifyH("LEFT")
local r=o and L==b.key
local L=not(g or r)and((f and not o)or b.off or b.unlearned or b.dim or x)
a.text:ClearAllPoints()
a.badge:SetShown(b.badge~=nil)
a.mark:SetShown(b.unlearned and true or false)


local p=b.top and 0 or(b.depth or 1)
local d,s
local D=b.glyph and(b.glyph=="event"and"thumb"or D[b.glyph])
local E
if e then
E=t+i/2
d=t+i+4+(b.icon and F or b.glyph and l or 0)+y
elseif g or x then

d=n and q-i-2 or 8+w*p
elseif f then



s=not n and 8+H or p>=2 and q+w/2+H
or q-i/2-2
d=s+l/2+y
elseif p==0 then
d=8
else



local a=n and q or 8+w
E=a-i/2-2
d=a+(D and l+y or 0)
if p>=2 then d=a+w/2 end
end


local h=e and t or 4
local w=b.plus~=nil and b.plus or nil
if f and o then w=w or function()Q(b.key)end end
local F=w~=nil and not f
a.plus:SetShown(F)
a.plus.click=F and w or nil
a.lead:SetShown(f)
a.simLabel=f and"+ "..b.text or nil
local Z=h
if F then
a.plus.simLabel="+ "..b.text
h=h+M+W
end
local M=b.off and not(g or f or x)
a.off:SetShown(M and true or false)
local W=h
if M then h=h+G+4 end
local _=h
if b.unlearned then h=h+N+4 end
local aa=h
if b.badge then
a.badge.say(b.badge)
h=h+a.badge:GetWidth()+4
end
local x=Y(b,L and not e)


if g then x=n and b.text or b.text:upper()end
local G=math.max(u-d-h,20)
local h=X("row")
local x=c.wrapText(a.text,x,G)

local N=((e and O or h)-K)/2
local G=g and 7+(B and z or 0)or N
local x=e and math.max(O,x+2*N)or g and math.max(h,x+9)
or math.max(h,x+h-K)
if B then x=x+z end

local h=G+K/2
a.head:SetShown(e)
local K=n and not e and not g and p>=2
a.guide:SetShown(K)
if K then
a.guide:ClearAllPoints()
a.guide:SetPoint("TOPLEFT",a,"TOPLEFT",q-i/2-2,0)
a.guide:SetPoint("BOTTOMLEFT",a,"BOTTOMLEFT",q-i/2-2,0)
end
a.rule:SetShown(e)
if J then
a.band:ClearAllPoints()
a.band:SetPoint("TOPLEFT",a,"TOPLEFT",d,-1)
a.band:SetPoint("TOPRIGHT",a,"TOPRIGHT",-4,-1)
elseif B then
a.band:ClearAllPoints()
a.band:SetPoint("TOPLEFT",a,"TOPLEFT",4,-z/2)
a.band:SetPoint("TOPRIGHT",a,"TOPRIGHT",-4,-z/2)
end
a.fold:SetShown(b.toggle~=nil)
if b.toggle~=nil then
c.setArrow(a.fold,b.folded and"right"or"down")
a.fold:ClearAllPoints()
a.fold:SetPoint("CENTER",a,"TOPLEFT",E,-h)
end
a.foldHit:SetShown(V and true or false)
if V then
a.foldHit:ClearAllPoints()
a.foldHit:SetPoint("CENTER",a,"TOPLEFT",E,-h)
a.foldHit.click=b.toggle
end
a.icon:SetShown(b.icon~=nil)
a.iconEdge:show(b.icon~=nil)
if b.icon then
a.icon:SetTexture(b.icon)
a.icon:ClearAllPoints()
a.icon:SetPoint("LEFT",a,"TOPLEFT",t+i+4,-h)
end
a.glyph:SetShown(D~=nil)
if D then
a.glyph:SetTexture(c.art(D))
a.glyph:SetSize(b.glyph=="event"and l-3 or l,b.glyph=="event"and l-3 or l)
a.glyph:SetVertexColor(c.rgba(b.glyph=="event"and"accent"or e and"gold"or"rule",
L and 0.5 or 1))
a.glyph:ClearAllPoints()
a.glyph:SetPoint("LEFT",a,"TOPLEFT",d-l-y+(b.glyph=="event"and 1 or 0),-h)
end
a:SetHeight(x)
a:ClearAllPoints()



local i=false
if f and n and v and A+T==k and U==p then
local b=S+v.text:GetStringWidth()+P/2
local c=P/2+H
local e=c+d-s+a.text:GetStringWidth()+8
if b+e<=u then
i=true
d,s=c+d-s,c
v:SetWidth(b)
a:SetPoint("TOPLEFT",j,"TOPLEFT",m-1+b,-(A-1))
a:SetWidth(u-b)
a.y=A
end
end
if not i then
a:SetPoint("TOPLEFT",j,"TOPLEFT",m-1,-(k-1))
a:SetWidth(u)
a.y=k
end
if f and n and not i then
v,S,A,T,U=a,d,k,x,p
else
v=nil
end
a.text:SetPoint("TOPLEFT",a,"TOPLEFT",d,-G)
if F then
a.plus:ClearAllPoints()
a.plus:SetPoint("RIGHT",a,"TOPRIGHT",-Z,-h)
end
if f then
a.lead:ClearAllPoints()
a.lead:SetPoint("TOP",a,"TOPLEFT",s,-G)
end
if b.unlearned then
a.mark:ClearAllPoints()
a.mark:SetPoint("RIGHT",a,"TOPRIGHT",-_,-h)
end
if b.badge then
a.badge:ClearAllPoints()
a.badge:SetPoint("RIGHT",a,"TOPRIGHT",-aa,-h)
end
if M then
a.off:ClearAllPoints()
a.off:SetPoint("RIGHT",a,"TOPRIGHT",-W,-h)
end


c.tint(a.text,r and"white"or g and"rule"or L and"off"or e and"gold"or f and"accent"
or b.lit and"listOn"or"listSub")

local d=g and 0.85 or f and not r and 0.8 or 1
a.text:SetAlpha(d)
if f then
c.tint(a.lead,r and"white"or"accent")
a.lead:SetAlpha(d)
end
a.sel:SetShown(r)
a.bar:SetShown(r)
a.lit:SetShown(o or C)
a:EnableMouse(o or C or(R~=nil and b.actions~=nil))


a.click=f and o and function()w(a)end or o and function()
if b.toggle and(I()==b.key or b.folded)then b.toggle()end
Q(b.key)
end or C and b.toggle or nil
a:Show()
if not i then k=k+x end
end
B()
for a=n+1,#d.rows do d.rows[a]:Hide()end
for a=o+1,#d.cards do d.cards[a]:Hide()end
d.height=k+m
j:SetHeight(d.height)
a:UpdateScrollChildRect()
e:paint()
end
return d
end
