




local a,i=...
local a,p,t,u,n,d=i.Kit,i.Form,i.ElementBanner,i.ContentsList,i.StyleArea,
i.ElementModel

local r=0.45

local b={}
i.PageElement=b

local v=12
local y={d.NEW_LOOK,d.NEW_STATE}



local h,j,g={},{},{}

function b.selected(a)return d.entry(a,h[a])end

function b.pickOf(a)return h[a]end

local function k()
local a=a.window():page()
if a then a.scroll:SetVerticalScroll(0)end
end
function b.refusal(a)return j[a]end



local function c(b,c,d)return(d..tostring(b)..":"..c):sub(1,a.KEY_MAX)end
function b.folded(b,d)
if a.isFolded(c(b,d,"tf:"))then return true end
if a.isFolded(c(b,d,"tu:"))then return false end
return nil
end
function b.setFolded(b,d,e)
a.setFolded(c(b,d,"tf:"),e)
a.setFolded(c(b,d,"tu:"),not e)
end

function b.select(c,d)

local e,f=(d or""):match("^%a+:([^/]+)/([^/]+)")
e=e or(d or""):match("^source:(.+)$")or(d or""):match("^add:%a+:([^/]+)")
if e and b.folded(c,"source:"..e)and not(d or""):match("^source:")then
b.setFolded(c,"source:"..e,false)
end
if f and(d or""):match("^look:")and b.folded(c,"layer:"..e.."/"..f)then
b.setFolded(c,"layer:"..e.."/"..f,false)
end
if(d or""):match("^customState:")and b.folded(c,"customStates")then b.setFolded(c,"customStates",false)end
if d~=h[c]then
j[c],g[c]=nil,nil
k()
end
h[c]=d

local b,d=(d or""):match("^layer:([^/]+)/([^/]+)$")
if b then i.Placement.selectLayer(c,b,d)end
a.repaint()
end


function b.answer(d,c)
if c.ok then
j[d]=nil
if c.select then b.select(d,c.select)end
else
j[d]=c.line or"That can't be done."
end
a.repaint()

local a=not c.ok and a.window():page()
if a and a.refusalCallout then a:bringIntoView(a.refusalCallout)end
return c.ok
end
function b.act(a,c,e)return b.answer(a,d.act(a,c,e))end


a.confirm("RESET_PREMADE","Reset %s to its pre-made?","Reset",function(a)
b.act(a.id,"resetPremade",{key=a.key})
end)
a.confirm("REMOVE_PART","Remove %s?","Remove",function(a)a.remove()end)

a.confirm("REMOVE_USED","%s","Remove",function(a)a.remove()end)


function b.run(e,c,f)
if c.op=="open"then

if c.args.event and c.args.key:match("^add:effect:")then
i.AddViews.draftOf(e).moment=c.args.key:match("^add:effect:(.+)$").."/"..c.args.event
end
return b.select(e,c.args.key)
end
if c.op=="openStyles"then return n.openStyles(c.args.part)end

if c.op=="showInPreview"then
local a=a.window():page()
if a and a.banner then return a.banner:pickAll(d.lookPicks(e,c.args.key))end
return b.act(e,c.op,c.args)
end

if c.op=="rename"then
local a=a.window():page()
if a and a:renameHead(c.args.key)then return end
end

if c.op=="keyMenu"then return f and b.openKeyMenu(e,f,c.args.path,c.args.field,c.args.title)end
if c.op=="resetPremade"then
return a.showPopup("RESET_PREMADE",c.args.key and d.title(e,c.args.key)or p.nameOf(d.view(e)),
{id=e,key=c.args.key})
end



if c.op=="remove"or c.op=="removePart"or c.op=="removeSpell"then
local f=d.ask(e,c.op,c.args)
if f.line and c.op=="removePart"then
return a.showPopup("REMOVE_USED",f.line,{remove=function()b.act(e,c.op,c.args)end})
end
if f.line then
g[e]={line=f.line,op=c.op,args=c.args}
return a.repaint()
end
if c.op~="remove"then return b.act(e,c.op,c.args)end
return a.showPopup("REMOVE_PART",d.title(e,c.args.key or"")~=""and d.title(e,c.args.key)or"it",
{remove=function()b.act(e,"remove",c.args)end})
end
if c.ask and f then
return a.askInline(f,"Name","",function(d)
local a={}
for b,c in pairs(c.args)do a[b]=c end
a.name=strtrim(d or"")
b.act(e,c.op,a)
end)
end
return b.act(e,c.op,c.args)
end



function b.openKeyMenu(e,h,f,g,c)
local i=d.keyMenu(e,f,g)

local c=c and{{title=c}}or{}
local function d(a)
local b={}
for c,a in ipairs(a)do
b[#b+1]={value=a,label=a.label,disabled=a.greyed,tip=a.reason}
end
return b
end
for b,a in ipairs(i.sections)do

if#a.items==0 and a.note then
c[#c+1]={note=a.note}
elseif#a.items>0 then
if a.submenu then
c[#c+1]={label=a.title,submenu=d(a.items)}
else
c[#c+1]={title=a.title}
for b,a in ipairs(d(a.items))do c[#c+1]=a end
end
end
end
a.openMenu(h,c,function(a)
if a.greyed then return end
if a.op=="newCustomState"then return b.act(e,"newCustomState",{path=f,field=g})end
if a.op=="newRange"then
return b.act(e,"newRange",{path=f,field=g,source=a.source,fact=a.fact})
end
b.act(e,"addKey",{path=f,field=g,key=a.key})
end)
end



local function o(e,f,d)
local c={}
for b,a in ipairs(f)do c[#c+1]={value=a,label=a.label}end
a.openMenu(d,c,function(a)b.run(e,a,d)end)
end

local function k(c,a)
if not a or#a==0 then return nil end
return function(d)
if#a==1 then return b.run(c,a[1],d)end
o(c,a,d)
end
end

local function m(c)
local a={}
local function b(c)
for d,c in ipairs(c)do
a[#a+1]=c
b(c.children or{})
end
end
b(c.nodes or{})
return a
end


local function c()return{}end

local function l(e,f)
local a=not f and d.kept(e,"entries",c)
local c=i.Store.ui()
if a and a.ui==c then return a.out end
local h=d.tree(e,not f and function(a)return b.folded(e,a)end or nil)
local g={}
for c,a in ipairs(f and m(h)or d.visible(h))do


local c={key=a.key,text=a.label,note=a.note,node=a,plus=k(e,a.adds),
actions=a.actions and#a.actions>0 and a.actions or nil}
if a.type=="global"and not f then
c=nil
elseif a.type=="quick"or a.type=="general"or a.type=="structure"then
c.kind,c.top="entry",true
elseif a.type=="section"then
c.kind,c.pick="heading",a.pick~=false
c.off=a.on==false or a.greyed or nil
c.unlearned,c.drag=a.unlearned,a.drag

c.icon,c.glyph=a.icon,a.glyph
elseif a.type=="sub"or a.type=="line"then
c.kind,c.depth=a.type,a.depth

if a.type=="line"and f then c.text,c.dim=a.wide or a.label,true end
elseif a.type=="add"then

c.kind,c.depth="add",a.depth
c.top=(a.depth or 0)==0 or nil
else
c.kind,c.depth="entry",a.depth
c.off=a.on==false or a.greyed or nil
c.unlearned,c.lit,c.drag=a.unlearned,a.lit,a.drag
c.dim=a.type=="global"or nil
c.glyph=a.glyph or(a.type=="event"and"event")or nil
if a.type=="event"then c.sep=" · "end
end
if c and a.folds then
c.folded=a.folded
c.toggle=function()b.setFolded(e,a.key,not a.folded)end
end
if c then g[#g+1]=c end
end
if a then a.ui,a.out=c,g end
return g
end
b.entriesOf=l



function b.drop(f,a,c)
if type(a)~="table"or c==nil then return end
local e={}
for c,b in ipairs(l(f,true))do
if b.drag==a.band then e[#e+1]=b.key end
end
local d
for b,c in ipairs(e)do if c==a.key then d=b end end
if not d then return end
local c=c>d and c-1 or c
if c==d then return end
b.act(f,"move",{key=a.key,index=c})
end





local function c(a,...)
for b=1,select("#",...)do a[#a+1]=tostring((select(b,...)))end
end
local function f(a)return type(a)=="table"and table.concat(a,".")or tostring(a)end
local function e(a,b)
local d=a.type
c(b,"/",d,a.widget,a.key)
if d=="field"then
c(b,a.label,a.tip,a.unit,a.min,a.max,a.step,a.softMin,a.softMax,a.optional,a.help,a.maxBytes,
a.tags~=nil)

if a.widget=="multi"then
for d,a in ipairs(a.choices or{})do c(b,a[1],a[2])end
end
elseif d=="keys"or d=="button"then
c(b,a.label)
elseif d=="link"then
c(b,a.op=="open"or a.op=="openStyles")
elseif d=="line"then
c(b,a.full,a.strong)
elseif d=="note"then
c(b,a.note)
elseif d=="table"then
for d,a in ipairs(a.columns or{})do c(b,a)end
for d,a in ipairs(a.rows or{})do
c(b,a.label)
for d,a in ipairs(a.cells or{})do
c(b,a[1]and a[1].unit)
for d,a in ipairs(a)do c(b,a.label)end
end
end
elseif d=="style"then
c(b,a.part,f(a.path))
for d,a in ipairs(a.rows or{})do
local a=a.form or{}
c(b,f(a.path),a.field and a.field.name)

if a.field and a.field.name=="kind"then
local d={}
for a in pairs(a.vars or{})do d[#d+1]=tostring(a)end
table.sort(d)
for e,d in ipairs(d)do c(b,d,type(a.vars[d])~="table"and a.vars[d]or"{}")end
end
end
end
for c,a in ipairs(a.rows or{})do e(a,b)end
for c,a in ipairs(a.cells or{})do
for c,a in ipairs(a)do e(a,b)end
end
for d,a in ipairs(a.items or{})do
c(b,"item",a.key)
for c,a in ipairs(a.rows or{})do e(a,b)end
end
if a.add then c(b,"add")end
end
local function z(a,b)

local c=false
for b,a in ipairs(a.actions or{})do c=c or a.op=="rename"end

b[#b+1]=(a.intro and"i"or"")..(a.on and"o"or"")..(a.tree and"t"or"")..(c and"r"or"")
..(a.actions and#a.actions>0 and"a"or"")
for c,a in ipairs(a.sections or{})do
b[#b+1]="s:"..tostring(a.key)..(a.title and"t"or"")..(a.group and"g"or"")..(a.on and"o"or"")
..(a.holds and"h"or"")..(a.actions and#a.actions or 0)
for c,a in ipairs(a.rows)do e(a,b)end
end
end



local function q(c,a,d,b)
local a=c:hint(function()return a()or""end,b,
function()return d()and(a()or"")~=""end)

if b then a.fromEdge=true end
return a
end
local A=4



local function B(g,h,e,c)
local k=function()return g.target end
local function m()
local a=e()
return a and a.value
end
local function o(a)
local c=e()
if not c then return false end
if c.widget=="choice"and a==p.NONE then a=nil end
if c.noneIsWhite and a=="#ffffff"then a=nil end
return b.act(k(),c.op or"set",{path=c.path,value=a})
end
local function s(c)
local a=e()
return a~=nil and b.act(k(),a.textOp or"setText",{path=a.path,text=c,widget=a.widget})
end
local function t()
local a=e()
return a and a.text or""
end
local function l()return c()and e()~=nil and e().shown~=false end
local c={unit=h.unit,dense=true}
local j,n=h.widget,h.tip
local f
if j=="toggle"then
f=a.checkbox(g.content,h.label,n,m,o,c)
elseif j=="choice"then
c.choices=function()
local a=e()
return a and a.choices or{}
end
c.offered=function(a)return d.listed(k(),e(),a)end
f=a.dropdown(g.content,h.label,n,m,o,c)
elseif j=="percent"then
c.min,c.max,c.step=0,100,1
f=a.slider(g.content,h.label,n,m,o,c)
elseif j=="slider"then
c.min,c.max,c.step,c.softMin,c.softMax=h.min,h.max,h.step,h.softMin,h.softMax
if h.optional then c.fallback=function()return e()and e().fallback end end
f=a.slider(g.content,h.label,n,m,o,c)
elseif j=="edit"or j=="spell"or j=="fileId"then


c.width=j=="spell"and 80 or j=="edit"and 120 or nil
if j=="spell"then
c.unit=nil
c.note=function()return e()and e().note or""end
end


if j=="fileId"then
c.hint=function()local a=e()return a and a.hint or""end
c.action={text="From a spell…",width=a.textWidth("button","From a spell…")+20,
click=function(b)
local a=e()
if a then i.AddViews.pickFor(b,{at="picture",id=k(),path=a.path})end
end}
end
f=a.textbox(g.content,h.label,n,t,s,c)
elseif j=="spells"then


c.label=h.label
g:addRow(a.entryList(g.content,function()
local a=e()
if not a then return{}end
local d={}
for e,c in ipairs(a.entries or{})do
d[e]={label=c.label,icon=c.icon,idText=c.idText,note=c.note,tip=c.tip,
remove=function()b.run(k(),{op="removeSpell",args={path=a.path,spell=c.id}})end}
end
return{entries=d,add=a.add and{text=a.add,click=function(b)
i.AddViews.pickFor(b,{at="spells",id=k(),path=a.path})
end}or nil}
end,c),l)
elseif j=="text"then
c.maxBytes=h.maxBytes
c.hint=function()local a=e()return a and a.hint or""end
f=a.textbox(g.content,h.label,n,t,s,c)
elseif j=="picture"then
local function b()
local a=e()
return a and a.form and p.pictureOpts(a.form,d.view(k()))or{}
end
c.families=function()return b().families and b().families()or{}end
c.familyOf=function(a)return b().familyOf and b().familyOf(a)end
f=a.picturePicker(g.content,h.label,n,m,o,c)
elseif j=="colour"then
f=a.color(g.content,h.label,n,m,o,c)
elseif j=="sound"then
c.offered=function(a)return d.listed(k(),e(),a or nil)end
f=a.sound(g.content,h.label,n,m,o,c)
elseif j=="multi"then

g:subhead(h.label,nil,l)
for b,a in ipairs(h.choices or{})do
local b=a[1]
g:checkbox(a[2],nil,function()
for c,a in ipairs(m()or{})do if a==b then return true end end
return false
end,function(c)
local a={}
for d,c in ipairs(m()or{})do if c~=b then a[#a+1]=c end end
if c then a[#a+1]=b end
if#a==0 then return false end
return o(a)
end,function()return l()and d.offersInList(k(),e(),b)end,c)
end

g:endSubhead()
end
if f then
a.marks(f,c)

local c={}
local function d()
local a=e()
if a and a.reset then b.act(k(),"reset",{path=a.reset})end
end
local function i()
local a=e()
if not a then return nil end
local c=a.tags and{}or c
c.set,c.tip,c.reset=a.set,a.resetTip,a.reset and d or nil
if a.tags then
c.tags={}
for d,a in ipairs(a.tags)do
local d=a.key
c.tags[#c.tags+1]={text=(a.label:gsub("^While ","")),dim=a.holds and not a.wins or nil,
click=function()b.select(k(),d)end}
end
end
return c
end

local function a()
if f.marksAt~=g.paints or not g.rowW then f.marksAt,f.marksHeld=g.paints,i()end
return f.marksHeld
end
f.wantMarks=a
local b=f.refresh
f.refresh=function(c)
b(c)
f.paintMarks(a())
local a=e()
f:SetAlpha(a and a.greyed and r or 1)
end
if h.tags then f.marksNow,f.shownFn=a,l end
g:addRow(f,l)
g:addRow(f.tagRow,function()return f.tagRow.has and l()end)
end
if h.help then g:hint(h.help,nil,l)end
if j=="spells"then q(g,function()return e()and e().widened end,l)end
if j=="sound"then g:hint(a.SOUND_NOTE,nil,l)end
q(g,function()return e()and e().caveats end,l)
q(g,function()return e()and e().greyed and e().reason end,l)
return f
end


local k,f=4,20
local function C(h,d,e,g)
local c=a.row(h.content,a.metric("pane","row"))
c.label=a.label(c,d.label,nil,{dense=true})
c.chips={}
local i=1
c.plus=a.textLink(c,"+",function(c)
local a=e()
if a then b.openKeyMenu(h.target,c,a.menu,a.field)end
end)
c.plus.simLabel="+ "..d.label
c.height=function()return a.metric("pane","row")+(i-1)*f end
h:addRow(a.finishRow(c,function(d)
local j=e()or{keys={}}
local m=a.metric("pane","labelW")
local o=(d or 300)-8
local e,l=m,0
i=1
for n,g in ipairs(j.keys)do
local d=c.chips[n]
if not d then
d=a.tag(c)

d:SetScript("OnEnter",function(b)if b.tip then a.note(b,b.tip)end end)
d:SetScript("OnLeave",function()a.note()end)
c.chips[n]=d
end
local n=g.key
d.tip=g.greyed and g.reason or nil
d.text:SetAlpha(g.greyed and 0.6 or 1)
if g.greyed then
d.say(g.label)
d.click=nil
else
d.say(g.label.."  ×")
d.click=function()b.act(h.target,"removeKey",{path=j.menu,field=j.field,key=n})end
end
if e>m and e+d:GetWidth()>o then e,l,i=m,l+f,i+1 end
d:ClearAllPoints()
d:SetPoint("LEFT",c,"TOPLEFT",e,-(a.metric("pane","row")/2+l))
d:Show()
e=e+d:GetWidth()+k
end
for a=#j.keys+1,#c.chips do c.chips[a]:Hide()end
c.plus:ClearAllPoints()
c.plus:SetPoint("LEFT",c,"TOPLEFT",e,-(a.metric("pane","row")/2+l))
end),g)
return c
end




local D,w,E,s=6,2,18,14
local x={}
local function F(d,c,e,h)
local c=a.row(d.content,f)
local p,l,g,q,t,m={},{},{},{},{},{}
local y=f
local function z(a)
local c=e()
if not(c and a.key)or a.greyed then return end
local e={}
for a,b in pairs(c.args or x)do e[a]=b end
e.key=a.key
b.act(d.target,c.op,e)
end
local function A(c)
local a=e()
local a=a and a.groups[c.group]
if a and a.link then b.run(d.target,a.link,c)end
end

local function u(d,e)
local b=d[e]
if not b then
b=a.fontString(c,"small")
a.tint(b,"help")
b:SetJustifyH("LEFT")
d[e]=b
end
return b
end
c.height,c.chips=function()return y end,g
d:addRow(a.finishRow(c,function(b)
local d=e()
local v=(b or 300)-4
local b,e,h,i,n,o,j=0,0,0,0,0,0,0
for x,d in ipairs(d and d.groups or x)do
if b>0 then b=b+D end
if d.title then
local f=4
if d.icon then
h=h+1
local e=l[h]
if not e then
e=c:CreateTexture(nil,"ARTWORK")
e:SetSize(s,s)
a.cropIcon(e)
l[h]=e
end
e:SetTexture(d.icon)
e:ClearAllPoints()
e:SetPoint("TOPLEFT",c,"TOPLEFT",4,-b-1)
e:Show()
f=4+s+4
end
e=e+1
local a=u(p,e)
a:SetText(d.title)
a:ClearAllPoints()
a:SetPoint("TOPLEFT",c,"TOPLEFT",f,-b-2)
a:Show()
b=b+E
end
local e,l=4,false
for d,h in ipairs(d.chips)do
i=i+1
local d=g[i]
if not d then
d=a.chip(c)
d.onClick=function()z(d)end
g[i]=d
end
d.key,d.greyed=h.key,h.greyed
d:say(h.label,h.on,false,d.onClick)
d:SetAlpha(h.greyed and r or 1)
if e>4 and e+d:GetWidth()>v then e,b=4,b+f+k end
d:ClearAllPoints()
d:SetPoint("TOPLEFT",c,"TOPLEFT",e,-b)
e,l=e+d:GetWidth()+k,true
end
if d.note then
n=n+1
local a=u(q,n)
a:SetText(d.note)
a:ClearAllPoints()
a:SetPoint("LEFT",c,"TOPLEFT",e,-b-f/2)
a:Show()
e,l=e+a:GetStringWidth()+6,true
end
if d.link then
j=j+1
local g=m[j]
if not g then
g=a.textLink(c,"",A)
m[j]=g
end
g.group=x
g.say(d.link.label)
if e>4 and e+g:GetWidth()>v then e,b=4,b+f+k end
g:ClearAllPoints()
g:SetPoint("LEFT",c,"TOPLEFT",e,-b-f/2)
g:Show()
l=true
end
if l then b=b+f end
for a,d in ipairs(d.lines)do
o=o+1
local a=u(t,o)
a:SetWidth(math.max(v-12,40))
a:SetText(d)
a:ClearAllPoints()
a:SetPoint("TOPLEFT",c,"TOPLEFT",8,-b-w)
a:Show()
b=b+a:GetStringHeight()+2*w
end
end
for a=e+1,#p do p[a]:Hide()end
for a=h+1,#l do l[a]:Hide()end
for a=i+1,#g do g[a]:Hide()end
for a=n+1,#q do q[a]:Hide()end
for a=o+1,#t do t[a]:Hide()end
for a=j+1,#m do m[a]:Hide()end
y=math.max(b+2,f)
end),h)
return c
end




local function s(d,f,e,h)
local function c(b)
local a=e()
for c,a in ipairs(a and a.rows or{})do
for c,a in ipairs(a.cells)do
for c,a in ipairs(a)do
if a.key==b then return a end
end
end
end
end
local function i(a,e)
return{glue=e,name=e,list=function()
local a=c(a)
return a and a.keys or{}
end,add=function(e)
local a=c(a)
if a then b.openKeyMenu(d.target,e,a.menu,a.field)end
end,remove=function(e)
local a=c(a)
local c=a and a.keys[e]
if c then b.act(d.target,"removeKey",{path=a.menu,field=a.field,key=c.key})end
end}
end
local g={}
for f,a in ipairs(f.rows)do
local e={}
for h,g in ipairs(a.cells)do
local f=g[1]
local a=f.key
if f.type=="keys"then
local a={}
for c,b in ipairs(g)do a[#a+1]=i(b.key,b.label)end
e[h]={keys=a}
elseif f.type=="field"then

local g={}
local function i()
local a=c(a)
if a and a.reset then b.act(d.target,"reset",{path=a.reset})end
end
e[h]={slider={min=0,max=100,step=1,unit=f.unit,
marks=function()
local a=c(a)
if not(a and a.set)then return nil end
g.set,g.tip,g.reset=a.set,a.resetTip,a.reset and i or nil
return g
end,
get=function()
local a=c(a)
return a and a.value
end,
set=function(e)
local a=c(a)
return a~=nil and b.act(d.target,a.op or"set",{path=a.path,value=e})
end}}
else
e[h]={text=function()
local a=c(a)
return a and a.text or""
end}
end
end
g[f]={label=a.label,cells=e}
end

local c={}
local function i()
local a=e()
if a and a.reset then b.act(d.target,"reset",{path=a.reset})end
end
d:addRow(a.table(d.content,{columns=f.columns,rows=g,marks=function()
local a=e()
if not(a and a.set)then return nil end
c.set,c.tip,c.reset=a.set,a.resetTip,a.reset and i or nil
return c
end},{dense=true}),h)
end



local function w(e,f,d,g)
local c=a.row(e.content,a.metric("pane","row"))
c.link=a.textLink(c,f.label,function(c)
local a=d()
if a and not a.greyed then b.run(e.target,a,c)end
end)
c.link:SetPoint("LEFT",c,"LEFT",4,0)

c.link.text:SetJustifyH("LEFT")
if f.op=="open"or f.op=="openStyles"then c.link:leaves()end

local b=c.link.rested
function c.link.rested(c)
b(c)
local b=d()
if b and b.look then a.tint(c.text,b.lit and"listOn"or"listSub")end
end

local h=c.height
local f=h
c.height=function()return f end
e:addRow(a.finishRow(c,function(e)
local b=d()
if b then c.link.say(b.label)end



local d=math.max(40,(e or 300)-12)
local e=c.link.text:GetUnboundedStringWidth()
local g=0
if b and b.look and e>d then
local a,e,b=a.wrapText(c.link.text,b.label,d)
g=math.max(0,a-b)
c.link:SetWidth(d+2)
else
c.link.text:SetWordWrap(false)
c.link.text:SetWidth(e<=d and 0 or d)
c.link:SetWidth(math.min(e,d)+2)
end

c.link:SetHeight(a.LINK_H+g)
f=h+g
c:SetHeight(f)
c.link:rested()
c.link:SetAlpha(b and(b.greyed or b.dim)and r or 1)
end),g)
q(e,function()return d()and d().greyed and d().reason end,g)
q(e,function()return d()and d().dim and d().note end,g)
end

local k

local function r(c,a,h,e)
local f={}
for a,b in ipairs(a.rows)do f[a]=b.form end
local g={}
for b,a in ipairs(a.rows)do g[a.key]=a end
n.add(c,{part=a.part,path=a.path,rows=f,
view=function()return d.view(c.target)end,
own=function()return p.own(c.target,a.path)end,
write=function(a,d,e)
return b.act(c.target,"set",{path=a,value=d,copyFrom=e})
end,
save=function(b,d)
return p.saveAsPreset({kind="element",key=c.target},a.part,a.path,b,d)
end,
parent=function()return p.styleParent()end,
vars=function()return p.styleVars(d.view(c.target),a.path)end,
shown=e,
row=function(a,d)
local b=a.key
local function a()
local a=h()
for c,a in ipairs(a and a.rows or{})do
if a.key==b then return a end
end
end
local b=k(c,g[b],a,e)
if d and b then d(b,function()return e()and a()~=nil and a().shown~=false end)end
return b
end,
opts={dense=true}})
end

function k(e,c,f,h)
if not c then return end
local function g()return h()and f()~=nil and f().shown~=false end
if c.type=="field"then return B(e,c,f,h)end
if c.type=="keys"then return C(e,c,f,g)end
if c.type=="table"then return s(e,c,f,g)end
if c.type=="keyChips"then return F(e,c,f,g)end
if c.type=="link"then return w(e,c,f,g)end
if c.type=="style"then return r(e,c,f,g)end
if c.type=="heading"then
e:subhead(function()return f()and f().label or c.label end,nil,g)
return
end


if c.type=="line"then
local b=q(e,function()return f()and f().text end,g,c.full and A or nil)
if c.strong and b then a.setFont(b.text,"label")end
return
end

if c.type=="button"then
e:buttons({{text=c.label,width=130,click=function()
local a=f()
if a then b.run(e.target,a)end
end}},g)
return
end

if c.type=="rule"then
e:divider(g)
return
end
if c.type=="note"then
e:parchment(i.Notes.spec(c.note,function()e:refresh()end),function()
return g()and i.Notes.shown(c.note)
end)
return
end

if c.type=="alertWhen"then return i.AlertWhen.build(e,function()return d.view(e.target)end,g)end
end


local function n(d,c)
return function()
local a={}
for e,c in ipairs(c()or{})do
local e=c
a[#a+1]={text=c.label,click=function()b.run(d.target,e)end}
end
return a
end
end



local function p(a)
return a and true or false
end


local function r(c,f,a)
local function g()return c.target~=nil and b.selected(c.target)==f end
local function e()return c.target and d.pane(c.target,f)end
local d={key=f,level="title",title=function()return e()and e().title or""end,shown=g,
note=function()return e()and e().note or""end}
if a.intro then

d.intro=function()
local d={}
for f,a in ipairs(e()and e().intro or{})do
local e=a.open
d[f]={label=a.label,value=a.value,name=a.name,note=a.note,icon=a.icon,
click=e and function()b.select(c.target,e)end or nil}
end
return d
end
end
for g,a in ipairs(a.actions or{})do
if a.op=="rename"then
local a=a.args
d.rename={max=i.Schema.field(f:match("^(%a+):"),"name").max,get=function()return e()and e().title or""end,
set=function(d)b.act(c.target,"rename",{key=a.key,name=d})end}
end
end
if a.on then
d.on={get=function()return e()and e().on and e().on.value end,
set=function(d)
local a=e()
return a and a.on and b.act(c.target,"set",{path=a.on.path,value=p(d)})
end}
end
if a.actions and#a.actions>0 then
d.menu=n(c,function()return e()and e().actions end)
end
c:block(d)

if a.tree then c:addRow(i.StructurePane.new(c),g)end

local j,h=f:match("^%a+"),false
for d,a in ipairs(a.sections or{})do
local i=a.key
local function d()
local a=e()
for b,a in ipairs(a and a.sections or{})do
if a.key==i then return a end
end
end
local function e()return g()and d()~=nil end
if a.title or a.on or(a.actions and#a.actions>0)then


local e={key=f.."|"..i,small=not a.group,joined=not a.group,shown=e,
nest=not a.group,title=function()return d()and d().title or""end}
if a.group then
local b="pane:"..j..":"..i
e.card,e.holds,e.inside=true,a.holds,h and not a.holds
e.foldKey=function()return b end
h=h or a.holds or false
end
if a.on then
e.on={get=function()return d()and d().on and d().on.value end,
set=function(e)
local a=d()
return a and a.on and b.act(c.target,"set",{path=a.on.path,value=p(e)})
end}
end
if a.actions and#a.actions>0 then
e.menu=n(c,function()return d()and d().actions end)
end
c:block(e)
end
for b,a in ipairs(a.rows)do
local b=a.key
k(c,a,function()
local a=d()
for c,a in ipairs(a and a.rows or{})do
if a.key==b then return a end
end
end,e)
end
end
end


local c=false
local function e()
if c then return end
c=true
a.window().frame:HookScript("OnHide",function()
for b,a in pairs(h)do
if a==d.NEW_LOOK or a==d.NEW_STATE then h[b]=d.draftBack(b,a)end
end
d.closeDrafts()
end)
end


local function n(a)return a~=nil and not(a:match("^sub:")or a:match("^line:")or a:match("^add:"))end

local k


local function w(c,m)
e()
c.dense=true
c.noFoldAll=true
local function h()return d.view(c.target)end
local function f()return b.selected(c.target)end
local function p(a)b.select(c.target,a)end

local e=t.new({select=p,selected=f,go=function(a)b.select(c.target,a)end})
c.banner=e
local q={}
c:pin(e.frame,e.height,function()

if c.target==nil then return end
local a=f()
if q[c.target]~=a then
q[c.target]=a
e:follow(h(),a)
end
e:paint(c.target,h())
if c.fixed.height~=e.height then c:setPinHeight(e.height)end
end,v)

local e=u.new(function()return c.target and l(c.target)or{}end,f,p,
function(b)c:scrollBy(-b*a.PAGE_STEP)end,
function(a,b)if c.target then o(c.target,a.actions,b)end end)
c.contents=e


c:side(e.frame,function()return c.contentsDrag or a.contentsWidth()end,function()

local a=math.min(e.height,math.max(c.scroll:GetHeight(),60))
e:fit(a)
return a
end)



local l,o=a.contentsWidthRange()
c.contentsHandle=a.edgeHandle(e.frame,{least=l,
most=function()return math.min(o,c:sideMost())end,
drag=function(b)
if not a.Page.resizing then a.Page.startResize(c)end
c.contentsDrag=b
e.frame:SetWidth(b)
e.frame.refresh(b,true)
end,
release=function(b)
c.contentsDrag=nil
a.setContentsWidth(b)
a.Page.endResize()
end})

c.refusalCallout=c:callout(function()return j[c.target]or""end,
function()return j[c.target]~=nil end)
c:callout(function()return g[c.target]and g[c.target].line or""end,
function()return g[c.target]~=nil end)
c:buttons({{text="Remove",width=90,click=function()
local a=g[c.target]
g[c.target]=nil
if a then b.act(c.target,a.op,a.args)end
end},{text="Cancel",width=90,click=function()
g[c.target]=nil
a.repaint()
end}},function()return g[c.target]~=nil end)


local a={}
for c,b in ipairs(m)do
for c,b in ipairs(b.adds or{})do
if b.op=="open"and i.AddViews.offers(b.args.key)then a[#a+1]=b.args.key end
end
if b.type=="customState"then a[#a+1]="add:effect:"..b.key:match("^customState:(.+)$")end
end
i.AddViews.build(c,{view=h,selected=f,select=function(a)b.select(c.target,a)end},
a)

c.built={}

local function a(a)
c:lazy(function()return c.target~=nil and f()==a and h()~=nil end,function()
local d=d.pane(c.target,a)
c.built[a]=b.shapeOf(d)
k(c,a,d)
r(c,a,d)
end)
end
for c,b in ipairs(m)do
if n(b.key)then a(b.key)end
end
for c,b in ipairs(y)do a(b)end
c:endBlock()
end






function b.shapeOf(b)
local a={}
z(b,a)
return table.concat(a,"|")
end
local function i(b)
local a={}
for c,b in ipairs(b)do
a[#a+1]=b.key..":"..tostring(b.type)
for c,b in ipairs(b.adds or{})do
if b.op=="open"then a[#a+1]="+"..tostring(b.args.key)end
end
end
return table.concat(a,"|")
end

local h,o={},0


local s,p={},{}



local q,t=setmetatable({},{__mode="k"}),{__mode="v"}
function b.isKey(a)return type(a)=="string"and a:match("^element#%d+$")~=nil end
function b.keyFor(e)
local r=d.view(e)
if not r then return nil end
local f,k=b.selected(e),d.version(e)
local c=q[r]
if c and c.v==k and c.sel==f and c.pane==(n(f)and d.pane(e,f)or false)then
return c.key
end

local j
local g=c and c.v==k and c.tree
if not g then
j=m(d.tree(e))
g=i(j)
end
local i=h[g]
if not i then
i={}
h[g]=i
end


local h,l
if not n(f)then h=false end
local function n(a)
local a=h~=false and a.page and a.page.built[f]
if not a then return true end
h=h or d.pane(e,f)
l=l or b.shapeOf(h)
return a==l
end
local b
local l=p[s[e]]
if l and l.tree==g and n(l)then b=l.key end
if not b then
for c,a in ipairs(i)do
if n(a)then
b=a.key
break
end
end
end
if not b then
o=o+1
local c={key="element#"..o,tree=g}
i[#i+1],p[c.key]=c,c
j=j or m(d.tree(e))
a.registerPage(c.key,{build=function(a)
c.page=a
w(a,j)
end})
b=c.key
end
s[e]=b
if c then
c.v,c.sel,c.pane,c.key,c.tree=k,f,h,b,g
else
q[r]=setmetatable({v=k,sel=f,pane=h,key=b,tree=g},t)
end
return b
end

function k(b,e,f)
local a=q[d.view(b.target)]
local c=a and p[a.key]
if c and c.page==b and a.sel==e and a.pane==nil then a.pane=f end
end
