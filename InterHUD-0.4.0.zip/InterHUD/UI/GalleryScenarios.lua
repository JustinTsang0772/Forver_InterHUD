


local b,a=...
local d,b,e=a.Gallery,a.GalleryTiles,a.Blueprints


local f=3

local function c(a,b)
return{first=a,frost="missing",flame="missing",facts=b}
end





local g={
{"ready","Ready","shaman-shocks",c("ready"),"comesReady",
"Made with: Shocks. A cooldown's Ready state and the pop as it comes ready."},
{"cooling","Cooling down","shaman-shocks",c("coolingDown"),nil,
"Made with: Shocks. A cooldown's sweep and time."},
{"range","Out of range","shaman-shocks",c("ready",{outOfRange=true}),nil,
"Made with: Shocks. Out of range's style, from Global's styles."},
{"mana","Not enough power","shaman-shocks",c("ready",{notEnoughPower=true}),nil,
"Made with: Shocks. Not enough power's look, from Global's styles."},
{"debuff","Present","shaman-flameshock",{first="present"},nil,
"Made with: Flame Shock. An aura on your target, its time left as a bar and a number."},
{"debuffMissing","Debuff missing from target","shaman-flameshock",{first="missing"},nil,
"Made with: Flame Shock. The aura's Missing state."},
{"purge","Purgeable buff on target","shaman-purge",{first="present"},nil,
"Made with: Purge. A Magic buff on a hostile target."},
{"charges","Charges","shaman-shields",{first="present"},nil,
"Made with: Shields. A buff's charges as a bar under its icon."},
{"buffMissing","Missing","shaman-shields",{first="missing"},nil,
"Made with: Shields. The buff's Missing state."},
{"expiring","Expiring","shaman-imbue",{first="present",facts={expiring=true}},nil,
"Made with: Weapon Imbue. Shown only late in its time (the Expiring state)."},
{"reagent","Reagent warning","shaman-waterbreathing",
{first="missing",reagent={state="present",facts={low=true}}},nil,
"Made with: Water Breathing. Its reagent's Low state."},

{"drown","You're going to drown (breath bar active), and you have no more Shiny Fish Scales... uh oh!",
"shaman-waterbreathing",{first="missing",reagent="none",breath="draining"},nil,
"Made with: Water Breathing. Breath running down with no reagent left.",true,3},
}


local function c(c)
local e=e.premade(c.spec.premade)
if not e then return nil end
local a=a.copy(e.record)
a.baseSize=d.SIZES[d.sizeOf("scenarios")]or 40


for b,a in ipairs(a.sources or{})do
if a.shownSpell=="lastSeen"or a.shownSpell=="lastCast"then a.shownSpell=nil end
end
return a,b.picks(a,c.spec.picks),b.profile()
end

d.tab("scenarios",{label="Scenarios",rank=40,bar={"backdrop","pause","reset"},
build=function(a)
local d=b.section(a,{key="scenarios",title="Scenarios",tab="scenarios",kind="icon",
help="Sample icons as they might appear based on states and events InterHUD supports. This is just a small"
.." example.",record=c})
local c={}
for b,a in ipairs(g)do
if e.premade(a[3])then
c[#c+1]={key="scenario:"..a[1],caption=a[2],premade=a[3],picks=a[4],
plays=a[5],info=a[6],wide=a[7],captionLines=a[8]or f,use=false}
end
end
b.grid(a,d,c)
a:endBlock()
end})
