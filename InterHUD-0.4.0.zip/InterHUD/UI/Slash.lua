


local a,b=...

local c={}
b.Slash=c
local a={}




c.LIST={
{word="",says="Open or close the options (also /interhud)."},
{word="on",says="Turn InterHUD on for this character."},
{word="off",says="Turn InterHUD off for this character: nothing shows."},
{word="lock",says="Lock or unlock positioning."},
{word="unlock",says="Unlock positioning."},
{word="explorer",says="Open the Styles Explorer."},
{word="help",says="List these commands.",about=false},
}

function c.typed(a)return"/ihud"..(a.word~=""and" "..a.word or"")end
local function d()
b.print("version "..b.version..". Commands:")
for b,a in ipairs(c.LIST)do print(c.typed(a).." - "..a.says)end
end
a.help=d

a.debug=function(a)
if a==""then b.DebugWindow.toggle()
elseif a=="full"then b.Debug.report()
else d()end
end
a.unlock=function()b.Placement.setUnlocked(true)end

a.lock=function()b.Placement.setUnlocked(not b.Placement.unlocked())end

local function c(a)
if not b.Store.editChar(function(b)b.off=a or nil end)then return end
b.print(a and"off for this character. /ihud on to show it again."or"on.")
end

a.explorer=function()b.Gallery.toggle()end
a.styles,a.stylesexplorer,a.gallery=a.explorer,a.explorer,a.explorer
a.data=function()b.DataWindow.toggle()end
a.off=function()c(true)end
a.on=function()c(false)end

SLASH_INTERHUD1="/ihud"
SLASH_INTERHUD2="/interhud"
SlashCmdList.INTERHUD=function(c)
local c,e=strtrim(c or""):lower():match("^(%S*)%s*(.-)$")
if c==""then
b.Window.toggle()
return
end
local a=a[c]
if a then a(e)else d()end
end
