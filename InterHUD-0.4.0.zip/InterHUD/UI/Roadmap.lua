





local a,c=...
local b=c.Store

local a={}
c.Roadmap=a



a.ON=true
local d=a.ON and c.RoadmapData or{}
a.versions=d.new or{}
a.issues=d.issues or{}

a.GROUPS={{key="soon",label="Soon"},{key="later",label="Later"},{key="maybe",label="Maybe"}}
a.coming={}
for c,b in ipairs(a.GROUPS)do
for d,c in ipairs(d[b.key]or{})do
c.when=b.key
a.coming[#a.coming+1]=c
end
end
local d={new=a.versions,coming=a.coming,issues=a.issues}
function a.list(a)return d[a]or{}end


a.TABS={}
for c,b in ipairs({{key="new",label="What's new"},{key="coming",label="What's coming"},
{key="issues",label="Known issues"}})do
if#d[b.key]>0 then a.TABS[#a.TABS+1]=b end
end
function a.has(b)return#a.list(b)>0 end


function a.latest()return a.versions[1]end



a.KINDS={{key="highlights",label="Highlights"},{key="fixed",label="Fixes"}}

function a.highlights(d)
local b={}
for a,c in ipairs(a.KINDS)do
for d,a in ipairs(d[c.key]or{})do
if a[1]<2 then b[#b+1]={c.key,a[2],a[1]}end
end
end
return b
end



local function e()
local a={}
for c,b in ipairs(b.ready()and b.ui().roadmapSeen or{})do a[b]=true end
return a
end


function a.unseen(c)
if not b.ready()then return false end
local b=e()
for c,a in ipairs(a.list(c))do
if not b[a.key]then return true end
end
return false
end


function a.anyUnseen()
for c,b in ipairs(a.TABS)do
if a.unseen(b.key)then return true end
end
return false
end




function a.open(c)
if not b.ready()then return end
if c=="new"then a.dismissLine()end
if not a.unseen(c)then return end
local e=e()
for b,a in ipairs(a.list(c))do e[a.key]=true end
local c={}
for b,a in pairs(d)do
for b,a in ipairs(a)do c[a.key]=true end
end
local a={}
for b in pairs(e)do
if c[b]then a[#a+1]=b end
end
table.sort(a)
b.editUI(function(b)b.roadmapSeen=a end)
end





function a.noteInstall()
local a=a.latest()
if not(b.ready()and a)or b.ui().roadmapVersion then return end
b.editUI(function(b)b.roadmapVersion=a.version end)
end


function a.lineVersion()
local a=a.latest()
if not(b.ready()and a)then return nil end
local b=b.ui().roadmapVersion
if b==nil or b==a.version then return nil end
return a.version
end

function a.dismissLine()
local a=a.latest()
if not(b.ready()and a)or b.ui().roadmapVersion==a.version then return end
b.editUI(function(b)b.roadmapVersion=a.version end)
end




function a.updateLine(a)return"Updated to "..a..". Type /ihud to see what's new."end
local function d(e)
local d=a.latest()
if not(b.ready()and d)or b.ui().roadmapSaid==d.version then return end
b.editUI(function(a)a.roadmapSaid=d.version end)
if not e then c.print(a.updateLine(d.version))end
end


c.Events.on("PLAYER_LOGIN","roadmap",function()
local b=b.ready()and b.ui().roadmapVersion==nil
a.noteInstall()
d(b)
end)
