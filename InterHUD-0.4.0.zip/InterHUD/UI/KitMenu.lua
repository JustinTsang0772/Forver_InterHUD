




























local a,e=...
local b=e.Kit
local i=e.Events

local l="InterHUDOptionsMenu"
local g=14

b.MENU_ROWS,b.MENU_ROW_H=16,20


local m,f,n="common-dropdown-bg",{10,3},0.925
local h={left=8,top=8,right=8,bottom=15}
local q=8+g+4

local a
local d={}
local c={}

local function j(a,b)
for a=#UISpecialFrames,1,-1 do
if UISpecialFrames[a]==b then table.remove(UISpecialFrames,a)end
end
for c,b in ipairs(UISpecialFrames)do
if b==a then return end
end
UISpecialFrames[#UISpecialFrames+1]=a
end

local function k()return h end
b.MENU_INSET=h

local function h(a)
local a=a:CreateTexture(nil,"BACKGROUND")
a:SetAtlas(m)
a:SetPoint("TOPLEFT",-f[1],f[2])
a:SetPoint("BOTTOMRIGHT",f[1],-f[2])
a:SetAlpha(n)
end
b.menuGround=h

b.escapeFirst=j

local function f()
local c=d.onClose
d.owner,d.onClose,d.grid=nil,nil,nil
if a.grid then a.grid:Hide()end
i.off("GLOBAL_MOUSE_DOWN","kit menu")
j(b.WINDOW_NAME,l)
if c then e.try("kit menu close",c)end
end


local function s()
if a:IsMouseOver()or(d.owner and d.owner:IsMouseOver())then return end
b.closeMenu()
end

local function t()
a=CreateFrame("Frame",l,UIParent)
a:SetFrameStrata("FULLSCREEN_DIALOG")
a:SetToplevel(true)
a:SetClampedToScreen(true)
a:EnableMouse(true)
h(a)
a.measure=a:CreateFontString(nil,"OVERLAY",b.font("field"))
a.measure:Hide()
a:SetScript("OnHide",f)
a:Hide()
end





local function r(c,b)
local a=b
while a:GetParent()and a:GetParent()~=UIParent do a=a:GetParent()end
local d,e,f=b:GetEffectiveScale(),a:GetEffectiveScale(),c:GetEffectiveScale()
local g,h,i=b:GetLeft(),b:GetTop(),b:GetBottom()
local a,j,k=a:GetRight(),a:GetTop(),a:GetBottom()
local l,m=c:GetWidth(),c:GetHeight()
if not(g and h and i and a and j and k and l and m)then return end
local g=g*d+l*f>a*e
local a,d=i*d-k*e,j*e-h*d
local d=(m+2)*f>a and d>a
local a=g and"RIGHT"or"LEFT"
c:ClearAllPoints()
if d then
c:SetPoint("BOTTOM"..a,b,"TOP"..a,0,2)
else
c:SetPoint("TOP"..a,b,"BOTTOM"..a,0,-2)
end
end


local function m()Menu.GetManager():CloseMenus()end


local function n(a,d,b)return c.owner==a and b=="GLOBAL_MOUSE_DOWN"end


e.Debug.experimental("Blizzard's list menu (a context menu with HandlesGlobalMouseEvent on its owner) opened and picked from "
.."an addon window in combat, its taint kept to that menu: I (D Blizzard_Menu, C ShamanForever, EllesmereUI)")


e.Debug.experimental("a submenu and a greyed entry's tooltip in Blizzard's list menu from an addon window, in combat: I"
.." (D Blizzard_Menu's guide)")

function b.openMenu(a,g,h,j)
b.closeMenu()
m()
b.closeAsk()
b.closePicker()
local d=MenuUtil.CreateRootMenuDescription(MenuVariants.GetDefaultMenuMixin())

d:AddMenuAcquiredCallback(function(b)b:SetScale(a:GetEffectiveScale())end)

d:SetMinimumWidth(a:GetWidth())
local f
local function k(b,a)
for c,a in ipairs(a)do
local function c()f=a end
if a.divider then
b:CreateDivider()
elseif a.title then
b:CreateTitle(a.title)
elseif a.note then

b:CreateTitle(a.note,_G.GRAY_FONT_COLOR)
elseif a.submenu then
k(b:CreateButton(a.label),a.submenu)
elseif a.checked~=nil then
b:CreateRadio(a.label,function()return a.checked end,c)
else
local b=b:CreateButton(a.label,c)
if a.disabled then b:SetEnabled(false)end
if a.tip then
local a=a.tip
b:SetTooltip(function(b)GameTooltip_AddHighlightLine(b,a)end)
end
end
end
end
k(d,g)
if#g>b.MENU_ROWS then d:SetScrollMode(b.MENU_ROWS*b.MENU_ROW_H)end
if not rawget(a,"HandlesGlobalMouseEvent")then a.HandlesGlobalMouseEvent=n end

if not rawget(a,"menuHooked")then
a.menuHooked=true
a:HookScript("OnHide",function(a)if c.owner==a then b.closeMenu()end end)
end
local b=Menu.GetManager():OpenMenu(a,d,AnchorUtil.CreateAnchor("TOPLEFT",a,"BOTTOMLEFT",0,-2))
if not b then return end
r(b,a)
c.owner,c.menu=a,b
b:SetClosedCallback(function()
if c.menu~=b then return end
c.owner,c.menu=nil,nil
if f and h then i.atFrameEnd("kit menu pick",h,f.value)end
if j then e.try("kit menu close",j)end
end)
end

function b.closeMenu()
if c.menu then c.menu:Close()end
if a and a:IsShown()then a:Hide()end
end

function b.menuOwner()
if c.owner then return c.owner end
return a and a:IsShown()and d.owner or nil
end



local f,n,u=24,44,12

local function v(a)
local a=b.segment(a,"field")
a:SetSize(n,f-4)
a:SetScript("OnClick",function(a)if a.click then a.click()end end)
return a
end

local function o()
local c,a=a.grid,d.grid
if not a then return end
if c.top:IsShown()then c.top.mark:SetShown(a.topChecked and a.topChecked()and true or false)end
for d,c in ipairs(c.rows)do
if c:IsShown()then
local d=a.value(c.key)
for c,a in ipairs(c.segs)do b.paintSegment(a,a.value==d)end
end
end
end

local function c()
local c=CreateFrame("Frame",nil,a)
local e=k()
c:SetPoint("TOPLEFT",e.left,-e.top)
c:SetPoint("BOTTOMRIGHT",-e.right,e.bottom)
c.top=CreateFrame("Button",nil,c)
c.top:SetHeight(f)
c.top:SetPoint("TOPLEFT")
c.top:SetPoint("TOPRIGHT")
c.top:EnableMouse(true)
local e=c.top:CreateTexture(nil,"HIGHLIGHT")
e:SetAllPoints()
b.fill(e,"menuPick")
c.top.mark=c.top:CreateTexture(nil,"ARTWORK")
c.top.mark:SetTexture(b.art("check"))
c.top.mark:SetVertexColor(b.rgba("gold"))
c.top.mark:SetSize(g,g)
c.top.mark:SetPoint("LEFT",6,0)
c.top.text=c.top:CreateFontString(nil,"OVERLAY",b.font("field"))
c.top.text:SetPoint("LEFT",q,0)
c.top:SetScript("OnClick",function()
if d.grid then d.grid.pick(nil)end
o()
end)
c.rule=c:CreateTexture(nil,"ARTWORK")
b.fill(c.rule,"rule",0.3)
c.rule:SetHeight(1)
c.rows={}
a.grid=c
return c
end

local function w(c,d)
local a=c.rows[d]
if a then return a end
a=CreateFrame("Frame",nil,c)
a:SetHeight(f)
a.text=a:CreateFontString(nil,"OVERLAY",b.font("field"))
a.text:SetPoint("LEFT",6,0)
a.text:SetJustifyH("LEFT")
a.segs={}
c.rows[d]=a
return a
end

function b.openGrid(p,e,g)
if not a then t()end
b.closeMenu()
m()
b.closeAsk()
b.closePicker()
local c=a.grid or c()
d.owner,d.onClose,d.grid=p,g,e
local g=0
for c,b in ipairs(e.rows)do
a.measure:SetText(b.label)
g=math.max(g,a.measure:GetStringWidth())
end
g=g+6+u
local h=0
c.top:SetShown(e.top~=nil)
c.rule:SetShown(e.top~=nil)
local m=g+#e.options*(n-1)+2
if e.top then
c.top.text:SetText(e.top.label)
m=math.max(m,c.top.text:GetStringWidth()+q+8)
h=f+5
c.rule:ClearAllPoints()
c.rule:SetPoint("TOPLEFT",c,"TOPLEFT",0,-(f+2))
c.rule:SetPoint("TOPRIGHT",c,"TOPRIGHT",0,-(f+2))
end
for a,b in ipairs(e.rows)do
local a=w(c,a)
a.key=b.key
a.text:SetText(b.label)
a:ClearAllPoints()
a:SetPoint("TOPLEFT",c,"TOPLEFT",0,-h)
a:SetPoint("TOPRIGHT",c,"TOPRIGHT",0,-h)
for c,e in ipairs(e.options)do
local b=a.segs[c]or v(a)
a.segs[c]=b
b.value=e[1]
b.text:SetText(e[2])
b:ClearAllPoints()
b:SetPoint("LEFT",a,"LEFT",g+(c-1)*(n-1),0)
b.click=function()
local a=a.key
if d.grid then d.grid.pick(a,e[1])end
o()
end
b:Show()
end
for b=#e.options+1,#a.segs do a.segs[b]:Hide()end
a:Show()
h=h+f
end
for a=#e.rows+1,#c.rows do c.rows[a]:Hide()end
local d=k()
a:SetSize(m+d.left+d.right,h+d.top+d.bottom)
a:ClearAllPoints()
a:SetPoint("TOPLEFT",p,"BOTTOMLEFT",0,-2)
r(a,p)
c:Show()
j(l,b.WINDOW_NAME)
i.on("GLOBAL_MOUSE_DOWN","kit menu",s)
a:Show()
o()
end


function b.gridFrame()return a and a.grid end



local g,f,o,d,l,n="InterHUDAskInline",280,24,72,22,8
local a
local c={}

local function q()
c.anchor,c.run=nil,nil
i.off("GLOBAL_MOUSE_DOWN","kit ask")
j(b.WINDOW_NAME,g)
end


local function p()
local d=c.anchor
if not d then return end
local c=k()
local b=c.top+n
a.prompt:ClearAllPoints()
a.prompt:SetPoint("TOPLEFT",c.left+4,-b)
a.prompt:SetWidth(f-c.left-c.right-8)
b=b+a.prompt:GetStringHeight()+n
a.box:ClearAllPoints()
a.box:SetPoint("TOPLEFT",c.left+4,-b)
b=b+o+4
a.err:ClearAllPoints()
a.err:SetPoint("TOPLEFT",c.left+4,-b)
a.err:SetWidth(f-c.left-c.right-8)
if a.err:IsShown()then b=b+a.err:GetStringHeight()+4 end
b=b+4
a.ok:ClearAllPoints()
a.ok:SetPoint("TOPRIGHT",a.cancel,"TOPLEFT",-6,0)
a.cancel:ClearAllPoints()
a.cancel:SetPoint("TOPRIGHT",-c.right-4,-b)
local c=b+l+n+c.bottom
a:SetSize(f,c)
local b=d:GetEffectiveScale()/UIParent:GetEffectiveScale()
a:SetScale(b)


local e=d:GetBottom()
local b=d
while b:GetParent()and b:GetParent()~=UIParent do b=b:GetParent()end
local b=(b:GetBottom()or 0)*b:GetEffectiveScale()
a:ClearAllPoints()
if e and e*d:GetEffectiveScale()-(c+2)*a:GetEffectiveScale()<b then
a:SetPoint("BOTTOMLEFT",d,"TOPLEFT",0,2)
else
a:SetPoint("TOPLEFT",d,"BOTTOMLEFT",0,-2)
end
end

local function n()
local b=c.run
if not b then return end
local c,b=e.try("kit ask",b,a.box:GetText())
if not(c and b)then return a:Hide()end
a.err:SetText(b)
a.err:Show()
p()
a.box:SetFocus()
end

local function e()
a=CreateFrame("Frame",g,UIParent)
a:SetFrameStrata("FULLSCREEN_DIALOG")
a:SetToplevel(true)
a:SetClampedToScreen(true)
a:EnableMouse(true)
h(a)
a.prompt=b.fontString(a,"field")
a.prompt:SetJustifyH("LEFT")
a.prompt:SetWordWrap(true)
a.box=b.editBox(a,f-k().left-k().right-8,o)
a.box:SetMaxLetters(48)
a.box:SetScript("OnEnterPressed",n)
a.box:SetScript("OnEscapePressed",function()a:Hide()end)
a.err=b.fontString(a,"field")
b.tint(a.err,"error")
a.err:SetJustifyH("LEFT")
a.err:SetWordWrap(true)
a.ok=b.button(a,"OK",d,l)
a.ok:SetScript("OnClick",n)
a.cancel=b.button(a,"Cancel",d,l)
a.cancel:SetScript("OnClick",function()a:Hide()end)
a:SetScript("OnHide",q)
a:Hide()
end


local function f()
if a:IsMouseOver()or(c.anchor and c.anchor:IsMouseOver())then return end
a:Hide()
end

function b.askInline(d,h,k,l)
if not a then e()end
local e=c.anchor==d
b.closeAsk()
b.closeMenu()
b.closePicker()
if e then return end
m()
c.anchor,c.run=d,l

if not d.askHooked then
d.askHooked=true
d:HookScript("OnHide",function(b)if c.anchor==b then a:Hide()end end)
end
a.prompt:SetText(h)
a.err:SetText("")
a.err:Hide()
a.box:SetText(k or"")
p()
j(g,b.WINDOW_NAME)
i.on("GLOBAL_MOUSE_DOWN","kit ask",f)
a:Show()
a.box:SetFocus()
a.box:HighlightText()
end

function b.closeAsk()
if a and a:IsShown()then a:Hide()end
end

function b.askOwner()return a and a:IsShown()and c.anchor or nil end
function b.askFrame()return a end
