








local a,b=...
local e,i,f,c=b.Kit,b.Schema,b.Spells,b.Store

local a={}
b.AlertWhen=a

local o={{"buff","A buff is on you"},{"stacks","A buff is at N stacks or more"},
{"usable","A spell becomes usable"},{"reset","A cooldown ends early"}}
a.MODES=o



local k={buff={kind="aura",unit="player"},stacks={kind="aura",unit="player"},
usable={kind="spell",single=true},reset={kind="spell"}}
a.KINDS=k


local p={none=true,custom=true,nopicture=true}

local s,m=2,5
local g,l,j="just-reset","stacks","ready-and-usable"

local function d(a)
if a==nil then return{}end
if type(a)=="table"then return a end
return{a}
end


local function h(b)
local a
for c,b in ipairs(type(b.sources)=="table"and b.sources or{})do
a=a or c
for d,a in ipairs(type(b.layers)=="table"and b.layers or{})do
if a.kind==i.ALERT_LAYER then return b,c,a end
end
end
if a then return b.sources[a],a,nil end
end


local function n(a)
local b=d(a["while"])
if#b~=1 or a.unless~=nil then return nil end
return b[1]
end



local function q(a,b)
if type(a)~="table"or type(a.hold)=="table"and a.hold.after~=nil then return false end
if#d(a.any)>0 or#d(a.none)>0 then return false end
local a=d(a.all)
if#a~=2 then return false end
local b={[b..".ready"]=true,[b..".usable"]=true}
return b[a[1]]==true and b[a[2]]==true and a[1]~=a[2]
end

local function r(a)
if a==nil then return""end
return f.nameOf(a)or tostring(a)
end


function a.read(g)
local a,b,c=h(g)
if not a then return{mode="none"}end
local b=f.firstOf(a.spells)
local b={mode="custom",spell=b,spells=f.listOf(a.spells),name=r(b)}
if not c then
b.mode="nopicture"
return b
end
local e=c.looks or{}
local d=#e==1 and n(e[1])or nil
if not d then return b end
local e=e[1]
if a.kind=="aura"and(a.unit or"player")=="player"then
if d=="missing"and e.shown==false and c.shown~=false then
b.mode="buff"
elseif c.shown==false and e.shown==true then
for c,a in ipairs(type(a.facts)=="table"and a.facts.stacks or{})do
if a.id==d and a.atLeast and not a.atMost and not a.between then
b.mode,b.stacks="stacks",a.atLeast
end
end
end
elseif a.kind=="spell"and c.shown==false and e.shown==true then

for e,c in ipairs(g.customStates or{})do
if c.id==d and type(c.hold)=="table"and c.hold.after==a.id..".reset"then
b.mode,b.seconds="reset",c.hold.seconds
elseif c.id==d and q(c,a.id)then
b.mode="usable"
end
end
end
return b
end

local function n(a,b)return a.." "..b..(a==1 and""or"s")end

function a.sentence(a)
if a.mode=="buff"then return"While "..a.name.." is on you."end
if a.mode=="stacks"then return"While "..a.name.." is at "..n(a.stacks,"stack").." or more."end
if a.mode=="usable"then return"While "..a.name.." is usable."end
if a.mode=="reset"then
return"For "..n(a.seconds or m,"second").." after "..a.name.."'s cooldown ends early."
end
if a.mode=="none"then return""end
if a.mode=="nopicture"then return"No picture: add a Spell Alert layer with Add layer."end
return"Custom: see the picture's looks."
end


local function n(a)
local b=i.field("source","spells",a.kind)
return not(a.single or b and b.maxItems==1)
end


local function q(a)
local b={}
for c=2,#(a.spells or{})do
local a=a.spells[c]
b[#b+1]=f.nameOf(a)and(f.nameOf(a).." ("..a..")")or tostring(a)
end
return b
end


local function f(a)
if#a<2 then return a[1]or""end
return table.concat(a,", ",1,#a-1).." and "..a[#a]
end


function a.replacesLine(b)
local a=b and q(a.read(b))or{}
if#a==0 then return nil end
return"Alert when replaces its other spells "..f(a).."."
end





local function r(b,c,a)
if b=="buff"then
return{look={["while"]="missing",shown=false},sound={event="arrived"}}
elseif b=="stacks"then
return{shown=false,look={["while"]=l,shown=true},
stacks={{id=l,atLeast=c.stacks or s}}}
elseif b=="usable"then

return{shown=false,look={["while"]=j,shown=true},
customState={id=j,name="Ready and usable",all={a..".ready",a..".usable"}},
sound={customState=j,event="enters"}}
end
return{shown=false,look={["while"]=g,shown=true},
customState={id=g,name="After it ends early",all=a..".ready",
hold={after=a..".reset",seconds=c.seconds or m}},
sound={customState=g,event="enters"}}
end


local function m(b)
local a={}
i.eachRecord("element",b,function(c,b,d)
if c=="effect"and b.kind=="sound"then a[#a+1]={effect=b,path=d}end
end)
return a
end




local function s(e,a,c)
local a=r(a,{},c).customState
if not a then return true end
local function c(c)
local a={}
for b,c in pairs(c)do a[b]=c end
for e,b in ipairs({"all","any","none"})do
a[b]=#d(c[b])>0 and d(c[b])or nil
end
if type(a.hold)=="table"then
a.hold=b.copy(a.hold)
a.hold.seconds=nil
end


local b={}
for d,c in pairs(type(c.events)=="table"and c.events or{})do
local a={}
for c,b in ipairs(type(c)=="table"and c.effects or{})do
if not(type(b)=="table"and b.kind=="sound")then a[#a+1]=b end
end
if#a>0 then b[d]=a end
end
a.events=next(b)and b or nil
return a
end
return b.equal(c(e),c(a))
end




function a.replaced(d,b,i)
local a={}
local d=c.element(d.id)or{}
local h,e,c=h(d)
if b.mode=="custom"and c and type(c.looks)=="table"and#c.looks>0 then
a[#a+1]="the picture's looks you set by hand"
end
local c,e={},{}
for d,a in ipairs(type(d.customStates)=="table"and d.customStates or{})do
local d=a.id==g and b.mode=="reset"or a.id==j and b.mode=="usable"
if not d then
c[#c+1]=a.name or a.id
elseif h and not s(a,b.mode,h.id)then
e[#e+1]=a.name or a.id
end
end
if#c>0 then a[#a+1]="the custom state"..(#c>1 and"s "or" ")..table.concat(c,", ")end
if#e>0 then a[#a+1]="your changes to the custom state "..table.concat(e,", ")end
local b=n(k[i])and{}or q(b)
if#b>0 then a[#a+1]="its other spells "..f(b)end
if#m(d)>0 and i=="stacks"then a[#a+1]="its sound, which At N stacks can't play"end
return a
end



local function d(c,j,l,f)
local d=k[j]
c.sources=type(c.sources)=="table"and c.sources or{}

local a=m(c)[1]
local g=a and b.copy(a.effect)
local e,m,h=h(c)
local k=e and e.kind==d.kind and(e.unit or"player")==(d.unit or"player")
local a=k and e or{kind=d.kind}
if d.unit and d.unit~="player"then a.unit=d.unit end
a.id=e and e.id or b.Form.freeId(c,d.kind=="aura"and"buff"or"spell")

if f.spells and f.spells[1]==l and n(d)then
a.spells=b.copy(f.spells)
else
a.spells={l}
end


if f.exact then a.exact={l}elseif not k then a.exact=nil end
a.layers=e and e.layers or{}


local d=j=="usable"and k and type(a.facts)=="table"and type(a.facts.usable)=="table"
and b.copy(a.facts.usable)or nil
a.facts,a.events=nil,nil
if d then
for b,a in ipairs(d)do
if type(a)=="table"then a.events=nil end
end
a.facts={usable=d}
end
local d=r(j,f,a.id)
if d.stacks then a.facts={stacks=d.stacks}end
if not h then
h={kind=i.ALERT_LAYER,id=b.Form.freeId(c,"spell-alert")}
a.layers[#a.layers+1]=h
end
h.shown,h.looks=d.shown,{d.look}
if m then c.sources[m]=a else c.sources[1]=a end

c.customStates=d.customState and{d.customState}or nil

if d.sound then
local e=g==nil
g=g or{kind="sound",id=b.Form.freeId(c,"sound")}
local b={g}
if d.sound.customState then
d.customState.events={[d.sound.event]={effects=b}}
else
a.events={[d.sound.event]={effects=b}}
end
if e then
c.quick=type(c.quick)=="table"and c.quick or{}
c.quick[#c.quick+1]={label="Sound",part=g.id,field="sound"}
end
end
end

function a.write(a,b,e,f)
return c.editElement(a,function(a)d(a,b,e,f or{})end)
end


function a.setSpell(a,b,d)
return c.editElement(a,function(a)
local a=h(a)
if a then a.spells,a.exact={b},d and{b}or nil end
end)
end

function a.setStacks(a,b)
return c.editElement(a,function(a)
local a=h(a)
for c,a in ipairs(a and type(a.facts)=="table"and a.facts.stacks or{})do
if a.id==l then a.atLeast=b end
end
end)
end
function a.setSeconds(a,b)
return c.editElement(a,function(a)
for c,a in ipairs(type(a.customStates)=="table"and a.customStates or{})do
if a.id==g and type(a.hold)=="table"then a.hold.seconds=b end
end
end)
end




local g={}

b.onChanged(function(a,b)
if a=="profile"then
wipe(g)
elseif a=="element"and not c.element(b)then
g[b]=nil
end
end,"alert when drafts")
local function i(a)

if a==nil then return{}end
g[a]=g[a]or{}
return g[a]
end


e.confirm("ALERT_WHEN","%s","Change",function(a)a.run()end)




function a.build(c,l,h)
local function f()return c.target end
local function d()
local b=l()
return b and a.read(b)or{mode="none"}
end
local function j()return i(f())end
local function i()
local a=d()
if a.mode=="none"then return j().mode or"none"end
return a.mode
end
local function q(...)
local a=i()
for c,b in ipairs({...})do
if a==b then return true end
end
return false
end
local function k(c,a)
return b.PageElement.answer(f(),{ok=c,line=a and a[1]and a[1].text})
end
local function m()return d().mode~="none"end

local function n(c,a)
local a={at="alert",id=f(),kind=b.NewModel.way(true,a)}
e.openPicker(c,{
read=function(c)return b.PickerModel.picker(a,c)end,
pick=function(d)
local function c()
local a=b.PickerModel.pick(a,d)
if a.ok then g[f()]=nil end
return b.PageElement.answer(f(),a),a.line
end
local a=b.PickerModel.ask(a)
if not a then return c()end
e.showPopup("ALERT_WHEN",a,{run=c})
return true
end,
})
end
local g

local function b(c)
local h=l()
local b=d()
if not h or p[c]then return true end
if b.mode=="none"then
j().mode=c
e.repaint()
n(g.dropdown,c)
return true
end
if c==b.mode then return true end
local g={stacks=b.stacks,seconds=b.seconds,spells=b.spells}
local function d()k(a.write(f(),c,b.spell,g))end
local a=a.replaced(h,b,c)
if#a==0 then
d()
else
e.showPopup("ALERT_WHEN","Alert when replaces "..table.concat(a," and ")..".",{run=d})
end
return true
end

g=e.dropdown(c.content,"Alert when",nil,i,b,{dense=true,
choices=function()
local a={}
for c,b in ipairs(o)do a[c]={b[1],b[2]}end
if i()=="custom"then a[#a+1]={"custom","Custom"}end
if i()=="nopicture"then a[#a+1]={"nopicture","No picture"}end
if i()=="none"then a[#a+1]={"none","Choose…"}end
return a
end,
offered=function(a)return not p[a]end})
c:addRow(g,h)

c:textbox("Spell",nil,function()return tostring(d().spell or"")end,function(b)
local b=tonumber(b)
if not b then return false end
local function c()k(a.setSpell(f(),b))end

local a=a.replacesLine(l())
if not a then
c()
else
e.showPopup("ALERT_WHEN",a,{run=c})
end
return true
end,function()return h()and m()and q("buff","stacks","usable","reset")end,
{dense=true,width=80,note=function()return d().name or""end,
action={text="Pick…",width=70,click=function(a)n(a,i())end}})
c:addRow(e.slider(c.content,"Stacks","The picture shows from this many stacks.",function()
return d().stacks
end,function(b)return(k(a.setStacks(f(),b)))end,
{min=2,max=255,softMax=10,step=1,dense=true}),function()
return h()and d().mode=="stacks"
end)
c:addRow(e.slider(c.content,"Seconds","How long the picture shows after the reset.",function()
return d().seconds
end,function(b)return(k(a.setSeconds(f(),b)))end,
{min=0.5,max=60,softMax=20,step=0.5,unit="s",dense=true}),function()
return h()and d().mode=="reset"
end)

c:hint(function()return a.sentence(d())end,4,function()return h()and m()end)


local function a()return h()and not m()and j().mode~=nil end
c:buttons({{text="Pick its spell…",width=130,click=function(a)n(a,j().mode)end}},
a)
end
