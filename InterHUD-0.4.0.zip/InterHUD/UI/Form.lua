


local a,b=...
local d,o,h,c,e,l=b.Schema,b.Clean,b.Resolve,b.Store,b.Layers,b.Styles

local a={}
b.Form=a







local f={boolean="toggle",choice="choice",unit="choice",point="choice",percent="percent",
number="slider",integer="slider",string="text",spell="spell",colour="colour",sound="sound",
keys="keys",spells="spells"}

local function m(a)
return not a.required and a.default==nil and a.defaultFrom==nil
end
a.optional=m

local function n(a)
if a.control then return a.control end
if a.type=="list"and(a.of=="choice"or a.ref=="layer")then return"multi"end


if(a.type=="number"or a.type=="integer")and m(a)then return a.softMax and"slider"or"edit"end
return f[a.type]
end
a.widgetOf=n

local function j(b)
local a={}
for b,c in ipairs(b)do a[b]=tostring(c)end
return table.concat(a,".")
end
a.pathKey=j

local function f(b,c)
local a={}
for b,c in ipairs(b)do a[b]=c end
a[#a+1]=c
return a
end
a.extend=f
local function g(a,c)
local b={}
for c=1,#a-(c or 1)do b[c]=a[c]end
return b
end
a.up=g


function a.pathString(b)
local a=""
for c,b in ipairs(b)do
if type(b)=="number"then a=a.."["..b.."]"
else a=a==""and tostring(b)or(a.."."..tostring(b))end
end
return a
end
function a.pathList(b)
local a={}
for b in tostring(b or""):gmatch("[^%.]+")do
local b,c=b:match("^([^%[]*)(.*)$")
if b~=""then a[#a+1]=b end
for b in c:gmatch("%[(%d+)%]")do a[#a+1]=tonumber(b)end
end
return a
end


function a.read(a,b)
for c,b in ipairs(b)do
if type(a)~="table"then return nil end
a=a[b]
end
return a
end




function a.inForce(c,d)
local c=c.path
if not d then return nil end
local a=a.read(d,g(c))
if c[#c]=="fontSize"then
return type(a)=="table"and b.TextColours.sizeOf(a)or nil
end
if(c[#c]=="length"or c[#c]=="thickness")and c[#c-2]=="layers"then return d.baseSize end
if(c[#c]=="width"or c[#c]=="height")and c[#c-2]=="layers"and type(a)=="table"then
local b=e.get(a.kind)
if b and b.pictureSize then
local a,b=b.pictureSize(a)
return c[#c]=="width"and a or b
end
return d.baseSize
end
end




function a.pictureOpts(b,c)
local b=b.path
local a=c and b[#b]=="picture"and a.read(c,g(b))
local a=type(a)=="table"and e.get(a.kind)
if not(a and a.families)then return nil end
return{families=a.families,familyOf=a.familyOf}
end



function a.unitOf(a)
if a.control=="edit"and(a.name=="x"or a.name=="y")then return nil end
return a.unit or(a.type=="percent"and"%"or nil)
end




local i={facts=true,events=true,changeEvents=true,ownStyles=true,origin=true,
hold=true}
local function s(a,b)

return a.exportOnly or(a.type=="id"and not a.ref)or(a.name=="kind"and not tostring(b):find("^style:"))
or(a.type=="list"and a.record~=nil)or a.type=="map"
or i[a.record or false]or a.name=="enabled"

or(a.partKind~=nil and not tostring(b):find("^look:"))
end


function a.labelOf(a,b)
return a.labelFrom and a.labelFrom(b or{})or a.label
end

local function t(a,b)
return a.under and{path=f(b,a.under[1]),
values=type(a.under[2])=="table"and a.under[2]or{a.under[2]}}
end





local function k(c,p,h,b,l,e,g,m,q)
local b,o,i=d.frame(p,h or{},b)

local o={}
local r,u=e,g
for v,b in ipairs(b)do
e,g=r,u

local p=not s(b,p)and not(m and m.ownSize and b.name=="size")
and not(q and q(b))
if p and b.group then
local a=o[b.group]
if not a then
local f=f(l,"@"..b.group)
a={key=j(f),path=f,label=d.groupLabel(b.group),heading=true,group=b.group,
depth=e,parent=g}
c[#c+1]=a
o[b.group]=a
a.members={}
end
e,g=r+1,a
end
if p then
local d=f(l,b.name)
local f=t(b,l)
if b.type=="record"and b.style then
k(c,b.record,h and h[b.name],i,d,e,g,
{path=d,part=b.style,ownSize=b.ownSize})
elseif b.type=="record"then
c[#c+1]={key=j(d),path=d,field=b,label=a.labelOf(b,i),heading=true,
depth=e,under=f,parent=g}
k(c,b.record,h and h[b.name],i,d,e+1,c[#c])
else
c[#c+1]={key=j(d),path=d,field=b,label=a.labelOf(b,i),
widget=n(b),unit=a.unitOf(b),depth=e,under=f,vars=i,
parent=g,style=m}
end
end
end

for a,b in ipairs(c)do
local a=b.parent
while a and not a.members do a=a.parent end
if a and o[a.group]==a then a.members[#a.members+1]=b end
end
end
a.addRows=k



function a.headingsLast(c)
local function d(a)
local b=a.heading and a or nil
local a=a.parent
while a do
if a.heading then b=a end
a=a.parent
end
return b
end
local a,b={},{}
for e,c in ipairs(c)do
local a=d(c)and b or a
a[#a+1]=c
end
for c,b in ipairs(b)do a[#a+1]=b end
return a
end


function a.varsAt(a,g)
local e,a,f,b="element",a,{},1
while b<=#g do
local d,c,h=d.frame(e,type(a)=="table"and a or{},f)
local c
for d,a in ipairs(d)do
if a.name==g[b]then c=a end
end
if not(c and c.record)then return nil end
a=type(a)=="table"and a[c.name]or nil
if c.type=="list"or c.type=="map"then
b=b+1
a=type(a)=="table"and a[g[b]]or nil
end
e,f,b=c.record,h,b+1
end
local c,d,b=d.frame(e,type(a)=="table"and a or{},f)
return e,a,f,b
end





function a.partSections(g,b,l,h)
local i={}
local n,b,m=d.frame("layer",g,b)
local b=h and d.source(d.variantKey(h))
local d=b and b.offersPart
local c={}
for b,a in ipairs(n)do c[a.name]=a end
for n,b in ipairs(e.partsOf(g.kind))do
local c=c[b.key]
if c and c.partUnder then
local a,b=c.partUnder[2],g[c.partUnder[1]]
if not(b==a or(type(a)=="table"and e.inList(a,b)))then c=nil end
end
if c and d and not d(h,b.kind)then c=nil end
if c then
local c=b.list and(g[b.key]or{})or{g[b.key]or{}}
for g,c in ipairs(c)do
local d=b.list and f(f(l,b.key),g)or f(l,b.key)
local a={key=j(d),partKey=b.key,kind=b.kind,item=b.list and g or nil,
partId=b.list and c.id or nil,off=c.enabled==false,rows={},path=d,
on=f(d,"enabled"),
title=a.partTitle(c,g,e.partLabel(b.kind,m))}
k(a.rows,"part:"..b.kind,c,m,d,0)

for c,b in ipairs(a.rows)do b.partOn=a.on end
i[#i+1]=a
end
end
end
return i
end

function a.partTitle(c,a,b)
return c.name or(a>1 and(b.." "..a)or b)
end


a.sourceTypeLabel=d.sourceTypeLabel


a.layerKindLabel=e.kindLabel
function a.layerName(a,b)return e.nameOf(a and a.layers,b)end


local p={
unit={player="You",target="Your target",pet="Your pet",focus="Your focus target"},
point={TOPLEFT="Top left",TOP="Top",TOPRIGHT="Top right",LEFT="Left",CENTER="Centre",
RIGHT="Right",BOTTOMLEFT="Bottom left",BOTTOM="Bottom",BOTTOMRIGHT="Bottom right"},
}




a.NONE=""



function a.overDefault(a,b)
local c=a.vars and a.vars.source
for b,a in ipairs(b and b.layers or{})do
if a.kind=="icon"and a.id and(c==nil or a.source==c.id and a.enabled~=false)then
return a.id
end
end
end
function a.choices(f,j)
local c=f.field
local h=c.type=="list"and(c.item or{})or c
local g=a.read(j,g(f.path))
local e,i={},{}
if c.ref=="layer"and c.type=="list"then
local c=f.vars or{}
for d,b in ipairs(j and j.layers or{})do
if b.id and not(c.moment=="engine"and c.source and b.source~=c.source.id)then
e[#e+1]=b.id
i[b.id]=a.layerName(j,b)
end
end
return e,i
end
e=o.choicesOf(h,g,f.vars or{})
if c.type~="list"and m(c)and#e>0 then
local a={a.NONE}
for b,c in ipairs(e)do a[b+1]=c end
e=a
end

if h.offered then
local d=type(g)=="table"and g[c.name]or nil
local c={}
for e,b in ipairs(e)do
if b==a.NONE or b==d or h.offered(b)then c[#c+1]=b end
end
e=c
end

local j=h.pickSpell
local k={}
if j and type(g)=="table"then
local a={}
for c,b in ipairs(e)do
if b~=j.value then a[#a+1]=b end
end
for d,c in ipairs(b.Spells.listOf(g.spells))do
a[#a+1]=c
k[c]=b.Spells.nameOf(c)
end
e=a
end
local b=f.vars and d.source(f.vars.variant)
local d=p[h.type or c.type]
local f=c.labelsFrom and c.labelsFrom(f.vars or{})
for e,a in ipairs(e)do
local e=b and(b.states and b.states[a]or b.facts and b.facts[a])
local b=b and b.events and b.events[a]
i[a]=k[a]or(f and f[a])or(h.labels and h.labels[a])
or(c.labels and c.labels[a])or(d and d[a])
or(e and e.label)or(b and b.label)or tostring(a)
end
i[a.NONE]=c.noneLabel or"None"
return e,i
end




function a.popMoves(b,a)
if not(a and a.kind=="pop")then return true end
local a=a.at or{}
if a.moment=="engine"then return false,"button"end
local b=a.source and b.sourcesById and b.sourcesById[a.source]
local b=b and d.variantOf(b)
local a=b and a.event and b.events[a.event]
if not(a and e.effectMoves)then return true end
local a,b,c=pcall(e.effectMoves,{plain=b.moment~="engine",event=a,target={}})
if not a or b~=false then return true end
return false,c
end





function a.shown(b,c)
if b.parent and not a.shown(b.parent,c)then return false end
if b.partOn and a.read(c,b.partOn)==false then return false end
if b.style and b.style.part=="pop"and b.field and b.field.name=="motion"
and a.styleVars(c,b.path).motion=="none"then
return false
end
if b.field and b.field.shownIf and not b.field.shownIf(c,a.read(c,g(b.path)))then
return false
end
if b.widget=="choice"then
local b=a.choices(b,c)
if#b==0 or(#b==1 and b[1]==a.NONE)then return false end
end
if not b.under then return true end
local a=a.read(c,b.under.path)
for c,b in ipairs(b.under.values)do
if a==b then return true end
end
return false
end



function a.nameOf(c)
if c.name then return c.name end
local d=c.sources and c.sources[1]
local e=d and b.Spells.firstOf(d.spells)

return(e and b.Spells.label(e))or(d and a.sourceWords(d))or c.id
end


a.namesWords,a.sourceWords=d.namesWords,d.sourceWords



local function m(a)
if not b.Sources.unset(a)then return false end
local b=b.Sources.get(a.kind)
local a
for c,b in pairs(b and b.variants or{})do
local b=b.add and b.add.label
if b then
if a and b~=a then return true end
a=a or b
end
end
return false
end


local i={player="on you",target="on your target",pet="on your pet",focus="on your focus target"}
function a.unitNote(a)
if not(a and a.unit)or m(a)then return nil end
return i[a.unit]or i.player
end


function a.sourceLabel(b)
local c=a.sourceWords(b)
local a=b and b.unit
if a and a~="player"and i[a]and not m(b)then return c..", "..i[a]end
return c
end






a.OTHER_VERSIONS="Also counts its other versions."
a.CAMP_BUFF="Also counts the %s's buff."

local i
local function m(a)
if not i then
i={}
for b,a in pairs(b.SpellTable and b.SpellTable.families or{})do
for a,b in pairs(a.equivalents or{})do i[a]=i[a]or b.object end
end
end
return i[a]
end
function a.widenedLine(c,d)
local c=a.read(c,g(d))
local d=type(c)=="table"and b.Sources.get(c.kind)
if not(d and d.widenedFrom)then return""end
local c,d=pcall(d.widenedFrom,c.spells,c.unit,c.castBy~="anyone",c.exact)
if not(c and type(d)=="table")then return""end
local c,e={},{}
if#(d.variants or{})>0 then c[1]=a.OTHER_VERSIONS end
for f,d in ipairs(d.equivalents or{})do
local b=b.Spells.nameOf(m(d))
if b and not e[b]then
e[b]=true
c[#c+1]=a.CAMP_BUFF:format(b)
end
end
return table.concat(c,"\n")
end


function a.partAt(e,c)
if c==nil then return e,{},"element"end
local i,f=d.splitKey(c)
local b
d.eachRecord("element",e,function(e,a,g,h)
if b then return false end
local d=d.get(e)
if f then
if d.idSpace=="source"and h.source and h.source.id==f and a.id==i then b={a,g,e}end
elseif d.idSpace=="element"and a.id==c then
b={a,g,e}
end
end)
if b then return b[1],a.pathList(b[2]),b[3]end
end






function a.quickTarget(c,d,e)
local b=b.Check.quickTarget(c,d,e)
if not b then return nil end
local a=a.pathList(b.path)
if b.lookWord~=nil then a=f(f(a,"looks"),b.lookIndex or b.lookWord)end
if#b.names==2 then a=f(a,b.names[1])end
return{path=f(a,b.field.name),field=b.field,vars=b.ownVars or{},look=b.lookWord,
missingLook=b.lookWord~=nil and b.lookIndex==nil}
end





function a.quickRows(k)
local i={}
local function c(c,l,m)
local j="quick:"..j(l)
if c.choices~=nil then
i[#i+1]={key=j,itemPath=l,choice=c,label=c.label,help=c.help,depth=0,
vars={},section=m}
return
end
local e=a.quickTarget(k,c)
if not e then return end
local b=e.field

local h
for c,b in ipairs(c.also or{})do
local a=a.quickTarget(k,b)
if a then
h=h or{}
h[#h+1]=a
end
end
local k=h and"setQuickPointer"or(e.look~=nil and"setQuickLook"or nil)
i[#i+1]={key=j,itemPath=l,path=e.path,field=b,section=m,help=c.help,pointer=c,
label=c.label or(b.group and(d.groupLabel(b.group)..": "..a.labelOf(b,e.vars)))or a.labelOf(b,e.vars),
widget=n(b),unit=a.unitOf(b),depth=0,vars=e.vars,op=k,look=e.look,also=h,
under=b.under and{path=f(g(e.path),b.under[1]),
values=type(b.under[2])=="table"and b.under[2]or{b.under[2]}}}
end
for b,a in ipairs(k.quick or{})do
if a.section~=nil then
for d,e in ipairs(a.rows or{})do c(e,{"quick",b,"rows",d},{key="s"..b,title=a.section})end
else
c(a,{"quick",b})
end
end
return i
end

function a.quickSections(d)
local c,b={},nil
for d,a in ipairs(a.quickRows(d))do
local d=a.section and a.section.key or"top"
if not(b and b.key==d)then
b={key=d,title=a.section and a.section.title or nil,rows={}}
c[#c+1]=b
end
b.rows[#b.rows+1]=a
end
return c
end




a.setLookField=b.Check.setLookField




function a.writeQuickPointer(c,b,e)
local d=a.pathString(b)
for f,b in ipairs(a.quickRows(c))do
if b.also and a.pathString(b.path)==d then
local d={{path=b.path,look=b.look}}
for b,a in ipairs(b.also)do d[#d+1]=a end
for d,b in ipairs(d)do
if b.look~=nil then a.setLookField(c,b.path,e)else a.writer(b.path,e)(c)end
end
return true
end
end
return false
end


function a.applyQuickWrite(c,d)
local b=a.quickTarget(c,d,true)
if not b then return false end
local d=d.clear and nil or d.value
if b.look~=nil then return a.setLookField(c,b.path,d)end
a.writer(b.path,d)(c)
return true
end



function a.quickMatch(h,c)
for c,d in ipairs(c.choices or{})do
local e=true
for c,f in ipairs(d.writes or{})do
local c=a.quickTarget(h,f,true)
local d
if c and not c.missingLook then d=a.read(h,c.path)end

if c and c.field.type=="keys"and type(d)=="table"and#d==1 then d=d[1]end
if f.clear then
if d~=nil then e=false end
elseif d==nil then
if not c or f.value~=b.Clean.defaultOf(c.field,a.read(h,g(c.path))or{},c.vars)then e=false end
elseif d~=f.value then
e=false
end
if not e then break end
end
if e then return c end
end
end




local n={toggle="On/off",switch="On/off",choice="Dropdown",multi="Tick boxes",spells="Spell list",spell="Spell",
text="Text",colour="Colour",edit="Number",fileId="Picture",sound="Sound",slider="Slider",
percent="Slider"}
local function i(a)
if a==nil then return"not set"end
if a==true then return"On"end
if a==false then return"Off"end
if type(a)=="table"then
local c={}
for d,a in ipairs(a)do c[d]=b.Spells.nameOf(a)or tostring(a)end
return#c>0 and table.concat(c,", ")or"none"
end
return tostring(a)
end

local function m(f,d)
local c,e=b.Check.partOf(f,d.part)
local b
if not c then b="nothing"
elseif c=="element"then b="the element"
elseif c=="source"then b=a.sourceLabel(e)
elseif c=="layer"then b=a.layerName(f,e).." layer"
elseif c=="effect"then b=(e.name or tostring(e.kind)).." effect"
elseif c=="customState"then b="custom state "..tostring(e.name or e.id)
elseif c:match("^part:")then b=e.name or c:sub(6)
elseif c:match("^factItem:")then b=tostring(d.part)
else b=tostring(d.part)end
if d.look~=nil then b=b..", its "..tostring(d.look).." look"end
local c=a.quickTarget(f,d,true)
local h=c and a.labelOf(c.field,c.vars)or tostring(d.field)
local e={}
for a in tostring(d.field):gmatch("[^%.]+")do e[#e+1]=a end
if#e==2 and c then
local b=a.fieldAt("element",f,g(c.path))
h=(b and a.labelOf(b,c.vars)or e[1])..": "..h
end
return b.." · "..h
end
function a.quickWords(d)
local b={}
for e,c in ipairs(a.quickSections(d))do
local e={title=c.title,rows={}}
b[#b+1]=e
for c,b in ipairs(c.rows)do
local c={label=b.label,help=b.help}
if b.choice then
c.control="Dropdown"
local a=a.quickMatch(d,b.choice)
c.ships=a and b.choice.choices[a].label or"Custom"
c.choices={}
for e,a in ipairs(b.choice.choices or{})do
local b={}
for c,a in ipairs(a.writes or{})do
b[c]=m(d,a)..(a.clear and" cleared"or(" = "..i(a.value)))
end
c.choices[e]={label=a.label,writes=table.concat(b,"; ")}
end
else
local e=b.field
c.control=n[b.widget]or b.widget
if(b.widget=="slider"or b.widget=="percent")and e.min~=nil and e.max~=nil then
c.control=c.control.." "..e.min.." to "..e.max..(b.unit or"")
end
if b.widget=="choice"then
local b,d=a.choices(b,d)
local a={}
for c,b in ipairs(b)do a[c]=d[b]or tostring(b)end
c.control=c.control..": "..table.concat(a,", ")
end
c.points=m(d,b.pointer)
local e=a.read(d,b.path)
if b.widget=="choice"then
local b,a=a.choices(b,d)
c.ships=e~=nil and(a[e]or tostring(e))or"not set"
else
c.ships=i(e)
end
end
e.rows[#e.rows+1]=c
end
end
return b
end


function a.caveats(a,b)
return d.caveatsAt(b,a.path,a.vars)
end


function a.view(a)
local a=c.element(a)
return a and h.element(a,c.profile())
end

function a.get(b,c)
return a.read(a.view(b),c)
end


function a.own(b,d)
return a.read(c.element(b),d)
end


local function m(a,c,d)
local a=a
for b=1,#c-1 do
local b=c[b]
if type(a[b])~="table"then a[b]={}end
a=a[b]
end
a[c[#c]]=b.copy(d)
end
a.setAt=m


local function i(e,f)
return function(g)
local c=g
for a=1,#e-1 do
local a=e[a]
if type(c[a])~="table"then c[a]={}end
c=c[a]
end
local h=e[#e-2]=="sources"and type(c.kind)=="string"and b.Sources.get(c.kind)

if type(f)=="number"and h then
for b,a in ipairs(d.fieldsOf("source",c.kind))do
if a.name==e[#e]and a.pickSpell then
c[a.pickSpell.field]=f
f=a.pickSpell.value
end
end
end

local a=c[e[#e]]~=f and a.fieldAt("element",g,e)
for b,a in ipairs(a and a.resets or{})do c[a]=nil end
c[e[#e]]=b.copy(f)


local b=h and b.Sources.get(c.kind)
if b and b.shownSpell then
for d,a in ipairs(d.fieldsOf("source",c.kind))do
if a.type=="spell"and a.under and a.under[1]==e[#e]and a.under[2]==f and c[a.name]==nil
then
c[a.name]=b.shownSpell(c)
end
end
end
end
end
a.writer=i


local function p(a)return a==nil or(type(a)=="table"and a.preset~=nil)end

function a.ownStyle(a)return not p(a)end



local function q(f,b,e)
local g,c={},1
while c<=#e do
local h,a,d=d.frame(f,type(b)=="table"and b or{},g)
local a
for d,b in ipairs(h)do
if b.name==e[c]then a=b end
end
if not a then return nil end
if c==#e then return a,d end
b=type(b)=="table"and b[a.name]or nil
if a.type=="list"and a.record or a.type=="map"then
c=c+1
b=type(b)=="table"and b[e[c]]or nil
end
if not a.record then return nil end
f,g,c=a.record,d,c+1
end
end
a.fieldAt=q




local function s(f,c,d)
local e=a.read(c,d)
local a,c=q(f,c,d)
if a and a.style then return l.asOwn(a.style,e,c)end
return b.copy(e or{})
end





function a.set(b,e,f,d)
local e=i(e,f)
if d and p(a.own(b,d))then
local f=s("element",a.view(b),d)
return c.editElement(b,function(a)
i(d,f)(a)
e(a)
end)
end
return c.editElement(b,e)
end





local function n(f,g,h,c)
local d,e={},{}
local function a(a)
local b=b.Styles.spec(a)
if e[a]or not b or l.isLook(a)~=c then return end
e[a]=true
local b={key=(c and"look:"or"style:")..a,part=a,title=b.title or b.label,
help=b.help,rows={}}
k(b.rows,l.recordOf(a),f[a],{ownStyle=false},{a},0,nil,
not c and{path={a},part=a}or nil)
d[#d+1]=b
end
for c,b in ipairs(g or{})do a(b)end
for c,b in ipairs(h)do a(b)end
return d
end
function a.styleSections(a,b)
return n(a,b,d.STYLE_PARTS,false)
end

function a.buttonCueParts()
local a={}
for c,b in ipairs(d.get("buttonCues").fields)do a[#a+1]=b.name end
return a
end

function a.lookSections(b)
local a=a.buttonCueParts()
return n(b,a,a,true)
end

function a.styles()
return h.styles(c.profile()or{})
end

function a.globalStyle(b)
local a=c.profile()
return a and a.styles and a.styles[b]
end

function a.setStyle(a,b)
return c.editStyles(i(a,b))
end

function a.resetStyle(a)
return c.editStyles(function(b)b[a]=nil end)
end

function a.buttonCues()
return h.buttonCues(c.profile()or{})
end
function a.globalFactLook(b)
local a=c.profile()
return a and a.buttonCues and a.buttonCues[b]
end
function a.setFactLook(a,b)
return c.editFactLooks(i(a,b))
end
function a.resetFactLook(a)
return c.editFactLooks(function(b)b[a]=nil end)
end







local n,o=nil,{}
b.onChanged(function()
n=nil
wipe(o)
end,"form style users")
local function r()
if n then return n end
local e=c.profile()or{}
local a,b={},{}
local function f(b)
if not a[b]then a[b]={own={},following={},presets={},units={}}end
return a[b]
end
local function c(a,c)
b[a]=b[a]or{}
if b[a][c]then return end
b[a][c]=true
a[#a+1]=c
end
d.eachProfileStyleField(e,function(a,e,b,g,d)
local a=f(a.style)
local b=d.kind..":"..tostring(d.key)
a.units[b]=d
if e.preset==nil then return c(a.own,b)end
local d=e.preset
a.presets[d]=a.presets[d]or{}
c(a.presets[d],b)
c(a.following,b)
end)
n=a
return a
end
local t={own={},following={},presets={},units={}}
local function n(a)return r()[a]or t end


local function t(e,b)
if b.kind=="special"then
local a=d.field("specials",b.key)
return a and a.label or tostring(b.key)
end
local c=c.element(b.key)
return c and a.nameOf(h.element(c,e))or tostring(b.key)
end

local function r(d,a,e)
local f=c.profile()or{}
local b={}
for c=1,math.min(#a,e or#a)do
local a=a[c]
if not o[a]then o[a]=t(f,d.units[a])end
b[c]=o[a]
end
return b,#a
end

function a.styleOwners(a,b)
local a=n(a)
return r(a,a.own,b)
end

function a.presetFollowers(a,b)
local a=n(a)
return r(a,a.following,b)
end
function a.presetUsers(a,b,c)
local a=n(a)
return r(a,a.presets[b]or{},c)
end




function a.presetStyle(a,b)
local b=c.preset(a,b)
return b and h.record("style:"..a,b.style)or nil
end
function a.setPresetStyle(a,b,d,e)
return c.editPreset(a,b,function(b)i(d,e)({[a]=b})end)
end




function a.stylePick(d,b,a)
local a={{"follow",a}}
for c,b in ipairs(c.presets(d))do a[#a+1]={"preset:"..b.id,b.name}end
a[#a+1]={"own","Own"}
local c="follow"
if type(b)=="table"and b.preset~=nil then c="preset:"..b.preset
elseif b~=nil then c="own"end
return{choices=a,picked=c}
end



function a.pickValue(b,a,c,d)
if a=="follow"then return nil end
local a=a:match("^preset:(.+)$")
if a then return{preset=a}end
return l.asOwn(b,c,d or{})
end


function a.saveAsPreset(a,d,b,e,f)
return c.saveAsPreset(d,e,f,a,function(c,d)
if a.kind=="element"then i(b,{preset=d})(c)else m(c,b,{preset=d})end
end)
end

function a.styleParent()
return"Global"
end



function a.styleLimits(b,c,e,d)
local a={}
local b=l.spec(b)
if not(b and c)then return a end
for f,b in ipairs(b.limits or{})do
if(d==nil or b.setting==d)and b.cant(c,e or{})then a[#a+1]=b.text end
end
return a
end

function a.limited(a,b)
local a=l.spec(a)
for c,a in ipairs(a and a.limits or{})do
if a.setting==b then return true end
end
return false
end


function a.styleVars(d,b)
if not d then return{}end
for c=#b,1,-1 do
if b[c-1]=="layers"and type(b[c])=="number"then
return{layer=a.read(d,g(b,#b-c))}
end
if b[c-1]=="effects"and type(b[c])=="number"then
local a,b=a.popMoves(d,a.read(d,g(b,#b-c)))
return{motion=not a and(b or"none")or nil}
end
end
return{}
end









function a.recordSections(c,e,h)
h=h or{}
e=e or{}
local f,g={},{}
local i=d.frame(c,e,{})
local j={}
for b,a in ipairs(i)do j[a.name]=a end
local function l(b)
local a=b
while a do
if a.field and a.field.section then return a.field.section end
a=a.parent
end
local a=j[b.path[1]]
return a and a.section
end
local j={}
k(j,c,e,{},{},0)
for a,c in ipairs(j)do
local b=l(c)
if b then
local a=g[b]
if not a then
a={key=b,rows={}}
g[b]=a
f[#f+1]=a
end
a.rows[#a.rows+1]=c
end
end
for c,b in ipairs(f)do b.rows=a.headingsLast(b.rows)end
for c,a in ipairs(i)do
if a.type=="record"and a.record=="ownStyles"then
local g
if a.parts then
g={}
for b,a in ipairs(a.parts)do g[a]=true end
end
for d,c in ipairs(d.STYLE_PARTS)do
local b=b.Styles.spec(c)
if b and(not g or g[c])then
local d={a.name,c}
local b={key="style:"..c,part=c,
title=b.title or b.label,help=b.help,section=h.styleSection or a.section or"style",
style={path=d,part=c},rows={}}
k(b.rows,"style:"..c,e[a.name]and e[a.name][c],{ownStyle=true},d,0,nil,
b.style)
f[#f+1]=b
end
end
end
end
return f
end


function a.specialView(a)
return h.special(a,c.special(a),c.profile())
end




function a.setSpecial(b,f,g,e)
if e and p(a.read(c.special(b),e))then
local d=s(d.field("specials",b).record,a.specialView(b),e)
return c.editSpecial(b,function(a)
m(a,e,d)
m(a,f,g)
end)
end
return c.editSpecial(b,function(a)m(a,f,g)end)
end


function a.groupValue(b,d)
local a=c.profile()
local b=h.groupOf(a or{},b)
return b and h.group(b,a)[d]
end



function a.premadeOf(a)
local a=c.element(a)
local a=a and a.origin
return a and a.kind=="premade"and b.Blueprints.premade(a.id)~=nil or false
end


local g={}
b.onChanged(function(a)if a~="ui"then wipe(g)end end,"form premade parts")
function a.premadeHas(d,e)
if e==nil or not a.premadeOf(d)then return false end
local a=g[d]
if not a then
a={}
g[d]=a
end
local f=a[e]
if f==nil then
f=b.Blueprints.originPart(c.element(d),e)~=nil
a[e]=f
end
return f
end
function a.resetToPremade(e,f)
local d=c.element(e)
if not(d and a.premadeOf(e))then return false end
if not f then
local b=b.Blueprints.resetElement(d)
return b~=nil and c.editElement(e,function(a)
for b in pairs(a)do a[b]=nil end
for b,c in pairs(b)do a[b]=c end
end)
end
local g=b.Blueprints.originPart(d,f)
local f,a=a.partAt(d,f)
if not(g and a)then return false end


local f={}
local b=a[1]=="sources"and#a==2 and b.Blueprints.resetElement(d)
for a,b in ipairs(b and b.sources or{})do f[b.id]=a end
return c.editElement(e,function(c)
m(c,a,g)
if not b then return end

local b,a={},{}
for d,c in ipairs(c.sources)do
if f[c.id]then b[#b+1],a[#a+1]=d,c end
end
table.sort(a,function(a,b)return f[a.id]<f[b.id]end)
for b,d in ipairs(b)do c.sources[d]=a[b]end
end)
end




local function g(b,c,d)
local a=a.read(b,c)
if type(a)~="table"then return nil end
for c,b in ipairs(e.partsOf(a.kind))do
if b.key==d and b.list then return a,b end
end
end

local function k(e,d,b)
local c={}
for b,e in ipairs(e)do c[a.partTitle(e,b,d)]=true end
b=b or d
if not c[b]then return b end
local a=2
while c[b.." "..a]do a=a+1 end
return b.." "..a
end


local function h(b,c)
for d,b in ipairs(b)do
if b.name==nil then b.name=a.partTitle(b,d,c)end
end
end

function a.freeId(b,c)
local a={}
for b in pairs(d.keyIndex(b).ids)do a[b]=true end
return d.partId(c,a)
end


function a.canAddPart(b,d,c)
local a=a.read(b,d)
if type(a)~="table"then return false end
local b=q("element",b,f(d,c))
if not b then return false end
if b.partUnder then
local a,b=b.partUnder[2],a[b.partUnder[1]]
if not(b==a or(type(a)=="table"and e.inList(a,b)))then return false end
end
for d,b in ipairs(e.partsOf(a.kind))do
if b.key==c and b.list then return#(a[c]or{})<(b.max or 16)end
end
return false
end
function a.addPart(b,j,d)
local f
local a,b=c.editElement(b,function(i)
local c,g=g(i,j,d)
if not c then return end
local b=type(c[d])=="table"and c[d]or{}
c[d]=b
local c=e.partLabel(g.kind)
h(b,c)
f=a.freeId(i,g.kind)
b[#b+1]={id=f,name=k(b,c)}
end)
return a,b,f
end
function a.removePart(b,f,a,i)
return c.editElement(b,function(c)
local b,g=g(c,f,a)
local f=b and type(b[a])=="table"and b[a][i]
if not f then return end
h(b[a],e.partLabel(g.kind))

if f.id then d.removeId(c,f.id)end
local c=b[a]
if type(c)~="table"then return end
for a=#c,1,-1 do
if c[a]==f then table.remove(c,a)end
end
if#c==0 then b[a]=nil end
end)
end
function a.duplicatePart(f,j,d,i)
local l
local a,b=c.editElement(f,function(m)
local c,j=g(m,j,d)
local f=c and type(c[d])=="table"and c[d][i]
if not f or#c[d]>=(j.max or 16)then return end
local g=b.copy(f)
local e=e.partLabel(j.kind)
h(c[d],e)
g.id=a.freeId(m,j.kind)
l=g.id

local a=(a.partTitle(f,i,e):gsub(" %d+$",""))
g.name=k(c[d],e,a)
table.insert(c[d],i+1,g)

for c,a in ipairs(type(c.looks)=="table"and c.looks or{})do
if type(a[d])=="table"and a[d][f.id]then a[d][g.id]=b.copy(a[d][f.id])end
end
end)
return a,b,l
end
function a.renamePart(d,e,a,f,b)
return c.editElement(d,function(c)
local c=g(c,e,a)
local a=c and type(c[a])=="table"and c[a][f]
if a then a.name=(b~=nil and b~="")and b or nil end
end)
end




local d={}
b.onChanged(function(a)if a~="ui"then wipe(d)end end,"form offers")


local function e(a)
if type(a)~="table"then return type(a)..":"..tostring(a)end
local b={}
for a in pairs(a)do b[#b+1]=tostring(a)end
table.sort(b)
local c={}
for d,b in ipairs(b)do
local a=a[b]~=nil and a[b]or a[tonumber(b)]
c[d]=b.."="..e(a)
end
return"{"..table.concat(c,",").."}"
end

function a.accepts(b,f,g)
local e=tostring(b).."|"..j(f).."|"..e(g)
local a=d[e]
if a==nil then
a=c.wouldEditElement(b,i(f,g))
d[e]=a
end
return a
end



function a.offers(c,d,b,e)
if b==a.NONE then b=nil end
if b==e then return true end
return a.accepts(c,d.path,b)
end



function a.offersInList(d,e,c,f)
local b={}
for d,a in ipairs(f or{})do
if a==c then return true end
b[#b+1]=a
end
b[#b+1]=c
return a.accepts(d,e.path,b)
end
