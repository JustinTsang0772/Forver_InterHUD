























































































local a,g=...
local a=g.Kit
local c=g.Events

local b={}
b.__index=b
a.Page=b

local k,s=10,6
local y=4
local t=8
local z=24



local A,f,n=12,4,8
local i,B=40,10
local j,l=a.LINK_H,14


local o,q=30,10
local C=7
local d,m,h=16,6,64
a.PAGE_STEP=h

local e={}
a.pages=e




a.clock=debugprofilestop
a.speed={}
function a.timed(d,c)
local b=a.speed[d]
if not b then
b={n=0,max=0,sum=0,first=c}
a.speed[d]=b
end
b.n,b.last,b.sum,b.max=b.n+1,c,b.sum+c,math.max(b.max,c)
end



function a.newPage(f,j)
local c=CreateFrame("ScrollFrame",nil,f)
c:SetPoint("TOPLEFT",f,"TOPLEFT",0,0)
c:SetPoint("BOTTOMRIGHT",f,"BOTTOMRIGHT",-d,0)


local g=CreateFrame("Frame",nil,c)
local d=a.WIDTH-a.LIST_W-64
g:SetSize(d,1)
local i=CreateFrame("Frame",nil,g)
i:SetPoint("TOPLEFT")
i:SetSize(d,1)
c:SetScrollChild(g)
local d=setmetatable({area=f,key=j,scroll=c,holder=g,content=i,
contentW=d,lines={},items={},blocks={},subs={},
site="options page "..tostring(j)},b)
c:SetScript("OnSizeChanged",function(e,a)
if not b.resizing then d:fitWidth(a)end
c:UpdateScrollChildRect()
d:keepScroll()
if not b.resizing and d:isShown()then d:refresh()end
end)
g:SetScript("OnSizeChanged",function()c:UpdateScrollChildRect()end)


local a=a.scrollBar(f,{
step=h,
active=function()return c:IsShown()end,
offset=function()return c:GetVerticalScroll()end,
range=function()return d:range()end,
view=function()return c:GetHeight()end,
scrollTo=function(a)d:scrollBy(a-c:GetVerticalScroll())end,
})
a:SetPoint("TOPLEFT",c,"TOPRIGHT",m,0)
a:SetPoint("BOTTOMLEFT",c,"BOTTOMRIGHT",m,0)
d.bar=a
c:SetScript("OnScrollRangeChanged",function()
if d.hold then d:keepScroll()end
a:paint()
end)
c:SetScript("OnVerticalScroll",function()
a:paint()
d:stickSide()
end)
c:EnableMouseWheel(true)
c:SetScript("OnMouseWheel",function(b,a)d:scrollBy(-a*h)end)
c:Hide()
e[#e+1]=d
return d
end


function b:range()
return math.max(0,(self.contentH or 0)-self.scroll:GetHeight())
end




function b:fitGutter()
local a=(self.inset or 0)>0 and self:range()>0 and d or 0
if a==self.lane then return end
self.lane=a
local c=self.inset or 0
self.scroll:SetPoint("BOTTOMRIGHT",self.area,"BOTTOMRIGHT",-a-c,c)

local d=self.area:GetWidth()
if d>0 and not b.resizing then self:fitWidth(d-a-2*c)end
end


function b:scrollBy(b)
local a=self.scroll
self.hold=nil
a:SetVerticalScroll(math.max(0,math.min(a:GetVerticalScroll()+b,self:range())))
end

function b:show()

if self.onShow then g.try(self.site.." shown",self.onShow,self)end
self.scroll:Show()

local a=self.scroll:GetWidth()
if a>0 and not b.resizing then self:fitWidth(a)end
if self.fixed then self.fixed.frame:Show()end
if self.tabCard then self.tabCard:Show()end
self.bar:paint()
end
function b:hide()
self.scroll:Hide()
self.bar:Hide()
if self.fixed then self.fixed.frame:Hide()end
if self.tabCard then self.tabCard:Hide()end
end
function b:isShown()return self.scroll:IsShown()end


function b:setTarget(a)
if a~=self.target then


for b,a in ipairs(self.items)do
local a=a.frame.box
if a and a:GetObjectType()=="EditBox"and a:HasFocus()then
local b=a:GetScript("OnEscapePressed")
if b then b(a)else a:ClearFocus()end
end
end
self.target=a
self.hold,self.jump=nil,nil
self.scroll:SetVerticalScroll(0)
end
self:refresh()
end




local d

function b.startResize(a)
if not a then return end
b.resizing,d=true,a
a.hold=a:holdHere()
end


local function h(a,b,d)
c.atFrameEnd("kit "..b.." "..a.key,function()
d(false)
c.atFrameEnd("kit "..b.."2 "..a.key,function()d(true)end)
end)
end

function b.endResize()
local a=d
b.resizing,d=nil,nil
if not a then return end
for b,a in ipairs(e)do a:fitWidth(a.scroll:GetWidth())end
if a:isShown()then a:refresh()end
a:keepScroll()
local b=a.hold
h(a,"resize",function(c)
a:keepScroll()
if c and a.hold==b then a.hold=nil end
end)
end


function b:holdHere(a)
local b=self.scroll:GetVerticalScroll()+(a or 0)
local c={offset=b}
for d,a in ipairs(self.items)do
if a.visible and a.y and a.y+a.h>b then
c.row,c.dy=a,b-a.y
break
end
end
return c
end


function b:keepHeld(a)
if self.jump then return end
self.hold=a
h(self,"hold",function(b)
self:keepScroll()
if b and self.hold==a then self.hold=nil end
end)
end


function b:keepScroll()
local a,d=self.hold,self.scroll
if not a or a.busy then return end
local e=d:GetVerticalScrollRange()
if e<=0 then return end
local b,c=a.offset,a.row
if c and c.visible and c.y then b=c.y+a.dy end
b=math.max(0,math.min(b,e))
if math.abs(d:GetVerticalScroll()-b)>0.5 then
a.busy=true
d:SetVerticalScroll(b)
a.busy=false
end
end



function b:add(c,b,d,e)
local a=self.curBlock
local b={frame=c,height=b,shown=d,refresh=e,block=a,sub=self.subRun}
self.items[#self.items+1]=b
if a then a.items[#a.items+1]=b end
local a=self.subRun
while a do
a.items[#a.items+1]=b
a=a.outer
end
return c
end

function b:row(b)return a.row(self.content,b)end


local function d()return false end
function b:lazy(b,c)
self:endBlock()
local a=CreateFrame("Frame",nil,self.content)
a:Hide()
self:add(a,0,d)
self.lazies=self.lazies or{}
self.lazies[#self.lazies+1]={item=self.items[#self.items],when=b,build=c}
end



function b:expand()
local b=self.lazies
if not b then return end
local c=false
for d,b in ipairs(b)do
local d,e=g.try(self.site.." lazy",b.when)
if not b.built and d and e then
b.built,c=true,true
local e=a.clock()
local c=self.items
local d={self.curBlock,self.subRun}
self.items,self.curBlock,self.subRun={},nil,nil
g.try(self.site.." rows",b.build)
local f=self.items
self.items=c
self.curBlock,self.subRun=d[1],d[2]
for a,d in ipairs(c)do
if d==b.item then
for b,d in ipairs(f)do table.insert(c,a+b,d)end
break
end
end
a.timed("entry built",a.clock()-e)
end
end
if not c then return end
local a={}
for c,b in ipairs(self.items)do
if b.head then a[#a+1]=b.block end
end
self.blocks=a
end

local p=12
function b:side(a,c,d,e,b)
self:endBlock()

self.lastHolder=nil
a:SetParent(self.content)
self.items[#self.items+1]={frame=a,side=c,height=d,shown=e,
right=b and b.right or nil,ends=true}
return a
end


function b:sideMost()
local a=a.metric("pane","labelW")+a.metric("pane","fieldMin")+2*k+16
return math.max((self.scroll and self.scroll:GetWidth()or 0)-p-a,60)
end
function b:addRow(a,b)return self:add(a,a.height,b,a.refresh)end

for d,c in ipairs({"checkbox","switch","slider","textbox","dropdown","color","sound"})do
local d=a[c]
b[c]=function(a,b,c,e,f,g,h)
return a:addRow(d(a.content,b,c,e,f,h),g)
end
end
function b:linkList(b,c,d)
return self:addRow(a.linkList(self.content,b,c),d)
end
function b:buttons(b,c)return self:addRow(a.buttons(self.content,b),c)end
function b:text(b,c)return self:addRow(a.text(self.content,b),c)end
function b:callout(b,c,d)return self:addRow(a.callout(self.content,b,d),c)end
function b:note(b,c,d)return self:addRow(a.callout(self.content,b,d,"note"),c)end
function b:parchment(b,c)return self:addRow(a.parchment(self.content,b),c)end
function b:flourish(b)return self:addRow(a.flourish(self.content),b)end


function b:subhead(c,d,e)
local b=self.subRun
if b and b.underHead then
b=b.outer
self.subRun=b
end
local a=self:addRow(a.subhead(self.content,c,d,{dense=self.dense}),e)
if b and b.part then
local a={parent=self.items[#self.items],items={},depth=b.depth+1,outer=b,
underHead=true,loose=true}
self.subs[#self.subs+1]=a
self.subRun=a
end
return a
end

function b:endSubhead()
local a=self.subRun
if a and a.underHead then self.subRun=a.outer end
end
function b:hint(d,b,e)


local c=self.items[#self.items]
local c=b==nil and c and c.frame.check
if c then b=3+c:GetWidth()+6 end
return self:addRow(a.hint(self.content,d,b,{dense=self.dense}),e)
end


local d=13
function b:divider(e)
local c=self:row(d)
local b=c:CreateTexture(nil,"ARTWORK")
a.fill(b,"white")
b:SetGradient("HORIZONTAL",a.colorObj("rule",0.25),a.colorObj("rule",0))
self:line(b)
b:SetPoint("LEFT",4,0)
b:SetPoint("RIGHT",0,0)
return self:add(c,d,e)
end


local h=46
function b:section(d,e)
self:endBlock()
self.lastHolder=nil
local b=self:row(h)
b.text=a.fontString(b,"section")
b.text:SetPoint("BOTTOMLEFT",4,9)
local c=b:CreateTexture(nil,"ARTWORK")
a.fill(c,"rule",0.6)
self:line(c)
c:SetPoint("BOTTOMLEFT",0,3)
c:SetPoint("BOTTOMRIGHT",0,3)
self:add(b,h,e,function()b.text:SetText(type(d)=="function"and d()or d)end)
self.items[#self.items].ends=true
return b
end

function b:title(c,d)
local b=self:row(i)
b.text=a.fontString(b,"title")
b.text:SetPoint("BOTTOMLEFT",4,8)
b.text:SetShadowOffset(1,-1)
return self:add(b,i,d,function()b.text:SetText(type(c)=="function"and c()or c)end)
end



function b:sub(c,d,e)
local b
for a=#self.items,1,-1 do
if self.items[a].frame==c then
b=self.items[a]
break
end
end
if not b then error("Kit: page:sub's parent row is not on this page",2)end
local a=self.subRun
local b={parent=b,active=d,outer=a,items={},
depth=(a and a.depth or 0)+1}
if b.depth>f then error("Kit: page:sub nests "..f.." levels at most",2)end
self.subs[#self.subs+1]=b
self.subRun=b
e()
self.subRun=a
end



local d={}
d.__index=d
function d:setHidden(a)self.hidden=a and true or nil end
function d:foldKey()
local b=self.foldKeyFn and self.foldKeyFn()or(self.page.key..":"..self.key)
if#b>a.KEY_MAX then b=b:sub(1,a.KEY_MAX)end
return b
end
function d:isFolded()return self.card and a.isFolded(self:foldKey())or false end

function d:shutAbove()
local a=self.parent
return a~=nil and(a.folded or a.shut)or false
end

local h,i=9,2
local m=20

function b:block(c)
if not c.key then error("Kit: a block needs a key",2)end
for b,a in ipairs(self.blocks)do
if a.key==c.key then error("Kit: block key "..c.key.." used twice on page "..self.key,2)end
end
self.subRun=nil
local d=setmetatable({page=self,key=c.key,card=c.card and true or nil,
title=c.title,shownFn=c.shown,foldKeyFn=c.foldKey,joined=c.joined,
holds=c.holds,items={}},d)


if c.joined then
d.parent=self.lastHost
d.within=d.parent and d.parent.within
elseif c.inside then
d.parent,d.within=self.lastHolder,self.lastHolder
end
if not c.joined then
self.lastHost=d
if c.holds then self.lastHolder=d elseif not c.inside then self.lastHolder=nil end
end
self.blocks[#self.blocks+1]=d
self.curBlock=d
local e=a.theme.metric[self.dense and"pane"or"form"]
local f=c.title and(c.small and e.partHead or(c.level=="title"or c.holds)and e.bigHead or e.head)
or 0
local b=self:row(f)
b.baseH=f


local g=c.title and c.band~=false and not c.small and c.level~="title"and not c.holds
and(self.dense or self.settings)
d.band=g
if c.title then
b.font=c.font or(c.small and e.part)or(c.holds and e.section)
or(c.level=="title"and e.title)or e.heading
local e=(c.small or g)and 6 or 7

local f=d.card and 16 or 4
if d.card then
b.mark=a.foldMark(b,h,i)
b.mark:place(6,e+math.floor(a.theme.font[b.font].size/2+0.5))
b.summary=a.fontString(b,"dim")
b.summary:SetJustifyH("RIGHT")
b.summary:SetWordWrap(false)
b.summary:Hide()
end
b.text=a.fontString(b,b.font)

b.text:SetJustifyH("LEFT")
b.textX=f+(c.icon and 26 or 0)
b.text:SetPoint("BOTTOMLEFT",b.textX,e)
if c.icon then
b.icon=b:CreateTexture(nil,"ARTWORK")
b.icon:SetSize(20,20)
b.icon:SetPoint("BOTTOMLEFT",f,5)
a.cropIcon(b.icon)
end
if c.note then
b.note=a.fontString(b,"dim")
b.note:SetPoint("BOTTOMLEFT",b.text,"BOTTOMRIGHT",10,1)
end
if c.intro then b.introRows={}end
if c.badge then
b.badge=a.badge(b)
b.badge:SetPoint("LEFT",b.text,"RIGHT",10,0)
b.badge:Hide()
end
if c.draft then
b.draft=a.draftTag(b,c.draft)
b.draft:SetPoint("LEFT",b.text,"RIGHT",10,0)
end
if c.tags then
b.tagLead=a.fontString(b,"dim")
b.tagLead:Hide()
b.tagMarks={}
end

if c.menu then b.dots=a.dots(b,c.menu)end
if c.on then b.switch=a.pillSwitch(b,c.on.get,c.on.set,"On",nil,nil,true)end
if c.link then
b.link=a.textLink(b,"",c.link.click,true)
if c.link.leaves then b.link:leaves()end
a.setTip(b.link,"Reset",c.link.tip)
b.link:HookScript("OnLeave",function()b.link:rested()end)
end
if g then

b.band=b:CreateTexture(nil,"BACKGROUND")
a.fill(b.band,"cardHead")
b.band:SetPoint("TOPLEFT",-k+1,-1)
b.band:SetPoint("BOTTOMRIGHT",k-1,0)
else
local b=b:CreateTexture(nil,"ARTWORK")
a.fill(b,"white")
self:line(b)
b:SetGradient("HORIZONTAL",a.colorObj("rule",c.small and 0.25 or 0.45),a.colorObj("rule",0))
b:SetPoint("BOTTOMLEFT",0,3)
b:SetPoint("BOTTOMRIGHT",0,3)
end
if d.card then
b:EnableMouse(true)
b:SetScript("OnEnter",function()a.tint(b.text,"goldLight")end)
b:SetScript("OnLeave",function()a.tint(b.text,a.fontColor(b.font))end)
b:SetScript("OnMouseUp",function(b,a)
if a~="LeftButton"then return end
self:setFolded(d,not d:isFolded())
end)
end
b.spec=c
end
d.headFrame=b
self:add(b,f,nil,nil)
d.head=self.items[#self.items]
d.head.head=true
if c.nest and c.small and c.title then

local a={parent=d.head,items={},depth=1,part=true,loose=true}
self.subs[#self.subs+1]=a
self.subRun=a
end
return d
end

function b:endBlock()
self.curBlock,self.subRun=nil,nil
end

function b:setFolded(b,c)

if b.onFold then b.onFold(c)else a.setFolded(b:foldKey(),c)end
self:relaid()
end

function b:foldAll(c)
local b={}
for c,a in ipairs(self.blocks)do
if a.card and a.visible then b[#b+1]=a:foldKey()end
end
a.setFoldedAll(b,c)
self:relaid()

if c then self.scroll:SetVerticalScroll(0)end
end


function b:reveal(c)
for d,b in ipairs(self.items)do
if b.frame==c then
local b=b.block
while b do
if b:isFolded()then
if b.onFold then b.onFold(false)else a.setFolded(b:foldKey(),false)end
end
b=b.parent
end
return
end
end
end



local function r(a)
local a=a.headFrame and a.headFrame.spec
local a=a and a.summary
if type(a)=="function"then return a()or""end
return a or""
end



local u,v,h=6,16,14
local function i(b,d)
local c=b.name or b.value or""
if d then return c..(b.note and(" "..b.note)or"")end
if b.name then c=a.colorCode("headingText")..c.."|r"end
return c..(b.note and(" "..b.note)or"")
end
function b:paintIntro(c,b,f)
local d=0
for c,b in ipairs(b)do d=math.max(d,a.textWidth("dim",b.label or""))end
local g=c.textX+math.ceil(d)+12
local e=f
for f,d in ipairs(b)do
local b=c.introRows[f]
if not b then
b={label=a.fontString(c,"dim"),icon=c:CreateTexture(nil,"ARTWORK"),hit=CreateFrame("Button",nil,c)}
b.text=a.fontString(b.hit,"small")
b.text:SetJustifyH("LEFT")
b.text:SetWordWrap(true)
a.cropIcon(b.icon)
b.icon:SetSize(h,h)
b.hit:SetScript("OnEnter",function()
if not b.line.click then return end
b.text:SetText(i(b.line,true))
a.tint(b.text,"goldLight")
end)
b.hit:SetScript("OnLeave",function()
b.text:SetText(i(b.line))
a.tint(b.text,a.fontColor("small"))
end)
b.hit:SetScript("OnClick",function()if b.line.click then b.line.click()end end)
c.introRows[f]=b
end
b.line=d
b.label:SetText(d.label or"")
b.label:ClearAllPoints()
b.label:SetPoint("TOPLEFT",c,"TOPLEFT",c.textX,-(e+1))
local f=g
b.icon:SetShown(d.icon~=nil)
if d.icon then
b.icon:SetTexture(d.icon)
b.icon:ClearAllPoints()
b.icon:SetPoint("TOPLEFT",c,"TOPLEFT",f,-(e-1))
f=f+h+5
end
local g=math.max(self.rowW-f-8,40)
b.text:SetWidth(g)
b.text:SetText(i(d))
a.tint(b.text,a.fontColor("small"))
b.text:ClearAllPoints()
b.text:SetPoint("TOPLEFT",b.hit,"TOPLEFT",0,0)
local a=b.text:GetStringHeight()
b.hit:ClearAllPoints()
b.hit:SetPoint("TOPLEFT",c,"TOPLEFT",f,-e)
b.hit:SetSize(math.min(b.text:GetStringWidth(),g),a)
b.hit:EnableMouse(d.click~=nil)
b.label:Show()b.hit:Show()
e=e+math.max(v,a+4)
end
for a=#b+1,#c.introRows do
local a=c.introRows[a]
a.label:Hide()a.icon:Hide()a.hit:Hide()
end

return e-f+4
end



function b:renameHead(c)
for d,b in ipairs(self.blocks)do
local c=b.key==c and b.headFrame
if c and c.spec and c.spec.rename then
local b=c.renameBox
if not b then
b=a.editBox(c,200,24,c.font)
b:SetMaxLetters(c.spec.rename.max or 0)
local function a(d)
if not c.renaming then return end
c.renaming=nil
local a=b:GetText()
b:ClearFocus()
b:Hide()
if d and a~=b.started then c.spec.rename.set(a)end
self:relaid()
end
b:SetScript("OnEnterPressed",function()a(true)end)
b:SetScript("OnEscapePressed",function()a(false)end)
b:SetScript("OnEditFocusLost",function()a(true)end)
c.renameBox=b
end
b.started=c.spec.rename.get()or""
b:SetText(b.started)
c.renaming=true
self:relaid()
b:Show()
b:SetFocus()
b:HighlightText()
return true
end
end
return false
end

function b:paintHeader(e)
local b=e.headFrame
local c=b.spec
if not c then return end
local i=type(c.title)=="function"and c.title()or c.title
if b.icon then b.icon:SetTexture(type(c.icon)=="function"and c.icon()or c.icon)end
if b.note then

b.note:SetWidth(0)
b.note:SetWordWrap(false)
b.note:SetText(type(c.note)=="function"and c.note()or c.note)
b.note:Show()
end
if b.badge then
local a=c.badge()
b.badge:SetShown(a~=nil)
if a then b.badge.say(a)end
end
if b.tagLead then

local c=c.tags()or{}
local d=(b.badge and b.badge:IsShown())and b.badge or b.text
b.tagLead:SetShown(c.lead~=nil)
b.tagLead:ClearAllPoints()
b.tagLead:SetPoint("LEFT",d,"RIGHT",10,0)
b.tagLead:SetText(c.lead or"")
local f=b.tagLead
for d,e in ipairs(c)do
local c=b.tagMarks[d]
if not c then
c=a.tag(b)
c:SetScript("OnEnter",function(b)if b.tip then a.note(b,b.tip)end end)
c:SetScript("OnLeave",function()a.note()end)
a.linkTag(c)
b.tagMarks[d]=c
end
c.say(e.text)
c.click,c.tip=e.click,e.tip
c:ClearAllPoints()
c:SetPoint("LEFT",f,"RIGHT",d==1 and 5 or 3,0)
c:Show()
f=c
end
for a=#c+1,#b.tagMarks do b.tagMarks[a]:Hide()end
end


local d,f=a.EDGE,c.small and 5 or 7

local g=b.introRows and c.intro()or nil
local function h(a,e)
a:ClearAllPoints()
local c=f+(a==b.switch and-2 or 0)
if g then
a:SetPoint("TOPRIGHT",b,"TOPRIGHT",-d,-(b.baseH-c-a:GetHeight()))
else
a:SetPoint("BOTTOMRIGHT",b,"BOTTOMRIGHT",-d,c)
end
d=d+a:GetWidth()+e
end
local f=false
if b.dots then
f=#c.menu()>0
b.dots:SetShown(f)
if f then h(b.dots,6)end
end
if b.switch and not f then d=d+m+6 end
if b.switch then
b.switch:show(c.on.get()and true or false)
h(b.switch,10)
end
if b.link then
local a=c.link
local c=a.shown==nil or a.shown()
b.link:SetShown(c and true or false)
if c then
b.link.say(type(a.text)=="function"and a.text()or a.text)

if a.enabled then b.link:setEnabled(a.enabled()and true or false)end
h(b.link,10)
end
end


local c=self.rowW-b.textX-d-8
if b.badge and b.badge:IsShown()then c=c-b.badge:GetWidth()-10 end
if b.tagLead and b.tagLead:IsShown()then c=c-b.tagLead:GetStringWidth()-10 end
for b,a in ipairs(b.tagMarks or{})do
if a:IsShown()then c=c-a:GetWidth()-3 end
end



local f
if b.note then
local a,d=a.textWidth(b.font,i)+4,b.note:GetStringWidth()
local a=c-a-10
if d<=a then
f=d
elseif a>=40 then
b.note:SetWidth(a)
f=a
else
b.note:Hide()
end
if f then c=c-f-10 end
end
local h,i,c=a.wrapText(b.text,i,math.max(c,80),true)
e.head.height=b.baseH+math.max(h-c,0)
if g then
b.text:ClearAllPoints()
b.text:SetPoint("TOPLEFT",b,"TOPLEFT",b.textX,-(b.baseH-7-c))
e.head.height=e.head.height+self:paintIntro(b,g,b.baseH-7-c+h+u)
end
b:SetHeight(e.head.height)
if b.renameBox then
b.text:SetAlpha(b.renaming and 0 or 1)
local e=b.renameBox
e:ClearAllPoints()
e:SetPoint("LEFT",b.text,"LEFT",-a.EDIT_INSET,0)
e:SetSize(math.max(self.rowW-b.textX-d+a.EDIT_INSET,80),c+8)
end
if not e.card then return end
local c=e.folded
b.mark:set(c)
b.summary:SetShown(c)
if c then

b.summary:ClearAllPoints()
b.summary:SetPoint("BOTTOMRIGHT",-d,9)
b.summary:SetText(r(e))
local c=b.textX+b.text:GetStringWidth()+(f and 10+f or 0)
b.summary:SetWidth(math.max(self.rowW-c-d-24+a.EDGE,1))
end
end



function b:pixels(b)return a.windowScale()==1 and b or a.linePx(self.content,b)end
function b:pxLine(a,b)
if b then a:SetWidth(self:pixels(1))else a:SetHeight(self:pixels(1))end
end
function b:line(a,b)
self.lines[#self.lines+1]={a,b}
self:pxLine(a,b)
end

function a.repixelPages()
for b,a in ipairs(e)do
for c,b in ipairs(a.lines)do a:pxLine(b[1],b[2])end
if a:isShown()then a:refresh()end
end
end

local function d()c.atFrameEnd("kit rescaled",a.repixelPages)end
c.on("UI_SCALE_CHANGED","kit",d)
c.on("DISPLAY_SIZE_CHANGED","kit",d)

function b:fitWidth(a)
self.holder:SetWidth(a)
self.contentW=a
self.content:SetWidth(a)
end





function b:placeTopRow(e)
local b=self.topRow
local d=self.back
if not(e or d)then
if b then b:Hide()end
return 0
end
local c=self.tabCard~=nil
if b and b.tabbed~=c then b:Hide()b,self.topRow=nil,nil end
if not b then
b=CreateFrame("Frame",nil,c and self.fixed.frame or self.holder)
b.tabbed=c
b:SetFrameLevel((c and self.fixed.frame or self.content):GetFrameLevel()+10)
b:SetHeight(c and(self.tabH or o)or j)
b.collapse=a.textLink(b,"Collapse all",function()self:foldAll(true)end)
b.collapse:SetPoint(c and"BOTTOMRIGHT"or"RIGHT",b,c and"BOTTOMRIGHT"or"RIGHT",0,
c and 6 or 0)
b.expand=a.textLink(b,"Expand all",function()self:foldAll(false)end)
b.expand:SetPoint("RIGHT",b.collapse,"LEFT",-l,0)
if d then
b.back=a.textLink(b,d.text,d.click,true):leaves()
b.back.simLabel=d.text
end
self.topRow=b
end
b.expand:SetShown(e)
b.collapse:SetShown(e)
if b.back then
b.back:ClearAllPoints()
if not c then
b.back:SetPoint("LEFT",b,"LEFT",0,0)
elseif e then
b.back:SetPoint("RIGHT",b.expand,"LEFT",-l,0)
else
b.back:SetPoint("BOTTOMRIGHT",b,"BOTTOMRIGHT",0,6)
end
end
b:ClearAllPoints()
if c then
b:SetPoint("TOPRIGHT",self.head,"BOTTOMRIGHT",-q,-self.tabTop)
b:SetPoint("TOPLEFT",self.head,"BOTTOMLEFT",self.tabsW,-self.tabTop)
b:Show()
return 0
end
b:SetPoint("TOPLEFT",self.holder,"TOPLEFT",0,0)
b:SetPoint("TOPRIGHT",self.holder,"TOPRIGHT",0,0)
b:Show()
return j
end


function b:paintTopRow()
local a=self.topRow
if not(a and a:IsShown())then return end
local b,c=false,false
for d,a in ipairs(self.blocks)do
if a.card and a.visible then
if a.folded then b=true else c=true end
end
end
for b,a in ipairs({{a.expand,b},{a.collapse,c}})do
a[1]:SetEnabled(a[2])
a[1]:SetAlpha(a[2]and 1 or 0.45)
end
end



local function d(c,b,d,e)
if not b.panel then

b.panel=a.panel(c.content,b.holds and"windowBg"or nil,nil,nil,"card")
if b.holds then b.panel.fill:SetDrawLayer("BACKGROUND",-2)end
end
local a=c.content
b.panel:place(c:pixels(1),{a,"TOPLEFT",b.left or 0,-d},{a,"TOPRIGHT",-(b.right or 0),-e})
end




function b:refresh()
if self.painting then
c.atFrameEnd("kit repaint "..self.key,function()if self:isShown()then self:refresh()end end)
return
end
self.painting=true
g.try(self.site,self.paint,self)
self.painting=nil
end

function b:paint()

self.paints=(self.paints or 0)+1
if self.fixed and self.fixed.refresh then g.try(self.site.." pinned",self.fixed.refresh)end
self:expand()
local b=0
for c,a in ipairs(self.blocks)do
a.shut=a:shutAbove()
a.visible=not a.hidden and not a.shut and(not a.shownFn or a.shownFn())and true or false
a.folded=a.visible and a:isFolded()
a.drawn=false
if a.visible and a.card then b=b+1 end
end
local c=self:placeTopRow(b>=2 and not self.noFoldAll)
local u=a.theme.metric[self.dense and"pane"or"form"].gap
local v=self.contentW
local e,l=nil,false
local w

local x=false


local m,h,j=nil,nil,0

local n,o,q,r=0,0,0,nil
local function f()
if not e then return end
local a=e

c=math.max(c,a.low)+((a.folded and a.band)and 0 or s)
if a.joined and m then

if a.panel then a.panel:setShown(false)end
d(self,m,m.top,c)
else
d(self,a,a.top,c)
m=a
end
a.drawn=true
e,l=nil,true
end

local function i()
if not h then return end
f()
c=c+t
d(self,h,h.top,c)
h,j,l=nil,0,true
end
for d,b in ipairs(self.items)do
local d=b.block
if b.head or b.side or(e and d~=e)then f()end
if h and(b.ends or(b.head and d.visible and d.within~=h))then i()end
local f
if b.head then
f=d.visible
else
f=not d or(d.visible and not d.folded)


local a=((e and d==e)and k or 0)+j
self.shownW=v-n-o-2*a
f=f and(not b.shown or b.shown())and true or false
end
local i=b.sub
if f and i and not i.loose then
f=i.parent.visible and(not i.active or i.active())and true or false
end
b.visible=f
b.frame:SetShown(f)
if f and b.side then
if c>0 then c=c+u end


local a=type(b.side)=="function"and b.side()or b.side
a=math.min(a,self:sideMost())
if b.frame.refresh then g.try(self.site,b.frame.refresh,a)end
local d=type(b.height)=="function"and b.height()or b.height
b.frame:ClearAllPoints()
if b.right then
b.frame:SetPoint("TOPRIGHT",self.content,"TOPRIGHT",0,-c)
o=a+p
else
b.frame:SetPoint("TOPLEFT",self.content,"TOPLEFT",0,-c)
n=a+p
end
b.frame:SetSize(a,d)
b.x,b.y,b.h=0,c,d
q,l=math.max(q,c+d),false

r=true
elseif f then
if r then
r=nil
elseif b.head and d.joined and m then

c=c-s+B
elseif l or(b.head and c>0)then
c=c+u
end
l=false
if x and not b.head and d==e then c=c+y end
x=b.head and d.band and not d.folded or false
if b.head then
e=d
d.top,d.low=c,c
if d.holds and not d.folded then h=d end
j=(h and d.within==h)and t or 0
end

if b.frame.isHint and w then c=c-(b.frame.stack or C)end
w=b.frame.isHint
local k=(e and d==e and k or 0)+j
if b.head then d.left,d.right=n+j,o+j end

local h=i and i.depth*A or 0
local f=b.frame.rowLabel
if f then

if b.frame.labelTop then
f:ClearAllPoints()
f:SetPoint("TOPLEFT",4+h,b.frame.labelTop)
else
f:SetPoint("LEFT",4+h,0)
end
f:SetWidth(a.theme.metric[self.dense and"pane"or"form"].labelW-8-h)
end


local a=n+k+((f or(b.frame.isHint and not b.frame.fromEdge))and 0 or h)
local f=o+k
self.rowW=v-a-f

if b.refresh then g.try(self.site,b.refresh,self.rowW)end
if b.head then self:paintHeader(d)end
b.frame:ClearAllPoints()
b.frame:SetPoint("TOPLEFT",self.content,"TOPLEFT",a,-c)
b.frame:SetPoint("TOPRIGHT",self.content,"TOPRIGHT",-f,-c)
local f=type(b.height)=="function"and b.height()or b.height
b.x,b.y,b.h=a,c,f
if e and d==e then e.low=math.max(e.low,c+f)end
c=c+f
end
end
f()
i()
c=math.max(c,q)
for b,a in ipairs(self.blocks)do
if not a.drawn then
if a.panel then a.panel:setShown(false)end
end
end
self:paintTopRow()
for b,a in ipairs(self.subs)do self:placeRule(a)end
self.rowW,self.shownW=nil,nil

local a=math.max(c>0 and c+z or c,1)
self.contentH=a
self.content:SetHeight(a)
self.holder:SetHeight(a)
self:fitGutter()
self.scroll:UpdateScrollChildRect()
if self.hold then self:keepScroll()end
self.bar:paint()
self:stickSide()
end



function b:stickSide()
local b=self.scroll:GetVerticalScroll()
for c,a in ipairs(self.items)do
if a.side and a.visible and a.y then
local c=math.max((self.contentH or 0)-a.y-(a.h or 0),0)
local b=math.min(math.max(b-a.y,0),c)
a.frame:ClearAllPoints()
if a.right then a.frame:SetPoint("TOPRIGHT",self.content,"TOPRIGHT",0,-(a.y+b))
else a.frame:SetPoint("TOPLEFT",self.content,"TOPLEFT",0,-(a.y+b))end
end
end
end

function b:placeRule(b)
local c,d,e=b.parent,nil,nil
if c.visible then
for b,a in ipairs(b.items)do
if a.visible then
d=math.max(d or 0,a.y+a.h)
e=math.min(e or a.y,a.y)
end
end
end


local e,f=c.y and math.max(c.y+c.h,e or 0)-4,d and d-6
if not(d and f>e)then
if b.rule then b.rule:Hide()end
return
end
if not b.rule then
b.rule=self.content:CreateTexture(nil,"ARTWORK")
a.fill(b.rule,"rule",0.55)
end
self:pxLine(b.rule,true)
local a=c.x+n
b.rule:ClearAllPoints()
b.rule:SetPoint("TOPLEFT",self.content,"TOPLEFT",a,-e)
b.rule:SetPoint("BOTTOMLEFT",self.content,"TOPLEFT",a,-f)
b.rule:Show()
end


function b:relaid()
self:refresh()
local a=self.scroll
local b=a:GetVerticalScrollRange()
if a:GetVerticalScroll()>b then a:SetVerticalScroll(b)end
end



function b:anchor(a)
self.anchors=self.anchors or{}
self.anchors[a]=self.items[#self.items].frame
end


function b:scrollTo(b,c)
self:reveal(b)
self.hold=nil
self:refresh()
for d,a in ipairs(self.items)do
if a.frame==b and a.visible then
local b=self.scroll
b:SetVerticalScroll(math.max(0,math.min(a.y-8,self:range())))
if c then c()end
return true
end
end
return false
end



function b:bringIntoView(b,f)
self:reveal(b)
self.hold=nil
self:refresh()
for c,a in ipairs(self.items)do
if a.frame==b and a.visible then
local b=self.scroll
local e,c=b:GetVerticalScroll(),b:GetHeight()
local d=(type(a.height)=="function"and a.height()or a.height)or 0
local f=math.min(f or 0,c-d)
if a.y<e then
b:SetVerticalScroll(math.max(0,a.y-8))
elseif a.y+d+f>e+c then
b:SetVerticalScroll(math.max(0,math.min(a.y+d+f-c,self:range())))
end
return true
end
end
return false
end

function b:goTo(a)
local a=self.anchors and self.anchors[a]
if a then self:scrollTo(a,function()self:flash(a)end)end
end

function b:flash(d)
local b=d.flashAnim
if not b then
local c=d:CreateTexture(nil,"BACKGROUND")
c:SetPoint("TOPLEFT",-6,2)
c:SetPoint("BOTTOMRIGHT",6,-2)
a.fill(c,"accent",0.35)
c:SetAlpha(0)
b=c:CreateAnimationGroup()
local a=b:CreateAnimation("Alpha")
a:SetFromAlpha(0);a:SetToAlpha(1);a:SetDuration(0.35);a:SetOrder(1)
local a=b:CreateAnimation("Alpha")
a:SetFromAlpha(1);a:SetToAlpha(0);a:SetDuration(0.9);a:SetOrder(2)
b:SetLooping("NONE")
d.flashAnim=b
end
b:Stop()
b:Play()
end








local m,k,h=96,12,56

local e,g,n=12,28,30
local f,l=10,360
local o=10
local function d(a)if type(a)=="function"then return a()end return a end


local function i(b,c)
local b=CreateFrame("Button",nil,b)
b.ground=a.panel(b,"heroFill","heroEdge")
b.ground:cover(b,1)
b.title=a.fontString(b,"label")
b.title:SetPoint("TOPLEFT",f,-7)
a.tint(b.title,"gold")
b.line=a.fontString(b,"dim")
b.line:SetPoint("TOPLEFT",b.title,"BOTTOMLEFT",0,-3)
b:SetHeight(44)
b:SetScript("OnClick",c.click)

b:SetScript("OnEnter",function()
for c,b in ipairs(b.ground.edges)do a.fill(b,"gold")end
if c.tip then a.note(b,c.tip)end
end)
b:SetScript("OnLeave",function()
for c,b in ipairs(b.ground.edges)do a.fill(b,"heroEdge")end
a.note()
end)
return b
end



local function j(b,c,e)
local c,d=d(c.title)or"",d(c.line)or""
b.title:SetText(c)
b.line:SetText(d)

b:SetWidth(math.ceil(math.max(a.textWidth("label",c),a.textWidth("dim",d))+2*f))
local a=e-b:GetWidth()>=l
b:SetShown(a)
return a and b:GetWidth()+12 or 0
end

function b:header(c)
local l=CreateFrame("Frame",nil,self.area)
local b=CreateFrame("Frame",nil,l)
b:SetPoint("TOPLEFT")
b:SetPoint("TOPRIGHT")
local f=c.height or m
b:SetHeight(f)
local m=a.panel(b,"heroFill","heroEdge",nil,"header")
m:cover(b,1)
b.banner=b:CreateTexture(nil,"BACKGROUND",nil,1)
b.banner:SetTexture(a.art("banner"))
b.banner:SetPoint("TOPLEFT",1,-1)
b.banner:SetPoint("BOTTOMRIGHT",-1,1)
b.shade=b:CreateTexture(nil,"BACKGROUND",nil,2)
b.shade:SetPoint("TOPLEFT",1,-1)
b.shade:SetPoint("BOTTOMLEFT",1,1)
b.shade:SetWidth(420)
a.fill(b.shade,"white")
b.shade:SetGradient("HORIZONTAL",a.colorObj("heroShade"),a.colorObj("heroShade",0))
b.icon=b:CreateTexture(nil,"ARTWORK")
b.icon:SetSize(h,h)

b.icon:SetPoint("LEFT",a.cornerRoom("header",24),0)
a.cropIcon(b.icon)
b.iconEdge=b:CreateTexture(nil,"BORDER")
b.iconEdge:SetPoint("TOPLEFT",b.icon,-2,2)
b.iconEdge:SetPoint("BOTTOMRIGHT",b.icon,2,-2)
a.fill(b.iconEdge,"heroEdge")
b.title=a.fontString(b,"title")
if c.crest then

b.icon:SetTexture(a.art(c.crest))
b.icon:SetTexCoord(0,1,0,1)
b.icon:SetSize(f-8,f-8)
b.icon:ClearAllPoints()
b.icon:SetPoint("LEFT",12,0)
b.iconEdge:Hide()
for b,a in ipairs(m.ornaments or{})do a:SetShown(not a.corner:find("LEFT"))end
b.title:SetPoint("BOTTOMLEFT",b.icon,"RIGHT",10,2)
elseif c.plain then
b.icon:Hide()
b.iconEdge:Hide()
b.title:SetPoint("BOTTOMLEFT",b,"LEFT",a.cornerRoom("header",24)+6,2)
else
b.title:SetPoint("BOTTOMLEFT",b.icon,"RIGHT",14,2)
end
b.title:SetShadowOffset(1,-1)
b.note=b:CreateFontString(nil,"OVERLAY",a.font("label"))
b.note:SetPoint("TOPLEFT",b.title,"BOTTOMLEFT",0,-6)
b.note:SetShadowOffset(1,-1)

b.note:SetJustifyH("LEFT")
b.note:SetWordWrap(true)
b.note:SetMaxLines(2)
a.tint(b.note,"heroText")
local function m(c)b.banner:SetTexCoord(a.coverCoords(a.art("bannerCrop"),c-2,f-2))end

b:HookScript("OnSizeChanged",function(b,a)m(a)end)
self.headerCard=b

local h=self.headTag
if h then
b.tag=a.tag(b,14)
b.tag:SetPoint("LEFT",b.title,"RIGHT",10,0)
b.tag.say(h.word)
b.tag:SetScript("OnEnter",function(b)a.note(b,h.tip)end)
b.tag:SetScript("OnLeave",function()a.note()end)
end
if c.switch then
local c=c.switch
self.onSwitch=a.pillSwitch(b,c.get,c.set,c.title,c.tip,a.font("label"))
self.onSwitch:SetPoint("TOPRIGHT",b,"TOPRIGHT",-a.cornerRoom("header",e)-g,
-e+2)
end
local h=c.button
if h then
b.button=i(b,h)
b.button:SetPoint("TOPRIGHT",b,"TOPRIGHT",-a.cornerRoom("header",e),
-e-(c.switch and n or 0))
end
self.head,self.headH,self.tabTop=b,f,o
return self:pin(l,f+k,function()
b.title:SetText(d(c.title)or"")
local f=h and j(b.button,h,b:GetWidth())or 0

local e=b.note:GetLeft()and b:GetLeft()and(b.note:GetLeft()-b:GetLeft())or 0
local a=a.cornerRoom("header",24)+(self.onSwitch and g or 0)+f
+(self.headerRoom and self.headerRoom()or 0)
if b:GetWidth()>0 and e>0 then b.note:SetWidth(math.max(b:GetWidth()-e-a,100))end
b.note:SetText(d(c.note)or"")
if not(c.plain or c.crest)then b.icon:SetTexture(d(c.icon))end
if self.onSwitch then self.onSwitch:show(c.switch.get()and true or false)end
m(b:GetWidth())
end)
end







local f,h=64,6
a.PAGE_TITLE_H,a.PAGE_TITLE_GAP=f,h

local m,l,n,o,p=16,-14,-28,-8,2
function b:plainTitle(c)

local k=CreateFrame("Frame",nil,self.area)
local b=CreateFrame("Frame",nil,k)
b:SetPoint("TOPLEFT")
b:SetPoint("TOPRIGHT")
b:SetHeight(f)
b.title=a.fontString(b,"greeting")
b.title:SetPoint("TOPLEFT",m,l)
b.title:SetShadowOffset(1,-1)
b.title:SetJustifyH("LEFT")

b.title:SetWordWrap(false)
b.note=a.fontString(b,"label")
b.note:SetPoint("TOPLEFT",b.title,"BOTTOMLEFT",0,-4)
b.note:SetPoint("TOPRIGHT",b.title,"BOTTOMRIGHT",0,-4)
b.note:SetJustifyH("LEFT")
b.note:SetWordWrap(false)
a.tint(b.note,"help")
if c.switch then
local c=c.switch
self.onSwitch=a.pillSwitch(b,c.get,c.set,c.title,c.tip,a.font("label"))
end
local a=c.button
if a then
b.button=i(b,a)
b.button:SetPoint("TOPRIGHT",b,"TOPRIGHT",-e,o)
end
self.titleRow=b
self.head,self.headH,self.tabTop=b,f,p
local function i(a)if c.place then c.place(b,a)end end
if c.place then b:HookScript("OnSizeChanged",function(b,a)i(a)end)end
return self:pin(k,f+h,function()
local f=b:GetWidth()or 0
b.title:SetText(d(c.title)or"")
b.note:SetText(d(c.note)or"")

local a=e+(a and j(b.button,a,f)or 0)
if self.onSwitch then
self.onSwitch:ClearAllPoints()
self.onSwitch:SetPoint("RIGHT",b,"TOPRIGHT",-(a+g),n)
self.onSwitch:show(c.switch.get()and true or false)
a=a+g+self.onSwitch:GetWidth()+12
end
b.title:SetPoint("TOPRIGHT",b,"TOPRIGHT",-a,l)

i(f)
end)
end



function b:pin(a,b,c,d)
a:SetParent(self.area)
a:ClearAllPoints()
a:SetPoint("TOPLEFT",self.area,"TOPLEFT",0,0)

a:SetPoint("TOPRIGHT",self.area,"TOPRIGHT",0,0)
a:SetShown(self:isShown())
self.fixed={frame=a,refresh=c,gap=d or 0}
self:setPinHeight(b)
return a
end





local d,e,o=120,30,3

local j,h,f,p,q=300,62,8,4,190


local r,s=14,1
function b:tabs(b,l,t)
local g=self.fixed
if not(g and self.head)then error("Kit: page:tabs comes after page:header or page:plainTitle",2)end
local c=b[1]and b[1].line~=nil
local m,h,n=c and j or d,c and h or e,c and(j+f)or(d-1)
local d=CreateFrame("Frame",nil,g.frame)
d:SetPoint("TOPLEFT",self.head,"BOTTOMLEFT",0,-self.tabTop)
d:SetSize(#b*n-(c and f or-1),h)

local e=CreateFrame("Frame",nil,self.area)
e:SetPoint("TOPLEFT",d,"BOTTOMLEFT",0,1)
e:SetPoint("BOTTOMRIGHT",self.area,"BOTTOMRIGHT",0,0)
e:SetShown(self:isShown())
e.ground=a.panel(e,"tabCard","tabCardEdge")
e.ground:cover(e,1)
self.tabCard=e
self.tabsW=d:GetWidth()
self.tabH=h
local i={}
for e,b in ipairs(b)do
local a=c and a.bigTab(d,{icon=b.icon,title=b.label,line=b.line})or a.tab(d)

a:SetPoint("BOTTOMLEFT",(e-1)*n,0)
a:SetWidth(m)
if c then a.wrap(m)else a.text:SetText(b.label)end
a.key=b.key
a:SetScript("OnClick",function()
if l()==b.key then return end
t(b.key)
self:scrollBy(-self.scroll:GetVerticalScroll())
self:refresh()
end)
i[b.key]=a
end
self.inset=r
self.lane=nil
local m=g.refresh
self:pin(g.frame,self.headH+self.tabTop+h+s+k,function()
m()
local e=l()
local g=d:GetFrameLevel()
if c then

local a=0
for c,b in ipairs(self.blocks)do if b.card then a=a+1 end end
local a=a>=2 and not self.noFoldAll
local a=(self.head:GetWidth()or 0)-(a and q or 0)
local a=math.max(math.min(j,(a-(#b-1)*f)/#b),120)
for c,b in ipairs(b)do
local b=i[b.key]
b:ClearAllPoints()
b:SetPoint("BOTTOMLEFT",(c-1)*(a+f),0)
b:SetWidth(a)
b.wrap(a)
end
d:SetWidth(#b*a+(#b-1)*f)
self.tabsW=d:GetWidth()
end
for d,b in pairs(i)do
local d=d==e
if c then b:paint(d)else a.paintTab(b,d)end
b:SetHeight(d and h or h-(c and p or o))

b:SetFrameLevel(g+(d and 2 or 1))
end
end,g.gap)

e:SetFrameLevel(math.max(0,self.scroll:GetFrameLevel()-1))
return i
end



function b:setPinHeight(a)
local b=self.fixed
local c=b.height
b.height=a
b.frame:SetHeight(a)

if c and c~=a and self.scroll:GetVerticalScroll()>0 then self:keepHeld(self:holdHere(a-c))end
self.scroll:SetPoint("TOPLEFT",self.area,"TOPLEFT",self.inset or 0,-(a+b.gap))
end
