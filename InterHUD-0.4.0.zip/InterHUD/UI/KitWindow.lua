


























local a,d=...
local b=d.Kit
local g=d.Events
local v=d.Store

local t,f=b.WIDTH,b.LIST_W
local H,m,I,J=b.DEFAULT_H,640,1300,1600


local c,K,i=112,-19,24
local o,j,k=34,4,24


local n,p=i,j+o
local w,q,x=-38,12,i-c+3

local y,L=10,18
local M,N,z,A=40,8,18,8


local r,e,O=22,2,8

local P,B,C,Q=140,0.7,10,6
local R=8
b.WINDOW_NAME="InterHUDOptions"

local h,l={},{}
function b.registerPage(a,b)
if h[a]then error("Kit: page registered twice: "..tostring(a),2)end
if type(b.build)~="function"then error("Kit: page "..tostring(a).." needs a build",2)end
h[a]=b
l[#l+1]=a
end

function b.hasPage(a)return h[a]~=nil end


local D,E={},{}
function b.setPageBack(a,b)D[a]=b end

function b.setPageTag(a,b)E[a]=b end

local a



local function F()
if not(a and a.frame:IsShown())then return end
local e=b.clock()
local c=a.current and a.pages[a.current]
if c then c:refresh()end
if a.onRepaint then d.try("options list",a.onRepaint)end
b.timed("repaint",b.clock()-e)
end
function b.repaint()
if not(a and a.frame:IsShown())then return end
g.atFrameEnd("kit repaint",F)
end
d.onChanged(b.repaint,"kit")





local function u(a,b,c,d)return math.max(math.min(a,c,d),b)end
local function s()return t+math.max((a and a.listW or f)-f,0)end

local function G()
return math.min(UIParent:GetWidth()/s(),UIParent:GetHeight()/(m+n+p))
end
local function f()return math.min(b.windowScale(),G())end
local function l(a)return u(a,s(),J,UIParent:GetWidth()/f())end
local function t(a)return u(a,m,I,UIParent:GetHeight()/f()-n-p)end

local function m()

local b=a.frame
local c,d=b:GetLeft(),b:GetTop()
if not(c and d)then return end
local b=b:GetScale()
v.editUI(function(e)
e.window={x=math.floor(c*b+0.5),y=math.floor(d*b+0.5),width=math.floor(a.w+0.5),
height=math.floor(a.h+0.5)}
end)
end



local function u(d,e)
local f,b=a.frame,f()
local c,g,h=O*b,UIParent:GetWidth(),UIParent:GetHeight()
local i,j=math.max(c,n*b),math.max(c,p*b)
d=math.max(math.min(math.max(math.min(d,g-a.w*b-c),c),g-a.w*b),0)
e=math.min(math.max(math.min(math.max(e,a.h*b+j),h-i),a.h*b),h)
f:ClearAllPoints()
f:SetPoint("TOPLEFT",UIParent,"BOTTOMLEFT",d/b,e/b)
end

local function n(b,c)
a.w,a.h=b,c
a.frame:SetSize(b,c)

a:scrollList(a.listOffset)
end

local function I()
local d=a.frame
local c=v.ui().window
if not(c and c.x and c.y)then c=nil end
d:SetScale(f())
a.scaled=f()


a.wantW,a.wantH=c and c.width or b.DEFAULT_W,c and c.height or H
n(l(a.wantW),t(a.wantH))
if c then
u(c.x,c.y)
else


local b=f()
u((UIParent:GetWidth()-a.w*b)/2,(UIParent:GetHeight()+a.h*b)/2)
end
end


local function p(a,b)return a:GetFrameLevel()+b end


local function H(d)
local c=CreateFrame("Button",nil,d)
c:SetSize(16,16)
c:EnableMouse(true)
c:SetPoint("BOTTOMRIGHT",-6,6)
c:SetFrameLevel(p(d,50))
local e=b.art("grip")
c:SetNormalTexture(e.."Up")
c:SetHighlightTexture(e.."Highlight")
c:SetPushedTexture(e.."Down")
local function e()
local e,f=GetCursorPosition()
local b=d:GetEffectiveScale()
a.wantW,a.wantH=c.startW+(e-c.startX)/b,c.startH+(c.startY-f)/b
n(l(a.wantW),t(a.wantH))
end
c:SetScript("OnMouseDown",function(c)
local f,g=d:GetLeft(),d:GetTop()
d:ClearAllPoints()
d:SetPoint("TOPLEFT",UIParent,"BOTTOMLEFT",f,g)
c.startX,c.startY=GetCursorPosition()
c.startW,c.startH=a.w,a.h
b.Page.startResize(a:page())
c:SetScript("OnUpdate",e)
end)
local function a()
c:SetScript("OnUpdate",nil)
b.Page.endResize()
m()
end
c:SetScript("OnMouseUp",a)

d:HookScript("OnHide",function()
if c:GetScript("OnUpdate")then a()end
end)
return c
end


local function J(d)
local a=CreateFrame("Frame",nil,d)
a:SetSize(c,c)
a:SetPoint("TOPLEFT",d,"TOPLEFT",K,i)
a:SetFrameLevel(b.overPreviews(d,2))
local c=b.art("logo")
a.shadow=a:CreateTexture(nil,"BACKGROUND")
a.shadow:SetTexture(c)
a.shadow:SetVertexColor(b.rgba("logoShadow"))
a.shadow:SetPoint("TOPLEFT",3,-4)
a.shadow:SetPoint("BOTTOMRIGHT",3,-4)
a.tex=a:CreateTexture(nil,"ARTWORK")
a.tex:SetTexture(c)
a.tex:SetAllPoints()
return a
end


local function i()return a.h+x-q-a.listTop-a.listBottom end



local function v(a,c,e,f)
local a=CreateFrame("Frame",nil,a)
a:SetPoint(c.."LEFT")
a:SetPoint(c.."RIGHT",-(N),0)
a:SetHeight(A+z)
local d=a:CreateTexture(nil,"OVERLAY")
d:SetPoint(c.."LEFT")
d:SetPoint(c.."RIGHT")
d:SetHeight(A)
b.fill(d,"shade")
local d=a:CreateTexture(nil,"OVERLAY")
local c=c=="TOP"and"BOTTOM"or"TOP"
d:SetPoint(c.."LEFT")
d:SetPoint(c.."RIGHT")
d:SetHeight(z)
b.fill(d,"white")
d:SetGradient("VERTICAL",b.colorObj("shade",e),b.colorObj("shade",f))
a:Hide()
return a
end


local function z(c)
local d=CreateFrame("Frame",nil,c)
d:SetPoint("TOPLEFT",c,"TOPLEFT",8,x)
d:SetPoint("BOTTOMLEFT",c,"BOTTOMLEFT",8,q)
d:SetWidth(a.listW-16)
local c=CreateFrame("ScrollFrame",nil,d)
local f=CreateFrame("Frame",nil,c)
f:SetSize(a.listW-16,1)
c:SetScrollChild(f)
c:EnableMouseWheel(true)
c:SetScript("OnMouseWheel",function(c,b)a:scrollList(a.listOffset-b*M,-b)end)
local e=CreateFrame("Frame",nil,c)
e:SetAllPoints()
e:SetFrameLevel(f:GetFrameLevel()+5)
local a=b.scrollBar(e,{
offset=function()return a.listOffset end,
range=function()return a:listRange()end,
view=i,
scrollTo=function(b)a:scrollList(b)end,
})
a:SetPoint("TOPRIGHT",-1,0)
a:SetPoint("BOTTOMRIGHT",-1,0)
a.above,a.below=v(e,"TOP",0,1),v(e,"BOTTOM",1,0)
return d,c,f,a
end




local function v(d)
local c=CreateFrame("Button",nil,d)
c:EnableMouse(true)
c:SetWidth(R)
c:SetPoint("TOP",a.listEdge,"TOP")
c:SetPoint("BOTTOM",a.listEdge,"BOTTOM")
c:SetFrameLevel(p(d,40))
c.line=c:CreateTexture(nil,"OVERLAY")
c.line:SetPoint("TOP")
c.line:SetPoint("BOTTOM")
b.fill(c.line,"fieldEdgeLit")
c.line:Hide()
c:SetScript("OnEnter",function()c.line:Show()end)
c:SetScript("OnLeave",function()if not c.dragging then c.line:Hide()end end)
local function g()

local e=b.clock()
if c.frameAt then b.timed("drag frame",e-c.frameAt)end
c.frameAt=e
local b=GetCursorPosition()
a:setListWidth(c.startW+(b-c.startX)/d:GetEffectiveScale())
end
c:SetScript("OnMouseDown",function(c,e)
if e~="LeftButton"then return end

local e,f=d:GetLeft(),d:GetTop()
if e and f then
d:ClearAllPoints()
d:SetPoint("TOPLEFT",UIParent,"BOTTOMLEFT",e,f)
end
c.dragging,c.frameAt=true,nil
c.startX,c.startW=GetCursorPosition(),a.listW
b.Page.startResize(a:page())
c:SetScript("OnUpdate",g)
end)
local function e()
c:SetScript("OnUpdate",nil)
c.dragging=nil
if not c:IsMouseOver()then c.line:Hide()end
b.Page.endResize()
b.setListWidth(a.listW)
m()
end
c:SetScript("OnMouseUp",function()if c.dragging then e()end end)
d:HookScript("OnHide",function()if c.dragging then e()end end)
return c
end


b.BETA=true
function b.versionWords()return d.version..(b.BETA and" beta"or"")end

local c={}
c.__index=c




function b.dragByTitle(b,e,c,d)
local a=CreateFrame("Frame",nil,b)
a:SetAllPoints(e)
a:SetFrameLevel(b:GetFrameLevel()+1)
c:SetFrameLevel(math.max(c:GetFrameLevel(),a:GetFrameLevel()+1))
a:EnableMouse(true)
a:RegisterForDrag("LeftButton")
a:SetScript("OnDragStart",function()b:StartMoving()end)
a:SetScript("OnDragStop",function()
b:StopMovingOrSizing()
if d then d()end
end)
b.titleGrab=a
return a
end




local function p()
local a=CreateFrame("Frame",b.WINDOW_NAME,UIParent,"ButtonFrameTemplate")


a:SetFrameStrata("DIALOG")
if ButtonFrameTemplate_HideButtonBar then pcall(ButtonFrameTemplate_HideButtonBar,a)end
if ButtonFrameTemplate_HidePortrait then pcall(ButtonFrameTemplate_HidePortrait,a)end
if a.Inset then a.Inset:Hide()end
local c=a:CreateTexture(nil,"BACKGROUND",nil,1)
c:SetPoint("TOPLEFT",e,-r)
c:SetPoint("BOTTOMRIGHT",-e,e)
b.fill(c,"windowBg")

a.titleBar=a:CreateTexture(nil,"BACKGROUND")
a.titleBar:SetPoint("TOPLEFT")
a.titleBar:SetPoint("TOPRIGHT")
a.titleBar:SetHeight(r)
a.over=CreateFrame("Frame",nil,a)
a.over:SetAllPoints()
a.over:SetFrameLevel(b.overPreviews(a,1))

if a.SetTitle then a:SetTitle("InterHUD")end
local c=a.TitleContainer and a.TitleContainer.TitleText or a.TitleText
if c then
local a,b,d=c:GetFont()
if a and b then c:SetFont(a,b+2,d)end
end
a.title=c
a.version=b.fontString(a.over,"dim")
a.version:SetText(b.versionWords())
a.version:SetAlpha(0.8)
if c then


a.version:SetPoint("LEFT",c,"CENTER",math.floor(c:GetStringWidth()/2+0.5)+8,-1)
else
a.version:SetPoint("TOP",a,"TOP",0,-5)
end
local c=a.CloseButton
c:SetFrameLevel(b.overPreviews(a,3))

c:SetScript("OnClick",function()a:Hide()end)
return a,c
end



local function x(d,c)
local e=d.over
local f=b.textLink(e,"Reset",function()
a.scaleBar:setValue(1)
a:setScale(1)
end,true)
f:SetPoint("RIGHT",c,"LEFT",-Q,0)


local c=b.sliderBar(e,function(b)a.pendingScale=b end,{steppers=false,mark=1})
c:SetScale(B)
c:setWidth(P)

c:SetPoint("RIGHT",f,"LEFT",-C/B,0)
local g,h,i=b.windowScaleRange()
c:setRange(g,h,i)
local function g()
local b=a.pendingScale
a.pendingScale=nil
if b then a:setScale(b)end
end
c.hit:HookScript("OnMouseUp",g)
c.hit:HookScript("OnHide",g)
local e=e:CreateFontString(nil,"OVERLAY",b.font("small"))
e:SetPoint("RIGHT",c,"LEFT",-C,0)
e:SetText("Menu scale:")
b.tint(e,"help")
local a=CreateFrame("Frame",nil,d)
a:SetHeight(o)
a:SetPoint("TOPLEFT",d,"BOTTOMLEFT",-k,-j)
a:SetPoint("TOPRIGHT",d,"BOTTOMRIGHT",k,-j)
a.panel=b.panel(a,"bandWarnFill","bandWarnEdge")
a.panel:cover(a,1)
a.text=a:CreateFontString(nil,"OVERLAY",b.font("band"))
a.text:SetPoint("LEFT",12,0)
a.text:SetPoint("RIGHT",-12,0)
a.text:SetJustifyH("CENTER")
a.text:SetWordWrap(false)
a:Hide()
return c,f,e,a
end

local function A()
local d,e=p()
a=setmetatable({frame=d,close=e,pages={},listOffset=0,listH=0,listTop=0,
listBottom=0,listW=b.listWidth()},c)
a.listBg=d:CreateTexture(nil,"BACKGROUND",nil,3)
a.listBg:SetWidth(a.listW)
b.fill(a.listBg,"listBg")
a.listEdge=d:CreateTexture(nil,"BACKGROUND",nil,4)
a.listEdge:SetPoint("TOPLEFT",a.listBg,"TOPRIGHT")
a.listEdge:SetPoint("BOTTOMLEFT",a.listBg,"BOTTOMRIGHT")
b.fill(a.listEdge,"panelEdge")
a.listColumn,a.list,a.listContent,a.listBar=z(d)
a:setListInsets(0,0)
a.logo=J(d)
a.pageArea=CreateFrame("Frame",nil,d)
a.pageArea:SetPoint("TOPLEFT",d,"TOPLEFT",a.listW+y,w)
a.pageArea:SetPoint("BOTTOMRIGHT",d,"BOTTOMRIGHT",-L,q)
a.scaleBar,a.scaleReset,a.scaleLabel,a.band=x(d,e)
a.grip=H(d)
a.listHandle=v(d)
d:SetToplevel(true)
d:SetClampedToScreen(true)

d:SetClampRectInsets(-k,k,0,-(j+o))
d:SetMovable(true)
d:EnableMouse(true)

d:EnableMouseWheel(true)
d:SetScript("OnMouseWheel",function()end)
b.dragByTitle(d,d.titleBar,e,m)
UISpecialFrames[#UISpecialFrames+1]=b.WINDOW_NAME
d:Hide()
I()
a:placePixels()
return a
end


function c:placePixels()
local a=self.frame
local c=b.linePx(a,1)
self.listBg:ClearAllPoints()
self.listBg:SetPoint("TOPLEFT",a,"TOPLEFT",e,-r)
self.listBg:SetPoint("BOTTOMLEFT",a,"BOTTOMLEFT",e,e)
self.listBg:SetWidth(self.listW-e)
self.listEdge:SetWidth(c)
self.listHandle.line:SetWidth(b.linePx(a,2))
self.scaleBar:repixel()
end




function c:setScale(a)
local c,e,d=b.windowScaleRange()
local c=c+math.floor((G()-c)/d)*d
a=math.min(a,c)
if not b.setWindowScale(a)then return false end
self:applyScale()
self.scaleBar:setValue(b.windowScale())
return true
end
function c:applyScale()
local c,a=self.frame,f()
local d=self.scaled or 1
if a==d then return end

local e,f=c:GetRight(),c:GetBottom()
c:SetScale(a)
self.scaled=a
n(l(self.wantW or self.w),t(self.wantH or self.h))
if e and f then u(e*d-self.w*a,f*d+self.h*a)end
self:placePixels()
b.repixelPages()
m()
end

function b.window()return a or A()end



local function e()
if a then
g.atFrameEnd("kit window rescaled",function()
a:applyScale()
a:placePixels()
end)
end
end
g.on("UI_SCALE_CHANGED","kit window",e)
g.on("DISPLAY_SIZE_CHANGED","kit window",e)


function c:pageOf(c)
local a=self.pages[c]
if a or not h[c]then return a end
local e=h[c]
local f=b.clock()
a=b.newPage(self.pageArea,c)
a.settings=e.settings
a.back=D[c]
a.headTag=E[c]
self.pages[c]=a
d.try("options page "..tostring(c).." build",e.build,a)
b.timed("page built",b.clock()-f)
return a
end

function c:showPage(b,d)
local a=self:pageOf(b)
if not a then error("Kit: no page "..tostring(b),2)end
local c=self.current and self.pages[self.current]
if c and c~=a then c:hide()end
self.current=b
a:show()
a:setTarget(d)
return a
end


function c:clearPage()
local a=self.current and self.pages[self.current]
if a then a:hide()end
self.current=nil
end

function c:page()
local a=self.current
return a and self.pages[a],a
end

function c:open(a,c)
self.scaleBar:setValue(b.windowScale())
self:applyScale()
self.frame:Show()
a=a or self.current
if a then

self:showPage(a,c or(self:page()and self:page().target))
if self.onRepaint then d.try("options list",self.onRepaint)end
else
F()
end
end
function c:hide()self.frame:Hide()end
function c:isShown()return self.frame:IsShown()end
function c:toggle()
if self:isShown()then self:hide()else self:open()end
end


function c:setBand(c,d)
local a=self.band
if a.said==c and a.tone==d then return end
a.said,a.tone=c,d
a:SetShown(c~=nil)
if c then
local d=d=="off"
b.fill(a.panel.fill,d and"bandOffFill"or"bandWarnFill")
for c=1,4 do b.fill(a.panel.edges[c],d and"bandOffEdge"or"bandWarnEdge")end
a.text:SetText(c)
end
end






function c:setListWidth(a)
local b,c=b.listWidthRange()
a=math.floor(math.min(math.max(a,b),c)+0.5)
if a==self.listW then return end
self.listW=a
local b=self.frame
self.listColumn:SetWidth(a-16)
self.listContent:SetWidth(a-16)
self.pageArea:SetPoint("TOPLEFT",b,"TOPLEFT",a+y,w)
if self.w<s()then n(l(self.w),self.h)end
self:placePixels()
end


function c:setListInsets(b,c)
self.listTop,self.listBottom=b,c
local a,d=self.list,self.listColumn
a:ClearAllPoints()
a:SetPoint("TOPLEFT",d,"TOPLEFT",0,-b)
a:SetPoint("BOTTOMRIGHT",d,"BOTTOMRIGHT",0,c)
if self.w then self:scrollList(self.listOffset)end
end




function c:setListRows(c,d,a,b)
self.rowTops,self.rowHeights,self.rowFrames,self.rowCount=c,d,a,b

for b=1,b do a[b].listWhole=nil end
end

local function d(a,c)
local b=a.rowTops
for a=1,a.rowCount do
if b[a]>=c-0.5 then return b[a]end
end
return b[a.rowCount]
end

local function f(a,d)
local b,c=a.rowTops,0
for a=1,a.rowCount do
if b[a]>d+0.5 then break end
c=b[a]
end
return c
end
local function e(a)return a.rowTops~=nil and(a.rowCount or 0)>0 end

function c:listRange()
local a=self.listH-i()
if a<=0 then return 0 end
return e(self)and d(self,a)or a
end
function c:setListHeight(a)
self.listH=a
self:scrollList(self.listOffset)
end

function c:scrollList(a,b)
local c,g=i(),self:listRange()
a=math.max(0,math.min(a,g))
if e(self)then
local c,e=f(self,a),d(self,a)
if b and b>0 then
a=e>self.listOffset+0.5 and e or d(self,self.listOffset+1)
elseif b and b<0 then
a=c<self.listOffset-0.5 and c or f(self,self.listOffset-1)
else
a=(a-c<=e-a)and c or e
end
a=math.max(0,math.min(a,g))
end

local b=math.max(self.listH,a+c,1)
if b~=self.listContentH then
self.listContentH=b
self.listContent:SetHeight(b)
end
self.listOffset=a
self.list:SetVerticalScroll(a)
self:paintList()
end

function c:revealList(a,b)
local c=i()
if a<self.listOffset then self:scrollList(a)
elseif a+b>self.listOffset+c then
local a=a+b-c
self:scrollList(e(self)and d(self,a)or a)
end
end
function c:paintList()
local a=self.listBar
if not a then return end
local b=self:listRange()
a:paint()
a.above:SetShown(self.listOffset>0.5)
a.below:SetShown(self.listOffset<b-0.5)

if not e(self)then return end
local c,d=self.listOffset-0.5,self.listOffset+i()+0.5
local b,e,f=self.rowTops,self.rowHeights,self.rowFrames
for a=1,self.rowCount do
local b=b[a]>=c and b[a]+e[a]<=d
local a=f[a]
if a.listWhole~=b then
a.listWhole=b
a:SetShown(b)
end
end
end



local a="INTERHUD_"
function b.confirm(b,c,d,e)
StaticPopupDialogs[a..b]={
text=c,button1=d,button2=CANCEL,
OnAccept=function(b,a)e(a)end,
timeout=0,whileDead=true,hideOnEscape=true,preferredIndex=3,
}
end
function b.showPopup(b,c,d)
return StaticPopup_Show(a..b,c,nil,d)
end

local c
local function d(e)
local b=c
c=nil
if not b then return end
local d=b.run(e)
if d then

g.atFrameEnd("kit ask again",function()
c={prompt=b.prompt,initial=e,run=b.run,err=d}
StaticPopup_Show(a.."TEXT",d.."\n"..b.prompt)
end)
end
end
StaticPopupDialogs[a.."TEXT"]={
text="%s",button1=ACCEPT,button2=CANCEL,
hasEditBox=true,maxLetters=48,
OnShow=function(a)
local a=a:GetEditBox()
a:SetText(c and c.initial or"")
a:HighlightText()
a:SetFocus()
end,
OnAccept=function(a)d(a:GetEditBox():GetText())end,
EditBoxOnEnterPressed=function(a)
d(a:GetText())
a:GetParent():Hide()
end,
EditBoxOnEscapePressed=function(a)a:GetParent():Hide()end,
timeout=0,whileDead=true,hideOnEscape=true,preferredIndex=3,
}

function b.saidOf(a)
if type(a)=="string"then return a end
return a and a[1]and a[1].text or"That can't be done."
end

function b.askText(b,d,e,f)
c={prompt=b,initial=d,run=e}
StaticPopupDialogs[a.."TEXT"].button1=f or ACCEPT
return StaticPopup_Show(a.."TEXT",b)
end
