














local a,d=...
local c,i,j,m,A=d.Kit,d.Events,d.Ticker,d.Combat,d.Spells

local a={}
d.Gallery=a

local B,C,r,s=800,660,620,460
local D,k,E,n=24,20,28,16
local o,p,t,F,e=110,28,12,8,6
local G,l=14,30
a.NAME="InterHUDGallery"

a.TITLE="Styles Explorer"

a.NOTE="Nothing here changes your HUD until you pick Use as Global or Save as preset from a tile's menu."



a.BACKDROPS={
{key="dark",label="Dark"},


{key="marble",label="Marble",file="Interface\\FrameGeneral\\UI-Background-Marble"},
{key="parchment",label="Parchment",file="Interface\\Garrison\\GarrisonMissionParchment",shade=0.85},
{key="stone",label="Dungeon floor",file="Interface\\FrameGeneral\\UI-Background-Rock"},
}

a.SAMPLES={8042,122,348,589,331}


a.SIZES={32,40,52,64}
a.BAR_SIZES={{120,10},{160,14},{200,20},{240,28}}


function a.freshState()
return{tab=nil,sample=1,paused=false,backdrop={},size={},text="name",countdown=false,
texts=false,animate=false,font=nil}
end
a.state=a.freshState()
a.stamp=0




local g,f=0.15,0.1
local b
local function h()
if GetTime()<b then return end
j.unsubscribe(f,"gallery settle")
b=nil
a.restyle()
end
d.onChanged(function(c)
if c~="styles"and c~="profile"then return end
if c=="profile"or not a.isShown()then return a.restyle()end
b=GetTime()+g
j.subscribe(f,"gallery settle",h)
end,"gallery")



local f,g={},{}
function a.tab(a,b)
assert(not f[a],"gallery tab registered twice: "..a)
b.key=a
f[a]=b
g[#g+1]=a
table.sort(g,function(a,b)return(f[a].rank or 0)<(f[b].rank or 0)end)
end
function a.tabs()return g end
function a.tabSpec(a)return f[a]end



function a.sectionOf(b)
for c,a in ipairs(g)do
local b=f[a].parts and f[a].parts[b]
if b then return a,b end
end
end

local b
a.pages={}


function a.scale()return c.windowScale()end



local h=0

local u,q,v=4,4,6
local function w()
local d=(b.card:GetWidth()or 0)-2*(e+u)
if d<=0 then return end
local a=math.ceil(c.wrapText(b.note,a.NOTE,d))
if b.noteH==a then return end
b.noteH=a
b.area:SetPoint("TOPLEFT",b.card,"TOPLEFT",e,-(e+q+a+v))
end
local function x()
if not(b and b.frame:IsShown())then return end
h=h+1
a.paintN=h
w()
local d=a.pages[a.state.tab]
if d then d:refresh()end
for b,d in pairs(b.tabButtons)do c.paintTab(d,b==a.state.tab)end
if b.paintFoot then b.paintFoot()end
end
function a.repaint()
if not(b and b.frame:IsShown())then return end
i.atFrameEnd("gallery repaint",x)
end

function a.restyle()
a.stamp=a.stamp+1
a.repaint()
end




local y,z=0.5,6
local h=0
local function H()
h=h+1
local b=h%z
if a.replayTab then a.replayTab(a.state.tab,b,z)end
end
local function z()return b and b.frame:IsShown()and not a.state.paused and not m.inCombat()end
local function h()
if z()then j.subscribe(y,"gallery replays",H)else j.unsubscribe(y,"gallery replays")end
end
a.syncCycle=h
m.onStart("gallery",h)
m.onEnd("gallery",h)



local function m()
local b=CreateFrame("Frame",a.NAME,UIParent)


b:SetFrameStrata("DIALOG")
local d=b:CreateTexture(nil,"BACKGROUND",nil,1)
d:SetAllPoints()
c.fill(d,"windowBg")
local e,d=c.edge(b)
b.placeEdge=d
local d=b:CreateTexture(nil,"BACKGROUND",nil,2)
d:SetHeight(D)
c.gradient(d,"titleHigh","titleLow")
b.titleBar=d
b.titleRule=b:CreateTexture(nil,"BORDER")
b.titleRule:SetPoint("TOPLEFT",d,"BOTTOMLEFT")
b.titleRule:SetPoint("TOPRIGHT",d,"BOTTOMRIGHT")
c.fill(b.titleRule,"metalLow")

b.title=c.fontString(b,"windowTitle")
b.title:SetText(a.TITLE)
b.tag=c.fontString(b,"dim")
b.tag:SetText("experimental")
b.tag:SetAlpha(0.8)
local e=8
local a=c.textWidth("windowTitle",a.TITLE)+e+c.textWidth("dim","experimental")
b.title:SetPoint("LEFT",d,"CENTER",-math.floor(a/2),0)
b.tag:SetPoint("BOTTOMLEFT",b.title,"BOTTOMRIGHT",e,1)
local a=c.button(b,"",k,k)
a:SetPoint("RIGHT",d,"RIGHT",-3,0)
a.x=a:CreateTexture(nil,"OVERLAY")
a.x:SetTexture(c.art("close"))
a.x:SetVertexColor(c.rgba("gold"))
a.x:SetPoint("CENTER")
a.x:SetSize(k-2,k-2)
a:SetScript("OnClick",function()b:Hide()end)
a.simLabel="Close"
b.close=a
local a=CreateFrame("Frame",nil,b)
a:SetHeight(E)
a.ground=a:CreateTexture(nil,"BACKGROUND")
a.ground:SetAllPoints()
c.gradient(a.ground,"titleLow","titleHigh")
a.rule=a:CreateTexture(nil,"BORDER")
a.rule:SetPoint("TOPLEFT")
a.rule:SetPoint("TOPRIGHT")
c.fill(a.rule,"metalLow")
b.foot=a
return b
end



local function k(a,b,c)return math.max(math.min(a,c),b)end
local function j(a,c)
local d=b.frame:GetScale()
a=k(a,r,math.max(UIParent:GetWidth()/d,r))
c=k(c,s,math.max(UIParent:GetHeight()/d,s))
b.w,b.h=a,c
b.frame:SetSize(a,c)
end
local function r()
local d,e=b.frame,b.frame:GetScale()
d:ClearAllPoints()

local a=_G[c.WINDOW_NAME]
local c,f=a and a:IsShown()and a:GetRight(),a and a:IsShown()and a:GetTop()
if c and f then
local a=a:GetScale()
local a,c=c*a+8,f*a
if a+b.w*e<=UIParent:GetWidth()then
d:SetPoint("TOPLEFT",UIParent,"BOTTOMLEFT",a/e,c/e)
return
end
end
d:SetPoint("CENTER")
end


local function k(e)
local d=CreateFrame("Button",nil,e)
d:SetSize(n,n)
d:SetPoint("BOTTOMRIGHT",-6,6)
d:SetFrameLevel(e:GetFrameLevel()+50)
local f=c.art("grip")
d:SetNormalTexture(f.."Up")
d:SetHighlightTexture(f.."Highlight")
d:SetPushedTexture(f.."Down")
local function g()
local b,c=GetCursorPosition()
local a=e:GetEffectiveScale()
j(d.startW+(b-d.startX)/a,d.startH+(d.startY-c)/a)
end


local function f()
d:SetScript("OnUpdate",nil)
c.Page.endResize()
local b=a.state.tab
if b and a.onTabHidden then
a.onTabHidden(b)
a.restyle()
end
end
d:SetScript("OnMouseDown",function(d)
local f,h=e:GetLeft(),e:GetTop()
e:ClearAllPoints()
e:SetPoint("TOPLEFT",UIParent,"BOTTOMLEFT",f,h)
d.startX,d.startY=GetCursorPosition()
d.startW,d.startH=b.w,b.h
c.Page.startResize(a.pages[a.state.tab])
d:SetScript("OnUpdate",g)
end)
d:SetScript("OnMouseUp",f)
e:HookScript("OnHide",function()if d:GetScript("OnUpdate")then f()end end)
return d
end


local function s(h)
local d=CreateFrame("Frame",nil,h)
d:SetPoint("TOPLEFT",h.titleBar,"BOTTOMLEFT",t,-F)
d:SetSize(#g*(o-1)+1,p)
local b=CreateFrame("Frame",nil,h)
b:SetPoint("TOPLEFT",d,"BOTTOMLEFT",-(t-e),1)
b:SetPoint("BOTTOMRIGHT",h.foot,"TOPRIGHT",-e,e)
b.ground=c.panel(b,"tabCard","tabCardEdge")
b.ground:cover(b,1)
b:SetFrameLevel(h:GetFrameLevel()+1)
local h={}
for g,e in ipairs(g)do
local b=c.tab(d)
b:SetPoint("BOTTOMLEFT",(g-1)*(o-1),0)
b:SetSize(o,p)
b.text:SetText(f[e].label)
b.simLabel=f[e].label
b:SetScript("OnClick",function()a.show(e)end)
h[e]=b
end
d:SetFrameLevel(b:GetFrameLevel()+2)
return d,b,h
end

local function o()
local d=m()
b={frame=d}
d:SetToplevel(true)
d:SetClampedToScreen(true)
d:SetMovable(true)
d:EnableMouse(true)

d:EnableMouseWheel(true)
d:SetScript("OnMouseWheel",function()end)
c.dragByTitle(d,d.titleBar,d.close)
d:SetScale(a.scale())
b.strip,b.card,b.tabButtons=s(d)
b.note=c.fontString(b.card,"small")
c.tint(b.note,"help")
b.note:SetPoint("TOPLEFT",b.card,"TOPLEFT",e+u,-(e+q))
b.note:SetJustifyH("LEFT")
b.note:SetJustifyV("TOP")
b.area=CreateFrame("Frame",nil,b.card)
b.area:SetPoint("TOPLEFT",b.card,"TOPLEFT",e,-(e+q+14+v))
b.area:SetPoint("BOTTOMRIGHT",b.card,"BOTTOMRIGHT",-e,e)
b.grip=k(d)
if a.makeFoot then b.paintFoot=a.makeFoot(d.foot)end
d:SetScript("OnShow",function()
h()
a.repaint()
end)
d:SetScript("OnHide",function()
h()
c.closeMenu()

if a.onTabHidden and a.state.tab then a.onTabHidden(a.state.tab)end
a.hiddenTab=a.state.tab
end)



d:EnableKeyboard(true)
d:SetPropagateKeyboardInput(true)
d:SetScript("OnKeyDown",function(a,b)
if b~="ESCAPE"then return end
local b=_G[c.WINDOW_NAME]
if b and b:IsShown()and b:GetFrameLevel()>a:GetFrameLevel()then return end
if InCombatLockdown()then
a:Hide()
return
end
a:SetPropagateKeyboardInput(false)
a:Hide()
i.atFrameEnd("gallery escape",function()
if not InCombatLockdown()then a:SetPropagateKeyboardInput(true)end
end)
end)
d:Hide()
j(B,C)
return b
end


local function k()
local a=b.frame
local b=a.placeEdge()
local c=c.linePx(a,1)
a.titleBar:ClearAllPoints()
a.titleBar:SetPoint("TOPLEFT",b,-b)
a.titleBar:SetPoint("TOPRIGHT",-b,-b)
a.titleRule:SetHeight(c)
a.foot:ClearAllPoints()
a.foot:SetPoint("BOTTOMLEFT",a,"BOTTOMLEFT",b,b)
a.foot:SetPoint("BOTTOMRIGHT",a,"BOTTOMRIGHT",-b,b)
a.foot.rule:SetHeight(c)
end


function a.window()return b end



local function e()
if not b then return end
i.atFrameEnd("gallery rescaled",function()
local c=a.scale()
if b.frame:GetScale()~=c then
b.frame:SetScale(c)
j(b.w,b.h)
end
k()
a.restyle()
end)
end
i.on("UI_SCALE_CHANGED","gallery",e)
i.on("DISPLAY_SIZE_CHANGED","gallery",e)
d.onChanged(function(c)
if c=="ui"and b and b.frame:GetScale()~=a.scale()then e()end
end,"gallery scale")


local function e(g)
local e=a.pages[g]
if e then return e end
local f=f[g]
e=c.newPage(b.area,"gallery:"..g)
a.pages[g]=e
e.noFoldAll=true
if a.makeBar then a.makeBar(e,f)end
d.try("gallery tab "..g.." build",f.build,e)
return e
end


function a.show(c,d)
if not f[c]then return end
local b=a.state.tab
if b and b~=c and a.pages[b]then
a.pages[b]:hide()
if a.onTabHidden then a.onTabHidden(b)end
end
a.state.tab=c
local b=e(c)
b:show()
b:refresh()

if d then i.atFrameEnd("gallery go to",function()b:goTo(d)end)end
h()
a.repaint()
end

function a.open(c,e)
local d=b==nil
if d then o()end
local b=b.frame
b:SetScale(a.scale())
k()
if d then r()end
b:Show()
w()
c=c or a.state.tab or g[1]
if a.hiddenTab==c and a.pages[c]then a.state.tab=nil end
a.hiddenTab=nil
a.show(c,e)
x()
end
function a.hide()if b then b.frame:Hide()end end
function a.isShown()return b~=nil and b.frame:IsShown()end
function a.toggle()
if a.isShown()then a.hide()else a.open()end
end





local e={}
a.CONTROLS=e


local f=6
local function g(a,b,d)
local b=math.ceil(c.textWidth(c.theme.metric.pane.label,b))+2
a.label:ClearAllPoints()
a.label:SetPoint("LEFT",a,"LEFT",0,0)
a.label:SetWidth(b)
local c=a.dropdown or a.switch or a.swatchButton
c:ClearAllPoints()
c:SetPoint("LEFT",a,"LEFT",b+f,0)
a.barW=b+f+d
a:SetWidth(a.barW)
return a
end
function a.dropdown(d,a,e,f,h,b)
local c=c.dropdown(d,a,nil,e,function(a)
f(a)
return true
end,{choices=h,width=b,dense=true})
return g(c,a,b)
end

local function f(c,b,d)
local a=a.state[c]
if a[b]==nil then return d end
return a[b]
end
function a.backdropOf(a)return f("backdrop",a,"parchment")end
function a.sizeOf(a)return f("size",a,2)end
function a.sampleSpell()return a.SAMPLES[a.state.sample]or a.SAMPLES[1]end

e.backdrop=function(d,b)
local c={}
for b,a in ipairs(a.BACKDROPS)do c[b]={a.key,a.label}end
return a.dropdown(d,"Backdrop",function()return a.backdropOf(b)end,function(c)
a.state.backdrop[b]=c
a.repaint()
end,c,120)
end
e.sample=function(b)
local function c()
local b={}
for a,c in ipairs(a.SAMPLES)do b[a]={a,A.nameOf(c)or("Spell "..c)}end
return b
end
return a.dropdown(b,"Sample",function()return a.state.sample end,function(b)
a.state.sample=b
a.restyle()
end,c,140)
end
e.size=function(d,b)
local c={}
for a,b in ipairs(a.SIZES)do c[a]={a,tostring(b)}end
return a.dropdown(d,"Size",function()return a.sizeOf(b)end,function(c)
a.state.size[b]=c
a.restyle()
end,c,64)
end
e.barSize=function(d,b)
local c={}
for a,b in ipairs(a.BAR_SIZES)do c[a]={a,b[1].." x "..b[2]}end
return a.dropdown(d,"Size",function()return a.sizeOf(b)end,function(c)
a.state.size[b]=c
a.restyle()
end,c,96)
end
e.text=function(b)

local function c()
local a={}
for c,b in ipairs({"name","number","time"})do a[#a+1]={b,d.GalleryTiles.sampleWords(b)}end
return a
end
return a.dropdown(b,"Sample text",function()return a.state.text end,function(b)
a.state.text=b
a.restyle()
end,c,110)
end

local function f(a,b,d,e)
local a=c.checkbox(a,b,nil,d,function(a)
e(a and true or false)
return true
end,{dense=true})
a.barW=26+math.ceil(c.textWidth(c.theme.metric.pane.label,b))+6
a:SetWidth(a.barW)
return a
end

e.countdown=function(b)
return f(b,"Cooldown numbers",function()return a.state.countdown end,function(b)
a.state.countdown=b
a.restyle()
end)
end

e.animate=function(b)
return f(b,"Animate",function()return a.state.animate end,function(b)
a.state.animate=b
a.restyle()
end)
end

e.texts=function(b)
return f(b,"Texts",function()return a.state.texts end,function(b)
a.state.texts=b
a.restyle()
end)
end
e.font=function(b,c)
local function e()
local a={{"global","Global's"}}
local c=d.Schema.choiceLabels("media:font")
for d,b in ipairs(d.Schema.choicesOf("media:font")())do a[#a+1]={b,c[b]or b}end
return a
end
local b=a.dropdown(b,"Font",function()return a.state.font or"global"end,function(b)
a.state.font=b~="global"and b or nil
a.restyle()
end,e,140)

b.shownFn=function()
if c=="bars"then return a.state.texts end
return a.state.countdown
end
return b
end

e.pause=function(b)
return f(b,"Pause effects",function()return a.state.paused end,function(b)
a.state.paused=b
h()

if a.onPause then a.onPause(b)end
end)
end

e.reset=function(d,b)
local a=c.textLink(d,"Reset this tab",function()
a.state.backdrop[b],a.state.size[b]=nil,nil
if a.resetTab then a.resetTab(b)end
a.restyle()
end,true)

a.onTabs=true
return a
end

function a.makeBar(c,d)
local a=CreateFrame("Frame",nil,c.area)
a.controls={}
for c,f in ipairs(d.bar or{})do
local c=e[f](a,d.key)
c.name=f
if c.onTabs then

c:SetPoint("RIGHT",b.card,"TOPRIGHT",-10,p/2-1)
c:SetFrameLevel(b.strip:GetFrameLevel()+1)
else
a.controls[#a.controls+1]=c
end
end
c.galleryBar=a

c.inset=2
local b=1
c:pin(a,l+6,function()
local g,d,f,e=c.area:GetWidth()-8,4,0,1
for c,b in ipairs(a.controls)do

local c=not b.shownFn or b.shownFn()
b:SetShown(c)
if c then
if b.refresh then b.refresh()end
if d>4 and d+b.barW>g then d,f,e=4,f+l,e+1 end
b:ClearAllPoints()
b:SetPoint("LEFT",a,"TOPLEFT",d,-(f+l/2))
d=d+b.barW+G
end
end
if e~=b then
b=e
c:setPinHeight(e*l+6)
end
end,4)
return a
end




local f="Interface\\Icons\\inv_misc_enggizmos_19"
local g="While the Styles Explorer is open, InterHUD's memory in the AddOns list rises as it draws every "
.."sample. It's temporary: it goes back down shortly after you close the Styles Explorer."

function a.makeFoot(e)
if not d.isDev then return end
local b=CreateFrame("Button",nil,e)
b:SetSize(16,16)
b:SetPoint("RIGHT",e,"RIGHT",-(n+12),0)
b:EnableMouse(true)
b.icon=b:CreateTexture(nil,"ARTWORK")
b.icon:SetAllPoints()
b.icon:SetTexture(f)
c.cropIcon(b.icon)
c.setTip(b,"Memory while the Styles Explorer is open",g,"above")
b.simLabel="Memory"
a.memoryIcon=b
end
