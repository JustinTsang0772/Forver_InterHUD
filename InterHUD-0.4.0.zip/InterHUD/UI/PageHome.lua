




local a,c=...
local a,f,d,k,v,m=c.Kit,c.Store,c.Window,c.Specials,c.Combat,c.PageProfiles

local b={}
c.PageHome=b

local j,g,h,e,n=30,42,36,12,12
local o,i,p=72,10,28
local q={off="See everything on screen.",on="Back to the live HUD."}

local r="\1new"

local function l(a,b)return a.." "..b..(a==1 and""or"s")end





function b.counts()
local a={elements=0,off=0,unlearned=0,alerts={elements=0,off=0,unlearned=0},groups=0,
specials={on=0,off=0,never=0}}
for c,b in ipairs(d.entries())do
if b.kind=="element"then
local a=b.alert and a.alerts or a
a.elements=a.elements+1
if b.off then a.off=a.off+1 end
if b.unlearned then a.unlearned=a.unlearned+1 end
elseif b.kind=="group"then
a.groups=a.groups+1
end
end
for c,b in ipairs(k.list(f.profile()or{}))do
a.specials[b.state]=a.specials[b.state]+1
end
return a
end


function b.classHasCollection()
local b,a=UnitClass("player")
return c.Collections~=nil and#c.Collections.forClass(a)>0
end


function b.empty()
local a=f.profile()
return not a or((not a.elements or#a.elements==0)and(not a.groups or#a.groups==0))
end


function b.detailWords(b)
local a={}
if b.off>0 then a[#a+1]=b.off.." off"end
if b.unlearned>0 then a[#a+1]=b.unlearned.." not learned"end
return table.concat(a,", ")
end
function b.specialsDetail(a)
local a=a.specials
return a.off>0 and(a.off.." off")or""
end



function b.problemWords()
local a=#c.errorLines()
if a==0 then return nil end
return l(a,"problem").." noted this session"
end


local function k()d.onSwitch.set(true)end
local function l()SlashCmdList.INTERHUD("debug")end




function b.attention()
local a={}
if c.HUD.off()then a[#a+1]={"InterHUD is off for this character","Turn on ›",k}end
local b=b.problemWords()
if b then a[#a+1]={b,"/ihud debug ›",l,true}end
return a
end


function b.letterShown()
return f.ui().letterDismissed~=c.version
end
function b.dismissLetter()
f.editUI(function(a)a.letterDismissed=c.version end)
end

local w="InterHUD is in early beta, so expect rough edges and changes. If something feels broken or off, or if you"
.." have a feature request, please reach out on "..a.letterLink("feedback","Discord").."."



local k,s,t,u={},0,nil,nil
local l=0
c.onChanged(function()l=l+1 end,"home view")
function b.view()
local a,c=d.entries(),GetTime()
if s~=l or t~=a or u~=c then
s,t,u=l,a,c
k.counts=b.counts()
k.empty=b.empty()
k.attention=b.attention()
end
return k
end
function b.letterWords()return w end


local function l(a)
c.PageShare.state.tab=a
d.select("page","profiles")
end
local function s()l("import")end

local function t()c.StyleArea.showStyles()end


local function u(b,c)
local b=CreateFrame("Button",nil,b)
b:SetHeight(g)
local d=b:CreateTexture(nil,"HIGHLIGHT")
d:SetAllPoints()
a.fill(d,"lit")
b.icon=b:CreateTexture(nil,"ARTWORK")
b.icon:SetSize(j,j)
b.icon:SetPoint("TOPLEFT",2,-(g-j)/2)
a.cropIcon(b.icon)
if type(c.icon)=="table"then b.icon:SetAtlas(c.icon.atlas)else b.icon:SetTexture(c.icon)end
local d=b:CreateTexture(nil,"BORDER")
d:SetPoint("TOPLEFT",b.icon,-1,1)
d:SetPoint("BOTTOMRIGHT",b.icon,1,-1)
a.fill(d,"heroEdge")
b.title=a.fontString(b,"listTop")
b.title:SetPoint("TOPLEFT",b.icon,"TOPRIGHT",8,-1)
b.title:SetJustifyH("LEFT")
b.title:SetText(c.title)
b.line=a.fontString(b,"small")
a.tint(b.line,"help")
b.line:SetPoint("TOPLEFT",b.title,"BOTTOMLEFT",0,-4)
b.line:SetJustifyH("LEFT")
b.line:SetJustifyV("TOP")
b.line:SetSpacing(2)

b.line:SetText(c.line)
b:SetScript("OnEnter",function()a.tint(b.title,"goldLight")end)
b:SetScript("OnLeave",function()a.tint(b.title,a.fontColor("listTop"))end)
b:SetScript("OnClick",c.click)
b.simRole,b.simLabel="button",c.title
return b
end


local k={
{key="make",title="Make",actions={"new","collections","import"}},
{key="screen",title="On screen",actions={"preview","unlock"}},
{key="setup",title="Setup",actions={"profiles","styles"}},
}
local function w(b)
local f=a.row(b.content,1)
local l={
new={icon=a.art("iconNew"),title="New element",line="Pre-made or your own.",
click=function()d.openNew()end},
collections={icon=a.art("iconCollections"),title="Collections",line="Ready-made HUDs by class.",
click=function()d.openNew(nil,"collection")end},
import={icon=a.art("iconShare"),title="Import",line="An element or a profile.",click=s},
preview={icon=a.art("iconPreview"),title="Preview",line=q.off,click=d.togglePreview},
unlock={icon=a.art("iconUnlock"),title="Unlock positioning",line="Move things on screen.",
click=d.toggleUnlock},
profiles={icon=a.art("iconProfiles"),title="Profiles",line="Switch or copy setups.",
click=function()l("profiles")end},
styles={icon=a.art("iconGlobal"),title="Global styles",line="The style all elements follow.",
click=t},
}
f.cards,f.actions={},{}
local i=0
for d,c in ipairs(k)do
local b=CreateFrame("Frame",nil,f)
b.ground=a.panel(b,nil,nil,nil,"card")
b.ground:cover(b,1)

b.title=a.fontString(b,"heading")
b.title:SetPoint("TOPLEFT",e+2,-e)
b.title:SetText(c.title)
b.rule=b:CreateTexture(nil,"ARTWORK")
a.fill(b.rule,"white")
b.rule:SetGradient("HORIZONTAL",a.colorObj("rule",0.40),a.colorObj("rule",0))
b.rule:SetHeight(1)
b.rule:SetPoint("TOPLEFT",e,-h+6)
b.rule:SetPoint("TOPRIGHT",-e,-h+6)
for d,c in ipairs(c.actions)do
local a=u(b,l[c])
a:SetPoint("TOPLEFT",e-4,-h-(d-1)*g)
a:SetPoint("RIGHT",-e+4,0)
f.actions[c]=a
end
i=math.max(i,#c.actions)
f.cards[d]=b
end
local l=h+i*g+e
f.height=function()return l end
return b:addRow(a.finishRow(f,function(m)
local i=math.floor((m-(#k-1)*n)/#k)
local b=f.actions
local o=d.unlockWords()
b.unlock.title:SetText(o)
b.unlock.simLabel=o
b.unlock.line:SetText(c.Placement.unlocked()and"Done placing."or"Move things on screen.")
local d=d.previewWords()
b.preview.title:SetText(d)
b.preview.simLabel=d
b.preview.line:SetText(c.PreviewMode.isOn()and q.on or q.off)

local j=math.max(i-2*e+8-j-2-8-4,60)
local d=0
for c,f in ipairs(k)do
local c=h
for f,d in ipairs(f.actions)do
local b=b[d]
local d=a.wrapText(b.title,b.title:GetText()or"",j)
local a,h,f=a.wrapText(b.line,b.line:GetText()or"",j)


b.line:SetWordWrap(true)

a=math.max(a,2*f+2)
local a=math.max(g,1+math.max(d,14)+4+a+6)
b:ClearAllPoints()
b:SetPoint("TOPLEFT",e-4,-c)
b:SetWidth(i-2*e+8)
b:SetHeight(a)
c=c+a
end
d=math.max(d,c)
end
l=d+e
for b,a in ipairs(f.cards)do
a:ClearAllPoints()
a:SetPoint("TOPLEFT",(b-1)*(i+n),0)

a:SetSize(b==#f.cards and m-(b-1)*(i+n)or i,l)
a.ground:cover(a,1)
end
end))
end


local function e(c)
local c=a.row(c.content,1)
c.lines={}
local d={}

c.height=function()return#d>0 and(i+#d*(p+4))or 0 end
local function e(d)
local b=c.lines[d]
if b then return b end
b=CreateFrame("Frame",nil,c)
b:SetHeight(p)
b.band=b:CreateTexture(nil,"BACKGROUND")
b.band:SetAllPoints()
a.fill(b.band,"attention",0.10)
b.bar=b:CreateTexture(nil,"ARTWORK")
b.bar:SetWidth(3)
b.bar:SetPoint("TOPLEFT")
b.bar:SetPoint("BOTTOMLEFT")
a.fill(b.bar,"attention")
b.text=a.fontString(b,"label")
a.tint(b.text,"attentionText")
b.text:SetPoint("LEFT",12,0)

local function e()if b.click then b.click()end end
b.act=a.textLink(b,"",e,true)
b.go=a.textLink(b,"",e,true):leaves()
for c,a in ipairs({b.act,b.go})do a:SetPoint("LEFT",b.text,"RIGHT",12,0)end
c.lines[d]=b
return b
end
return a.finishRow(c,function(f)
d=b.view().attention
for c,b in ipairs(d)do
local a=e(c)
a:ClearAllPoints()
a:SetPoint("TOPLEFT",0,-(i+(c-1)*(p+4)))
a:SetWidth(f)
a.text:SetText(b[1])
a.link=b[4]and a.go or a.act
a.link.say(b[2])
a.act:SetShown(not b[4])
a.go:SetShown(b[4]and true or false)
a.click=b[3]
a:Show()
end
for a=#d+1,#c.lines do c.lines[a]:Hide()end

c:SetHeight(math.max(c.height(),1))
end)
end


local function h(c)
local c=a.row(c.content,o)
local e=o
c.height=function()return e end
local d={
{key="elements",name="Elements ›",one="Element ›",open=function()d.select("groups","groups")end,
read=function(a)return a.elements,b.detailWords(a)end},
{key="alerts",name="Spell Alerts ›",one="Spell Alert ›",
open=function()d.select("alerts","alerts")end,
read=function(a)return a.alerts.elements,b.detailWords(a.alerts)end},
{key="groups",name="Groups ›",one="Group ›",open=function()d.select("groups","groups")end,
read=function(a)return a.groups,""end},
{key="specials",name="Specials on ›",one="Special on ›",
open=function()d.select("specials","specials")end,
read=function(a)return a.specials.on,b.specialsDetail(a)end},
}
c.tiles={}
for f,d in ipairs(d)do
local b=CreateFrame("Button",nil,c)
b.ground=a.panel(b,"statFill")
b.ground:cover(b,1)
local e=b:CreateTexture(nil,"HIGHLIGHT")
e:SetAllPoints()
a.fill(e,"lit")
b.number=a.fontString(b,"stat")
b.number:SetPoint("TOPLEFT",10,-8)
b.name=a.fontString(b,"link")
b.name:SetPoint("TOPLEFT",b.number,"BOTTOMLEFT",0,-4)
b.name:SetText(d.name)
b.detail=a.fontString(b,"dim")
b.detail:SetPoint("TOPLEFT",b.name,"BOTTOMLEFT",0,-3)

b.detail:SetJustifyH("LEFT")
b.detail:SetJustifyV("TOP")
b:SetScript("OnClick",d.open)
b.simRole,b.simLabel="button",d.name
b.read,b.names=d.read,d
c.tiles[d.key]=b
c.tiles[f]=b
end
return a.finishRow(c,function(g)
local h=b.view().counts
local d=math.floor((g-3*i)/4)

local f=0
for e=1,4 do
local b=c.tiles[e]
local c,h=b.read(h)
b.number:SetText(tostring(c))

local c=c==1 and b.names.one or b.names.name
b.name:SetText(c)
b.simLabel=c
b.w=e==4 and g-3*(d+i)or d
local a,d,c=a.wrapText(b.detail,h,b.w-16)
b.detail:SetWordWrap(true)
f=math.max(f,a-2*c)
end
e=o+math.max(math.ceil(f),0)
for b=1,4 do
local a=c.tiles[b]
a:ClearAllPoints()
a:SetPoint("TOPLEFT",(b-1)*(d+i),0)
a:SetSize(a.w,e)
a.ground:cover(a,1)
end
c:SetHeight(e)
end)
end



local function i(c)
local c=a.row(c.content,30)
c.text=a.fontString(c,"label")
a.tint(c.text,"help")
c.text:SetPoint("LEFT",4,0)
c.text:SetText("Nothing made yet.")
c.new=a.textLink(c,"New element ›",function()d.openNew()end,true):leaves()
c.new:SetPoint("LEFT",c.text,"RIGHT",16,0)
c.collections=a.textLink(c,"Collections ›",function()d.openNew(nil,"collection")end,true):leaves()
c.collections:SetPoint("LEFT",c.new,"RIGHT",16,0)
return a.finishRow(c,function()c.collections:SetShown(b.classHasCollection())end)
end





local j=3
local function k(f)
local g,h=a.PAGE_TITLE_H,a.PAGE_TITLE_GAP
local e
f:plainTitle({switch=d.onSwitch,title=function()
local a=UnitName and UnitName("player")
return a and("Welcome, "..a)or"Welcome"
end,place=function(a,d)
if d<=0 then return end
local a,c=e.letter,0
local b=b.letterShown()
a:SetShown(b)
if b then
a.refresh(d)
a:SetSize(d,a.height())
a:ClearAllPoints()
a:SetPoint("TOPLEFT",e,"TOPLEFT",0,-g+18)
c=a.box:GetHeight()+j
end
if f.fixed and f.fixed.height~=g+h+c then
f:setPinHeight(g+h+c)
end
e.flourish:ClearAllPoints()
e.flourish:SetPoint("TOPLEFT",0,-g+18-c)
e.flourish:SetPoint("TOPRIGHT",0,-g+18-c)
e.flourish.refresh(d)
end})
e=f.titleRow


e.letter=a.parchment(e,{
crest=true,text=b.letterWords,sign="Thanks for trying it! — Inter",links={feedback=function()
c.PageAbout.openFeedback()
end},close=function()
b.dismissLetter()
f:refresh()
end})
f.letter=e.letter
e.flourish=a.flourish(e)
f.greeting=e
end



local g=34
local function d(f)
local e=c.Roadmap
local b=a.row(f.content,g)
local h=g
b.height=function()return h end
local d=CreateFrame("Frame",nil,b)
d:SetPoint("TOPLEFT",0,-2)
d:SetPoint("BOTTOMRIGHT",0,4)
local i=a.panel(d,"noteFill","noteEdge")
b.title=a.fontString(d,"listTop")
b.title:SetPoint("LEFT",12,0)
b.close=CreateFrame("Button",nil,d)
b.close:SetSize(16,16)
b.close:SetPoint("RIGHT",-8,0)
b.close.icon=b.close:CreateTexture(nil,"ARTWORK")
b.close.icon:SetTexture(a.art("close"))
b.close.icon:SetSize(12,12)
b.close.icon:SetPoint("CENTER")
b.close.icon:SetVertexColor(a.rgba("help"))
b.close:SetScript("OnEnter",function()b.close.icon:SetVertexColor(a.rgba("gold"))end)
b.close:SetScript("OnLeave",function()b.close.icon:SetVertexColor(a.rgba("help"))end)
b.close:SetScript("OnClick",function()
e.dismissLine()
f:refresh()
end)
b.close.simRole,b.close.simLabel="button","Dismiss"
b.link=a.textLink(d,"See what's new ›",function()c.PageAbout.openRoadmap("new")end,true):leaves()
b.link:SetPoint("RIGHT",b.close,"LEFT",-12,0)

b.summary=a.fontString(d,"small")
a.tint(b.summary,"help")
b.summary:SetPoint("LEFT",b.title,"RIGHT",10,0)
b.summary:SetJustifyH("LEFT")
b.summary:SetSpacing(2)
return f:addRow(a.finishRow(b,function(f)
local c=e.latest()
b.title:SetText("New in "..tostring(e.lineVersion()))
local e=f-12-b.title:GetStringWidth()-10-12-b.link:GetWidth()-12-16-8
local a=a.wrapText(b.summary,c and c.summary or"",math.max(e,60))
b.summary:SetWordWrap(true)
h=math.max(g,math.ceil(a)+22)
b:SetHeight(h)
i:cover(d,1)
end),function()return e.lineVersion()~=nil end)
end

a.registerPage("home",{build=function(a)
k(a)
local function c()return b.view().empty end
a.newsLine=d(a)
a.actionsRow=w(a)
a.actions=a.actionsRow.actions


a:block({key="hud",title="Your HUD"})

a.profileRow=m.choice(a,"Profile","The profile this character uses.",
function()return f.profileName()end,function(b)
if b==r then return m.askNewProfile(a.profileRow.dropdown)end
f.useProfile(b)
end,function()
local a=m.names()
a[#a+1]={r,"New profile…"}
return a
end)

a:hint("Switching waits until combat ends.",nil,v.inCombat)
a.stats=a:addRow(h(a),function()return not c()end)
a.emptyRow=a:addRow(i(a),c)
a.attention=a:addRow(e(a),function()return#b.view().attention>0 end)
a:endBlock()
end})
