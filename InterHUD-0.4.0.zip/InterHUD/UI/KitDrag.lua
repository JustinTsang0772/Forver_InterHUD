

















local a,f=...
local a=f.Kit

local d={}
local c
local b
local j,h,k=24,480,0.1



local function i(a)
local b,c,d,e=a:GetRect()
if not b then return nil end
local a=a:GetEffectiveScale()
return b*a,c*a,(b+d)*a,(c+e)*a
end
local function e(c,a,b)
local c,d,e,f=i(c)
return c~=nil and a>=c and a<=e and b>=d and b<=f
end
local function g()
local a,b=GetCursorPosition()
return a or 0,b or 0
end

function a.dropZone(c,b)
local b={frame=c,spec=b}
b.lit=c:CreateTexture(nil,"BACKGROUND",nil,7)
b.lit:SetAllPoints()
a.fill(b.lit,"accent",0.10)
b.lit:Hide()
b.line=a.dropLine(c)
d[#d+1]=b
c.dropZone=b
return b
end


local function l(c,f,g)
for a=#d,1,-1 do
local a=d[a]
local b=a.spec
if a.frame:IsVisible()and e(a.frame,c,f)and(not b.clip or e(b.clip,c,f))
and(not b.accepts or b.accepts(g))then
return a
end
end
end



local m={}
local function n(b)
local c,d,e=b.shown,b.tops,b.heights
if not c then
c,d,e={},{},{}
b.shown,b.tops,b.heights=c,d,e
end
local f=0
for b,a in ipairs(b.spec.rows and b.spec.rows()or m)do
if a:IsVisible()then
f=f+1
c[f]=a
end
end
for a=#c,f+1,-1 do c[a],d[a],e[a]=nil,nil,nil end
local g=UIParent:GetEffectiveScale()
for a=1,f do
local b=c[a]
local c=b:GetEffectiveScale()/g
d[a],e[a]=b:GetTop()*c,b:GetHeight()*c
end
return a.dropIndex(d,e),c
end

local function e(a,b)
if not a then return end
a.lit:SetShown(b)
if not b then a.line:Hide()end
end



local function d()
local b=c
if not b then return end
local f,d=g()
local g=GetTime()
local c=l(f,d,b.payload)
if c~=b.zone then
e(b.zone,false)
b.zone=c
e(c,true)
end
b.at=nil
if c and c.spec.ordered~=false then
local d,e=n(c)
b.at=d
if not a.placeDropLine(c.line,e,d)then c.line:Hide()end
end
local c=math.min(g-(b.stepAt or g),k)
b.stepAt=g
local a=b.spec.scroll
if a and c>0 and a.frame:IsVisible()then
local e,g,k,i=i(a.frame)
local b=j*a.frame:GetEffectiveScale()
if e and f>=e and f<=k then
if d>i-b and d<=i+b then a.by(-h*c)
elseif d<g+b and d>=g-b then a.by(h*c)end
end
end
end




function a.dragMove()
local b=c
if not b then return end
if IsMouseButtonDown("LeftButton")then
b.seenDown=true
elseif b.seenDown then
return a.dragCancel()
end
d()
end

function a.dragStart(e,d)
local f=d.payload()
if f==nil then return end
a.dragCancel()
if not b then
b=a.dragGhost(function()a.dragMove()end)
b.ground=a.panel(b,"menuFill","fieldEdgeLit")
b.ground:cover(b,1)
end
b.icon:SetTexture(d.icon and d.icon()or nil)
b.text:SetText(d.label and d.label()or"")
b:SetWidth(math.max(b.text:GetStringWidth()+40,80))
b:Show()
c={frame=e,spec=d,payload=f,ghost=b}
e:SetAlpha(0.5)

if not e:GetScript("OnUpdate")then
c.ownUpdate=true
e:SetScript("OnUpdate",function()a.dragMove()end)
end
a.dragMove()
end

local function b()
local a=c
c=nil
if not a then return end
e(a.zone,false)
a.ghost:Hide()
a.frame:SetAlpha(1)
if a.ownUpdate then a.frame:SetScript("OnUpdate",nil)end
a.frame.dragEndedAt=GetTime()
return a
end


function a.dragStop()
if not c then return end
d()
local a=b()
if a.zone then f.try("drop",a.zone.spec.drop,a.payload,a.at)end
end

function a.dragCancel()b()end

function a.dragging()return c end


function a.justDragged(a)
return a.dragEndedAt~=nil and a.dragEndedAt==GetTime()
end

function a.draggable(b,d)
b:RegisterForDrag("LeftButton")
b:SetScript("OnDragStart",function()a.dragStart(b,d)end)
b:SetScript("OnDragStop",function()a.dragStop()end)
b:HookScript("OnHide",function()if c and c.frame==b then a.dragCancel()end end)
end
