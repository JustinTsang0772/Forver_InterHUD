











local a,e=...
local b,l,r=e.Kit,e.Events,e.Combat

local g,i,o,m="InterHUDPicker",380,440,3
local f,h,n,j,p,d,k,s,t=6,24,20,22,34,20,12,18,10
local u=0.5

local a
local c={}

local function q()return b.MENU_INSET end



local function v(c,a)
local d=a.refused or a.unlearned
b.tint(c.label,a.refused and"off"or d and"help"or"text")
c.icon:SetDesaturated(d and true or false)
c.icon:SetAlpha(a.refused and u or 1)
c.picked:SetShown(a.picked==true)
end





function b.pickRow(a,f,c)
local a=CreateFrame("Button",nil,a)
a:EnableMouse(true)
local e=a:CreateTexture(nil,"HIGHLIGHT")
e:SetAllPoints()
b.fill(e,"menuPick")
a.picked=a:CreateTexture(nil,"BACKGROUND")
a.picked:SetAllPoints()
b.fill(a.picked,"menuPick")
a.picked:Hide()

a.foldButton=CreateFrame("Button",nil,a)
a.foldButton:SetSize(k+4,j)
a.foldButton:EnableMouse(true)
a.foldButton.simRole,a.foldButton.simLabel="button","Ranks"
a.foldButton:SetScript("OnClick",function()
if a.row and a.row.ranks and c then c(a.row)end
end)
a.fold=b.arrow(a.foldButton,"right",k)
a.fold:SetVertexColor(b.rgba("rule"))
a.fold:SetPoint("CENTER")
a.icon=a:CreateTexture(nil,"ARTWORK")
a.icon:SetSize(d,d)
b.cropIcon(a.icon)
a.label=b.fontString(a,"field")
a.label:SetJustifyH("LEFT")
a.label:SetWordWrap(false)
a.id=b.fontString(a,"dim")
a.id:SetJustifyH("RIGHT")
a.line=b.fontString(a,"small")
b.tint(a.line,"help")
a.line:SetJustifyH("LEFT")
a.line:SetWordWrap(false)
a:RegisterForClicks("LeftButtonUp")
a:SetScript("OnClick",function(a)if a.row then f(a.row)end end)

a:SetScript("OnEnter",function(a)
if not(a.row and a.row.reason)then return end
GameTooltip:SetOwner(a,"ANCHOR_RIGHT")
GameTooltip:SetText(a.row.label or"")
GameTooltip:AddLine(a.row.reason,1,1,1,true)
GameTooltip:Show()
end)
a:SetScript("OnLeave",function()GameTooltip:Hide()end)
return a
end

function b.placePickRow(a,c,e,g)
a.row=c

local f=c.refused and c.line and(p+b.fontSize("small")+2)or c.line and p or j
a:ClearAllPoints()
a:SetPoint("TOPLEFT",a:GetParent(),"TOPLEFT",0,-e)
a:SetSize(g,f)
local e=2+(c.depth or 0)*s
a.foldButton:SetShown(c.ranks~=nil)
if c.ranks then
a.foldButton:ClearAllPoints()
a.foldButton:SetPoint("LEFT",e,0)
b.setArrow(a.fold,c.unfolded and"down"or"right")
end
e=e+k+4
a.icon:ClearAllPoints()
a.icon:SetPoint("LEFT",e,0)
a.icon:SetTexture(c.icon or b.art("iconUnknown"))
a.id:SetText(c.idText or"")
a.id:ClearAllPoints()
a.id:SetPoint(c.line and"TOPRIGHT"or"RIGHT",a,c.line and"TOPRIGHT"or"RIGHT",-6,c.line and-4 or 0)
local b=e+d+8
a.label:ClearAllPoints()
a.label:SetPoint(c.line and"TOPLEFT"or"LEFT",a,c.line and"TOPLEFT"or"LEFT",b,c.line and-3 or 0)
a.label:SetPoint("RIGHT",a.id,"LEFT",-8,0)
a.label:SetText(c.label or"")
a.line:SetShown(c.line~=nil)
if c.line then
a.line:ClearAllPoints()
a.line:SetPoint("TOPLEFT",a.label,"BOTTOMLEFT",0,-3)
a.line:SetPoint("RIGHT",a,"RIGHT",-6,0)
a.line:SetWordWrap(c.refused==true)
a.line:SetMaxLines(c.refused and 2 or 1)
a.line:SetText(c.line)
end
v(a,c)
a:Show()
return f
end


local function p(e)
local d=a.rows[e]
if d then return d end
d=b.pickRow(a.content,function(a)b.pickerPick(a)end,function(a)
c.session.unfolded[a.key]=not c.session.unfolded[a.key]or nil
b.paintPicker()
end)
a.rows[e]=d
return d
end
local s=b.placePickRow


local function k(e)
local d=a.segs[e]
if d then return d end
d=b.segment(a,"small")
d:SetHeight(n)
d:SetScript("OnClick",function(a)
c.session[a.chip]=a.value
b.paintPicker()
end)
a.segs[e]=d
return d
end
local function u(d,h)
local g,c=q().left+4,0
for e,d in ipairs(d)do
for f,e in ipairs(d.choices)do
c=c+1
local c=k(c)
c.chip,c.value=d.key,e[1]
c.text:SetText(e[2])
c:SetWidth(b.textWidth("small",e[2])+14)
c:ClearAllPoints()
c:SetPoint("TOPLEFT",a,"TOPLEFT",g,-h)
b.paintSegment(c,d.value==e[1])
c:Show()
g=g+c:GetWidth()-(f<#d.choices and 1 or-10)
end
end
for b=c+1,#a.segs do a.segs[b]:Hide()end
return c>0 and n+f or 0
end


local function k()
local a=CreateFrame("Frame",nil,a)
a:SetHeight(h+4)
a.label=b.fontString(a,"field")
a.label:SetPoint("LEFT",4,0)
a.box=b.editBox(a,90,h)
a.box:SetPoint("LEFT",a.label,"RIGHT",8,0)
a.box:SetNumeric(true)
a.box:SetMaxLetters(10)
a.box.simLabel="By ID"
a.hint=b.fontString(a.box,"dim")
a.hint:SetPoint("LEFT",b.EDIT_INSET,0)
a.box:SetScript("OnTextChanged",function(d,e)
a.hint:SetShown(d:GetText()=="")
if e then
c.session.typed=d:GetText()
b.paintPicker()
end
end)
a.box:SetScript("OnEnterPressed",function()
local a=c.model
if a and a.byId and a.byId.typed then b.pickerPick(a.byId)end
end)
a.box:SetScript("OnEscapePressed",function()b.closePicker()end)
a.icon=a:CreateTexture(nil,"ARTWORK")
a.icon:SetSize(d,d)
a.icon:SetPoint("LEFT",a.box,"RIGHT",8,0)
b.cropIcon(a.icon)
a.name=b.fontString(a,"field")
a.name:SetPoint("TOPLEFT",a.icon,"TOPRIGHT",6,0)
a.name:SetPoint("RIGHT",-4,0)
a.name:SetJustifyH("LEFT")
a.name:SetWordWrap(false)

a.line=b.fontString(a,"small")
b.tint(a.line,"help")
a.line:SetPoint("TOPLEFT",a.name,"BOTTOMLEFT",0,-1)
a.line:SetPoint("RIGHT",-4,0)
a.line:SetJustifyH("LEFT")
a.line:SetWordWrap(false)

a:EnableMouse(true)
a:SetScript("OnEnter",function(b)
local a=c.model and c.model.byId
if not(a and a.reason)then return end
GameTooltip:SetOwner(b,"ANCHOR_RIGHT")
GameTooltip:SetText(a.label or"")
GameTooltip:AddLine(a.reason,1,1,1,true)
GameTooltip:Show()
end)
a:SetScript("OnLeave",function()GameTooltip:Hide()end)
return a
end
local function v(a,c)
a.label:SetText(e.PickerModel.WORDS.byId)
a.hint:SetText(c.hint or"")
a.hint:SetShown(a.box:GetText()=="")
local d=c.typed~=nil
a.icon:SetShown(d)
a.name:SetShown(d)
if d then
a.icon:SetTexture(c.icon or b.art("iconUnknown"))
a.icon:SetDesaturated(c.refused and true or false)
a.name:SetText(c.label or"")
b.tint(a.name,c.refused and"off"or"text")
end
a.line:SetShown(d and c.line~=nil)
a.line:SetText(c.line or"")

a.icon:ClearAllPoints()
a.icon:SetPoint("LEFT",a.box,"RIGHT",8,0)
a.name:ClearAllPoints()
if d and c.line then
a.name:SetPoint("BOTTOMLEFT",a.icon,"RIGHT",6,1)
else
a.name:SetPoint("LEFT",a.icon,"RIGHT",6,0)
end
a.name:SetPoint("RIGHT",-4,0)
end

local function e()
c.anchor,c.spec,c.session,c.model,c.refusal,c.up,c.room=nil,nil,nil,nil,nil,nil,nil
c.height=nil
l.off("GLOBAL_MOUSE_DOWN","kit picker")
b.escapeFirst(b.WINDOW_NAME,g)
GameTooltip:Hide()
end


local function n()
if a:IsMouseOver()or(c.anchor and c.anchor:IsMouseOver())then return end
b.closePicker()
end

local function w()
a=CreateFrame("Frame",g,UIParent)
a:SetFrameStrata("FULLSCREEN_DIALOG")
a:SetToplevel(true)
a:SetClampedToScreen(true)
a:EnableMouse(true)
a:SetSize(i,200)

local d=a:CreateTexture(nil,"BACKGROUND",nil,-1)
d:SetAllPoints()
b.fill(d,"menuFill")
b.menuGround(a)
a.title=b.fontString(a,"listTop")
a.title:SetJustifyH("LEFT")
a.title:SetWordWrap(false)
a.box=CreateFrame("EditBox",nil,a,"SearchBoxTemplate")
a.box:SetHeight(h)
a.box:SetMaxLetters(48)
a.box:SetFontObject(b.font("field"))
for b,a in ipairs({a.box.Left,a.box.Middle,a.box.Right})do a:SetHeight(h)end
a.box.simLabel="Search"
a.box.clearButton.simRole,a.box.clearButton.simLabel="button","Clear search"
a.box:HookScript("OnTextChanged",function(a,d)
if d and c.session then
c.session.words=a:GetText()
b.paintPicker()
end
end)
a.box.clearButton:HookScript("OnClick",function()
if c.session then
c.session.words=""
b.paintPicker()
end
end)
a.box:HookScript("OnEscapePressed",function()b.closePicker()end)

a.box:HookScript("OnEnterPressed",function()
local a=c.model
local a=a and(a.first and a.byId or a.rows[1])
if a then b.pickerPick(a)end
end)
a.segs,a.rows={},{}
a.scroll=CreateFrame("ScrollFrame",nil,a)
a.content=CreateFrame("Frame",nil,a.scroll)
a.content:SetSize(i,1)
a.scroll:SetScrollChild(a.content)
local function c()return a.scroll:GetVerticalScrollRange()end
a.bar=b.scrollBar(a,{
offset=function()return a.scroll:GetVerticalScroll()end,
range=c,
view=function()return a.scroll:GetHeight()end,
scrollTo=function(b)a.scroll:SetVerticalScroll(math.max(0,math.min(b,c())))end,
})
a.scroll:SetScript("OnScrollRangeChanged",function()a.bar:paint()end)
a.scroll:SetScript("OnVerticalScroll",function()a.bar:paint()end)
a.scroll:EnableMouseWheel(true)
a.scroll:SetScript("OnMouseWheel",function(d,b)
a.scroll:SetVerticalScroll(math.max(0,math.min(a.scroll:GetVerticalScroll()-b*2*j,c())))
end)
a.note=b.fontString(a.content,"small")
b.tint(a.note,"help")
a.note:SetJustifyH("LEFT")
a.byId=k()
a.err=b.fontString(a,"small")
b.tint(a.err,"error")
a.err:SetJustifyH("LEFT")
a.err:SetWordWrap(true)
a:SetScript("OnHide",e)
a:Hide()
end


local function d()
local c=c.anchor
local b=c
while b:GetParent()and b:GetParent()~=UIParent do b=b:GetParent()end
local a,d,e=c:GetEffectiveScale(),b:GetEffectiveScale(),a:GetEffectiveScale()
local c,f,g,h=c:GetTop(),c:GetBottom(),b:GetTop(),b:GetBottom()
if not(c and f and g and h)then return o,0,b end
return(f*a-h*d)/e-8,(g*d-c*a)/e-8,b
end


local e=300
local function k()
local a,b=d()
c.up=a<e and b>a
return math.max(c.up and b or a,m*j)
end

local function x()
local b=c.anchor
local e,f,d=d()
local g,h,e=b:GetEffectiveScale(),d:GetEffectiveScale(),a:GetEffectiveScale()
local d,f=b:GetLeft(),d:GetRight()
local d=d and f and math.min(0,(f*h-8*e-d*g)/e-i)or 0
a:ClearAllPoints()
if c.up then
a:SetPoint("BOTTOMLEFT",b,"TOPLEFT",d,2)
else
a:SetPoint("TOPLEFT",b,"BOTTOMLEFT",d,-2)
end
end


function b.paintPicker()
if not(a and a:IsShown()and c.spec)then return end
local e=c.spec.read(c.session)
c.model=e
local d=q()
local n=i-d.left-d.right-8
local b=d.top+4
a.title:ClearAllPoints()
a.title:SetPoint("TOPLEFT",d.left+4,-b)
a.title:SetWidth(n)
a.title:SetText(e.title or"")
b=b+a.title:GetStringHeight()+f
a.box:ClearAllPoints()
a.box:SetPoint("TOPLEFT",d.left+10,-b)
a.box:SetWidth(n-6)
a.box.Instructions:SetText(e.hint or"")
b=b+h+f
b=b+u(e.chips or{},b)

local k={}
if e.first and e.byId then k[1]=e.byId end
for b,a in ipairs(e.rows or{})do k[#k+1]=a end
local l=i-d.left-d.right-t
local g=0
for a,b in ipairs(k)do g=g+s(p(a),b,g,l)end
for b=#k+1,#a.rows do a.rows[b]:Hide()end
local k=e.waits or(#(e.rows or{})==0 and not e.first and e.empty)or e.more
a.note:SetShown(k~=nil)
if k then
a.note:ClearAllPoints()
a.note:SetPoint("TOPLEFT",a.content,"TOPLEFT",6,-(g+4))
a.note:SetWidth(l-12)
a.note:SetText(k)
g=g+a.note:GetStringHeight()+8
end
a.content:SetSize(l,math.max(g,1))

local k=(e.byId and not e.first)and(h+4+f)or 0
a.err:SetShown(c.refusal~=nil)
a.err:SetWidth(n)
a.err:SetText(c.refusal or"")
local n=c.refusal and(a.err:GetStringHeight()+f)or 0
local p=k+n+d.bottom

local g=math.max(math.min(g,math.min(o,c.room)-b-p),m*j)
if c.height then g=math.max(c.height-b-p-f,m*j)end
a.scroll:ClearAllPoints()
a.scroll:SetPoint("TOPLEFT",d.left,-b)
a.scroll:SetSize(l,g)
a.bar:ClearAllPoints()
a.bar:SetPoint("TOPRIGHT",a,"TOPRIGHT",-d.right-2,-b)
a.bar:SetPoint("BOTTOMRIGHT",a,"TOPRIGHT",-d.right-2,-(b+g))
b=b+g+f
a.byId:SetShown(k>0)
if k>0 then
a.byId:ClearAllPoints()
a.byId:SetPoint("TOPLEFT",d.left,-b)
a.byId:SetWidth(i-d.left-d.right)
v(a.byId,e.byId)
b=b+h+4+f
end
if c.refusal then
a.err:ClearAllPoints()
a.err:SetPoint("TOPLEFT",d.left+4,-b)
b=b+n
end
a:SetHeight(b+d.bottom)
c.height=c.height or(b+d.bottom)
a.scroll:SetVerticalScroll(math.min(a.scroll:GetVerticalScroll(),a.scroll:GetVerticalScrollRange()))
a.bar:paint()
x()
end




function b.pickerPick(a)
if not c.spec or a.refused then return end
local a,d=c.spec.pick(a)
if a then return b.closePicker()end
c.refusal=d or"That can't be done."
b.paintPicker()
end

function b.openPicker(d,e)
if not a then w()end
local f=c.anchor==d
b.closePicker()
b.closeMenu()
b.closeAsk()
if f then return end
Menu.GetManager():CloseMenus()
c.anchor,c.spec=d,e
c.session={words="",typed="",unfolded={}}

if not d.pickerHooked then
d.pickerHooked=true
d:HookScript("OnHide",function(a)if c.anchor==a then b.closePicker()end end)
end
a.box:SetText("")
a.byId.box:SetText("")
a.scroll:SetVerticalScroll(0)
a:SetScale(d:GetEffectiveScale()/UIParent:GetEffectiveScale())
c.room=k()
a:Show()
b.paintPicker()
b.escapeFirst(g,b.WINDOW_NAME)
l.on("GLOBAL_MOUSE_DOWN","kit picker",n)
a.box:SetFocus()
end

function b.closePicker()
if a and a:IsShown()then a:Hide()end
end
function b.pickerOwner()return a and a:IsShown()and c.anchor or nil end
function b.pickerFrame()return a end


r.onStart("kit picker",function()b.closePicker()end)
