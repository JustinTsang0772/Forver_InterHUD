















local a,c=...
local i,g,e=c.Schema,c.Spells,c.GameData

local d={}
c.PickerModel=d


d.WORDS={
title="%s: %s",addSpell="add a spell",fromSpell="From a spell",pickPicture="pick its picture",
hint="Name or ID",spellId="Spell ID",itemId="Item ID",byId="By ID",

classes={{"yours","Your class"},{"any","Any class"}},
learned={{"all","All"},{"learned","Learned"}},
rank="Rank %d",auraOf="%s's aura",versionOf="Another version of %s",
thisRank="This rank only",everyRank="Every rank counts",level="level %d",
pet="%s pet",racial="Racial",item="Item",trinket="Trinket",carried="in your bags",

onUnit={player="on you",target="on your target",pet="on your pet"},
from={item="Item",enchant="Enchant",set="Set bonus",other="Other"},
book="Your spellbook",bookAura="its aura may have another ID",client="Not in the game data",
unknown="Unknown ID",also="Also %s",

reasons={harmfulOnFriend="Cannot watch this debuff by its ID. Aura by type can.",
helpfulOnEnemy="Cannot watch an enemy's buff by its ID."},
nothing="Nothing found.",more="%d more: type to narrow",
waits="Picking waits until combat ends.",
}
local a=d.WORDS
local f=" · "
local j=50

local function h()return c.SpellTable and c.SpellTable.families or{}end


local function k(b)
local a=b and i.source(b)
if not a then return nil end
return{key=b,kind=a.kind,unit=a.unit,label=a.add and a.add.label or b}
end


local function l(a)
local b=c.ElementModel.view(a.id)
local a=b and a.path and c.Form.read(b,c.Form.up(a.path))
return type(a)=="table"and a or nil
end



local function n(a)
local a=a and rawget(a,"pickWords")or a and a.target and a.target.pick or"Pick its spell."
return(a:gsub("^%u",string.lower):gsub("%.$",""))
end




local function m(e)
local b={}
if e.at=="picture"then
b.data,b.byIcon,b.numbers="picture",true,true
b.title=a.title:format(a.fromSpell,a.pickPicture)
else
local d,f=e.kind,nil
if e.at=="spells"then
f=l(e)
d=f and f.kind and k(i.variantKey(f))or nil
end
b.kind,b.src=d,f
b.spec=d and c.Sources.get(d.kind)
b.picks=d and c.Sources.picksOf(d.kind)
b.data=b.picks and b.picks.data
b.unit=d and d.unit or(b.data=="aura"and"player"or nil)

b.anyUnit=d and d.anyUnit or nil
b.own=b.spec and b.spec.addChoices
b.numbers=e.at=="spells"

local d=f and c.Form.sourceLabel(f)or d and d.label or""
local c=b.spec and b.spec.target
b.title=a.title:format(d,e.at=="spells"and a.addSpell or n(b.spec))


b.byId=e.at~="addSource"and e.at~="new"or b.picks~=nil and b.picks.byId~=false
or not c or c.field=="spells"
end
if b.byId==nil then b.byId=true end

if e.at=="spells"and not b.kind then
b.data="known"
b.title=a.title:format(c.Schema.field("element","onlyWhileYouKnow").label,a.addSpell)
end

b.chips=(b.data=="spell"or b.data=="aura"or b.data=="known"or b.data=="picture")and not b.own
return b
end



local function i(a)return c.NewModel.className(a)end


local function n(c,b)
if b.list=="spellbook"then return c.data=="aura"and(a.book..f..a.bookAura)or a.book end
if b.unknown then return a.unknown end
if b.list=="client"then return a.client end
if b.kind=="item"then
local c=b.trinket and a.trinket or a.item
return b.carried and(c..f..a.carried)or c
end
if b.kind=="racial"then return a.racial end

local c=c.picks and c.picks.line and c.picks.line(b)
if c then return c end
if b.from=="pet"and b.class then return a.pet:format(i(b.class))end
if b.from=="class"and b.class then return i(b.class)end
return a.from[b.from]or a.from.other
end


local function o(f,b)
local c=b.key and h()[b.key]
if not(c and b.id~=b.key)then return nil end
local d=g.nameOf(b.key)or c.name
local e,c=e.memberReason(b.key,c,b.id)

if b.reason=="rank"and c then
local b=f.data=="aura"and a.thisRank or a.everyRank
return a.rank:format(c)..": "..b:gsub("^%u",string.lower)
end
if b.reason=="aura"then return a.auraOf:format(d)end
return a.versionOf:format(d)
end


local function l(a,b)
for c,a in ipairs(a)do
if a.unit==b then return a end
end
end

local function k(a,b)
if a.anyUnit and a.picks and a.picks.unitFor then return a.picks.unitFor(b.watch and b.watch.auras or{})end
return a.unit
end
local function p(a,b)
if a.data~="aura"or not b.watch then return nil end
local c=k(a,b)
local a=(a.picks.on or l)(b.watch.auras or{},c)
if not a then return nil end
local a,b=e.canWatchById(c,a.harmful)
if not a then return b end
end




local function l(c,b)
local d={key=tostring(b.id),id=b.id,label=b.name,icon=b.icon,idText=tostring(b.id)}
local e=o(c,b)or n(c,b)

if c.anyUnit and c.data=="aura"then e=e..f..a.onUnit[k(c,b)]end
if b.known==false and not c.noBook then
d.unlearned=true
if b.level then e=e..f..a.level:format(b.level)end
end
d.line=e

local b=p(c,b)
if b then d.refused,d.reason,d.line=true,a.reasons[b],a.reasons[b]end
return d
end




local function r(j,b,d,i)
local c=h()[b.id]
local e
if not j.noBook then
if d==false then
e=1
elseif d==true then
local a=g.highest(b.id)
local b=a and g.rankOf(a)or 0
for c,d in ipairs(c.ranks)do
if d==a and b>0 then e=c end
end
end
end
for g,d in ipairs(c.ranks)do
local d={key=b.key..":"..d,id=d,label=a.rank:format(g),icon=b.icon,idText=tostring(d),
depth=1,line=a.thisRank,pin=true,refused=b.refused,reason=b.reason}
if b.refused then d.line=b.reason end
if e and g>e then
d.unlearned=true
if c.levels and c.levels[g]then d.line=d.line..f..a.level:format(c.levels[g])end
end
i[#i+1]=d
end
end





local function q(a,d)
local b=a.spec and a.spec.target
if not(a.numbers and a.src and b and b.field~="spells"and a.spec.addRecord)then return true end
local d=a.spec.addRecord(d)
return d~=nil and c.equal(d[b.field],a.src[b.field])
end

local function s(b,a)
if b.byIcon then return a.kind~="item"and type(a.icon)=="number"end
if b.numbers and type(a.id)~="number"then return false end
if not b.picks then return true end
if not q(b,a.id)then return false end
local c=p(b,a)
if c then return a.from~="other"end
return b.picks.fits(a,k(b,a))
end


local function k(a)
local a=a.class or"yours"
if a=="any"then return nil end
local b,a=UnitClass("player")
return a
end


local function p(d,f,b)
if not d.byId then return nil end
local h=d.data=="item"and a.itemId or a.spellId
if not f then return{byId=true,key="byId",label=a.byId,word=a.byId,hint=h}end
local e=b or e.byId(f,d.data=="item")
local b=l(d,e)

b.byId,b.key,b.typed,b.hint,b.word,b.unlearned=true,"byId",f,h,a.byId,nil
b.line=b.refused and b.reason or o(d,e)or n(d,e)
if e.unknown then b.label,b.line=a.unknown,nil end

if d.byIcon and type(b.icon)~="number"and not c.Combat.inCombat()then
local c,a=g.highest(f)
b.icon=a
end
return b
end




local function n(c,a)
local d,k,b={},{},{}
local e,l=UnitClass("player")
for e,a in ipairs(c.own(a or"",j)or{})do
local h="own:"..tostring(a.id)
local j=type(a.id)=="number"and a.id or tonumber(tostring(a.id):match(":(%d+)$")or"")
local e=not b[h]and(not c.numbers or type(a.id)=="number")and q(c,a.id)
if e then
b[h]=true
local e=a.note
local g,b=g.family(j or 0)
if b and b.class and b.class~=l then
e=e and(e..f..i(b.class))or i(b.class)
end

local b={key=h,id=a.id,label=a.name,icon=a.icon,line=e,
idText=c.numbers and tostring(a.id)or nil,own=true}
local a=j and k or d
a[#a+1]=b
end
end
for b,a in ipairs(k)do d[#d+1]=a end
return d
end


local function o(b)
local c,d={},{}
for a,b in ipairs(b)do
local a=d[b.icon]
if a then
a.also=a.also or{}
if#a.also<3 then a.also[#a.also+1]=b.label end
else
d[b.icon]=b
c[#c+1]=b
end
end
for c,b in ipairs(c)do
if b.also then b.line=a.also:format(table.concat(b.also,", "))end
b.also,b.ranks=nil,nil
end
return c
end



local function q(a,d,b)
local b={learned=b.learned=="learned"and not a.noBook or nil,
class=a.chips and k(b)or nil}
if a.data~="picture"then b.kind,b.unit=a.data,a.data=="aura"and not a.anyUnit and a.unit or nil end

local f=a.picks and a.picks.facets
for a,c in pairs(f or{})do b[a]=c end
local g,i=UnitClass("player")
local g=0
if f then
local b,a=e.search(d,b,{limit=1})
g=a
elseif a.chips then
local a={}
for b,c in pairs(b)do a[b]=c end
a.class=i
local b,a=e.search(d,a,{limit=1})
g=a
end
local g,k=e.search(d,b,{limit=g+j})
local b,d,e={},nil,0
for g,c in ipairs(g)do
if c.byId then
d=c
elseif f or c.class==i and a.chips then
b[#b+1]=c
elseif e<j then
e=e+1
b[#b+1]=c
end
end

local a=d and(h()[d.id]or c.SpellTable and c.SpellTable.racials[d.id])and 1 or 0
return b,d,math.max(0,(k or 0)-#b-a)
end

function d.picker(b,d)
d=d or{}
local b=m(b)

b.noBook=d.noBook
local f=d.words or""
local g=tonumber((f:match("^%s*(%d+)%s*$")))
local m=tonumber(((d.typed or""):match("^%s*(%d+)%s*$")))
local e={title=b.title,hint=a.hint,chips={},rows={},first=g~=nil and b.byId}

if c.Combat.inCombat()then
e.first,e.waits=false,a.waits
return e
end
if b.chips then
e.chips[1]={key="class",value=d.class or"yours",choices=a.classes}
if not b.noBook then e.chips[2]={key="learned",value=d.learned or"all",choices=a.learned}end
end
local c,k,i,j={},nil,0,{}
if b.own then
for b,a in ipairs(n(b,f))do c[#c+1]=a end
end
if b.data then
local a
a,k,i=q(b,f,d)
for e,a in ipairs(a)do
if s(b,a)then
local e=l(b,a)
c[#c+1]=e
if a.kind~="item"then j[a.id]=true end

local f=b.data=="aura"and a.list=="data"and a.key==nil and a.kind=="spell"and h()[a.id]
if f and f.ranks and#f.ranks>1 then
e.ranks=#f.ranks
e.unfolded=d.unfolded and d.unfolded[e.key]or nil
if e.unfolded then r(b,e,a.known,c)end
end
end
end
end

if b.own and next(j)then
local a={}
for c,b in ipairs(c)do
if not(b.own and j[b.id])then a[#a+1]=b end
end
c=a
end
if b.byIcon then c=o(c)end
e.rows=c
e.byId=p(b,g or m,g and k or nil)
if#c==0 then e.empty=a.nothing end
if i>0 then e.more=a.more:format(i)end
return e
end



function d.listRow(a)
local b=l({},a)
b.ref={key=a.key or a.id,kind=a.kind=="item"and"item"or"spell",id=a.id}
return b
end



local function b(a,b,c)
local a={ok=a and true or false,line=not a and(b or"That can't be done.")or nil}
for b,c in pairs(c or{})do a[b]=c end
return a
end
local function f(a)return a and a[1]and(a[1].text or a[1])or nil end


local function g(a,b)
if b.own or not(a.picks and a.picks.choiceOf)then return b.id end
return a.picks.choiceOf(b.id)
end

local e={}
function e.addSource(d,f,a,e)
local a=c.AddViews.sourceRecord(d.kind,a,e.pin)
if not a then return b(false)end
return c.ElementModel.act(d.id,"addSource",{kind=a.kind,source=a})
end
function e.new(a,d,g,h)
local i=c.NewModel
local c,d,e
if a.alert then
c,d,e=i.makeAlert(a.kind.key,g,h.pin)
else
c,d,e=i.makeEmpty(a.kind,g,a.group,h.pin)
end
if not c then return b(false,f(d))end
return b(true,nil,{opened={id=c,entry=e}})
end
function e.spells(a,e,b,d)
return c.ElementModel.act(a.id,"addSpell",{path=a.path,spell=b,exact=d.pin})
end
function e.picture(a,e,f,d)
if type(d.icon)~="number"then return b(false)end
return c.ElementModel.act(a.id,"pictureFrom",{path=a.path,icon=d.icon})
end
function e.alert(a,d,g,h)
local d=c.AlertWhen
local i=d.read(c.ElementModel.view(a.id)or{})
local c,e
if i.mode=="none"then
c,e=d.write(a.id,a.kind.key,g,{exact=h.pin})
else
c,e=d.setSpell(a.id,g,h.pin)
end
return b(c,f(e))
end




function d.pick(f,d)
if not d then return b(false)end
if c.Combat.inCombat()then return b(false,a.waits)end
if d.refused then return b(false,d.reason)end
local a=m(f)
local c=g(a,d)
if c==nil then return b(false)end
local e=e[f.at]
if not e then return b(false)end
return e(f,a,c,d)
end


function d.ask(a)
if a.at~="alert"then return nil end
return c.AlertWhen.replacesLine(c.ElementModel.view(a.id))
end
