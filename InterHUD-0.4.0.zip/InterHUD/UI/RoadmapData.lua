


local b,a=...
a.RoadmapData={
new={
{
key="v0.4.0",
version="0.4.0",
date="",
summary="Scrolling combat text, swing timers and many new Sources for building Elements, all still experimental. And many other ongoing refinements and fixes.",
highlights={{1,"Scrolling combat text, a new special. Incoming damage, heals and other events appear in areas you place on your screen. It is experimental."},{1,"New sources: Health, Power, Combo points, Cast, the Five-second rule, Swing and Range. All are experimental."},{2,"Health: a health bar with incoming heals, shields and heal absorbs drawn on it. It knows Low, Full and Dead, and when its unit appears, dies or leaves."},{2,"Power: mana, rage or energy as a bar or text, with Low and Full. On a mana bar it can draw the cost of the spell you are casting."},{2,"Combo points: your points on your target as a bar of points, with looks for a set number of points, and events when you gain one, reach full or drop to none."},{2,"Cast: build your own cast bar. It knows casting from channelling, when a cast can't be interrupted, and when one starts or gets interrupted. On your own casts it also knows when one finishes or is cancelled."},{2,"Five-second rule: the window after you spend mana, before it regenerates again, with events when it pauses and resumes."},{2,"Swing: the time to your next auto attack with your main hand, off hand or ranged weapon, with events when a hand swings and when its next attack comes due."},{2,"Range: an estimate of how far away your target is, as text or as looks that change between the ranges your character can tell apart."},{2,"Health, Power and Cast can watch you, your target, your pet or your focus target. The Aura source can now watch your pet and your focus target too."},{1,"Swing timer pre-mades: using the new Swing source, new pre-made elements have been drafted for different variations of swing timer scenarios and functionality."},{1,"The swing timer special is gone, and its settings are not carried over. Swing timers are now ordinary elements built on the Swing source."},{1,"A debuff on your target or focus target can count anyone's cast, not only yours, for shared debuffs like Sunder Armor. It is experimental."}},
approved=true,
},
{
key="v0.3.0",
version="0.3.0",
date="",
summary="InterHUD is an ambitious project. It's an addon designed to allow maximum flexibility and customisation for creating dynamic HUD elements: cooldowns, buffs, procs, and many more. This is still an early beta. Expect rough edges and many changes.",
highlights={{1,"A fresh start with WoW Forever release. How InterHUD stores elements & profiles has changed in version 0.3, so profiles from WoW Forever Beta (addon version 0.2) don't carry over."},{1,"A companion website at interhud.com. You can browse pre-made elements there, and build or edit elements and whole profiles in the web-builder, then import them into the addon in-game."},{1,"Many pre-made HUD elements have been created. These are early drafts which have not yet been tested in-game, but they can act as a useful starting point."},{1,"A rebuilt options window structure. Each element's page lays out its sources, layers, looks and effects."},{1,"Elements use \"sources\", information the game provides, to drive their visual logic. Sources currently include: auras on self or target, spells (including cooldowns and abilities with dynamic resets), items and reagents, totems, weapon imbues and poisons, your breathing/drowning status. Many more sources are in the works."},{1,"Elements use \"layers\" to add visual things onto the HUD. Layer types include: icons, timer bars, stack/count segmented bars, text, and spell alert art. These can be mixed together within the same element. The appearance, styles and effects played on an element's layers come from the element's sources."},{1,"Elements can be placed in groups for purposes of HUD layout. Groups have different arrangement modes, e.g. row, column, grid, freeform."},{1,"Elements and groups can be previewed and dragged around within unlocked mode. Individual elements within groups, or individual layers within elements, can also be dragged within unlocked mode."},{1,"Export and import elements, groups or whole profiles. InterHUD also accepts imports from ShamanForever profiles (a different addon)."},{1,"A totem bar for shamans. This is the addon's first 'special'; a hand-coded feature, rather than a fully data-defined element which users can build. This approach is needed for certain complex features."}},
approved=true,
},
},
soon={
{
key="premades-refined-and-expanded",
title="Pre-made elements refined and expanded",
words={{0,"Currently, almost all pre-made elements are in 'Draft' status, meaning they've not had sufficient in-game testing. Pre-mades are being refined in play now that WoW Forever is live, and more will be designed and created."}},
approved=true,
},
{
key="sources-more",
title="More sources, and more from each source",
words={{0,"The sources added in 0.4 are still being tested and refined in play. Sources will keep improving: more states, facts and events from each one, and more settings for how they behave. New sources are on the way too: stances and forms, consumables, trinkets and other on-use items."}},
approved=true,
},
{
key="more-sounds",
title="More sounds",
words={{0,"The sound effects available in 0.3 are very limited. A much broader sound library will be added soon, along with more sound channel and volume settings."}},
approved=true,
},
{
key="groups-dynamic-positioning",
title="Groups with dynamic element positioning",
words={{0,"Improved group arrangement options, including letting groups of elements (e.g. debuffs on target) grow and collapse from an anchor, rather than leaving gaps when an element is not shown."}},
approved=true,
},
},
later={
{
key="collections",
title="Ready-to-play curated collections",
words={{0,"Full HUD collections for more classes, put together by hand. My workflow can create individual pre-made elements rather easily, but full HUDs need much more time, effort and experience."}},
approved=true,
},
{
key="quick-settings",
title="Better Pre-made Quick Settings system",
words={{0,"InterHUD is built on powerful foundations to enable broad capabilities and flexibility, which unfortunately makes it less intuitive to use for quick casual customisation. The Quick Settings panel included in pre-mades is a start, but has much room for refinement."}},
approved=true,
},
{
key="ai-skills-mcp-server",
title="Build InterHUD elements with AI",
words={{0,"Core to InterHUD's foundations is a data model which gives extreme flexibility and customisation for users who really wish to tinker with it. Given a suitable SKILL.md, AI can already reliably create high-quality HUD elements with complex conditional logic. The next extension to this is providing an MCP server via interhud.com to allow users to have their AI tool of choice design and refine elements, or a full HUD, with live feedback in the web-builder, ready to import in-game."}},
approved=true,
},
},
maybe={
{
key="midnight",
title="Midnight Retail support",
words={{0,"Support for the Midnight Retail client. Maybe."}},
approved=true,
},
},
issues={
{
key="ui-scale-and-resolution",
title="UI scales and resolutions",
words={{0,"How InterHUD handles imports & exports from players using different UI scales and resolutions needs some work."}},
approved=true,
},
},
}
