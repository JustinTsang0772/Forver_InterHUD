


local a,e=...
local c,i,v,j,a,o=e.Store,e.Resolve,e.Form,e.Spells,e.Kit,e.Placement
local w,h,l,f,x,y=e.HUD,e.Combat,e.Groups,e.Layers,e.Events,e.Specials
local q=e.PreviewMode

local b={}
e.Window=b



b.PAGES={
{key="styles",label="Settings & styles",icon="iconGlobal"},
{key="profiles",label="Profiles & sharing",icon="iconProfiles"},
{key="about",label="About",icon="iconAbout"},
}


b.SPECIALS_ICON="Interface\\Icons\\INV_Misc_Rune_01"



function b.isAlert(a)return a~=nil and e.Schema.holdsAlert(a)end

local function k(a)return tostring(a):lower()end












local m,n,s,d=nil,nil,nil,0
local g={}
local p={ui=true,group=true,styles=true,settings=true,char=true,special=true}
e.onChanged(function(a,b)
d=d+1
if a=="element"and b~=nil then
g[b]=nil
elseif not p[a]then
wipe(g)
end
end,"window entries")
local p={}
j.onChange("window entries",function()
d=d+1
wipe(g)
wipe(p)

a.repaint()
end)
local r
function b.entries(a)
if a~=nil then return r(a,{})end
local a=c.profile()
if not(m and n==a and s==d)then
if n~=a then wipe(g)end
m,n,s=r(a or{},g),a,d
end
return m
end
function r(f,h)
local a={{kind="home",key="home",label="Home",depth=0},
{kind="new",key="new",label="New",depth=0}}
local c,j,l,g,m={},{},{},{},{}
for d,a in ipairs(f.elements or{})do
local d=h[a.id]
if not d then
local c=i.element(a,f)
d={v.nameOf(c),not c.enabled,not e.ElementModel.elementLearned(c),b.isAlert(a)}
h[a.id]=d
end
c[a.id],j[a.id],l[a.id],g[a.id]=d[1],d[2],d[3],d[4]
end

local d={}
for b,a in ipairs(f.groups or{})do
if a.enabled==false then for b,a in ipairs(a.members or{})do d[a]=true end end
end
local function e(a,b)
return{kind="element",id=a,label=c[a],depth=b or 2,off=j[a]or d[a],
unlearned=l[a]or nil,alert=g[a]or nil}
end
local function h(a,b)
if k(c[a])~=k(c[b])then return k(c[a])<k(c[b])end
return a<b
end
a[#a+1]={kind="groups",key="groups",label="Elements",depth=0,fixed=true,top=true}
for d,b in ipairs(f.groups or{})do
local d={kind="group",id=b.id,label=b.name or b.id,depth=1,parent=true,
off=b.enabled==false,count=0}
a[#a+1]=d
for f,b in ipairs(b.members or{})do

if c[b]and not g[b]then
m[b]=true
a[#a+1]=e(b)
d.count=d.count+1
end
end
end
local c,d={},{}
for b,a in ipairs(f.elements or{})do
if g[a.id]then
d[#d+1]=a.id
elseif not m[a.id]then
c[#c+1]=a.id
end
end
table.sort(c,h)
table.sort(d,h)

if#c>0 then
a[#a+1]={kind="loose",key="loose",label="Not in a group",depth=1,parent=true,
count=#c}
for c,b in ipairs(c)do a[#a+1]=e(b)end
end


a[#a+1]={kind="alerts",key="alerts",label="Spell Alerts",depth=1,parent=true,
count=#d}
for c,b in ipairs(d)do a[#a+1]=e(b)end

a[#a+1]={kind="specials",key="specials",label="Specials",depth=0,foot=true}
for c,b in ipairs(y.list(f))do
if b.state=="on"then
a[#a+1]={kind="special",id=b.key,label=b.label,icon=b.icon,page=b.page,depth=1,
nolist=true}
end
end
for c,b in ipairs(b.PAGES)do
a[#a+1]={kind="page",key=b.key,label=b.label,icon=b.icon,foot=true}
end
return a
end



function b.iconOf(g)
local b=c.element(g)
if b and b.menuIcon then return e.Media.drawable(b.menuIcon)end
local c=p[g]
if c and c.rec==b then return c.icon end
local d=b and type(b.sources)=="table"and b.sources[1]
local f=d and j.firstOf(d.spells)
local c=f and select(2,j.highest(f))

if f and not c then
local a=j.icon(f)
c=not e.isSecret(a)and a or nil
end

if c then
p[g]={rec=b,icon=c}
return c
end

local b=not c and d and e.Sources.get(d.kind)
if b and b.icon then c=b.icon(d)end
return c or a.art("iconUnknown")
end







local function g(a,b,c)
local d,e=UIParent:GetSize()
local a=f.OFFSETS[a]or f.OFFSETS.CENTER
return a[1]*d+b,(1-a[2])*e+c
end

local function j(b,c,d,a)
local b=f.OFFSETS[b]or f.OFFSETS.CENTER
return c+(0.5-b[1])*a,d-(0.5-b[2])*a
end
local function d(a)return math.floor(a*2+0.5)/2 end


function b.screenCentre(h)
local a=c.element(h)
if not a then return nil end
local e=i.element(a,c.profile())

local k,b=e.baseSize*e.scale,e.position
local a=c.groupOf(h)
if not a then
local a,c=g(b.point,b.x,b.y)
return j(b.point,a,c,k)
end
local a=l.groups[a]
local c=a and a.view
if not c then return nil end
local i,d=c.scale,c.position
if c.arrangement=="free"then

local a,c=g(d.point,d.x,d.y)
return j(b.point,a+b.x*i,c+b.y*i,k*i)
end

if c.enabled==false or not(a.w and a.h)then return nil end

local d,g=g(d.point,d.x,d.y)
local b=f.OFFSETS[l.anchorPoint(c)]
local c,d=d-b[1]*a.w,g+b[2]*a.h
local b=l.slotOf(h)
if not b then return c+a.w/2,d-a.h/2 end

local a=b.scale
return c+b.x*a+e.baseSize*a/2,d+b.y*a-e.baseSize*a/2
end


function b.placeFor(e,a)
local b,e=b.screenCentre(e)
if not b then return nil end
if a==nil then
local a,c=UIParent:GetSize()
return{point="CENTER",x=d(b-a/2),y=d(e-c/2)}
end
local a=c.group(a)
local a=a and i.group(a,c.profile())
if not a or a.arrangement~="free"then return nil end
local c,f=g(a.position.point,a.position.x,a.position.y)
return{point="CENTER",x=d((b-c)/a.scale),y=d((e-f)/a.scale)}
end


function b.moveElement(a,d,e)
local f=c.groupOf(a)
return c.moveElement(a,d,e,f~=d and b.placeFor(a,d)or nil)
end


b.onSwitch={title="InterHUD",tip="Off hides the HUD and stops it watching anything.",
get=function()return not w.off()end,
set=function(a)return c.editChar(function(b)b.off=not a or nil end)end}




local I,j=12,10
local z=1
local g=6


local A,B,C,J=22,26,8,10
local D=8
local m,d={},{}
local f
local r,E
local s={}
local F,G={},{}

local function k(a)return a.kind..":"..tostring(a.id or a.key or"")end
local function l(b)return("list:"..k(b)):sub(1,a.KEY_MAX)end


local function t(b)
if b.kind=="element"then return e.PageElement.keyFor(b.id),b.id end
if b.kind=="new"or b.kind=="home"then return a.hasPage(b.key)and b.key or nil end
if b.kind=="group"then return a.hasPage("group")and"group"or nil,b.id end
if b.kind=="special"then return a.hasPage(b.page)and b.page or nil,b.id end
if b.kind=="specials"then return a.hasPage("specials")and"specials"or nil end
if(b.kind=="groups"or b.kind=="loose"or b.kind=="alerts"or b.kind=="page")and a.hasPage(b.key)then
return b.key
end
end

local function u(c)
local d,g=t(c)
if not d then return end
f=k(c)
a.window():showPage(d,g)
b.paintList()


if c.kind=="element"and c.alert and e.Placement.unlocked()then e.Placement.select(c.id)end
end



local function p(c)
local c=CreateFrame("Button",nil,c)
c:EnableMouse(true)
c.sel=c:CreateTexture(nil,"BACKGROUND")
c.sel:SetAllPoints()
a.fill(c.sel,"accent",0.16)
c.accent=c:CreateTexture(nil,"ARTWORK")
c.accent:SetWidth(3)
a.fill(c.accent,"accent")
local d=c:CreateTexture(nil,"HIGHLIGHT")
d:SetAllPoints()
a.fill(d,"white",0.05)
c.icon=c:CreateTexture(nil,"ARTWORK")
a.cropIcon(c.icon)

c.mark=c:CreateTexture(nil,"OVERLAY")
c.mark:SetSize(14,14)
c.mark:SetPoint("RIGHT",-4,0)
c.mark:SetVertexColor(a.rgba("off"))

c.dot=c:CreateTexture(nil,"OVERLAY")
c.dot:SetSize(6,6)
a.fill(c.dot,"gold")
c.dot:Hide()
c.text=a.fontString(c,"listTop")
c.text:SetPoint("LEFT",c.icon,"RIGHT",8,0)
c.text:SetPoint("RIGHT",-4,0)
c.text:SetJustifyH("LEFT")

c:SetScript("OnEnter",function(b)
if b.entry and b.cut then a.note(b,b.entry.label)end
end)
c:SetScript("OnLeave",function()a.note()end)
c.fold=CreateFrame("Button",nil,c)
c.fold:SetSize(j,a.theme.metric.sidebar.row)
c.fold:EnableMouse(true)
c.fold.arrow=a.arrow(c.fold,"down",10)
c.fold.arrow:SetPoint("CENTER")
c.fold:SetScript("OnClick",function()
local c=c.entry
if c then
a.setFolded(l(c),not a.isFolded(l(c)))
b.paintList()
end
end)


c:RegisterForClicks("LeftButtonUp","RightButtonUp")
c:SetScript("OnClick",function(d,e)
local c=d.entry
if not c then return end

if e=="RightButton"then return b.rowMenu(d)end
if c.parent and not c.fixed then
local b=l(c)
if f==k(c)then a.setFolded(b,not a.isFolded(b))
elseif a.isFolded(b)then a.setFolded(b,false)end
end
u(c)
end)
return c
end



local function K(a,b,c,d,e,f)
return table.concat({a.kind,tostring(a.id or a.key),tostring(a.label),tostring(a.icon),a.depth or"",b,tostring(c),
a.foot and 1 or 0,a.action and 1 or 0,a.off and 1 or 0,a.unlearned and 1 or 0,a.never and 1 or 0,
a.parent and 1 or 0,a.fixed and 1 or 0,d and 1 or 0,e and 1 or 0,f and 1 or 0,a.count or""},"\31")
end




local function L(b,c,g,e)
local f=a.WRAP_SPARE
b:SetFontObject(a.font(c))
b:SetJustifyH("LEFT")


b:SetWordWrap(true)
b:SetText(g)

if b:GetStringWidth()+f<=e then return 1,false end
local a,c,d=_G[a.font(c)]:GetFont()
b:SetFont(a,c-z,d)
b:SetText(g)
if b:GetStringWidth()+f<=e then return 1,false end
local c,a,d={},nil,false
for g in g:gmatch("%S+")do
local h=a and a.." "..g or g
b:SetText(h)
local i=b:GetStringWidth()+f>e
if i and a then
c[#c+1]=a
b:SetText(g)
d=d or b:GetStringWidth()+f>e
a=g
else
d=d or i
a=h
end
end
c[#c+1]=a
b:SetText(table.concat(c,"\n"))
return#c,d
end


local function H(a)return a.kind=="group"or a.kind=="loose"or a.kind=="alerts"end



local function M(b)
local a=a.theme.metric.sidebar
if H(b)then return a.group,a.group,0 end
if b.foot or b.kind=="new"then return a.foot,a.footStep,a.topIcon end
if b.depth==0 then return a.top,a.topStep,a.topIcon end
return a.row,a.rowStep,a.icon
end



local function n(c,d,i,p)
local m,q,n=M(d)
c.entry=d
local h=H(d)
local g
if d.kind=="element"then g=b.iconOf(d.id)
elseif d.kind=="groups"then g=a.art("iconElements")
elseif d.kind=="alerts"then g=a.art("iconAlerts")
elseif d.kind=="specials"then g=b.SPECIALS_ICON
elseif d.kind=="home"then g=a.art("logoSmall")
elseif d.kind=="special"then g=d.icon or a.art("iconUnknown")
elseif d.kind=="new"then g=a.art("iconNew")
else g=a.art(d.icon)end

local o=d.action or d.kind=="element"or t(d)~=nil
local b=f==k(d)

if not b and f and d.kind=="specials"then b=f:find("^special:")~=nil end
local k=d.parent and not d.fixed and a.isFolded(l(d))
local f=K(d,i,g,o,b,k).."\31"..p
if c.sign==f and c.theme==a.theme then return m+c.extra,c.extra,q end
c.sign,c.theme=f,a.theme
c.icon:SetSize(n,n)
c.icon:ClearAllPoints()
c.icon:SetPoint("LEFT",i+j,0)
c.icon:SetShown(not h)
if not h then c.icon:SetTexture(g)end
c.text:SetPoint("LEFT",h and c or c.icon,h and"LEFT"or"RIGHT",h and i+j or 8,0)
local g=not o or d.off or d.unlearned or d.never

local f=d.off and"markOff"or(d.unlearned or d.never)and"markUnlearned"or nil
c.mark:SetShown(f~=nil)
if f then c.mark:SetTexture(a.art(f))end

local f=f and 22 or 0
c.text:SetPoint("RIGHT",f>0 and-f or-1,0)
c.textLeft,c.textRight=i+j+(h and 0 or n+8),f>0 and f or 1
local f=d.kind=="element"or d.kind=="special"
local h=h and a.theme.metric.sidebar.groupFont or(f or d.action)and"listSub"or"listTop"

local j=d.label
if k and(d.count or 0)>0 then
j=d.label.." "..a.colorCode("dimText").."("..d.count..")|r"
end
local l
l,c.cut=L(c.text,h,j,p-c.textLeft-c.textRight)

c.extra=(l-1)*(a.fontSize(h)-z)
c:SetHeight(m+c.extra)

a.tint(c.text,g and"off"or b and"white"or f and"listSub"
or d.action and"link"or"gold")
c.icon:SetDesaturated(g and true or false)
local e=d.kind=="page"and d.key=="about"and e.Roadmap~=nil and e.Roadmap.anyUnseen()
c.dot:SetShown(e and true or false)
if e then
c.dot:ClearAllPoints()

c.dot:SetPoint("LEFT",c.text,"LEFT",c.text:GetStringWidth()+6,1)
end
c:EnableMouse(o and true or false)
c.sel:SetShown(b)
c.accent:SetShown(b)
c.accent:ClearAllPoints()

c.accent:SetPoint("TOPLEFT",1,-4)
c.accent:SetPoint("BOTTOMLEFT",1,4)
c.fold:SetShown(d.parent and not d.fixed and true or false)
if d.parent and not d.fixed then
c.fold:ClearAllPoints()
c.fold:SetPoint("LEFT",i,0)
c.fold:SetHeight(m)
a.setArrow(c.fold.arrow,k and"right"or"down")
end
return m+c.extra,c.extra,q
end


function b.toggleUnlock()
o.setUnlocked(not o.unlocked())
b.paintList()
end
function b.unlockWords()return o.unlocked()and"Lock positioning"or"Unlock positioning"end


function b.togglePreview()
q.toggle()
b.paintList()
end
function b.previewWords()return q.isOn()and"End preview"or"Preview"end



local function j(h)
local c=h.listColumn

local function i(d,e)
for g,f in ipairs({{0,0.45},{0.45,0}})do
local b=c:CreateTexture(nil,"ARTWORK")
a.fill(b,"white")
b:SetGradient("HORIZONTAL",a.colorObj("rule",f[1]),a.colorObj("rule",f[2]))
b:SetHeight(a.linePx(c,1))
local a,d=e and"TOP"or"BOTTOM",e and-d or d
if g==1 then
b:SetPoint(a.."LEFT",8,d)
b:SetPoint(a.."RIGHT",c,a,0,d)
else
b:SetPoint(a.."LEFT",c,a,0,d)
b:SetPoint(a.."RIGHT",-8,d)
end
end
end
d.home=p(c)
d.home:SetPoint("TOPLEFT",0,0)
d.home:SetPoint("TOPRIGHT",0,0)

d.home.icon:SetTexCoord(0,1,0,1)
local e=a.theme.metric.sidebar
i(e.topStep+g,true)

local f=e.topStep+2*g
d.elements=p(c)
d.elements:SetPoint("TOPLEFT",0,-f)
d.elements:SetPoint("TOPRIGHT",0,-f)


local function j(d,b)
local a=a.button(c,d,nil,A)
a:SetPoint("BOTTOMLEFT",C,b)
a:SetPoint("BOTTOMRIGHT",-C,b)
return a
end
d.unlock=j("Unlock positioning",0)
d.unlock:SetScript("OnClick",b.toggleUnlock)
a.setTip(d.unlock,"Positioning","Drag elements and groups on screen. /ihud unlock and lock do the same.")
d.preview=j("Preview",B)
d.preview:SetScript("OnClick",b.togglePreview)
a.setTip(d.preview,"Preview","Every element switched on, in a made-up moment. Combat ends it.")

q.onToggle("window",a.repaint)

local j=o.frames.bar
j:HookScript("OnShow",a.repaint)
j:HookScript("OnHide",a.repaint)
d.foot={}
local a=B+A+J
local function j()
local b=p(c)
b:SetPoint("BOTTOMLEFT",0,a)
b:SetPoint("BOTTOMRIGHT",0,a)
a=a+e.footStep
return b
end
for a=#b.PAGES+1,1,-1 do d.foot[a]=j()end
d.new=j()

i(a+g)
h:setListInsets(f+e.topStep+2,a+2*g)
end


function b.paintList()
local g=a.window()
if not d.new then j(g)end
local i,j,t=0,0,0

local o=g.listW-16
local q
wipe(s)
for c,b in ipairs(b.entries())do
if b.kind=="home"then
n(d.home,b,0,o)
elseif b.kind=="new"then
n(d.new,b,0,o)
elseif b.top then
n(d.elements,b,0,o)
elseif b.foot then
t=t+1
n(d.foot[t],b,0,o)
elseif not b.nolist and not(q and b.depth>q)then

q=nil
j=j+1
local c=m[j]or p(g.listContent)
m[j]=c
local d=b.depth*I
local d,e,f=n(c,b,d,o-D)

if c.placedY~=i then
c:ClearAllPoints()
c:SetPoint("TOPLEFT",g.listContent,"TOPLEFT",0,-i)
c:SetPoint("TOPRIGHT",g.listContent,"TOPRIGHT",-D,-i)
c.placedY=i
end
c:Show()
s[k(b)]={i,d}
F[j],G[j]=i,d
i=i+f+e
if b.parent and not b.fixed and a.isFolded(l(b))then q=b.depth end
end
end
for a=j+1,#m do m[a]:Hide()end
g:setListRows(F,G,m,j)
g:setListHeight(i)
d.unlock.say(b.unlockWords())
d.preview.say(b.previewWords())

if w.off()then
g:setBand("InterHUD is off. /ihud on to turn it back on.","off")
elseif h.inCombat()then
g:setBand("In combat: some changes wait until it ends.")
else
g:setBand(nil)
end


local b,a=(f or""):match("^(%a+):(.*)$")
local d,h=g:page()
if b=="element"then
if not c.element(a)then
f=nil
g:clearPage()
elseif d and e.PageElement.isKey(h)and h~=e.PageElement.keyFor(a)then


local b=d.target==a and r==a and E==e.PageElement.pickOf(a)
and d.scroll:GetVerticalScroll()
local a=g:showPage(e.PageElement.keyFor(a),a)
if b and b>0 then a.scroll:SetVerticalScroll(b)end
end
r,E=a,e.PageElement.pickOf(a)
elseif b=="group"and not c.group(a)then
f=nil
g:clearPage()
end
if b~="element"then r=nil end
end


h.onStart("window",a.repaint)
h.onEnd("window",a.repaint)




local function m(a,b)return a.." "..b..(a==1 and""or"s")end
local function d(b)
local a={}
local b=c.group(b)
for d,b in ipairs(b and b.members or{})do
if c.element(b)then a[#a+1]=b end
end
return a
end



local function g(d,a)
if d=="group"then return"groups","groups"end
if b.isAlert(c.element(a))then return"alerts","alerts"end
local d=c.groupOf(a)
if d then return"group",d end

for e,d in ipairs(c.profile().elements or{})do
if d.id~=a and not c.groupOf(d.id)and not b.isAlert(d)then return"loose","loose"end
end
return"page","home"
end


local function j(a,b,c)
if f==a..":"..tostring(b)then return true end
for b,a in ipairs(c or{})do
if f=="element:"..a then return true end
end
return false
end

function b.deleteElement(a)
if h.inCombat()or not c.element(a)then return false end
local d,e,f=j("element",a),g("element",a)
local a,c=c.removeElement(a)
if a and d then b.select(e,f)end
return a,c
end


function b.deleteGroup(a,e)
if h.inCombat()or not c.group(a)then return false end
local d=d(a)
local f={}
if not e then
for c,a in ipairs(d)do f[a]=b.placeFor(a,nil)end
end
local d=j("group",a,e and d or nil)
local c,e=c.deleteGroup(a,e,f)
if c and d then b.select(g("group",a))end
return c,e
end


local g={}
a.confirm("DELETE_ELEMENT","%s","Delete",function(a)b.deleteElement(a)end)
a.confirm("DELETE_GROUP","%s","Delete",function(a)b.deleteGroup(a,false)end)
a.confirm("DELETE_GROUP_ALL","%s","Delete",function(a)b.deleteGroup(a,true)end)
local function j(b,c,d)
g["INTERHUD_"..b]=a.showPopup(b,c,d)
end


function b.deleteElementWords(a)
local a=c.element(a)
return a and("Delete the element \""..v.nameOf(i.element(a,c.profile())).."\"?")or nil
end
function b.deleteGroupWords(b,e)
local a=c.group(b)
if not a then return nil end
local a,b=a.name or a.id,#d(b)
if e then return"Delete the group \""..a.."\" and its "..m(b,"element").."?"end
if b>0 then return"Delete the group \""..a.."\"? Its elements stay, in Not in a group."end
return"Delete the group \""..a.."\"?"
end
function b.askDeleteElement(a)
if not c.element(a)or h.inCombat()then return end
j("DELETE_ELEMENT",b.deleteElementWords(a),a)
end
function b.askDeleteGroup(a,d)
if not c.group(a)or h.inCombat()then return end
j(d and"DELETE_GROUP_ALL"or"DELETE_GROUP",b.deleteGroupWords(a,d),a)
end




local i=24
function b.duplicateElement(a)
local a,d,c=b.duplicate(a)
if a then b.select("element",c)end
return a,d,c
end

function b.duplicate(a)
local f=c.element(a)
if not f then return false end
local d=c.groupOf(a)
local g=d and not c.full("members",d)and d or nil
local d={name=e.Share.duplicateName(f,c.profile())}
local b=b.placeFor(a,g)
if b then d.position={point=b.point,x=b.x+i,y=b.y-i}end
return c.duplicateElement(a,d)
end


function b.looseEntries(a)
local c,d={},false
for b,a in ipairs(a or b.entries())do
if a.kind=="loose"then
d=true
elseif d and a.kind=="element"and a.depth==2 then
c[#c+1]=a
elseif d then
break
end
end
return c
end



local function i(b,a)
local b=#d(b)>0
a[#a+1]={value="delete",label=b and"Delete group, keep its elements"or"Delete group"}
if b then
a[#a+1]={value="deleteAll",label="Delete group and its elements"}
end
return a
end
local function j(a,c)b.askDeleteGroup(a,c=="deleteAll")end


function b.groupDeleteMenu(d,b)
if h.inCombat()or not c.group(b)then return end
a.openMenu(d,i(b,{}),function(a)j(b,a)end)
end



function b.moveMenu(i,f,h)
local g=c.groupOf(f)
local d={}
for b,a in ipairs((c.profile()or{}).groups or{})do
d[#d+1]={value=a.id,label=a.name or a.id,checked=a.id==g}
end
d[#d+1]={value=false,label="Not in a group",checked=g==nil}
a.openMenu(i,d,function(a)
if(a or nil)==g then return end
local b,a=b.moveElement(f,a or nil)
if h then return h(b,a)end
e.PageElement.answer(f,{ok=b,line=a and a[1]and a[1].text})
end)
end








local function m(f,d,b)
local e=d=="group"and c.group(b)or c.element(b)
if not e then return end
a.askInline(f,"Name",e.name or"",function(a)
local a=strtrim(a or"")
local c=d=="group"and c.editGroup or c.editElement
if not c(b,function(b)b.name=a~=""and a or nil end)then return"That name can't be used."end
end)
end

function b.rowMenu(f)
local d=f.entry
if not d or(d.kind~="group"and d.kind~="element")or h.inCombat()then return end
if d.kind=="group"then
if not c.group(d.id)then return end
local c={{value="settings",label="Group settings"},{value="rename",label="Rename"},
{divider=true}}
return a.openMenu(f,i(d.id,c),function(a)
if a=="settings"then
b.select("group",d.id)
elseif a=="rename"then
m(f,"group",d.id)
else
j(d.id,a)
end
end)
end
local c={{value="rename",label="Rename"},{value="duplicate",label="Duplicate element"},
{value="export",label="Export element"}}
if not d.alert then c[#c+1]={value="move",label="Move to…"}end
c[#c+1]={value="delete",label="Delete element"}
a.openMenu(f,c,function(a)
if a=="rename"then
m(f,"element",d.id)
elseif a=="duplicate"then
b.duplicateElement(d.id)
elseif a=="export"then
e.PageShare.exportElement(d.id)
elseif a=="move"then
b.moveMenu(f,d.id)
else
b.askDeleteElement(d.id)
end
end)
end


h.onStart("window deletes",function()
for b,a in pairs(g)do
if a and a:IsShown()and a.which==b then a:Hide()end
g[b]=nil
end
local b=a.menuOwner()
if b and((b.entry and b.fold)or b.deleteMenu)then a.closeMenu()end
end)


function b.select(e,g)
local h=e..":"..tostring(g)
local d={}
for c,b in ipairs(b.entries())do
if not b.foot then d[b.depth]=b end
if k(b)==h then
for b=0,(b.depth or 0)-1 do
if d[b]and d[b].parent then a.setFolded(l(d[b]),false)end
end
u(b)
local b=s[h]
if b then a.window():revealList(b[1],b[2])end
return true
end
end

if e=="special"then
for d,c in ipairs(y.list(c.profile()))do
if c.key==g then
local c,d=t({kind="special",id=c.key,page=c.page})
if not c then return false end
f="specials:specials"
a.window():showPage(c,d)
b.paintList()
return true
end
end
end
return false
end


function b.showUnder(c,d)
f=d
a.window():showPage(c)
b.paintList()
end



function b.openNew(c,d)
f="new:new"
e.New.start=e.NewModel.tabOf(d)
a.window():showPage("new",c)
b.paintList()
end



function b.open()
local a=a.window()
a.onRepaint=b.paintList

if not a.releasesData then
a.releasesData=true
a.frame:HookScript("OnHide",function()e.GameData.release()end)
end

local c=false
if not a:isShown()then
a:open()
c=true
end
if not f then
for b,a in ipairs(b.entries())do
if a.kind=="home"then
u(a)
c=true
break
end
end
end
if not c then b.paintList()end
end

function b.toggle()
local c=a.window()
if c:isShown()then
c:hide()
return
end

local c=a.clock()
b.open()
local b=a.clock()
a.timed("open",b-c)
x.atFrameEnd("window opened",function()
x.atFrameEnd("window opened 2",function()a.timed("open frame",a.clock()-c)end)
end)
end


function b.describe()
local a=a.speed
local function c(b,c)
local a=a[b]
if not a then return nil end
return string.format("%s %d (first %.0f ms, latest %.0f ms, slowest %.0f ms, mean %.1f ms)",c,a.n,a.first,
a.last,a.max,a.sum/a.n)
end
local a={}
for d,b in ipairs({{"open","opens"},{"open frame","their frames"},{"repaint","repaints"},
{"page built","pages built"},{"entry built","entries built"},{"drag frame","sidebar drag frames"}})do
a[#a+1]=c(b[1],b[2])
end
return{"window: "..(#a>0 and table.concat(a,"; ")or"not opened yet")}
end
