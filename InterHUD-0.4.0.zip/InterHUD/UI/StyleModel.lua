


local a,d=...
local b,c,e,j,k,g,f=d.Form,d.Store,d.Styles,d.Clean,d.Resolve,d.Schema,
d.GameCastBar

local a={}
d.StyleModel=a


a.PAGE={title="Settings & styles"}

a.EXPLORER={title="Styles Explorer",line="Browse every style"}
a.TABS={{key="settings",label="Settings",icon="Interface\\Icons\\Trade_Engineering",
line="How the whole addon behaves."},
{key="styles",label="Styles",icon="Interface\\Icons\\INV_Misc_Gem_01",line="How elements look, and presets."}}
a.LOOKS_TITLE="Button cues"
a.RESET="Reset to defaults"

local function h(a)return g.field("profileSettings",a).help end

local i={
silence="The game refused to hide its cast bar; it still shows.",
rearm="Blizzard's cast bar comes back after you reload the interface (/reload).",
}
function a.castBarRefused()
local a=f.refused()
return a and i[a]
end



a.SETTINGS={
{key="general",title="General",rows={
{kind="minimap",label="Minimap button"},
{kind="setting",name="cantAct",hint="When the HUD is greyed out or hidden, it also plays no pops or"
.." sounds."},
{kind="setting",name="fadeTime",hint="How long an element takes to fade when it hides or dims. It"
.." always comes back at once."},
{kind="setting",name="spellIdTooltips"},
{kind="setting",name="hideCastBar",refused=a.castBarRefused},
}},
{key="sounds",title="Sounds",rows={
{kind="setting",name="soundChannel"},
}},
{key="misc",title="Misc",rows={
{kind="setting",name="showUnlearned",hint=h("showUnlearned")},
}},
}



function a.setting(a)
local a=g.field("profileSettings",a)
if a.type=="number"then return{field=a,label=a.label,widget="slider",unit=a.unit}end
if a.type=="boolean"then return{field=a,label=a.label,widget="toggle"}end
local b={}
for d,c in ipairs(a.choices)do b[d]={c,a.labels[c]}end
return{field=a,label=a.label,widget="choice",choices=b}
end
function a.settingValue(a)return c.settings()[a]end
function a.setSetting(a,b)return(c.editSettings(function(c)c[a]=b end))end


local f,h,i=nil,nil,{}
d.onChanged(function()
f,h=nil,nil
wipe(i)
end,"style model")
function a.styles()
if not f then f=b.styles()end
return f
end
function a.looks()
if not h then h=b.buttonCues()end
return h
end


function a.sections()return b.styleSections(a.styles(),e.ranked())end
function a.lookSections()return b.lookSections(a.looks())end


function a.target(b,a)
if a~=nil and not c.preset(b,a)then return nil end
return a
end

function a.view(d,c)
c=a.target(d,c)
if not c then return a.styles()end
local a=d.."\0"..c
if not i[a]then i[a]={[d]=b.presetStyle(d,c)or{}}end
return i[a]
end

function a.write(d,c,e,f)
c=a.target(d,c)
if c then return b.setPresetStyle(d,c,e,f)end
return b.setStyle(e,f)
end
function a.writeLook(a,c)return b.setFactLook(a,c)end



function a.chips(e,d)
d=a.target(e,d)
local b={{kind="global",label="Global",picked=d==nil}}
for c,a in ipairs(c.presets(e))do
b[#b+1]={kind="preset",label=a.name,picked=d==a.id,id=a.id}
end
if a.roomForPreset(e)then b[#b+1]={kind="new",label="+ New preset",picked=false}end
return b
end

function a.roomForPreset(a)return not e.isLook(a)and#c.presets(a)<g.PRESETS_MAX end




local function f(c,d)
local e=d and b.globalFactLook(c.part)or not d and b.globalStyle(c.part)
if not e then return false end
local e={[c.part]=e}
for f,c in ipairs(c.rows)do
if c.field and c.path and b.read(e,c.path)~=nil and b.shown(c,d and a.looks()or a.styles())then
return true
end
end
return false
end

function a.canReset(b,d,c)
if not c and a.target(b.part,d)~=nil then return false end
return f(b,c)
end
function a.resetConfirm(a)
return"Reset the "..a:lower().." to its defaults? Every element following Global changes with it."
end
function a.reset(a,c)
if c then return b.resetFactLook(a)end
return b.resetStyle(a)
end


local f=6
local function h(b,c,a)
if a==0 then return""end
if a<=f then return b..table.concat(c,", ").."."end
return b..table.concat(c,", ",1,f).." and "..(a-f).." more."
end



function a.note(e,d,g)
d=a.target(e,d)
local a
if g=="editing"then
local a=d~=nil and c.preset(e,d)
return a and("Editing the preset "..tostring(a.name or d)..". Elements pick it on their Style row.")or nil
end
if g=="users"then
if d==nil then return nil end
local b,a=b.presetUsers(e,d,f)
return a==0 and"Not used yet."or h("Used by: ",b,a)
end
if d~=nil then return nil end
if g=="owners"then
a=h("Set on their own: ",b.styleOwners(e,f))
else
a=h("Following a preset: ",b.presetFollowers(e,f))
end
if a==""then return nil end
return a
end


local function f(b,a)
local b=c.preset(b,a)
return"\""..(b and b.name or tostring(a)).."\""
end

function a.newPresetPrompt(a)return"Name for the new "..e.spec(a).label.." preset:"end
function a.newPresetName(a,b)return c.freePresetName(a,b or e.spec(a).label)or""end
function a.renamePrompt(a,b)return"New name for "..f(a,b)..":"end
function a.presetName(a,b)
local a=c.preset(a,b)
return a and a.name or""
end



function a.deleteText(c,d,h)
local g,a=b.presetUsers(c,d,1)
local b="Delete the "..e.spec(c).label.." preset "..f(c,d).."?"
if a==0 then return b end
if h then
if a==1 then return b.." "..g[1].." uses it and keeps its style as its own."end
return b.." The "..a.." using it keep its style as their own."
end
if a==1 then return b.." "..g[1].." uses it and follows Global's style again."end
return b.." The "..a.." using it follow Global's style again."
end


function a.presetMenu(d,e)
if not(e and c.preset(d,e))then return{}end
local c={{key="rename",label="Rename"}}
if a.roomForPreset(d)then c[#c+1]={key="duplicate",label="Duplicate"}end
local b,a=b.presetUsers(d,e,0)
if a==0 then
c[#c+1]={key="delete",label="Delete"}
else
c[#c+1]={key="deleteKeep",label="Delete, keeping its style"}
c[#c+1]={key="deleteGlobal",label="Delete, back to Global"}
end
return c
end

function a.deleteKeeps(a)return a~="deleteGlobal"end


function a.newPreset(a,b)return c.newPreset(a,b)end
function a.duplicatePreset(a,b,d)return c.duplicatePreset(a,b,d)end
function a.renamePreset(a,b,d)return c.renamePreset(a,b,d)end
function a.deletePreset(a,b,d)return c.deletePreset(a,b,d)end



function a.sample(a)
local a,c=e.sample(a)
local b=a and j.clean("element",a,"load")
if not b then return nil end
return a,c,b
end



function a.sampleView(f,e,l,b,h)
local i=c.profile()
if not i then return nil end
local c=h
e=a.target(f,e)
if e then
c=d.copy(l)
g.eachStyleSlot("element",c,{},function(a,c,b)
if a.style==f then b[a.name]={preset=e}end
end)
c=j.clean("element",c,"load")or h
end

local a=k.element(c,i)
local e=a.sources and a.sources[1]
local c=b.picks and d.copy(b.picks)or{game={},held={}}
if e and not b.picks and b.state then c[e.id]={state=b.state,facts={}}end

c.allKnown=true
return a,c
end



a.PICK_LABEL="Style"
a.RESET_TIP="Reset to following Global's style."
a.pick=b.stylePick
a.pickValue=b.pickValue
a.ownStyle=b.ownStyle

local function c(a,b)
if type(a)=="table"and a.preset~=nil then return"preset",a.preset end
if a==nil and b=="Global"then return"global"end
end


a.SAVE_LABEL="Save as preset"
function a.links(b,d,e)
local c,e=c(d,e)
local d
if c then d={label=c=="preset"and"Edit preset"or"Edit Global's",part=b,id=e}end
return{save=a.roomForPreset(b),edit=d}
end

function a.limitLine(a,c,d,e)
return table.concat(b.styleLimits(a,c,d,e)," ")
end

function a.followLine(c,d,e,f)
if b.ownStyle(d)then return nil end
local a=a.limitLine(c,e,f)
if a==""then return nil end
return a
end



function a.rowLimit(c,d,f,g,e,h)
if not b.limited(c,d)then return nil end
local a=a.limitLine(c,f,g,d)
local c=a~=""
return{grey=e and c,line=c and(not e or b.ownStyle(h))and a or nil}
end
a.limited=b.limited
