


local b,a=...
local c,g,j,d=a.Events,a.Combat,a.Target,a.Debug

local e={}
a.Game=e

local h={inCombat=false,hostileTarget=false,inGroup=false,inRaid=false,targetCasting=false}


function e.holds(a)return h[a]==true end


local f=a.keyed("game facts")
function e.onChange(a,b)f:add(a,b)end

local function b(b,a)
a=a==true
if h[b]==a then return end
h[b]=a
f:call(b)
end


g.onStart("game facts",function()b("inCombat",true)end)
g.onEnd("game facts",function()b("inCombat",g.inCombat())end)



d.experimental("game.hostileTarget changing with no target change (a duel, a mob turning hostile): re-read at the"
.." target's UNIT_FACTION and UNIT_FLAGS (FR-4's plain reads; such a change unseen)","I")
j.onChange("game facts",function(a)b("hostileTarget",a)end)


d.experimental("game.inGroup and game.inRaid: IsInGroup and IsInRaid re-read at GROUP_ROSTER_UPDATE, in combat too"
.." (EP-46; EllesmereUI's buff reminders read them on Forever)","I")
local function f(b)
if not b then return false end
local c,b=a.try("group read",b)
return c and not a.isSecret(b)and b==true
end
local function l()
b("inGroup",f(IsInGroup))
b("inRaid",f(IsInRaid))
end
c.on("GROUP_ROSTER_UPDATE","game facts",l)







d.experimental("game.targetCasting from UnitCastingInfo's castBarID at the target's cast events, in combat (CA-4,"
.." CA-5: one caster 13 levels below you; elites and instances unseen)","T")
d.experimental("game.targetCasting from a channel's castBarID (UnitChannelInfo) at CHANNEL_START and CHANNEL_STOP"
.." (D: its docs; never seen: EP-45)","D")
d.experimental("game.targetCasting's Enters on a cast chained straight after another, both in one frame (the frame's"
.." end read may never see it stop: EP-45)","I")
local function i()
local c,d,e,f,g,h,i,j,k,l,b=a.try("UnitCastingInfo",UnitCastingInfo,"target")
if c and not a.isSecret(b)and b~=nil then return true end
local c,d,e,f,g,h,i,j,k,l,m,b=a.try("UnitChannelInfo",UnitChannelInfo,"target")
return c and not a.isSecret(b)and b~=nil
end


local k=false
local function f()b("targetCasting",not k and i())end


local n={"UNIT_SPELLCAST_START","UNIT_SPELLCAST_STOP","UNIT_SPELLCAST_INTERRUPTED",
"UNIT_SPELLCAST_FAILED","UNIT_SPELLCAST_SUCCEEDED","UNIT_SPELLCAST_CHANNEL_START","UNIT_SPELLCAST_CHANNEL_STOP",
"UNIT_SPELLCAST_EMPOWER_START","UNIT_SPELLCAST_EMPOWER_UPDATE","UNIT_SPELLCAST_EMPOWER_STOP"}
local function o()
f()
c.atFrameEnd("game targetCasting",f)
end

local m={}
local i=false
local function p()
local a=next(m)~=nil
if a==i then return end
i=a
for d,b in ipairs(n)do
if a then c.onUnit(b,"target","game targetCasting",o)else c.offUnit(b,"game targetCasting")end
end
if a then f()else b("targetCasting",false)end
end

function e.use(a,b,c)
if a~="targetCasting"then return end
m[b]=c and true or nil
p()
end
j.onChange("game facts casting",function(b,a)
if a=="PLAYER_TARGET_DIED"then k=true elseif a=="PLAYER_TARGET_CHANGED"then k=false end
if not i then return end
f()
c.atFrameEnd("game targetCasting",f)
end)


c.on("PLAYER_LOGIN","game facts",function()
b("inCombat",g.inCombat())
b("hostileTarget",j.hostile())
l()
end)


function e.describe()
local b={}
for c,a in ipairs(a.Schema.gameFacts())do
if h[a]then b[#b+1]=a end
end
return{"game facts: "..(#b>0 and table.concat(b,", ")or"none")..(i and
" (the target's cast read)"or"")}
end
d.register("game",e.describe)
