
local d,a=...

a.name=d
a.version=C_AddOns.GetAddOnMetadata(d,"Version")or"dev"

a.isDev=a.version:find("dev",1,true)~=nil or a.version:find("@",1,true)~=nil



local b=select(4,GetBuildInfo())
a.game=type(b)=="number"and b>=120000 and"retail"or"forever"


local b=issecretvalue
function a.isSecret(a)
return b~=nil and b(a)or false
end





local c,e={},{}
local f,b

function a.noteError(a,b)
local g=c[a]
if g then
g.count=g.count+1
return
end
b=tostring(b)
local g=f
f=nil
c[a]={err=b,count=1,stack=g}
e[#e+1]=a
local c=geterrorhandler()
if c then pcall(c,d.." ("..a.."): "..b..(g and("\n"..g)or""))end
end



local g=6
function a.errorLines(f)
local a={}
for b,d in ipairs(e)do
local b=c[d]
a[#a+1]=string.format("%s: %s (x%d)",d,b.err,b.count)
if f and b.stack then
local c=0
for b in b.stack:gmatch("[^\n]+")do


local b=b:match("InterHUD[/\\](.*)$")
if b and c<g then
c=c+1
b=b:gsub("^([^%]]*)%]","%1"):gsub("<[^>]-InterHUD[/\\]","<")
a[#a+1]="  "..b
end
end
end
end
return a
end


local function d(a)
if b and not c[b]then f=debugstack and debugstack(2)or nil end
return a
end

local function c(d,e,c,...)
b=d
if not c then a.noteError(e,...)end
return c,...
end



function a.try(a,e,...)
local f=b
b=a
return c(f,a,xpcall(e,d,...))
end




local b={}
b.__index=b

function a.keyed(a)
return setmetatable({keys={},fns={},sites={},listed={},prefix=a,depth=0,
dirty=false},b)
end

function b:add(a,b)
if not self.listed[a]then
self.keys[#self.keys+1]=a
self.listed[a]=true
self.sites[a]=self.prefix.." "..tostring(a)
end
self.fns[a]=b
end

function b:compact()
local a,c=self.keys,0
for d=1,#a do
local b=a[d]
a[d]=nil
if self.fns[b]~=nil then
c=c+1
a[c]=b
else
self.listed[b],self.sites[b]=nil,nil
end
end
self.dirty=false
end

function b:remove(a)
if self.fns[a]==nil then return end
self.fns[a]=nil
if self.depth>0 then self.dirty=true else self:compact()end
end

function b:has(a)return self.fns[a]~=nil end

function b:count()
local a=0
for c,b in ipairs(self.keys)do
if self.fns[b]~=nil then a=a+1 end
end
return a
end


function b:call(...)
self.depth=self.depth+1
local b,c,d=self.keys,self.fns,self.sites
for e=1,#b do
local b=b[e]
local c=c[b]
if c then a.try(d[b],c,...)end
end
self.depth=self.depth-1
if self.depth==0 and self.dirty then self:compact()end
end



local c=a.keyed("changed")
local b=0
function a.onChanged(a,d)
b=b+1
c:add(d or b,a)
end
function a.changed(a,b,d)
c:call(a,b,d)
end



local function c(b)
local a={}
for d,b in pairs(b)do
if type(b)=="table"then a[d]=c(b)else a[d]=b end
end
return a
end
function a.copy(a)
if type(a)~="table"then return a end
return c(a)
end


local function c(a,b)
for d,a in pairs(a)do
local b=b[d]
if a~=b and(type(a)~="table"or type(b)~="table"or not c(a,b))then return false end
end
for b in pairs(b)do
if a[b]==nil then return false end
end
return true
end

function a.equal(a,b)
if a==b then return true end
if type(a)~="table"or type(b)~="table"then return false end
return c(a,b)
end


function a.print(...)
print("|cff66ccffInterHUD:|r",...)
end
