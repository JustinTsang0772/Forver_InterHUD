


local a,c=...
local i,d,q=c.Spells,c.Combat,c.Debug

local b={}
c.GameData=b


b.FORMAT=1
local f={id=true,icon=true,length=true,level=true,spell=true,category=true,cooldown=true}





local e={}
local function g(d)
local a={n=0,at={},columns={}}
local g,c=#d,d:find("\n",1,true)
if not c then return a end
local b={}
for c in(d:sub(1,c-1).."|"):gmatch("([^|]*)|")do
b[#b+1]={name=c,num=f[c],list={}}
a[c],a.columns[#b]=b[#b].list,c
end
local h,c,e,i,f=#b,0,c+1,a.at,a.id
while e<=g do
local a=d:find("\n",e,true)or g+1
c=c+1
local g=e
for f=1,h do
local e=d:find("|",g,true)
local e=e and e<a and e or a
local a,b=d:sub(g,e-1),b[f]
if b.num then a=tonumber(a)or false end
b.list[c]=a
g=e+1
end
if f and f[c]then i[f[c]]=c end
e=a+1
end
a.n=c
return a
end
function b.kind(d)
local a=e[d]
if a then return a end
local c=c.PackedData
local b=c and c.format==b.FORMAT and c[d]
if type(b)~="string"then return nil end
a=g(b)
e[d]=a
return a
end


local a


function b.release()
e,a={},nil
end







function b.canWatchById(a,b)
if a=="target"or a=="focus"then
if b then return true end
return false,"helpfulOnEnemy"
end
if b then return false,"harmfulOnFriend"end
return true
end



local h={p="player",t="target",a="ally",e="pet"}
local r={c="class",p="pet",i="item",e="enchant",s="set",o="other"}
local k={"player","target","ally","pet"}

local function f()return c.SpellTable and c.SpellTable.families or{}end

local function g(a)return not d.inCombat()and i.nameOf(a)or nil end
local function e()return c.SpellTable and c.SpellTable.racials or{}end



local function j(b)
local c={}
for d,a in ipairs(k)do
if b.auras and b.auras[a]and#b.auras[a]>0 then c[#c+1]={unit=a,harmful=a=="target"}end
end
return c
end




local function s(a,b)
local a=h[a]
if not a then return{}end
local c=a=="target"
if b=="other"then a="player"end
return{{unit=a,harmful=c}}
end




local function n(b,a)
if i.inBook(b)then return true end
if a and(a.pet or a.talent or a.kind=="passive"or a.kind=="aura")then return nil end
return false
end

local function k(b,a,d)
local c=n(b,a)
return{id=b,name=d or g(b)or a.name,english=a.name,icon=a.icon,kind="spell",
class=a.class,pet=a.pet,from=a.pet and"pet"or"class",known=c,
level=c==false and a.levels and a.levels[1]or nil,list="data",
watch={auras=j(a),cooldown=a.cooldown,charges=a.charges,dispels=a.dispels,
dispelsOn=a.dispelsOn,cast=a.kind=="spell"}}
end

local function l(b,a,c)
return{id=b,name=c or g(b)or a.name,english=a.name,icon=a.icon,kind="racial",
known=n(b,a),list="data",races=a.races,
watch={auras=j(a),cooldown=a.cooldown,cast=a.kind=="spell"}}
end

local function o(a,b,e)
local c=r[a.from[b]]or"other"
local d=a.class[b]
return{id=a.id[b],name=e or a.name[b],english=a.name[b],icon=a.icon[b]or nil,kind="spell",
class=d~=""and d or nil,from=c,list="data",
watch={auras=s(a.where[b],c),length=a.length[b]or nil,
dispels=a.dispel[b]~=""and{a.dispel[b]}or nil}}
end

local function p(a,b,c)
return{id=a.id[b],name=c or a.name[b],english=a.name[b],icon=a.icon[b]or nil,kind="item",
level=a.level[b]or nil,list="data",trinket=a.type[b]=="t"or nil,
watch={auras={},spell=a.spell[b]or nil,category=a.category[b]or nil,
cooldown=a.cooldown[b]or nil}}
end









local t={player="p",target="t",pet="e",focus="t"}
local u={"player","target","pet"}


local h
local function v(a,b)
if h==nil then
h=false
for b,a in ipairs(c.Schema.sourceKeys())do
local a=c.Schema.source(a)
local a=a and c.Sources.picksOf(a.kind)
if a and a.data=="aura"and a.on then
h=a.on
break
end
end
end
if h then return h(a,b)end
for c,a in ipairs(a)do
if a.unit==b then return a end
end
end
local function m(c)
local a=""
for d,b in ipairs(u)do
if v(c,b)then a=a..t[b]end
end
return a
end
local function h(a,c,e,g,d,h,i,j,k)
local b=a.n+1
a.n=b
a.what[b],a.ref[b],a.low[b]=c,e,g:lower()
a.client[b]=d or false
a.clow[b]=d and d:lower()or false
a.class[b],a.cast[b],a.units[b],a.pet[b]=h or false,i or false,j,k or false

a.learnable[b]=(c=="family"or c=="racial")and not(c=="family"and f()[e].kind=="aura")
end
q.experimental("the search's client names: GetSpellName for every indexed ID at the first open, an ID you don't know"
.." named too, its cost unmeasured (EP-54); English where it answers nil","I")
local function u()
local a=not d.inCombat()
local c={n=0,what={},ref={},low={},client={},clow={},class={},cast={},units={},
pet={},learnable={},english=not a}
local function d(b)return a and i.nameOf(b)or nil end
for b,a in pairs(f())do
h(c,"family",b,a.name,d(b),a.class,a.kind=="spell",m(j(a)),a.pet)
end
for b,a in pairs(e())do
h(c,"racial",b,a.name,d(b),nil,a.kind=="spell",m(j(a)))
end
local a=b.kind("spells")
for b=1,a and a.n or 0 do
if a.flags[b]==""then
h(c,"single",b,a.name[b],d(a.id[b]),a.class[b]~=""and a.class[b],
false,m(s(a.where[b],r[a.from[b]])))
end
end
local a=b.kind("items")
for b=1,a and a.n or 0 do
if a.flags[b]==""then h(c,"item",b,a.name[b],nil,nil,false,"")end
end
return c
end
local function h()
if not a or a.english and not d.inCombat()then a=u()end
return a
end


local function u(a,c)
local c,a,d=a.what[c],a.ref[c],a.client[c]or nil
if c=="family"then return k(a,f()[a],d or f()[a].name)end
if c=="racial"then return l(a,e()[a],d or e()[a].name)end
if c=="single"then return o(b.kind("spells"),a,d)end
return p(b.kind("items"),a)
end


local function m(b,a)
if not a then return nil end
local a=a:find(b,1,true)
if not a then return nil end
return a==1 and 1 or 2
end



q.experimental("the search's bags: C_Container.GetContainerNumSlots and GetContainerItemID at rest, bags 0 to 4"
.." (D: Blizzard's container API; IT-1 proves counts by item ID, never the slots)","D")
local j=4
local function v()
local a={}
if d.inCombat()or not(C_Container and C_Container.GetContainerNumSlots and C_Container.GetContainerItemID)then
return a
end
for d=0,j do
local e,b=c.try("game data bags",C_Container.GetContainerNumSlots,d)
for b=1,e and type(b)=="number"and not c.isSecret(b)and b or 0 do
local d,b=c.try("game data bags",C_Container.GetContainerItemID,d,b)
if d and type(b)=="number"and not c.isSecret(b)then a[b]=true end
end
end
return a
end

local function r(a,b)
local b,a=c.try("game data name",a,b)
if b and type(a)=="string"and not c.isSecret(a)and a~=""then return a end
end




function b.byId(a,c)
if c then
local b=b.kind("items")
local c=b and b.at[a]
if c then
local a=p(b,c)
a.byId=true
return a
end
local b=not d.inCombat()and C_Item and C_Item.GetItemNameByID and r(C_Item.GetItemNameByID,a)
return{id=a,name=b or tostring(a),kind="item",list=b and"client"or nil,byId=true,
unknown=not b or nil,watch={auras={}}}
end
local d,h=i.family(a)
local c
if h then
c=k(d,h)
if d~=a then
c.reason=b.memberReason(d,h,a)
c.id,c.key=a,d
end
elseif e()[a]then
c=l(a,e()[a])
else
local b=b.kind("spells")
local d=b and b.at[a]
if d then
c=o(b,d,g(a))
else
local b=i.auraFamilies(a)
local d=b and f()[b[1]]
if d then
c=k(b[1],d)
c.id,c.key,c.reason=a,b[1],"aura"
c.name=g(a)or d.name
else
local b=g(a)
c={id=a,name=b or tostring(a),kind="spell",list=b and"client"or nil,
unknown=not b or nil,watch={auras={}}}
end
end
end
c.byId=true
return c
end



function b.memberReason(c,a,b)
if b==c then return nil end
for a,c in ipairs(a.ranks or{})do
if c==b then return"rank",a end
end
for c,a in ipairs(a.copies or{})do
if a==b then return"copy"end
end
if a.variants and a.variants[b]then return a.variants[b]end
if a.equivalents and a.equivalents[b]then return a.equivalents[b].why end
for c,a in pairs(a.auras or{})do
for c,a in ipairs(a)do
if a==b then return"aura"end
end
end
end


local function w(b,c,a,f)
local d,e=a.kind,b.what[c]
if d=="item"and e~="item"or(d=="spell"or d=="aura")and e=="item"then return false end
if d=="spell"and not b.cast[c]then return false end
if d=="aura"and b.units[c]==""then return false end
if d=="known"and not b.learnable[c]then return false end
if a.unit and not b.units[c]:find(t[a.unit]or"?",1,true)then return false end
local b=b.class[c]
if a.class=="none"and b or a.class and a.class~="none"and b~=a.class then
return false
end
if a.learned and f==false then return false end
return true
end


local function t(c,b)
local a=b.kind
if a=="item"and c.kind~="item"or(a=="spell"or a=="aura"or a=="known")and c.kind=="item"
then
return false
end
if b.class and b.class~="none"then return false end
return true
end




local function q(a,c,d,b,e)
if a=="book"or a=="racial"and b==true then return 1 end
if a=="single"or a=="item"then return 5 end
if a=="family"and not d and c==e then return b==true and 1 or b==nil and 2 or 3 end
return 4
end
local function s(a)
if a.list=="spellbook"then return"book"end
if a.kind=="item"or a.kind=="racial"then return a.kind end
return a.list=="data"and a.key==nil and f()[a.id]and"family"or"single"
end

local g=50



local function x()
local a={}
for b,c in pairs(e())do
for c,b in ipairs(c.ids or{b})do a[b]=true end
end
local b=b.kind("spells")
for c=1,b and b.n or 0 do a[b.id[c]]=true end
return a
end













function b.search(d,c,a)
c,a=c or{},a or{}
local k=a.class
if k==nil then
local b,a=UnitClass("player")
k=a
end
local o=a.limit or g
local d=type(d)=="string"and d:lower():match("^%s*(.-)%s*$")or""
local g=tonumber(d:match("^(%d+)$")or"")
local a=h()
local h,j,l={},{},{}
for b=1,a.n do
local i=d==""and 1 or math.min(m(d,a.clow[b])or 9,m(d,a.low[b])or 9)
if g and(a.what[b]=="family"or a.what[b]=="racial")and a.ref[b]==g then i=1 end
if i<9 then
local d=a.what[b]
local g
if d=="family"or d=="racial"then
g=n(a.ref[b],d=="family"and f()[a.ref[b]]or e()[a.ref[b]])
end
if w(a,b,c,g)then
h[#h+1]=b
j[b],l[b]=i,q(d,a.class[b],a.pet[b],g,k)
end
end
end
local function e(b)return a.clow[b]or a.low[b]end
table.sort(h,function(b,c)
if j[b]~=j[c]then return j[b]<j[c]end
if l[b]~=l[c]then return l[b]<l[c]end
local a,d=a.what[b]=="item"and 1 or 0,a.what[c]=="item"and 1 or 0
if a~=d then return a<d end
local a,d=e(b),e(c)
if a~=d then return a<d end
return b<c
end)

local e,f={},{}
for b=1,math.min(#h,o)do
local a=u(a,h[b])
e[b],f[a]=a,j[h[b]]
end
local j=0
local function l(a,b)
if b and t(a,c)then
e[#e+1],f[a]=a,b
j=j+1
end
end
local n=x()
for b,a in ipairs(i.bookEntries())do
if not a.key and a.name and not n[a.id]then
l({id=a.id,name=a.name,icon=a.icon,kind="spell",known=true,list="spellbook",
watch={auras={},cast=true}},d==""and 1 or m(d,a.name:lower()))
end
end
local n=c.kind~="spell"and c.kind~="aura"and c.kind~="known"and v()or{}
local i=b.kind("items")
for b,a in ipairs(e)do
if a.kind=="item"and n[a.id]then a.carried=true end
end
local p=C_Item and C_Item.GetItemNameByID
for a in pairs(n)do
if not(i and i.at[a])then
local b=p and r(p,a)
l({id=a,name=b or tostring(a),kind="item",list="bags",carried=true,
watch={auras={}}},b and(d==""and 1 or m(d,b:lower())))
end
end
if j>0 then
table.sort(e,function(a,b)
if f[a]~=f[b]then return f[a]<f[b]end
local c=q(s(a),a.class,a.pet,a.known,k)
local d=q(s(b),b.class,b.pet,b.known,k)
if c~=d then return c<d end
local c,d=a.kind=="item"and 1 or 0,b.kind=="item"and 1 or 0
if c~=d then return c<d end
if a.name:lower()~=b.name:lower()then return a.name:lower()<b.name:lower()end
return a.id<b.id
end)
end
local a={}
if g then
local d=b.byId(g,c.kind=="item")
if d.unknown and c.kind==nil and i and i.at[g]then d=b.byId(g,true)end
a[1]=d
end
for c,b in ipairs(e)do
if#a>=o then break end
if not(g and b.id==g and a[1].kind==b.kind)then a[#a+1]=b end
end
return a,#h+j
end





function b.describe(d,g)
local a
if g=="item"or g=="enchant"then
local b=b.kind(g=="item"and"items"or"enchants")
local c=b and b.at[d]
if not c then return nil end
a={key=d,kind=g}
for e,d in ipairs(b.columns)do a[d]=b[d][c]end
if g=="item"then a.row=p(b,c)end
else
local f=f()[d]
if f then
a=c.copy(f)
a.key,a.kind,a.spellKind=d,"family",f.kind
a.members={}
for e,c in ipairs({f.ranks or{},f.copies or{}})do
for e,c in ipairs(c)do
local b,e=b.memberReason(d,f,c)
a.members[#a.members+1]={id=c,why=b or"rank",rank=e or(c==d and 1 or nil)}
end
end
for b,c in pairs(f.variants or{})do a.members[#a.members+1]={id=b,why=c}end
for c,b in pairs(f.equivalents or{})do
a.members[#a.members+1]={id=c,why=b.why,object=b.object}
end
a.row=k(d,f)
elseif e()[d]then
a=c.copy(e()[d])
a.key,a.kind,a.spellKind=d,"racial",a.kind
a.row=l(d,e()[d])
else
local b=b.kind("spells")
local c=b and b.at[d]
if not c then return nil end
a={key=d,kind="single"}
for e,d in ipairs(b.columns)do a[d]=b[d][c]end
a.row=o(b,c)
end
end
a.sources=b.watchers(a.row)
return a
end




function b.watchers(d)
local b,e={},{}
if not(d and c.Schema and c.Sources)then return b end
for a,f in ipairs(c.Schema.sourceKeys())do
local a=c.Schema.source(f)
local c=a and c.Sources.picksOf(a.kind)
local g=a and a.add and a.add.label or nil
local h=a and(a.kind.."|"..tostring(g))
if c and not e[h]and c.fits(d,a.unit)then
e[h]=true
b[#b+1]={key=f,kind=a.kind,unit=a.unit,label=g}
end
end
return b
end
