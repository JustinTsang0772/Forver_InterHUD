





local a,b=...

local a={}
b.Debug=a


local c={}
function a.register(a,b)
for d,c in ipairs(c)do
if c.name==a then c.fn=b return end
end
c[#c+1]={name=a,fn=b}
end
function a.partNames()
local a={}
for b,c in ipairs(c)do a[b]=c.name end
return a
end

function a.part(a)
for d,c in ipairs(c)do
if c.name==a then
local b,a=b.try("describe "..a,c.fn)
return b and type(a)=="table"and a or{}
end
end
return{}
end



function a.experimental()end



function a.client()
local a,c,e,d=GetBuildInfo()
local b=b.game=="retail"and"Retail"or"Forever"
return string.format("%s %s, build %s (interface %s)",b,tostring(a),tostring(c),tostring(d))
end

local function d()
local a={}
local c=UnitClass and UnitClass("player")
local d=UnitLevel and UnitLevel("player")
if type(c)=="string"and not b.isSecret(c)then a[#a+1]=c end
if type(d)=="number"and not b.isSecret(d)then a[#a+1]=tostring(d)end
local a=table.concat(a," ")
local b=GetLocale and GetLocale()
if type(b)=="string"then a=a..(a~=""and", "or"")..b end
return a
end
function a.header()
local c=d()
return"InterHUD "..b.version..", "..a.client()..(c~=""and("; "..c)or"")
end


function a.errorLines()
local c=b.errorLines(true)
local a=#b.errorLines()
local a={a==0 and"errors: none"or("errors: "..a)}
for c,b in ipairs(c)do a[#a+1]="  "..b end
return a
end


function a.lines()
local b={a.header()}
for d,c in ipairs(c)do
for c,a in ipairs(a.part(c.name))do b[#b+1]=a end
end
for c,a in ipairs(a.errorLines())do b[#b+1]=a end
return b
end

function a.report()
for c,a in ipairs(a.lines())do b.print(a)end
end

a.register("combat",b.Combat.describe)
