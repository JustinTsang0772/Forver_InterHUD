












local b,a=...
local o,p,e,l=a.Events,a.Debug,a.Ticker,a.Combat

local b={}
a.Pressed=b

local g,m,q=0.08,10,0.15


local f=a.keyed("pressed")
function b.on(a,b)f:add(a,b)end
function b.off(a)f:remove(a)end


local function n(b)
if type(b)~="number"or a.isSecret(b)then return nil end
local d,b,c,e=a.try("GetActionInfo",GetActionInfo,b)
if not d or a.isSecret(b)or a.isSecret(c)then return nil end
if b=="spell"or(b=="macro"and e=="spell")then return c end
end
b.spellOf=n

local function h(a)
if not a then return nil end
local b=a.action
if b==nil and a.GetAttribute then b=a:GetAttribute("action")end
return b
end



local c={}


local i={}
local j=false

local d={}

local function r(a)
d[a]=(d[a]or 0)+1
if d[a]==1 then f:call(a,true)end
end
local function k(a)
local b=(d[a]or 1)-1
d[a]=b>0 and b or nil
if b<=0 then f:call(a,false)end
end

local function s()
local b=GetTime()
for d,a in pairs(c)do
if a.down and b>=a.at+g then
local c=a.down()
if c==false or(c==nil and b>=a.at+m)then a.ends=b end
end
if b>=a.ends then
c[d]=nil
k(a.spell)
end
end
if next(c)==nil then
e.unsubscribe(0.1,"pressed")
j=false
end
end


local function t(b)
local a=c[b]
if not a then return end
i[a.slot]=GetTime()
if GetTime()-a.at>=g then
c[b]=nil
k(a.spell)
else
a.ends=a.at+g
end
end


local function g(b)
if not b then return nil end
local b,c,d=a.try("GetBindingKey",GetBindingKey,b)
if not b then return nil end

local function b(a)return a and(a:match("^.+%-(.+)$")or a)end
local b,c=b(c),b(d)
if not(b or c)then return nil end

local function d(b)
if not b then return false end
local b=IsKeyDown(b)
if a.isSecret(b)then return nil end
return b==true
end
return function()
local a,b=d(b),d(c)
if a or b then return true end
if a==nil or b==nil then return nil end
return false
end
end


local function d(a,b,h,g)
local d=n(b)
if not d then return end
local f=c[a]
if f then
c[a]=nil
k(f.spell)
end
local f=GetTime()
c[a]={spell=d,slot=b,at=f,down=g,
ends=g and math.huge or f+(h or m)}
i[b]=f
r(d)
if not j then
j=true
e.subscribe(0.1,"pressed",s)
end
end

local function j(a,b)d(a,h(a),nil,g(b))end
local function f(a)t(a)end



local function k(a)return GetActionButtonForID and GetActionButtonForID(a)end
local function m(a,b)return _G[tostring(a).."Button"..tostring(b)]end
local n={MultiBarBottomLeft="MULTIACTIONBAR1BUTTON",MultiBarBottomRight="MULTIACTIONBAR2BUTTON",
MultiBarRight="MULTIACTIONBAR3BUTTON",MultiBarLeft="MULTIACTIONBAR4BUTTON",MultiBar5="MULTIACTIONBAR5BUTTON",
MultiBar6="MULTIACTIONBAR6BUTTON",MultiBar7="MULTIACTIONBAR7BUTTON"}
local function r(a,b)
local a=n[a]
return a and a..tostring(b)or nil
end



local function s(b,a)
if a and IsMouseButtonDown(a)then
return function()return IsMouseButtonDown(a)end
end
local a=h(b)
if type(a)=="number"and a>=1 and a<=12 then return g("ACTIONBUTTON"..a)end
end


local n={}
local function g()
if l.inCombat()then return end
for a=1,180 do
local a=_G["EABButton"..a]
if a and not n[a]and a.HookScript then
n[a]=true
a:HookScript("PostClick",function(a,b,c)
if c then d(a,h(a),nil,s(a,b))else f(a)end
end)
end
end
end
p.experimental("a pressed look on EllesmereUI's own buttons, from their PostClick at both edges, held while the key"
.." or mouse button reads down (ihud-step6b, out of combat and in combat, by eye)","T")

function b.start()
if b.started then return end
b.started=true
if ActionButtonDown then
hooksecurefunc("ActionButtonDown",function(a)j(k(a),"ACTIONBUTTON"..tostring(a))end)
hooksecurefunc("ActionButtonUp",function(a)f(k(a))end)
end
if MultiActionButtonDown then
hooksecurefunc("MultiActionButtonDown",function(a,b)j(m(a,b),r(a,b))end)
hooksecurefunc("MultiActionButtonUp",function(a,b)f(m(a,b))end)
end

hooksecurefunc("UseAction",function(b)
if type(b)~="number"or a.isSecret(b)then return end
local a=i[b]
if a and GetTime()-a<0.5 then return end
for c,a in pairs(c)do
if a.slot==b then return end
end
d("use "..tostring(b),b,q)
end)


local a=0
local function c()
a=a+1
g()
if a>=5 then e.unsubscribe(1,"pressed EUI")end
end
local function b()
g()
a=0
e.subscribe(1,"pressed EUI",c)
end
b()
o.on("PLAYER_ENTERING_WORLD","pressed",b)
l.onEnd("pressed",g)
end





function b.serve(c,d)
b.on(c,function(e,f)
for b in pairs(d)do
local d=b.rig and b.rig.watch
if d and d.pressed and b:names(e)then a.try("pressed "..c,b.pressed,b,f)end
end
end)
end
