

local b,a=...
local b=a.Events

local d={}
a.Target=d

local c=false


local function e(b,...)
local c,b=a.try("target read",b,...)
if not c or a.isSecret(b)then return nil end
return b
end

local function f()
return e(UnitExists,"target")==true and e(UnitCanAttack,"player","target")==true
and not e(UnitIsDead,"target")
end

function d.hostile()
return c
end

local e=a.keyed("target change")

function d.onChange(a,b)e:add(a,b)end

local function a(a)
c=f()
e:call(c,a)
end

b.on("PLAYER_LOGIN","target",a)
b.on("PLAYER_TARGET_CHANGED","target",a)
b.on("PLAYER_TARGET_DIED","target",a)

b.onUnit("UNIT_FACTION","target","target",a)




b.onUnit("UNIT_FLAGS","target","target",function(b)
if f()~=c then a(b)end
end)
