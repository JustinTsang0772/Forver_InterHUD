

local a,c=...
local o,l=c.Events,c.Combat

local b={}
c.Sounds=b





local e={


{"spellAlert","Level-up fanfare","UI_POWER_AURA_GENERIC",568016,byFile=true,length=4.6},
{"ready","Ready check","READY_CHECK",567409,length=2.9},
{"bell","Bell",nil,7467088,byFile=true,length=2.0},
{"rising","Rising chime",nil,7466072,byFile=true,length=2.6},
{"tick","Tick",nil,567474,byFile=true,length=1.6},
{"click","Click",nil,567453,byFile=true,length=0.1},
{"raid","Raid warning","RAID_WARNING",567397,length=1.3},
{"alarm","Alarm clock","ALARM_CLOCK_WARNING_3",567458,length=1.9},
{"horn","War horn",nil,7466967,byFile=true,length=2.7},
{"ping","Map ping","MAP_PING",567416,byFile=true,length=1.6},

{"emote","Boss emote","RAID_BOSS_EMOTE_WARNING",hidden=true},
{"queue","Queue pop","PVP_THROUGH_QUEUE",hidden=true},
{"invite","Group invite","IG_PLAYER_INVITE",hidden=true},
{"quest","Quest complete","IG_QUEST_LIST_COMPLETE",hidden=true},
{"toast","Friend online","UI_BNET_TOAST",hidden=true},
}
local a={}
for c,b in ipairs(e)do a[b[1]]=b end


local f="Master"


local function g(a)
if a[3]==nil then return a.byFile and true or nil end
return SOUNDKIT and SOUNDKIT[a[3]]
end


local function h()
local a=_G.LibStub
return a and a("LibSharedMedia-3.0",true)or nil
end


local function d(a)
if a==""or a=="None"then return nil end
local b=h()
if not b then return nil end
local b,a=c.try("sound: shared media",b.Fetch,b,"sound",a,true)
if b and(type(a)=="string"or type(a)=="number")then return a end
end


local function h(b)
if type(b)~="string"then return nil end
local c=b:match("^file:(%d+)$")
if c then return"file",tonumber(c)end
local c=b:match("^media:(.+)$")
if c then
local a=d(c)
if a then return"file",a end
return nil
end
local a=a[b]
if not a then return nil end
local b=g(a)
if not b then return nil end
if a.byFile then return"file",a[4]end
return"kit",b
end



function b.fileID(b)
if type(b)~="string"then return nil end
local c=b:match("^file:(%d+)$")
if c then return tonumber(c)end
local c=b:match("^media:(.+)$")
if c then
local a=d(c)
return type(a)=="number"and a or nil
end
local a=a[b]
return a and g(a)and a[4]or nil
end

function b.playable(a)return h(a)~=nil end


function b.missing(a)
local a=type(a)=="string"and a:match("^media:(.+)$")
return a and d(a)==nil or false
end



function b.names()
local a={}
for c,b in ipairs(e)do
if not b.hidden then a[#a+1]=b[1]end
end
return a
end
function b.label(b)
local a=a[b]
return a and a[2]or nil
end
function b.length(b)
local a=a[b]
return a and a.length or nil
end

function b.choiceLabel(b)
local a=a[b]
if not a then return nil end
return a.length and string.format("%s  %.1f s",a[2],a.length)or a[2]
end



local j,k=2,0.5
local d,i={},{}

local function m(b,a)
if b=="kit"then return c.try("sound: play",PlaySound,a,f)end
return c.try("sound: play",PlaySoundFile,a,f)
end






local e=false
local g={}

function b.muted(a)
if a~=nil then return g[a]==true end
return e
end



function b.play(c,a,b)
local f,g=h(c)
if not f then return false end
if e and a~=nil and not b then return false end
local b=GetTime()
if a~=nil then
local a=d[a]
if a and b-a<j then return false end
end
local e=i[c]
if e and b-e<k then return false end
if a~=nil then d[a]=b end
i[c]=b
m(f,g)
return true
end







local i={Removed=true,Added=true}
local p=1


local d={}

local j,a={},{}

local h=false



local function m()
if h then return true end
if not InCombatLockdown()then return false end
local b,a=c.try("sound: instance",IsInInstance)
return not b or c.isSecret(a)or a==true
end
c.Debug.experimental("aura sound changes wait out an instanced fight or an encounter (C: ShamanPower)","C")

local function k(b)
if not j[b]then
j[b]=true
a[#a+1]=b
end
end



local function n(b)
local a={}
for d,b in ipairs(b.handles)do
if not c.try("sound: aura remove",C_UnitAuras.RemoveAuraSound,b)then a[#a+1]=b end
end
b.handles=a
return#a==0
end

local function q(a,b)
if not b or not i[a.trigger]or#a.ids==0 then return""end
return b..":"..f..":"..a.trigger..":"..table.concat(a.ids,",")
end



local function i(g)
local a=d[g]
if not a then return end
local h=b.fileID(a.value)
local b=(e and a.secret==0)and""or q(a,h)
local e=not e or a.value==nil
if b==a.sig then
if b==""and#a.handles==0 and a.secret==0 and e then d[g]=nil end
return
end
if m()then
k(g)
return
end
a.sig=b
if not n(a)then

a.sig=false
k(g)
return
end
if b==""then
if a.secret==0 and e then d[g]=nil end
return
end
local b=Enum.UnitAuraSoundTrigger[a.trigger]
local e=false
for g,d in ipairs(a.ids)do
local b,d=c.try("sound: aura add",C_UnitAuras.AddAuraSound,b,{unitToken="player",
spellID=d,soundFileID=h,outputChannel=f,throttleSeconds=p})
if b and c.isSecret(d)then
a.secret=a.secret+1
elseif b and type(d)=="number"then
a.handles[#a.handles+1]=d
elseif b then
e=true
end
end

if e and a.secret==0 then
a.sig=false
k(g)
end
end


local function k()
if#a==0 or m()then return end
local b=a
j,a={},{}
for b,a in ipairs(b)do i(a)end
end




function b.setAuraSound(c,e,f,g)
local a=d[c]
if not a then
a={sig="",handles={},secret=0}
d[c]=a
end
local b={}
for c,a in ipairs(f or{})do
if type(a)=="number"then b[#b+1]=a end
end
table.sort(b)
a.value,a.ids,a.trigger=e,b,g or"Removed"
i(c)
end


function b.setChannel(a)
if a==f then return end
f=a
for a in pairs(d)do i(a)end
end




function b.setMuted(a,b)
g[b or"preview"]=a and true or nil
local a=next(g)~=nil
if a==e then return end
e=a
for a in pairs(d)do i(a)end
end

function b.clearAuraSound(a)
if d[a]then b.setAuraSound(a,nil)end
end

l.onEnd("sounds",k)
local i=Enum.AddOnRestrictionType.Encounter
local f=Enum.AddOnRestrictionState.Inactive
l.onRestrictionChange("sounds",function(d,a)






if e and(c.isSecret(a)or a~=f)then
b.setMuted(false,"preview")
b.setMuted(false,"cantAct")
end
if c.isSecret(d)or c.isSecret(a)or d~=i then return end
h=a~=f
if not h then k()end
end)



o.on("PLAYER_LOGOUT","sounds",function()
for b,a in pairs(d)do n(a)end
end)
c.Debug.experimental("aura sounds dropped at PLAYER_LOGOUT so a /reload can't double them (EP-7)","I")


function b.describe()
local b={}
for a in pairs(g)do b[#b+1]=a end
table.sort(b)
local c,f,g=0,0,0
for b,a in pairs(d)do
c=c+1
f=f+#a.handles
g=g+a.secret
end
return{string.format("sounds: %d aura sounds (%d handles, %d secret), %d waiting for combat's end%s%s",
c,f,g,#a,h and", in an encounter"or"",
e and(", muted ("..table.concat(b,", ")..")")or"")}
end
