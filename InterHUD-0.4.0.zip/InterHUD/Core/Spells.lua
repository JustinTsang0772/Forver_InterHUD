



local a,b=...
local d=b.Events

local a={}
b.Spells=a


function a.nameOf(a)
if type(a)~="number"or b.isSecret(a)then return nil end
local c,a=b.try("GetSpellName",C_Spell.GetSpellName,a)
if c and type(a)=="string"and not b.isSecret(a)and a~=""then return a end
end


function a.label(b)
local c=a.nameOf(b)
if c or type(b)~="number"then return c end
local b,a=a.family(b)
return a and a.name or nil
end

function a.icon(c)
if type(c)~="number"or b.isSecret(c)then return nil end
local e,d=b.try("GetSpellTexture",C_Spell.GetSpellTexture,c)
if e and(b.isSecret(d)or d~=nil)then return d end
local b,a=a.family(c)
return a and a.icon or nil
end



function a.listOf(a)
if type(a)=="table"then return a end
if a==nil then return{}end
return{a}
end


function a.firstOf(a)
if type(a)=="table"then return a[1]end
return a
end


function a.rankOf(c,a)
local a=a
if(a==nil or a=="")and C_Spell.GetSpellSubtext then
local d,c=b.try("GetSpellSubtext",C_Spell.GetSpellSubtext,c)
if d and not b.isSecret(c)then a=c end
end
return tonumber((type(a)=="string"and a or""):match("(%d+)"))or 0
end


local c
local function e()
if c then return c end
c={}
local a=b.SpellTable
for a,b in pairs(a and a.families or{})do
for d,b in ipairs(b.ranks or{})do c[b]=a end
for d,b in ipairs(b.copies or{})do c[b]=a end
c[a]=a
end
return c
end




function a.alias(c)
local a=b.SpellTable and b.SpellTable.moved
local a=a and a[c]
if a~=nil and e()[a]==a then return a end
return c
end



function a.family(c)
local a=e()[a.alias(c)]
if a then return a,b.SpellTable.families[a]end
end




function a.ownAuras(a,b)
return a and a.auras and a.auras[b]or{}
end


function a.watchedAuras(b,c)
local d=a.ownAuras(b,c)
if#d==0 and c=="player"then return a.ownAuras(b,"ally")end
return d
end


function a.isKey(b)
local c=a.family(b)
return c~=nil and c==a.alias(b)
end



local c
local function i()
if c then return c end
c={}
for b,a in pairs(b.SpellTable and b.SpellTable.families or{})do
for d,a in pairs(a.auras or{})do
for a,d in ipairs(a)do
local a=c[d]
if not a then
a={}
c[d]=a
end
if a[#a]~=b then a[#a+1]=b end
end
end
end
return c
end


function a.auraFamilies(a)
return i()[a]
end







local c
local function f()
if c then return c end
c={}
for d,a in pairs(b.SpellTable and b.SpellTable.families or{})do
if a.variants or a.equivalents then
local b={variants={},equivalents={}}
for a,c in pairs(a.variants or{})do b.variants[a]=c end
for a,c in pairs(a.equivalents or{})do b.equivalents[a]=c.why end
c[d]=b
end
end
return c
end



function a.widening(b)
return f()[a.alias(b)]
end




local f,c={},0
local g=2000
local function h(a)

if type(a)~="number"then return false end
local d,b=b.try("IsSpellKnown",C_SpellBook.IsSpellKnown,a)
b=d and b==true
if f[a]==nil then
if c>=g then
wipe(f)
c=0
end
c=c+1
end
f[a]=b
return b
end



local c,g={},{}
local j=""

local function l()
local g,h,f={},{},{}
local d=Enum.SpellBookSpellBank.Player
local i=Enum.SpellBookItemType.Spell
for c=1,C_SpellBook.GetNumSpellBookSkillLines()do
local c=C_SpellBook.GetSpellBookSkillLineInfo(c)
if c then
for c=c.itemIndexOffset+1,c.itemIndexOffset+c.numSpellBookItems do
local d,c=b.try("GetSpellBookItemInfo",C_SpellBook.GetSpellBookItemInfo,c,d)
local d=d and c and c.itemType==i and c.spellID
if d and not b.isSecret(d)and not c.isPassive then
local b=c.actionID~=nil and not b.isSecret(c.actionID)and c.actionID or d

local e=e()[b]or e()[d]
local e=e and("#"..e)or a.nameOf(b)or c.name
if e then
local i=a.rankOf(b,c.subName)
local a=g[e]
if not a then
a={ids={}}
g[e]=a
end
a.ids[d],a.ids[b]=true,true
if not a.id or i>a.rank then a.id,a.icon,a.rank=d,c.iconID,i end
h[d],h[b]=a,a
f[#f+1]=d
end
end
end
end
end
table.sort(f)
return g,h,table.concat(f,",")
end

local k=b.keyed("spells changed")
function a.onChange(a,b)k:add(a,b)end


function a.scan()
local b,d,e,a=b.try("spellbook scan",l)
if not b then return end
c,g=d,e
local b=false
for a,c in pairs(f)do
if h(a)~=c then b=true end
end
if a==j and not b then return end
j=a
k:call()
end


local function f(b)
local d=a.family(b)
if d and c["#"..d]then return c["#"..d]end
if g[b]then return g[b]end
local a=a.nameOf(b)
return a and c[a]
end



function a.inBook(a)
local b=e()[a]
return(b and c["#"..b]or g[a])~=nil
end



function a.bookEntries()
local a={}
for b,c in pairs(c)do
local d=tonumber(b:match("^#(%d+)$")or"")
a[#a+1]={id=c.id,icon=c.icon,key=d,name=not d and b or nil}
end
return a
end



function a.highest(a)
local c=f(a)
if c then return c.id,c.icon end
if h(a)then
local d,c=b.try("GetSpellTexture",C_Spell.GetSpellTexture,a)
return a,d and not b.isSecret(c)and c or nil
end
end

function a.known(b)
return a.highest(b)~=nil
end





function a.knowsAtLeast(b)
local d,c=a.family(b)
if not c then return a.known(b)end

if c.pet then return true end
local a=c.ranks or{d}
local c=1
for a,d in ipairs(a)do
if d==b then c=a end
end
local b=f(d)
for c=c,#a do
if b and b.ids[a[c]]then return true end
end
for b=c,#a do
if h(a[b])then return true end
end
return false
end






function a.auraLearned(b)
local c,d=a.family(b)
if c then return d.kind=="aura"or a.knowsAtLeast(c)end
local b=i()[b]
if not b then return true end
for c,b in ipairs(b)do
if a.knowsAtLeast(b)then return true end
end
return false
end



function a.ranks(b)
local c={[b]=true}
local d,a=a.family(b)
for b,a in ipairs(a and a.ranks or{})do c[a]=true end
local a=f(b)
for a in pairs(a and a.ids or{})do c[a]=true end
return c
end

d.on("PLAYER_LOGIN","spells",a.scan)

d.on("SPELLS_CHANGED","spells",function()d.atFrameEnd("spells scan",a.scan)end)

d.on("PLAYER_TALENT_UPDATE","spells",function()d.atFrameEnd("spells scan",a.scan)end)
