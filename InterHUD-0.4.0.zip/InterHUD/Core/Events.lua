
local a,d=...

local a={}
d.Events=a


local b={}
local c=CreateFrame("Frame")


local function f(a)
if C_EventUtils and C_EventUtils.IsEventValid then return C_EventUtils.IsEventValid(a)end
return true
end
a.valid=f

c:SetScript("OnEvent",function(c,a,...)
local b=b[a]
if b then b:call(a,...)end
end)



function a.on(a,g,h)
local e=b[a]
if not e then
if not f(a)or not d.try("register "..a,c.RegisterEvent,c,a)then return false end
e=d.keyed("event "..a)
b[a]=e
end
e:add(g,h)
return true
end

function a.off(a,e)
local d=b[a]
if not d then return end
d:remove(e)
if d:count()==0 then
c:UnregisterEvent(a)
b[a]=nil
end
end





local c={}
local e={}

local function i(b)
local a=c[b]
if a then return a end
local d={}
a={frame=CreateFrame("Frame"),lists=d,armed={}}
a.frame:SetScript("OnEvent",function(b,a,...)
local b=d[a]
if b then b:call(a,...)end
end)
c[b]=a
return a
end


local function h(b,a,d)
local a=c[a]
local c=a and a.lists[b]
if not c then return end
c:remove(d)
if a.armed[b]and c:count()==0 then
a.frame:UnregisterEvent(b)
a.armed[b]=nil
end
end

function a.onUnit(a,g,b,j)
if not f(a)then return false end
local c=e[a]
if not c then
c={}
e[a]=c
end
local e=c[b]
if e~=nil and e~=g then
c[b]=nil
h(a,e,b)
end
local e=i(g)
local f=e.lists[a]
if not f then
f=d.keyed("event "..a)
e.lists[a]=f
end
if not e.armed[a]then
if not d.try("register "..a,e.frame.RegisterUnitEvent,e.frame,a,g)then
f:remove(b)
c[b]=nil
return false
end
e.armed[a]=true
end
f:add(b,j)
c[b]=g
return true
end

function a.offUnit(c,a)
local b=e[c]
local d=b and b[a]
if d==nil then return end
b[a]=nil
h(c,d,a)
end





local function b()return{keys={},fns={},args={}}end
local c,b=b(),b()
local e={}
local f=CreateFrame("Frame")
f:Hide()
f:SetScript("OnUpdate",function(a)
a:Hide()
c,b=b,c
local b,c,f=b.keys,b.fns,b.args
for g=1,#b do
local a=b[g]
local h,i=c[a],f[a]
b[g],c[a],f[a]=nil,nil,nil
d.try(e[a],h,i)
end
end)

function a.atFrameEnd(a,d,g)
local b=c
if b.fns[a]==nil then b.keys[#b.keys+1]=a end
b.fns[a],b.args[a]=d,g
if not e[a]then e[a]="frame end "..tostring(a)end
f:Show()
end
