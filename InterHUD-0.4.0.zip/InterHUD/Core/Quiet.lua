




local a,d=...
local e,h=d.Events,d.Ticker

local a={}
d.Quiet=a


a.SHOW,a.LOADING=1.5,1.5

local c={}
local b=0
local d=d.keyed("quiet")
local f=false


function a.onChange(a,b)d:add(a,b)end


local function i()
local e=GetTime()
if b>0 and b~=math.huge and e>=b then
b=0
d:call(nil)
end

local a
for b,c in pairs(c)do
if e>=c then
a=a or{}
a[#a+1]=b
end
end
for b,a in ipairs(a or{})do
c[a]=nil
d:call(a)
end
if b==0 and next(c)==nil then
h.unsubscribe(0.1,"quiet")
f=false
end
end

local function g()
if f then return end
f=true
h.subscribe(0.1,"quiet",i)
end



function a.open(b,e)
local a=GetTime()+(e or a.SHOW)
if(c[b]or 0)>=a then return end
c[b]=a
g()
d:call(b)
end


function a.openAll(c)
local a=GetTime()+(c or a.SHOW)
if b>=a then return end
b=a
g()
d:call(nil)
end

function a.isQuiet(a)
if b>0 and(b==math.huge or GetTime()<b)then return true end
local a=a and c[a]
return a~=nil and GetTime()<a
end


e.on("PLAYER_LOGIN","quiet",function()a.openAll(a.LOADING)end)



e.on("PLAYER_LEAVING_WORLD","quiet",function()
b=math.huge
g()
d:call(nil)
end)
local function c()
if b==math.huge then b=0 end
a.openAll(a.LOADING)
end
e.on("PLAYER_ENTERING_WORLD","quiet",c)
e.on("LOADING_SCREEN_DISABLED","quiet",c)



local b=CreateFrame("Frame",nil,UIParent)
b:SetSize(1,1)
b:SetPoint("TOPLEFT")
b:SetScript("OnShow",function()a.openAll(a.SHOW)end)
