
local a,d=...

local a={}
d.Ticker=a


a.RATES={0.1,0.2,0.5,1}

local b={}

local function e(a,b)
a.wait=a.wait+b
if a.wait<a.rate then return end

a.wait=a.wait-a.rate
if a.wait>a.rate then a.wait=0 end
a.list:call()
end

local function c(c)
local a=b[c]
if a then return a end
a={rate=c,list=d.keyed("ticker "..c),wait=0,frame=CreateFrame("Frame")}
a.frame:Hide()
a.frame:SetScript("OnUpdate",function(c,b)e(a,b)end)
b[c]=a
return a
end


function a.subscribe(a,b,d)
local a=c(a)
a.list:add(b,d)
a.frame:Show()
end

function a.unsubscribe(a,c)
local a=b[a]
if not a then return end
a.list:remove(c)
if a.list:count()==0 then
a.frame:Hide()
a.wait=0
end
end


function a.describe()
local a={}
for b in pairs(b)do a[#a+1]=b end
table.sort(a)
local c={}
for d,a in ipairs(a)do
local b=b[a].list:count()
if b>0 then c[#c+1]=string.format("%gs: %d",a,b)end
end
return{"tickers: "..(#c>0 and table.concat(c,", ")or"none running")}
end
