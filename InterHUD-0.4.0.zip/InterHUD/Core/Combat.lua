


local b,a=...
local d=a.Events

local b={}
a.Combat=b



local f=InCombatLockdown()

function b.inCombat()
return f or InCombatLockdown()
end


function b.aurasSecret()
if not(C_Secrets and C_Secrets.ShouldAurasBeSecret)then return false end
local c,b=a.try("aurasSecret",C_Secrets.ShouldAurasBeSecret)
if not c or a.isSecret(b)then return true end
return b==true
end


function b.buttonsWritable()
return not InCombatLockdown()and not b.aurasSecret()
end

local function e()return not InCombatLockdown()end



local function c(a,b)
return{keys={},fns={},sites={},prefix=a,ready=b}
end
local g=c("after combat",e)
local c=c("button write",b.buttonsWritable)

local function e(b,c)
local a=b.sites[c]
if not a then
a=b.prefix.." "..tostring(c)
b.sites[c]=a
end
return a
end

local function i(a,b,c)
if a.fns[b]==nil then a.keys[#a.keys+1]=b end
a.fns[b]=c
end

local function k(a,b)
if a.fns[b]==nil then return end
a.fns[b]=nil
for c=#a.keys,1,-1 do
if a.keys[c]==b then table.remove(a.keys,c)end
end
end


local function h(b)
local c,d=b.keys,b.fns
b.keys,b.fns={},{}
for f=1,#c do
local c=c[f]
local d=d[c]
if d then
if b.ready()then
a.try(e(b,c),d)
else
i(b,c,d)
end
end
end
end


local function j(b,c,d)
if b.ready()then
k(b,c)
a.try(e(b,c),d)
return true
end
i(b,c,d)
return false
end


function b.whenUnlocked(a,b)return j(g,a,b)end




local e=false
local function i()
h(c)
if#c.keys==0 or InCombatLockdown()then
a.Ticker.unsubscribe(0.5,"button queue")
e=false
end
end
local function k()
h(c)
if#c.keys>0 and not InCombatLockdown()and not e then
e=true
a.Ticker.subscribe(0.5,"button queue",i)
end
end

function b.whenButtonsWritable(b,d)
local b=j(c,b,d)
if not b and not InCombatLockdown()and not e then
e=true
a.Ticker.subscribe(0.5,"button queue",i)
end
return b
end


local e,i,j=a.keyed("combat start"),a.keyed("combat end"),a.keyed("restriction change")
function b.onStart(a,b)e:add(a,b)end
function b.onEnd(a,b)i:add(a,b)end
function b.onRestrictionChange(a,b)j:add(a,b)end

d.on("PLAYER_REGEN_DISABLED","combat",function()
f=true
e:call()
end)


d.on("PLAYER_REGEN_ENABLED","combat",function()
f=false
h(g)
k()
i:call()
end)



local e=Enum and Enum.AddOnRestrictionState and Enum.AddOnRestrictionState.Inactive or 0
d.on("ADDON_RESTRICTION_STATE_CHANGED","combat",function(f,c,b)
if not a.isSecret(b)and b==e then d.atFrameEnd("combat restriction",k)end
j:call(c,b)
end)

function b.describe()
return{string.format("combat: in combat %s, lockdown %s, auras secret %s, queued %d protected, %d button",
tostring(f),tostring(InCombatLockdown()),tostring(b.aurasSecret()),#g.keys,
#c.keys)}
end




local function c(b,c)
local c,b=a.try(b,c,"player")
return c and not a.isSecret(b)and b==true
end
function b.deadOrGhost()return c("UnitIsDeadOrGhost",UnitIsDeadOrGhost)end
function b.cantAct()
return b.deadOrGhost()or c("UnitOnTaxi",UnitOnTaxi)
end



local c,e=a.keyed("can act"),false
function b.onCanActChange(a,b)c:add(a,b)end
local function f()
local a=b.cantAct()
if a==e then return end
e=a
c:call(a)
end
local function c()
a.Ticker.unsubscribe(1,"can act")
f()
end
for e,b in ipairs({"PLAYER_DEAD","PLAYER_ALIVE","PLAYER_UNGHOST","PLAYER_CONTROL_LOST",
"PLAYER_CONTROL_GAINED","PLAYER_ENTERING_WORLD"})do
d.on(b,"can act",function()
f()
if b=="PLAYER_CONTROL_LOST"or b=="PLAYER_CONTROL_GAINED"then
a.Ticker.subscribe(1,"can act",c)
end
end)
end
