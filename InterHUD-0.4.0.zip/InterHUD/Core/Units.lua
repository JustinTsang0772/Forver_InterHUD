

local b,a=...
local c,i=a.Events,a.Target

local b={}
a.Units=b

local d={}
local g={}
local h={}


b.TOKENS={"player","target","pet","focus"}

local function e(a,c)
local b=d[a]
if b then b:call(a,c)end
end



local function f(d,c)
h[d]=not c or nil
if not c then a.Debug.register("unit watch",b.describe)end
return c
end





local e={
target=function()
i.onChange("unit watch",function(b,a)e("target",a)end)
return true
end,
focus=function()
return f("PLAYER_FOCUS_CHANGED",
c.on("PLAYER_FOCUS_CHANGED","unit watch",function(a)e("focus",a)end))
end,
pet=function()
local function a(a)e("pet",a)end

local b=f("UNIT_PET",c.onUnit("UNIT_PET","player","unit watch",a))
local a=f("PET_UI_UPDATE",c.on("PET_UI_UPDATE","unit watch",a))
return b and a
end,
}




function b.onChange(b,f,h)
local c=d[b]
if not c then
c=a.keyed("unit change "..b)
d[b]=c
end
c:add(f,h)
if not g[b]and e[b]then g[b]=e[b]()or nil end
end


local function c(b,c,d)
local c,b=a.try("unit read",b,c,d)
if not c or a.isSecret(b)then return nil end
return b
end


function b.hostile(a)
return c(UnitExists,a)==true and c(UnitCanAttack,"player",a)==true
and not c(UnitIsDead,a)
end


function b.alive(a)
return c(UnitExists,a)==true and c(UnitIsDeadOrGhost,a)==false
end


function b.describe()
local a={}
for b in pairs(h)do a[#a+1]=b end
if#a==0 then return{}end
table.sort(a)
return{"unit watch: the game refused "..table.concat(a,", ")
.."; a unit change that only those events report is missed"}
end
