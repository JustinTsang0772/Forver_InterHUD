
local a,f=...
local h,d,i,e,a,k,b=f.Schema,f.Sources,f.Layers,f.Spells,f.Totems,f.Ticker,f.Debug


b.experimental("a totem element's Expiring: a gate whose alpha a curve on the slot's duration sets, polled, held past"
.." its zero till the slot empties (A6; TO-3, TO-7's curve route, as the totem bar's Expiring)","C")





local b={sound=false}



local c={{name="slot",type="choice",choices=a.SLOT_ORDER,label="Slot",
labels={earth="Earth",fire="Fire",water="Water",air="Air"}},
d.spellsField("Totems","Spell IDs; left out, any totem in the slot.")}



local g={label="Expiring",holds="The totem is in its last seconds.",read="gate",within="down",max=1,
setting={{name="seconds",type="integer",default=10,min=1,max=30,unit="s",label="Seconds"}},
default=function()return{}end}

d.register("totem",{
fields=c,
idWord="totem",
target={field="slot",pick="Pick its slot."},
variantOrder={"totem"},
variants={
totem={
add={label="Totem",note="A totem"},
noun="a totem",

read="lua",moment="plain",
stateOrder={"down","empty"},

states={
down={label="Down",holds="Your totem is down."},
empty={label="Not down",holds="Your totem isn't down."},
},
factOrder={"expiring"},facts={expiring=g},
eventOrder={"placed","ended","killedEarly","ranOut"},
events={
placed={label="Placed",holds="it's put down",begins="down"},
ended={label="Ended",holds="it ends",begins="empty"},
killedEarly={label="Killed early",holds="it ends early",effects=b,begins="empty"},
ranOut={label="Ran out",holds="it runs out",effects=b,begins="empty"},
},
},
},
})

local b=d.get("totem")

b.pickWords="Pick its totem."


local function g(a)return e.listOf(a.spells)end



function b.learned(a)
local b=g(a)
if#b==0 then return true end
local c=d.exactSet(a.exact)
for b,a in ipairs(b)do
if c and c[a]then
if e.knowsAtLeast(a)then return true end
elseif e.known(a)then
return true
end
end
return false
end

function b.yourSpells(a)return g(a)end

d.takesExact("totem")


b.matches=d.get("spell").matches



function b.shownSpell(c)
local b=g(c)
for b,a in ipairs(b)do
if e.known(a)then return a end
end
if b[1]then return b[1]end
return a.spellsOf(a.SLOTS[c.slot]or 0)[1]
end





local c={earth="Earth",fire="Fire",water="Water",air="Air"}


local j={earth=136098,fire=135825,water=136053,air=136046}
function b.addChoices(d,i)
local f=d and d~=""and d:lower()or nil
local b={}
for g,h in ipairs(a.SLOT_ORDER)do
for g,a in ipairs(a.spellsOf(a.SLOTS[h]))do

local g=e.label(a)
if g and(not f or g:lower():find(f,1,true)or tostring(a)==d)and#b<(i or 30)then
b[#b+1]={id=a,name=g,icon=e.icon(a),note=c[h]}
end
end
end
table.sort(b,function(a,b)return a.name<b.name end)
for d,a in ipairs(a.SLOT_ORDER)do
local c="Any "..c[a]:lower().." totem"
if not f or c:lower():find(f,1,true)then
b[#b+1]={id="slot:"..a,name=c,icon=j[a],
note="Any of yours in its slot"}
end
end
return b
end

function b.icon(a)
return a and#g(a)==0 and j[a.slot]or nil
end

function b.words(a)
local a=a and c[a.slot]
return a and"Any "..a:lower().." totem"or nil
end



local j={
[2484]="earth",[5730]="earth",[8071]="earth",[8075]="earth",[8143]="earth",
[3599]="fire",[8181]="fire",[8190]="fire",[8227]="fire",
[5394]="water",[5675]="water",[8166]="water",[8170]="water",[8184]="water",[16190]="water",
[6495]="air",[8177]="air",[8512]="air",[8835]="air",[10595]="air",[15107]="air",
}
local function g(b)
local c=a.slotOf(b)
for a,b in pairs(a.SLOTS)do
if b==c then return a end
end
return type(b)=="number"and j[e.family(b)or b]or nil
end
function b.addRecord(b)
local d=type(b)=="string"and b:match("^slot:(%a+)$")
if d then
if not a.SLOTS[d]then return nil end
return{kind="totem",slot=d},c[d].." totem"
end
local a=g(b)
if a then return{kind="totem",slot=a,spells={b}},e.label(b)end
end



b.picks={data="spell",facets={class="SHAMAN"},byId=false,
fits=function(a)return a.kind=="spell"and g(a.id)~=nil end,
line=function(a)return c[g(a.id)or""]end}


h.caveat("totem from your cast",{
text="Known from your own cast: after a /reload in combat, shown from your next cast.",
at=function(a)return h.isPath(a,"sources","*","spells")end,
applies=function(a,b)
local a=type(a.sources)=="table"and a.sources[b[2]]
return type(a)=="table"and a.kind=="totem"
end,
})


local j={killedEarly=true,ranOut=true}

b.variants.totem.events.killedEarly.still=true
b.variants.totem.events.ranOut.still=true



function b.plan(c)
local a=c.source
local b={kind="totem",slot=a.slot,spells=a.spells,exact=a.exact,parts=i.allParts(c,nil)}
d.planCopies(c,b)
local d=d.firstItem(a,"expiring")
if d then b.expiring,b.expiringKey=d.seconds,a.id.."."..d.id end
for b,a in ipairs(b.parts)do
if a.effect and j[a.event]then
a.holder="gate:"..a.event


local b=i.effect(a.kind)
a.shape=b and b.shape and b.shape(c.effects[a.effect],false)or nil
end
end
return b
end

local h="unknown"
local l=134400
local g={}
local c={}
c.__index=c



function c:mine(a)
if#self.list==0 then return true end
if a==nil then return false end
local c,d=e.family(a),self.exact
for f,b in ipairs(self.list)do
if b==a or(c~=nil and not(d and d[b])and c==e.family(b))then return true end
end
return false
end



function c:read()
local g=self.slot
local d=a.ownerOf(g)
local c=a.isDown(g)and self:mine(d)
local f=c and"down"or"empty"
if f~=self.state then
self.state=f
self.element:setState(f)
end
local f=self.data
f.duration=c and a.durationOf(g)or false
local a=c and d and self:mine(d)and d or b.shownSpell(self.view.source)


if c and d==nil then a=h end
if a~=self.shown then
self.shown=a
f.icon=a==h and l or a and e.icon(a)or nil
f.name=a~=h and a and e.label(a)or false
end
self.element:feed(f)
self.isDown=c
self:regate()
return c
end






local h={}
local function l()
for a in pairs(h)do a:light()end
end
function c:light()
if not self.curve then return end
local b,c=0,1
local a=self.isDown and a.durationOf(self.slot)
if a then
local d,e=f.try("totem expiring curve",a.EvaluateRemainingDuration,a,self.curve)
local a,f=f.try("totem expiring curve",a.EvaluateRemainingDuration,a,self.offCurve)
if d and a then b,c=e,f end
end
d.lightGates(self.element.element,self.rig.expiringKey,b,c)
end
function c:poll(a)
if(h[self]~=nil)==a then return end
h[self]=a or nil
if a then
k.subscribe(0.1,"totem expiring",l)
elseif not next(h)then
k.unsubscribe(0.1,"totem expiring")
end
end

function c:regate()
self:light()
self:poll(self.isDown and self.curve~=nil and d.usesGate(self.element.element,self.rig.expiringKey)or false)
end


local function k(b)
local c={}
for d in pairs(j)do
local e,g=false,0
if b then e,g=f.try("totem end curve",b.EvaluateRemainingDuration,b,a.endCurve(d))end
c[d]=e and g or 0
end
return c
end




function c:onSlot(a,b,c)
if a=="emptied"and b then

self.endAlphas,self.endAt=k(b),GetTime()
end
if a=="ended"then
if not self:mine(c)then return end
local c=self.endAlphas and self.endAt and GetTime()-self.endAt<1 and self.endAlphas or k(b)
self.endAlphas=nil
for a in pairs(j)do
local b=self.ends and self.ends[a]
if b then b:SetAlpha(c[a])end
end
self.lastEnd=GetTime()
self.element:moment("ended")
self.element:moment("killedEarly")
self.element:moment("ranOut")
return
end
local c=self.state
local d=self:read()
if d and c~="down"and(a=="placed"or(a=="owner"and b==true))then
self.lastPlaced=GetTime()
self.element:moment("placed")
end
end


function b.build(g,b,h,f)
if f then f:release()end
local a=setmetatable({element=g,view=h,rig=b,slot=a.SLOTS[b.slot],
list=e.listOf(b.spells),exact=d.exactSet(b.exact),data={}},c)
d.plainBuild(a,g,b,f)
a.ends=a.frames.ends

a.curve=b.expiring and i.lastCurve(b.expiring,true)or nil
a.offCurve=b.expiring and i.lastCurve(b.expiring,true,true)or nil
return a
end

function c:paint()
d.plainPaint(self)
end

function c:start()
g[self]=true
a.watch(self.element.id)
self.state,self.shown=nil,nil
self:read()
end

function c:stop()
g[self]=nil
self:poll(false)
a.unwatch(self.element.id)
end

function c:release()
self:stop()
self.host:Hide()
end

function c:refeed()
self.shown=nil
self:read()
end


function c:respell()
if g[self]then self:refeed()end
end

function c:describe()
local b=a.ownerOf(self.slot)
return string.format("totem %s slot %s, %s, %s%s%s%s",tostring(self.rig.slot),tostring(self.slot),
tostring(self.state),#self.list==0 and"any totem"or(#self.list.." named"),
a.isDown(self.slot)and(", owner "..(b and tostring(b)or"unknown"))or"",
self.lastEnd and string.format(", last end at %.1f",self.lastEnd)or"",
self.curve and string.format(", Expiring in the last %s s%s",tostring(self.rig.expiring),
h[self]and" (polled)"or"")or"")
end


local c={cast=true,dismissed=true}
a.onChange("totem source",function(d,b,e,h)
if c[b]then return end
for a in pairs(g)do
if a.slot==d then f.try("totem "..a.element.id,a.onSlot,a,b,e,h)end
end
end)

b.live=g
