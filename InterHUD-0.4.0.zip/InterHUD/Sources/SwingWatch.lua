


local a,c=...
local i,j,b=c.Events,c.Ticker,c.Debug

local a={}
c.SwingWatch=a


b.experimental("the swing watch's weapon-swap restart: WEAPON_SLOT_CHANGED restarting the swing under way at"
.." UnitAttackSpeed (D: Blizzard's own swing timer, ResetSwingTimerForEquippedWeapon; the speed is secret in a"
.." fight, UN-11, so a swap there clears; what a swap does to the swing is EP-33, unrun)","D")
b.experimental("swings in a restricted fight, an instance or a dungeon (CA-8 restricted untested: EP-24)","I")
b.experimental("the off hand's and ranged swings: PLAYER_SWING's OffHand and Ranged types read as the main hand's"
.." (D: SwingTimerDocumentation, Blizzard's three bars; CA-8 saw the main hand only: EP-16)","D")
b.experimental("a swing due: none come within the grace after the last one's time ran out (CA-8: the gaps within"
.." 0.04 s of the duration in steady swinging; a miss, a parry and a cast between unseen: EP-32, EP-35)","I")


local b=Enum and Enum.PlayerSwingType or{}
a.HANDS={main=b.MainHand or 0,off=b.OffHand or 1,ranged=b.Ranged or 2}
a.ORDER={"main","off","ranged"}
local k={}
for a,b in pairs(a.HANDS)do k[b]=a end

local l=0.1


local m=0.25




local b={}
for a in pairs(a.HANDS)do
b[a]={swings=0,secret=0,invalid=0,restarts=0,heard={},cleared={}}
end




local d=c.keyed("swing watch")
function a.onChange(a,b)d:add(a,b)end
function a.offChange(a)d:remove(a)end


function a.state(a)
local a=b[a]
if a and a.endsAt then return a.length,a.startedAt,a.endsAt end
return nil
end


function a.phase(a)
local a=b[a]
if not a then return nil end
if a.endsAt or a.dueAt then return"swinging"end
return a.due and"due"or nil
end

local e=false
local function f()
for b,a in pairs(b)do
if a.endsAt or a.dueAt then return true end
end
return false
end
local function h()
if e and not f()then
e=false
j.unsubscribe(l,"swingWatch")
end
end

local function f(c)
local a=b[c]
local b=a.dueAt~=nil or a.due
a.dueAt,a.due=nil,false
h()
if b then d:call("unknown",c)end
end

local function g(e,c)
local a=b[e]
a.heard[c]=(a.heard[c]or 0)+1
if not a.endsAt then return end
a.endsAt,a.length,a.startedAt=nil,nil,nil
a.cleared[c]=(a.cleared[c]or 0)+1
a.last=c
if c=="ran out"then a.dueAt=GetTime()+m end
h()
d:call("clear",e,c)
end
local function m(a)
for b in pairs(b)do g(b,a)end
end


local function n()
local c=GetTime()
for b,a in pairs(b)do
if a.endsAt and c>=a.endsAt then g(b,"ran out")end
if a.dueAt and c>=a.dueAt then
a.dueAt,a.due=nil,true
h()
d:call("due",b)
end
end
end


local function h(f,c,g)
local a=b[f]
local b=GetTime()
a.length,a.startedAt,a.endsAt=c,b,b+c
a.dueAt,a.due=nil,false
if not e then
e=true
j.subscribe(l,"swingWatch",n)
end
d:call("swing",f,c,b,g)
end


local function d(a)
if c.isSecret(a)then return"secret"end

if type(a)~="number"or a~=a or a<=0 or a==math.huge then return"invalid"end
end

local function e(i,e,a)
if c.isSecret(a)then return end
local a=k[a]
if not a then return end
local b=b[a]
b.swings=b.swings+1
local c=d(e)
if c then
b[c]=b[c]+1
f(a)
return g(a,c)
end
h(a,e)
end


local function j(a)
if not UnitAttackSpeed then return nil end
local b,c,d,e=c.try("UnitAttackSpeed",UnitAttackSpeed,"player")
if not b then return nil end
if a=="main"then return c end
if a=="off"then return d end
return e
end



local function c()
for c in pairs(b)do
local a=b[c]
if a.endsAt then
local b=j(c)
if d(b)then
g(c,"weapon swap")
f(c)
else
a.heard["weapon swap"]=(a.heard["weapon swap"]or 0)+1
a.restarts=a.restarts+1
h(c,b,"weapon swap")
end
else
a.heard["weapon swap"]=(a.heard["weapon swap"]or 0)+1

f(c)
end
end
end



local g={
{"PLAYER_SWING",e},
{"WEAPON_SLOT_CHANGED",c},
}
local c={}
local d={}

local function e(b)
for c,a in ipairs(g)do
if b then
d[a[1]]=i.on(a[1],"swingWatch",a[2])
else
i.off(a[1],"swingWatch")
d[a[1]]=nil
end
end
end

function a.watch(a)
if not next(c)then e(true)end
c[a]=true
end
function a.unwatch(a)
if not c[a]then return end
c[a]=nil
if not next(c)then
e(false)
m("stopped")
for a in pairs(b)do f(a)end
end
end
function a.watching()return next(c)~=nil end

local function e(b)
local a={}
for b in pairs(b)do a[#a+1]=b end
table.sort(a)
for d,c in ipairs(a)do a[d]=c.." "..b[c]end
return#a>0 and table.concat(a,", ")or"none"
end

function a.describe()
local c={}
for d,f in ipairs(a.ORDER)do
local b=b[f]
local d=b.endsAt and b.endsAt-GetTime()
c[#c+1]=string.format("swing %s: %s; %d swings seen, %d with a secret duration, %d invalid, %d weapon"
.." swap restarts; %s",f,a.watching()and"on"or"off",b.swings,b.secret,b.invalid,b.restarts,
d and(d>0 and string.format("next in %.1f s",d)or"due")or b.due and"due"
or"no swing under way")
c[#c+1]="  clears by cause: "..e(b.cleared).."; last "..tostring(b.last or"none")
.."; events heard: "..e(b.heard)
end
local a={}
for b,c in pairs(d)do
if not c then a[#a+1]=b end
end
if#a>0 then
table.sort(a)
c[#c+1]="  the client took no: "..table.concat(a,", ")
end
return c
end
