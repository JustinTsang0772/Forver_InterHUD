


local a,c=...
local h,a,d,q,f,g=c.Schema,c.Spells,c.Layers,c.Sources,c.Resolve,c.Keys
local b=c.Sources.get("aura")






local function e(d,a)
local c
local e=b.dataUnit(a)
for b,a in ipairs(d)do
if a.unit==e then return a end
if a.unit=="ally"then c=a end
end
if b.takesAlly(a)then return c end
end
b.picks={data="aura",on=e,fits=function(b,a)
a=a or"player"
if b.kind=="item"then return false end
if b.list=="spellbook"then return true end
local b=e(b.watch.auras,a)
return b~=nil and c.GameData.canWatchById(a,b.harmful)==true
end,



unitFor=function(b)
if e(b or{},"player")then return"player"end
local a=false
for c,b in ipairs(b or{})do
if b.unit=="target"then return"target"end
a=a or b.unit=="pet"
end
return a and"pet"or"player"
end}



function b.watchedAuras(c,d)
local b=a.watchedAuras(c,b.dataUnit(d))
if#b==0 and d=="pet"then return a.ownAuras(c,"ally")end
return b
end



function b.widens(b,c)
return not(c and c[b])and a.isKey(b)
end

c.Sources.takesExact("aura")













local function e(c,d,f,e,g)
if not b.widens(d,g)then
c[d]=true
return
end
local h,g=a.family(d)
local h=a.ownAuras(g,b.dataUnit(f))
if#h>0 then
for b,a in ipairs(h)do c[a]=true end
else
if b.takesAlly(f)then
for b,a in ipairs(a.ownAuras(g,"ally"))do c[a]=true end
end
for a in pairs(a.ranks(d))do c[a]=true end
end
local a=f=="player"and e~="own"and a.widening(d)
if not a then return end
for a,b in pairs(a.variants)do
if not(e=="yours"and b=="other")then c[a]=true end
end
if e=="copies"or e=="yours"then return end
for a in pairs(a.equivalents)do c[a]=true end
end
function b.auraIds(d,f,g,b)
local b,c={},c.Sources.exactSet(b)
for d,a in ipairs(a.listOf(d))do e(b,a,f,g,c)end
return b
end

function b.matches(a,c)return b.auraIds(a,c.unit or"player")end


function b.ownIds(a,c,d)return b.auraIds(a,c,"own",d)end







function b.widenedFrom(f,g,d,e)
local c,e,h={variants={},equivalents={}},{},c.Sources.exactSet(e)
if(g or"player")~="player"then return c end
for g,f in ipairs(a.listOf(f))do
local b=b.widens(f,h)and a.widening(f)
for f,a in ipairs(b and(d and{"variants"}or{"variants","equivalents"})or{})do
for b,f in pairs(b[a])do
if not e[b]and not(d and f=="other")then
e[b]=true
c[a][#c[a]+1]=b
end
end
end
end
table.sort(c.variants)
table.sort(c.equivalents)
return c
end




function b.learned(b)
if b.castBy=="anyone"then return true end
local b=a.listOf(b.spells)
if#b==0 then return true end
for c,b in ipairs(b)do
if a.auraLearned(b)then return true end
end
return false
end




function b.yourSpells(c)
if c.castBy=="anyone"then return{}end
local b={}
for d,c in ipairs(a.listOf(c.spells))do
local d,e=a.family(c)
if d then
if e.kind=="aura"then return{}end
b[#b+1]=c
else
local a=a.auraFamilies(c)
if not a then return{}end
for c,a in ipairs(a)do b[#b+1]=a end
end
end
return b
end




function b.shownSpell(d)
local b=a.listOf(d.spells)
if#b<2 then return b[1]end
if d.shownSpell=="lastSeen"then
local a=c.LastSeen.get(b)
if a then return a end
end
for c,b in ipairs(b)do
if(a.family(b)or a.auraFamilies(b))and a.auraLearned(b)then return b end
end
return b[1]
end





c.Debug.experimental("Cast by Anyone: another player's copy of a buff on you matched by its IDs with no PLAYER filter "
.."(EP-28, unplayed)")
c.Debug.experimental("Cast by Anyone on an enemy: its debuff matched by its IDs under HARMFUL with no PLAYER filter"
.." (AU-13 by Blizzard's source; a second player's copy unplayed)")
function b.filterOf(d,a,c)
if a then return a.filter end
if b.onEnemy(d)then return c and"HARMFUL"or"HARMFUL|PLAYER"end
return c and"HELPFUL"or"HELPFUL|PLAYER"
end



function b.candidatesOf(a,b)
if a.typed then return c.copy(a.typed.candidates)end
return{includeSpellIDs=b}
end

local function i(a,b)
return a.x==b.x and a.y==b.y and a.w==b.w and a.h==b.h
end

local function j(b,a)
for c,a in ipairs(a)do
if b.sockets[a]and not d.MULTI[a]then return false end
end
return true
end







local function o(c,a,d,e)
for c,b in ipairs(c.slots)do
if b.kind==d and b.region==a.region and b.half==a.half and b.gate==a.gate
and b.curve==a.curve and b.dim==a.dim and i(b.rect,e)and j(b,a.sockets or{})then
a.slot=c
return b
end
end
local b={n=#c.slots+1,kind=d,rect=e,sockets={},parts={},level=a.level,
region=a.region,half=a.half,gate=a.gate,bits=a.gate and a.bits,mask=a.gate and a.mask,
curve=a.curve,curveOn=a.curve and a.curveOn,dim=a.dim}
if d=="driver"then b.sockets.durationBar="driver"end
c.slots[b.n]=b
a.slot=b.n
return b
end

local v={button="button",expiring="driver"}





local function w(a,b,c)
for e,a in ipairs(a)do
local b=a.kind=="icon"and a.layer and not a.partKey and b.layers[a.layer]
local c=b and(c or b.picture~=nil)
if c and a.sockets and d.inList(a.sockets,"icon")then
local c={}
for b,a in ipairs(a.sockets)do
if a~="icon"then c[#c+1]=a end
end
a.sockets,a.ownPicture,a.picture=c,true,b.picture
end
end
return a
end
c.Debug.experimental("an aura icon keeping its own picture (a dispel type's spell, a layer's Picture): the button's"
.." icon socket withheld, our texture set inside its init and fed while button writes are allowed (AU-30: unseen"
.." in combat)","I")




function b.cellOf(a)
return c.Check.cellOf(a,a.source)
end

local function n(b,a)
b.cellRun=c.Check.cellRun(a,a.source)
return c.Check.cellInto(a,b.cellRun,{})
end












local l=c.Check.coverOnly
local function m(a)
if type(a)~="table"then return false end
for a in pairs(a)do
if a~="opacity"then return false end
end
return a.opacity~=nil
end
local function s(b,a)
if a.values then return a.values end
return a.borrow and b.borrowed and b.borrowed[a.borrow]or nil
end
local function t(d,i,c,j,n,o)
local a=i.compiled
local b={looks={},bits={},counts=0,gates={},over=0}
if not a then return b end
local f,g={},{}
local k=c..".missing"
for p,c in ipairs(a.flags)do
local a={flag=c,w=c["while"],u=c.unless,gates={}}
local e={}
local h=false
for c,b in ipairs(c["while"])do
local f=d:atomsOf(b)
local c=d:term(b)
if b==k then h=true end

if c and c.kind=="cond"then
local function e(b,a)
a=a or{}
if a[b]then return false end
a[b]=true
for c,b in ipairs(d.conds[b]and d.conds[b].all or{})do
if b==k then return true end
local b=d:term(b)
if b and b.kind=="cond"and e(b.id,a)then return true end
end
return false
end
if e(c.id)then h=true end
end
if next(f.lua)then e[#e+1]="w:"..b end
for b,c in pairs(f.drawn)do
if c=="gate"then a.gates[#a.gates+1]=b end
end
end
for c,b in ipairs(c.unless)do
local c=d:atomsOf(b)
if next(c.lua)then e[#e+1]="u:"..b end
for b,c in pairs(c.drawn)do
if c=="gate"then a.gates[#a.gates+1]=b end
end
end
a.lua=#e>0
a.mixed=d:mixedNegative(c["while"],c.unless)
local i=s(i,c)
if a.lua and not h and not o then
table.sort(e)
local d=table.concat(e,"&")
local e=not j and l(i)
local h=not j and not e and m(i)

local i=not e and not g[d]and b.counts>=n
if i then
e,h=true,false
a.over=true
b.over=b.over+1
end
if not e then
if not g[d]then
g[d]=true
b.counts=b.counts+1
end
a.cbit=d
end
a.cover,a.dim=e or nil,h or nil
if not e and not h then
if not f[d]then
b.bits[#b.bits+1]={sig=d,["while"]=c["while"],unless=c.unless}
f[d]=#b.bits
end
a.bit=f[d]
end
end


for c,a in ipairs(a.gates)do b.gates[a]="change"end
b.looks[p]=a
end
return b
end


local function i(a,b,c,d)
local b={[a..".present"]=b=="present",[a..".missing"]=b=="missing"}
for c in pairs(c or{})do b[a.."."..c]=true end
for a,c in pairs(d or{})do b[a]=c end
return b
end






local function u(b,e)
local a=b.compiled
if not a then return b end
local d={}
for b,a in ipairs(a.flags)do
d[b]={i=a.i,["while"]={"#look."..b},unless={},values=a.values,borrow=a.borrow}
end
local c={}
for a,b in pairs(a)do c[a]=b end
c.flags=d
local a={}
for b,c in pairs(b)do a[b]=c end
a.compiled=c
a.lookInfo=e
return a
end
local function j(e,a,c,g,h)
local b=a.lookInfo
local d={}
for f,a in pairs(b.looks)do
local b
if a.lua and not a.bit then
b=false
else
b=e:lookPart(a.w,a.u,"lua",c)
if b and a.bit then
local c
for b,d in ipairs(h)do
if d==a.bit then c=b end
end
b=c~=nil and math.floor(g/2^(c-1))%2==1
end
end
d["#look."..f]=b
end
return f.lookAt(a,function(a)
local b=d[a]
if b~=nil then return b end
return c[a]==true
end)
end



local function l(a,b,c)
if not a or type(b)~="table"then return false end
if a.colourByCount and a.colourByCount(b)then return true end
return c and a.colourByTime and a.colourByTime(b)or false
end


local e=setmetatable({},{__mode="k"})
local function a(b)
local a=e[b]
if a then return a end
a={}
for c,d in ipairs(b)do
local b={}
for a in d:gmatch("[^%.]+")do b[#b+1]=a end
a[c]=b
end
e[b]=a
return a
end
local e={}
local function m(b)
local a=e[b]
if a then return a end
a={}
for c,b in ipairs(d.partsOf(b))do a[b.key]=b end
e[b]=a
return a
end

local function k(b,j)
local h={}
local c=d.get(b.kind)
local k=m(b.kind)
local i=f.leafPaths(b)
for m,a in ipairs(a(i))do
local g,c,e=c,b
local f=k[a[1]]
if#a==1 then
e=b[a[1]]
elseif f and not f.list then
g,c=d.part(f.kind),b[a[1]]
e=type(c)=="table"and c[a[2]]or nil
elseif f then
g=d.part(f.kind)
c=nil
for d,b in ipairs(type(b[a[1]])=="table"and b[a[1]]or{})do
if b.id==a[2]then c=b end
end
e=type(c)=="table"and c[a[3]]or nil
else

local b=b[a[1]]
e=type(b)=="table"and b[a[2]]or nil
end
if not(a[#a]=="colour"and l(g,c,j))then h[i[m]]=e end
end
return h
end

local function l(a,b)
for d,a in pairs(a)do
local b=b[d]
if a~=b and not(type(a)=="table"and type(b)=="table"and c.equal(a,b))then return false end
end
for b in pairs(b)do
if a[b]==nil then return false end
end
return true
end

local function x(b)
local a={}
for b=0,2^b-1 do a[#a+1]=b end
return a
end

local function y(a)
local b={{}}
for a,d in ipairs(a)do
local a={}
for b,e in ipairs(b)do
local b,c={},{}
for a,d in pairs(e)do b[a],c[a]=d,d end
b[d],c[d]=true,false
a[#a+1]=c
a[#a+1]=b
end
b=a
end
return b
end
local function p(b)
local a={}
for b,c in pairs(b)do
if c then a[#a+1]=b end
end
table.sort(a)
return table.concat(a,"+")
end










local m=function(a)return b.stackRange(a)end
local function r(o,b,r,s,d)
local e=b.source
local f={}
local a=type(e.facts)=="table"and e.facts or{}
for b,a in ipairs(type(a.stacks)=="table"and a.stacks or{})do
if a.enabled~=false and m(a)then f[#f+1]=a end
end
local a,g={},{}
for c,b in ipairs(f)do
local c,b=m(b)
for c,b in ipairs({c,b and b+1})do
if b and b>=2 and not g[b]then
g[b]=true
a[#a+1]=b
end
end
end
table.sort(a)
local b,g=c.Check.cells(e,b)
g=d~=nil and g==true
local c={}
for b=0,#a do
local n=a[b]or 1
local h={}
for b,a in ipairs(f)do
local b,c=m(a)
if(b<=1 or n>=b)and(c==nil or n<=c)then h[a.id]=true end
end
local a={lo=a[b],hi=a[b+1]and a[b+1]-1,items=h,early={},late={},base={}}
local f={}
for a in pairs(h)do f[a]=true end
if d then f[d.id]=true end
local q=false
for b,c in ipairs(r)do
local b=s[c]
for n,m in ipairs(b.gates)do
for r,n in ipairs(b.masks)do
local c=c.."|"..n.."|"..p(m)
local h=j(o,b.layer,i(e.id,"present",h,m),n,b.bitList)
a.early[c]=k(h,false)
if d then
local b=j(o,b.layer,i(e.id,"present",f,m),n,b.bitList)
a.late[c]=k(b,true)
a.base[c]=k(h,true)
if g and not l(a.base[c],a.late[c])then q=true end
end
end
end
end
a.cut=q
c[#c+1]=a
end
local b={}
for c,a in ipairs(c)do
local c=b[#b]
local d=c~=nil and c.cut==a.cut
if d then
for b,e in pairs(a.early)do
if not l(e,c.early[b])or(a.cut and not l(a.late[b],c.late[b]))then
d=false
end
end
end
if d then
c.hi=a.hi
else
b[#b+1]=a
end
end
local e=0
for b,a in ipairs(b)do e=e+(a.cut and 2 or 1)end
return{rows=b,all=c,driver=d~=nil and not g,cells=e,stacks=#f>0,
top=a[#a]or 1}
end




local function k(m,a,h,i,n)
local j,b,e,k={},{},0,{}
local f=0
local g={}
for h,l in ipairs(h)do
local h=a.layers[l]
local d=not i and not d.onButtonPresent(h,a.baseSize)
local a=t(m,h,a.run,i,n or c.Check.MAX_BITS,d)
f=f+a.over
local d={}
for a,c in ipairs(a.bits)do
local a=g[c.sig]
if not a then
b[#b+1]=c
a=#b
g[c.sig]=a
end
d[#d+1]=a
end

for c,b in pairs(a.looks)do
if b.bit then b.bit=g[a.bits[b.bit].sig]end
end
local b={}
for a,c in pairs(a.gates)do
if c=="change"then
b[#b+1]=a
k[a]=true
end
end
table.sort(b)
e=math.max(e,math.min(a.counts,c.Check.MAX_BITS))
j[l]={layer=u(h,a),looks=a,bitList=d,
masks=x(math.min(#d,c.Check.MAX_BITS)),gates=y(b),changing=b}
end
local a=0
for b in pairs(k)do a=a+1 end
return j,b,e,a,f
end


local function f(b)
local a={}
for c,d in ipairs(b.layers)do
if d.source==b.run then a[#a+1]=c end
end
return a
end

local function l(a)
if b.neverEnds(a)then return nil end
return q.firstItem(a,"expiring")
end



local function e(a)
local b=g.compile(a)
local e=a.source
local d=f(a)
local j=l(e)
local f,l,g,h,m=k(b,a,d,false)
local i=r(b,a,d,f,j)
local n=i.cells>1
if n then
f,l,g,h,m=k(b,a,d,true)
i=r(b,a,d,f,j)
end


local e=c.Check.MAX_BITS
while e>0 and i.cells*2^math.min(g,e)*2^h>c.Check.MAX_DISPLAYS do e=e-1 end
if e<g then f,l,g,h,m=k(b,a,d,n,e)end
return{ks=b,own=d,ex=j,plan=f,bits=l,counts=g,doubles=h,grid=i,
inCells=n,over=m}
end





b.MAX_CELLS=64
function b.displays(a)
local a=e(a)
return a.grid.cells*2^a.counts*2^a.doubles
end




local function x(c,b,d)
local a={}
for b,e in ipairs(b)do
a[b]=c[e].sig.."="..math.floor(d/2^(b-1))%2
end
table.sort(a)
return table.concat(a,";")
end








function b.plan(f)
local g=f.source
local a=g.unit or"player"
local a={kind=g.kind,variant=h.variantKey(g),unit=a,spells=g.spells,exact=g.exact,
slots={},
clips={present={},missing={}},parts={},moments={},copies={},copyOf={},presentOf={},
covers={},dimmers={}}

local h=c.Sources.get(g.kind).typeFilter
if h then h(a,g)end

if g.castBy=="anyone"then a.anyone=true end
a.cell=n(a,f)
local e=e(f)
a.over=e.over
local h,l,m=e.grid,e.ex,e.ks
a.bits={}
for c,b in ipairs(e.bits)do a.bits[c]={["while"]=b["while"],unless=b.unless}end
local function k(b)
b.n=#a.parts+1
a.parts[b.n]=b
return b
end

local function n(c,d,e)
local b={}
local f=q.restsOn(m,f.layers[c])
for a in pairs(f.lua)do b[#b+1]=a end
table.sort(b)
a.copies[#a.copies+1]={layer=c,atoms=b,assign=d,skip=e}
return#a.copies
end
local q=e.inCells
local t=h.stacks and#h.rows>1

local r={}
local function u(b,k,n,o,q)
local c=b.."|"..k.."|"..tostring(n).."|"..o.."|"..p(q)
if r[c]then return r[c]end
local d={}
for a in pairs(h.rows[k].items)do d[a]=true end
if n==2 then d[l.id]=true end
local e=e.plan[b]
local d=j(m,e.layer,i(g.id,"present",d,q),o,e.bitList)

if a.dimmers[b]then
local a={}
for b,c in pairs(d)do a[b]=c end
a.opacity=100
d=a
end
local e={}
for a,b in ipairs(f.layers)do e[a]=b end
e[b]=d
local b={}
for a,c in pairs(f)do b[a]=c end
b.layers=e
a.moments[#a.moments+1]=b
r[c]=#a.moments
return#a.moments
end

if not q then
for c,b in ipairs(e.own)do
for d,c in pairs(e.plan[b].looks.looks)do
if c.dim then a.dimmers[b]=a.dimmers[b]or n(b,i(g.id,"present"))end
end
end
end
c.Debug.experimental("the layer dimmer: a buff's or debuff's layer whose look changes only its Opacity on a key Lua"
.." reads, its parts on a container of their own under a holder of ours (FR-3, AU-36; the dim probe passed on"
.." Midnight, unrun on Forever)","I")
for i in ipairs(h.rows)do
local b=h.rows[i].cut and{1,2}or{false}
for b,g in ipairs(b)do
g=g or nil
for b,f in ipairs(e.own)do
local c=e.plan[f]
for b,j in ipairs(c.gates)do
for b,h in ipairs(c.masks)do
local m=u(f,i,g,h,j)

local l=l and not g and u(f,i,2,h,j)or nil
local b=d.parts(a.moments[m],"present",{only={[f]=true},dropHidden=true})
w(b,a.moments[m],a.types)
for d,b in ipairs(b)do
if b.holder~="present"or q then
b.moment,b.late=m,l
b.region=t and i or nil
b.half=g
if#c.bitList>0 then
b.bits,b.mask=c.bitList,h
b.gate=x(e.bits,c.bitList,h)
end
if#c.changing>0 then b.curve,b.curveOn=table.concat(c.changing,","),p(j)end
if a.dimmers[f]then b.dim=f end
if b.holder=="present"then b.inPane=true end
k(b)
end
end
end
end
end
end
end


if h.driver then
for n,b in ipairs(e.own)do
local e=e.plan[b]
local n={}
for a in pairs(h.rows[1].items)do n[a]=true end
n[l.id]=true
local l=j(m,e.layer,i(g.id,"present",n,{}),0,e.bitList)
local i=j(m,e.layer,i(g.id,"present",h.rows[1].items,{}),0,e.bitList)
local g={}
for a,b in ipairs(f.layers)do g[a]=b end
g[b]=l
local e={}
for a,b in pairs(f)do e[a]=b end
e.layers=g
a.moments[#a.moments+1]=e
local j=#a.moments
local h={}
local g={}
for a,b in pairs(f)do g[a]=b end
local a={}
for b,c in ipairs(f.layers)do a[b]=c end
a[b]=i
g.layers=a
for b,a in ipairs(d.parts(g,"present",{only={[b]=true},dropHidden=true}))do
h[(a.partKey or"")..":"..tostring(a.item)]=a
end
for b,a in ipairs(d.parts(e,"present",{only={[b]=true},dropHidden=true}))do
local b=h[(a.partKey or"")..":"..tostring(a.item)]
local c=b and a.partKey=="border"
and not c.equal(d.recordOf(e,a).colour,d.recordOf(g,b).colour)
if(not b or c)and a.holder=="button"then
a.holder,a.moment,a.underButton="expiring",j,true
k(a)
end
end
end
end

for c,b in ipairs(e.own)do
local h=n(b,i(g.id,"missing"))
a.copyOf[b]=h

local l=e.plan[b]
local c,e={},{}
for a,b in pairs(f)do c[a]=b end
for a,b in ipairs(f.layers)do e[a]=b end
e[b]=j(m,l.layer,i(g.id,"missing"),0,l.bitList)
c.layers=e
for b,a in ipairs(d.parts(c,"missing",{only={[b]=true}}))do
a.copy=h
k(a)
end

local c=n(b,i(g.id,"present"))
a.presentOf[b]=c
if not q then
for b,a in ipairs(d.parts(f,"present",{only={[b]=true}}))do
if a.holder=="present"then
a.copy=c
k(a)
end
end
end
end
c.Debug.experimental("a buff's look past C2 or C4 drawn as a cover inside cells: its tint, overlay or ring over every"
.." cell's copy of the layer (AU-6, FR-10: the cover proven outside cells only)","I")




do
for b,c in ipairs(e.own)do
local h=f.layers[c]
local b,j=false,false
local l={}
for c,a in pairs(e.plan[c].looks.looks)do
if a.cover then
b=true
l[c]=true
local a=s(h,a.flag)or{}

local a=a.border
local b=type(h.border)=="table"and h.border.ring
if type(a)=="table"and(a.ring or(b and(a.ringColour~=nil or a.ringSize~=nil)))then
j=true
end
end
end
local e=h.kind=="icon"or h.kind=="bar"
if b and e and h.shown~=false then
local e=n(c,i(g.id,"present"))
local g=n(c,i(g.id,"present"),l)
local b=d.parts(f,"present",{only={[c]=true}})[1]
local b=b and{rect=b.rect,level=b.level,pixel=b.pixel}
if b and h.kind=="icon"then
local b=k({layer=c,kind="icon",holder="cover",state="present",rect=b.rect,
level=b.level+d.RUNGS.look,pixel=b.pixel,cover=true,copy=e,base=g})
a.covers[#a.covers+1]=b
end
if b and j then
local b=k({layer=c,kind="border",partKey="border",holder="cover",state="present",
rect=b.rect,level=b.level+d.RUNGS.borderCopy,pixel=b.pixel,cover=true,
copy=e,base=g})
a.covers[#a.covers+1]=b
end
end
end
end


local c={}
for b,a in ipairs(a.parts)do
if a.holder=="button"and(a.region or 1)==1 and(a.half or 1)==1 and(a.mask or 0)==0 then
c[#c+1]=a
end
end
for b,a in ipairs(d.effectParts(f,false,c,{arrived=true}))do k(a)end

for c,b in ipairs(a.parts)do
local c=b.effect and"pop"or v[b.holder]
if c then
local a=o(a,b,c,(c=="button"or c=="pop")and b.rect or a.cell)
for d,c in ipairs(b.sockets or{})do a.sockets[c]=b.n end
a.parts[#a.parts+1]=b
elseif b.holder=="present"or b.holder=="missing"then
local a=a.clips[b.holder]
a[#a+1]=b
end
end

if t then
local c={}
local b
for d,a in ipairs(h.rows)do
c[d]={lo=a.lo,hi=a.hi}
if not b and not next(a.items)then b=d end
end
if#h.rows==1 then b=1 end
a.stacks={segments=c,top=h.top,first=b}
local b=o(a,{sockets={},level=1},"stacks",a.cell)
b.sockets.applicationBar="stacks"
b.stackTop=h.top
a.stacks.driver=b.n
end
local c=false
for b,a in ipairs(h.rows)do c=c or a.cut end
if c then a.halves={driver=o(a,{sockets={},level=1},"driver",a.cell).n}end
a.splits=a.stacks~=nil or c or nil



local c
if h.stacks then
c=function(a)
local b=e.plan[a.layer]
if not b then return nil end
local d={}
for h,e in ipairs(h.all)do
local c={}
for a,b in ipairs(f.layers)do c[a]=b end
c[a.layer]=j(m,b.layer,i(g.id,"present",e.items,{}),a.mask or 0,
b.bitList)
local a={}
for b,c in pairs(f)do a[b]=c end
a.layers=c
d[h]={lo=e.lo,view=a}
end
return d
end
end
b.coloursOf(a,l,c)
if l then a.expire={share=l.share/100}end
return a
end





function b.coloursOf(b,e,f)

local c={}
for d,a in ipairs(b.parts)do
if a.moment and a.layer then
local d=a.layer.."|"..tostring(a.mask).."|"..tostring(a.curveOn)
c[d]=c[d]or{}
c[d][(a.region or 1)..":"..tostring(a.half)]=b.moments[a.moment]
end
end
for g,a in ipairs(b.parts)do
local d=a.moment and not a.effect and d.specOf(a)
if d and d.handedColours then
local c=c[a.layer.."|"..tostring(a.mask).."|"..tostring(a.curveOn)]or{}
local g=a.region or 1
local c=a.late and b.moments[a.late]or c[g..":2"]
local f=f and f(a)
local b=b.moments[a.moment]
a.colours=d.handedColours(b,a,{share=e and e.share or nil,late=c,
stretches=f})
end
end
end




function b.costOf(a)
local f=b.plan(a)
local d,c={},1
for e,a in ipairs(f.slots)do
local a=b.containerOf(a)
if not d[a]then
d[a]=true
c=c+1
end
end
local d=0
local g=type(a.source.facts)=="table"and a.source.facts or{}
for b,a in ipairs(type(g.stacks)=="table"and g.stacks or{})do
if a.enabled~=false then d=d+1 end
end
local e=e(a)
return{displays=b.displays(a),maxDisplays=b.MAX_CELLS,ranges=d,maxRanges=b.MAX_RANGES,
bits=e.counts,buttons=#f.slots,containers=c}
end
