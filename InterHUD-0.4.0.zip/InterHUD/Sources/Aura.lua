





local b,a=...

local c,f,h,i,s,g,o=a.Schema,a.Events,a.Layers,a.Quiet,a.Target,a.Combat,a.Units
local e=a.Sources.get("aura")

local k=2
local p=0.1
local w=1.6
local v="Interface\\Buttons\\WHITE8x8"
local d="DisableUntrustedLayoutScriptsTemplate"
local n="MEDIUM"


local b={"EnableMouse","SetMouseClickEnabled","SetMouseMotionEnabled"}
local function t(a)
for c,b in ipairs(b)do pcall(function()a[b](a,false)end)end
end

local b={}
b.__index=b
local j={}

a.Debug.experimental("a Spell Alert's display with no quiet window after a load, shown the moment its buff reads up"
.." (its pulse, a shown animation, may start again at a full refresh)","I")

function b:quiet()
local a=self.element.element
return i.isQuiet(a.id)and not c.alertFlag(a.view,"noQuiet")
end



function b:updateHold()
if self.f.owner~=self then return end
local a=self.trusted and self.pointed and not self:quiet()
self.f.hold:SetAlpha(a and 1 or 0)
for b in pairs(self.f.follows or{})do b:SetAlpha(a and 1 or 0)end
end

function b:follow(a)
self.f.follows=self.f.follows or{}
self.f.follows[a]=true
local b=self.trusted and self.pointed and not self:quiet()
a:SetAlpha(b and 1 or 0)
end




function b:updatePops()
if self.f.owner~=self then return end
local a=i.isQuiet(self.popKey)or a.Showing.cantAct()~=nil
self.f.popHolder:SetAlpha(a and 0 or 1)
end


local function c(a)
a.waiting=a.waiting-1
if a.waiting>0 then
f.atFrameEnd(a.frameKey,c,a)
return
end
a.trusted=true
a:updateHold()
end
function b:wait()
self.trusted,self.waiting=false,2
self:updateHold()
f.atFrameEnd(self.frameKey,c,self)
end




function b:edge(b,c,d)
local a=a.try(self.element.id.." "..b,c)
if d~=false then i.open(self.element.element.id)end
self:wait()
return a
end

local function c(a,b)
return CreateFrame("Frame",nil,a,b)
end



local function q(a)
if a.types then return{}end
return e.auraIds(a.spells,a.unit,not a.anyone and"yours"or nil,a.exact)
end









local function x(a,b,g,h,k,i)
local j={region=g,half=h,anchor=a.cell}
local f,b=nil,b
if g then
local e=c(b,d)
e:SetClipsChildren(true)
if i then e:SetFrameLevel(i)end
if not a.stacksHung and k.stacks and g==k.stacks.first then
e:SetAllPoints(a.cell)
else
e:Hide()
end
b=c(e,d)
b:SetAllPoints(a.cell)
a.stretchPanes=a.stretchPanes or{}
a.stretchPanes[#a.stretchPanes+1]={clip=e,region=g,pane=j}
f=e
end
if h then
local e=c(b,d)
e:SetClipsChildren(true)
if i and not f then e:SetFrameLevel(i)end
if not a.halvesHung and h==1 then
e:SetAllPoints(a.cell)
else
e:Hide()
end
b=c(e,d)
b:SetAllPoints(a.cell)
a.halfPanes=a.halfPanes or{}
a.halfPanes[#a.halfPanes+1]={clip=e,half=h,pane=j}
f=f or e
end
return f,b,j
end


local function y(a)
for b,a in ipairs({a.stretchPanes or{},a.halfPanes or{}})do
for b,a in ipairs(a)do
if a.pane.hung then return true end
end
end
return false
end





local function z(a,f,e)
a.covers=a.covers or{}
local b=a.covers[f]
if not b then
local e=c(a.hold,d)
e:SetClipsChildren(true)
e:SetPoint("TOPLEFT",a.sensor,"TOPLEFT",0,0)
e:SetPoint("BOTTOMRIGHT",a.sensor,"BOTTOMRIGHT",-k,0)
local c=c(e,d)
c:SetAllPoints(a.cell)
b={clip=e,area=c}
a.covers[f]=b
end
b.clip:SetFrameLevel(e)
b.clip:Show()
return b.area,b
end





local function A(b,f)
local a={slots={},made=0,containers={}}
a.hold=c(b.root)
a.hold:SetAllPoints()
a.cell=c(a.hold)
local b=CreateFrame("AuraContainer",nil,a.hold,"CustomAuraContainerTemplate")
b:SetPoint("TOPLEFT",a.cell,"TOPLEFT",0,0)
b:SetFrameStrata(n)
b:SetUnit(f.unit)
pcall(b.EnableMouse,b,false)
pcall(b.SetFlowLayoutPadding,b,0,0,0,0)
local e,g=e.filterOf(f.unit,f.typed,f.anyone),e.candidatesOf(f,q(f))
b:AddAuraGroup("sensor",e,{
candidateFilters=g,maxFrameCount=1,
layout={elementWidth=f.cell.w+k,elementHeight=f.cell.h},
initializeFrame=function(a)
a:SetSize(1,1)
t(a)
end,
})
a.sensor,a.unit,a.cell0=b,f.unit,f.cell
a.filter,a.filters=e,g
a.pointedAt=f.unit


local e=c(a.hold,d)
e:SetClipsChildren(true)
e:SetPoint("TOPLEFT",b,"TOPLEFT",0,0)
e:SetPoint("BOTTOMRIGHT",b,"BOTTOMRIGHT",-k,0)
a.presentArea=c(e,d)
a.presentArea:SetAllPoints(a.cell)


local f=c(a.hold,d)
f:SetClipsChildren(true)
f:SetPoint("TOPLEFT",b,"TOPRIGHT",0,0)
f:SetPoint("BOTTOMRIGHT",a.cell,"BOTTOMRIGHT",0,0)
a.unitGate=c(f,d)
a.unitGate:SetAllPoints(a.cell)
a.missingArea=c(a.unitGate,d)
a.missingArea:SetAllPoints(a.cell)
a.presentClip,a.missingClip=e,f


a.presentHolder=c(a.hold)
a.presentHolder:SetAllPoints()


a.popHolder=c(a.presentHolder)
a.popHolder:SetAllPoints()

a.chain={}
return a
end

local function r(b,c,a)
b.cell:SetPoint("TOPLEFT",c,"TOPLEFT",a.x,-a.y)
b.cell:SetSize(a.w,a.h)
end







a.Debug.experimental("a buff's copy under two gate keys at once: AND by nested curve gates, each frame's alpha its own"
.." curve's (A6 for one gate; nested unplayed)","I")
a.Debug.experimental("a buff's gated copy keyed on another source's state (a spell's Cooling down) rather than a fact:"
.." AU-39's frames, only the bit's reader differs (unplayed)","I")
local function m(b,f,g,a)
local j,i=g,tostring(g)
local function k(a,e)
i=i.."|"..a
local a=b.chain[i]
if not a then
local c=c(j,g==b.presentHolder and nil or d)
if g==b.presentHolder then c:SetAllPoints()else c:SetAllPoints(b.cell)end
a={frame=c}
b.chain[i]=a
if e then e(a)end
end
j=a.frame
return a
end
if a.dim then
k("dim:"..a.dim,function(b)b.dim=a.dim end)
end
if a.curve then
local c={}
for a in(a.curveOn or""):gmatch("[^+]+")do c[a]=true end
for a in a.curve:gmatch("[^,]+")do
local d=k("curve:"..a.."="..tostring(c[a]==true),function(b)
b.frame:SetAlpha(c[a]and 0 or 1)
end)
f.gates=f.gates or{}
local b=f.gates[a]
if not b then
b={on={},off={}}
f.gates[a]=b
end
local a=c[a]and b.on or b.off
if not h.inList(a,d.frame)then a[#a+1]=d.frame end
end
end
if a.gate then


local c=k("gate:"..a.gate)
local d=c.bits==nil
c.bits,c.mask,c.used=a.bits,a.mask,b.pass
if d then c.frame:SetAlpha(e.lookLit(c,b.owner and b.owner.mask)and 1 or 0)end
end
return j
end



function e.lookLit(b,c)
local a=0
for b,d in ipairs(b.bits or{})do
if c and math.floor(c/2^(d-1))%2==1 then a=a+2^(b-1)end
end
return a==(b.mask or 0)
end


local c={button="display",driver="display",stacks="display",pop="pops"}


local function l(b)
local a=c[b.kind]
if a=="pops"then return a end
if b.dim then a=a..":d"..b.dim end
if b.curve then a=a..":c"..b.curve.."="..tostring(b.curveOn)end
if b.gate then a=a..":g"..b.gate end
return a
end
e.containerOf=l
local function B(c,d,g,e,b)
if c[e]then

if b and(b.curve or b.gate)then m(c,d,c.presentHolder,b)end
return c[e]
end
local f=c.popHolder
if e~="pops"then f=m(c,d,c.presentHolder,b or{})end
local b=CreateFrame("AuraContainer",nil,f,"CustomAuraContainerTemplate")
b:SetPoint("TOPLEFT",d.root,"TOPLEFT",0,0)
b:SetSize(1,1)
b:SetFrameStrata(n)
b:SetFrameLevel(h.levelOf(d.view,0))
b:SetUnit(g)
pcall(b.EnableMouse,b,false)


if b.SetEditModePreviewEnabled then a.try("edit mode preview",b.SetEditModePreviewEnabled,b,false)end
c[e]=b
c.containers[#c.containers+1]=b
return b
end


local function u(b)
local a={b.sensor}
for c,b in ipairs(b.containers)do a[#a+1]=b end
return a
end



local function C(a)
local b={l(a),a.kind,tostring(a.stackTop),tostring(a.region),tostring(a.half)}
for c,a in ipairs(a.parts)do
b[#b+1]=a.kind..":"..tostring(a.shape)..":"..a.level..":"..table.concat(a.sockets or{},",")
end
return table.concat(b,"|")
end




local function c(b,d,c)
if not e.widens(b,c)then
local d,c=a.Spells.family(b)
if not c then
local b=a.Spells.auraFamilies(b)
c=b and a.SpellTable.families[b[1]]
end
if not c then return nil end
return b,c,{b}
end
local f,c=a.Spells.family(b)
if not c then return nil end
local d=e.watchedAuras(c,d)
local a=a.Spells.highest(b)
for b,e in ipairs(c.ranks or{})do
if e==a then return d[b],c,d end
end
return nil,c,d
end



local function n(a,b,d)
local b,a,c=c(a,b,d)
if not(a and a.durations)then return nil end
if b and a.durations[b]then return a.durations[b]end
local b
for d,c in ipairs(c)do
local a=a.durations[c]
if a and a>0 and(not b or a>b)then b=a end
end
return b
end





function e.endless(b)
if type(b)~="table"or b.spells==nil or b.kind~="aura"then return false end
local d,e=false,a.Sources.exactSet(b.exact)
for g,f in ipairs(a.Spells.listOf(b.spells))do
local c,b,e=c(f,b.unit,e)
if not(b and b.endless)then return false end
local c=c and{c}or e or{}
if#c==0 then return false end
for d,c in ipairs(c)do
if not a.Layers.inList(b.endless,c)then return false end
end
d=true
end
return d
end




function e.sampleLength(b)
if b.source.kind~="aura"then return nil end
local c,d=nil,a.Sources.exactSet(b.source.exact)
for e,a in ipairs(a.Spells.listOf(b.source.spells))do
local a=n(a,b.source.unit,d)
if a and(not c or a>c)then c=a end
end
return c
end






local c=307200
e.TIME_DRIVER=c
a.Debug.experimental("new calls inside a button's init until ihud-step4 passes: the gate's interpolation option,"
.." a looping glow as a shown animation, Expiring's clip anchored there","I")
local function n(a,d,b)
local b=b and b.share
if not(a.driver and b and b>0)then
if a.clip then a.clip:SetAlpha(0)end
a.placed=false
return
end
a.driver:ClearAllPoints()
a.driver:SetPoint("TOPLEFT",a.button,"TOPLEFT",-c*b,0)
a.driver:SetSize(c,d.h)
a.clip:SetAlpha(1)
a.placed=true
end



local function D(e,b,f,c)
local a=CreateFrame("StatusBar",nil,c)
a:SetStatusBarTexture(v)
a:SetStatusBarColor(0,0,0,0)
if f.kind=="stacks"then


local d,e=e.rig.cell.w,e.rig.cell.h
a:SetPoint("TOPLEFT",c,"TOPLEFT",0,0)
a:SetSize(d*f.stackTop,e)
b.stackFill=a:GetStatusBarTexture()
c:SetApplicationBar(a,{minApplications=0,maxApplications=f.stackTop,
interpolation=Enum.StatusBarInterpolation.Immediate})


b.stackDriver=a
return a
end


local f=a:GetStatusBarTexture()
c:SetDurationBar(a,{interpolation=Enum.StatusBarInterpolation.Immediate,
direction=Enum.StatusBarTimerDirection.RemainingTime})
b.driver,b.fill=a,f
local a=CreateFrame("Frame",nil,c,d)
a:SetClipsChildren(true)
a:SetPoint("TOPLEFT",f,"TOPRIGHT",0,0)
a:SetPoint("BOTTOMRIGHT",c,"BOTTOMRIGHT",0,0)
b.clip=a
n(b,e.rig.cell,e.rig.expire)
return a
end





local function v(b,f,c,h,a,g)
local a=CreateFrame("Frame",nil,a,d)
a:SetClipsChildren(true)
a:SetFrameLevel(c.level)
local e
if g then
e=not b.f.halvesHung and g==1
f.halfClip=a
else
e=not b.f.stacksHung and c.region==b.rig.stacks.first
f.regionClip=a
end
if e then
a:SetAllPoints(b.f.cell)
else
a:Hide()
end
local a=CreateFrame("Frame",nil,a,d)
a:SetAllPoints(h)
a:SetFrameLevel(c.level)
return a
end




local function E(d,e,b,c)
e.button=c
h.place(c,e.c,b.rect)
c:SetFrameLevel(b.level)
t(c)
local g=d.element.id.." button"
local f=c
if b.region then
local a,b=a.try(g.." stack copy",v,d,e,b,c,f)
if not a then return end
f=b
end
if b.half then
local a,b=a.try(g.." time half",v,d,e,b,c,f,b.half)
if not a then return end
f=b
end
if b.kind=="driver"or b.kind=="stacks"then
local a,b=a.try(g.." "..b.kind,D,d,e,b,c)
if not a then return end
f=b
end
for h,b in ipairs(b.parts)do
local f,d=a.try(g.." "..b.kind,d.element.makeVisual,d.element,f,b)
if f then
e.visuals[h]=d
if b.sockets and#b.sockets>0 then
a.try(g.." handOver "..b.kind,d.spec.handOver,d.visual,c,b)
end
end
end
end





local function t(b,c)
local c=b.part.ownPicture and{icon=c.icon}
or not(b.part.sockets and#b.part.sockets>0)and c

if not(b.underButton or b.inPane)or b.gone or b.part.effect or b.part.cover or not c then return end
g.whenButtonsWritable(b.site.." feed "..b.part.n,function()
if not b.gone then a.try(b.site,b.spec.feed,b.visual,c)end
end)
end



local function D(e,c,f)
local b,d=e.f,e.element
local i=C(c)
for e,a in ipairs(b.slots)do
if not f[a]and a.sig==i then
f[a]=true
a.slot=c

if l(c)~="pops"then m(b,d,b.presentHolder,c)end
for b,a in pairs(a.visuals)do
a.part=c.parts[b]
d:keepVisual(a)

if d.still then t(a,d.still)end
end

g.whenButtonsWritable(d.id.." slot "..a.key,function()
if a.button and b.taken[a]then
h.place(a.button,a.c,a.slot.rect)
if a.driver then n(a,b.owner.rig.cell,b.owner.rig.expire)end
end
end)
if not a.enabled then
a.enabled=true
a.c:SetAuraSlotEnabled(a.key,true)
return l(c)
end
return nil
end
end
b.made=b.made+1

local g=B(b,d,b.pointedAt or e.rig.unit,l(c),c)
local e={key="slot"..b.made,sig=i,slot=c,visuals={},enabled=true,c=g}
b.slots[#b.slots+1]=e
f[e]=true



local a,d=pcall(g.AddAuraSlot,g,e.key,b.filter,{
candidateFilters=b.filters,

initializeFrame=function(c)
a.try(d.id.." button",E,b.owner,e,e.slot,c)
end,
})
if not a then
table.remove(b.slots)
f[e]=nil
error(d,0)
end
return l(c)
end



local function v(c)
local b=e.shownSpell(c)
if b==nil then
local b=a.Sources.get(c.kind)
return{icon=b.icon and b.icon(c)or a.Sources.UNSET_ICON,name=false,duration=false}
end

local c=select(2,a.Spells.highest(b))
return{icon=c or a.Spells.icon(b),name=a.Spells.label(b),duration=false}
end






function e.build(d,c,l,i)
local f=setmetatable({element=d,view=l,rig=c,trusted=false,pointed=true,
frameKey="aura "..d.id,popKey=d.id.." pops",list=a.Spells.listOf(l.source.spells)},b)
if i then i:stop()end
local b=i and i.f
local i=not b
local n={}
if not b then b=A(d,c)end
f.f,b.owner=b,f
if not b.hold:IsShown()then
b.hold:Show()
i=true
end
f.ids=q(c)
f:updateHold()
f:updatePops()
r(b,d.root,c.cell)

local e,j=e.filterOf(c.unit,c.typed,c.anyone),e.candidatesOf(c,f.ids)
local o=d.id.." sensor"
local p=b.unit~=c.unit
if p or b.filter~=e then
i=true
a.try(o,function()
b.sensor:SetAuraGroupFilterString("sensor",e)
for b,a in ipairs(b.slots)do a.c:SetAuraSlotFilterString(a.key,e)end

if p and c.unit=="player"then
for b,a in ipairs(u(b))do a:SetUnit("player")end
end
end)
b.filter=e
if p then b.unit,b.pointedAt=c.unit,c.unit=="player"and"player"or nil end
end
if not a.equal(b.filters,j)then
i=true
a.try(o,function()
b.sensor:SetAuraGroupCandidateFilters("sensor",j)
for b,a in ipairs(b.slots)do a.c:SetAuraSlotCandidateFilters(a.key,j)end
end)
end
b.filters=j
if not a.equal(b.cell0,c.cell)then
a.try(o,b.sensor.SetAuraGroupLayout,b.sensor,"sensor",
{elementWidth=c.cell.w+k,elementHeight=c.cell.h})
b.cell0,f.relaid=c.cell,true
end


local k=v(l.source)
d.still=k
d.gates=nil




local l=g.buttonsWritable()




local h,e=h.clipLevel(c.clips.missing),h.clipLevel(c.clips.present)
if h then b.missingClip:SetFrameLevel(h)end
local j=e and not l and y(b)
if e and not j then b.presentClip:SetFrameLevel(e)end
b.pass=(b.pass or 0)+1
b.paneGates=b.paneGates or{}
for b,a in pairs(b.paneGates)do a.used,a.stale=nil,nil end
local function o(a)
local f=tostring(a.region)..":"..tostring(a.half)..":"..tostring(a.gate)..":"
..tostring(a.curve).."="..tostring(a.curveOn)
local e=b.paneGates[f]
if not e then
local d=m(b,d,b.presentArea,a)
local d,a,c=x(b,d,a.region,a.half,c)
e={body=a,pane=c}
b.paneGates[f]=e
else
m(b,d,b.presentArea,a)
end
e.used=true
return e
end
local h={}
local function m(b,c,a,e)
if l or not(a and a.hung)then
d:makeVisual(b,c,a)
else
e.stale=true
h[#h+1]={b,c,a}
end
end
for c,a in ipairs(c.clips.present)do
if a.inPane then
local b=o(a)
m(b.body,a,b.pane,b)
else
d:makeVisual(b.presentArea,a)
end
end
for c,a in ipairs(c.clips.missing)do d:makeVisual(b.missingArea,a)end
for c,a in ipairs(c.covers)do
local b=z(b,c,a.level)
d:makeVisual(b,a)
end
for a=#c.covers+1,#(b.covers or{})do b.covers[a].clip:Hide()end
d:feed(k)
if#h>0 or d.hungLater or j then
g.whenButtonsWritable(d.id.." panes",function()
if b.owner~=f then return end
if j then


b.presentClip:SetFrameLevel(e)
for c,b in ipairs(d.visuals)do
if b.part.holder=="present"and not b.gone then
b.visual.frame:SetFrameLevel(b.part.level)
a.try(b.site,b.spec.apply,b.visual,(d:recordOf(b.part)),b.part,b.part.rect)
d:fadeTo(b)
end
end
end
d:keepHung()
for b,a in ipairs(h)do d:makeVisual(a[1],a[2],a[3])end
for b,a in pairs(b.paneGates)do a.stale=nil end
f:paint()
end)
end


local e={}
b.taken=e
for c,b in ipairs(c.slots)do
local b,a=a.try(d.id.." slot",D,f,b,e)

i=i or not b
if a then n[a]=true end
end
for f,c in ipairs(b.slots)do
if not e[c]and c.enabled then
c.enabled=false
a.try(d.id.." slot off",c.c.SetAuraSlotEnabled,c.c,c.key,false)
n[c.c==b.pops and"pops"or"display"]=true
end
end
f.changed,f.slotsChanged=i,n
if c.splits then f:split()end
f:relight()
return f
end






local function l(a,b,c,d,e)
a:ClearAllPoints()
if b.hi then
a:SetPoint("TOPLEFT",d,"TOPRIGHT",-b.hi*e,0)
else
a:SetPoint("TOPLEFT",c.cell,"TOPLEFT",0,0)
end
if b.lo then
a:SetPoint("BOTTOMRIGHT",d,"BOTTOMRIGHT",-(b.lo-1)*e,0)
else
a:SetPoint("BOTTOMRIGHT",c.cell,"BOTTOMRIGHT",0,0)
end
a:Show()
end
local function m(a,b,d)
local c=b.stacks
local b
for d,c in ipairs(a.slots)do
if a.taken[c]and c.stackDriver and c.slot.kind=="stacks"then b=c end
end
if not b then return end
local d,e=d.w,d.h
b.stackDriver:ClearAllPoints()
b.stackDriver:SetPoint("TOPLEFT",b.button,"TOPLEFT",0,0)
b.stackDriver:SetSize(d*c.top,e)
local e=b.stackFill
for f,b in ipairs(a.slots)do
if a.taken[b]and b.regionClip then l(b.regionClip,c.segments[b.slot.region],a,e,d)end
end


for f,b in ipairs(a.stretchPanes or{})do
local c=c.segments[b.region]
if c then
l(b.clip,c,a,e,d)
b.pane.hung=true
else
b.clip:Hide()
end
end
a.stacksHung=true
end






local function d(a,b,c,d)
a:ClearAllPoints()
if not d then
if b==1 then a:SetAllPoints(c.cell)end
a:SetShown(b==1)
return
end
if b==1 then
a:SetPoint("TOPLEFT",c.cell,"TOPLEFT",0,0)
a:SetPoint("BOTTOMRIGHT",d.fill,"BOTTOMRIGHT",0,0)
else
a:SetPoint("TOPLEFT",d.fill,"TOPRIGHT",0,0)
a:SetPoint("BOTTOMRIGHT",c.cell,"BOTTOMRIGHT",0,0)
end
a:Show()
end
local function l(a,b,c)
for e,b in ipairs(a.slots)do
if a.taken[b]and b.halfClip then d(b.halfClip,b.slot.half,a,c)end
end
for e,b in ipairs(a.halfPanes or{})do
d(b.clip,b.half,a,c)
if c then b.pane.hung=true end
end
a.halvesHung=true
end


function b:split()
local c=self.f
g.whenButtonsWritable(self.element.id.." split",function()
local a=c.owner
if not(a and c.taken)then return end
local a=a.rig
if a.stacks then m(c,a,a.cell)end
local d
for e,b in ipairs(c.slots)do
if c.taken[b]and b.driver and b.button then
n(b,a.cell,a.expire)
if a.halves and b.slot.n==a.halves.driver and b.placed then d=b end
end
end
if a.halves then l(c,a,d)end
end)
end




a.Debug.experimental("an aura element's cell re-laid out in place after an edit (SetAuraGroupLayout: D)","D")
function b:update(e,c)
local d=self.f
self.rig=c
self:sounds()
self:updatePops()

if not a.equal(e.cell,c.cell)or not a.equal(d.cell0,c.cell)then
r(d,self.element.root,c.cell)
a.try(self.element.id.." layout",d.sensor.SetAuraGroupLayout,d.sensor,"sensor",
{elementWidth=c.cell.w+k,elementHeight=c.cell.h})
d.cell0=c.cell
self:wait()
end
for f,b in ipairs(d.slots)do
if d.taken[b]then
local f=b.slot
b.slot=c.slots[f.n]
local f=not a.equal(f.rect,b.slot.rect)
local a=b.slot.kind=="driver"and(f or not a.equal(e.expire,c.expire)
or not a.equal(e.cell,c.cell))

if f or a then
g.whenButtonsWritable(self.element.id.." slot "..b.key,function()
if not(b.button and d.taken[b])then return end
h.place(b.button,b.c,b.slot.rect)
if b.driver then n(b,self.rig.cell,self.rig.expire)end
end)
end
end
end

if c.splits then self:split()end
end








local function l(b,c,d,e,f)
a.try(b.element.id.." layout",c.sensor.SetAuraGroupLayout,c.sensor,"sensor",
{elementWidth=d+k,elementHeight=e})
if not f then b:wait()end
end






a.Debug.experimental("an aura's sensor laid out far larger than its cell for a layer's drag (the cell plus twice the"
.." screen; AU-38 proves long plain bars, not a container)","I")






function b:reflowBegin(f)
local a,b=self.f,self.rig.cell
if a.owner~=self then return end
self.stays={}
for c,b in ipairs(a.slots)do
local c=b.slot
if a.taken[b]and(c.kind=="button"or c.kind=="pop")then
local a,e,d
for c,b in ipairs(c.parts)do
local b=b.effect and b.onLayer or b.layer
local b=b and self.view.layers[b]
if b then
local b=b.source.."/"..tostring(b.id)
if a==nil then a=b elseif b~=a then e=true end
d=d or f[b]
end
end
if e and d then self.stays[b]=true end
end
end
local c,d=UIParent:GetSize()
local c=2*math.max(c,d)/(self.view.rootScale or 1)
local c,d=b.w+c,b.h+c
l(self,a,c,d,true)
a.cell0={x=b.x,y=b.y,w=c,h=d}
end

local function k(b,c,e)
local a=c.parts[1]
local d=a and(a.effect and a.onLayer or a.layer)
local a=a and a.moment and b.rig.moments[a.moment]or b.view
local b=d and a.layers[d]
if not b then return c.rect end
return h.drawnRectInto(b,a.baseSize,a.allLayers or a.layers,e)
end
function b:reflow(f,e)
local b,c=self.f,self.rig
if b.owner~=self then return end
local d=a.Check.cellInto(self.view,c.cellRun,b.flow or{})
b.flow=d
r(b,self.element.root,d)
if e and not a.equal(b.cell0,c.cell)then
l(self,b,c.cell.w,c.cell.h)
b.cell0=c.cell
end
if not f then return end
local f=not e and self.stays or nil
if e then self.stays=nil end
for e,a in ipairs(b.slots)do
if b.taken[a]and a.button and not(f and f[a])then
local b=a.slot.kind
local e=d
if b=="button"or b=="pop"then
a.flow=a.flow or{}
e=k(self,a.slot,a.flow)
end
h.place(a.button,a.c,e)
if a.driver then n(a,d,c.expire)end
end
end
if c.stacks and b.stacksHung then m(b,c,d)end
end





function b:relight()
local b=self.f
if b.owner~=self then return end
local a=self.element.element and self.element.element.keys
local c=0
for d,b in ipairs(self.rig.bits or{})do
if a and a:lookPart(b["while"],b.unless,"drawn")then c=c+2^(d-1)end
end
self.mask=c
for d,a in pairs(b.chain)do
if a.bits then a.frame:SetAlpha((a.used==b.pass and e.lookLit(a,c))and 1 or 0)end
if a.dim then
local b=self.rig.dimmers and self.rig.dimmers[a.dim]
local b=b and self.element.live and self.element.live[b]
local b=b and b.view and b.view.layers[a.dim]
a.frame:SetAlpha(b and((b.opacity or 100)/100)or 1)
end
end


local c=0
for b,a in pairs(b.paneGates or{})do
local b=(a.used and not a.stale)and 1 or 0
if a.lit~=b then
if not(a.pane and a.pane.hung)or g.buttonsWritable()then
a.body:SetAlpha(b)
a.lit=b
else
c=c+1
end
end
end
self.paneWaits=c
if c>0 then

if not self.relightLater then
self.relightKey=self.element.element.id.." pane bodies"
self.relightLater=function()
if self.f.owner==self then self:relight()end
end
end
g.whenButtonsWritable(self.relightKey,self.relightLater)
end
end





function b:paint()
local a=self.f
local b=self.rig.unit=="player"or a.pointedAt==self.rig.unit
local c=(b or not self.rig.types)and 1 or 0
a.presentHolder:SetAlpha(c)
a.presentArea:SetAlpha(c)
a.unitGate:SetAlpha(b and 1 or 0)
self:relight()
end



function b:refeed()
local a=v(self.view.source)
self.element.still=a
self.element:feed(a)
for c,b in ipairs(self.element.visuals)do t(b,a)end
end




local k={
target=function()return s.hostile()end,
focus=function()return o.hostile("focus")end,
pet=function()return o.alive("pet")end,
}
local r={}


local function t()
local c,b=a.try("unit read",UnitGUID,"pet")
if not c or a.isSecret(b)then return nil end
return b or false
end
local v




function b:repoint()
local a=self.f
local b=k[self.rig.unit]()
r[self.rig.unit]=b
if self.rig.unit=="pet"then v=t()end
local b=b and self.rig.unit or"none"
local c=self:edge("repoint",function()
for d,c in ipairs(u(a))do
if a.pointedAt~=b then c:SetUnit(b)end
if(a.pointedAt==b or a.pointedAt==nil)and b~="none"then c:UpdateAllAuras()end
end
end,false)
a.pointedAt=c and b or nil
self.pointed=c
if not c then
g.whenUnlocked(self.element.id.." repoint",function()
if j[self]then self:repoint()end
end)
end
self:paint()
self:updateHold()
end








local x={focus={"UNIT_FACTION","UNIT_FLAGS","UNIT_HEALTH"},pet={"UNIT_FLAGS","UNIT_HEALTH"}}
local u={focus=true}
local c={focus="aura watch focus",pet="aura watch pet"}
local d={}
local l={}
local function m(b)
for a in pairs(j)do
if a.rig.unit==b then a:repoint()end
end
end
local function n(a)
if k[a]()~=r[a]then m(a)end
end


local function r(a)
local b=t()
if b==nil or b~=v then m(a)else n(a)end
end
local r={focus=m,pet=r}
local function t()
for a in pairs(u)do
if d[a]then f.atFrameEnd(c[a],n,a)end
end
end

local function m(a,b)
if not c[a]then return end
if b then o.onChange(a,"aura source",r[a])end
local e=d[a]or 0
local b=e+(b and 1 or-1)
d[a]=b>0 and b or nil
if(e>0)==(b>0)then return end
local c=c[a]
if not l[a]then l[a]=function()f.atFrameEnd(c,n,a)end end
for e,d in ipairs(x[a])do
if b>0 then f.onUnit(d,a,c,l[a])else f.offUnit(d,c)end
end
local a=false
for b in pairs(u)do a=a or d[b]~=nil end
if a then f.on("UNIT_DIED","aura watch",t)else f.off("UNIT_DIED","aura watch")end
end
a.Debug.experimental("your debuff on your focus target: containers on \"focus\" with your debuffs' IDs"
.." (HARMFUL|PLAYER), re-pointed at PLAYER_FOCUS_CHANGED and pointed at none while it isn't hostile and alive,"
.." at rest and in a fight (AU-12 and AU-15 on the target; UN-22; a container on focus unplayed: EP-44)","I")
a.Debug.experimental("a buff on your pet: containers on \"pet\" with its IDs (HELPFUL, PLAYER under Cast by You),"
.." re-pointed at UNIT_PET and PET_UI_UPDATE where UnitGUID(\"pet\") reads another pet (taken as plain on your own"
.." pet, unread; a secret one re-points), and pointed at none while no pet is out or it is dead, at rest and in a"
.." fight (AU-13: helpful auras by ID on a player-controlled unit, Blizzard's rule; AU-15; UN-21; EllesmereUI's pet"
.." containers on Forever; a container on pet unplayed: EP-26)","I")

local d=true






local function l(b,d)
for c,a in ipairs(b.effects)do
local c=a.at or{}
if c.event==d and c.fact==nil and a.kind=="sound"and a.sound~=nil
and h.ownsEffect(b,a)then
return a.sound
end
end
end
function b:sounds()
local c=self.rig.unit=="player"and not self.rig.types
local b={}
for a in pairs(self.ids)do b[#b+1]=a end
a.Sounds.setAuraSound(self.element.id.." removed",c and l(self.view,"removed")or nil,b,"Removed")
local c=c and not d and l(self.view,"arrived")or nil
a.Sounds.setAuraSound(self.element.id.." arrived",c,b,"Added")
end

function b:start()
j[self]=true
self.started=true
local b=a.Spells.listOf(self.view.source.spells)
if#b>1 and self.view.source.shownSpell=="lastSeen"then
a.LastSeen.watch(self.element.id,b,self.rig.unit,self.view.source.exact)
end
local a=self.f
if c[self.rig.unit]and not self.watching then
self.watching=true
m(self.rig.unit,true)
end
if k[self.rig.unit]and(self.changed or a.pointedAt==nil)then
if self.changed then i.open(self.element.element.id)end
self:repoint()
elseif self.changed then
i.open(self.element.element.id)
self:wait()
elseif self.relaid then
self:wait()
else
self.trusted=true
self:updateHold()
end

if not self.changed and self.slotsChanged.pops then
i.open(self.popKey,math.max(self:popLength(),w)+p)
end
self:sounds()
end

function b:stop()
j[self]=nil
if self.watching then
self.watching=nil
m(self.rig.unit,false)
end
a.LastSeen.unwatch(self.element.id)
end



function b:release()
self:stop()
a.Sounds.clearAuraSound(self.element.id.." removed")
a.Sounds.clearAuraSound(self.element.id.." arrived")
local b=self.f
for c,b in ipairs(b.slots)do
if b.enabled then
b.enabled=false
a.try(self.element.id.." slot off",b.c.SetAuraSlotEnabled,b.c,b.key,false)
end
end
b.taken={}
b.hold:Hide()
end



function b:respell()
local b=q(self.rig)
if a.equal(b,self.ids)then return end
local a=self.f
local c=e.candidatesOf(self.rig,b)
self.ids,a.filters=b,c
self:edge("refilter",function()
a.sensor:SetAuraGroupCandidateFilters("sensor",c)
for b,a in ipairs(a.slots)do a.c:SetAuraSlotCandidateFilters(a.key,c)end
end)
self:sounds()
end

function b:describe()
local c=0
for b,a in ipairs(self.f.slots)do if a.enabled then c=c+1 end end
local b={}
for a,c in ipairs(a.Spells.listOf(self.rig.spells))do b[a]=tostring(c)end
if self.rig.types then
local a=self.rig.longest and(" up to "..self.rig.longest.." s")or""
b={table.concat(self.rig.types,"+")..a.." ("..table.concat(b,"+")..")"}
end
local a=0
for b in pairs(self.f.paneGates or{})do a=a+1 end
local a=string.format("%s on %s, %d slots (%d made), %d containers, %d panes, held %s, pops %s",
table.concat(b,"+"),self.rig.unit,c,#self.f.slots,#self.f.containers+1,a,
tostring(not(self.trusted and self.pointed and not self:quiet())),
self.f.pops and(i.isQuiet(self.popKey)and"faded"or"shown")or"none")
if#(self.rig.bits or{})>0 then a=a..string.format(", %d Lua bits, mask %d",#self.rig.bits,self.mask or 0)end

if(self.paneWaits or 0)>0 then
a=a..string.format(", %d panes waiting for combat's end",self.paneWaits)
end
if(self.rig.over or 0)>0 then
a=a..string.format(", %d look%s past the caps drawn as a cover only (tint, overlay, ring)",self.rig.over,
self.rig.over==1 and""or"s")
end
return a
end


local function c()
for a in pairs(j)do a:updatePops()end
end
g.onCanActChange("aura source",c)
a.onChanged(function(a)
if a=="settings"or a=="profile"then c()end
end,"aura source")


a.LastSeen.onChange("aura source",function()
for a in pairs(j)do
if a.view.source.shownSpell=="lastSeen"then a:refeed()end
end
end)



local function c(a)
if d==a then return end
d=a
for a in pairs(j)do a:sounds()end
end
f.on("PLAYER_LEAVING_WORLD","aura sounds",function()c(true)end)
g.onStart("aura sounds",function()c(false)end)

i.onChange("aura source",function(a)
if a==nil and d and not i.isQuiet(nil)then c(false)end
for b in pairs(j)do
if a==nil or b.element.element.id==a then b:updateHold()end
if a==nil or b.popKey==a then b:updatePops()end
end
end)












e.REPLAY_MARGIN=p
function b:popLength()
local b=0
for c,a in ipairs(self.element.visuals)do
if a.part.effect and a.underButton and not a.gone and a.visual.length then
b=math.max(b,a.visual.length)
end
end
return b
end
local function b(a,b)
for a in pairs(j)do

if a.f.pops and not a.rig.types and(b=="player"or a.f.pointedAt==b)then
local b=a:popLength()

if b>0 then i.open(a.popKey,b+p)end
end
end
end
for c,a in ipairs({"UNIT_FLAGS","UNIT_FACTION"})do
f.onUnit(a,"player","aura replay player",b)
f.onUnit(a,"target","aura replay target",b)
end

a.Debug.experimental("an aura's arrival sound: AddAuraSound's Added trigger sounding as a new buff instance comes, at"
.." rest and in combat, and not at a /reload, a pull or a combat's end with the buff up (AU-21: one arrival heard"
.." at rest, its trigger unnamed)","I")

a.Debug.experimental("Water Shield's filter with 408511 beside 408510 (ShamanForever's second ID; the client's tables"
.." give it no aura)","I")
a.Debug.experimental("aura containers made with Edit Mode's preview off (D: SetEditModePreviewEnabled; no pop at"
.." Edit Mode, ihud-d92b)","T")
a.Debug.experimental("an aura's arrival pop on a container of its own, its holder faded at the player's UNIT_FLAGS"
.." (the replay hidden at a pull and a combat's end, ihud-d92)","T")
a.Debug.experimental("the same fade at the target's UNIT_FLAGS and UNIT_FACTION and the player's UNIT_FACTION (the replay hidden;"
.." Blizzard's source, unplayed)","I")

a.Debug.experimental("an aura by dispel type's pop not faded at a fight's edges: a type-only container never"
.." refreshes there (AuraContainerUtil, 70425)","D")
a.Debug.experimental("an aura by dispel type: a poison lighting a Poison filter on you in combat, leaving a"
.." Disease one dark (AU-13, T 70450)","T")
a.Debug.experimental("an aura by dispel type on a hostile target: its Magic buff lighting a HELPFUL Magic filter, at"
.." rest and in combat (AU-13: documented only), skipping long ones by maxDuration","D")
s.onChange("aura source",function()
for a in pairs(j)do
if a.rig.unit=="target"then a:repoint()end
end
end)
