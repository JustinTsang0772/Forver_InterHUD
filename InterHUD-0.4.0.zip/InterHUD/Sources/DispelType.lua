


local a,c=...
local b,d,e=c.Schema,c.Sources,c.Spells
local a=d.get("aura")


local g={"magic","curse","disease","poison","frenzy"}
local h={magic="Magic",curse="Curse",disease="Disease",poison="Poison",frenzy="Frenzy"}



local i={magic="Magic",curse="Curse",disease="Disease",poison="Poison"}
local k={"magic","curse","disease","poison"}





local l={player="HARMFUL|RAID",target="HELPFUL|RAID_PLAYER_DISPELLABLE"}
local m={player="HARMFUL",target="HELPFUL"}
local n={player="HARMFUL|DISPELLABLE",target="HELPFUL|DISPELLABLE"}
c.Debug.experimental("Only what you can remove: Blizzard's filter tokens HARMFUL|RAID on you and"
.." HELPFUL|RAID_PLAYER_DISPELLABLE on the hostile target, with a type list on the same slot (EP-40, unplayed)")
c.Debug.experimental("a dispel type's Frenzy: HELPFUL|DISPELLABLE (or the switch's token) less the named types by"
.." excludeDispelTypes, never its dispelName (EP-40, unplayed)")

local o={magic="Interface\\Icons\\Spell_Holy_DispelMagic",curse="Interface\\Icons\\Spell_Holy_RemoveCurse",
disease="Interface\\Icons\\Spell_Holy_NullifyDisease",poison="Interface\\Icons\\Spell_Nature_NullifyPoison",
frenzy="Interface\\Icons\\Spell_Nature_Drowsy"}

local function f(b,a)return a~=nil and a.unit=="target"end
local p={
{name="unit",type="unit",default="player",label="Watches"},

{name="types",type="list",of="choice",unique=true,minItems=1,maxItems=#g,
item={choices=g},labels=h,label="Dispel types"},

{name="onlyRemovable",type="boolean",default=false,label="Only what you can remove"},

d.spellsField("Spells","Its icon shows the first; empty, its first type's picture."),

{name="skipLong",type="boolean",default=false,label="Skip long buffs",
help="Leaves out buffs longer than Longest buff, and buffs with no end.",shownIf=f},
{name="longest",type="integer",default=2,min=1,max=60,step=1,unit="min",
under={"skipLong",true},label="Longest buff",shownIf=f},
}





local f={label="Aura by type",note="Curses, poisons, diseases and magic to cure or purge"}

local function j(b,c)

return a.islandVariant(b,{add=c,noun=b=="target"and"a buff on the target"
or"a dispel type",subject=b~="target"and"an effect you can dispel"or nil,eventOrder={"arrived"},
events={arrived=b=="target"and a.NOT_YET or a.POP}})
end
d.register("dispel",{
variantOf=function(a)return"dispel:"..(a.unit or"player")end,
idWord="dispel",
fields=p,
drawsAs="aura",
target={field="types",pick="Pick its types."},
variantOrder={"dispel:player","dispel:target"},
variants={
["dispel:player"]=j("player",f),
["dispel:target"]=j("target",{label=f.label,note=f.note,listed=false}),
},
})

a.notYet("dispel:target")


local a=setmetatable(d.get("dispel"),{__index=a})
a.TYPES=g


function a.learned()return true end

function a.yourSpells()return{}end






a.unpickedInChoices=true
local p={"player","target"}
local g={player="on you",target="on the target"}
local j={player="Any type on you",target="Any type on the target"}
local function q(b,c)
local a={}
for c,b in ipairs(b.dispels)do a[c]=h[b]or b end
return table.concat(a,", ")..", "..g[c]
end

a.pickWords="Pick its spell."
function a.addChoices(f,h)
local g=f and f~=""and f:lower()or nil
local b={}
for a,c in pairs(c.SpellTable and c.SpellTable.families or{})do
local d=c.dispels and e.known(a)and e.nameOf(a)
if d and(not g or d:lower():find(g,1,true)or tostring(a)==f)then
local e,f=e.highest(a)
for g,e in ipairs(c.dispelsOn)do
b[#b+1]={id=g==1 and a or(e..":"..a),name=d,icon=f,
note=q(c,e)}
end
end
end
table.sort(b,function(a,b)
if a.name~=b.name then return a.name<b.name end
return tostring(a.id)<tostring(b.id)
end)
while#b>(h or 30)do b[#b]=nil end
for e,c in ipairs(p)do
local e=j[c]
if not g or e:lower():find(g,1,true)then
b[#b+1]={id="any:"..c,name=e,icon=d.UNSET_ICON,note=a.target.pick}
end
end
return b
end
function a.addRecord(a)
local b=type(a)=="string"and a:match("^any:(%a+)$")
if b then
if not j[b]then return nil end
return{kind="dispel",unit=b~="player"and b or nil},f.label
end
local b,c
if type(a)=="string"then
b,c=a:match("^(%a+):(%d+)$")
c=tonumber(c)
elseif type(a)=="number"then
c=a
end
local d,a
if c then d,a=e.family(c)end
if not(a and a.dispels)then return nil end
b=b or a.dispelsOn[1]
local c=false
for d,a in ipairs(a.dispelsOn)do c=c or a==b end
if not c then return nil end
local c={}
for a,b in ipairs(a.dispels)do c[a]=b end

return{kind="dispel",unit=b~="player"and b or nil,types=c,spells={d}},
e.nameOf(d)or a.name
end






function a.typeFilter(a,b)
local f,c={},{}
for b,a in ipairs(type(b.types)=="table"and b.types or{})do
f[b],c[a]=a,true
end
local d=a.unit=="target"and"target"or"player"
local g=b.onlyRemovable and l[d]or(c.frenzy and n[d]or m[d])
local e={}
if c.frenzy then
local a={}
for d,b in ipairs(k)do
if not c[b]then a[i[b]]=true end
end
if next(a)then e.excludeDispelTypes=a end
else
local a={}
for c,b in ipairs(f)do a[i[b]]=true end
e.includeDispelTypes=a
end
if d=="target"and b.skipLong then
a.longest=b.longest*60
e.maxDuration=a.longest
end
a.types,a.typed=f,{filter=g,candidates=e}
end


function a.icon(a)
if type(a)~="table"or#e.listOf(a.spells)>0 then return nil end
return o[type(a.types)=="table"and a.types[1]or""]or d.UNSET_ICON
end

function a.words(a)
local b={}
for c,a in ipairs(type(a)=="table"and type(a.types)=="table"and a.types or{})do
b[c]=h[a]or tostring(a)
end
return#b>0 and table.concat(b,", ")or nil
end
a.wordsFirst=true

function a.preview(b)
return{icon=a.icon(b)}
end



local function a(a,b)
local a=type(a.sources)=="table"and a.sources[b[2]]
return type(a)=="table"and a.kind=="dispel"and a or nil
end
b.caveat("dispel type",{
text="Any effect of these types lights it, even one you can't remove.",
at=function(a)return b.isPath(a,"sources","*","types")end,
applies=function(b,c)
local a=a(b,c)
return a~=nil and not a.onlyRemovable
end,
})


b.caveat("dispel type removable on a target",{
text="In a group, also what others can remove.",
at=function(a)return b.isPath(a,"sources","*","onlyRemovable")end,
applies=function(b,c)
local a=a(b,c)
return a~=nil and a.unit=="target"
end,
})
