


local a,b=...
local e,a,d,n,l,h,c=b.Sources,b.Schema,b.Layers,b.Events,b.Quiet,b.Ticker,b.Debug







c.experimental("the five seconds timed from your own cast that spends mana, by our clock (UN-13: the pause itself T"
.." 70009, at rest and in a burst; regeneration's shape, a talent that keeps some going and the pause in a fight"
.." against our estimate unmeasured: EP-17)","T")
c.experimental("a spend told by the mana entry of C_Spell.GetSpellPowerCost read at UNIT_SPELLCAST_SENT and counted at"
.." the cast's SUCCEEDED by castGUID, a free cast reading no cost at SENT, a secret cost counted as a spend (CA-2:"
.." plain at SENT and SUCCEEDED in a fight, T 70338; a free cast's reading and the events' order unseen: EP-17)",
"I")

local j=5
local i=0.1
local m=Enum.PowerType.Mana
local g="five-second rule"

e.register("fiveSecondRule",{
experimental=true,
fields={},

idWord="yourfivesecondrule",

noteWord=function()return"from your casts"end,
nothingToPick=true,
variantOrder={"fiveSecondRule"},
variants={
fiveSecondRule={
add={label="Five-second rule",note="Timed from your casts that cost mana",whenLearned=true},
noun="your five-second rule",
read="lua",moment="plain",
stateOrder={"paused","regenerating"},
states={
paused={label="Paused",holds="An estimate: five seconds have not passed since your last cast that"
.." cost mana, so your mana regeneration is paused or slowed."},
regenerating={label="Regenerating",holds="An estimate: five seconds or more have passed since"
.." your last cast that cost mana, or InterHUD has not seen one since you logged in or reloaded."},
},
eventOrder={"pauses","resumes"},
events={
pauses={label="Pauses",holds="your mana regeneration pauses",begins="paused"},
resumes={label="Resumes",holds="your mana regeneration resumes",begins="regenerating"},
},
typical="paused",
},
},
})

local c=e.get("fiveSecondRule")

local f="Five-second rule"
function c.words()return f end



function c.learned()
local c,a=b.try("UnitPowerMax",UnitPowerMax,"player",m)
if not c or b.isSecret(a)or type(a)~="number"then return true end
return a>0
end


a.caveat("five-second rule estimate",{
text="An estimate, timed from your own casts that cost mana: a pause that the game starts for any other reason"
.." isn't seen, and a talent that keeps some regeneration going isn't taken into account.",
at=function(b)return a.isPath(b,"sources","*","enabled")end,
applies=function(a,b)
local a=type(a.sources)=="table"and a.sources[b[2]]
return type(a)=="table"and a.kind=="fiveSecondRule"
end,
})


function c.preview(b,a)
return{length=a and a.state=="paused"and j or false}
end

function c.plan(a)
local b={kind="fiveSecondRule",parts=d.allParts(a,nil)}
e.planCopies(a,b)
return b
end




local a={endsAt=false,duration=false,pending={},queue={}}
c.rule=a


local function k()
return a.endsAt~=false and GetTime()<a.endsAt
end

local f={}
local d={}
d.__index=d


function d:feed()
local b=self.data
if k()then b.duration=a.duration else b.duration=false end
self.element:feed(b)
end




function d:read(c)
local b=self.state
local a=k()and"paused"or"regenerating"
if a~=b then
self.state=a
self.element:setState(a)
end
self:feed()
if not c or b==nil or a==b or l.isQuiet(nil)then return end
self.element:moment(a=="paused"and"pauses"or"resumes")
end

local function o(b)
for a in pairs(f)do e.try(a,a.read,b)end
end


local function l()
if a.endsAt~=false and GetTime()>=a.endsAt then
a.endsAt,a.duration=false,false
h.unsubscribe(i,g)
o(true)
end
end


local function r()
local b=GetTime()
local c=C_DurationUtil.CreateDuration()
c:SetTimeFromStart(b,j)
a.endsAt,a.duration=b+j,c
h.subscribe(i,g,l)
o(true)
end



local function j(a)
local a=e.powerCost(a,m)
if b.isSecret(a)then return true end
return a~=false and a>0
end

local q=16
local function m(b)
if a.pending[b]==nil then return end
a.pending[b]=nil
local a=a.queue
for c=1,#a do
if a[c]==b then
table.remove(a,c)
return
end
end
end
local function o(a,c)
return not b.isSecret(a)and type(a)=="string"and not b.isSecret(c)and type(c)=="number"
end


local function p(d,e,f,b,c)
if not o(b,c)then return end
if a.pending[b]==nil then
if#a.queue>=q then m(a.queue[1])end
a.queue[#a.queue+1]=b
end
a.pending[b]=j(c)
end

local function q(d,e,b,c)
if not o(b,c)then return end
local a=a.pending[b]
m(b)
if a==nil then a=j(c)end
if a then r()end
end
local function j(c,d,a)
if not b.isSecret(a)and type(a)=="string"then m(a)end
end
c.onSent,c.onSucceeded,c.onEnd,c.tick=p,q,j,l



local j={UNIT_SPELLCAST_SENT=p,UNIT_SPELLCAST_SUCCEEDED=q,UNIT_SPELLCAST_FAILED=j,
UNIT_SPELLCAST_FAILED_QUIET=j,UNIT_SPELLCAST_INTERRUPTED=j}

local function b(b)
for a,c in pairs(j)do
if b then n.onUnit(a,"player",g,c)else n.offUnit(a,g)end
end
if not b then
for b in pairs(a.pending)do a.pending[b]=nil end
for b=#a.queue,1,-1 do a.queue[b]=nil end
h.unsubscribe(i,g)
end
end


function c.build(b,c,f,a)
if a then a:release()end
local d=setmetatable({element=b,view=f,rig=c,data={}},d)
e.plainBuild(d,b,c,a)
return d
end

function d:paint()
e.plainPaint(self)
end


function d:start()
if next(f)==nil then
b(true)

if a.endsAt~=false then h.subscribe(i,g,l)end
end
f[self]=true
self.state=nil
self:read(false)
end

function d:stop()
f[self]=nil
if next(f)==nil then b(false)end
end

function d:release()
self:stop()
self.host:Hide()
end

function d:refeed()
if f[self]then self:feed()end
end

function d:describe()
return string.format("five-second rule: %s%s",tostring(self.state),
k()and string.format(", %.1f s left",a.endsAt-GetTime())or"")
end

c.live=f
