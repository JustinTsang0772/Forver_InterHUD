




local b,a=...
local g,c,o,k,l,b=a.Sources,a.Schema,a.Layers,a.Spells,a.Ticker,a.Debug







b.experimental("the range ladder: each spellbook spell's range from C_Spell.GetSpellInfo's minRange and maxRange and"
.." C_Spell.IsSpellHarmful (D; C: EllesmereUI's ladder on Forever), IsSpellInRange asked by the rank you know"
.." (UN-7: T 70450, each spell at its own range, in combat)","C")
b.experimental("the range read five times a second while you have a target, and at a target change (UN-7's poll; the"
.." range event, UN-16, would serve one spell alone)","T")

b.experimental("the range ladder's item rungs: C_Item.IsItemInRange on items you don't own, 5 to 35 yards, plain at"
.." rest and in a fight on a target you can attack (UN-23: T 70862, open world; a dungeon and an enemy player"
.." unread, EP-77)","T")

local m=0.2
local h="range source"
local p=3
local e=100

local q={{5,{8149}},{10,{17626,10699}},{20,{10645,21519}},{25,{13289}},
{30,{17202,835,7734}},{35,{18904}}}

local d

local function b()return d.boundaries()end

local function f(c,d)
return function(a)
local a,c={},type(a)=="table"and a[c]or nil
for e,b in ipairs(b())do
if not c or(d and b<c)or(not d and b>c)then a[#a+1]=b end
end
return a
end
end
local function i()
local a={}
for c,b in ipairs(b())do a[b]=b.." yards"end
return a
end


local function j(d)
return function(a,c)
local a=a
for b=1,#c-1 do a=type(a)=="table"and a[c[b]]or nil end
local a=type(a)=="table"and a[d]or nil
if a==nil then return nil end
for c,b in ipairs(b())do
if b==a then return nil end
end
return"This character has no way to tell "..a.." yards apart, so this range never holds here."
end
end




local function n(a)return a.from or 0,a.to end
local b={label="Ranges",read="lua",max=4,saidAlone=true,
holds="Your target is known to be within a set range.",
full="A range takes at most %d of these.",
rule=function(a,b,c)
if a.from and a.to and a.from>=a.to then b:problem(c,"has a from that isn't under its to.")end
end,
finish=function(a,b)
if a.from==nil and a.to==nil then b.to=5 end
end,
newItem=function()return{to=b()[1]or 5}end,
setting={
{name="from",type="integer",min=1,max=e,control="choice",choicesFrom=f("to",true),
labelsFrom=i,noneLabel="No nearer end",label="From",said="%s yards or more",
helpFrom=j("from")},
{name="to",type="integer",min=1,max=e,control="choice",choicesFrom=f("from",false),
labelsFrom=i,noneLabel="No farther end",label="To",said="%s yards or less",
helpFrom=j("to")},
}}

g.register("range",{
experimental=true,
fields={},
idWord="targetrange",
noteWord=function()return"to your target"end,
nothingToPick=true,
variantOrder={"range"},
variants={
range={
add={label="Range",note="An estimate of how far away your target is"},
noun="your target's range",
read="lua",moment="plain",
stateOrder={"known","unknown"},
states={
known={label="Known",holds="At least one of your spells or the range items could tell how far away your target is.",
scene={"hostileTarget"}},
unknown={label="Unknown",holds="You have no target you can attack, or nothing could"
.." tell how far away it is."},
},
factOrder={"ranges"},facts={ranges=b},
eventOrder={},events={},
typical="known",
},
},
})

d=g.get("range")

local b="Range"
function d.words()return b end

c.caveat("range estimate",{
text="An estimate from the ranges of your own harmful spells and of six items the game can check (5, 10, 20, 25, 30"
.." and 35 yards): it can only say that your target is between two of those ranges.",
at=function(a)return c.isPath(a,"sources","*","enabled")end,
applies=function(a,b)
local a=type(a.sources)=="table"and a.sources[b[2]]
return type(a)=="table"and a.kind=="range"
end,
})


local function j(a,b)
if not b then return string.format("Over %d yd",a)end
if a<=0 then return string.format("Under %d yd",b)end
return string.format("%d to %d yd",a,b)
end


function d.icon()return 132172 end


function d.preview(c,a)
if not a or a.state~="known"then return{length=false,range=false}end
local d,b=10,20
local c=type(c.facts)=="table"and c.facts.ranges or nil
for e,c in ipairs(type(c)=="table"and c or{})do
if c.enabled~=false and a.facts and a.facts[c.id]then
d,b=n(c)
if b==nil then b=false end
end
end
return{length=false,range=j(d,b or nil)}
end

function d.plan(b)
local c=b.source
local a={kind="range",parts=o.allParts(b,nil),ranges={}}
g.planCopies(b,a)
local b=type(c.facts)=="table"and c.facts.ranges or nil
for c,b in ipairs(type(b)=="table"and b or{})do
if b.enabled~=false then
local c,d=n(b)
a.ranges[#a.ranges+1]={id=b.id,lo=c,hi=d or false}
end
end
return a
end



local c,i,f={},false,false
local function n(b)return not a.isSecret(b)and type(b)=="number"end
local function o(c)
local d,b=a.try("GetSpellInfo",C_Spell.GetSpellInfo,c)
if not d or type(b)~="table"then return nil end
local d,b=b.minRange,b.maxRange
if not n(b)or b<=0 or b>e then return nil end
if n(d)and d>0 then return nil end
local d,c=a.try("IsSpellHarmful",C_Spell.IsSpellHarmful,c)
if not d or a.isSecret(c)or c~=true then return nil end
return b
end
local function e()
i=true
for a=#c,1,-1 do c[a]=nil end
local d={}
local function e(b)
local a=d[b]
if not a then
a={range=b,spells={},items={}}
d[b]=a
c[#c+1]=a
end
return a
end
local b={}
for c,a in ipairs(k.bookEntries())do b[#b+1]=a.id end
table.sort(b)
for a,b in ipairs(b)do
local a=o(b)
if a then
local a=e(a)
if#a.spells<p then a.spells[#a.spells+1]=b end
end
end
if C_Item and C_Item.IsItemInRange then
for c,b in ipairs(q)do
local c=e(b[1])
for d,b in ipairs(b[2])do
c.items[d]=b
if not f and C_Item.RequestLoadItemDataByID then
a.try("RequestLoadItemDataByID",C_Item.RequestLoadItemDataByID,b)
end
end
end
f=true
end
table.sort(c,function(a,b)return a.range<b.range end)
end
d.ladder=c

local b={}
function d.boundaries()
if not i then e()end
for a=#b,#c+1,-1 do b[a]=nil end
for a,c in ipairs(c)do b[a]=c.range end
return b
end



local function o(b)
for c=1,#b.spells do
local c,b=a.try("IsSpellInRange",C_Spell.IsSpellInRange,b.spells[c],"target")
if c and not a.isSecret(b)and b~=nil then return b==true end
end
for c=1,#b.items do
local c,b=a.try("IsItemInRange",C_Item.IsItemInRange,b.items[c],"target")
if c and not a.isSecret(b)and b~=nil then return b==true end
end
return nil
end



local b={known=false,lo=0,hi=false,words=false}
d.now=b

local function n()
if not i then e()end
local e,f,d=0,false,false

for a=1,a.Target.hostile()and#c or 0 do
local b=o(c[a])
if b==true then
d,f=true,c[a].range
break
elseif b==false then
d,e=true,c[a].range
end
end
if d==b.known and(not d or(e==b.lo and f==b.hi))then return false end
b.known,b.lo,b.hi=d,e,f
b.words=d and j(e,f or nil)or false
return true
end

local f={}
local e={}
e.__index=e

function e:feed()
local a=self.data
a.range=b.known and b.words or false
self.element:feed(a)
end


function e:read(c)
local a=b.known and"known"or"unknown"
if a~=self.state then
self.state=a
self.element:setState(a)
end
for d,a in ipairs(self.rig.ranges)do
local b=b.known and b.lo>=a.lo and(not a.hi or(b.hi and b.hi<=a.hi))or false
self.element:setFact(a.id,b,c)
end
self:feed()
end

local function o(a)
if n()or a then
for a in pairs(f)do g.try(a,a.read,true)end
end
end
local function j()
if next(f)~=nil then o(false)end
end
d.tick=j
a.Target.onChange(h,j)

k.onChange(h,function()i=false end)

function d.build(b,c,d,a)
if a then a:release()end
local d=setmetatable({element=b,view=d,rig=c,data={}},e)
g.plainBuild(d,b,c,a)
return d
end

function e:paint()
g.plainPaint(self)
end

function e:start()
if next(f)==nil then
l.subscribe(m,h,j)
end
f[self]=true
self.state=nil

if n()then
for a in pairs(f)do
if a~=self then g.try(a,a.read,true)end
end
end
self:read(false)
end

function e:stop()
f[self]=nil
if next(f)==nil then l.unsubscribe(m,h)end
end

function e:release()
self:stop()
self.host:Hide()
end

function e:refeed()
if f[self]then self:feed()end
end

function e:describe()
local d={}
for b,a in ipairs(c)do d[b]=a.range.."x"..#a.spells.."+"..#a.items end
return string.format("range: %s; rungs %s",b.known and b.words or"unknown",table.concat(d," "))
end

d.live=f
