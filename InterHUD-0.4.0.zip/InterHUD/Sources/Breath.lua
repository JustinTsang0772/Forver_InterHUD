
local a,b=...
local h,c,d,n,a=b.Sources,b.Layers,b.Events,b.Quiet,b.Debug







a.experimental("the breath bar's START and STOP in combat (CA-10: T 70009 only), and in a restricted instance","C")
a.experimental("breath's time left fed as a duration made from its plain progress (CA-10, A5)","C")

a.experimental("a paused breath bar as Draining with no countdown (MIRROR_TIMER_PAUSE: never seen)","I")

local i="BREATH"
local j=136148
local f=3

h.register("breath",{
experimental=true,
fields={},
idWord="breath",
nothingToPick=true,
variantOrder={"breath"},
variants={
breath={
add={label="Breath",note="Your breath under water"},
noun="your breath",
read="lua",moment="plain",
stateOrder={"draining","notDraining"},
states={
draining={label="Draining",holds="Your breath bar is running down."},
notDraining={label="Not draining",holds="Your breath bar isn't running down."},
},
eventOrder={"starts","stops"},
events={
starts={label="Starts",holds="it starts draining",begins="draining"},
stops={label="Stops",holds="it stops draining",begins="notDraining"},
},
},
},
})

local e=h.get("breath")

local a="Your breath"
function e.icon()return j end
function e.words()return a end


function e.addChoices(b,c)
local b=b and b~=""and b:lower()or nil
if b and not a:lower():find(b,1,true)then return{}end
return{{id="breath",name=a,icon=j,note="Under water"}}
end
function e.addRecord(a)
if a~="breath"then return nil end
return{kind="breath"},"Breath"
end


function e.preview()
return{icon=j,name="Breath",length=60}
end

function e.plan(a)
local b={kind="breath",parts=c.allParts(a,nil)}
h.planCopies(a,b)
return b
end


local a={draining=false,paused=false}
e.bar=a


local function k(a)
return a==true or(type(a)=="number"and a~=0)
end



local function g(d,e,c,g,f,h)
a.draining=d
a.paused=d and k(h)
a.label=type(f)=="string"and not b.isSecret(f)and f or a.label
a.maxValue,a.scale=c,g
if not d or a.paused then
a.endsAt,a.total=nil,nil
return
end
local d=-g
if GetMirrorTimerProgress then
local c,a=b.try("GetMirrorTimerProgress",GetMirrorTimerProgress,i)
if c and type(a)=="number"and not b.isSecret(a)then e=a end
end
if type(e)=="number"and type(c)=="number"and c>0 then
a.endsAt,a.total=GetTime()+math.max(0,e)/1000/d,c/1000/d
else
a.endsAt,a.total=nil,nil
end
end

local function k(...)
for a=1,select("#",...)do
if b.isSecret((select(a,...)))then return false end
end
return true
end



local function l()
if not GetMirrorTimerInfo then return nil end
for a=1,f do
local f,b,c,d,a,e,g=b.try("GetMirrorTimerInfo",GetMirrorTimerInfo,a)
if not f or not k(b,c,d,a,e)then return nil end
if b==i and type(a)=="number"then return true,c,d,a,g,e end
end
return false
end


local function m()
local a,c,d,b,e,f=l()
if a==nil then return end
if a then g(b<0,c,d,b,e,f)else g(false)end
end

local f={}
local c={}
c.__index=c



local o=0.5
function c:feed()
local b=a.draining and a.endsAt or false
if self.fedEnds~=nil and(b==self.fedEnds
or(b and self.fedEnds and math.abs(b-self.fedEnds)<o))then
return
end
self.fedEnds=b
local b=self.data
b.icon=j
b.name=a.label or"Breath"
if a.draining and a.endsAt then
local c=C_DurationUtil.CreateDuration()
c:SetTimeFromStart(a.endsAt-a.total,a.total)
b.duration=c
else
b.duration=false
end
self.element:feed(b)
end




function c:read(c)
local b=self.state
local a=a.draining and"draining"or"notDraining"
if a~=b then
self.state=a
self.element:setState(a)
end
self:feed()
if not c or b==nil or a==b or n.isQuiet(nil)then return end
self.element:moment(a=="draining"and"starts"or"stops")
end

function e.build(b,d,e,a)
if a then a:release()end
local c=setmetatable({element=b,view=e,rig=d,data={}},c)
h.plainBuild(c,b,d,a)
return c
end

function c:paint()
h.plainPaint(self)
end

local function h(c)
for a in pairs(f)do b.try("breath "..tostring(a.element.id),a.read,a,c)end
end
local function j(j,b,c,d,a,e,f)
if not k(b,c,d,a,e)or b~=i or type(a)~="number"then return end
g(a<0,c,d,a,f,e)
h(true)
end


local function n(d,b,c)
if not k(b,c)or b~=i or not a.draining then return end
g(true,nil,a.maxValue,a.scale,nil,c)
h(false)
end
local function k(c,a)
if b.isSecret(a)or a~=i then return end
g(false)
h(true)
end

local function b()
m()
h(false)
end




local function i()
if not a.draining then return end
local a,c,d,b=l()
if a==nil or(a and b<0)then return end
g(false)
h(true)
end

function c:start()
if next(f)==nil then
d.on("MIRROR_TIMER_START","breath source",j)
d.on("MIRROR_TIMER_STOP","breath source",k)
d.on("MIRROR_TIMER_PAUSE","breath source",n)
d.on("PLAYER_ENTERING_WORLD","breath source",b)
d.onUnit("UNIT_AURA","player","breath source",i)
m()
end
f[self]=true
self.state,self.fedEnds=nil,nil
self:read(false)
end

function c:stop()
f[self]=nil
if next(f)==nil then
d.off("MIRROR_TIMER_START","breath source")
d.off("MIRROR_TIMER_STOP","breath source")
d.off("MIRROR_TIMER_PAUSE","breath source")
d.off("PLAYER_ENTERING_WORLD","breath source")
d.offUnit("UNIT_AURA","breath source")
end
end

function c:release()
self:stop()
self.host:Hide()
end

function c:refeed()
self.fedEnds=nil
if f[self]then self:feed()end
end

function c:describe()
return string.format("breath %s%s%s",tostring(self.state),a.paused and", paused"or"",a.endsAt
and string.format(", %.1f s of %.1f s left",math.max(0,a.endsAt-GetTime()),a.total)or"")
end

e.live=f
