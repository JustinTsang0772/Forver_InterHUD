


local a,b=...
local c,d,g,e,l,h,i,a=b.Schema,b.Sources,b.Layers,b.Events,b.Quiet,b.Target,
b.Combat,b.Debug










a.experimental("your threat on your target from UnitThreatSituation through target at the player's"
.." UNIT_THREAT_SITUATION_UPDATE and the target's UNIT_THREAT_LIST_UPDATE, in combat (UN-14: one ordinary"
.." open-world mob, every read plain; whether an event comes at each change of the state unseen: EP-29)","T")
a.experimental("threat against an elite, a boss and in an instance: the state held at 0 where it reads secret"
.." (EP-29; a boss's numbers secret, D; the state's secrecy there unread)","D")

d.register("threat",{
experimental=true,
fields={},
idWord="threat",
nothingToPick=true,
variantOrder={"threat"},
variants={
threat={

add={label="Threat",note="Your threat on your target",further=true},
noun="your threat",
read="lua",moment="plain",

stateOrder={"tanking","slipping","pulling","behind","noThreat","hidden"},
states={

tanking={label="Tanking",holds="Your target is attacking you, and your threat is the highest.",
scene={"hostileTarget"}},
slipping={label="Slipping",holds="Your target is attacking you, but someone else has more threat.",
scene={"hostileTarget"}},
pulling={label="Pulling",holds="Your target is attacking someone else, but your threat is higher than theirs.",
scene={"hostileTarget"}},
behind={label="Behind",holds="Your target is attacking someone else, and your threat is lower than theirs.",
scene={"hostileTarget"}},
noThreat={label="No threat",holds="You have no hostile target, or you aren't on its threat list."},

hidden={read="held",label="Hidden",holds="The game hides your threat on your target.",
scene={"hostileTarget"}},
},


eventOrder={"gainsAggro","losesAggro"},
events={
gainsAggro={label="Gains aggro",holds="it turns on you",begins="tanking"},
losesAggro={label="Loses aggro",holds="you lose it",begins="behind"},
},

typical="tanking",
},
},
})

local f=d.get("threat")

local a="Your threat"
function f.words()return a end


function f.addChoices(b)
local b=b and b~=""and b:lower()or nil
if b and not a:lower():find(b,1,true)and not("threat"):find(b,1,true)then return{}end
return{{id="threat",name=a,icon=d.UNSET_ICON,note="On your target"}}
end
function f.addRecord(a)
if a~="threat"then return nil end
return{kind="threat"},"Threat"
end


c.caveat("threat hidden",{
text="Not shown where the game hides threat.",
at=function(a)return c.isPath(a,"sources","*","enabled")end,
applies=function(a,b)
local a=type(a.sources)=="table"and a.sources[b[2]]
return type(a)=="table"and a.kind=="threat"
end,
})

function f.plan(a)
local b={kind="threat",parts=g.allParts(a,nil)}
d.planCopies(a,b)
return b
end



local a={state="noThreat",held=false,serial=0}
f.threat=a

local c={[0]="behind",[1]="pulling",[2]="slipping",[3]="tanking"}

local g={slipping=true,tanking=true}
local j={behind=true,pulling=true}




local function k()
if not h.hostile()then return"noThreat",false end
local d,a=b.try("UnitThreatSituation",UnitThreatSituation,"player","target")
if not d then return"noThreat",false end
if b.isSecret(a)then return"hidden",true end
return c[a]or"noThreat",false
end

local c={}
local b={}
b.__index=b





function b:read(d)
local c,e=self.state,self.serial
local b=a.state
self.serial=a.serial

if b~=c then
self.state=b
self.element:setState(b)
self.element:hold(a.held==true)
end
if not d or c==nil or b==c or e~=a.serial or l.isQuiet(nil)then return end
if j[c]and g[b]then
self.element:moment("gainsAggro")
elseif g[c]and j[b]then
self.element:moment("losesAggro")
end
end


function b:paint()
d.plainPaint(self)
self.element:hold(a.held==true)
end

function f.build(c,e,f,a)
if a then a:release()end
local b=setmetatable({element=c,view=f,rig=e},b)
d.plainBuild(b,c,e,a)
return b
end

local function g(b)
a.state,a.held=k()
for a in pairs(c)do d.try(a,a.read,b)end
end
local function d()g(true)end




local function j()
e.atFrameEnd("threat source",d)
end

h.onChange("threat source",function()
if next(c)==nil then return end
a.serial=a.serial+1
g(true)
e.atFrameEnd("threat source",d)
end)

local function h()
if next(c)==nil then return end
g(true)
e.atFrameEnd("threat source",d)
end
i.onStart("threat source",h)
i.onEnd("threat source",h)

function b:start()
if next(c)==nil then
e.onUnit("UNIT_THREAT_SITUATION_UPDATE","player","threat source",j)
e.onUnit("UNIT_THREAT_LIST_UPDATE","target","threat source",j)
a.state,a.held=k()
end
c[self]=true
self.state,self.serial=nil,nil
self:read(false)
end

function b:stop()
c[self]=nil
if next(c)==nil then
e.offUnit("UNIT_THREAT_SITUATION_UPDATE","threat source")
e.offUnit("UNIT_THREAT_LIST_UPDATE","threat source")
end
end

function b:release()
self:stop()
self.host:Hide()
end

function b:describe()
return"threat: "..tostring(self.state)..(a.held and" (the game hides it: held at 0)"or"")
end

f.live=c
