



local a,c=...
local g,p,e,q,n,l,a=c.Sources,c.Layers,c.Events,c.Quiet,c.Units,c.Ticker,c.Debug







a.experimental("Casting and Channelling told by isTradeskill's nil test on UnitCastingInfo and UnitChannelInfo"
.." (CA-19: NeverSecret by the docs, unread in game: EP-45)","D")
a.experimental("your own cast's START, STOP, DELAYED, channel and INTERRUPTED events and its duration objects, in"
.." combat (CA-20: the docs; CA-1 records only SENT, SUCCEEDED and the FAILED pair: EP-70)","D")
a.experimental("the target's cast bar over a whole cast and a channel, its pushback taken again at DELAYED and"
.." CHANNEL_UPDATE, a channel's fade at its end a curve on its secret duration (CA-5: two stills of a cast;"
.." channels, a run, a pushback and the fade's curve on a cast unseen: EP-45)","T")
a.experimental("the target's cast name into a font string and its picture into a texture, both secret (FR-27 records"
.." a secret number and a totem's picture; a cast's unseen: EP-45)","I")
a.experimental("Can't be interrupted: the target's notInterruptible into SetAlphaFromBoolean on its gate's frames, a"
.." nil read lit plainly at 0 (FR-39: a frame host by the docs; SE-4: a nil refused by the call: EP-45; FR-42:"
.." a look's two copies, never both or neither: EP-69)","D")
a.experimental("a target's channel ended by an interrupt told by CHANNEL_STOP's interruptedBy: a secret one counted"
.." as given, nil as a plain end (SE-4: Blizzard's bar reads interruptedBy == nil; a secret never is nil: EP-45)","D")
a.experimental("an icon's sweep and time on a target's cast, off by default: its secret duration into"
.." SetCooldownFromDurationObject (CA-5 proves only a StatusBar's sink: EP-45)","I")
a.experimental("your pet's cast read as yours: UnitCastingInfo, UnitChannelInfo, their durations and its"
.." UNIT_SPELLCAST_* through RegisterUnitEvent on pet, plain in a fight (CA-21: the cast predicate exempts the"
.." player or their pet, the docs only); None where UnitExists(\"pet\") is false (UN-21); a pet's change at"
.." UNIT_PET for you (UN-21; what it brings at a summon, a dismissal and a death unread: EP-26)","D")
a.experimental("your focus target's cast read as your target's: secret, drawn through the same sinks, Can't be"
.." interrupted from its flag, its UNIT_SPELLCAST_* through RegisterUnitEvent on focus, its change at"
.." PLAYER_FOCUS_CHANGED, None where UnitExists(\"focus\") is false; its death read below (UN-22: the docs, CA-5's"
.." predicates by token: EP-73)","D")
a.experimental("a cancelled target cast (the mob moved or died) read as a plain end with no Gets interrupted (CA-4"
.." records SUCCEEDED and INTERRUPTED only: EP-45)","I")
a.experimental("a cast you cancel (moving, Escape) told from a kick by INTERRUPTED's interruptedBy, taken as nil at"
.." a cancel (our reading: Blizzard's bar shows Interrupted either way and the docs say never nil: EP-73)","I")

a.experimental("Finishes: your SUCCEEDED naming the cast under way as that cast ends (CA-1: the event and its GUID"
.." plain in a fight; its place against STOP unread, so one a frame before or after the end is taken: EP-70); a"
.." channel plays none (its SUCCEEDED comes at its start, and its end can't be told from a cancel)","I")
a.experimental("Is cancelled: your INTERRUPTED with no interruptedBy naming the cast under way (EP-73's reading: one"
.." cancel by moving seen on 70862, interruptedBy nil, three more INTERRUPTED 0.44 s later with the cast gone,"
.." which name no cast under way and play nothing; a kick unseen; a channel you cancel plays none, its"
.." CHANNEL_STOP carrying no interruptedBy as a channel run out does)","I")

local r=1
local h=136048

local i={"casting","channelling","interrupted","notCasting"}

local d={pet="You have no pet out.",focus="You have no focus target."}
local function b(a)


local b=a=="target"and{"hostileTarget"}or nil
return{
casting={label="Casting",holds="A cast is currently casting.",scene=b},
channelling={label="Channelling",holds="A channelled cast is currently channelling.",scene=b},
interrupted={label="Interrupted",holds="The cast was just interrupted.",scene=b},
notCasting={label="Not casting",holds="Nothing is being cast."},
none=d[a]and{label="None",holds=d[a]}or nil,
}
end


local j={label="Can't be interrupted",holds="The cast can't be interrupted.",read="gate"}

local k={player="yourcast",target="targetcast",pet="petcast",focus="focuscast"}
local d="Yours, your target's, your pet's or your focus target's"



local m={label="Starts",holds="the cast starts",begins="casting",says=false}

local o={label="Starts",holds="the cast starts",begins="casting",says=""}
local f={label="Gets interrupted",holds="it is interrupted",begins="interrupted",
says="Interrupted"}

g.register("cast",{
experimental=true,
fields={{name="unit",type="unit",units=n.TOKENS,default="player",label="Watches"}},
variantOf=function(a)return"cast:"..(a.unit or"player")end,

idWord=function(a)return k[a.unit]or k.player end,

noteWord=function()return false end,
nothingToPick=true,
variantOrder={"cast:player","cast:target","cast:pet","cast:focus"},
variants={
["cast:player"]={
add={label="Cast",note=d},
unit="player",noun="your cast",
read="lua",moment="plain",
stateOrder=i,states=b("player"),


eventOrder={"starts","finishes","getsInterrupted","isCancelled","failed"},
events={
starts=m,
finishes={label="Finishes",holds="your cast finishes",begins="notCasting",says="Finished"},
getsInterrupted=f,
isCancelled={label="Is cancelled",holds="you cancel your cast",begins="notCasting",
says="Cancelled"},
failed={label="Failed",holds="your cast fails",begins="notCasting",says="Failed"},
},
typical="casting",
},

["cast:target"]={
add={label="Cast",note=d,listed=false},
unit="target",noun="your target's cast",
read="lua",moment="plain",
stateOrder=i,states=b("target"),
factOrder={"notInterruptible"},facts={notInterruptible=j},

eventOrder={"starts","getsInterrupted"},
events={starts=o,getsInterrupted=f},
typical="casting",
},


["cast:pet"]={
add={label="Cast",note=d,listed=false},
unit="pet",noun="your pet's cast",
read="lua",moment="plain",
stateOrder={"casting","channelling","interrupted","notCasting","none"},states=b("pet"),
eventOrder={"starts","getsInterrupted"},
events={starts=m,getsInterrupted=f},
typical="casting",
},


["cast:focus"]={
add={label="Cast",note=d,listed=false},
unit="focus",noun="your focus target's cast",
read="lua",moment="plain",
stateOrder={"casting","channelling","interrupted","notCasting","none"},states=b("focus"),
factOrder={"notInterruptible"},facts={notInterruptible=j},
eventOrder={"starts","getsInterrupted"},
events={starts=o,getsInterrupted=f},
typical="casting",
},
},
})

local f=g.get("cast")

local d="Cast"
function f.icon()return h end
function f.words()return d end


function f.preview(b,a)
local a=a and a.state
local b
if a=="interrupted"then b=true elseif a=="notCasting"then b=false end
return{icon=h,name=d,length=2.5,channel=a=="channelling",full=b}
end



function f.plan(b)
local c=b.source
local a={kind="cast",unit=c.unit or"player",parts=p.allParts(b,nil)}
g.planCopies(b,a)
local b=f.variants["cast:"..a.unit]
if b and b.facts and b.facts.notInterruptible then a.flagKey=c.id..".notInterruptible"end
return a
end







local b={}
f.casts=b
local function o(a)
local c=b[a]
if not c then
local d=f.variants["cast:"..a]
c={unit=a,state="notCasting",duration=false,name=false,icon=false,flag=false,
key="cast source "..a,deathKey="cast source death "..a,seen={},play={},
dead=false,absent=d~=nil and d.states.none~=nil}
b[a]=c
end
return c
end


local function j(a)
if c.isSecret(a)then return a end
if a==nil then return false end
return a
end

local function d(b,a)
return b and not c.isSecret(a)and a~=nil
end


local function p(a)
local b=a.unit
if a.dead then return nil end
local a,e,j,f,k,l,g,h,i=c.try("UnitCastingInfo",UnitCastingInfo,b)
if d(a,g)then return"casting",e,f,i,h end
local a,b,g,c,h,i,e,f=c.try("UnitChannelInfo",UnitChannelInfo,b)
if d(a,e)then return"channelling",b,c,f,nil end
return nil
end
local function s(b,a)
local a=a=="channelling"and UnitChannelDuration or UnitCastingDuration
if not a then return false end
local a,b=c.try("cast duration",a,b.unit)
if not a then return false end
return j(b)
end

local h={}
local d={}
d.__index=d




function d:feed()
local b,a=b[self.unit],self.data
local c=b.state=="casting"or b.state=="channelling"
if c then a.duration=b.duration else a.duration=false end
a.channel=b.state=="channelling"

if c then a.full=nil else a.full=b.state=="interrupted"end
if c then
a.name,a.icon=b.name,b.icon
elseif b.state=="interrupted"then
a.name,a.icon=nil,nil
else
a.name,a.icon=false,false
end
self.element:feed(a)
end


function d:light()
local a=self.rig.flagKey
if not a then return end
local b=b[self.unit]
if b.state=="casting"or b.state=="channelling"then
g.lightGatesFrom(self.element.element,a,b.flag)
else
g.lightGates(self.element.element,a,0,1)
end
end

function d:regate()self:light()end



function d:read(c)
local a=b[self.unit]
if a.state~=self.state then
self.state=a.state
self.element:setState(a.state)
end
self:feed()
self:light()
if not c then return end
local a=a.play
if a.getsInterrupted then self.element:moment("getsInterrupted")end
if a.isCancelled then self.element:moment("isCancelled")end
if a.finishes then self.element:moment("finishes")end
if a.failed then self.element:moment("failed")end
if a.starts then self.element:moment("starts")end
end

local function m(b,c)
for a in pairs(h)do
if a.unit==b.unit then g.try(a,a.read,c)end
end
end


local k=false
local i
local function t()
local c=false
for b,a in pairs(b)do
if a.heldUntil then
if GetTime()>=a.heldUntil then i(a)else c=true end
end
end
if not c and k then
k=false
l.unsubscribe(0.1,"cast hold")
end
end






function i(a)
local b,d=a.seen,a.play
local f=a.state

if a.absent and not g.unitPresent(a.unit)then
a.state,a.heldUntil,a.duration,a.flag,a.guid="none",nil,false,false,nil
b.start,b.interrupt,b.failed,a.retargeted=nil,nil,nil,nil
b.cancel,b.finish,b.finishLate=nil,nil,nil
a.finishing,a.endedGuid,a.endedAt=nil,nil,nil
d.getsInterrupted,d.failed,d.starts=nil,nil,nil
d.isCancelled,d.finishes=nil,nil
m(a,true)
return
end
local e,p,u,v,i=p(a)
local g=a.retargeted or q.isQuiet(nil)
local h=b.interrupt and not a.retargeted and(f=="casting"or f=="channelling"or b.start)
and(e==nil or b.start)
d.getsInterrupted=h and not g or nil
d.failed=b.failed and not h and not g or nil
d.starts=e~=nil and b.start and not g or nil


local n=(f=="casting"or f=="channelling"or b.start)and(e==nil or b.start)

d.isCancelled=b.cancel and n and not h and not b.failed and not g or nil


local o=not h and not b.cancel and not b.failed
if b.finish and e~=nil and not b.start then a.finishing=true end
local n=(b.finish or a.finishing)and f=="casting"and n and o
d.finishes=(n or b.finishLate)and not g or nil
if e==nil or b.start then a.finishing=nil end

a.endedGuid,a.endedAt=nil,nil
if f=="casting"and e==nil and o and not n and not b.finishLate and a.unit=="player"then
a.endedGuid,a.endedAt=a.guid,GetTime()
end
if e then
a.state,a.heldUntil=e,nil
a.duration=s(a,e)
a.name,a.icon,a.flag=j(p),j(u),j(v)
if a.unit=="player"and type(i)=="string"and not c.isSecret(i)then a.guid=i end
else
if h then
a.state,a.heldUntil="interrupted",GetTime()+r
elseif not(f=="interrupted"and a.heldUntil and GetTime()<a.heldUntil)then
a.state,a.heldUntil="notCasting",nil
end
a.duration,a.flag,a.guid=false,false,nil
end
b.start,b.interrupt,b.failed,a.retargeted=nil,nil,nil,nil
b.cancel,b.finish,b.finishLate=nil,nil,nil
if a.heldUntil and not k then
k=true
l.subscribe(0.1,"cast hold",t)
end
m(a,true)
end
f.settle=i


local function j(a,b)
return a.unit=="player"and a.guid~=nil and type(b)=="string"and not c.isSecret(b)and b==a.guid
end


local function k(a,b)
return a.unit=="player"and a.guid~=nil and type(b)=="string"and not c.isSecret(b)and b~=a.guid
end





local function l(a)
return c.isSecret(a)or a~=nil
end

local m={UNIT_SPELLCAST_START=true,UNIT_SPELLCAST_CHANNEL_START=true}
local q=0.5

local function p(f,g,d,a,h)
local a=b[g]
if not a then return end
local b=a.seen
if m[f]then
b.start=true
if g=="player"and type(d)=="string"and not c.isSecret(d)then a.guid=d end
elseif f=="UNIT_SPELLCAST_INTERRUPTED"then
if l(h)then
if not k(a,d)then b.interrupt=true end
elseif j(a,d)then
b.cancel=true
end
elseif f=="UNIT_SPELLCAST_SUCCEEDED"then


if j(a,d)then
b.finish=true
elseif g=="player"and a.endedGuid~=nil and type(d)=="string"and not c.isSecret(d)
and d==a.endedGuid and GetTime()-a.endedAt<=q then
b.finishLate=true
else
return
end
elseif f=="UNIT_SPELLCAST_CHANNEL_STOP"then
if l(h)and not k(a,d)then b.interrupt=true end
elseif f=="UNIT_SPELLCAST_FAILED"then
if j(a,d)then b.failed=true end
end
e.atFrameEnd(a.key,i,a)
end
f.onCast=p

local q={"UNIT_SPELLCAST_START","UNIT_SPELLCAST_STOP","UNIT_SPELLCAST_INTERRUPTED","UNIT_SPELLCAST_FAILED",
"UNIT_SPELLCAST_SUCCEEDED",
"UNIT_SPELLCAST_DELAYED","UNIT_SPELLCAST_CHANNEL_START","UNIT_SPELLCAST_CHANNEL_UPDATE",
"UNIT_SPELLCAST_CHANNEL_STOP","UNIT_SPELLCAST_INTERRUPTIBLE","UNIT_SPELLCAST_NOT_INTERRUPTIBLE"}





local r={PLAYER_TARGET_CHANGED="changed",PLAYER_TARGET_DIED="died",PLAYER_FOCUS_CHANGED="changed",
UNIT_PET="changed",PET_UI_UPDATE="reread"}

local function k(a,b)
a.dead=b
a.retargeted,a.heldUntil,a.seen.start,a.seen.interrupt=true,nil,nil,nil
if a.state=="interrupted"then a.state="notCasting"end
if next(h)==nil then return end
e.atFrameEnd(a.key,i,a)
end










local l={target=true,focus=true}
local s={"UNIT_HEALTH","UNIT_FLAGS"}

local j={}

local function m(a)
local b,a=c.try("UnitIsDead",UnitIsDead,a)
if not b or c.isSecret(a)then return nil end
return a==true
end

local function c(a)
local b,c=m(a.unit),a.told
a.told=nil
if b==true and not a.dead then
k(a,true)
elseif b==false and a.dead and not c then
k(a,false)
end
end
local function t(a,d)
local a=b[d]
if not a then return end
if m(d)==true and not a.dead then k(a,true)end
e.atFrameEnd(a.deathKey,c,a)
end

local function u()
for d in pairs(l)do
local a=b[d]
if a and j[d]then e.atFrameEnd(a.deathKey,c,a)end
end
end
a.experimental("the target's and your focus target's death read from UnitIsDead (plain by the docs) at its own"
.." UNIT_HEALTH and UNIT_FLAGS, at once and again at the frame's end, ending its cast as PLAYER_TARGET_DIED does;"
.." a plainly alive read at the frame's end clearing it, never in the frame of a PLAYER_TARGET_DIED (UN-22, UN-4:"
.." which events come at a death and when the flag is set, unread: EP-73)","I")
a.experimental("UNIT_DIED as a trigger alone: the target's and your focus target's UnitIsDead read again at the"
.." frame's end, its secret GUID never read; registered only where C_EventUtils.IsEventValid knows it (the docs"
.." list it, 70755; whether it comes at a mob's death unread: EP-73)","I")


local function v(d,a)
local b,a=r[a],b[d]
if not b or not a then return end
if b=="reread"then
if next(h)~=nil then e.atFrameEnd(a.key,i,a)end
return
end
k(a,b=="died")
if b=="died"and l[d]then
a.told=true
e.atFrameEnd(a.deathKey,c,a)
end
end


local function a(a,b)
if(j[a]or false)==b then return end
j[a]=b
local c=o(a).key
if b then n.onChange(a,"cast source",v)end
for f,d in ipairs(q)do
if b then e.onUnit(d,a,c,p)else e.offUnit(d,c)end
end
if not l[a]then return end
for f,d in ipairs(s)do
if b then e.onUnit(d,a,c,t)else e.offUnit(d,c)end
end
if b then
e.on("UNIT_DIED","cast source",u)
elseif not(j.target or j.focus)then
e.off("UNIT_DIED","cast source")
end
end


function f.build(c,a,e,b)
if b then b:release()end
local d=setmetatable({element=c,view=e,rig=a,unit=a.unit,data={}},d)
o(a.unit)
g.plainBuild(d,c,a,b)
return d
end

function d:paint()
g.plainPaint(self)
end


function d:start()
local c=self.unit
local d=true
for a in pairs(h)do
if a.unit==c then d=false end
end
h[self]=true
if d then
a(c,true)
local a=b[c]
a.seen.start,a.seen.interrupt,a.seen.failed=nil,nil,nil
a.retargeted=true

if l[c]then a.dead,a.told=m(c)==true,nil end
i(a)
end
self.state=nil
self:read(false)
end

function d:stop()
h[self]=nil
for a in pairs(h)do
if a.unit==self.unit then return end
end
a(self.unit,false)
end

function d:release()
self:stop()
self.host:Hide()
end

function d:refeed()
if h[self]then self:feed()end
end

function d:describe()
local a=b[self.unit]
return string.format("cast %s: %s%s",self.unit,tostring(self.state),
a.heldUntil and string.format(", held %.1f s more",math.max(0,a.heldUntil-GetTime()))or"")
end

f.live=h
