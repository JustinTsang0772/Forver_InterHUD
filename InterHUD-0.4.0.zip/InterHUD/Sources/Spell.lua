

local b,a=...



local b={a.Sources.spellsField("Spells","Spell IDs sharing one cooldown.")}
local function c(b,a)return a~=nil and type(a.spells)=="table"and#a.spells>1 end
b[#b+1]={name="shownSpell",type="choice",choices={"firstKnown","lastCast","chosen"},
default="firstKnown",labels={firstKnown="First known",lastCast="Last cast",chosen="Chosen"},
label="Shown spell",help="Which one's icon, range and cost it shows.",shownIf=c,


pickSpell={value="chosen",field="chosen"}}
b[#b+1]={name="chosen",type="spell",under={"shownSpell","chosen"},label="Spell",
shownIf=function()return false end}





local c={label="Soon",holds="The spell's cooldown is almost over.",read="gate",within="coolingDown",max=1,
setting={{name="seconds",type="number",default=5,min=0.5,max=30,step=0.5,unit="s",
label="Seconds"}},
default=function()return{}end}





local d={label="Usable",read="lua",max=1,together=true,
holds="The game lets you use the spell now, whether or not it is on cooldown; short of power counts as usable"
.." unless “Not while short of power” is on.",
setting={
{name="needsPower",type="boolean",default=false,label="Not while short of power",
help="Counts the spell as usable only once you can pay its cost."},
},
default=function()return{}end}



local e={label="Queued",read="lua",
holds="You have pressed the spell and it is queued for your next swing, for spells like Heroic Strike and Raptor"
.." Strike."}
local c,d=a.Sources.facts({order={"soon","usable","queued"},
facts={soon=c,usable=d,queued=e}},
"pressed","notUsable","notEnoughPower","outOfRange")

a.Sources.register("spell",{
fields=b,
idWord="spell",
target={field="spells",pick="Pick its spell."},

picks={data="spell",fits=function(a)return a.kind~="item"and a.watch.cast==true end},
variantOrder={"spell"},
variants={
spell={

add={label="Spell",note="Its cooldown, range and cost"},
noun="a spell",


read="lua",moment="plain",
stateOrder={"ready","coolingDown"},
states={
ready={label="Ready",holds="The spell is ready to cast (only the global cooldown may be left)."},
coolingDown={label="Cooling down",holds="The spell is on cooldown."},
},
factOrder=c,facts=d,


eventOrder={"comesReady","reset","cast"},
events={
comesReady={label="Comes ready",holds="its cooldown ends",begins="ready"},
reset={label="Reset",holds="its cooldown ends early",begins="ready"},
cast={label="Cast",holds="you cast it",begins="coolingDown",orBegins="ready"},
},
},
},
})

a.Sources.takesExact("spell")



local g,d,o,m,f,h,q,e,r,s=a.Events,a.Spells,a.Layers,a.Combat,a.Debug,a.Schema,
a.Pressed,a.Sources,a.Ticker,a.Resolve
local c=a.Sources.get("spell")

c.countdownGates=true


function c.matches(a)
local c,b=d.family(a)
local a={[a]=true}
if not b then return a end
a[c]=true
for c,b in ipairs({b.ranks or{},b.copies or{}})do
for c,b in ipairs(b)do a[b]=true end
end
return a
end








function c.noCooldown(b)
local b=d.listOf(type(b)=="table"and b.spells or nil)
if#b==0 then return false end
for b,c in ipairs(b)do
local d,b=d.family(c)
if not b or b.kind~="spell"or b.cooldown~=nil then return false end

if GetSpellBaseCooldown then
local c,b=a.try("GetSpellBaseCooldown",GetSpellBaseCooldown,c)
if not c or a.isSecret(b)or b~=0 then return false end
end
end
return true
end
f.experimental("a spell with no cooldown known by the client's base cooldown reading 0 (CD-19 read one with a"
.." cooldown; in doubt its states are offered), and a school lockout's read on one (unrecorded)","I")
local i,j={coolingDown=true},{sweep=true,time=true}
local k={comesReady=true,reset=true}
local b=h.source("spell")
function b.offersState(a,b)
return not(i[b]and c.noCooldown(a))
end
function b.offersPart(a,b)
return not(j[b]and c.noCooldown(a))
end
function b.offersEvent(a,b)
return not(k[b]and c.noCooldown(a))
end



function c.sampleCooldown(b)
local a
for c,b in ipairs(d.listOf(b.source.spells))do
local c,b=d.family(b)
local b=b and b.cooldown
if type(b)=="number"and b>0 and(not a or b>a)then a=b end
end
return a
end





function c.learned(a)

local c=e.exactSet(a.exact)
for b,a in ipairs(d.listOf(a.spells))do
local e,b=d.family(a)
if c and c[a]or b and(b.kind=="passive"or b.pet)then
if d.knowsAtLeast(a)then return true end
elseif d.known(a)then
return true
end
end
return false
end


function c.yourSpells(a)return d.listOf(a.spells)end



function c.shownSpell(c)
local b=d.listOf(c.spells)
if#b<2 then return b[1]end
if c.shownSpell=="chosen"then
for b,a in ipairs(b)do
if a==c.chosen then return a end
end
elseif c.shownSpell=="lastCast"then
local a=a.LastSeen.get(b)
if a then return a end
end
for b,a in ipairs(b)do
if d.known(a)then return a end
end
return b[1]
end


h.rule("source","chosen spell",function(a,c,b)
if a.kind~="spell"or a.shownSpell~="chosen"then return end
for c,b in ipairs(d.listOf(a.spells))do
if b==a.chosen then return end
end
c:problem((b==""and""or b..".").."chosen",a.chosen==nil and"is missing: Chosen needs its"
.." spell."or"isn't one of its spells; pick one of the list.",function()
a.shownSpell,a.chosen=nil,nil
end)
end)


local k=a.game=="retail"and 61304 or 29515
if a.game=="retail"then f.experimental("the global cooldown read from spell 61304 on Retail (EllesmereUI's GCD_SPELL)","C")end
f.experimental("Ready's arming-GCD guard: a tracker fed the GCD at the arm while the GCD runs (the game's own GCD timing, CD-21)","I")
f.experimental("Soon: a gate whose alpha a curve on the cooldown's ignore-GCD duration sets, polled every 0.1 s"
.." while it cools (FR-3, CD-5, CD-17's route, this build of it unplayed)","I")
f.experimental("the GCD sweep from the spell's GCD-inclusive duration on a gcd read (CD-1, CD-3)","I")
f.experimental("a list member's cast arming at the first own read in its GCD, where the cast event's read isn't own"
.." (a shared cooldown's read there unrecorded: ihud-shocks' shared, ihud-fixes' shared)","I")



local function l(b)
local c,b=a.try("GetSpellCooldown",C_Spell.GetSpellCooldown,b)
if not c or type(b)~="table"then return nil end
local c=b.isActive
if a.isSecret(c)or c==nil then return nil end
if c==false then return"ready"end
local b=b.isOnGCD
if a.isSecret(b)then return nil end
return b==true and"gcd"or"own"
end
c.readOf=l

local function j(b,c)
local b,a=a.try("GetSpellCooldownDuration",C_Spell.GetSpellCooldownDuration,b,c)
if b and a then return a end
return false
end


local function t(b)
if not b then return false end
local c,b=pcall(b.IsZero,b)
if not c or a.isSecret(b)then return nil end
return b==false
end


local function n()
local c,b=a.try("GetSpellCooldown GCD",C_Spell.GetSpellCooldown,k)
return c and type(b)=="table"and not a.isSecret(b.isActive)and b.isActive==true
end




local b=CreateFrame("Frame")
b:SetSize(1,1)
b:SetPoint("TOPLEFT")
b:SetAlpha(0)

local function p(c)
local a=CreateFrame("Cooldown",nil,b,"CooldownFrameTemplate")
a:SetAllPoints()
a:SetDrawSwipe(false)
a:SetDrawEdge(false)
a:SetDrawBling(false)
a:SetHideCountdownNumbers(true)
a.running=false
a:SetScript("OnCooldownDone",function(a)
a.running=false
c()
end)
return a
end



local function h(a,b)
if not b then
a:Clear()
a.running=false
return
end
a:SetCooldownFromDurationObject(b,true)
a.running=true
end


local i={}

local b={}
b.__index=b



function b:memberOf(b)
if b==nil or a.isSecret(b)then return nil end
if b==self.id then return self.spell end
local c,e=d.family(b),self.exact
for f,a in ipairs(self.list)do
if b==a or(c~=nil and not(e and e[a])and c==d.family(a))then return a end
end
end


function b:names(a)
return self:memberOf(a)~=nil
end



function b:inArmingGCD()
return self.guard.running
end






function b:arm(a,b)
self.armed,self.armedBy,self.armedAt,self.armedAtRead=true,a,GetTime(),b or false
self.turnPending,self.resetPending,self.namedThisFrame,self.castPending=false,false,false,false

self.guardArmed=false
h(self.ready,j(self.id,true))
h(self.guard,n()and j(k,false)or false)
end

function b:setState(a)
if self.state==a then return end
self.state=a
self.element:setState(a)
self:soon()

if self.rig.usable then c.repollUsable()end
end



function b:comesReady(a)
self.armed,self.turnPending,self.resetPending,self.namedThisFrame=false,false,false,false
if not self.castPending then h(self.guard,false)end
self.lastMoment,self.lastMomentAt=a,GetTime()
self:setState("ready")
self:feedLayers(self.lastRead)
self.element:moment(a)
end


local function u(a)
if a.armed and a.ready.running and(a.turnPending or a.resetPending)then
a:comesReady(a.namedThisFrame and a.resetPending and"reset"or"comesReady")
end
a.turnPending,a.resetPending,a.namedThisFrame=false,false,false
end



function b:onCooldownEvent(b)
local a=l(self.id)
self.lastRead=a
local b=self:names(b)
if a=="own"then
h(self.stateTracker,j(self.id,true))


if not self.armed or self.castPending then
self:setState("coolingDown")
self:arm(self.castPending and"cast"or"read",self.castPending)
end
elseif a=="gcd"or a=="ready"then
if not self.armed then
self:setState("ready")
elseif self.ready.running and not self:inArmingGCD()then
if b then
self.namedThisFrame,self.resetPending=true,true
elseif self.armedBy~="read"then


self.turnPending=true
end
if self.turnPending or self.resetPending then g.atFrameEnd(self.frameKey,u,self)end
end
end
self:feedLayers(a)
end



function b:onCast(a)
local a=self:memberOf(a)
if not a then return end

if self.view.source.shownSpell=="lastCast"then self:show(a)end
if l(self.id)=="own"then
self:setState("coolingDown")



self:arm("cast")
else




self.castPending=true
local a=n()and j(k,false)
if a then
h(self.guard,a)
else
g.atFrameEnd(self.castKey,b.endCastWindow,self)
end
end

self.element:moment("cast")
end


function b:endCastWindow()
self.castPending=false
end



function b:onGuardEnd()
self.castPending=false
if self.armed and l(self.id)=="ready"then self:comesReady("comesReady")end
end



function b:feedLayers(b)
local a=self.data

a.duration=self.state~="ready"and j(self.id,true)or false
a.gcd=b=="gcd"and j(self.id,false)or false
self.element:feed(a)
self:soon()
end






local n={}
local function k()
for a in pairs(n)do a:light()end
end
function b:light()
local c=self.rig.soonKey
if not(c and self.curve)then return end
local d,f=0,1
local b=i[self]and self.state=="coolingDown"and self.data.duration
if b then
local c,e=a.try("soon curve",b.EvaluateRemainingDuration,b,self.curve)
local a,b=a.try("soon curve",b.EvaluateRemainingDuration,b,self.offCurve)
if c and a then d,f=e,b end
end
e.lightGates(self.element.element,c,d,f)
end
function b:poll(a)
if(n[self]~=nil)==a then return end
n[self]=a or nil
if a then
r.subscribe(0.1,"soon",k)
elseif not next(n)then
r.unsubscribe(0.1,"soon")
end
end

function b:soon()
if not(self.rig.soonKey and self.curve)then return end
self:poll(i[self]==true and self.state=="coolingDown"and e.usesGate(self.element.element,self.rig.soonKey))
self:light()
end


function b:regate()self:soon()end


function b:paint()
e.plainPaint(self)
end



















f.experimental("Out of range from SPELL_RANGE_CHECK_UPDATE after EnableSpellRangeCheck, armed again at each target"
.." change (UN-7, UN-16: InterHUD's tint at rest and in combat, 70425; another source's at rest and in combat,"
.." ihud-modifiers 70450; a check switched on in combat unrecorded)","T")
f.experimental("Not enough power and Not usable from IsSpellUsable at SPELL_UPDATE_USABLE, the player's power"
.." updates, a stance change and combat's edges (CD-8, UN-15; Earth Shock's mana seen, ihud-modifiers 70450; the"
.." usable event at every flip, T 70862)","T")


local function f(b)
if not C_Spell.SpellHasRange then return true end
local c,b=a.try("SpellHasRange",C_Spell.SpellHasRange,b)
if not c or a.isSecret(b)then return true end
return b==true
end


function c.anyRanged(a)
local a=d.listOf(a)
if#a==0 then return true end
for b,a in ipairs(a)do
if f(d.highest(a)or a)then return true end
end
return false
end

local function r(b)
if not f(b)then return false end
a.try("EnableSpellRangeCheck",C_Spell.EnableSpellRangeCheck,b,true)
return true
end

local k={}
local f={}

function f:tellFacts(b)
local a,c=self.rig.watch,self.element
if not a then return end
if a.outOfRange then c:setFact("outOfRange",self.outOfRange==true,b)end
if a.notEnoughPower then c:setFact("notEnoughPower",self.noPower==true,b)end
if a.notUsable then c:setFact("notUsable",self.unusable==true,b)end
if a.usable and self.rig.usable then c:setFact(self.rig.usable.id,self.usableNow==true,b)end
if a.queued then c:setFact("queued",self.queuedNow==true,b)end
end
function f:readQueued()
if self.id==nil then return end
local c,b=a.try("IsCurrentSpell",C_Spell.IsCurrentSpell,self.id)
if not c or a.isSecret(b)then return end
self.queuedNow=b==true
end

function f:readRange()
if self.id==nil then return end
local c,b=a.try("IsSpellInRange",C_Spell.IsSpellInRange,self.id,"target")
if not c or a.isSecret(b)then return end
self.outOfRange=b==false
end
function f:readUsable()
if self.id==nil then return end
local d,c,b=a.try("IsSpellUsable",C_Spell.IsSpellUsable,self.id)
if not d or a.isSecret(c)or a.isSecret(b)then return end
self.noPower=b==true

self.unusable=c==false and b~=true

local a=self.rig.usable
if a then
local a=c==true or(b==true and not a.needsPower)

if self.usableNow~=nil and a~=self.usableNow then self.usableFlips=(self.usableFlips or 0)+1 end
self.usableNow=a
end
end


function f:watchFacts()
k[self]=true
local a=self.rig.watch
if not a then return end
if a.outOfRange then
self.ranged=self.ranged or{}
for b,a in ipairs(self.list)do
local a=self.exact and self.exact[a]and a or d.highest(a)or a
if self.ranged[a]==nil then self.ranged[a]=r(a)end
end
self.rangeArmed=self.ranged[self.id]and self.id or nil
if self.rangeArmed then self:readRange()end
end
if a.notEnoughPower or a.notUsable or a.usable then self:readUsable()end
if a.pressed then q.start()end
if a.queued then self:readQueued()end
self:tellFacts(false)
end

function f:unwatchFacts()
k[self]=nil
self.rangeArmed,self.ranged=nil,nil
self.outOfRange,self.noPower,self.unusable,self.usableNow,self.queuedNow=nil,nil,nil,nil,nil
end

function f:reshowFacts()
local a=self.rig.watch
if not a then return end
if self.ranged then
self.rangeArmed=self.ranged[self.id]and self.id or nil
self.outOfRange=nil
if self.rangeArmed then self:readRange()end
end
if a.notEnoughPower or a.notUsable or a.usable then self:readUsable()end
if a.queued then self:readQueued()end
self:tellFacts(true)
end



function f:rearmFacts()
if m.inCombat()then self.rearm=true else self:watchFacts()end
end

local r={"outOfRange","notEnoughPower","notUsable","usable","pressed","queued"}
function f:describeFacts()
local b={}
for c,a in ipairs(r)do
if self.rig.watch and self.rig.watch[a]then
local c=(a=="outOfRange"and self.outOfRange)or(a=="notEnoughPower"and self.noPower)
or(a=="notUsable"and self.unusable)or(a=="usable"and self.usableNow)or(a=="pressed"and self.held)
or(a=="queued"and self.queuedNow)
b[#b+1]=a..(c and" holds"or" no")
end
end
return b
end

function f:pressed(a)
if not(self.rig.watch and self.rig.watch.pressed)then return end
self.held=a or nil
self.element:setFact("pressed",a,true)
end
for a,c in pairs(f)do b[a]=c end



local function f(a,b,c,d)
if a.rangeArmed==b then
a.outOfRange=d==true and c==false
a:tellFacts(true)
end
end
g.on("SPELL_RANGE_CHECK_UPDATE","spell facts",function(g,b,c,d)
if a.isSecret(b)or a.isSecret(c)or a.isSecret(d)then return end
for a in pairs(k)do e.try(a,f,b,c,d)end
end)


local function f(b)
local c=b.rig.watch
local c=c and(c.notEnoughPower or c.notUsable or c.usable)
if b.rangeArmed then
a.try("EnableSpellRangeCheck",C_Spell.EnableSpellRangeCheck,b.rangeArmed,true)
b:readRange()
end
if c then b:readUsable()end
if b.rangeArmed or c then b:tellFacts(true)end
end
a.Target.onChange("spell facts",function()
for a in pairs(k)do e.try(a,f)end
end)
local function r(a)
a:readUsable()
a:tellFacts(true)
end

local function f()
for b in pairs(k)do
local a=b.rig.watch
if a and(a.notEnoughPower or a.notUsable or a.usable)then e.try(b,r)end
end
end
g.on("SPELL_UPDATE_USABLE","spell facts",f)
g.on("UPDATE_SHAPESHIFT_FORM","spell facts",f)
g.onUnit("UNIT_POWER_UPDATE","player","spell facts",f)
m.onStart("spell facts usable",f)
m.onEnd("spell facts usable",f)


a.Debug.experimental("Queued read at CURRENT_SPELL_CAST_CHANGED by the known rank (CA-17: T 70374 on a warrior's"
.." Heroic Strike, 9 spent and 6 cancelled; Cleave, Maul and Raptor Strike unseen; a queue dropped with the target"
.." read again at the target's change)","T")
local function r(a)
a:readQueued()
a:tellFacts(true)
end
local function f()
for a in pairs(k)do
local b=a.rig.watch
if b and b.queued then e.try(a,r)end
end
end
g.on("CURRENT_SPELL_CAST_CHANGED","spell facts",f)
a.Target.onChange("spell facts queued",f)
local function f(a)
a.rearm=nil
a:watchFacts()
end
m.onEnd("spell facts range",function()
for a in pairs(k)do
if a.rearm then e.try(a,f)end
end
end)




function c.plan(d)
local b=d.source
local a={kind="spell",spells=b.spells,exact=b.exact,parts=o.allParts(d,nil)}
e.planCopies(d,a)
local f=e.firstItem(b,"soon")
if f then a.soon,a.soonKey=f.seconds,b.id.."."..f.id end
c.coloursOf(d,a)
a.watch=e.usedFacts(d,{"outOfRange","notEnoughPower","notUsable","pressed","usable","queued"})


local d=a.watch and a.watch.usable and e.firstItem(b,"usable")
if d then a.usable={id=d.id,needsPower=d.needsPower==true}end

c.keepUsable(b,d and d.id or false)
return a
end




function c.coloursOf(e,b)
for c,a in ipairs(b.parts)do
local d=a.kind=="icon"and not a.effect and not a.partKey and b.formatter[a.layer]
local c
if d and b.soon then
local a=e.layers[a.layer]
local a=s.lookAt(a,function(a)return a==d end)
c=type(a.time)=="table"and a.time.colour or nil
end
a.colours=c and{at=b.soon,colour=c}or nil
end
end


function b:rekey()
local a,b
if not(self.exact and self.exact[self.spell])then a,b=d.highest(self.spell)end
self.id=a or self.spell
self.data.icon=b or d.icon(self.spell)
self.data.name=d.label(self.id)
end




function b:show(a)
if a==nil or a==self.spell then return end
self.spell=a
self:rekey()
if not i[self]then return end
self:feedLayers(self.lastRead)
self:reshowFacts()
end



function c.build(g,f,h,i)
if i then i:release()end
local b=setmetatable({element=g,view=h,rig=f,list=d.listOf(h.source.spells),
exact=a.Sources.exactSet(h.source.exact),spell=c.shownSpell(h.source),data={},
frameKey="cd "..g.id,
castKey="cd cast "..g.id,castPending=false},b)
b:rekey()
e.plainBuild(b,g,f,i)
local a=b.frames

a.owner=b
if not a.ready then
a.ready=p(function()
local a=a.owner
if a.armed then a:comesReady("comesReady")end
end)
a.guard=p(function()a.owner:onGuardEnd()end)

a.stateTracker=p(function()
local a=a.owner
if not a.armed then
a:setState("ready")
a:feedLayers("ready")
end
end)
end
b.ready,b.guard,b.stateTracker=a.ready,a.guard,a.stateTracker


b.curve=f.soon and o.lastCurve(f.soon)or nil
b.offCurve=f.soon and o.lastCurve(f.soon,false,true)or nil
return b
end


q.serve("spell",i)




function b:start()
i[self]=true
if#self.list>1 and self.view.source.shownSpell=="lastCast"then
a.LastSeen.watch(self.element.id,self.list,nil,self.view.source.exact)
end
local a=l(self.id)
self.lastRead=a
self.state=nil
self:setState(a=="own"and"coolingDown"or"ready")
if a=="own"then
local a=j(self.id,true)
if not m.inCombat()and t(a)then
h(self.stateTracker,a)
self:arm("load")
end
end
self:feedLayers(a)
self:watchFacts()
c.pollUsable(self,true)
end

function b:stop()
i[self]=nil
self:soon()
a.LastSeen.unwatch(self.element.id)
h(self.ready,false)
h(self.guard,false)
h(self.stateTracker,false)
self.armed,self.castPending=false,false
self:unwatchFacts()
c.pollUsable(self,false)
end


function b:refeed()
self:show(c.shownSpell(self.view.source))
self:feedLayers(self.lastRead)
end

function b:release()
self:stop()
self.host:Hide()
end


function b:respell()
local a=self.id

self.spell=c.shownSpell(self.view.source)
self:rekey()
if self.id~=a then self:feedLayers(l(self.id))end

self:rearmFacts()
end

function b:describe()
local b=self:describeFacts()
local d=#self.list>1 and(" of "..#self.list.." ("..tostring(self.view.source.shownSpell)..")")or""

local a=self.armedBy and(tostring(self.armedBy)..(self.armedBy=="cast"
and(self.armedAtRead and", at its frame's read"or", at its cast event")or""))
return string.format("spell %s%s, %s, %s%s, last %s%s%s%s",tostring(self.id),d,tostring(self.state),
self.armed and("armed by "..a)or((self.castPending and"unarmed, a cast pending"or"unarmed")
..(a and(" (last armed by "..a..")")or"")),self.guard.running and", in its GCD"or"",
tostring(self.lastMoment),self.lastMomentAt and string.format(" at %.1f",self.lastMomentAt)or"",
self.curve and string.format(", Soon in the last %s s%s",tostring(self.rig.soon),
n[self]and" (polled)"or"")or"",
#b>0 and("; "..table.concat(b,", "))or"")..c.describeUsable(self)
end


g.on("SPELL_UPDATE_COOLDOWN","cooldown source",function(a,b)
for a in pairs(i)do e.try(a,a.onCooldownEvent,b)end
end)
g.onUnit("UNIT_SPELLCAST_SUCCEEDED","player","cooldown source",function(a,c,d,b)
for a in pairs(i)do e.try(a,a.onCast,b)end
end)

c.live=i
