



local b,a=...
local d,e,i,h=a.Events,a.Combat,a.Store,a.Spells

local b={}
a.LastSeen=b

local j=200

local c={}
local f=a.keyed("last seen")
function b.onChange(a,b)f:add(a,b)end


function b.keyOf(b)
local a={}
for b,c in ipairs(b)do a[b]=c end
table.sort(a)
for b,c in ipairs(a)do a[b]=tostring(c)end
return table.concat(a,",")
end

local function g()
local a=i.char()
if not a then return nil end
a.lastSeen=a.lastSeen or{}
return a.lastSeen
end


function b.get(a)
local c=b.keyOf(a)
for d,b in ipairs(g()or{})do
if b.key==c then
for c,a in ipairs(a)do
if a==b.spell then return a end
end
end
end
end

local function i(d,c)
local a=g()
if not a then return false end
local b=b.keyOf(d)
for e,d in ipairs(a)do
if d.key==b then
if d.spell==c then return false end
table.remove(a,e)
break
end
end
a[#a+1]={key=b,spell=c}
if#a>j then table.remove(a,1)end
return true
end




local function g()
if e.inCombat()or e.aurasSecret()or not(C_UnitAuras and C_UnitAuras.GetPlayerAuraBySpellID)then return end
local g=a.Sources.get("aura")
local d=false
for c,b in pairs(c)do
if b.unit=="player"then
for e,c in ipairs(b.list)do
local e=false
for b in pairs(g.ownIds(c,"player",b.exactList))do
local c,b=a.try("last seen read",C_UnitAuras.GetPlayerAuraBySpellID,b)
if c and b~=nil and not a.isSecret(b)then e=true end
end
if e then
if i(b.list,c)then d=true end
break
end
end
end
end
if d then f:call()end
end



local function j(d,e,g,b)
if type(b)~="number"or a.isSecret(b)then return end
local e=h.family(b)or b
local d=false
for a,c in pairs(c)do
for f,a in ipairs(c.list)do
if a==b or not(c.exact and c.exact[a])and(h.family(a)or a)==e then
if i(c.list,a)then d=true end
break
end
end
end
if d then f:call()end
end


function b.watch(e,f,h,b)
c[e]={list=f,unit=h,exactList=b,exact=a.Sources.exactSet(b)}
d.atFrameEnd("last seen read",g)
end
function b.unwatch(a)c[a]=nil end

d.onUnit("UNIT_AURA","player","last seen",g)
e.onEnd("last seen",g)
d.onUnit("UNIT_SPELLCAST_SUCCEEDED","player","last seen",j)

