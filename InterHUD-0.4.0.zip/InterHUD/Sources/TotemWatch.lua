
local a,b=...
local c,m,n,u,i,o=b.Events,b.Spells,b.Combat,b.Ticker,b.Debug,b.Layers

local a={}
b.Totems=a


a.SLOTS={fire=1,earth=2,water=3,air=4}
a.SLOT_ORDER={"earth","fire","water","air"}

local z=36936
local p=0.4
local E=0.1
local F=1.5
local G=1.5

i.experimental("each totem's slot from GetMultiCastTotemSpells, in combat too (no playbook row: documented plain;"
.." ShamanForever ships it)","D")
i.experimental("a totem named by your cast just after its slot's update, within 0.4 s (TO-5 records the pair, not"
.." that order)","I")
i.experimental("a loading screen's silent empty: the slots read at PLAYER_ENTERING_WORLD, no end told"
.." (ShamanForever's note)","I")
i.experimental("a flight path's ends told as usual (the totem bar is exempt from the can't-act rule): whether one"
.." ends every totem at take-off (ShamanForever's note, no playbook row)","I")
i.experimental("Totemic Recall's ends filtered by its cast seen within 0.1 s of its slots emptying (TO-9: Recall's"
.." slot updates last logged on 70009)","T 70009")

local v,A={},{}
local w={{},{},{},{}}
local j=false
local e,h,d,k={},{},{},{}
local q={}
local r={}
local x
local s={}
local l={}
local y=0
local t,f={},false

local B=b.keyed("totems")










function a.onChange(a,b)B:add(a,b)end
local function g(a,b,c,d)B:call(a,b,c,d)end



function a.isDown(a)return e[a]==true end
function a.ownerOf(a)return d[a]end
function a.durationOf(a)return h[a]end
function a.spellsOf(b)
if not j then a.map()end
return w[b]or{}
end
function a.slotOf(c)
if type(c)~="number"or b.isSecret(c)then return nil end
if not j then a.map()end
return v[c]or A[m.family(c)or 0]
end





local B={
killedEarly=o.curve({0,0,1.2,0,1.25,1,36000,1},"Linear"),
ranOut=o.curve({0,1,1.2,1,1.25,0,36000,0},"Linear"),
}
function a.endCurve(a)return B[a]end







function a.pulseCopy(a)
local a=o.get("icon").create(a)
a.cd:Hide()
a.overlay:SetAlpha(0)
local c=a.overlay:CreateAnimationGroup()
c:SetLooping("BOUNCE")
local b=c:CreateAnimation("Alpha")
b:SetFromAlpha(0)
b:SetToAlpha(0.55)
b:SetDuration(0.6)
b:SetSmoothing("IN_OUT")
a.pulse=c
return a
end
function a.applyPulse(b,a,c,d)
o.get("icon").apply(b,{desaturated=true,overlay=a.overlay~=false,overlayColour="#000000",
sweep={enabled=false},time={enabled=false},framedBy=a.framedBy,scale=a.scale},c,d)
b.overlay:SetAlpha(0)
end

local function o()return GetTime()<y end



local function B()return n.deadOrGhost()or o()end



function a.map()
if not GetMultiCastTotemSpells then return end
local e,f,d={},{},{}
for a=1,4 do
local c,g=b.try("GetMultiCastTotemSpells",function()return{GetMultiCastTotemSpells(a)}end)
d[a]={}
for g,c in ipairs(c and g or{})do
if type(c)=="number"and not b.isSecret(c)then
e[c]=a
local b=m.family(c)
if b then f[b]=a end
d[a][#d[a]+1]=c
end
end
end
v,A,w,j=e,f,d,true
end



local function A(a)
if n.inCombat()or(x and GetTime()-x<=p)then return nil end
local c,d,e,f,g,h,i,a=b.try("GetTotemInfo",GetTotemInfo,a)
if c and not b.isSecret(a)and type(a)=="number"and a>0 then return a end
end


local function o()
if next(l)then return true end
for a=1,4 do
if e[a]and d[a]==nil and not n.inCombat()then return true end
end
return false
end

local C
local function D()
if o()then u.subscribe(0.1,"totems",C)end
end


function C()
local f=GetTime()
for a,c in pairs(l)do
if f-c.at>=E then
l[a]=nil
local b,d=b.try("GetTotemDuration",GetTotemDuration,a)
local b=b and d~=nil
local d=s[a]and f-s[a]<F
if not b and not d and not c.quiet and not B()then
g(a,"ended",c.duration,c.owner)
end
end
end
for a=1,4 do
if e[a]and d[a]==nil and k[a]and f-k[a]>p then
local b=A(a)
if b then
d[a]=b
g(a,"owner",false)
end
end
end
if not o()then u.unsubscribe(0.1,"totems")end
end





local function o(a,f)

if not GetTotemDuration then return end
local c,b=b.try("GetTotemDuration",GetTotemDuration,a)
if not c then return end
local c=GetTime()
if b then
local j=h[a]
h[a]=b
q[a]=c
local h=r[a]
local i=h and c-h.at<=p
if not e[a]or i then
e[a]=true
k[a]=c
d[a]=i and h.spell or(not f and A(a))or nil
r[a]=nil

g(a,f and"placed"or"owner",false)
elseif b~=j then

g(a,"refilled",b)
end
elseif e[a]then
if f then
l[a]={at=c,duration=h[a],owner=d[a],quiet=B()}
end
local b=h[a]
e[a],h[a],d[a],k[a],q[a]=nil,nil,nil,nil,nil
g(a,"emptied",b)
end
D()
end



local function A(f,h,i,c)
if type(c)~="number"or b.isSecret(c)then return end
local b=GetTime()
if c==z or m.family(c)==z then
for a=1,4 do s[a]=b end
for a=1,4 do g(a,"dismissed")end
return
end
local a=a.slotOf(c)
if not a then return end
x=b
g(a,"cast",c)


r[a]={spell=c,at=b}
if e[a]and q[a]and b-q[a]<=p and d[a]~=c then
d[a]=c
k[a]=b
g(a,"owner",true)
end
end

local function p(c,a)
if type(a)=="number"and not b.isSecret(a)and a>=1 and a<=4 then
o(a,true)
else
for a=1,4 do o(a,true)end
end
end


if DestroyTotem then
hooksecurefunc("DestroyTotem",function(a)
if type(a)=="number"and not b.isSecret(a)and a>=1 and a<=4 then
s[a]=GetTime()

if f then g(a,"dismissed")end
end
end)
end


local function b()y=math.huge end
local function g()
y=GetTime()+G
for a=1,4 do o(a,false)end
end



function a.watch(d)
t[d]=true
if f then return end
f=true
c.on("PLAYER_TOTEM_UPDATE","totems",p)
c.onUnit("UNIT_SPELLCAST_SUCCEEDED","player","totems",A)
c.on("PLAYER_LEAVING_WORLD","totems",b)
c.on("PLAYER_ENTERING_WORLD","totems",g)
if not j then a.map()end
for a=1,4 do o(a,false)end
end


local function b()
if not f or next(t)then return end
f=false
c.off("PLAYER_TOTEM_UPDATE","totems")
c.offUnit("UNIT_SPELLCAST_SUCCEEDED","totems")
c.off("PLAYER_LEAVING_WORLD","totems")
c.off("PLAYER_ENTERING_WORLD","totems")
wipe(l)
for a=1,4 do e[a],h[a],d[a],k[a],r[a]=nil,nil,nil,nil,nil end
u.unsubscribe(0.1,"totems")
end
function a.unwatch(a)
t[a]=nil
if f and not next(t)then c.atFrameEnd("totems teardown",b)end
end


c.on("SPELLS_CHANGED","totems",function()
if f then c.atFrameEnd("totems map",a.map)else j=false end
end)
n.onEnd("totems",function()
if not f then return end
D()
end)


function a.describe()
if not f then return{}end
local b=0
for a in pairs(v)do b=b+1 end
local c={}
for b,f in ipairs(a.SLOT_ORDER)do
local a=a.SLOTS[f]
local b=d[a]
c[#c+1]=f.." "..(e[a]and("down, "..(b and(tostring(b).." "
..tostring(m.nameOf(b)))or"owner unknown"))or"empty").." ("..#(w[a]or{}).." known)"
end
return{string.format("totems: %d spells in the slot map%s",b,j and""or" (not read yet)"),
"  "..table.concat(c,"; ")}
end
i.register("totems",a.describe)
