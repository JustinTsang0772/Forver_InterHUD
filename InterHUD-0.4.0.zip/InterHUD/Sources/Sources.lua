

local a,b=...
local c=b.Schema

local a={}
b.Sources=a

local e={}






































function a.register(b,a)
assert(not e[b],"source kind registered twice: "..b)
e[b]=a

local d={}
for b,a in ipairs(a.fields)do d[#d+1]=a end
for b,a in ipairs(c.sourceFields())do d[#d+1]=a end
c.variant("source",b,d,{variantOf=a.variantOf})
for d,e in ipairs(a.variantOrder)do
local d=a.variants[e]
d.kind,d.layerKind=b,a.drawsAs or b
c.sourceVariant(e,d)
end
return a
end





a.FACTS={
pressed={label="Pressed",holds="You are holding down the spell's key.",read="lua",look={pressed={shown=true}}},
notUsable={label="Not usable",holds="The game won't let you cast the spell right now, for example in the wrong stance or in combat.",read="lua",
look="notUsable"},
notEnoughPower={label="Not enough power",holds="You don't have enough power to cast the spell.",read="lua",
look="notEnoughPower"},
outOfRange={label="Out of range",holds="Your target is out of the spell's range.",read="lua",look="outOfRange"},
}

function a.facts(c,...)
local b,d={},{}
for e,c in ipairs({...})do
b[#b+1]=c
d[c]=assert(a.FACTS[c],"no such fact: "..tostring(c))
end
for e,a in ipairs(c and c.order or{})do
b[#b+1]=a
d[a]=c.facts[a]
end
return b,d
end



function a.spellsField(a,b,d)
return{name="spells",type="spells",minItems=1,maxItems=d or c.MAX_SPELLS,unique=true,control="spells",
label=a or"Spells",help=b}
end





a.EXACT={name="exact",type="list",of="integer",item={min=1},minItems=1,maxItems=c.MAX_SPELLS,
unique=true,control="spells",label="Exact",shownIf=function()return false end}

function a.takesExact(b)
c.extendVariant("source",b,{a.EXACT})
for d,a in ipairs(c.sourceFields())do c.moveLast("source",b,a.name)end
end

function a.exactSet(a)
if type(a)~="table"or#a==0 then return nil end
local b={}
for c,a in ipairs(a)do b[a]=true end
return b
end

c.rule("source","exact",function(a,c,d)
if type(a.exact)~="table"then return end
local e,b={},{}
for b,a in ipairs(type(a.spells)=="table"and a.spells or{})do e[a]=true end
for f,a in ipairs(a.exact)do
if e[a]then
b[#b+1]=a
elseif c.mode=="import"then
c:note((d~=""and d.."."or"").."exact["..f.."]",a.." isn't one of its spells; left out.")
end
end
a.exact=#b>0 and b or nil
end)



function a.picksOf(a)
local a=e[a]
return a and rawget(a,"picks")or nil
end




function a.matchesOf(b,c)

local d=type(b)=="table"and e[b.kind]
local d=d and rawget(d,"matches")
if not d or type(c)~="number"then return nil end
local a=a.exactSet(b.exact)
if a and a[c]then return nil end
local a={}
for b in pairs(d(c,b)or{})do
if type(b)=="number"then a[#a+1]=b end
end
if#a==0 or#a==1 and a[1]==c then return nil end
table.sort(a)
return a
end


function a.oneRange(a,b,c)
local a=(a.atLeast and 1 or 0)+(a.atMost and 1 or 0)+(a.between and 1 or 0)
if a>1 then b:problem(c,"names more than one of atLeast, atMost and between; keep one.")end
end


function a.firstItem(a,b)
local a=type(a)=="table"and type(a.facts)=="table"and a.facts[b]
for b,a in ipairs(type(a)=="table"and a or{})do
if a.enabled~=false then return a end
end
end





function a.usedFacts(d,j)
local e=d.source
local g=b.Keys.compile(d)
local h={}
local function i(a)
for a in pairs(g:atomsOf(a).lua)do h[a]=true end
end
local function f(a)
for b,a in ipairs(b.Keys.asList(a))do i(a)end
end
for c,b in ipairs(d.layers or{})do
for a in pairs(a.restsOn(g,b).lua)do h[a]=true end
end
for b,a in ipairs(d.effects or{})do
f(a["while"])
f(a.unless)
end
f(d["while"])
f(d.unless)
for a in pairs(g.conds)do i(a)end
local d
local f=type(e.facts)=="table"and e.facts or{}
local g=c.variantOf(e)
for i,b in ipairs(j)do

local c=g and c.isListFact(g.facts[b])
local a=c and a.firstItem(e,b)or not c and type(f[b])=="table"and f[b]
local f=false
for b,a in pairs(a and type(a.events)=="table"and a.events or{})do
if type(a)=="table"and type(a.effects)=="table"and#a.effects>0 then f=true end
end
local e=e.id.."."..(c and a and a.id or b)
if(a or not c)and(not a or a.enabled~=false)and(h[e]or f)then
d=d or{}
d[b]=true
end
end
return d
end


a.UNSET_ICON=134400



function a.unset(a)
local b=type(a)=="table"and e[a.kind]
return b and b.target~=nil and a[b.target.field]==nil or false
end



function a.try(a,d,...)
local c=a.trySite
if not c then
c="source "..tostring(a.element and a.element.id)
a.trySite=c
end
return b.try(c,d,a,...)
end



local d=b.keyed("source data loaded")
function a.onDataLoaded(a,b)d:add(a,b)end
function a.dataLoaded()d:call()end

function a.get(a)
return e[a]
end

function a.experimental(a)
local a=e[a]
return a~=nil and a.experimental==true
end

a.EXPERIMENTAL={word="Experimental",
tip="EXPERIMENTAL. This source type is still under construction and/or is not yet fully tested."}












b.Debug.experimental("a plain layer following another buff's or debuff's state: drawn twice, under that aura's"
.." Present and Missing clips (FR-3: a frame inside an aura clip shows only while both hold; the split itself"
.." unplayed)","I")
b.Debug.experimental("a gate key that only adds: the layer's parts it shows under a gate whose alpha a curve sets,"
.." polled (A6; TO-3 records the totem's; Soon's, I)","I")

local function d(a,b)
for b in pairs(b)do a[b]=true end
end

local function l(a)
for b,a in pairs(a or{})do
if type(a)=="table"then
if not l(a)then return false end
elseif not(b=="shown"and a==true)then
return false
end
end
return true
end

local function n(a)
if type(a)~="table"then return false end
for b,a in pairs(a)do
if b~="time"or type(a)~="table"then return false end
for a in pairs(a)do
if a~="colour"then return false end
end
end
return next(a)~=nil
end





function a.restsOn(e,a)
local b={lua={},drawn={},looks={}}
local a=a.compiled
if not a then return b end
local function c(a)
local a=e:atomsOf(a)
d(b.lua,a.lua)
for a,c in pairs(a.drawn)do b.drawn[a]=c end
return a
end
for d,b in ipairs(a.stateOrder or{})do
if a.states[b]then c(a.source.."."..b)end
end
for b in pairs(a.global or{})do c(a.source.."."..b)end
for d,a in ipairs(a.flags or{})do
local d={}
for b,a in ipairs({a["while"],a.unless})do
for b,a in ipairs(a)do
for a,b in pairs(c(a).drawn)do d[a]=b end
end
end
b.looks[#b.looks+1]={drawn=d,values=a.values,borrow=a.borrow,flag=a}
end
return b
end


local function f(b)
local a={}
for b in pairs(b)do a[#a+1]=b end
table.sort(a)
return a
end
a.sortedKeys=f



function a.clipAura(a,d)
for e,b in ipairs(f(a.drawn))do
local e,c=c.splitKey(b)
if a.drawn[b]=="clip"and c~=d then return c end
end
end


function a.splitsOn(d)
local e={}
if not d.layers then return e end
local g=b.Keys.compile(d)
for h,f in ipairs(d.layers)do
if b.Layers.ownsLayer(d,f)and d.run~=nil and f.compiled then
for a,b in pairs(a.restsOn(g,f).drawn)do
local c,a=c.splitKey(a)
if b=="clip"and a~=d.run then e[a]=true end
end
end
end
return e
end




function a.planCopies(g,d)
local i=b.Keys.compile(g)
d.copies,d.copyOf,d.formatter={},{},{}

local e=g.source and e[g.source.kind]
local o=e~=nil and e.countdownGates==true
local k=d.parts
local h={}
for b,a in ipairs(k)do
if a.layer and not a.effect then
h[a.layer]=h[a.layer]or{}
table.insert(h[a.layer],a)
end
end
for e,m in ipairs(g.layers)do
if h[e]then
local j=a.restsOn(i,m)

local i,a=a.clipAura(j,g.run),{}
for b,d in pairs(j.drawn)do
local c,e=c.splitKey(b)
if d=="gate"then a[b]={key=b,word=c,own=e==g.run}end
end
for f,a in pairs(a)do
local b,c=true,true
for e,d in ipairs(j.looks)do
if d.drawn[f]then
b=b and l(d.values)
c=c and o and m.kind=="icon"and a.own and n(d.values)
end
end
a.mode=c and"countdown"or b and"adds"or"change"
if a.mode=="countdown"then d.formatter[e]=f end
end


local c={{assign=nil,axes={}}}
local function g(a,b,d,c)
local b={}
for a,d in ipairs(a)do
for a,e in ipairs(c)do
local c={}
for a,b in pairs(d.assign or{})do c[a]=b end
for a,b in pairs(e.assign)do c[a]=b end
local a={}
for b,c in ipairs(d.axes)do a[b]=c end
a[#a+1]=e.axis
b[#b+1]={assign=c,axes=a}
end
end
return b
end
if i then
local a,b=i..".present",i..".missing"
c=g(c,i,"aura",{
{assign={[a]=true,[b]=false},axis={kind="aura",src=i,side="present"}},
{assign={[a]=false,[b]=true},axis={kind="aura",src=i,side="missing"}}})
end
for d,b in ipairs(f(a))do
if a[b].mode=="change"then
c=g(c,b,"gate",{
{assign={[b]=true},axis={kind="gate",key=b,on=true}},
{assign={[b]=false},axis={kind="gate",key=b,on=false}}})
end
end

local g={}
for c,b in ipairs(c)do
for d,c in ipairs(f(a))do
if a[c].mode~="change"then
b.assign=b.assign or{}
b.assign[c]=false
end
end
d.copies[#d.copies+1]={layer=e,atoms=f(j.lua),assign=b.assign,
axes=b.axes}
g[#g+1]=#d.copies
end
for h,b in ipairs(f(a))do
if a[b].mode=="adds"then
for i,h in ipairs(c)do
local c={}
for a,b in pairs(h.assign or{})do c[a]=b end
c[b]=true
local a={}
for b,c in ipairs(h.axes)do a[b]=c end
a[#a+1]={kind="gate",key=b,on=true}
d.copies[#d.copies+1]={layer=e,atoms=f(j.lua),assign=c,axes=a,
adds=g[i]}
end
end
end
d.copyOf[e]=g[1]
local a=g[1]
for c,b in ipairs(h[e])do b.copy=a end
for f=a+1,#d.copies do
local d=d.copies[f]
if d.layer==e then
local g={}
local c={}
for a,e in ipairs(h[e])do
local a=b.copy(e)
a.n,a.copy,a.adds=#k+1,f,d.adds
k[a.n]=a
g[e.n]=a.n
c[#c+1]=a
end
for b,a in ipairs(c)do
if a.rides then a.rides=g[a.rides]end
end
end
end
end
end
end










local i="DisableUntrustedLayoutScriptsTemplate"
local j=2
b.Debug.experimental("an effect over another buff's or debuff's layer: drawn twice, under that aura's Present and"
.." Missing clips, each at its side's Opacity (FR-3, AU-6: the split pane's frames; the split itself unplayed)","I")
local function f(b,a)
return b.."|"..(a.kind=="aura"and(a.src..":"..a.side)or(a.key..":"..tostring(a.on)))
end



local function k(a,c)
if a.levelsOf==c then return a.levels end
local d={}
local function e(a,b)
d[a]=d[a]or{}
table.insert(d[a],b)
end
for b,a in ipairs(c and c.parts or{})do
if a.effect then
if a.side then e(f("",{kind="aura",src=a.onRun,side=a.side}),a)end
else
local c=c.copies and c.copies[a.copy]
local b=""
for d,c in ipairs(c and c.axes or{})do
b=f(b,c)
if c.kind=="aura"then e(b,a)end
end
end
end
local e={}
for a,c in pairs(d)do e[a]=b.Layers.clipLevel(c)end
a.levels,a.levelsOf=e,c
return e
end
local function h(g,c,a,l)
local h,e=c.root,""
for a,d in ipairs(a or{})do
e=f(e,d)
local a=g.axes[e]
if not a then
a=CreateFrame("Frame",nil,h,i)
g.axes[e]=a
if d.kind=="aura"then a:SetClipsChildren(true)else a:SetAllPoints(c.root)end
end
a:Show()
if d.kind=="aura"then

local b=k(g,l or c.rig)[e]
if b then a:SetFrameLevel(b)end
local e=c.element.runById[d.src]
local b=e and e.inst and e.inst.f
a:ClearAllPoints()
if b and d.side=="present"then
a:SetPoint("TOPLEFT",b.sensor,"TOPLEFT",0,0)
a:SetPoint("BOTTOMRIGHT",b.sensor,"BOTTOMRIGHT",-j,0)
elseif b then
a:SetPoint("TOPLEFT",b.sensor,"TOPRIGHT",0,0)
a:SetPoint("BOTTOMRIGHT",b.cell,"BOTTOMRIGHT",0,0)
else
a:SetAllPoints(c.root)
a:SetAlpha(0)
end
if b and e.inst.follow then e.inst:follow(a)end
else
c.gates=c.gates or{}
local e=c.gates[d.key]
if not e then
e={on={},off={}}
c.gates[d.key]=e
end
local c=d.on and e.on or e.off
if not b.Layers.inList(c,a)then c[#c+1]=a end
a:SetAlpha(d.on and 0 or 1)
end
h=a
end
return h
end


function a.effectParent(b,c,a,d,e)
if not a.side then return d end
return h(b,c,{{kind="aura",src=a.onRun,side=a.side}},e)
end
function a.plainBuild(c,e,f,b)
local b=b and b.frames
if not b then
b={axes={}}
b.host=CreateFrame("Frame",nil,e.root)
b.host:SetAllPoints()
end
c.frames,c.host=b,b.host
b.host:Show()
for b,a in pairs(b.axes)do a:Hide()end
e.gates=nil
local i={}
for d,c in ipairs(f.parts)do
local g
local d=c.effect and type(c.holder)=="string"and c.holder:match("^gate:(.+)$")
if d then
b.ends=b.ends or{}
if not b.ends[d]then
b.ends[d]=CreateFrame("Frame",nil,b.host)
b.ends[d]:SetAllPoints()
b.ends[d]:SetAlpha(0)
end
g=b.ends[d]
elseif c.effect then
g=a.effectParent(b,e,c,b.host,f)
else
local a=c.rides and i[c.rides]
g=a and a.visual.frame
or h(b,e,f.copies[c.copy]and f.copies[c.copy].axes,f)
end
i[c.n]=e:makeVisual(g,c)
end
end





function a.lightGates(a,b,c,d)
for e,a in ipairs(a and a.runs or{})do
local a=a.gates and a.gates[b]
if a then
for b,a in ipairs(a.on)do a:SetAlpha(c)end
for b,a in ipairs(a.off)do a:SetAlpha(d)end
end
end
end




local e="gate from a boolean"
function a.lightGatesFrom(d,f,c)
if not b.isSecret(c)then
local b=c==true
a.lightGates(d,f,b and 1 or 0,b and 0 or 1)
return
end
for d,a in ipairs(d and d.runs or{})do
local a=a.gates and a.gates[f]
if a then
for d,a in ipairs(a.on)do
if not b.try(e,a.SetAlphaFromBoolean,a,c,1,0)then a:SetAlpha(0)end
end
for d,a in ipairs(a.off)do
if not b.try(e,a.SetAlphaFromBoolean,a,c,0,1)then a:SetAlpha(1)end
end
end
end
end

function a.readLevel(a,c,...)
local c,a=b.try(a,c,...)
if not c then return false end
if b.isSecret(a)then return a end
if a==nil then return false end
return a
end

function a.unitPresent(a)
if a=="player"then return true end
local c,a=b.try("UnitExists",UnitExists,a)
return c and not b.isSecret(a)and a==true
end





local c="spell power cost"
local function d(a)
local a,c=a.requiredAuraID,a.hasRequiredAura
if b.isSecret(a)or b.isSecret(c)then return false end
return type(a)=="number"and a~=0 and c==false
end
function a.powerCost(a,e)
if not C_Spell or not C_Spell.GetSpellPowerCost then return false end
local c,a=b.try(c,C_Spell.GetSpellPowerCost,a)
if not c or b.isSecret(a)or type(a)~="table"then return false end
for c=1,#a do
local a=a[c]
if type(a)=="table"and not b.isSecret(a.type)and a.type==e and not d(a)then
local a=a.cost
if b.isSecret(a)then return a end
return type(a)=="number"and a or false
end
end
return false
end


function a.levelGates(a)
local c={}
if a.lowKey and b.Layers.levelCurve(a.low)then
c[#c+1]={key=a.lowKey,on=b.Layers.levelCurve(a.low),
off=b.Layers.levelCurve(a.low,true)}
end
if a.fullKey and b.Layers.levelCurve(100)then
c[#c+1]={key=a.fullKey,on=b.Layers.levelCurve(100),off=b.Layers.levelCurve(100,true)}
end
return c
end





local function d(a)return b.isSecret(a)or type(a)=="number"end
function a.lightLevels(e,c,f,k,g,h)
for i=1,#c do
local c=c[i]
local i,j=0,1
if k and a.usesGate(e,c.key)then
local e,a=b.try(f,g,h,c.on)
local c,b=b.try(f,g,h,c.off)
if e and c and d(a)and d(b)then i,j=a,b end
end
a.lightGates(e,c.key,i,j)
end
end

function a.usesGate(a,b)
for c,a in ipairs(a and a.runs or{})do
if a.gates and a.gates[b]then return true end
end
return false
end



local d={element=true,styles=true,group=true,settings=true,profile=true,char=true}
local c=false
local function e()c=false end
local function f()b.Events.atFrameEnd("plain paint edit",e)end
b.onChanged(function(a)
if not d[a]then return end
c=true
b.Events.atFrameEnd("plain paint edit",f)
end,"plain paint edit")

function a.editing()return c end


function a.plainPaint(a)
local a=a.element
for c,b in ipairs(a.visuals)do
if not b.gone then a:fadeTo(b)end
end
end
