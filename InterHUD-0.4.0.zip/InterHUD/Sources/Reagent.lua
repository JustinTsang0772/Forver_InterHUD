

local b,a=...
local f,n,h,d,j,o,b=a.Sources,a.Layers,a.Spells,a.Events,a.Combat,a.Quiet,a.Debug







local k={
[131]={17057},
[546]={17058},
[21169]={17030},
}







local p=1225503

local q={1262636,1262638,1262643,1262647,1262650,1262654,1262662}
local r={
[17030]=true,
[17020]=true,[17031]=true,[17032]=true,
[17033]=true,[21177]=true,
[17028]=true,[17029]=true,
[17034]=true,[17035]=true,[17036]=true,[17037]=true,[17038]=true,
[17021]=true,[17026]=true,
[5565]=true,[16583]=true,
}

b.experimental("Reagent Economy lifting the reagents its class aura's spell mask names (never seen taken: IT-4)","I")


local b={label="Low",holds="You carry only a few of the item.",read="lua",within="present",max=1,
setting={{name="count",type="integer",default=2,min=1,max=200,softMax=20,label="Count"}},
default=function()return{}end}


local c={
{name="items",type="list",of="integer",item={min=1},minItems=1,maxItems=20,unique=true,
control="items",label="Items"},
{name="reagentFor",type="spell",label="For spell",
help="Shown only while you know this spell and it takes the item."},
}

f.register("reagent",{
fields=c,
idWord="reagent",
target={field="items",pick="Pick its item."},
variantOrder={"reagent"},
variants={
reagent={
add={label="Reagent",note="An item's count in your bags"},
noun="a reagent",
read="lua",moment="plain",
stateOrder={"present","none"},
states={
present={label="Present",holds="You carry some of the item."},
none={label="None",holds="You carry none of the item."},
},
factOrder={"low"},facts={low=b},

eventOrder={"ranLow","ranOut"},
events={
ranLow={label="Ran low",holds="it runs low",begins="present"},
ranOut={label="Ran out",holds="it runs out",begins="none"},
},
},
},
})

local b=f.get("reagent")
b.TAKES=k

local l="Interface\\Icons\\INV_Misc_QuestionMark"

local function e(a)return h.listOf(a and a.items)end


local function s(b)
if not(C_Item and C_Item.GetItemCount)then return nil end
local c,b=a.try("GetItemCount",C_Item.GetItemCount,b)
if not c or a.isSecret(b)or type(b)~="number"then return nil end
return b
end
local function m(b)
if not(C_Item and C_Item.GetItemIconByID)then return nil end
local c,b=a.try("GetItemIconByID",C_Item.GetItemIconByID,b)
return c and not a.isSecret(b)and b or nil
end



local g,c,t={},0,200


local function u(d,b,c)
if c==true and not a.isSecret(b)and g[b]then f.dataLoaded()end
end
local function i(b)
if not(C_Item and C_Item.GetItemNameByID)then return nil end
local f,e=a.try("GetItemNameByID",C_Item.GetItemNameByID,b)
if f and type(e)=="string"and not a.isSecret(e)then return e end
if g[b]or not C_Item.RequestLoadItemDataByID then return nil end
if c>=t then
wipe(g)
c=0
end
if c==0 then d.on("GET_ITEM_INFO_RECEIVED","reagent asked",u)end
g[b],c=true,c+1
a.try("RequestLoadItemDataByID",C_Item.RequestLoadItemDataByID,b)
end
b.itemName=i


local g=false
local function t()
if j.inCombat()or j.aurasSecret()then return false end
local b=g
g=h.known(p)
if not g and C_UnitAuras and C_UnitAuras.GetPlayerAuraBySpellID then
for c,b in ipairs(q)do
local c,b=a.try("Reagent Economy's aura",C_UnitAuras.GetPlayerAuraBySpellID,b)
g=c and not a.isSecret(b)and type(b)=="table"
if g then break end
end
end
return g~=b
end
function b.perkKnown()return g end




function b.learned(a)
local a=a and a.reagentFor
return a==nil or h.known(a)
end


function b.yourSpells(a)
return{a and a.reagentFor}
end


function b.icon(a)
local a=e(a)[1]
return a and m(a)or l
end

function b.words(b)
local a={}
for c,b in ipairs(e(b))do a[c]=i(b)or("item "..b)end
if#a==0 then return nil end
local a=#a>2 and(a[1].." and "..(#a-1).." more")or table.concat(a," or ")
local b=b.reagentFor and h.nameOf(b.reagentFor)
return b and(a.." for "..b)or a
end




b.picks={data="item",fits=function(a)return a.kind=="item"and not a.trinket end,
choiceOf=function(a)return"item:"..a end}




function b.addChoices(a,b)
local b=a and a~=""and a:lower()or nil
local a={}
for c,d in pairs(k)do
local f=i(d[1])or("Item "..d[1])
local e=h.nameOf(c)
if h.known(c)and e and(not b or f:lower():find(b,1,true)
or e:lower():find(b,1,true))then
a[#a+1]={id=c,name=f,icon=m(d[1])or l,note="For "..e}
end
end
table.sort(a,function(a,b)return a.name<b.name end)
return a
end
function b.addRecord(a)
local b=type(a)=="string"and tonumber(a:match("^item:(%d+)$"))
if b then return{kind="reagent",items={b}},i(b)or("item "..b)end
local b=k[a]
if not b then return nil end
local c={}
for a,b in ipairs(b)do c[a]=b end
return{kind="reagent",items=c,reagentFor=a},i(b[1])
end



local k=20
function b.preview(c,a)
local e=e(c)[1]
local d=f.firstItem(c,"low")
local f=d and a and a.facts and a.facts[d.id]
local a=a and a.state=="none"and 0 or f and(d.count or 2)or k
return{icon=b.icon(c),name=e and i(e)or false,length=false,count=a}
end


function b.plan(a)
local b=a.source
local c={kind="reagent",items=e(b),reagentFor=b.reagentFor,parts=n.allParts(a,nil)}
f.planCopies(a,c)
local a=f.firstItem(b,"low")
if a then c.low={id=a.id,count=a.count or 2}end
return c
end

local e={}
local c={}
c.__index=c




function c:stateOf(a)
if self.rig.reagentFor~=nil and g and self.lifted then return"present",false end
if a<=0 then return"none",false end
local b=self.rig.low
return"present",b~=nil and a<=b.count
end



function c:readCounts()
local a,b=nil,0
for c,d in ipairs(self.items)do
local c=s(d)
if c==nil then return nil end
if c>0 and not a then a=d end
b=b+math.max(c,0)
end
return a or self.items[1],b
end


function c:feed(b,c)
if b==self.fedItem and c==self.fedCount and not self.refeedName then return end
self.fedItem,self.fedCount,self.refeedName=b,c,nil
local a=self.data
a.icon=m(b)or l
a.name=i(b)or false
self.nameMissing=a.name==false
a.count=c
self.element:feed(a)
end





function c:read(d)
local e,f=self:readCounts()
if e==nil then
self.unreadable=true
return
end
self.unreadable=false
local b,h=self.state,self.low
local a,c=self:stateOf(f)
if a~=b then
self.state=a
self.element:setState(a)
end
self.low=c
local g=o.isQuiet(nil)
if self.rig.low then self.element:setFact(self.rig.low.id,c,d and b~=nil and not g)end
self:feed(e,f)
if not d or b==nil or g then return end

if a=="none"and b~="none"then
self.element:moment("ranOut")
elseif c and not h and a=="present"then
self.element:moment("ranLow")
end
end

function b.build(e,a,b,d)
if d then d:release()end
local b=setmetatable({element=e,view=b,rig=a,items=a.items,data={}},c)

b.lifted=#a.items>0
for c,a in ipairs(a.items)do b.lifted=b.lifted and r[a]==true end
f.plainBuild(b,e,a,d)
return b
end

function c:paint()
f.plainPaint(self)
end


local function f()
for b in pairs(e)do a.try("reagent "..tostring(b.element.id),b.read,b,true)end
end
local function g()d.atFrameEnd("reagent source",f)end


local function i()
if not t()then return end
for b in pairs(e)do
if b.rig.reagentFor~=nil then a.try("reagent "..tostring(b.element.id),b.read,b,false)end
end
end
local function f()d.atFrameEnd("reagent perk",i)end
h.onChange("reagent perk",f)
j.onEnd("reagent perk",f)


local function h(d,b,c)
if c~=true or a.isSecret(b)then return end
for a in pairs(e)do
if a.fedItem==b and a.nameMissing then
a.refeedName=true
a:feed(a.fedItem,a.fedCount)
end
end
end

function c:start()
if next(e)==nil then
d.on("BAG_UPDATE_DELAYED","reagent source",g)
d.on("ITEM_COUNT_CHANGED","reagent source",g)
d.on("GET_ITEM_INFO_RECEIVED","reagent source",h)
d.onUnit("UNIT_AURA","player","reagent source",f)
i()
end
e[self]=true
self.state,self.low,self.fedItem,self.fedCount=nil,nil,nil,nil
self:read(false)
end

function c:stop()
e[self]=nil
if next(e)==nil then
d.off("BAG_UPDATE_DELAYED","reagent source")
d.off("ITEM_COUNT_CHANGED","reagent source")
d.off("GET_ITEM_INFO_RECEIVED","reagent source")
d.offUnit("UNIT_AURA","reagent source")
end
end

function c:release()
self:stop()
self.host:Hide()
end

function c:refeed()
self.fedItem=nil
if e[self]then self:read(false)end
end

function c:describe()
return string.format("reagent %s, %s, count %s%s",table.concat(self.items,"/"),tostring(self.state),
tostring(self.fedCount),self.unreadable and", unreadable"or"")
end

b.live=e
