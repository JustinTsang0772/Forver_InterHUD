


local a,b=...
local a=b.Schema




local m={"present","missing"}

local function h(a)
if type(a)~="table"or a.kind~="aura"or a.spells==nil then return false end
return b.Sources.get("aura").endless(a)
end
local n={
present={label="Present",holds="The buff or debuff is active."},
missing={label="Missing",holds="The buff or debuff isn't active."},
}




local c={label="Expiring",holds="The buff or debuff is in the last part of its duration.",read="cell",within="present",
max=1,capRule="C5",capText="has %d shares; a buff or debuff takes one for now.",
setting={{name="share",type="percent",default=20,min=1,max=99,label="Share"}},
default=function(a)return not h(a)and{}or false end,

none=function(a)return h(a)and"never runs out, so it has no Expiring"or nil end}



local function d(a,b,c)
local a=(a.atLeast and 1 or 0)+(a.atMost and 1 or 0)+(a.between and 1 or 0)
if a~=1 then
b:problem(c,a==0 and"needs its stacks: atLeast, atMost or between."or"names more than one of atLeast,"
.." atMost and between; keep one.")
end
end
local i={label="Stacks",holds="The buff or debuff's stack count is in a set range.",read="cell",within="present",max=5,
capRule="C1",capText="has %d stack ranges; a buff or debuff can have %d.",example={id="full",atLeast=2},
rule=d,retired={exactly="is now between: [n, n]; left out."},
setting={
{name="atLeast",type="integer",min=1,max=255,label="At least"},
{name="atMost",type="integer",min=1,max=255,label="At most"},
{name="between",type="list",of="integer",item={min=1,max=255},minItems=2,maxItems=2,
label="Between"},
}}
local o={"expiring","stacks"}
local j={expiring=c,stacks=i}



local function k(a)
if type(a)~="table"then return nil end
if a.atLeast then return a.atLeast,nil end
if a.atMost then return 0,a.atMost end
local a=a.between
if type(a)=="table"and a[1]and a[2]then return math.min(a[1],a[2]),math.max(a[1],a[2])end
return nil
end


i.range=k




local p={label="Arrived",holds="it arrives",effects={pop=true},begins="present"}




local e={label="Arrived",holds="it arrives",effects={},later={pop=true,sound=true},
begins="present"}


local q={label="Arrived",holds="it arrives",effects={pop=true,sound=true},begins="present"}
local r={label="Removed",holds="it goes",effects={sound=true},begins="missing"}









local c=b.Units.TOKENS
local l={target=true,focus=true}
local s={focus="target"}
local t={player=true,pet=true}



local c={{name="unit",type="unit",units=c,default="player",label="Watches"},
b.Sources.spellsField("Spells","Spell IDs, any one up counts.")}
c[#c+1]={name="shownSpell",type="choice",choices={"first","lastSeen"},default="first",
labels={first="First",lastSeen="Last seen"},label="Shown spell",
help="Which one's icon while none is up.",
shownIf=function(b,a)return a~=nil and type(a.spells)=="table"and#a.spells>1 end}





c[#c+1]={name="castBy",type="choice",choices={"you","anyone"},default="you",
labels={you="You",anyone="Anyone"},label="Cast by",
help="Anyone also counts another player's cast. Where two players' copies of one debuff are on an enemy, one is"
.." shown.",
shownIf=function(b,a)return a~=nil end}


local f,g="Aura","A buff on you or your pet, or your debuff on your target or your focus target"

local function d(b,a)
a.unit,a.read,a.moment=b,"clip","engine"
a.stateOrder,a.states,a.factOrder,a.facts=m,n,o,j

function a.offersEvent(c,b)return next(a.events[b].effects)~=nil end
return a
end

b.Sources.register("aura",{

variantOf=function(a)return"aura:"..(a.unit or"player")end,


idWord=function(a)
if a.unit=="focus"then return"focusdebuff"end
if a.unit=="pet"then return"petbuff"end
return a.unit=="target"and"debuff"or"buff"
end,

noteWord=function(a)return l[a.unit]and"debuff"or"buff"end,
fields=c,
target={field="spells",pick="Pick its spell."},
variantOrder={"aura:player","aura:target","aura:pet","aura:focus"},
variants={




["aura:player"]=d("player",{add={label=f,note=g,anyUnit=true},
noun="a buff",eventOrder={"arrived","removed"},events={arrived=q,removed=r}}),
["aura:target"]=d("target",{add={label=f,note=g,listed=false},
noun="a debuff",eventOrder={"arrived"},events={arrived=e}}),


["aura:pet"]=d("pet",{add={label=f,note=g,listed=false},
noun="a buff on your pet",eventOrder={"arrived"},events={arrived=e}}),
["aura:focus"]=d("focus",{add={label=f,note=g,listed=false},
noun="a debuff on your focus target",eventOrder={"arrived"},events={arrived=e}}),
},
})


local function f(a,b)
local a=type(a.sources)=="table"and a.sources[b[2]]
return type(a)=="table"and a or nil
end

a.caveat("aura arrival pop at a fight's edges",{
text="This effect can't play within 1.5 seconds after combat starts or ends, due to addon limitations.",
at=function(b)return a.isPath(b,"sources","*","events","arrived","effects","*","kind")end,
applies=function(a,c)
local a=f(a,c)
local b=a and type(a.events)=="table"and a.events.arrived
local b=b and type(b.effects)=="table"and b.effects[c[6]]

return a~=nil and a.kind=="aura"and type(b)=="table"and b.kind=="pop"
end,
})

local function c(b)
a.caveat(b.." arrival",{
text=a.subjectOf(a.source(b)).." can't play a pop or a sound when it arrives yet.",
at=function(b)return a.isPath(b,"sources","*","unit")end,
applies=function(c,d)return a.variantKey(f(c,d))==b end,
})
end
c("aura:target")
c("aura:pet")
c("aura:focus")


a.caveat("aura list name",{
text="With several spells, it names the one Shown spell picks, even while another is up.",
at=function(b)
return a.isPath(b,"sources","*","layers","*","content")
or a.isPath(b,"sources","*","layers","*","texts","*","content")
or a.isPath(b,"sources","*","layers","*","nameText","content")
end,
applies=function(c,a)
local c=f(c,a)
local d=c and type(c.layers)=="table"and c.layers[a[4]]
local a=d and(a[5]=="texts"and(d.texts and d.texts[a[6]])
or a[5]=="nameText"and d.nameText or a[5]=="content"and d)
return c~=nil and c.kind=="aura"and#b.Spells.listOf(c.spells)>1 and type(a)=="table"
and a.content=="name"
end,
})


local a=b.Sources.get("aura")
a.stackRange,a.MAX_RANGES=k,i.max
a.islandVariant,a.POP,a.FACTS,a.neverEnds=d,p,j,h
a.NOT_YET,a.notYet=e,c


function a.onEnemy(a)return l[a]==true end
function a.takesAlly(a)return t[a or"player"]==true end
function a.dataUnit(a)return s[a]or a or"player"end
