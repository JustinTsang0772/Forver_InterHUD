



local b,a=...
local b,i,c,n,j,k,d=a.Sources,a.Layers,a.Events,a.Quiet,a.Units,a.Combat,a.Debug









d.experimental("health's secrecy as the docs give it: UnitHealth, UnitHealthMissing, UnitHealthPercent and"
.." UnitGetTotalAbsorbs handed on as read on you and your target, at rest and in a fight (UN-4: drawn T 70450;"
.." each one's secrecy unread: EP-67)","D")
d.experimental("your shields, incoming heals and heal absorbs through the heal-prediction calculator: one a"
.." source (two where a bar draws Shields with no heals), its clamps set once (heals to missing health; shields to"
.." what is left after them, or to missing health where a bar draws no heals; heal absorbs and heals"
.." reduced by each other, heal absorbs to current health; the overflow 1.0), read at each event, every output handed to a bar"
.." alone; none where the client lacks it (UN-19: the docs, EllesmereUI's heals on Forever; its outputs' secrecy"
.." and the clamps unseen: EP-65)","D")
d.experimental("health's Low and Full: a Step curve on UnitHealthPercent into each gate's alpha and the mirrored"
.." curve into its complement's, sampled at every read, lit plainly at None and Dead (A6; UN-4's under-20% alpha"
.." T 70450; the complement and Full's exact top unrecorded: FR-42, EP-69)","I")
d.experimental("your pet's health as yours: UnitHealth, UnitHealthMissing and UnitHealthPercent secret and handed"
.." on, UnitHealthMax plain, UnitExists and UnitIsDeadOrGhost plain, at rest and in a fight; its events through"
.." RegisterUnitEvent on pet; read again at UNIT_PET for you and PET_UI_UPDATE (UN-21: the docs and Blizzard's pet"
.." frame; a pet player-controlled I: EP-26)","D")
d.experimental("your pet's Appears, Dies and Leaves from its state at the frame's end: Dies where Dead begins with"
.." the token kept, Leaves where it goes (UN-21: whether the token outlives a death, and what UNIT_PET brings at a"
.." summon, a dismissal, a death and a flight path, unread: EP-26)","I")
d.experimental("Incoming heals, shields and heal absorbs on your pet: UnitGetDetailedHealPrediction(\"pet\","
.." \"player\", calc) (UN-19: a pet a unit by the docs; unseen: EP-65, EP-26)","D")
d.experimental("your focus target's health as your target's: its levels and maximum secret on a mob and handed on,"
.." UnitExists and UnitIsDeadOrGhost plain, its events through RegisterUnitEvent on focus, read again at"
.." PLAYER_FOCUS_CHANGED; its death read below; its overlays through UnitGetDetailedHealPrediction(\"focus\","
.." \"player\", calc) (UN-22: the docs, UN-4's predicates by token; UN-19: EP-65; EP-73)","D")
d.experimental("your focus target's death read from UnitIsDeadOrGhost (plain by the docs) at its UNIT_HEALTH and"
.." UNIT_FLAGS, at once and again at the frame's end, its bar zeroed (UN-22, UN-4: which events come at its death"
.." and when the flag is set, unread: EP-73)","I")
d.experimental("UNIT_DIED as a trigger alone: the target's and your focus target's state read again at the frame's"
.." end, its secret GUID never read; registered only where C_EventUtils.IsEventValid knows it (the docs list it,"
.." 70755; whether it comes at a mob's death unread: EP-73)","I")
d.experimental("health read again at UNIT_MAX_HEALTH_MODIFIERS_CHANGED from any unit at the frame's end, its"
.." payload secret and never read (D: SecretPayloads; unseen: EP-65)","D")

local o=CurveConstants and CurveConstants.ScaleTo100 or i.curve({0,0,1,100})


local e={
player={alive="You are alive.",dead="You are dead, or a ghost."},
target={alive="Your target is alive.",dead="Your target is dead.",none="You have no target."},
pet={alive="Your pet is alive.",dead="Your pet is dead.",none="You have no pet out."},
focus={alive="Your focus target is alive.",dead="Your focus target is dead.",
none="You have no focus target."},
}
local function d(a)


local b=a=="target"and{"hostileTarget"}or nil
local a=e[a]
local b={
alive={label="Alive",holds=a.alive,scene=b},
dead={label="Dead",holds=a.dead,scene=b},
}
if a.none then b.none={label="None",holds=a.none}end
return b
end




local h={label="Low",holds="Health is at or under its \"Share\".",read="gate",max=1,within="alive",
setting={{name="share",type="percent",default=20,min=1,max=99,label="Share",said="%s or under",
help="Low holds while health is at or under this share of its maximum."}},
default=function()return{}end}
local e={label="Full",holds="Health is full.",read="gate",max=1,within="alive",setting={},
default=function()return{}end}
local e,f={"low","full"},{low=h,full=e}


local l={player="yourhealth",target="targethealth",pet="pethealth",focus="focushealth"}
local g="Yours, your target's, your pet's or your focus target's"

b.register("health",{
experimental=true,
fields={{name="unit",type="unit",units=j.TOKENS,default="player",label="Watches"}},
variantOf=function(a)return"health:"..(a.unit or"player")end,

idWord=function(a)return l[a.unit]or l.player end,

noteWord=function()return false end,
nothingToPick=true,
variantOrder={"health:player","health:target","health:pet","health:focus"},
variants={
["health:player"]={
add={label="Health",note=g},
unit="player",noun="your health",
read="lua",moment="plain",
stateOrder={"alive","dead"},states=d("player"),
factOrder=e,facts=f,
typical="alive",
},

["health:target"]={
add={label="Health",note=g,listed=false},
unit="target",noun="your target's health",
read="lua",moment="plain",
stateOrder={"alive","dead","none"},states=d("target"),
factOrder=e,facts=f,
typical="alive",
},


["health:pet"]={
add={label="Health",note=g,listed=false},
unit="pet",noun="your pet's health",
read="lua",moment="plain",
stateOrder={"alive","dead","none"},states=d("pet"),
factOrder=e,facts=f,
eventOrder={"appears","dies","leaves"},
events={
appears={label="Appears",holds="your pet appears",begins="alive"},
dies={label="Dies",holds="your pet dies",begins="dead"},
leaves={label="Leaves",holds="your pet is dismissed or lost",begins="none"},
},
typical="alive",
},

["health:focus"]={
add={label="Health",note=g,listed=false},
unit="focus",noun="your focus target's health",
read="lua",moment="plain",
stateOrder={"alive","dead","none"},states=d("focus"),
factOrder=e,facts=f,
typical="alive",
},
},
})

local g=b.get("health")

local d="Health"
function g.words()return d end



local d=5000
function g.preview(c,a)
local e=a and a.state
if e=="dead"then
return{length=false,amount=0,max=d,percent=0,missing=d,shields=false,heals=false,
absorbs=false,absorbsAlone=false,healAbsorbs=false}
end
if e~="alive"then
return{length=false,amount=false,max=false,percent=false,missing=false,shields=false,
heals=false,absorbs=false,absorbsAlone=false,healAbsorbs=false}
end
local e=a.facts or{}
local a=b.firstItem(c,"low")
local b=b.firstItem(c,"full")
local e=b and e[b.id]and 100 or a and e[a.id]and(a.share or h.setting[1].default)
or 70
local b=d*e/100
local a=d-b
local f,c=math.min(600,a),400
return{length=false,amount=b,max=d,percent=e,missing=a,shields=c,
heals=f,absorbs=math.min(c,a-f),absorbsAlone=math.min(c,a),
healAbsorbs=math.min(300,b)}
end




local function d(a)return type(a)=="table"and a.enabled~=false end
local function e(b,c)
local a
for e,b in ipairs(b.layers)do
if b.source==c and b.kind=="bar"and b.value=="amount"and b.enabled~=false then
local c,e=d(b.incomingHeals),d(b.shields)
if c or e or d(b.healAbsorbs)then
a=a or{}
a.heals=a.heals or c or nil
a.chained=a.chained or(e and c)or nil
a.alone=a.alone or(e and not c)or nil
a.healAbsorbs=a.healAbsorbs or d(b.healAbsorbs)or nil
end
end
end
return a
end


function g.plan(d)
local a=d.source
local c={kind="health",unit=a.unit or"player",parts=i.allParts(d,nil),
overlays=e(d,a.id)}
b.planCopies(d,c)
local d=b.firstItem(a,"low")
if d then c.low,c.lowKey=d.share or h.setting[1].default,a.id.."."..d.id end
local b=b.firstItem(a,"full")
if b then c.fullKey=a.id.."."..b.id end
return c
end

local h,d=b.readLevel,b.unitPresent


local function l(b)
if not d(b)then return"none"end
local c,b=a.try("UnitIsDeadOrGhost",UnitIsDeadOrGhost,b)
if c and not a.isSecret(b)and b==true then return"dead"end
return"alive"
end








local f="health prediction"
local function e(b,d)
local c=Enum.UnitDamageAbsorbClampMode
local a=a.try(f,b.SetIncomingHealClampMode,b,Enum.UnitIncomingHealClampMode.MissingHealth)
and a.try(f,b.SetHealAbsorbMode,b,Enum.UnitHealAbsorbMode.ReducedByIncomingHeals)
and a.try(f,b.SetHealAbsorbClampMode,b,Enum.UnitHealAbsorbClampMode.CurrentHealth)
and a.try(f,b.SetDamageAbsorbClampMode,b,
d and c.MissingHealthWithoutIncomingHeals or c.MissingHealth)


and(not b.SetIncomingHealOverflowPercent or a.try(f,b.SetIncomingHealOverflowPercent,b,1))
return a and b or nil
end
local function d(b)
if not(CreateUnitHealPredictionCalculator and UnitGetDetailedHealPrediction and Enum.UnitDamageAbsorbClampMode)then
return nil
end
local c,a=a.try(f,CreateUnitHealPredictionCalculator)
if not c or a==nil then return nil end
return e(a,b)
end


local function m(b,c)
if not b then return d(c)end
if not(b.SetToDefaults and a.try(f,b.SetToDefaults,b))then return d(c)end
return e(b,c)or d(c)
end

local function i(b,c)
local c,b=a.try(f,b,c)
if not c then return false end
if a.isSecret(b)then return b end
return type(b)=="number"and b or false
end

local d={}
local e={}
e.__index=e


function e:predict(b)
local e,c,d=self.unit,self.calc,self.calcAlone
if c and a.try(f,UnitGetDetailedHealPrediction,e,"player",c)then
b.heals=i(c.GetIncomingHeals,c)
b.absorbs=i(c.GetDamageAbsorbs,c)
b.healAbsorbs=i(c.GetHealAbsorbs,c)
else
b.heals,b.absorbs,b.healAbsorbs=false,false,false
end
if d and a.try(f,UnitGetDetailedHealPrediction,e,"player",d)then
b.absorbsAlone=i(d.GetDamageAbsorbs,d)
if not c then b.healAbsorbs=i(d.GetHealAbsorbs,d)end
else
b.absorbsAlone=false
end
end






local function p(b,a)
if b=="none"then return a~="none"and"appears"or nil end
if b=="alive"then return a=="dead"and"dies"or a=="none"and"leaves"or nil end
return nil
end
local i={}
local a

local function f(a,b)return UnitHealthPercent(a.unit,false,b)end



function e:read(e)
local b=self.unit
local d=l(b)
if d~=self.state then
self.state=d
self.element:setState(d)
e=true
if self.settled~=nil then c.atFrameEnd(i[b],a,b)end
end
local a=self.data
a.snap=e==true
if d=="alive"then
a.amount=h("UnitHealth",UnitHealth,b)
a.max=h("UnitHealthMax",UnitHealthMax,b)
a.percent=h("UnitHealthPercent",UnitHealthPercent,b,false,o)
a.sample=f
a.missing=h("UnitHealthMissing",UnitHealthMissing,b)
a.shields=h("UnitGetTotalAbsorbs",UnitGetTotalAbsorbs,b)
self:predict(a)
else

if d=="dead"then
a.amount,a.percent=0,0
a.max=h("UnitHealthMax",UnitHealthMax,b)
else
a.amount,a.percent,a.max=false,false,false
end
a.missing,a.sample=a.max,false
a.shields,a.heals,a.absorbs,a.absorbsAlone,a.healAbsorbs=false,false,false,false,false
end
self.element:feed(a)
self:light()
end




local h="health level gate"
function e:light()
b.lightLevels(self.element.element,self.gates,h,d[self]and self.state=="alive",f,self)
end

function e:regate()self:light()end


local function f(a,c)
a:read(false)
local b=p(a.settled,a.state)
a.settled=a.state
if b and not c then a.element:moment(b)end
end
function a(c)
local e=n.isQuiet(nil)
for a in pairs(d)do
if a.unit==c and a.settled~=nil then b.try(a,f,e)end
end
end
g.settle=a

local function a(a,c)
for a in pairs(d)do
if a.unit==c then b.try(a,a.read,false)end
end
end
g.onHealth=a
local p={UNIT_HEALTH=a,UNIT_MAXHEALTH=a,UNIT_ABSORB_AMOUNT_CHANGED=a,
UNIT_HEAL_ABSORB_AMOUNT_CHANGED=a,UNIT_HEAL_PREDICTION=a}

local function f()
for a in pairs(d)do b.try(a,a.read,false)end
end

local function q()c.atFrameEnd("health source modifiers",f)end




local n={}
local function h(c)
for a in pairs(d)do
if a.unit==c then b.try(a,a.read,true)end
end
end
local function r(a)
if next(d)==nil then return end
h(a)
c.atFrameEnd(n[a],h,a)
end

k.onStart("health source",f)
k.onEnd("health source",f)



local f={}







local k={target=true,focus=true}
local s={focus=true}
local t={UNIT_HEALTH=true,UNIT_FLAGS=true}
local h={}
local function o(c)
for a in pairs(d)do
if a.unit==c and l(c)~=a.state then b.try(a,a.read,true)end
end
end
local function l(d,b)
a(d,b)
c.atFrameEnd(h[b],o,b)
end
local function u()
for a in pairs(k)do
if f[a]then c.atFrameEnd(h[a],o,a)end
end
end

local function a(a,b)
if(f[a]or false)==b then return end
f[a]=b
local e="health source "..a

if b then
n[a]=e
h[a]="health source death "..a
j.onChange(a,"health source",r)
end
local g=s[a]
for d,f in pairs(p)do
if g and t[d]then f=l end
if b then c.onUnit(d,a,e,f)else c.offUnit(d,e)end
end
if g then
if b then c.onUnit("UNIT_FLAGS",a,e,l)else c.offUnit("UNIT_FLAGS",e)end
end
if b then
c.on("UNIT_MAX_HEALTH_MODIFIERS_CHANGED","health source",q)
elseif not next(d)then
c.off("UNIT_MAX_HEALTH_MODIFIERS_CHANGED","health source")
end
if b and k[a]then
c.on("UNIT_DIED","health source",u)
elseif not b and not(f.target or f.focus)then
c.off("UNIT_DIED","health source")
end
end



function g.build(h,c,a,f)
if f then f:release()end
local d=setmetatable({element=h,view=a,rig=c,unit=c.unit,data={}},e)

local a=d.data
a.by,a.amount,a.max,a.percent,a.missing,a.sample,a.snap=d,false,false,false,
false,false,false
a.heals,a.absorbs,a.absorbsAlone,a.healAbsorbs,a.shields=false,false,false,false,false
b.plainBuild(d,h,c,f)
d.gates=b.levelGates(c)

local a=g.variants["health:"..c.unit]
d.moments=a~=nil and next(a.events)~=nil
if d.moments then i[c.unit]=i[c.unit]or"health source moments "..c.unit end
local a=c.overlays

if a and(a.heals or a.chained or(a.healAbsorbs and not a.alone))then
d.calc=m(f and f.calc,false)
end
if a and a.alone then d.calcAlone=m(f and f.calcAlone,true)end
return d
end

function e:paint()
b.plainPaint(self)
end


function e:start()
d[self]=true
a(self.unit,true)
self.state,self.settled=nil,nil
self:read(true)
if self.moments then self.settled=self.state end
end

function e:stop()
d[self]=nil
self:light()
for a in pairs(d)do
if a.unit==self.unit then return end
end
a(self.unit,false)
end

function e:release()
self:stop()
self.host:Hide()
end


function e:refeed()
if d[self]then self:read(true)end
end

function e:describe()
return string.format("health %s: %s%s%s",self.unit,tostring(self.state),
self.rig.lowKey and string.format(", Low at %s%%",tostring(self.rig.low))or"",
self.rig.overlays and(self.calc or self.calcAlone)==nil and", no heal prediction"or"")
end

g.live=d
