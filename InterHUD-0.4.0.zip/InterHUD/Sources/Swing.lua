


local b,a=...
local e,g,i,c,j,k,a,l=a.Sources,a.Schema,a.Layers,a.SwingWatch,a.Quiet,a.Weapons,
a.Debug,a.Events

a.experimental("a swing's bar and texts fed one duration object a hand, set again at each swing from its plain length"
.." (CA-8 proves the length plain; A5 has the call; an object set again under bars already fed it is unseen, so"
.." each swing feeds them again)","I")

local h={"main","off","ranged"}
local m={main="Main hand",off="Off hand",ranged="Ranged"}
local d={main="swing",off="offhandswing",ranged="rangedswing"}
local a={main="main hand",off="off hand",ranged="ranged"}
local b=132223
local f=2.6

e.register("swing",{
experimental=true,
fields={
{name="hand",type="choice",choices=h,default="main",labels=m,label="Hand",
help="Ranged is a bow's, gun's or wand's shots."},
},
idWord=function(a)return d[a.hand]or d.main end,
noteWord=function(b)return a[b.hand]or a.main end,
nothingToPick=true,
variantOrder={"swing"},
variants={
swing={
add={label="Swing",note="The time to your next auto attack"},
noun="your swing",
read="lua",moment="plain",
stateOrder={"swinging","due","none"},
states={
swinging={label="Swinging",holds="You have attacked with this hand and the time to its next attack is"
.." running."},
due={label="Due",holds="The time to this hand's next attack has run out and it has not attacked"
.." since, for example because your target is out of range."},
none={label="None",holds="InterHUD has not seen this hand attack since you logged in, reloaded or"
.." changed weapons."},
},
eventOrder={"swings","comesDue"},
events={
swings={label="Swings",holds="this hand attacks",begins="swinging"},
comesDue={label="Comes due",holds="this hand's next attack comes due",begins="due"},
},
typical="swinging",
},
},
})

local d=e.get("swing")

function d.words(b)
return"Swing, "..(a[b and b.hand]or a.main)
end
function d.icon(a)
local a=a and a.hand or"main"
return(a~="ranged"and k.textureOf(a))or b
end



g.caveat("swing speed change",{
text="If your attack speed changes in the middle of a swing, for example when Flurry starts, the bar is right"
.." again from your next swing.",
at=function(a)return g.isPath(a,"sources","*","enabled")end,
applies=function(a,b)
local a=type(a.sources)=="table"and a.sources[b[2]]
return type(a)=="table"and a.kind=="swing"
end,
})


function d.preview(c,a)
local a=a and a.state
if a=="swinging"then return{icon=b,length=f,marks=f}end
if a=="due"then return{icon=b,length=false,marks=f}end
return{icon=b,length=false,full=false,marks=false}
end

function d.plan(a)
local b={kind="swing",parts=i.allParts(a,nil)}
e.planCopies(a,b)
return b
end


local b={}
local function i(c,d,e)
local a=b[c]
if not a then
a=C_DurationUtil.CreateDuration()
b[c]=a
end
a:SetTimeFromStart(e,d)
return a
end

local g={}
local b={}
for c,a in ipairs(h)do b[a]={}end
local f=0

local a={}
a.__index=a



function a:feed()
local a=self.data
local b,e,f=c.state(self.hand)
a.icon=d.icon(self.view.source)
if b and GetTime()<f then
a.full=nil
a.duration=i(self.hand,b,e)
a.length=b
g[self.hand]=b
elseif c.phase(self.hand)~=nil then


a.duration,a.full=false,nil
a.length=g[self.hand]or false
else

a.duration,a.full,a.length=false,false,false
g[self.hand]=nil
end
self.element:feed(a)
end


function a:read(e,d)
local b=self.state
local a=c.phase(self.hand)or"none"
if a~=b then
self.state=a
self.element:setState(a)
end
self:feed()
if not e or b==nil or j.isQuiet(nil)then return end

if d=="swing"then
self.element:moment("swings")
elseif d=="due"and a~=b then
self.element:moment("comesDue")
end
end


local function g(a,d,f,g,c)
local b=b[d]
if not b or a=="clear"and c=="ran out"then return end
local d=a
if a=="swing"and c~=nil then d="restart"end
for a in pairs(b)do e.try(a,a.read,true,d)end
end

function d.build(d,f,g,c)
if c then c:release()end
local h=g.source.hand
local a=setmetatable({element=d,view=g,rig=f,data={},
hand=b[h]and h or"main"},a)
e.plainBuild(a,d,f,c)
return a
end

function a:paint()
e.plainPaint(self)
end

function a:start()
c.onChange("swing source",g)
c.watch("swing source")
if not b[self.hand][self]then
b[self.hand][self]=true
f=f+1
end
self.state=nil
self:read(false)
end



local function e()
if f==0 then
c.unwatch("swing source")
c.offChange("swing source")
end
end
function a:stop()
if not b[self.hand][self]then return end
b[self.hand][self]=nil
f=f-1
if f==0 then l.atFrameEnd("swing source",e)end
end

function a:release()
self:stop()
self.host:Hide()
end

function a:refeed()
if b[self.hand][self]then self:feed()end
end

function a:describe()
local b,c,a=c.state(self.hand)
return string.format("swing %s: %s%s",self.hand,tostring(self.state),
a and string.format(", %.1f s left",a-GetTime())or"")
end

d.live=b
