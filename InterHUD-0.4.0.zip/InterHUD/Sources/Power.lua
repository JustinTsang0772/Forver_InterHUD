




local a,c=...
local a,l,g,m,n,b=c.Sources,c.Layers,c.Events,c.Units,c.Combat,c.Debug








b.experimental("energy on a rogue and in Cat Form, and a bar through a form's change at UNIT_DISPLAYPOWER (UN-15: a"
.." shaman's and a warrior's reads; energy unread, a form unseen: EP-15, EP-20)","D")
b.experimental("rage and energy through UnitPowerPercent's curve for a percent (UN-15: rage's output secret and"
.." drawn by no test of ours; energy's unread: EP-15)","I")
b.experimental("your target's power: UnitPowerType, UnitPower and UnitPowerMax on the target fed to a bar and its"
.." texts, UnitPowerPercent through ScaleTo100 on it, its own events through RegisterUnitEvent, Hidden held where"
.." its type reads secret, a type picked settled by its shown type where its maximum is secret (UN-20: the docs"
.." only: EP-66)","D")
b.experimental("your pet's power: UnitPowerType plain, Mana, Energy or Focus, UnitPower secret and UnitPowerMax"
.." plain on it, handed on as read, its own events through RegisterUnitEvent on pet, read again at UNIT_PET for you"
.." and PET_UI_UPDATE, Hidden held where its type reads secret, at rest and in a fight (UN-21: the docs; a pet"
.." player-controlled I: EP-26)","D")
b.experimental("your focus target's power as your target's: UnitPowerType, UnitPower and UnitPowerMax on it fed to"
.." a bar and its texts, its own events through RegisterUnitEvent on focus, read again at PLAYER_FOCUS_CHANGED,"
.." Hidden held where its type reads secret (UN-22: the docs, UN-20's predicates by token: EP-73, EP-66)","D")
b.experimental("your cast's cost on a bar's Cost part: C_Spell.GetSpellPowerCost's entry of the type shown, read at"
.." UNIT_SPELLCAST_START and kept by castGUID until that cast's STOP, SUCCEEDED, FAILED or INTERRUPTED, handed to"
.." the bar as read (CA-2: plain at START in a fight, T 70009; a secret one goes to the bar alone; the strip on a"
.." Lua-fed fill's edge in a fight, the bar clipping it: FR-41, EP-68; the events' order in a fight: EP-17)","C")
b.experimental("power's Low and Full: a Step curve on UnitPowerPercent into each gate's alpha and the mirrored curve"
.." into its complement's, sampled at every read, lit plainly outside Mana, Rage and Energy (A6, UN-3: an under-N%"
.." alpha T 70338; a Step curve's cut, Full's exact top and the complement unrecorded: FR-42, EP-69; on your target"
.." as its power is: UN-20, EP-66)","I")

local b=Enum.PowerType


local d={mana=b.Mana,rage=b.Rage,energy=b.Energy,focus=b.Focus}
local p={[b.Mana]="mana",[b.Rage]="rage",[b.Energy]="energy",[b.Focus]="focus"}
local q={MANA="mana",RAGE="rage",ENERGY="energy",FOCUS="focus"}
local r=CurveConstants and CurveConstants.ScaleTo100 or l.curve({0,0,1,100})

local s={"mana","rage","energy","none"}

local t={"mana","energy","focus","none","hidden"}





local i={name="share",type="percent",default=30,min=1,max=99,label="Share",said="%s or under",
help="Low holds while the power is at or under this share of its maximum."}

local function e(a)
return{
low={label="Low",holds="The power is at or under its \"Share\".",read="gate",max=1,within=a,
setting={c.copy(i)},default=function()return{}end},
full={label="Full",holds="The power is full.",read="gate",max=1,within=a,setting={},
default=function()return{}end},
}
end
local b,j={"low","full"},e({"mana","rage","energy"})
local u=e({"mana","energy","focus"})

local v={shown="shown power",mana="mana",rage="rage",energy="energy",focus="focus"}

local f={
player="Your power isn't mana, rage or energy.",
target="No target, or its power isn't mana, rage or energy.",
pet="You have no pet out, or its power isn't mana, energy or focus.",
focus="No focus target, or its power isn't mana, rage or energy.",
}
local function e(a)


local b=a=="target"and{"hostileTarget"}or nil
local c={
mana={label="Mana",holds="The bar shows mana.",scene=b},
energy={label="Energy",holds="The bar shows energy.",scene=b},
none={label="None",holds=f[a]},
}
if a=="pet"then
c.focus={label="Focus",holds="The bar shows focus."}
else
c.rage={label="Rage",holds="The bar shows rage.",scene=b}
end

if a~="player"then
c.hidden={read="held",label="Hidden",holds="The game hides this power.",scene=b}
end
return c
end

local function f(a,b)
local a=a and a.type or"shown"
return a=="shown"or not d[b]or b==a
end

local function k(b,a)return a~="cost"end


local w={"shown","mana","rage","energy"}
local x={"shown","mana","energy","focus"}
local y={focus="Focus is your pet's power, so it is offered only where \"Watches\" is \"Your pet\"."}
local z={rage="No pet has rage, so Rage isn't offered where \"Watches\" is \"Your pet\"."}

local o={player="your",target="target",pet="pet",focus="focus"}
local h="Mana, rage, energy or a pet's focus"

a.register("power",{
experimental=true,
fields={
{name="unit",type="unit",units=m.TOKENS,default="player",label="Watches"},
{name="type",type="choice",default="shown",
choicesFrom=function(a)
if a.unit=="pet"then return x,z end
return w,y
end,
labels={shown="Shown power",mana="Mana",rage="Rage",energy="Energy",focus="Focus"},
label="Type",help="\"Shown power\" is the one the game shows, so a druid's follows the form."},
},
variantOf=function(a)return"power:"..(a.unit or"player")end,


idWord=function(a)
return(o[a.unit]or o.player)..(d[a.type]and a.type or"power")
end,

noteWord=function(a)return v[d[a.type]and a.type or"shown"]end,
nothingToPick=true,
variantOrder={"power:player","power:target","power:pet","power:focus"},
variants={
["power:player"]={
add={label="Power",note=h},
unit="player",noun="your power",
read="lua",moment="plain",
stateOrder=s,states=e("player"),
factOrder=b,facts=j,
offersState=f,
typical="mana",
},

["power:target"]={
add={label="Power",note=h,listed=false},
unit="target",noun="your target's power",
read="lua",moment="plain",
stateOrder={"mana","rage","energy","none","hidden"},states=e("target"),
factOrder=b,facts=j,
offersState=f,offersPart=k,
typical="mana",
},
["power:pet"]={
add={label="Power",note=h,listed=false},
unit="pet",noun="your pet's power",
read="lua",moment="plain",
stateOrder=t,states=e("pet"),
factOrder=b,facts=u,
offersState=f,offersPart=k,
typical="focus",
},

["power:focus"]={
add={label="Power",note=h,listed=false},
unit="focus",noun="your focus target's power",
read="lua",moment="plain",
stateOrder={"mana","rage","energy","none","hidden"},states=e("focus"),
factOrder=b,facts=j,
offersState=f,offersPart=k,
typical="mana",
},
},
})

local f=a.get("power")

local b="Power"
function f.words()return b end



local b={mana={3200,4000,80,600},rage={40,100,40,20},energy={70,100,70,30},
focus={80,100,80,0}}
function f.preview(c,d)
local b=b[d and d.state]
if not b then return{length=false,amount=false,max=false,percent=false,cost=false}end
local e=d.facts or{}
local d=a.firstItem(c,"low")
local a=a.firstItem(c,"full")
local a=a and e[a.id]and 100 or d and e[d.id]and(d.share or i.default)
or b[3]
return{length=false,amount=b[2]*a/100,max=b[2],percent=a,
cost=(c.unit or"player")=="player"and b[4]or false}
end



local function h(a,b)
if(a.source.unit or"player")~="player"then return nil end
for c,a in ipairs(a.layers)do
if a.source==b and a.kind=="bar"and a.value=="amount"and a.enabled~=false
and type(a.cost)=="table"and a.cost.enabled~=false then
return true
end
end
end



function f.plan(e)
local b=e.source
local c={kind="power",unit=b.unit or"player",want=d[b.type]and b.type or"shown",
parts=l.allParts(e,nil),cost=h(e,b.id)}
a.planCopies(e,c)
local d=a.firstItem(b,"low")
if d then c.low,c.lowKey=d.share or i.default,b.id.."."..d.id end
local a=a.firstItem(b,"full")
if a then c.fullKey=b.id.."."..a.id end
return c
end

local h,i=a.readLevel,a.unitPresent






local function e(b,d)
local e,a=c.try("UnitPowerType",UnitPowerType,b)
if not e then return"none",nil end
if c.isSecret(a)then return b~="player"and"hidden"or"none",nil end
local b=a~=nil and p[a]
if not(b and d[b])then return"none",nil end
return b,a
end

local function b(a,b,f)
if not i(a)then return"none",nil end
local d=d[b]
if not d then return e(a,f)end
local g=h("UnitPowerMax",UnitPowerMax,a,d)
if not c.isSecret(g)then
if g==0 then return"none",nil end
return b,d
end
local a=e(a,f)
if a=="hidden"then return a,nil end
if a~=b then return"none",nil end
return b,d
end

local e={}
local d={}
d.__index=d


local function i(a,b)return UnitPowerPercent(a.unit,a.ptype,false,b)end



function d:read(d)
local c=self.unit
local a,b=b(c,self.want,self.has)
if a~=self.state then
self.state=a
self.element:setState(a)
self.element:hold(a=="hidden")
d=true
end
self.ptype=b
local a=self.data
a.snap=d==true

if b and b==self.costType then a.cost=self.cost else a.cost=false end
if b then
a.amount=h("UnitPower",UnitPower,c,b)
a.max=h("UnitPowerMax",UnitPowerMax,c,b)
a.percent=h("UnitPowerPercent",UnitPowerPercent,c,b,false,r)
a.sample=i
else
a.amount,a.max,a.percent,a.sample=false,false,false,false
end
self.element:feed(a)
self:light()
end




local b="power level gate"
function d:light()
a.lightLevels(self.element.element,self.gates,b,e[self]and self.ptype~=nil,i,self)
end

function d:regate()self:light()end


local function h(b,a)
if c.isSecret(a)or type(a)~="string"then return true end
local a=q[a]
return a~=nil and(b.want=="shown"or b.want==a)
end
local function b(b,c,d)
for b in pairs(e)do
if b.unit==c and h(b,d)then a.try(b,b.read,false)end
end
end

local function h(b,c)
for b in pairs(e)do
if b.unit==c then a.try(b,b.read,true)end
end
end
f.onPower=b
local l={UNIT_POWER_FREQUENT=b,UNIT_MAXPOWER=b,UNIT_DISPLAYPOWER=h}



local i={}
local function b(a)h(nil,a)end
local function o(a)
if next(e)==nil then return end
b(a)
g.atFrameEnd(i[a],b,a)
end

local function b()
for b in pairs(e)do a.try(b,b.read,false)end
end
n.onStart("power source",b)
n.onEnd("power source",b)





local b={}
local n={"UNIT_SPELLCAST_START","UNIT_SPELLCAST_STOP","UNIT_SPELLCAST_SUCCEEDED",
"UNIT_SPELLCAST_FAILED","UNIT_SPELLCAST_INTERRUPTED"}

function d:takeCost()
if b.spell and self.ptype then
self.cost,self.costType=a.powerCost(b.spell,self.ptype),self.ptype
else
self.cost,self.costType=false,nil
end
end
local function p(c)
for b in pairs(e)do
if b.rig.cost then a.try(b,c)end
end
end
local function h(a)
a:takeCost()
a:read(false)
end
local function j(a,b)
return not c.isSecret(a)and type(a)=="string"and not c.isSecret(b)and type(b)=="number"
end
local function k(e,f,a,d)
if e=="UNIT_SPELLCAST_START"then
if j(a,d)then b.guid,b.spell=a,d else b.guid,b.spell=nil,nil end
elseif b.guid==nil or c.isSecret(a)or a~=b.guid then
return
else
b.guid,b.spell=nil,nil
end
p(h)
end
f.onCast=k

local function p()
b.guid,b.spell=nil,nil
local f,a,g,h,i,k,l,d,m,e=c.try("UnitCastingInfo",UnitCastingInfo,"player")
if f and not c.isSecret(a)and a~=nil and j(d,e)then b.guid,b.spell=d,e end
end

local c=false
local function j()
local a=false
for b in pairs(e)do
if b.rig.cost then a=true end
end
if a==c then return end
c=a
for c,b in ipairs(n)do
if a then g.onUnit(b,"player","power source cost",k)else g.offUnit(b,"power source cost")end
end
if a then p()else b.guid,b.spell=nil,nil end
end


local c={}
local function k(a,b)
if(c[a]or false)==b then return end
c[a]=b
local c="power source "..a

if b then
i[a]=c
m.onChange(a,"power source",o)
end
for d,e in pairs(l)do
if b then g.onUnit(d,a,c,e)else g.offUnit(d,c)end
end
end


function f.build(g,c,b,e)
if e then e:release()end
local d=setmetatable({element=g,view=b,rig=c,unit=c.unit,want=c.want,
has=f.variants["power:"..c.unit].states,data={}},d)

local b=d.data
b.by,b.amount,b.max,b.percent,b.sample,b.cost,b.snap=d,false,false,false,false,
false,false
a.plainBuild(d,g,c,e)
d.gates=a.levelGates(c)
return d
end


function d:paint()
a.plainPaint(self)
self.element:hold(self.state=="hidden")
end


function d:start()
e[self]=true
k(self.unit,true)
j()
self.state,self.cost,self.costType=nil,false,nil
self:read(true)

if self.rig.cost and b.spell then h(self)end
end

function d:stop()
e[self]=nil
self:light()
j()
for a in pairs(e)do
if a.unit==self.unit then return end
end
k(self.unit,false)
end

function d:release()
self:stop()
self.host:Hide()
end


function d:refeed()
if e[self]then self:read(true)end
end

function d:describe()
return string.format("power %s (%s): %s%s%s",self.unit,self.want,tostring(self.state),
self.rig.lowKey and string.format(", Low at %s%%",tostring(self.rig.low))or"",self.rig.cost and", Cost"or"")
end

f.live=e
