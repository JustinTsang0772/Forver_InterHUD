


local a,b=...
local d,c,o,h,p,f=b.Schema,b.Events,b.Spells,b.Store,b.Ticker,b.Debug

local a={}
b.Weapons=a


f.experimental("a hand's item and its picture read in combat (GetInventoryItemID, GetInventoryItemTexture: IT-2's"
.." item read, plain in combat; ShamanForever ships it too)","T 70425")
f.experimental("an enchant ID learned at your cast: one new or reapplied on a hand within 3 s of it, either way"
.." round, read at WEAPON_ENCHANT_CHANGED, UNIT_INVENTORY_CHANGED or the second's read (IT-2's events at an imbue"
.." cast and at a stone; ShamanForever's imbueIDs)","T 70425")
f.experimental("a hand's item class read in combat (C_Item.GetItemInfoInstant on the equipped item's ID: no row;"
.." the fishing pole's class 2, subclass 20 from Blizzard's item documentation)","C")
f.experimental("an enchant's run-out seen by the second's read while watched (no event recorded at it: EP-39)","I")




a.IMBUES={
[8017]={ids={29,6,1,503,1663,683,1664},school="earth",length=3600},
[8024]={ids={5,4,3,523,1665,1666},school="fire",length=3600},
[8033]={ids={2,12,524,1667,1668},school="water",length=3600},
[8232]={ids={283,284,525,1669},school="air",length=3600},
}
a.OTHER_LENGTH=1800


local e=Enum and Enum.WeaponSlot or{}
a.HANDS={
main={slot=e.MainHand or 0,inv=16},
off={slot=e.OffHand or 1,inv=17},
}
local i={"main","off"}
local e=Enum and Enum.ItemEnchantType and Enum.ItemEnchantType.Imbue or 3

local j=3
local q=100





d.record("weaponEnchantLearned",{fields={
{name="cast",type="integer",required=true,min=1,max=99999999},
{name="id",type="integer",required=true,min=1,max=99999999},
}})
d.record("weaponCaches",{fields={
{name="enchants",type="list",record="weaponEnchantLearned",maxItems=q},
}})
d.record("caches",{fields={{name="weapon",type="record",record="weaponCaches"}}})


local k={}
for a,b in pairs(a.IMBUES)do
for c,b in ipairs(b.ids)do k[b]=a end
end
local g,d={},false
local function r()
local a=h.caches()
if not a then return nil end
a.weapon=a.weapon or{}
return a.weapon
end
local function l()
if d then return end
local a=r()
if not a then return end
d=true
for b,a in ipairs(a.enchants or{})do g[a.id]=a.cast end
end


function a.keyOf(a)
if type(a)~="number"or b.isSecret(a)then return nil end
return(o.family(a))or a
end





function a.read(c)
local a=a.HANDS[c]
if not(a and C_Item and C_Item.GetWeaponEnchantInfo)then return nil end
local c,a=b.try("weapon enchant read",C_Item.GetWeaponEnchantInfo,a.slot)
if not c or b.isSecret(a)or type(a)~="table"then return nil end
local c={}
for d,a in ipairs(a)do
if b.isSecret(a)or b.isSecret(a.hasEnchant)or b.isSecret(a.enchantType)or b.isSecret(a.enchantID)
or b.isSecret(a.timeLeft)or b.isSecret(a.charges)or b.isSecret(a.enchantIconID)then
return nil
end
if a.hasEnchant and type(a.enchantID)=="number"and a.enchantID>0 then
c[#c+1]={id=a.enchantID,imbue=a.enchantType==e,
left=type(a.timeLeft)=="number"and a.timeLeft/1000 or 0,
charges=type(a.charges)=="number"and a.charges or 0,icon=a.enchantIconID}
end
end
return c
end


function a.keyOfEnchant(b)
l()
local c=k[b.id]or g[b.id]
if c then return c end
if b.imbue and b.icon then
for a in pairs(a.IMBUES)do
if b.icon==C_Spell.GetSpellTexture(a)then return a end
end
end
return nil
end



function a.imbue(b)
local b=a.read(b)
if not b then return nil end
for c,b in ipairs(b)do
if b.imbue then return a.keyOfEnchant(b)or"unknown",b.id end
end
return false
end


function a.itemOf(c)
local a=a.HANDS[c]
if not(a and GetInventoryItemID)then return false end
local c,a=b.try("weapon item read",GetInventoryItemID,"player",a.inv)
if not c or b.isSecret(a)then return false end
return a
end

function a.textureOf(c)
local a=a.HANDS[c]
if not(a and GetInventoryItemTexture)then return nil end
local c,a=b.try("weapon texture read",GetInventoryItemTexture,"player",a.inv)
if c and a~=nil and not b.isSecret(a)then return a end
end





local d,e=2,20
function a.canEnchant(c)
local a=a.itemOf(c)
if a==false then return true end
if a==nil then return false end
if not(C_Item and C_Item.GetItemInfoInstant)then return true end
local f,g,h,i,j,k,a,c=b.try("weapon class read",C_Item.GetItemInfoInstant,a)
if not f or type(a)~="number"or b.isSecret(a)or b.isSecret(c)then return true end
return a==d and c~=e
end



local m,d,e={},{},{}
local function s()
local c=GetTime()
for f,b in ipairs(i)do
local a=a.itemOf(b)
if a~=false then
if d[b]and a~=m[b]then e[b]=c end
d[b],m[b]=true,a
end
end
end
function a.itemChangedAt(a)return e[a]or-math.huge end







local d={}
local h
local t={}
local e={}
function a.learnFor(b,a)
for c,a in pairs(d)do
a[b]=nil
if not next(a)then d[c]=nil end
end
for c,a in ipairs(a or{})do
d[a]=d[a]or{}
d[a][b]=true
end
end

local u=1
local function n()
local d=GetTime()
for a=#e,1,-1 do
if d-e[a].at>j then table.remove(e,a)end
end
for c,b in ipairs(i)do
local a=a.read(b)
if a then
local c,f=t[b],{}
for g,a in ipairs(a)do
f[a.id]=a.left
if c and(c[a.id]==nil or a.left>c[a.id]+u)then
e[#e+1]={hand=b,id=a.id,imbue=a.imbue,at=d}
end
end
t[b]=f
end
end
end
local function t(b,c)
g[b]=c
local a=r()
if a then
a.enchants=a.enchants or{}
a.enchants[#a.enchants+1]={cast=c,id=b}
while#a.enchants>q do table.remove(a.enchants,1)end
end
end
local function q()
local b=h
if not b then return false end
if GetTime()>b.at+j then
h=nil
return false
end
l()


local c=a.IMBUES[b.key]~=nil
for d,a in ipairs(e)do
if math.abs(a.at-b.at)<=j and a.imbue==c then
local c=k[a.id]or g[a.id]
if c==b.key then
h=nil
return false
elseif c==nil then
t(a.id,b.key)
h=nil
return true
end
end
end
return false
end



local b=b.keyed("weapons")
function a.onChange(a,c)b:add(a,c)end
function a.offChange(a)b:remove(a)end

local function e()
s()
n()
if q()then b:call("learned")end
b:call("enchant")
end


c.onUnit("UNIT_SPELLCAST_SUCCEEDED","player","weapons",function(e,f,g,c)
local c=a.keyOf(c)
if not c or not(a.IMBUES[c]or d[c])then return end
n()
h={key=c,at=GetTime()}
if q()then b:call("learned")end
b:call("cast",c)
end)


c.on("WEAPON_ENCHANT_CHANGED","weapons",e)
c.onUnit("UNIT_INVENTORY_CHANGED","player","weapons",e)
c.on("PLAYER_EQUIPMENT_CHANGED","weapons",e)



local d=3
local b=0
function a.zoning()return GetTime()<b end
c.on("PLAYER_LEAVING_WORLD","weapons",function()b=math.huge end)

c.on("PLAYER_ENTERING_WORLD","weapons",function()
b=GetTime()+d
n()
end)


local b={}
function a.watch(a)
if not next(b)then
s()
p.subscribe(1,"weapons",e)
end
b[a]=true
end
function a.unwatch(a)
b[a]=nil
if not next(b)then p.unsubscribe(1,"weapons")end
end


function a.describe()
if not next(b)then return{}end
l()
local c,d=0,0
for a in pairs(g)do c=c+1 end
for a in pairs(b)do d=d+1 end
local e={}
for b,c in ipairs(i)do
local d=a.read(c)
local b={}
for d,c in ipairs(d or{})do
local a=a.keyOfEnchant(c)
b[#b+1]=string.format("enchant %d (%s), %.0f s, %d charges",c.id,
a and(o.nameOf(a)or tostring(a))or"not recognised",c.left,c.charges)
end
e[#e+1]=c.." "..(d==nil and"unreadable"or#b==0 and"none"
or table.concat(b,"; "))..", item "..tostring(m[c])
end
return{string.format("weapons: %d watching, %d enchant IDs learned; %s",d,c,table.concat(e,"; "))}
end
f.register("weapons",a.describe)
