


local a,b=...
local h,i,d,l,m,k,a=b.Sources,b.Layers,b.Events,b.Quiet,b.Target,b.Combat,b.Debug








a.experimental("combo points read by GetComboPoints(\"player\", \"target\"), bound to your target and read again at"
.." PLAYER_TARGET_CHANGED and COMBO_TARGET_CHANGED (UN-18: Forever's own bar and the docs; which bar the client"
.." loads EP-62, a retarget and a transfer with points up unseen: EP-15)","D")
a.experimental("a combo count plain at rest and in a fight on a rogue and a Cat-Form druid, its states, Points"
.." items and moments read from it, Unknown where it reads secret (SE-2: ComboPoints NeverSecret; UN-15: a"
.." shaman's zeros; real points EP-15)","I")
a.experimental("combo moments only at a power event in a frame with no target change, transfer or death: Drops to"
.." none at any fall to none, a finisher's, a decay's or points lost alike, so it never claims a spend (a"
.." finisher-only Spent waits on EP-15's record of each fall's cause); a death's count read as the client gives it"
.." (CA-14: the event; the count after it unseen); a druid's points across a form's change (EP-20)","I")



local a=5
local e=Enum.PowerType and Enum.PowerType.ComboPoints

local g={"none","building","full","unknown"}

local c={"hostileTarget"}
local c={
none={label="None",holds="No combo points on your target."},
building={label="Building",holds="Some combo points, not yet full.",scene=c},
full={label="Full",holds="Your target holds all its combo points.",scene=c},
unknown={label="Unknown",holds="The game hides the count; the bar still shows it.",scene=c},
}





local function f(b)
if b.atMost then return 1,b.atMost end
local a=b.between
if type(a)=="table"and a[1]and a[2]then return math.min(a[1],a[2]),math.max(a[1],a[2])end
return b.atLeast or 1,nil
end


local j={label="Combo points",holds="Your target's count of your combo points is in a set range.",read="lua",max=4,

full="Combo points take at most %d of these.",
rule=h.oneRange,first=1,
finish=function(a,b)
if a.atLeast==nil and a.atMost==nil and a.between==nil then b.atLeast=1 end
end,
setting={
{name="atLeast",type="integer",min=1,max=10,label="At least",said="%s or more",
help="Holds while your target has at least this many of your combo points."},
{name="atMost",type="integer",min=1,max=10,label="At most",said="%s or fewer",
help="Holds while your target has some of your combo points, and at most this many."},
{name="between",type="list",of="integer",item={min=1,max=10},minItems=2,maxItems=2,
label="Between",help="Holds while your target has a count of your combo points from the first to the"
.." second, both included. The same number twice is exactly that many."},
}}
h.register("combo",{
experimental=true,
fields={},

idWord="yourcombo",

noteWord=function()return"on your target"end,
nothingToPick=true,
variantOrder={"combo"},
variants={
combo={
add={label="Combo points",note="On your target"},
noun="your combo points",
read="lua",moment="plain",
stateOrder=g,states=c,
factOrder={"points"},facts={points=j},



eventOrder={"gainsPoint","reachesFull","dropsToNone"},
events={
gainsPoint={label="Gains a combo point",holds="you gain a combo point",begins="building"},
reachesFull={label="Reaches full",holds="you reach full combo points",begins="full"},
dropsToNone={label="Drops to none",holds="your combo points fall to none",begins="none"},
},
typical="building",
},
},
})

local g=h.get("combo")

local c="Combo points"
function g.words()return c end



local c={none=0,building=3,full=a,unknown=3}
function g.preview(d,b)
local c=c[b and b.state]or 0
local g=b and b.facts or{}
local e=type(d.facts)=="table"and d.facts.points or nil
local b,d=0,a
for e,c in ipairs(type(e)=="table"and e or{})do
if c.enabled~=false and g[c.id]then
local c,e=f(c)
b,d=math.max(b,c),math.min(d,e or a)
end
end
if b>0 then c=math.max(b,math.min(c,d))end
return{length=false,amount=c,max=a}
end


function g.plan(b)
local c=b.source
local a={kind="combo",parts=i.allParts(b,nil),points={}}
h.planCopies(b,a)
local b=type(c.facts)=="table"and c.facts.points or nil
for c,b in ipairs(type(b)=="table"and b or{})do
if b.enabled~=false then
local c,d=f(b)
a.points[#a.points+1]={id=b.id,lo=c,hi=d or false}
end
end
return a
end


local function j(a)return not b.isSecret(a)and type(a)=="number"end


local function n()
if not GetComboPoints then return false end
local c,a=b.try("GetComboPoints",GetComboPoints,"player","target")
if not c then return false end
if b.isSecret(a)then return true,a end
return true,type(a)=="number"and a or 0
end
local function o()
if not(e and UnitPowerMax)then return a end
local c,b=b.try("UnitPowerMax",UnitPowerMax,"player",e)
if not c or not j(b)or b<=0 then return a end
return math.min(b,a)
end
local function p(a,b)
if not j(a)then return"unknown"end
if a<=0 then return"none"end
return a>=b and"full"or"building"
end





local a={n=0,max=a,state="none",play={}}
g.count=a
local c="combo source"

local f={}
local e={}
e.__index=e



function e:read(d)
local c,b=a.state,a.n
if c~=self.state then
self.state=c
self.element:setState(c)
end
local e=j(b)
local c=self.rig.points
for a=1,#c do
local a=c[a]
self.element:setFact(a.id,e and b>=a.lo and(not a.hi or b<=a.hi),d)
end
local c=self.data
c.amount,c.max,c.snap=b,a.max,true
self.element:feed(c)
if not d then return end
local a=a.play
if a.reachesFull then self.element:moment("reachesFull")end
if a.gainsPoint then self.element:moment("gainsPoint")end
if a.dropsToNone then self.element:moment("dropsToNone")end
end




local function i()
local b,c=n()
local d=a.power and not a.moved and not a.dead and not l.isQuiet(nil)
a.power,a.moved=nil,nil
if not b then
a.unread=true
return
end
a.unread=nil
local e,g=a.n,a.state
a.n,a.max=c,o()
a.state=p(c,a.max)
local b=a.play
b.gainsPoint,b.reachesFull,b.dropsToNone=nil,nil,nil
d=d and j(e)and j(c)
if d then
if c>e then
if a.state=="full"and g~="full"then b.reachesFull=true else b.gainsPoint=true end
elseif c<=0 and e>0 then
b.dropsToNone=true
end
end
for a in pairs(f)do h.try(a,a.read,d==true)end
end
g.settle=i



local function j(f,g,e)
if not b.isSecret(e)and type(e)=="string"and e~="COMBO_POINTS"then return end
a.power=true
d.atFrameEnd(c,i)
end
g.onPower=j

local function n(e,f,a)
if not b.isSecret(a)and type(a)=="string"and a~="COMBO_POINTS"then return end
d.atFrameEnd(c,i)
end

local function o()
a.moved=true
d.atFrameEnd(c,i)
end


m.onChange(c,function(e,b)
if b=="PLAYER_TARGET_DIED"then
a.dead=true
elseif b=="PLAYER_TARGET_CHANGED"then
a.dead=nil
else
return
end
a.moved=true
if next(f)==nil then return end
d.atFrameEnd(c,i)
end)

local function l()
if next(f)~=nil then d.atFrameEnd(c,i)end
end
k.onStart(c,l)
k.onEnd(c,l)


local function k(a)
if a then
d.onUnit("UNIT_POWER_FREQUENT","player",c,j)
d.onUnit("UNIT_MAXPOWER","player",c,n)
d.on("COMBO_TARGET_CHANGED",c,o)
else
d.offUnit("UNIT_POWER_FREQUENT",c)
d.offUnit("UNIT_MAXPOWER",c)
d.off("COMBO_TARGET_CHANGED",c)
end
end


function g.build(b,c,d,a)
if a then a:release()end
local d=setmetatable({element=b,view=d,rig=c,data={}},e)
h.plainBuild(d,b,c,a)
return d
end

function e:paint()
h.plainPaint(self)
end


function e:start()
local b=next(f)==nil
f[self]=true
if b then
k(true)
a.moved=true
i()
end
self.state=nil
self:read(false)
end

function e:stop()
f[self]=nil
if next(f)==nil then k(false)end
end

function e:release()
self:stop()
self.host:Hide()
end


function e:refeed()
if f[self]then self:read(false)end
end

function e:describe()
local c=a.n
local b=b.isSecret(c)and"secret"or tostring(c)
return string.format("combo: %s, %s of %s%s",tostring(self.state),b,tostring(a.max),
a.unread and", unreadable"or"")
end

g.live=f
