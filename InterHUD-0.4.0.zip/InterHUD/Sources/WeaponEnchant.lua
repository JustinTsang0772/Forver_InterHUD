

local a,e=...
local k,f,m,c,a,h,n,b=e.Schema,e.Sources,e.Layers,e.Spells,e.Weapons,e.LastSeen,
e.Quiet,e.Debug



b.experimental("a weapon enchant's time left fed as a duration made from its plain read (IT-2, A5), in combat","C")



local b={label="Expiring",holds="The enchant is in its last seconds or charges.",read="lua",within="present",max=1,
setting={

{name="seconds",type="number",min=1,max=600,step=1,unit="s",label="Seconds"},
{name="charges",type="integer",min=1,max=255,label="Charges"},
},
default=function()return{}end,

rule=function(a,b,c)
if a.seconds~=nil and a.charges~=nil then b:problem(c,"names both seconds and charges; keep one.")end
end,
finish=function(a,b)if a.seconds==nil and a.charges==nil then b.seconds=60 end end}

local l={"main","off"}
local d={main="Main hand",off="Off hand"}
local g={
{name="hand",type="choice",choices=l,default="main",labels=d,label="Hand"},

f.spellsField("Spells","Spell IDs of the imbues, poisons or stones that count; left out, any."),

{name="shownSpell",type="choice",choices={"first","lastSeen"},default="first",
labels={first="First",lastSeen="Last seen"},label="Shown spell",
help="Which one's icon while none is on.",
shownIf=function(b,a)return a~=nil and type(a.spells)=="table"and#a.spells>1 end},
}

f.register("weaponEnchant",{
fields=g,
idWord="enchant",
variantOrder={"weaponEnchant"},
variants={
weaponEnchant={
add={label="Weapon enchant",note="An imbue, poison or stone on a hand"},
noun="an enchant",
read="lua",moment="plain",
stateOrder={"present","missing"},
states={
present={label="Present",holds="An enchant that counts is on the weapon."},
missing={label="Missing",holds="No enchant that counts is on the weapon."},
},
factOrder={"expiring"},facts={expiring=b},
eventOrder={"arrived","removed"},
events={
arrived={label="Arrived",holds="it's put on",begins="present"},
removed={label="Removed",holds="it goes",begins="missing"},
},
},
},
})

local b=f.get("weaponEnchant")


b.matches=f.get("spell").matches
local i="Interface\\Icons\\INV_Sword_04"

local function g(a)return c.listOf(a and a.spells)end



function b.learned(a)
local a=g(a)
if#a==0 then return true end
for b,a in ipairs(a)do
if c.family(a)==nil or c.known(a)then return true end
end
return false
end


function b.yourSpells(a)
local a=g(a)
for b,a in ipairs(a)do
if c.family(a)==nil then return{}end
end
return a
end


function b.shownSpell(b)
local a=g(b)
if#a==0 then return nil end
if b.shownSpell=="lastSeen"and#a>1 then
local a=h.get(a)
if a then return a end
end
for b,a in ipairs(a)do
if c.known(a)then return a end
end
return a[1]
end


local function j(a)
local d,b=c.highest(a)
return b or(a and c.icon(a))or nil
end


function b.icon(c)
if not c then return nil end
local b=b.shownSpell(c)
return b and j(b)or a.textureOf(c.hand or"main")or i
end

function b.words(a)
if not a then return nil end
local d=d[a.hand or"main"]or d.main
local b={}
for d,a in ipairs(g(a))do b[d]=c.label(a)or tostring(a)end
if#b==0 then return d..", any enchant"end
return table.concat(b," or ")..", "..d:lower()
end




b.pickWords="Pick its enchant."
function b.addChoices(e,g)
local f=e and e~=""and e:lower()or nil
local b={}
for e,c in ipairs(l)do
local d=d[c]..", any enchant"
if not f or d:lower():find(f,1,true)then
b[#b+1]={id="hand:"..c,name=d,icon=a.textureOf(c)or i,
note="Any imbue, poison or stone"}
end
end
local d={}
for a in pairs(a.IMBUES)do
local b=c.nameOf(a)
if b and c.known(a)and(not f or b:lower():find(f,1,true)or tostring(a)==e)then
d[#d+1]={id=a,name=b,icon=j(a),note="Main hand"}
end
end
table.sort(d,function(a,b)return a.name<b.name end)
for c,a in ipairs(d)do
if#b<(g or 30)then b[#b+1]=a end
end
return b
end
function b.addRecord(a)
local b=type(a)=="string"and a:match("^hand:(%a+)$")
if b then
if not d[b]then return nil end
return{kind="weaponEnchant",hand=b},d[b]
end
if type(a)~="number"then return nil end
return{kind="weaponEnchant",hand="main",spells={a}},c.label(a)
end



function b.preview(e)
local d=b.shownSpell(e)
local f=d and a.IMBUES[a.keyOf(d)]
return{icon=b.icon(e),
name=d and c.label(d)or b.words(e),
length=f and f.length or a.OTHER_LENGTH}
end


k.caveat("weapon enchant from your cast",{
text="Recognised by its enchant: one not seen before is learned from your own cast of it.",
at=function(a)return k.isPath(a,"sources","*","spells")end,
applies=function(a,b)
local a=type(a.sources)=="table"and a.sources[b[2]]
return type(a)=="table"and a.kind=="weaponEnchant"
end,
})


function b.plan(a)
local b=a.source
local c={kind="weaponEnchant",hand=b.hand or"main",spells=b.spells,
parts=m.allParts(a,nil)}
f.planCopies(a,c)
local a=f.firstItem(b,"expiring")
if a then c.expiring={id=a.id,seconds=a.charges==nil and(a.seconds or 60)or nil,charges=a.charges}end
return c
end


local k=1
local l=0.5

local g={}
local d={}
d.__index=d




function d:counted(b)
for c,b in ipairs(b)do
if not self.keys then return b end
local a=a.keyOfEnchant(b)
if a and self.keys[a]then return b end
if not a and b.imbue and self.anyImbue then return b end
end
end


function d:expiring(a)
local b=self.rig.expiring
if not(a and b)then return false end
if b.charges then return a.charges>0 and a.charges<=b.charges end
return a.left>0 and a.left<=b.seconds
end



function d:feed(d)
local e,h=self.data,GetTime()
if d then
local f=a.keyOfEnchant(d)
local g=f and c.nameOf(f)and f or nil
local b=d.left>0 and h+d.left or nil
if d.id~=self.fedId or f~=self.fedKey then self.total=nil end
if b and(self.total==nil or d.left>self.total)then self.total=d.left end
local h=b~=nil and(self.fedEnds==nil or math.abs(b-self.fedEnds)>l)
if d.id==self.fedId and f==self.fedKey and not h and(b~=nil)==(self.fedEnds~=nil)then
return
end
self.fedId,self.fedKey,self.fedEnds=d.id,f,b
e.icon=g and j(g)or(type(d.icon)=="number"and d.icon>0 and d.icon)
or a.textureOf(self.hand)or i
e.name=g and c.label(g)or false
if b then
local a=C_DurationUtil.CreateDuration()
a:SetTimeFromStart(b-self.total,self.total)
e.duration=a
else
e.duration=false
end
else
if self.fedId==false then return end
self.fedId,self.fedKey,self.fedEnds,self.total=false,nil,nil,nil
local b=b.shownSpell(self.view.source)
e.icon=b and j(b)or a.textureOf(self.hand)or i
e.name=b and c.label(b)or false
e.duration=false
end
self.element:feed(e)
end






function d:read(g)
local b=a.read(self.hand)
if not b then
self.unreadable=true
return
end
self.unreadable=false

local c=not a.canEnchant(self.hand)
local e=not c and self:counted(b)or nil
if c~=self.bare then
self.bare=c
self.element:hold(c)
end
local f=a.zoning()or n.isQuiet(nil)
local b=self.state

if not e and f and b~=nil and b~="missing"then return end
local d=e and"present"or"missing"
if d~=b then
self.state=d
self.element:setState(d)
end

if self.rig.expiring then
self.element:setFact(self.rig.expiring.id,self:expiring(e),g and b~=nil and not f and not c)
end
self:feed(e)
if not g or b==nil or f or c then return end
local a=GetTime()-a.itemChangedAt(self.hand)<k
if b=="missing"and d~="missing"and not a then
self.lastArrived=GetTime()
self.element:moment("arrived")
elseif b~="missing"and d=="missing"and not a then
self.lastRemoved=GetTime()
self.element:moment("removed")
end
end

function b.build(h,e,b,g)
if g then g:release()end
local b=setmetatable({element=h,view=b,rig=e,hand=e.hand,data={}},d)
local c=c.listOf(e.spells)
if#c>0 then
b.keys={}
for d,c in ipairs(c)do
local c=a.keyOf(c)or c
b.keys[c]=true
if a.IMBUES[c]then b.anyImbue=true end
end
end
b.list=c
f.plainBuild(b,h,e,g)
return b
end


function d:paint()
f.plainPaint(self)
self.element:hold(self.bare==true)
end

function d:start()
g[self]=true
local b="weapon enchant "..tostring(self.element.id).." "..tostring(self.element.src)
self.key=b
a.watch(b)

local c={}
for a in pairs(self.keys or{})do c[#c+1]=a end
a.learnFor(b,c)
if#self.list>1 and self.view.source.shownSpell=="lastSeen"then h.watch(b,self.list,"weapon")end
self.state,self.fedId,self.bare=nil,nil,nil
self:read(false)
end

function d:stop()
g[self]=nil
if self.key then
a.unwatch(self.key)
a.learnFor(self.key,nil)
h.unwatch(self.key)
end
end

function d:release()
self:stop()
self.element:hold(false)
self.host:Hide()
end

function d:refeed()
self.fedId=nil
if g[self]then self:read(false)end
end


function d:respell()
self:refeed()
end

function d:describe()
return string.format("weapon enchant %s hand, %s, %s%s%s",tostring(self.hand),tostring(self.state),
self.keys and(#self.list.." named")or"any enchant",self.unreadable and", unreadable"or"",
self.lastRemoved and string.format(", last removed at %.1f",self.lastRemoved)or"")
end

a.onChange("weapon enchant source",function(a)
if a=="cast"then return end
for a in pairs(g)do e.try("weapon enchant "..tostring(a.element.id),a.read,a,true)end
end)

h.onChange("weapon enchant source",function()
for a in pairs(g)do
if a.state=="missing"then
a.fedId=nil
a:feed(nil)
end
end
end)

b.live=g
