

local a,b=...
local e,d,i,a,l=b.Sources,b.Events,b.Ticker,b.Debug,b.Schema
local c=e.get("spell")





local j=0.1
a.experimental("Usable as a fact on a Spell: the window read from CD-8's flag at its event (CD-8: Revenge's flips"
.." all announced, T 70862), read plainly to the player in play (Revenge, 9 November 2026)","T 70862")

a.experimental("Execute, Hammer of Wrath, Riposte, Mongoose Bite and Counterattack as Usable from the usable flag"
.." (CD-8 proves Overpower and Revenge; Execute's and Hammer of Wrath's follow the target's health, whose event"
.." is unseen: read again at a target change)","C")


a.experimental("Execute and Hammer of Wrath not Usable while short of power (needsPower: CD-8's power flag, unseen"
.." on them)","I")












local h=0.5
a.experimental("Usable's cooldown guard: isActive with isOnGCD false at two ticks running while Usable holds at"
.." Ready, held up to "..h.." s after its own Comes ready until isActive reads false (CD-6's lag past"
.." the end, measured once), armed as a read (as the cast where one is pending) and ended by the tracker or"
.." isActive false (CD-3's shared cooldown at its event unrecorded on Spell)","I")

local a={}
local f=false
local g


local function k(a)
local d,c=b.try("GetSpellCooldown",C_Spell.GetSpellCooldown,a.id)
local d=d and type(c)=="table"and not b.isSecret(c.isActive)

if d and c.isActive==false then a.guardClearAt=a.lastMomentAt end
local b=d and not b.isSecret(c.isOnGCD)and c.isActive==true and c.isOnGCD==false
if b and a.lastMomentAt and a.guardClearAt~=a.lastMomentAt
and GetTime()<a.lastMomentAt+h then
b=false
end
if not b then
a.guardSeen=nil
return
end
if not a.guardSeen then
a.guardSeen=true
return
end
a.guardSeen=nil
a.guardCaught=(a.guardCaught or 0)+1
a:setState("coolingDown")
a:arm(a.castPending and"cast"or"read",a.castPending)

a.guardArmed=true
a:feedLayers("own")
end



local function b(a)
local b=a.usableNow
a:readUsable()

if a.guardArmed and a.armed and a.state=="coolingDown"and a.id~=nil
and c.readOf(a.id)=="ready"then
a:comesReady("comesReady")
end
if a.usableNow and a.state=="ready"and a.id~=nil then
k(a)
else
a.guardSeen=nil
end
if b~=nil and a.usableNow~=b then
a.flipAt,a.flipEventBefore,a.flipEventAfter=GetTime(),g,nil


a.pollFirst=(a.pollFirst or 0)+1
end
a:tellFacts(true)
end



local function m()
for a in pairs(a)do
if(a.usableNow and a.state=="ready")or(a.guardArmed and a.state=="coolingDown")then
return true
end
end
return false
end


local h
local function k()
for a in pairs(a)do e.try(a,b)end
h()
end
function h()
local b=m()
if b==f then return end
f=b
if b then
i.subscribe(j,"spell usable",k)
else
i.unsubscribe(j,"spell usable")

for a in pairs(a)do a.guardSeen=nil end
end
end


local function b()d.atFrameEnd("spell usable poll",h)end
function c.repollUsable()
if next(a)~=nil then b()end
end

local function i()
g=GetTime()
for a in pairs(a)do
if a.flipAt and a.flipEventAfter==nil then
a.flipEventAfter=g
a.eventLag=math.max(a.eventLag or 0,g-a.flipAt)
end
end
b()
end
local function g(a)
if a then
d.on("SPELL_UPDATE_COOLDOWN","spell usable poll",b)
d.on("SPELL_UPDATE_USABLE","spell usable poll",i)
d.on("UPDATE_SHAPESHIFT_FORM","spell usable poll",b)
else
d.off("SPELL_UPDATE_COOLDOWN","spell usable poll")
d.off("SPELL_UPDATE_USABLE","spell usable poll")
d.off("UPDATE_SHAPESHIFT_FORM","spell usable poll")
end
end

function c.pollUsable(b,c)
c=c and b.rig.usable~=nil or nil
if a[b]==c then return end
local d=next(a)~=nil
a[b]=c
local a=next(a)~=nil
if d~=a then g(a)end
if c==nil then b.flipAt,b.flipEventBefore,b.flipEventAfter,b.guardSeen=nil,nil,nil,nil end
h()
end

function c.pollingUsable()return f end
c.polledUsable,c.usableTick=a,k






function c.describeUsable(b)
local d=b.rig.usable
if not d then return""end
local function c(a)return a and string.format("%.2f",a)or"none"end
local e,g=b.usableFlips or 0,b.pollFirst or 0
return string.format("; Usable at its event%s%s%s%s%s",f and a[b]and" (guard tick on)"or"",
d.needsPower and", not while short of power"or"",
b.flipAt and string.format(", tick saw a flip at %s, usable event before %s, after %s",c(b.flipAt),
c(b.flipEventBefore),c(b.flipEventAfter))or"",
e>0 and string.format(", flips: %d read at an event, %d seen by the tick first (event lag up to %.2f s)",
e-g,g,b.eventLag or 0)or"",
b.guardCaught and string.format(", guard caught %d",b.guardCaught)or"")
end










local d=setmetatable({},{__mode="kv"})
function c.keepUsable(a,b)
if type(a.facts)=="table"then d[a.facts]=b end
end
l.source("spell").typical=function(h,b)
local f=b.facts
local g=type(f)=="table"
local a
if g then a=d[f]end
if a==nil then
local c={}
for a,b in pairs(h)do c[a]=b end
c.run,c.source=b.id,b
local b=e.usedFacts(c,{"usable"})and e.firstItem(b,"usable")
a=b and b.id or false
if g then d[f]=a end
end
if a then return{state="ready",facts={[a]=true}}end
end
