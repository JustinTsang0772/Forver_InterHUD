



local a,b=...
local d,f,l,i,u,j,g,h,v,w,m,q=b.Layers,b.Sources,b.Combat,b.Showing,
b.Groups,b.Schema,b.Media,b.Keys,b.Resolve,b.Events,b.Game,b.Quiet

local e={}
b.Element=e







local a={}
a.__index=a
e.Run=a

local c={}
c.__index=c

local r=b.keyed("moment")

function e.onMoment(a,b)r:add(a,b)end

function e.new(a)
return setmetatable({id=a,runs={},runById={}},c)
end


function e.newRun(b,c,d)
local a=setmetatable({id=b,src=d,root=c,visuals={}},a)
return a
end





function e.split(c)
local d,e={},{}
for b,a in ipairs(c.sources or{})do
local b=j.variantOf(a)
e[a.id]=b~=nil and b.read~="clip"
end
for a,b in ipairs(c.sources or{})do
local a={}
for b,c in pairs(c)do a[b]=c end
a.run,a.source,a.variant,a.plainRuns=b.id,b,j.variantOf(b),e
d[#d+1]={id=b.id,view=a}
end
return d
end


local function x(b)
local a={}
for b,c in pairs(b)do a[b]=c end
a.run,a.host=nil,true
local c={}
for b,a in ipairs(b.sources or{})do
local b=j.variantOf(a)
c[a.id]=b~=nil and b.read~="clip"
end
a.plainRuns=c
return a
end

b.Debug.experimental("each part on Blizzard's aura button its own frame at its layer's level (the foundations"
.." review's finding 2)","I")


local k={button=true}
local function n(a)return k[a.holder]or a.rides~=nil end







local function k(a)a.colour,a.greyed=g.greyOf(a.colour),true end

local function o(c,d)
local a=c[d]
if type(a)~="table"or a.colour==nil then return end
local b={}
for a,c in pairs(a)do b[a]=c end
b.colour=g.greyOf(a.colour)
c[d]=b
end
local s={
icon=function(a)
a.desaturated,a.tint,a.overlay=true,"#ffffff00",false
o(a,"time")

if type(a.sweep)=="table"and type(a.sweep.style)=="table"then
local c,b={},{}
for a,b in pairs(a.sweep)do c[a]=b end
for a,c in pairs(a.sweep.style)do b[a]=c end
if b.colour then b.colour=g.greyOf(b.colour)end
if b.edgeColour then b.edgeColour=g.greyOf(b.edgeColour)end
c.style=b
a.sweep=c
end
end,
bar=function(a)
a.colour=g.greyOf(a.colour)
o(a,"background")
o(a,"segmentLines")

if type(a.colourSteps)=="table"then
local b={}
for c in ipairs(a.colourSteps)do
b[c]=a.colourSteps[c]
o(b,c)
end
a.colourSteps=b
end
end,
border=function(a)a.colour,a.ring=nil,false end,

gcdSweep=function(a)
if type(a.sweep)=="table"and a.sweep.gcdColour then
local b={}
for a,c in pairs(a.sweep)do b[a]=c end
b.gcdColour=g.greyOf(b.gcdColour)
a.sweep=b
end
end,
text=k,barText=k,barName=k,barTime=k,count=k,
}
local k=setmetatable({},{__mode="k"})
local function y(a,b)
local c=not a.effect and s[a.kind]
if not c or type(b)~="table"then return b end
local a=k[b]
if not a then
a={}
for b,c in pairs(b)do a[b]=c end
c(a)
k[b]=a
end
return a
end










local z=0.45
local k={tint="#ffffff",overlay=false,sweep={enabled=false},time={enabled=false}}
local o=setmetatable({},{__mode="k"})
local t={ringOnly=true,ring=false}
local p=setmetatable({},{__mode="k"})
local function A(c,a)
local d=type(c.border)=="table"and c.border or{}
local b=type(a.border)=="table"and a.border or{}
if not d.ring or(b.ring and b.enabled~=false and d.ringColour==b.ringColour and d.ringSize==b.ringSize)
then
return t
end
local f=p[c]
local e=f and f[a]
if e then return e end
local g=a.kind=="bar"or nil
local b=g and b.enabled~=false and b.style or not g and a.framedBy or nil
e={ringOnly=true,ring=true,ringColour=d.ringColour,ringSize=d.ringSize,style=b,
scale=a.scale,onBar=g}
p[c]=f or setmetatable({},{__mode="k"})
p[c][a]=e
return e
end
local function p(a,b)
if a.overlay and not(b.overlay and a.overlayColour==b.overlayColour)then
return a.overlayColour or"#00000080"
end
if a.tint and a.tint~=b.tint then
local b,c,d,a=g.rgba(a.tint)
a=a*z
if a>0 and(b<1 or c<1 or d<1)then
return string.format("#%02x%02x%02x%02x",math.floor(b*255+0.5),math.floor(c*255+0.5),
math.floor(d*255+0.5),math.floor(a*255+0.5))
end
end
end
function e.coverRecord(c,a,b)
if c=="border"then
if not a or a==b then return t end
return A(a,b)
end
if not a or a==b then return k end
local d=o[a]
local c=d and d[b]
if c then return c end
local e=p(a,b)
c={framedBy=b.framedBy,scale=b.scale,tint="#ffffff",overlay=e~=nil,overlayColour=e,
sweep=k.sweep,time=k.time}
o[a]=d or setmetatable({},{__mode="k"})
o[a][b]=c
return c
end



function a:viewFor(a)
local b=a.moment and self.rig and self.rig.moments and self.rig.moments[a.moment]
if b then return b end
local a=a.copy and self.live and self.live[a.copy]
if a and a.view then return a.view end
return self.view
end



function a:recordOf(a)
local b
if a.cover then

local c=self.live and self.live[a.copy]
local d=self.live and self.live[a.base]
b=e.coverRecord(a.kind,c and c.view and c.view.layers[a.layer],
d and d.view and d.view.layers[a.layer]or self.view.layers[a.layer])
else
b=d.recordOf(self:viewFor(a),a)
end
if self.element and self.element.greyed then b=y(a,b)end
return b,d.specOf(a)
end




function a:targetOf(a)
local b=a.target
if not b then return nil end
local a,c=self,function(a)return a.n==b end
if type(b)=="table"then
a=self.element and self.element.runById[b.run]
local d=a and a.rig and a.rig.copyOf and a.rig.copyOf[b.layer]
c=function(a)
return a.layer==b.layer and not a.partKey and not a.effect and(a.copy==nil or a.copy==d)
end
end
for b,a in ipairs(a and a.visuals or{})do
if c(a.part)and not a.gone then return a.visual end
end
end









b.Debug.experimental("a layer's Opacity on a frame of its own under Blizzard's aura button, written in the init and"
.." then only while button writes are allowed (FR-3: alphas multiply down the tree; under the button untried)","I")
function a:fadeOf(c,d,e)
self.fades=self.fades or{}
local a=self.fades[c]
if not a then
a={}
self.fades[c]=a
end
local b=a[d]
if not b then
b=CreateFrame("Frame",nil,c)
b:SetAllPoints(e or c)
a[d]=b
end
return b
end



function a:parentFor(b,a,c)
if a.effect or a.rides~=nil or not a.layer then return b end
return self:fadeOf(b,a.layer,c)
end


local function g(b,a)
return not b.partKey or type(a)~="table"or a.shown~=false
end


function a:layerAt(a)
local a=self:viewFor(a).layers[a.layer]
if not a then return 1,true end
return(a.opacity or 100)/100,a.shown~=false
end




function a:effectAlpha(a)
local c=self
if a.onRun then c=self.element and self.element.runById[a.onRun]or self end
local b=c.rig
local d=c==self or a.side=="present"
local b=b and(d and b.presentOf and b.presentOf[a.onLayer]
or b.copyOf and b.copyOf[a.onLayer])
local a,b=c:layerAt({layer=a.onLayer,copy=b})
return b and a or 0
end






function a:fadeTo(a)
local c=a.part


if a.inPane and not l.buttonsWritable()and not(a.hangs and not a.hangs.hung)then return end
if c.effect then
if c.onLayer then a.visual.frame:SetAlpha(self:effectAlpha(c))end
return
end
local e=self:recordOf(c)
if a.fade then
local d,b=self:layerAt(c)
if c.adds then b=b and self:addsShown(c,nil)end
a.fade:SetShown(b)
i.fadeTo(a.fade,d,a.underButton or a.inPane or c.holder~="layer"or f.editing())
end
if c.partKey then
local d=g(c,e)
if d and c.adds then d=self:addsShown(c,e)end
local e=a.shown
a.shown=d
a.visual.frame:SetShown(d)

if d and e==false and a.spec.shown then b.try(a.site,a.spec.shown,a.visual)end

if c.kind=="glow"then a.visual.frame:SetAlpha(self.element and self.element.greyed and 0 or 1)end
end
end



function a:addsShown(a,e)
local c=self.live and self.live[a.adds]and self.live[a.adds].view
local b=c and c.layers[a.layer]
if not b then return true end
local b=b.shown~=false
if a.partKey then
local c=d.recordOf(c,a)
b=b and g(a,c)
local c=self:viewFor(a).layers[a.layer]
return not b and(c==nil or c.shown~=false)and g(a,e)
end
return not b
end







local g=48
local function k(a,b)
while#a>b do table.remove(a,1)end
end
local function o(b)
local a=d.structureOf(b)


a.n,a.level,a.target=nil,nil,nil
a.region,a.half,a.gate,a.bits,a.mask,a.copy,a.adds,a.copyOf=nil,nil,nil,nil,nil,nil,nil,nil
a.rides=b.rides~=nil or nil
return a
end


function a:takeKept(f,c,g)
local d=self.spare
if not d or c.underButton then return nil end
local e
for h,a in ipairs(d)do
if a.parent==f and a.target==g and a.part.kind==c.kind then
e=e or o(c)
if b.equal(a.shape,e)then
table.remove(d,h)
a.taken=true
return a
end
end
end
end




function a:letGo()
local c=self.spare or{}
self.spare=c
local d=l.buttonsWritable()
local b=0
for e,a in ipairs(self.visuals)do
a.gone=true
if a.inPane and not d then
self.hungLater=self.hungLater or{}
self.hungLater[#self.hungLater+1]=a
b=b+1
elseif not a.underButton then
a.visual.frame:Hide()
c[#c+1]=a
b=b+1
end
end
self.keptMax=g+b
k(c,self.keptMax)
self.visuals={}
end

function a:keepHung()
local a=self.spare or{}
self.spare=a
for c,b in ipairs(self.hungLater or{})do
if not b.taken then
b.visual.frame:Hide()
a[#a+1]=b
end
end
self.hungLater=nil
k(a,self.keptMax or g)
end







function a:makeVisual(c,a,g)
local i,e=self:recordOf(a)
local h=a.effect and self:targetOf(a)or nil
local j=self:takeKept(c,a,h)
local k=c
local f=self:parentFor(c,a,g and g.anchor)
if f~=c then c=f else f=nil end
local b
if j then
b=j.visual
b.frame:SetParent(c)
b.frame:ClearAllPoints()
b.frame:Show()
else
b=e.create(c,i,a,h)
end
if n(a)then
b.frame:SetAllPoints(c)
else
d.place(b.frame,self.root,a.rect)
end
b.frame:SetFrameLevel(a.level)
e.apply(b,i,a,a.rect)



if(a.underButton or a.inPane and not a.cover)and self.still then
if not a.sockets or#a.sockets==0 then
e.feed(b,self.still)
elseif a.ownPicture then
e.feed(b,{icon=self.still.icon})
end
end
local a={part=a,spec=e,visual=b,underButton=a.underButton,fade=f,
site=self.id.." "..a.kind,parent=k,target=h,shape=o(a),inPane=a.inPane,
hangs=g}
self:fadeTo(a)
self.visuals[#self.visuals+1]=a
return a
end


function a:feed(c)
self.lastFed=c

for d,a in ipairs(self.visuals)do
if not a.underButton and not a.inPane and not a.part.cover then b.try(a.site,a.spec.feed,a.visual,c)end
end
end


function a:keepVisual(a)
a.gone=nil
self.visuals[#self.visuals+1]=a
self:reapply(a)
end




function a:reapply(a)
if a.underButton or a.inPane then
l.whenButtonsWritable(self.id.." part "..(a.part.n or("effect "..a.part.effect)),function()
if a.gone then return end

if not n(a.part)then d.place(a.visual.frame,self.root,a.part.rect)end
a.spec.apply(a.visual,(self:recordOf(a.part)),a.part,a.part.rect)
self:fadeTo(a)
end)
return
end
if not n(a.part)then d.place(a.visual.frame,self.root,a.part.rect)end
b.try(a.site,a.spec.apply,a.visual,(self:recordOf(a.part)),a.part,a.part.rect)
self:fadeTo(a)
end








function a:reflow(a)
local c=self.view
if not c then return end
local e=l.buttonsWritable()
local g=self.rig and self.rig.moments
for b,a in ipairs(self.visuals)do
local b=a.part
local f=b.effect and b.onLayer or b.layer
if f and not a.gone and not n(b)and(e or not(a.underButton or a.inPane))then

local b=b.moment and g and g[b.moment]or c
local c=b.layers[f]
if c then
a.flow=d.drawnRectInto(c,b.baseSize,b.allLayers or b.layers,a.flow or{})
d.place(a.visual.frame,self.root,a.flow)
end
end
end
if self.inst and self.inst.reflow then f.try(self.inst,self.inst.reflow,e,a)end
end






local g={}

local function k(c,b)
local a,d=0,#b
for b,e in ipairs(b)do
local c,e=c:holds(e)
if c then
a=a+2^(b-1)
elseif e then
a=a+2^(d+b-1)
end
end
return a
end
function a:momentOf(a,c,e)
self.cache=self.cache or{}
local b=self.cache[a]
if not b then
b={}
self.cache[a]=b
end
local d=b[e]
if d then return d end
local a,f=self.element.keys,c.assign
local g=function(b)return a:holds(b,f)end
local f={}
for a,b in ipairs(self.view.layers)do f[a]=b end
local a=self.view.layers[c.layer]

if a and c.skip and a.compiled then
local b,d={},{}
for a,c in pairs(a.compiled)do b[a]=c end
for a,b in ipairs(a.compiled.flags)do
if not c.skip[a]then d[#d+1]=b end
end
b.flags=d
local c={}
for a,b in pairs(a)do c[a]=b end
c.compiled=b
a=c
end
local g=a and v.lookAt(a,g)or a


for d,a in pairs(b)do
if a.layers[c.layer]==g then
b[e]=a
return a
end
end
f[c.layer]=g
d={layers=f,effects=self.view.effects,baseSize=self.view.baseSize}
b[e]=d
return d
end
function a:relook(f)
local a=self.rig and self.rig.copies
local c=self.element and self.element.keys
if not(a and c)then return false end
self.live=self.live or{}
local d=false
for b,e in ipairs(a)do
local c=k(c,e.atoms or g)
local a=self.live[b]
if not a then
a={}
self.live[b]=a
end
if f or a.mask~=c or not a.view then
local f=a.view
a.mask,a.view=c,self:momentOf(b,e,c)
if a.view~=f then
a.dirty=true
d=true
end
end
end
if not d then return false end


for c,a in ipairs(self.visuals)do
local c=a.part.copy
local c=c and self.live[c]
local d=a.part.adds and self.live[a.part.adds]
if not a.gone and((c and c.dirty)or(d and d.dirty))then
if a.part.cover then
self:reapply(a)
elseif not a.underButton and not a.inPane then
b.try(a.site,a.spec.apply,a.visual,(self:recordOf(a.part)),a.part,a.part.rect)
self:fadeTo(a)
end
end
end
for b,a in pairs(self.live)do a.dirty=nil end
return true
end



function a:buildRun(b,a)
a=a or self.kept
self.kept=nil
self.view=b
local c=f.get(b.source.kind)
if a and a.rig.kind~=b.source.kind then
a:release()
a=nil
end
self.root:Show()
self:letGo()
self.rig=c.plan(b)
self.live,self.cache={},{}
self:relook(true)


local d=self.element and self.element.keys
if d and self.state then d.now[self.src.."."..self.state]=false end
self.state=nil
self.inst=c.build(self,self.rig,b,a)
self.inst:start()
end




function a:applyRun(c)
local a=f.get(c.source.kind)
local e=a.plan(c)
if not self.inst or c.source.kind~=self.view.source.kind or not d.sameStructure(e,self.rig)then
self:buildRun(c,self.inst)
return"rig"
end
local a,g=self.rig,self.view
local f={}
for a,b in ipairs(self.visuals)do f[a]=(self:recordOf(b.part))end
self.view,self.rig,self.inst.view=c,e,c
self.live,self.cache={},{}
self:relook(true)
if self.inst.update then self.inst:update(a,e)end
for h,a in ipairs(self.visuals)do
local d=e.parts[a.part.n]
if d and(not b.equal(d,a.part)or not b.equal((self:recordOf(d)),f[h])
or(d.effect and g~=c))then
a.part=d
self:reapply(a)
elseif d then
a.part=d

if a.underButton or a.inPane then self:reapply(a)else self:fadeTo(a)end
end
end
self.inst:paint()
if self.inst.refeed then self.inst:refeed()end
return"live"
end


function a:releaseRun()
if self.inst then
self.inst:release()
self.kept=self.inst
end
self.inst=nil
if self.root then self.root:Hide()end
end




function a:setState(b)
local a=self.element
if self.state==b then return end
local c=a and a.keys
if c and self.state then c.now[self.src.."."..self.state]=false end
self.state=b
if c and b then c.now[self.src.."."..b]=true end
if a and a.keysChanged then a:keysChanged()end
end




function a:setFact(d,a,f)
local b=self.element
local c=b and b.keys
if not c then return end
local e=self.src.."."..d
a=a==true
if(c.now[e]==true)==a then return end
c.now[e]=a
b:keysChanged()
if f and not q.isQuiet(nil)then self:play("fact",d,a and"enters"or"leaves")end
end


function a:factOn(b)
local a=self.element and self.element.keys
local a=a and a:term(self.src.."."..b)
return a~=nil and a.on~=false
end



function a:moment(a)
self.lastMoment=a
r:call(self,a)
local b=self.element
if b and b.keys and b.keys:stamp(self.src,a)then b:keysChanged()end
self:play("event",a)
end





function a:play(h,d,g)
if i.cantAct()then return end
local a,e=self.view,self.element and self.element.keys
for i,c in ipairs(a and a.effects or{})do
local a=c.at or{}
local f
if h=="event"then
f=a.event==d and a.fact==nil and a.customState==nil and a.source==self.src
elseif h=="fact"then
f=a.source==self.src and(a.item or a.fact)==d and a.event==g and a.customState==nil
else
f=a.customState==d and a.event==g
end
if f and(not e or e:lookHolds(e:list(c["while"]),e:list(c.unless)))then
if c.kind=="sound"then
b.Sounds.play(c.sound,self.id.." "..tostring(g or d))
else
for c,a in ipairs(self.visuals)do
if a.part.effect==i and not a.gone then
self:fadeTo(a)
b.try(a.site,a.spec.play,a.visual)
end
end
end
end
end
end


function a:hold(a)
if self.root then self.root:SetAlpha(a and 0 or 1)end
end


function a:describeRun()
return self.inst and self.inst:describe()or"not built"
end



b.Debug.experimental("a Spell Alert's frames below the plain elements' in their strata (a lower frame level, never"
.." BACKGROUND) and taking no mouse, so a click through it reaches the world","I")
local g={}



local function k(b)
local c={}
local d=b.keys
local function a(a)
for a in pairs(d:atomsOf(a).lua)do
local a,b=j.splitKey(a)
if b==j.GAME then c[a]=true end
end
end
for c,b in ipairs(b.view.layers)do
for c,b in ipairs(b.looks or{})do
for c,b in ipairs(h.asList(b["while"]))do a(b)end
for c,b in ipairs(h.asList(b.unless))do a(b)end
end
end
for c,b in ipairs(b.view.effects or{})do
for c,b in ipairs(h.asList(b["while"]))do a(b)end
for c,b in ipairs(h.asList(b.unless))do a(b)end
end
for c,b in ipairs(h.asList(b.view["while"]))do a(b)end
for c,b in ipairs(h.asList(b.view.unless))do a(b)end
for b in pairs(d.conds)do a(b)end
return c
end



function c:compileKeys(a)
local b=h.compile(self.view)
if a then
for a,c in pairs(a.now)do
if not a:match("^#hold%.")then b.now[a]=c end
end
b:keepStamps(a)
for b,c in pairs(b.conds)do
local a=a.conds[b]
if a then c.was=a.was end
end
a:stop()
end
b.onEnd=function()self:keysChanged()end
self.keys=b
local a=k(self)
for b in pairs(self.games or{})do
if not a[b]then m.use(b,self.id,false)end
end
for a in pairs(a)do m.use(a,self.id,true)end
self.games=a
end




local function h(b,e)
local a=b.keys
if not a then return end
a:bump()
for d,c in pairs(a.conds)do
local a=a:cond(d)
if a~=c.was then
local f=c.was==nil
c.was=a
if not e and not f and not q.isQuiet(nil)and b.host then
b.host:play("customState",d,a and"enters"or"leaves")
end
end
end
end




function c:keysChanged()
local a=self.keys
if not a then return end
a:bump()
for b,a in ipairs(self.runs)do
a:relook()
if a.inst and a.inst.relight then a.inst:relight()end
end
if self.host then self.host:relook()end
if self.isBuilt then i.apply(self)end
w.atFrameEnd(self.settleKey,h,self)
end

function c:place()
u.place(self.root,self.id,self.view)
end


function c:runOf(a)return self.runById[a]end



function c:runFor(c)
local b=self.runById[c]
if not b then
b=setmetatable({id=self.id..":"..c,src=c,element=self,visuals={}},a)
b.root=CreateFrame("Frame",nil,self.root)
b.root:SetAllPoints(self.root)
self.runById[c]=b
end
return b
end




local function j(a)
local b={}
for e,c in ipairs(a.effects or{})do
if d.ownsEffect(a,c)then
for c,d in ipairs(c.over or{})do
for e,c in ipairs(a.layers)do
if c.id==d and c.source~=a.run then b[c.source]=true end
end
end
end
end
for a in pairs(f.splitsOn(a))do b[a]=true end
return b
end
local function k(a)
local b,d={},{}
local e={}
for b,a in ipairs(a)do e[a.id]=j(a.view)end
for c=1,#a do
for f,c in ipairs(a)do
if not d[c.id]then
local f=true
for b in pairs(e[c.id])do
if not d[b]and b~=c.id then
for c,a in ipairs(a)do
if a.id==b then f=false end
end
end
end
if f then
d[c.id]=true
b[#b+1]=c
end
end
end
end
for c,a in ipairs(a)do
if not d[a.id]then b[#b+1]=a end
end
return b,e
end





function c:setRuns(a,g)
local c,b={},{}
local d,h=k(a)
for b,a in ipairs(a)do c[a.id]=true end
self.runs={}
for b,a in ipairs(a)do self.runs[#self.runs+1]=self:runFor(a.id)end
local e="live"
for c,a in ipairs(d)do
local c=self:runFor(a.id)
local d=false
for a in pairs(h[a.id])do d=d or b[a]==true end
if g and c.inst and not d then
if c:applyRun(a.view)=="rig"then b[a.id]=true end
else
c:buildRun(a.view,c.inst)
b[a.id]=true
end
if b[a.id]then e="rig"end
end
for b,a in pairs(self.runById)do
if not c[b]and a.inst then a:releaseRun()end
end

for b,a in ipairs(self.runs)do
if a.inst and a.inst.regate then f.try(a.inst,a.inst.regate)end
end
return e
end



function c:setHost(c)
local b=false
for c,a in ipairs(c.effects or{})do
if a.at and a.at.customState~=nil then b=true end
end
if not b then
if self.host then
self.host:letGo()
self.host.view,self.host.rig=nil,nil
end
self.hostOn=nil
return
end
local b=self.host
if not b then
b=setmetatable({id=self.id..":customStates",element=self,visuals={}},a)
b.root=CreateFrame("Frame",nil,self.root)
b.root:SetAllPoints(self.root)
self.host=b
end
local c=x(c)
local a=d.effectParts(c,true,{},nil)
for a,b in ipairs(a)do b.n=a end
local a={kind="customStates",parts=a}
if b.rig and d.sameStructure(a,b.rig)then
b.view,b.rig=c,a
for d,c in ipairs(b.visuals)do
c.part=a.parts[c.part.n]
b:reapply(c)
end
return
end
b:letGo()
b.view,b.rig=c,a
b.frame=b.frame or CreateFrame("Frame",nil,b.root)
b.frame:SetAllPoints(b.root)
b.frames=b.frames or{axes={}}
for b,a in pairs(b.frames.axes)do a:Hide()end
for c,a in ipairs(a.parts)do b:makeVisual(f.effectParent(b.frames,b,a,b.frame),a)end
self.hostOn=true
end



function c:build(a)
if not self.root then
self.root=CreateFrame("Frame",nil,UIParent)
self.root:SetFrameStrata("MEDIUM")
end


self.root:SetFrameLevel(d.levelOf(a,0))
if d.below(a)then self.root:EnableMouse(false)end
self.root:Show()
self.view,self.whole=a,a
self.settleKey=self.settleKey or("customStates "..self.id)
self:compileKeys(nil)
self:place()
self:setRuns(e.split(a),nil)
self:setHost(a)
g[self]=true
h(self,true)
self:keysChanged()
i.add(self)
self.isBuilt=true
end




function c:apply(a)
self.view,self.whole=a,a
self:compileKeys(self.keys)
local b=self:setRuns(e.split(a),true)
self:setHost(a)
h(self,true)
self:keysChanged()
self:place()
i.apply(self)
return b
end



function c:reflowBegin(b)
if not self.isBuilt then return end
for c,a in ipairs(self.runs)do
if a.inst and a.inst.reflowBegin then f.try(a.inst,a.inst.reflowBegin,b)end
end
end


function c:reflow(a)
if not self.isBuilt then return end
for c,b in ipairs(self.runs)do b:reflow(a)end
if self.host then self.host:reflow(a)end
end




local function d(c)
for b,a in ipairs(c.visuals)do
local b=a.part
if not a.gone and not b.effect and(s[b.kind]or b.kind=="glow")then c:reapply(a)end
end
end
function c:setGreyed(a)
a=a and true or nil
if a==self.greyed then return end
self.greyed=a
for b,a in ipairs(self.runs)do d(a)end
end
b.Debug.experimental("Grey while you can't act on Blizzard's aura button: a handed icon greyed and a handed glow"
.." faded after the init (writes under the button while allowed, AU-30; a desaturation there unrecorded)","I")


function c:paint()
for c,a in ipairs(self.runs)do
if a.inst then b.try(a.id.." paint",a.inst.paint,a.inst)end
end
end


function c:release()
for a=#self.runs,1,-1 do self.runs[a]:releaseRun()end
if self.host then self.host:letGo()end
if self.keys then self.keys:stop()end
for a in pairs(self.games or{})do m.use(a,self.id,false)end
self.games=nil
g[self]=nil
self.isBuilt=nil
i.remove(self)
if self.root then self.root:Hide()end
end


function c:respell()
for c,a in ipairs(self.runs)do
if a.inst and a.inst.respell then b.try("respell "..a.id,a.inst.respell,a.inst)end
end
end


function c:describe(b)
local a={}
for c,b in ipairs(self.runs)do a[#a+1]=b.src..": "..b:describeRun()end
local a=(b or self.id)..": "..table.concat(a,"; ")
local b=self.keys and self.keys:describe()
if b then a=a.."; "..b end
return a
end


m.onChange("elements",function(b)
for a in pairs(g)do
if a.games and a.games[b]then a:keysChanged()end
end
end)
