


local a,c=...
local g,h,i=c.Events,c.Store,c.Debug

local e={}
c.GameCastBar=e





i.experimental("Blizzard's player cast bar silenced by UnregisterAllEvents and re-armed by registering SetUnit's"
.." events again from our code, at rest and in a fight, through Edit Mode (FR-43, D; C: oUF, EllesmereUI;"
.." EP-74)","D; C")



e.EVENTS={
"UNIT_SPELLCAST_INTERRUPTED","UNIT_SPELLCAST_DELAYED","UNIT_SPELLCAST_CHANNEL_START",
"UNIT_SPELLCAST_CHANNEL_UPDATE","UNIT_SPELLCAST_CHANNEL_STOP","UNIT_SPELLCAST_EMPOWER_START",
"UNIT_SPELLCAST_EMPOWER_UPDATE","UNIT_SPELLCAST_EMPOWER_STOP","UNIT_SPELLCAST_INTERRUPTIBLE",
"UNIT_SPELLCAST_NOT_INTERRUPTIBLE","UNIT_SPELLCAST_START","UNIT_SPELLCAST_STOP","UNIT_SPELLCAST_FAILED",
}

local k,j="game cast bar silence","game cast bar re-arm"
local a=PlayerCastingBarFrame

local f=false
local d=false
local b=nil


local function l()
local a=a:IsShown()
return not c.isSecret(a)and not a
end

local function m()
d=false
local d=false
for e,b in ipairs(e.EVENTS)do

if g.valid(b)and not c.try(j,a.RegisterUnitEvent,a,b,"player")then
d=true
end
end
if not c.try(j,a.RegisterEvent,a,"PLAYER_ENTERING_WORLD")then d=true end
b=d and"rearm"or nil
end







local function j()
if not a then return end
if f then
if b=="rearm"then b=nil end
if d or not l()then return end
local a=c.try(k,a.UnregisterAllEvents,a)
d=a
b=not a and"silence"or nil
else
if b=="silence"then b=nil end
if d then m()end
end
end

if a then

a:HookScript("OnHide",function()
if f and not d then g.atFrameEnd("game cast bar",j)end
end)
end

local function g()
f=h.ready()and h.settings().hideCastBar==true
j()
end
c.onChanged(function(a)
if a=="settings"or a=="profile"then g()end
end,"game cast bar")


function e.refused()return b end

function e.describe()
if not a or not(f or d or b)then return{}end
local a=d and"silenced by us"
or b=="silence"and"the game refused our silence"
or b=="rearm"and"the game refused part of our re-arm"
or f and"waiting for the bar to hide"or"armed"
return{"game cast bar: "..a}
end
i.register("game cast bar",e.describe)
