








local b,a=...
local f,m,y,d,n,r,h,s,t,u,v,z=a.Store,a.Resolve,a.Preview,a.HUD,a.Combat,
a.Ticker,a.Layers,a.Placement,a.Specials,a.Sounds,a.Events,a.Schema

local c={}
a.PreviewMode=c

local b=false
local e=false
local l=true
local o,p

local g=CreateFrame("Frame",nil,UIParent)
g:SetFrameStrata("MEDIUM")
g:SetFrameLevel(h.BASE_LEVEL)
g:SetSize(1,1)
g:SetPoint("CENTER")
g:Hide()

local j={}
local h={}

local q={typical=true}
local x={typical=true,lit=true}

local A={typical=true,allKnown=true}
local B={typical=true,lit=true,allKnown=true}


local w={}





local i=0
local function C()
if b or e then d.layout()end
end
local function k()
i=i+1
if b or e then v.atFrameEnd("preview mode again",C)end
end
a.Spells.onChange("preview mode",k)
a.LastSeen.onChange("preview mode",k)
a.Sources.onDataLoaded("preview mode",k)
d.onRepixel("preview mode",function()i=i+1 end)




local function k(b,d)
local c=w[b.id]or(b.lit and(b.unlearned and B or x)or(b.unlearned and A or q))
b.picks=c
if not(d and b.drawnView==b.view and b.drawnPicks==c and b.drawnGen==i)then
b.drawnView,b.drawnPicks,b.drawnGen=b.view,c,i
a.try("preview mode "..b.id,b.preview.show,b.preview,b.view,c)
end
b.root:SetAlpha((b.view.opacity or 100)/100)
end
local function q(a)
a.drawnView=nil
a.preview:hide()
end


local function i(b)
for c,b in ipairs(b.sources or{})do
if b.enabled~=false and#(b.layers or{})>0 and not a.Sources.unset(b)then return true end
end
return false
end



local function x(a,b)
if not a.enabled or a.groupOn==false then return false end
if b then return i(a)end
return d.learned(a)and i(m.drawn(a,d.sourceLearned))
end
c.previewed=x



local function A()
local a=f.profile()
local i=b and(f.ui().previewUnlearned or f.settings().showUnlearned)
local f=f.ui().previewAlerts
wipe(h)
for d,c in ipairs(a and a.elements or{})do

local d=z.alertFlag(c,"lit")
local e=(b or(d and f))and m.element(c,a)
if e and(b or d)and(f or not d)and x(e,i)then
local a=j[c.id]
if not a then
a={id=c.id,preview=y.new(g)}
a.root=a.preview.box
j[c.id]=a
end
a.view,a.lit,a.unlearned=e,d,i or nil
k(a,true)
h[c.id]=a
end
end
for a,b in pairs(j)do
if not h[a]then q(b)end
end
end


local function y()
for b,a in pairs(h)do
if a.preview:ranOut()then k(a)end
end
end




local i={}
local m={}
local k={}
function c.register(a,b)
assert(type(a)=="string"and not i[a],"PreviewMode: a drawer registered twice or unnamed")
i[a]=b
m[#m+1]=a
end

local function x(a)
return not t.get(a)or t.running(a)
end

local function z(b)
k[b]=true
if i[b].show then a.try("preview mode "..b,i[b].show)end
end
local function t(b)
k[b]=nil
if i[b].hide then a.try("preview mode "..b,i[b].hide)end
end


local function i()
if not b then return end
for b,a in ipairs(m)do
local b=x(a)
if b and not k[a]then z(a)
elseif not b and k[a]then t(a)end
end
u.setMuted(l)
end

local x=a.keyed("preview mode")

function c.onToggle(a,b)x:add(a,b)end

function c.isOn()return b end



function c.pick(a,c)
w[a]=c
if b then d.layout()end
end



local function w()
local c=b
if not(b or e)then
for b,a in pairs(j)do q(a)end
wipe(h)
end
p=f.ui().previewAlerts
g:SetShown(b or e)
a.try("preview mode layout",d.setPreview,(b or e)and{standIns=h,refresh=A,all=c}
or nil)
end


function c.set(c)
c=c and true or false
if c==b then return true end
if c and d.off()then
a.print("off for this character; /ihud on first.")
return false
end
if c and n.inCombat()then
a.print("preview mode can't open in combat.")
return false
end
b=c
l=true
o=f.ui().previewUnlearned


if not b then
for b,a in ipairs(m)do
if k[a]then t(a)end
end


u.setMuted(false)
r.unsubscribe(1,"preview mode")
for b,a in pairs(j)do q(a)end
wipe(h)
end
w()
if b then
r.subscribe(1,"preview mode",y)
i()
end
s.paintBanner()
x:call(b)
return true
end



function c.setPlacing(a)
a=a and true or false
if a==e then return end
e=a
w()
end

function c.toggle()return c.set(not b)end


function c.muting()return l end
function c.setMuting(a)
l=a and true or false
i()
s.paintBanner()
end


n.onStart("preview mode",function()
if not b then return end
c.set(false)
a.print("preview mode closed for combat.")
end)


local g=Enum and Enum.AddOnRestrictionState and Enum.AddOnRestrictionState.Inactive or 0
n.onRestrictionChange("preview mode",function(e,d)
if not b or(not a.isSecret(d)and d==g)then return end
c.set(false)
a.print("preview mode closed for combat.")
end)


a.onChanged(function(g)
if not(b or e)then return end
if b then
if g=="char"and d.off()then
c.set(false)
return
end
if g=="special"or g=="profile"or g=="char"or g=="ui"then
v.atFrameEnd("preview mode",i)
end
end
if g=="ui"then
local c=f.ui()

local b=(b and c.previewUnlearned~=o)or c.previewAlerts~=p
o,p=c.previewUnlearned,c.previewAlerts
if b then a.try("preview mode layout",d.layout)end
end
end,"preview mode")

