





local a,c=...
local e,g,p,t,aG,X,u,M,F,S=c.Store,c.Layers,c.Groups,c.HUD,c.Showing,
c.Combat,c.Spells,c.Events,c.Schema,c.Resolve

local b={}
c.Placement=b

local a=8
local N={idle={0.2,0.6,1,0.9},hover={0.55,0.85,1,1},chosen={1,0.82,0,1},
aim={0.3,1,0.4,1}}


local T={alert=4,mover=10,member=20,buttons=40}
local O,aq=14,110

local aH,h,U,ag,v,Y,ah=-40,10,18,19,22,12,16

local y,ai,aI,ar=24,90,8,4
local Z=0
local P=0
local as,at=0,0
local aj=0


local au,av=h+U+6+ag+6+v+h,100
local ak=24
local J={8,16,32,64,128}

local i=false
local G
local d
local f
local w
local k
local H
local l

local s
local _
local Q
local z
local r={}
b.movers=r
local m={}


local function C()
return UIParent:GetSize()
end


local function K(a,b,c)
local d,e=C()
local a=g.OFFSETS[a]or g.OFFSETS.CENTER
return a[1]*d+b,(1-a[2])*e+c
end


local o=CreateFrame("Frame",nil,UIParent)
o:SetAllPoints(UIParent)
o:SetFrameStrata("BACKGROUND")
o:Hide()
o.lines={}





local function n(c)
local a=g.truePixel()
local b=g.lineWidth(1/a)

return g.toPixels(c-b/2+a*1e-3),b
end

local function aJ(a)
local d,e=C()
local b=0
local function c(f,c)
b=b+1
local a=o.lines[b]
if not a then a=o:CreateTexture(nil,"BACKGROUND")o.lines[b]=a end
a:ClearAllPoints()
if c==0 then a:SetColorTexture(0.2,0.6,1,0.5)else a:SetColorTexture(1,1,1,0.1)end
if f then
local b,c=n(d/2+c)
a:SetPoint("TOPLEFT",o,"TOPLEFT",b,0)
a:SetPoint("BOTTOMLEFT",o,"BOTTOMLEFT",b,0)
a:SetWidth(c)
else
local b,c=n(e/2+c)
a:SetPoint("BOTTOMLEFT",o,"BOTTOMLEFT",0,b)
a:SetPoint("BOTTOMRIGHT",o,"BOTTOMRIGHT",0,b)
a:SetHeight(c)
end
a:Show()
end
for b=0,math.floor(d/2/a)do
c(true,b*a)
if b>0 then c(true,-b*a)end
end
for b=0,math.floor(e/2/a)do
c(false,b*a)
if b>0 then c(false,-b*a)end
end
for a=b+1,#o.lines do o.lines[a]:Hide()end
end

local j=CreateFrame("Frame",nil,UIParent)
j:SetAllPoints(UIParent)
j:SetFrameStrata("BACKGROUND")
j:SetFrameLevel(o:GetFrameLevel()+5)
j.x=j:CreateTexture(nil,"ARTWORK")
j.x:SetColorTexture(1,0.82,0,0.8)
j.y=j:CreateTexture(nil,"ARTWORK")
j.y:SetColorTexture(1,0.82,0,0.8)

local function E(a,b)
j.x:SetShown(a~=nil)
j.y:SetShown(b~=nil)
if a then
local a,b=n(a)
j.x:ClearAllPoints()
j.x:SetPoint("TOPLEFT",j,"TOPLEFT",a,0)
j.x:SetPoint("BOTTOMLEFT",j,"BOTTOMLEFT",a,0)
j.x:SetWidth(b)
end
if b then
local a,b=n(b)
j.y:ClearAllPoints()
j.y:SetPoint("BOTTOMLEFT",j,"BOTTOMLEFT",0,a)
j.y:SetPoint("BOTTOMRIGHT",j,"BOTTOMRIGHT",0,a)
j.y:SetHeight(b)
end
end



local function B(b,d,h,e,c)
local f,a,g=a,nil,nil

for e,c in ipairs(h)do
for e=-1,1 do
local b=c-(b+e*d)
if math.abs(b)<=f then f,a,g=math.abs(b),b,c end
end
end
if a then return b+a,g end
if c then
for f=-1,1 do
local b=b+f*d
local b=e+math.floor((b-e)/c+0.5)*c-b
if not a or math.abs(b)<math.abs(a)then a=b end
end
return b+a
end
return b
end

local function L(a)return math.floor(a*2+0.5)/2 end










local function q(a)return p.groups[a]end



local function aa(b,a,c,d)
if b.arrangement=="free"then
local b,c=K(b.position.point,c,d)
return b+a.x,c-a.y-a.h,b+a.x+a.w,c-a.y
end
local c,d=K(b.position.point,c,d)
local b=g.OFFSETS[p.anchorPoint(b)]
local b,c=c-b[1]*a.w,d+b[2]*a.h
return b,c-a.h,b+a.w,c
end
local function ab(a,b,c)
local a=q(a)
return aa(a.view,a,b,c)
end

local function I(a)
local b=math.ceil(math.abs(a)*2-1e-9)/2
return a<0 and-b or b
end

local function aF(a)
local function b()return q(a.id).view end
a.position=function()return b().position end
a.alive=function()local a=q(a.id)return a~=nil and a.view~=nil end
a.saved=function()
local a=e.group(a.id)
local a=a and a.position or{}
return a.x or 0,a.y or 0
end
a.rectAt=function(b,c)return ab(a.id,b,c)end
a.moveTo=function(c,d)
local b,a=q(a.id),b()
local b=a.arrangement=="free"and b.origin or b.frame
b:ClearAllPoints()
b:SetPoint(a.arrangement=="free"and"CENTER"or p.anchorPoint(a),UIParent,a.position.point,c,d)
end
a.commit=function(c,d)
e.editGroup(a.id,function(a)a.position={point=b().position.point,x=c,y=d}end)
end


a.scaleRecord="group"
a.scaleNow=function()
local a=e.group(a.id)
return a and a.scale or 1
end
a.writeScale=function(b)e.editGroup(a.id,function(a)a.scale=b end)end
a.preview=function(b)
p.preview(a.id,b,t.drawn)
return true
end
a.unit=function()return 1 end
a.name=function()return b().name or a.id end
end


local function al(a,b,c,d)
local a,b=a.baseSize*b,g.OFFSETS[a.position.point]
return c-b[1]*a,d+b[2]*a
end

local function n(a,b,c,d)
local a=g.bounds(a)
return c+a.x*b,d-(a.y+a.h)*b,c+(a.x+a.w)*b,d-a.y*b
end
local function aK(a,b,c,d)
return n(a,b,al(a,b,c,d))
end


local function aL(a)
local function c()return t.drawn(a.id)end
local f={x=0,y=0}
a.position=function()return a.slotted and f or c().view.position end
a.alive=function()return c()~=nil end
a.saved=function()
if a.slotted then return 0,0 end
local a=e.element(a.id)
local a=a and a.position or{}
return a.x or 0,a.y or 0
end


local function h()return a.pending or p.scaleOf(c().view)end


a.rootScale=function()
return(a.kind=="member"and q(d).view.scale or 1)*h()
end
a.unit=function()
if a.slotted then return a.rootScale()end
return a.kind=="member"and q(d).view.scale or 1
end
local function i(e,b,c)
if a.kind=="member"then
local a,d=q(d).view,a.unit()
local a,e=K(a.position.point,a.position.x,a.position.y)
return a+b*d,e+c*d
end
return K(e,b,c)
end

a.rootAt=function(e,f)
local c=c().view
local b=a.rootScale()
if a.slotted then

local a=p.slotOf(a.id)
local c=q(d).view
local c,g,h,d=ab(d,c.position.x,c.position.y)
return c+(a.x+e)*b,d+(a.y+f)*b
end
return al(c,b,i(c.position.point,e,f))
end
a.rectAt=function(b,d)
return n(c().view,a.rootScale(),a.rootAt(b,d))
end
a.moveTo=function(e,f)
local g=c().view.position
local b=c().root
b:ClearAllPoints()
local c=h()
if a.slotted then
local a=p.slotOf(a.id)
b:SetPoint(a.point,a.frame,a.toPoint,a.x+e,a.y+f)
elseif a.kind=="member"then
b:SetPoint(g.point,q(d).origin,"CENTER",e/c,f/c)
else
b:SetPoint(g.point,UIParent,g.point,e/c,f/c)
end
end
a.commit=function(f,g)
if a.slotted then
local c=a.aimAt(f,g)
a.moveTo(0,0)
b.reorder(d,a.id,c and c.id)
return
end
local b=c().view.position.point
e.editElement(a.id,function(a)a.position={point=b,x=f,y=g}end)
end


a.aimAt=function(b,c)
local e,f,g,h=a.rectAt(b,c)
local b,c=(e+g)/2,(f+h)/2
local i=q(d).view
local i,j,k,l=ab(d,i.position.x,i.position.y)
local d,e=(g-e)/2,(h-f)/2
if b<i-d or b>k+d or c<j-e or c>l+e then return nil end
local d,e
for f,a in ipairs(m)do
if a.slotted then
local f,g,h,i=a.rectAt(0,0)
local b=((f+h)/2-b)^2+((g+i)/2-c)^2
if not e or b<e then d,e=a,b end
end
end
return d~=a and d or nil
end



a.scaleRecord="element"
a.scaleNow=function()
local a=e.element(a.id)
return a and a.scale or 1
end
a.writeScale=function(b)e.editElement(a.id,function(a)a.scale=b end)end
a.preview=function(f)
if a.slotted then return false end
local b=c()
local h,c=b.view,b.root
local e,b=h.position,a.kind=="member"and q(d).view.scale or 1
local b=b*f
local i=g.boxSize(h,b)
c:SetScale(b)
c:SetSize(i,i)
c:ClearAllPoints()
if k==a and a.to then

a.moveTo(a.to.x,a.to.y)
elseif a.kind=="member"then
c:SetPoint(e.point,q(d).origin,"CENTER",
p.onPixels(e.point,e.x/f,e.y/f,i,i,b))
else
c:SetPoint(e.point,UIParent,e.point,p.looseAt(h,f))
end
local d=g.bounds(h,nil,b)
a:ClearAllPoints()
a:SetPoint("TOPLEFT",c,"TOPLEFT",d.x*b,-d.y*b)
a:SetSize(d.w*b,d.h*b)
return true
end
a.name=function()

local b=c()
local b=b and b.view
if not b then return a.id end
local c=b.sources and b.sources[1]

return b.name or(c and u.label(u.firstOf(c.spells)))or a.id
end
end










local function ac(a)return a.preview and a.preview.view or a.view end

local function R(a)return a.allLayers or a.layers end
local function n(a,b,c)
for d,a in ipairs(a or{})do
if a.source==b and a.id==c then return a,d end
end
end

local function u(a,b,c)
for d,a in ipairs(a and a.sources or{})do
if a.id==b then
for b,a in ipairs(a.layers or{})do
if a.id==c then return a end
end
end
end
end

local function x(e,b,c,d,a)
local b,e,f,g=g.rect(e,b.baseSize,R(b))
return c+b*a,d-(e+g)*a,c+(b+f)*a,d-e*a
end

local function af(b,a)
local a=R(a)
local c,b=n(a,b.layer.src,b.layer.id)
local c={}
for b in pairs(b and g.anchoredTo(a,b)or{})do c[a[b].source.."/"..a[b].id]=true end
return c
end
local aw,ae

local function A(a)
local b,c=a.current()
local a,d,e=a.root()
return x(b,c,a,d,e)
end



local function D(b,a)
if not a.preview then a:reflow()end
local c=ac(a)
local e=b.rootScale()
for d=1,#b.moving do
local b=b.moving[d]
local d=n(c.layers,b.layer.src,b.layer.id)
if d then ae(b,d,c,a.root,e)end
end
end


local function ap(b,d)
local a=b.flowed
b.flowed=nil
if not a then return end
if a.preview then
a.preview:dragAt(nil)
if not d then a.preview:reflow()end
elseif not d then
c.try("layer drag",a.reflow,a,true)
end
end

local function V(a,d,e)
local c=a.against
local b,d,e,f=b.anchorPair({a.rectAt(d,e)},c.rect)
local a=a.unit()
return{point=b,to=c.id,piece=c.piece,toPoint=d},L(e/a),L(f/a)
end

local function aM(a)
local function c()return r["element "..a.id]end

local function b()
local b=t.drawn(a.id)
local c=b and ac(b)
local a=c and n(c.layers,a.layer.src,a.layer.id)
if a then return a,c,b end
end

local function d()
local a=c()
local b=a.position()
local b,c=a.rootAt(b.x,b.y)
return b,c,a.rootScale()
end
a.root,a.current=d,b
a.position=function()return(b()).position end
a.alive=function()return c()~=nil and c().alive()and b()~=nil end
a.saved=function()
local a=u(e.element(a.id),a.layer.src,a.layer.id)
local a=a and a.position or{}
return a.x or 0,a.y or 0
end
a.rootScale=function()return c().rootScale()end
a.unit=a.rootScale

a.rectAt=function(b,c)
local b,c,d,e,f=g.withDrag(a.layer.src,a.layer.id,b,c,A,a)
if b then return c,d,e,f end
a.broken=true
return 0,0,0,0
end
a.moveTo=function(c,d)
local e,f,b=b()
a.flowed=b
local e=not b.preview or b.preview:dragAt(a.layer.src,a.layer.id,c,d)
if not(e and g.withDrag(a.layer.src,a.layer.id,c,d,D,a,b))then a.broken=true end
end


a.commit=function(c,d)
local b=e.element(a.id)
local b=b and S.element(b,e.profile())
local b=b and n(b.layers,a.layer.src,a.layer.id)
local f=false
if b then
local b=b.position
if a.against then b,c,d=V(a,c,d)end
f=e.editElement(a.id,function(e)
local a=u(e,a.layer.src,a.layer.id)
if a then a.position={point=b.point,to=b.to,piece=b.piece,toPoint=b.toPoint,x=c,y=d}end
end)and true or false
end
if not f then z()end
return f
end
a.name=function()
local b,c=b()
return b and g.nameOf(R(c),b)or tostring(a.layer.id)
end

a.scaleRecord,a.preview=nil,nil
end





function b.anchorCandidates(b)
local c={}
if not(b and b.kind=="layer"and b.alive())then return c end
local a,d=b.current()
local f,h,e=b.root()
local j=af(b,d)
for i,a in ipairs(d.layers)do
if not(a.source==b.layer.src and a.id==b.layer.id)and not j[a.source.."/"..a.id]then
local f,k,l,h=x(a,d,f,h,e)
local j=g.nameOf(R(d),a)
local b=g.pieces(a,d.baseSize)
if#b>1 then
for d,b in ipairs(b)do
local g=b.label and(b.label:sub(1,1):lower()..b.label:sub(2))or("picture "..d)
c[#c+1]={layer=i,id=a.id,source=a.source,piece=d,name=j.."'s "..g,
rect={f+b.x*e,h-(b.y+b.h)*e,f+(b.x+b.w)*e,h-b.y*e}}
end
else
c[#c+1]={layer=i,id=a.id,source=a.source,rect={f,k,l,h},name=j}
end
end
end
return c
end

local function ao(a)
local b,c=a.current()
local a,b,d=a.root()
local c=c.baseSize*d
return{rect={a,b-c,a+c,b},name="the element"}
end



function b.nearestAnchor(b,c,e)
local d,a
for c,e in ipairs(c)do
local c=e.rect
local f=math.max(0,c[1]-b[3],b[1]-c[3])
local b=math.max(0,c[2]-b[4],b[2]-c[4])
local b=math.sqrt(f*f+b*b)
if not a or b<a then d,a=e,b end
end
if a and a<e then return d end
return nil
end

local n={CENTER=0,TOP=1,BOTTOM=1,LEFT=1,RIGHT=1,TOPLEFT=2,TOPRIGHT=2,BOTTOMLEFT=2,
BOTTOMRIGHT=2}





function b.anchorPair(a,b)
local i,d=c.Clean.POINTS,g.OFFSETS
local f,g,j,k,e,h
for l,c in ipairs(i)do
local l=a[1]+d[c][1]*(a[3]-a[1])
local m=a[4]-d[c][2]*(a[4]-a[2])
for i,a in ipairs(i)do
local i=b[1]+d[a][1]*(b[3]-b[1])
local o=b[4]-d[a][2]*(b[4]-b[2])
local b,d=(l-i)^2+(m-o)^2,n[c]+n[a]
if not e or b<e-1e-6
or(b<=e+1e-6 and(d<h or(d==h and c==a and f~=g)))then
f,g,j,k,e,h=c,a,l-i,m-o,b,d
end
end
end
return f,g,j,k
end


local function n(b,a)
if a.id==nil then return r["element "..b.id]end
return r["layer "..b.id.."/"..tostring(a.source).."/"..tostring(a.id)]
end



local function aB(a)
local d,c=a.current()
local b={list=b.anchorCandidates(a),whole=ao(a),limit=c.baseSize*a.rootScale(),rect={},
mover={},words={}}
local d=a.name()
local function c(c)b.mover[c],b.words[c]=n(a,c),d.."  against "..c.name end
for b,a in ipairs(b.list)do c(a)end
c(b.whole)
return b
end

local function aC(d,e,f)
local c=d.aims
local a=c.rect
a[1],a[2],a[3],a[4]=d.rectAt(e,f)
return b.nearestAnchor(a,c.list,c.limit)or c.whole
end








local function n(a,b)
for c,a in ipairs(c.Specials.boxes(a)or{})do
if a.id==b then return a end
end
end
local u={point="CENTER",x=0,y=0}
local function am(e,h,i,f)
local c=c.Specials
local a,b,d
if f~=nil then
local c=n(e,f)
a,b,d=c and c.w,c and c.h,c and c.position or u
else
a,b=c.box(e)
d=c.view(e).position
end
a,b=a or 1,b or 1
local e,f=K(d.point,h,i)
local c=g.OFFSETS[d.point]or g.OFFSETS.CENTER
local c,d=e-c[1]*a,f+c[2]*b
return c,d-b,c+a,d
end
local function aN(a)
local b=c.Specials
local function d()return b.view(a.id)end
local function f(b,c)
local b,c,d,e=a.rectAt(b,c)
a:ClearAllPoints()
a:SetPoint("BOTTOMLEFT",UIParent,"BOTTOMLEFT",b,c)
a:SetSize(d-b,e-c)
end
a.place=f

local function g()
if a.box==nil then return d().position end
local a=n(a.id,a.box)
return a and a.position or u
end
a.position=g
a.alive=function()
if not b.running(a.id)then return false end
if a.box~=nil then return n(a.id,a.box)~=nil end
for c,b in ipairs(b.placeable())do
if b==a.id then return true end
end
return false
end
a.saved=function()
local a=g()
return a.x,a.y
end
a.rectAt=function(b,c)return am(a.id,b,c,a.box)end
a.moveTo=function(d,e)
local b=b.get(a.id)
if b.moveTo then c.try("special "..a.id.." moveTo",b.moveTo,d,e,a.box)end
f(d,e)
end
a.commit=function(f,g)
local b=b.get(a.id)
if b.commit then return c.try("special "..a.id.." commit",b.commit,f,g,a.box)end
if a.box~=nil then return false end
local b=d().position.point
e.editSpecial(a.id,function(a)a.position={point=b,x=f,y=g}end)
end


local c=F.field("specials",a.id)
a.scaleRecord=c and F.field(c.record,"scale")and c.record or nil
a.scaleNow=function()return d().scale or 1 end
a.writeScale=function(b)e.editSpecial(a.id,function(a)a.scale=b end)end
a.preview=nil
a.unit=function()return 1 end
a.rootScale=function()return 1 end
a.name=function()
local b=b.get(a.id)
local c=a.box~=nil and n(a.id,a.box)
return c and c.label or b and b.label or a.id
end
end





local n={off="markOff",unlearned="markUnlearned"}
local function aO(a,b)
if not n[b]then
if a.mark then a.mark:Hide()end
return
end
if not a.mark then
a.mark=a:CreateTexture(nil,"OVERLAY")
a.mark:SetSize(12,12)
a.mark:SetPoint("TOPRIGHT",a,"TOPRIGHT",-2,-2)
a.mark:SetAlpha(0.6)
end
a.mark:SetTexture(c.Kit.art(n[b]))
a.mark.why=b
a.mark:Show()
end

local function x(a)
local c=H==a or k==a
local e=(w==a)and N.chosen or c and N.hover or N.idle
local b=(l==a)and N.aim or e
local c=c and 0.1 or 0

local d=a.pieces~=nil and a.pieces.n>0
for c,a in ipairs(a.edges)do a:SetColorTexture(b[1],b[2],b[3],d and 0 or b[4])end
if a.kind=="group"then a.fill:SetColorTexture(0.1,0.3,0.6,0.25+c)
else a.fill:SetColorTexture(0,0,0,d and 0 or 0.35-c)end
for d=1,d and a.pieces.n or 0 do
local f=a.pieces[d]

local a=(l==a and s and s~=d)and e or b
for c,b in ipairs(f.edges)do b:SetColorTexture(a[1],a[2],a[3],a[4])end
f.fill:SetColorTexture(0,0,0,0.35-c)
end
end

local ad
function ad(a)
for b=1,a.pieces and a.pieces.n or 0 do ad(a.pieces[b])end
local b=g.pixel(a)
local c,d,e,f=a.edges[1],a.edges[2],a.edges[3],a.edges[4]
c:ClearAllPoints()
c:SetPoint("TOPLEFT",a,"TOPLEFT",0,0)
c:SetPoint("TOPRIGHT",a,"TOPRIGHT",0,0)
c:SetHeight(b)
d:ClearAllPoints()
d:SetPoint("BOTTOMLEFT",a,"BOTTOMLEFT",0,0)
d:SetPoint("BOTTOMRIGHT",a,"BOTTOMRIGHT",0,0)
d:SetHeight(b)
e:ClearAllPoints()
e:SetPoint("TOPLEFT",a,"TOPLEFT",0,0)
e:SetPoint("BOTTOMLEFT",a,"BOTTOMLEFT",0,0)
e:SetWidth(b)
f:ClearAllPoints()
f:SetPoint("TOPRIGHT",a,"TOPRIGHT",0,0)
f:SetPoint("BOTTOMRIGHT",a,"BOTTOMRIGHT",0,0)
f:SetWidth(b)
end


local function n(a)
return _ or H==a or w==a or k==a or a.isEntered
end

local function D(a,b)
a.label:SetText(a.name()..(b or a.note or""))
a.label:SetShown(n(a))
end




function b.wheeled(d,a,e,f,g)
local b=F.field(a,"scale")
local c=b.step or F.SCALE.step
local a=e+f*c*(g and 5 or 1)
a=math.min(math.max(a,b.min or F.SCALE.min),b.max or F.SCALE.max)
a=tonumber(string.format("%.6f",math.floor(a/c+0.5)*c))
d.note=string.format("  Scale %.2fx",a)
D(d)
return a
end







local W=0.3
b.WHEEL_REST=W

local n
local u=CreateFrame("Frame")
u:Hide()


local function V()
if not n then return end
n.pending,n.base,n=nil,nil,nil
u:Hide()
end

local function an(a)
return not a.alive()or a.scaleNow()~=a.base
end

local function A()
local a=n
if not a then return end
local b=a.pending
if an(a)then return V()end
V()
if b~=a.scaleNow()then a.writeScale(b)end
end
u:SetScript("OnUpdate",function(a,b)
a.left=a.left-b
if a.left<=0 then A()end
end)

function b.wheel(a,c,d)
if n and n~=a then A()end
if not a.scaleRecord then return end
if n==a and an(a)then V()end
local b=b.wheeled(a,a.scaleRecord,a.pending or a.scaleNow(),c,d)
local c,d=a.pending,a.base or a.scaleNow()
a.pending,a.base=b,d
if a.preview and a.preview(b)then
n=a
u.left=W
u:Show()
else
a.pending,a.base=c,nil
a.writeScale(b)
end
end

M.on("PLAYER_LOGOUT","placement",function()A()end)


local u
local function ax()
local a,b=C()
local a,b=a/2+u.x-P/2,b+u.y
return a,b-Z,a+P,b
end
local function ay(a,b,c,d,e,f,g,h)
return a<g and e<c and b<h and f<d
end



local function az(f,a,b)
local c,d=C()
local e,g,c,a=unpack(a)
local h,i,j,k=ax()
local function c(c)
local a=c and a+2 or g-2-O
local c=a+O
if c>d or a<0 then return false end
if ay(e,a,e+aq,c,h,i,j,k)then return false end
if b and f.draggable and a<b[2]and c>b[1]then return false end
return true
end
if c(true)then return"above"end
if c(false)then return"below"end
return a+2+O>d and"below"or"above"
end

local function aA(a,b)
a.labelSide=b
a.label:ClearAllPoints()
if b=="below"then
a.label:SetPoint("TOPLEFT",a,"BOTTOMLEFT",0,-2)
else
a.label:SetPoint("BOTTOMLEFT",a,"TOPLEFT",0,2)
end
end


local function W()
local b,c=GetCursorPosition()
local a=UIParent:GetEffectiveScale()
return b/a,c/a
end




function b.snapBox(a,b,c,d,f,g,h,i,e)
local f,h=B((a+c)/2,(c-a)/2,f,h/2,e)
local e,g=B((b+d)/2,(d-b)/2,g,i/2,e)
return f-(a+c)/2,e-(b+d)/2,h,g
end




function b.snapTargets(d)
local a,c={},{}
if not e.ui().snap then return a,c end
if d.kind=="layer"then
local function f(b)
a[#a+1],a[#a+2],a[#a+3]=b[1],(b[1]+b[3])/2,b[3]
c[#c+1],c[#c+2],c[#c+3]=b[2],(b[2]+b[4])/2,b[4]
end
local e=d.aims
f(e and e.whole.rect or ao(d).rect)
for b,a in ipairs(e and e.list or b.anchorCandidates(d))do f(a.rect)end
return a,c
end
local b,e=C()
a[1],c[1]=b/2,e/2
for e,b in ipairs(m)do
if b~=d and b.draggable then
local d=b.position()
local d,e,f,g=b.rectAt(d.x,d.y)
if b.pieces and b.pieces.n>0 then
a[#a+1],c[#c+1]=(d+f)/2,(e+g)/2
else
a[#a+1],a[#a+2],a[#a+3]=d,(d+f)/2,f
c[#c+1],c[#c+2],c[#c+3]=e,(e+g)/2,g
end
end
end
return a,c
end

local function aD(a,d,f)
local c=e.ui()
if not(c.snap or c.grid)then return d,f end
local e,g=C()

local h,i=a.snapX,a.snapY
local j,k,l,m=a.rectAt(d,f)
local b,c,e,g=b.snapBox(j,k,l,m,h,i,e,g,c.grid and c.gridSize or nil)
E(e,g)
local a=a.unit()
return d+b/a,f+c/a
end

local ao=3
local B
local function aE(a)

if not a.alive()then return B(a)end
local b,c=W()
if not a.to and math.abs(b-a.from.cx)<ao and math.abs(c-a.from.cy)<ao then return end
local d=a.unit()
local b,c=a.from.x+(b-a.from.cx)/d,a.from.y+(c-a.from.cy)/d

local d=a.at or{}
a.at=d
if a.slotted then
d.x,d.y=b,c
a.to=d
a.moveTo(b,c)
local b,a=l,a.aimAt(b,c)
if a~=b then
l=a
if b then x(b)end
if a then x(a)end
end
return
end
b,c=aD(a,b,c)

if a.broken then
a.to=nil
return B(a)
end
b,c=L(b),L(c)


local e=a.kind=="layer"and IsControlKeyDown()and true or false
if a.kind=="layer"and a.to and a.to.x==b and a.to.y==c and a.ctrl==e then return end
d.x,d.y=b,c
a.to,a.ctrl=d,e
a.moveTo(b,c)

if a.kind=="layer"then
a.against=e and aC(a,b,c)or nil
if a.broken then
a.to=nil
return B(a)
end
local b=a.against and a.aims.mover[a.against]or nil
local c=a.against and a.against.piece or nil
if b~=l or c~=s then
local a=l
l,s=b,c
if a and a~=b then x(a)end
if b then x(b)end
end
if a.against then
if a.labelled~=a.against then a.label:SetText(a.aims.words[a.against])end
a.labelled=a.against
return
end
a.labelled=nil
end

a.label:SetFormattedText("%s  %g, %g",a.dragName,b,c)
end



local function ao(a)
a.note=nil
local c=a.position()
local d,e=W()
a.from,a.to,a.against,a.ctrl,a.labelled={x=c.x,y=c.y,cx=d,cy=e},nil,nil,nil,nil
a.aims,a.moving=nil,nil
if a.kind=="layer"then
a.aims=aB(a)
local d,c,b=a.current()
a.dragDrawn,a.dragView=b,c

a.flowed=b
local c=af(a,c)
c[a.layer.src.."/"..tostring(a.layer.id)]=true
if b.reflowBegin then b:reflowBegin(c)end
a.moving={a}
for d,b in ipairs(m)do
if b~=a and b.kind=="layer"and c[b.layer.src.."/"..b.layer.id]then
a.moving[#a.moving+1]=b
end
end
end
a.snapX,a.snapY=b.snapTargets(a)
a.dragName=a.name()
k=a
x(a)
D(a)
a:SetScript("OnUpdate",aE)
end

function B(a)
a:SetScript("OnUpdate",nil)
k=nil
E()
if l then
local a=l
l,s=nil,nil
if a.alive()then x(a)end
end
local b=false
if a.alive()then
x(a)
D(a)

if a.to and(a.against or a.to.x~=a.from.x or a.to.y~=a.from.y)then b=a.commit(a.to.x,a.to.y)end
end
if a.kind=="layer"then ap(a,b)end
a.against,a.aims,a.moving,a.snapX,a.snapY,a.broken=nil,nil,nil,nil,nil,nil
a.dragDrawn,a.dragView=nil,nil
if Q then
Q=false
z()
end
end



local l={UP={0,1},DOWN={0,-1},LEFT={-1,0},RIGHT={1,0}}
local s=CreateFrame("Frame",nil,UIParent)
s:Hide()

local function af(a)
local a=l[a]

if not(a and w)or k then return end
A()
local b=IsShiftKeyDown()and 10 or 1

local c,d=w.saved()
w.commit(c+a[1]*b,d+a[2]*b)
end

local function aB()
local a=i and w~=nil and not w.slotted and not X.inCombat()
if a then
if not s.keys then
s:EnableKeyboard(true)
s.keys=true
end

s:SetPropagateKeyboardInput(true)
elseif s.keys and not InCombatLockdown()then

s:SetPropagateKeyboardInput(true)
end
s:SetShown(a)
end

local function E(a)
if w==a then return end
local b=w
w=a
if b then x(b)D(b)end
if a then x(a)D(a)end
aB()
end

s:SetScript("OnKeyDown",function(a,b)
if InCombatLockdown()then a:Hide()return end
if l[b]or b=="ESCAPE"then
a:SetPropagateKeyboardInput(false)

M.atFrameEnd("nudger",function()if not InCombatLockdown()then a:SetPropagateKeyboardInput(true)end end)
if b=="ESCAPE"then E(nil)return end
af(b)
a.held,a.wait=b,0.4
end
end)
s:SetScript("OnKeyUp",function(a,b)
if b==a.held then a.held=nil end
end)
s:SetScript("OnUpdate",function(a,b)
if not a.held then return end
a.wait=a.wait-b
if a.wait<=0 then
af(a.held)
a.wait=0.04
end
end)
s:SetScript("OnHide",function(a)a.held=nil end)




local function l(a)
if a.alive()then return false end
a:Hide()
return true
end

local function af(a,b)
A()
if l(a)or b~="LeftButton"or not a.draggable then return end
E(a)
ao(a)
end

local function ao(a,c)
A()
if k==a and not a.alive()then B(a)end
if l(a)then return end
if c=="LeftButton"then
if k==a then B(a)end
elseif c=="RightButton"then

if IsShiftKeyDown()then
b.openPage(a)
elseif f then
b.leave()
elseif d then
if a.kind=="member"then b.enterElement(a.id)else b.leave()end
elseif a.kind=="group"then
b.enter(a.id)
elseif a.kind=="element"then
b.enterElement(a.id)
end
end
end

local function ap(a,c)
if l(a)or not a.draggable then return end
b.wheel(a,c,IsShiftKeyDown())
end


local function l(a)
if not(a.alive()and a.draggable)then return end
H=a
x(a)
D(a)
end
local function aC(a)
if n==a then A()end
if H~=a then return end
H=nil
a.note=nil
if a.alive()then
x(a)
D(a)
end
end




function b.pieces(a)
local b={}
for d,c in ipairs(a.layers or{})do
local d,e=g.rect(c,a.baseSize,a.allLayers or a.layers)
for c,a in ipairs(g.pieces(c,a.baseSize))do
b[#b+1]={x=d+a.x,y=e+a.y,w=a.w,h=a.h}
end
end
return b
end



local function aD(b,d,c,a)
local f,g=a and a.x or 0,a and a.y or 0
b.pieces=b.pieces or{n=0}
for e,d in ipairs(d)do
local a=b.pieces[e]
if not a then
a=CreateFrame("Frame",nil,b)
a.fill=a:CreateTexture(nil,"BACKGROUND")
a.fill:SetAllPoints(a)
a.edges={}
for b=1,4 do a.edges[b]=a:CreateTexture(nil,"BORDER")end
a:SetScript("OnMouseDown",function(c,a)af(b,a)end)
a:SetScript("OnMouseUp",function(c,a)ao(b,a)end)
a:SetScript("OnMouseWheel",function(c,a)ap(b,a)end)
a:SetScript("OnEnter",function()l(b)end)
a:SetScript("OnLeave",function()aC(b)end)
b.pieces[e]=a
end
a:ClearAllPoints()
a:SetPoint("TOPLEFT",b,"TOPLEFT",(d.x-f)*c,-(d.y-g)*c)
a:SetSize(math.max(d.w*c,1),math.max(d.h*c,1))
a:Show()
end
for a=#d+1,#b.pieces do b.pieces[a]:Hide()end
b.pieces.n=#d
end
local function aE(a)
if not a.pieces then return end
for b=1,#a.pieces do a.pieces[b]:Hide()end
a.pieces.n=0
end

function ae(b,d,c,h,a)
local c,d,e,f=g.rect(d,c.baseSize,R(c))
c,d,e,f=g.onPixels(c,d,e,f,a)
b:ClearAllPoints()
b:SetPoint("TOPLEFT",h,"TOPLEFT",c*a,-d*a)
b:SetSize(math.max(e*a,1),math.max(f*a,1))
end

function aw(a,b,c,e,d)
ae(a,b,c,e,d)
local b=g.pieces(b,c.baseSize)
if#b>1 then aD(a,b,d)else aE(a)end
end

local function ae(c,b,d)
local a=r[c]
if not a then
a=CreateFrame("Frame",nil,UIParent)
a:SetFrameStrata("DIALOG")
a.fill=a:CreateTexture(nil,"BACKGROUND")
a.fill:SetAllPoints(a)
a.edges={}
for b=1,4 do a.edges[b]=a:CreateTexture(nil,"BORDER")end
a.label=a:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
a:SetScript("OnMouseDown",af)
a:SetScript("OnMouseUp",ao)
a:SetScript("OnMouseWheel",ap)
a:SetScript("OnEnter",l)
a:SetScript("OnLeave",aC)
r[c]=a
end
a.kind,a.id=b,d
if b=="group"then aF(a)elseif b=="special"then aN(a)
elseif b=="layer"then aM(a)else aL(a)end
return a
end


local l=CreateFrame("Frame",nil,UIParent)
l:SetFrameStrata("DIALOG")
l:SetFrameLevel(T.buttons)
l:SetSize(40,16)
l:EnableMouse(true)
l.fill=l:CreateTexture(nil,"BACKGROUND")
l.fill:SetAllPoints(l)
l.fill:SetColorTexture(0.2,0.6,1,0.9)
l.text=l:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
l.text:SetPoint("CENTER",l,"CENTER",0,0)
l.text:SetText("Done")
l:SetScript("OnMouseUp",function()b.leave()end)
l:Hide()




local a=CreateFrame("Frame",nil,UIParent)
a:SetFrameStrata("DIALOG")
a:SetFrameLevel(T.buttons)
a:SetWidth(P)
a:EnableMouse(true)
a:Hide()


local ao={"Click, then arrow keys","Nudge (Shift: 10)"}
local ap={"Mouse wheel","Scale (Shift: faster)"}
local R={"Alt","Show every name"}
local af={"Shift + right-click","Open its page"}
local aC={"Right-click","Enter an element, or leave the group"}
local aF={"Done","Leave the group"}
local R={
top={{"Drag","Move a group or element"},ao,ap,R,{"Right-click","Enter a group or an element"},
af},
free={{"Drag","Move it within the group"},ao,ap,R,aC,aF,af},
slots={{"Drag","Drop on another's place to reorder"},ap,R,aC,aF,af},
layers={{"Drag","Move the layer within its element"},
{"Ctrl + drag","Drop it against a layer: it moves with that layer"},ao,R,
{"Right-click or Done","Leave the element"},af},
}
local ap=7
local af="CANCEL_PLACING"



u={x=0,y=aH}
local function ao()
local b,c=C()
local b=(b-P)/2
u.x=math.min(math.max(u.x,-b),b)
u.y=math.min(math.max(u.y,Z-c),0)
a:ClearAllPoints()
a:SetPoint("TOP",UIParent,"TOP",u.x,u.y)
end
a:SetScript("OnMouseDown",function(a,b)
if b~="LeftButton"then return end
local b,c=W()
a.from={x=u.x,y=u.y,cx=b,cy=c}
a:SetScript("OnUpdate",function()
local b,c=W()
u.x,u.y=a.from.x+b-a.from.cx,a.from.y+c-a.from.cy
ao()
end)
end)
local function u(a)
if not a.from then return end
a.from=nil
a:SetScript("OnUpdate",nil)

if i then z()end
end
a:SetScript("OnMouseUp",u)
a:SetScript("OnHide",u)


local function u(c)
local b,a=e.ui().gridSize,nil
if c then
for c=#J,1,-1 do
if J[c]>b then a=J[c]end
end
else
for d,c in ipairs(J)do
if c<b then a=c end
end
end
if a then e.editUI(function(b)b.gridSize=a end)end
end

local function aC()
local f=c.Kit
a.fill=a:CreateTexture(nil,"BACKGROUND")
a.fill:SetAllPoints(a)
f.fill(a.fill,"windowBg",0.92)

a.edges={}
for b=1,4 do
a.edges[b]=a:CreateTexture(nil,"BORDER")
a.edges[b]:SetColorTexture(unpack(N.idle))
end
ad(a)

local d=CreateFrame("Frame",nil,a)
d:SetPoint("TOPLEFT")
d:SetPoint("TOPRIGHT")
d:SetHeight(1)
a.unlockHalf=d
a.title=f.fontString(d,"windowTitle")
a.title:SetPoint("TOPLEFT",h,-h)
a.title:SetText("InterHUD: positioning unlocked")

local i=0
for b,a in pairs(R)do
for b,a in ipairs(a)do i=math.max(i,f.textWidth("small",a[1]))end
end
i=math.ceil(i)
a.help={}
for c=1,ap do
local e=-(h+U+6+(c-1)*ag)
local b={key=f.fontString(d,"small"),what=f.fontString(d,"small")}
f.tint(b.key,"gold")
b.key:SetWidth(i)
b.key:SetJustifyH("RIGHT")
b.key:SetWordWrap(false)
b.key:SetPoint("TOPLEFT",h,e)
b.what:SetPoint("TOPLEFT",h+i+Y,e)
b.what:SetJustifyH("LEFT")
a.help[c]=b
end


local j=0
for b,a in pairs(R)do
for b,a in ipairs(a)do j=math.max(j,f.textWidth("small",a[2]))end
end
local n=i+Y+math.ceil(j)
local d=CreateFrame("Frame",nil,d)
d:SetPoint("TOPLEFT",h+n+y,-(h+U+6-ar))
local k,i=0,ai

local function o(a,b)
a:SetPoint("LEFT",d,"TOPLEFT",0,-(k*v+v/2))
k=k+1
i=math.max(i,b)
end

local function l(a,b,c)
local a=f.checkBox(a,ah)
a.text=f.fontString(a,"small")
a.text:SetPoint("LEFT",a,"RIGHT",6,0)
a.text:SetText(b)
local b=ah+6+math.ceil(f.textWidth("small",b))
a:SetHitRectInsets(0,-(b-ah),0,0)
a:SetScript("OnClick",function(b,a)
if a and a~="LeftButton"then return end
c()
end)
return a,b
end
local function m(a,b)
local a,b=l(d,a,b)
o(a,b)
return a
end
local function j(a)return function()e.editUI(function(b)b[a]=not e.ui()[a]end)end end
a.snapAll=m("Snap to groups and elements",j("snap"))
a.snapGrid=m("Snap to grid",j("grid"))
a.hideGrid=m("Hide grid",j("gridHidden"))

a.alerts=m("Spell Alerts",j("previewAlerts"))

a.grid=CreateFrame("Frame",nil,d)
a.grid:EnableMouseWheel(true)
a.grid:SetScript("OnMouseWheel",function(b,a)
e.editUI(function(b)b.gridSize=e.ui().gridSize+a*4 end)
end)
local e=f.fontString(a.grid,"small")
e:SetPoint("LEFT",0,0)
e:SetText("Grid size")
local e=math.ceil(f.textWidth("small","Grid size"))
a.gridDown=f.button(a.grid,"-",20,20)
a.gridDown:SetPoint("LEFT",e+8,0)
a.gridDown:SetScript("OnClick",function()u(false)end)
a.gridValue=f.fontString(a.grid,"small")
a.gridValue:SetPoint("LEFT",a.gridDown,"RIGHT",2,0)
local m=math.ceil(f.textWidth("small","128"))+6
a.gridValue:SetWidth(m)
a.gridUp=f.button(a.grid,"+",20,20)
a.gridUp:SetPoint("LEFT",a.gridValue,"RIGHT",2,0)
a.gridUp:SetScript("OnClick",function()u(true)end)
local e=e+8+20+2+m+2+20
a.grid:SetSize(e,v)
o(a.grid,e)
a.lock=f.button(d,"Lock",ai,v)
a.lock:SetPoint("BOTTOMRIGHT",0,0)
a.lock:SetScript("OnClick",function()b.setUnlocked(false)end)

local e=math.ceil(f.textWidth("button","Cancel"))+ak
a.cancel=f.button(d,"Cancel",e,v)
a.cancel:SetPoint("RIGHT",a.lock,"LEFT",-Y,0)
a.cancel:SetScript("OnClick",function()b.askCancel()end)

f.confirm(af,"Put everything back where it was when you unlocked?","Put back",function()
b.cancel()
end)
StaticPopupDialogs["INTERHUD_"..af].button2="Keep"

local m=math.ceil(f.textWidth("button","Preview mode"))+ak
a.previewButton=f.button(d,"Preview mode",m,v)
a.previewButton:SetScript("OnClick",function()c.PreviewMode.toggle()end)
a.previewButton:SetPoint("BOTTOMLEFT",0,0)
i=math.max(i,m+y+e+Y+ai)
aj=k*v+aI+v
d:SetSize(i,aj)

as=2*h
+math.max(n+y+i,math.ceil(f.textWidth("windowTitle",a.title:GetText())))

local d=CreateFrame("Frame",nil,a)
d:SetHeight(au)
a.previewHalf=d
d.rule=d:CreateTexture(nil,"BORDER")
d.rule:SetColorTexture(unpack(N.idle))
d.rule:SetPoint("TOPLEFT",h,0)
d.rule:SetPoint("TOPRIGHT",-h,0)
d.rule:SetHeight(g.pixel(a))
d.title=f.fontString(d,"windowTitle")
d.title:SetPoint("TOPLEFT",h,-h)
d.title:SetText("Preview")
d.line=f.fontString(d,"small")
d.line:SetPoint("TOPLEFT",h,-(h+U+6))
d.line:SetText("Every element switched on, with sample states and events occasionally.")
local g=h+v/2
local e,i,k
d.unlearned,e=l(d,"Show unlearned",j("previewUnlearned"))
d.unlearned:SetPoint("LEFT",d,"BOTTOMLEFT",h,g)
d.muted,i=l(d,"Mute sounds",
function()c.PreviewMode.setMuting(not c.PreviewMode.muting())end)
d.muted:SetPoint("LEFT",d,"BOTTOMLEFT",h+e+y,g)

d.alerts,k=l(d,"Spell Alerts",j("previewAlerts"))
d.alerts:SetPoint("LEFT",d,"BOTTOMLEFT",h+e+y+i+y,g)
d.stop=f.button(d,"End preview",av,v)
d.stop:SetPoint("BOTTOMRIGHT",-h,h)
d.stop:SetScript("OnClick",function()c.PreviewMode.set(false)end)

local c=math.ceil(f.textWidth("button","Unlock positioning"))+ak
d.unlock=f.button(d,"Unlock positioning",c,v)
d.unlock:SetPoint("RIGHT",d.stop,"LEFT",-y,0)
d.unlock:SetScript("OnClick",function()b.setUnlocked(true)end)
at=2*h+math.ceil(math.max(f.textWidth("windowTitle",d.title:GetText()),
f.textWidth("small",d.line:GetText()),
e+y+i+y+k+y+c+y+av))
a.built=true
end

b.frames={nudger=s,done=l,bar=a,grid=o,guides=j}

local function j()
local b=e.ui()

if i and not b.gridHidden then
aJ(b.gridSize)
o:Show()
else
o:Hide()
end
if not a.built then return end
a.snapGrid:setChecked(b.grid)
a.snapAll:setChecked(b.snap)
a.hideGrid:setChecked(b.gridHidden)
a.alerts:setChecked(b.previewAlerts)

a.cancel:setEnabled(G~=nil)
a.gridValue:SetText(tostring(b.gridSize))

a.gridDown:setEnabled(b.gridSize>J[1])
a.gridUp:setEnabled(b.gridSize<J[#J])
local e=f and R.layers or not d and R.top
or q(d).view.arrangement=="free"and R.free or R.slots
for a,b in ipairs(a.help)do
local a=e[a]
b.key:SetText(a and a[1]or"")
b.what:SetText(a and a[2]or"")
end

local d=c.PreviewMode.isOn()
a.previewHalf.unlearned:setChecked(b.previewUnlearned)
a.previewHalf.muted:setChecked(c.PreviewMode.muting())
a.previewHalf.alerts:setChecked(b.previewAlerts)
a.previewHalf.alerts:SetShown(not i)
local c=i and h+U+6+math.max(#e*ag,aj-ar)+h or 0
a.unlockHalf:SetShown(i)
a.unlockHalf:SetHeight(math.max(c,1))
local b=a.previewHalf
b:SetShown(d)
b.rule:SetShown(i)
b.unlock:SetShown(not i)
b:ClearAllPoints()
b:SetPoint("TOPLEFT",0,-c)
b:SetPoint("TOPRIGHT",0,-c)
Z=c+(d and au or 0)
P=math.max(i and as or 0,d and at or 0)
a:SetSize(P,math.max(Z,1))
ao()
end



function b.paintBanner()
local b=i or c.PreviewMode.isOn()
if b and not a.built then aC()end
j()
a:SetShown(b)
end




local function h(c,a)
if a~="LeftButton"or not(d or f)then return end
local a=f and r["element "..f]or r["group "..d]
if not(a and a.alive())then return end
local g,h=W()
local c=a.position()
local i,c,d,e=a.rectAt(c.x,c.y)
local j=O+6
if a.labelSide=="below"then c=c-j else e=e+j end
d=math.max(d,i+aq+46)
local g=function(a,b,c,d)return g>=a and g<=c and h>=b and h<=d end
if g(i,c,d,e)or g(ax())then return end

for b,a in ipairs(m)do
if a.kind=="member"and not f and a:IsShown()then
local b=a.position()
if g(a.rectAt(b.x,b.y))then return end
end
end
b.leave()
end


function z()
if n and an(n)then V()end
if k then
Q=false
B(k)
end


local a=d and q(d)
if d and not(a and a.view and a.view.enabled~=false)then d=nil end
local k=d~=nil and a.view.arrangement~="free"

if f and not(t.drawn(f)and p.of(f)==d)then
f=nil
end


for b,a in pairs(r)do a.draggable,a.isEntered=false,nil end
wipe(m)
l:Hide()
if(d or f)and i then M.on("GLOBAL_MOUSE_DOWN","placement",h)
else M.off("GLOBAL_MOUSE_DOWN","placement")end

j()
if not i then
for b,a in pairs(r)do a:Hide()end
return
end
local a=e.profile()
for a,b in ipairs(a and a.groups or{})do
local a=q(b.id)

if a and a.view and a.view.enabled~=false then
local b=ae("group "..b.id,"group",b.id)
b:ClearAllPoints()
b:SetAllPoints(a.frame)
m[#m+1]=b
end
end
local a=t.drawnIds()
for a,e in ipairs(a)do
local h=t.drawn(e)
local f=p.of(e)
if not f or f==d then
local a=ae("element "..e,f and"member"or"element",e)
a.slotted=f~=nil and k


local d=a.rootScale()
local f=g.bounds(h.view,nil,d)
a:ClearAllPoints()
a:SetPoint("TOPLEFT",h.root,"TOPLEFT",f.x*d,-f.y*d)
a:SetSize(f.w*d,f.h*d)
a.alert=F.alertFlag(h.view,"below")
if a.alert then aD(a,b.pieces(h.view),d,f)else aE(a)end
m[#m+1]=a
aO(a,c.PreviewMode.isOn()and t.hiddenWhy(e)or nil)
end
end

local b=f and t.drawn(f)
if b then
local d,e=ac(b),r["element "..f].rootScale()
for g,a in ipairs(d.layers)do
local c=ae("layer "..f.."/"..tostring(a.source).."/"..tostring(a.id),
"layer",f)
c.layer={src=a.source,id=a.id,index=g}
aw(c,a,d,b.root,e)
m[#m+1]=c
end
end

if not(d or f)then
for a,b in ipairs(c.Specials.placeable())do
local a=c.Specials.boxes(b)
for c,a in ipairs(a or{false})do
local b=ae("special "..b..(a and("/"..tostring(a.id))or""),"special",b)
b.box=a and a.id or nil
local a=b.position()
b.place(a.x,a.y)
m[#m+1]=b
end
end
end

local g
for b,a in ipairs(m)do


local c,b
if f then
c=a.kind=="layer"
b=(a.kind=="element"or a.kind=="member")and a.id==f
else
c=d~=nil and a.kind=="member"
b=a.kind=="group"and a.id==d
end
a.isEntered=b or nil
a.draggable=not(d or f)or c
a:SetFrameLevel(c and T.member or a.alert and T.alert or T.mover)

local e=a.pieces~=nil and a.pieces.n>0
a:EnableMouse((a.draggable or b)and not e)

local h=a.draggable and a.scaleRecord~=nil
a:EnableMouseWheel(h and not e)
for c=1,e and a.pieces.n or 0 do
a.pieces[c]:EnableMouse(a.draggable or b)
a.pieces[c]:EnableMouseWheel(h)
end
a:SetAlpha((not(d or f)or c or b)and 1 or 0.3)
local c=a.position()
a.rect={a.rectAt(c.x,c.y)}
if b then
local b=az(a,a.rect)
aA(a,b)
local b=b=="above"and a.rect[4]+2 or a.rect[2]-2-O
g={b,b+O}
l:ClearAllPoints()
l:SetPoint("LEFT",a.label,"RIGHT",6,0)
l:Show()
end
end
local b,c=false,false
for d,a in ipairs(m)do
if not a.isEntered then aA(a,az(a,a.rect,g))end
ad(a)
if a==w then b=true end
if a==H and a.draggable then c=true end
end
if w and not b then E(nil)end
if not c then H=nil end
local b={}
for c,a in ipairs(m)do
x(a)
D(a)
a:Show()
b[a]=true
end
for c,a in pairs(r)do
if not b[a]then a:Hide()end
end

if n and n:IsShown()then n.preview(n.pending)
elseif n then A()end
end



function b.reorder(a,d,f)
if not f then return false end
return e.editGroup(a,function(a)
local c=a.members or{}
local a,b
for c,e in ipairs(c)do
if e==d then a=c end
if e==f then b=c end
end
if not(a and b)or a==b then return end
table.remove(c,a)
table.insert(c,b,d)
end)
end

function b.enter(a)
d,f=a,nil
E(nil)
z()
end



function b.enterElement(a)
if not(i and t.drawn(a))or p.of(a)~=d then return false end
f=a
E(nil)
z()
return true
end
function b.enteredElement()return f end


function b.leave()
if f then f=nil else d=nil end
E(nil)
z()
end

function b.unlocked()return i end


function b.select(a)
local a=r["element "..tostring(a)]
if i and a and a:IsShown()and a.draggable then E(a)end
end

function b.selectLayer(b,a,c)
local a=r["layer "..tostring(b).."/"..tostring(a).."/"..tostring(c)]
if i and f==b and a and a:IsShown()and a.draggable then E(a)end
end
function b.entered()return d end



function b.openPage(a)
local b=c.Window
if not c.Kit.window():isShown()then b.toggle()end
local d=(a.kind=="group"or a.kind=="special")and a.kind or"element"
local b=b.select(d,a.id)

if b and a.kind=="layer"then c.PageElement.select(a.id,"layer:"..a.layer.src.."/"..a.layer.id)end
return b
end


function b.refreshMovers()
if not i then return end
if k then Q=true else z()end
end


function b.namesHeld()
local a=IsAltKeyDown()and true or false
if a==_ then return end
_=a
for b,a in ipairs(m)do D(a)end
end


function b.askCancel()
if not(i and G)then return end
if c.equal(e.placement(),G)and not n and not(k and k.to)then
return b.setUnlocked(false)
end
c.Kit.showPopup(af)
end



function b.cancel()
if not(i and G)then return false end
A()
if k then B(k)end
local d,a=e.restorePlacement(G)
if not d then
c.print("couldn't put everything back: "..tostring(a and a[1]and a[1].text))
return false
end
return b.setUnlocked(false)
end

function b.setUnlocked(a)
a=a and true or false

if a and t.off()then
c.print("off for this character; /ihud on first.")
return false
end
if a and X.inCombat()then
c.print("Positioning can't be unlocked in combat.")
return false
end
A()
if k then B(k)end
if a and not i then G=e.placement()end
if not a then
G=nil
StaticPopup_Hide("INTERHUD_"..af)
end
i,d,f,H,_=a,nil,nil,nil,false

if a then
M.on("MODIFIER_STATE_CHANGED","placement",b.namesHeld)
else
M.off("MODIFIER_STATE_CHANGED","placement")
end
E(nil)
aG.setPlacing(a)


c.Specials.placing(a)

c.PreviewMode.setPlacing(a)
b.paintBanner()
z()
return true
end

t.onLayout("placement",function()
if not i then return end



local a=k
if a and a.kind=="layer"then
local b=t.drawn(a.id)
if b~=a.dragDrawn or not c.equal(ac(b),a.dragView)then
a.to=nil
z()
else
Q=true
end
return
end
if k then Q=true else z()end
end)
c.onChanged(function(a)

if a=="profile"then
V()
G=nil

if k and k.kind=="layer"then
k.to=nil
B(k)
end
end
if a=="ui"then
j()
elseif a=="char"and i and t.off()then

b.setUnlocked(false)
end
end,"placement")

X.onStart("placement",function()
s:Hide()
if i then
b.setUnlocked(false)
c.print("Positioning locked for combat.")
end
end)
X.onEnd("placement",aB)






local k,l=1365,768
local h=48


local g=8

local function n(a)return F.alertFlag(a,"loose")end
local function o(a)
local b=a.position
return aK(a,p.scaleOf(a),K(b.point,b.x,b.y))
end


local function j(b,d)
local a=S.group(b,d)
if a.enabled==false then return nil end
local c={}
for b,a in ipairs(b.members or{})do c[#c+1]=e.element(a)end
local b={}
b.x,b.y,b.w,b.h=p.measureRecords(a,c,d)
return{aa(a,b,a.position.x,a.position.y)}
end



local function r(d,g,h)
local a,f={},nil
for b,c in ipairs(d.groups or{})do
if h then
a[#a+1]=j(c,d)
else
local b=q(c.id)
if b and b.view and b.view.enabled~=false and b.w and b.h then
a[#a+1]={ab(c.id,b.view.position.x,b.view.position.y)}
end
end
end
for h,c in ipairs(d.elements or{})do
if c.id~=g and not e.groupOf(c.id)then
local c=S.element(c,d)
if not n(c)then
a[#a+1]={o(c)}
f=a[#a]
else

local d=p.scaleOf(c)
local e,f=al(c,d,K(c.position.point,c.position.x,c.position.y))
for c,b in ipairs(b.pieces(c))do
a[#a+1]={e+b.x*d,f-(b.y+b.h)*d,e+(b.x+b.w)*d,f-b.y*d}
end
end
end
end
for d,b in ipairs(c.Specials.placeable())do
local d=c.Specials.boxes(b)
if d then

for d,c in ipairs(d)do
if not c.open then a[#a+1]={am(b,c.position.x,c.position.y,c.id)}end
end
else
local c=c.Specials.view(b).position
a[#a+1]={am(b,c.x,c.y)}
end
end
return a,f
end

local function j()
local a,b=C()
return math.max(0,(a-k)/2),math.min(a,(a+k)/2),math.max(0,(b-l)/2),
math.min(b,(b+l)/2)
end


local function l(d,e,f,g,a,b)
local h,i,j,k=j()
local c={}

for l=math.floor((h-d)/a)-1,math.ceil((i-f)/a)+1 do
for m=math.floor((j-e)/b)-1,math.ceil((k-g)/b)+1 do


local a,b=I(l*a),I(m*b)
if d+a>=h and f+a<=i and e+b>=j and g+b<=k then
c[#c+1]={a,b,a*a+b*b}
end
end
end
table.sort(c,function(a,b)
if a[3]~=b[3]then return a[3]<b[3]end
if math.abs(a[2])~=math.abs(b[2])then return math.abs(a[2])<math.abs(b[2])end
if a[1]~=b[1]then return a[1]>b[1]end
return a[2]<b[2]
end)
return c
end

local function q(a,e,f,h,i,j)
for b,a in ipairs(a)do
local b,c=a[1],a[2]
local d=true
for j,a in ipairs(j)do
if ay(e+b-g,f+c-g,h+b+g,i+c+g,a[1],a[2],a[3],a[4])then
d=false
break
end
end
if d then return a end
end
end






function b.landing(c)
local d=e.profile()
local b=S.element(c,d)
local a=b.position
local k={point=a.point,x=a.x,y=a.y}
if n(b)then return k end

local m,d=r(d,c.id,true)
local b,f,i,c=o(b)

local g=l(b,f,i,c,i-b+g,c-f+g)
local e=q(g,b,f,i,c,m)
if e then return{point=a.point,x=a.x+e[1],y=a.y+e[2]}end


if d then
local k,l,n,o=j()
local function j(d,e)
for f,a in ipairs(m)do
if math.abs(a[1]-(b+d))<0.5 and math.abs(a[4]-(c+e))<0.5 then return true end
end
return false
end
local d,e=I(d[1]+h-b),I(d[4]-h-c)
while b+d>=k and i+d<=l and f+e>=n and c+e<=o do
if not j(d,e)then return{point=a.point,x=a.x+d,y=a.y+e}end
d,e=I(d+h),I(e-h)
end

for c,b in ipairs(g)do
if not j(b[1],b[2])then return{point=a.point,x=a.x+b[1],y=a.y+b[2]}end
end
end
return k
end



local n=32

local function o(b,c,d,e,a)
local b=math.min(d+g,a[3])-math.max(b-g,a[1])
local a=math.min(e+g,a[4])-math.max(c-g,a[2])
return(b>0 and a>0)and b*a or 0
end









function b.groupLanding(m,b)
local k=e.profile()
local h=S.group(m,k)
local a={}
a.x,a.y,a.w,a.h=p.measureRecords(h,b,k)
local i=h.position
local b,c=i.x,i.y
local d,e,f,g=aa(h,a,b,c)
if not m.position then
local i,j=C()
b,c=b+L(i/2-(d+f)/2),c+L(j/2-(e+g)/2)
d,e,f,g=aa(h,a,b,c)
end

local k=r(k,nil,true)
local l=l(d,e,f,g,n,n)
local a=q(l,d,e,f,g,k)
if not a then
local h
for c,b in ipairs(l)do
local c=0
for h,a in ipairs(k)do c=c+o(d+b[1],e+b[2],f+b[1],g+b[2],a)end
if not h or c<h then a,h=b,c end
end
end
if not a then


local h,j,k,l=j()
local function a(a,b,c,d)
if b-a>d-c then return L((c+d)/2-(a+b)/2)end
if a<c then return I(c-a)end
if b>d then return I(d-b)end
return 0
end
return{point=i.point,x=b+a(d,f,h,j),y=c+a(e,g,k,l)}
end
return{point=i.point,x=b+a[1],y=c+a[2]}
end


function b.describe()
local a=e.ui()
local function b(a)return a and"on"or"off"end
return{string.format("placing: %s%s; snap to grid %s, to elements %s, grid %s%s; %d movers",
i and"unlocked"or"locked",(d and(", in group "..d)or"")
..(f and(", in element "..f)or""),b(a.grid),
b(a.snap),a.gridSize,a.gridHidden and" (hidden)"or"",#m)}
end

