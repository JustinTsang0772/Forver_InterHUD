




local a,b=...
local f,g,s,l,h,m,n,t=b.Store,b.Resolve,b.Schema,b.Combat,b.HUD,b.Placement,
b.Showing,b.Debug

local a={}
b.Specials=a





























































local c,d={},{}

local function e(a,c,...)
local d=a.spec[c]
if d then b.try("special "..a.key.." "..c,d,...)end
end

local function i(a)
if not a.spec.relevant then return true end
local a,b=b.try("special "..a.key.." relevant",a.spec.relevant)
return a and b and true or false
end

local function o(a)return a.spec.switch or"enabled"end

local function p(a,c)
if not c then return false end
if a.spec.on then
local a,b=b.try("special "..a.key.." on",a.spec.on,c)
return a and b and true or false
end
return c[o(a)]~=false
end

local function k(b,a)
if not f.ready()then return nil end
a=a or f.profile()
return g.special(b,a and a.specials and a.specials[b],a)
end



function a.view(b,c)
local a=d[b]
if not c and a and a.running and not a.stopping and not a.busy and not a.again and a.view then
return a.view
end
return k(b,c)
end

local function u(a,b)
return f.ready()and not h.off()and i(a)and p(a,b)
end

local function q(b,c)
b.running,b.stopping,b.view,b.cantAct=false,nil,nil,nil
e(b,"stop",c)
a.laidOut()
end


local g=false
local function r()
local a=n.cantAct()
if a=="hide"and g then return nil end
return a
end

local function j(a)
local b=r()
if b==a.cantAct then return end
a.cantAct=b
e(a,"cantAct",b)
end


local function r(c,f)
local d=k(c.key)
if u(c,d)then
if not c.running then
c.running,c.view,c.cantAct=true,d,nil
e(c,"start",d)
if g then e(c,"placing",true)end
j(c)
a.laidOut()
elseif c.stopping or not b.equal(d,c.view)then

c.stopping,c.view=nil,d
e(c,"apply",d,f)
a.laidOut()
end
elseif c.running and not c.stopping then
local a=h.off()and"off"or(f=="profile"and"profile"or"switched")
if l.inCombat()then
c.stopping=a
e(c,"stopping",a)
else
q(c,a)
end
end
end



local function h(a,c,...)
a.busy=true
b.try("specials "..a.key,c,a,...)
while a.again do
local c=a.again
a.again=nil
b.try("specials "..a.key,r,a,c)
end
a.busy=false
end

local function k(a,b)
if a.busy then
a.again=b
return
end
h(a,r,b)
end

function a.register(a,e)
assert(type(a)=="string"and not d[a],"Specials: registered twice or unnamed: "..tostring(a))
local b=s.field("specials",a)
assert(b and b.record,"Specials: "..a.." declares no record in the profile's specials (Data/Fields.lua)")
local b={key=a,spec=e,running=false}
d[a]=b
c[#c+1]=b

if f.ready()then k(b,"profile")end
end


function a.keys()
local a={}
for b,c in ipairs(c)do a[b]=c.key end
return a
end

function a.get(a)
local a=d[a]
return a and a.spec
end


function a.running(a)
local a=d[a]
return a~=nil and a.running
end


b.onChanged(function(a,b)
if a=="profile"or a=="char"or a=="styles"then
for c,b in ipairs(c)do k(b,a)end
elseif a=="special"then
local a=d[b]
if a then k(a,"edit")end
end
end,"specials")


l.onEnd("specials",function()
for b,a in ipairs(c)do
if a.stopping then h(a,q,a.stopping)end
end
end)


function a.placing(a)
a=a and true or false
if a==g then return end
g=a
for c,b in ipairs(c)do
if b.running then
h(b,e,"placing",a)
h(b,j)
end
end
end


n.onCantAct("specials",function()
for b,a in ipairs(c)do
if a.running then h(a,j)end
end
end)


function a.placeable()
local d={}
for c,b in ipairs(c)do
if b.running and not b.stopping and((b.spec.box and a.box(b.key))or a.boxes(b.key))then
d[#d+1]=b.key
end
end
return d
end



function a.boxes(e)
local a=d[e]
if not(a and a.spec.boxes and a.running and not a.stopping)then return nil end
if a.boxes~=nil then return a.boxes or nil end
local c={}
local d,b=b.try("special "..e.." boxes",a.spec.boxes)
for b,a in ipairs(d and type(b)=="table"and b or{})do
if type(a)=="table"and a.id~=nil and type(a.w)=="number"and type(a.h)=="number"and a.w>0
and a.h>0 and type(a.position)=="table"then
c[#c+1]=a
end
end
a.boxes=#c>0 and c or false
return a.boxes or nil
end


function a.box(c)
local a=d[c]
if not(a and a.spec.box)then return nil end
local c,a,b=b.try("special "..c.." box",a.spec.box)
if c and type(a)=="number"and type(b)=="number"and a>0 and b>0 then return a,b end
return nil
end


function a.laidOut()
for b,a in ipairs(c)do a.boxes=nil end
if m.unlocked()then m.refreshMovers()end
end




function a.list(e)
local d={on={},off={},never={}}
for c,b in ipairs(c)do
local a=not i(b)and"never"or(p(b,a.view(b.key,e))and"on"or"off")
local c=d[a]
c[#c+1]={key=b.key,label=b.spec.label or b.key,icon=b.spec.icon,page=b.spec.page or b.key,
state=a,experimental=b.spec.experimental and true or nil}
end
local a={}
for c,b in ipairs({"on","off","never"})do
for c,b in ipairs(d[b])do a[#a+1]=b end
end
return a
end



function a.setOn(b,c)
local a=d[b]

if not(a and i(a))then return false end
local a=o(a)
return f.editSpecial(b,function(b)b[a]=c and true or false end)
end

function a.describe()
local d={"specials: "..#c.." registered"..(g and", placing"or"")}
for c,a in ipairs(c)do
local c=a.stopping and("stopping at combat's end ("..a.stopping..")")
or(a.running and"started")or(i(a)and"not started"or"not for this class")
d[#d+1]="  "..a.key..": "..c..(a.running and a.cantAct and(", "..a.cantAct)or"")
if a.running and a.spec.describe then
local b,a=b.try("special "..a.key.." describe",a.spec.describe)
for b,a in ipairs(b and type(a)=="table"and a or{})do d[#d+1]="    "..a end
end
end
return d
end
t.register("specials",a.describe)
