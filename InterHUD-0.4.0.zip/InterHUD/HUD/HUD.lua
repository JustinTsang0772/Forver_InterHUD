


local a,b=...
local d,h,q,z,j,g,i,u,v,r=b.Store,b.Resolve,b.Element,b.Spells,b.Events,
b.Groups,b.Showing,b.Layers,b.Combat,b.Schema

local a={}
b.HUD=a

local e={}
a.elements=e
local f={}
local m={}
local k={}






local function n()
return d.ready()and d.settings().showUnlearned==true
end
local t=false
local function o(a)
if n()then return true end
return h.kindLearned(a)
end
a.sourceLearned=o

local function p(a)
return n()or h.youKnow(a)
end
a.learned=p



function a.viewOf(b,c,a)
a=a or h.element(b,c)
local b=h.drawn(a,o)
b.learned=p(a)
return b,a
end

local function w(a)
for b,a in ipairs(a.sources or{})do
if#(a.layers or{})>0 then return true end
end
return false
end

function a.off()
local a=d.char()
return a~=nil and a.off==true
end



local function s(b)
return b.enabled and b.groupOn~=false and b.learned~=false and w(b)and not a.off()
end






local c


local function l(a)return r.alertFlag(a,"lit")end


function a.drawn(a)
if not c then return e[a]end
local b=c.standIns[a]
if b or c.all then return b end
local a=e[a]
return a and not l(a.view)and a or nil
end


function a.drawnIds()
local a={}
if c and c.all then
for b in pairs(c.standIns)do a[#a+1]=b end
return a
end
for b,d in pairs(e)do
if not(c and l(d.view))then a[#a+1]=b end
end
if c then
for b in pairs(c.standIns)do a[#a+1]=b end
end
return a
end



function a.hiddenWhy(b)
local a=e[b]
if not a then
local a=d.element(b)
local a=a and h.element(a,d.profile())
if not(a and a.enabled and a.groupOn~=false)then return"off"end
return not p(a)and"unlearned"or nil
end
if(a.view.otherwise or 0)==0 and not i.holds(a)then return"while"end
return nil
end

function a.setPreview(b)
c=b
i.setVeiled(b and(b.all and"all"or"alerts")or nil)
a.layout()
end




local l={}
a.scaleWaits=l
local function r(a,b)
return a.whole~=nil and v.inCombat()and g.scaleOf(b)~=g.scaleOf(a.whole)
end




a.narrowCheck=false




local function i(c,g)
local i=d.profile()
local j=d.element(c)
local d=e[c]
if not j then
if d then d:release()end
e[c],f[c]=nil,nil
return
end
local g=g and d and d.isBuilt and h.element(j,i)or nil
if g and f[c]==g then
if a.narrowCheck then
local e=a.viewOf(nil,i,h.element(b.copy(j),i))
if not b.equal(d.view,e)then a.narrowCheck(c,d.view,e)end
end
return
end
local h
h,g=a.viewOf(j,i,g)
if not s(h)then
if d then d:release()end
e[c],f[c]=nil,nil
return
end
if d and d.isBuilt then
if r(d,h)then
l[c]=true
return
end
l[c]=nil
if b.try("apply "..c,d.apply,d,h)then
f[c]=g
else
d:release()
e[c],f[c]=nil,nil
end
return
end
d=m[c]or q.new(c)
m[c]=d

if b.try("build "..c,d.build,d,h)and d.isBuilt then
e[c],f[c]=d,g
k[c]=nil
else
b.try("release "..c,d.release,d)
e[c],f[c]=nil,nil
k[c]=true
end
end



local function q(a,c)
if b.try("resolve "..a,i,a,c)then return end
local c=e[a]
if c then b.try("release "..a,c.release,c)end
e[a],f[a]=nil,nil
k[a]=true
end

local i=b.keyed("hud layout")

function a.onLayout(a,b)i:add(a,b)end


function a.layout()
if c then c.refresh()end
g.layout(a.drawn)
for b,a in pairs(e)do a:place()end
if c then
for b,a in pairs(c.standIns)do g.place(a.root,b,a.view)end
end
i:call()
end


local m={}



function a.rebuild()
local a=d.profile()
wipe(m)
for c,a in ipairs(a and a.groups or{})do
if a.id then m[a.id]=b.copy(a.members or{})end
end
b.Sounds.setChannel(d.settings().soundChannel)
t=n()
local b={}
for c,a in ipairs(a and a.elements or{})do b[a.id]=true end
for a,c in pairs(e)do
if not b[a]then
c:release()
e[a],f[a]=nil,nil
end
end
for b,a in ipairs(a and a.elements or{})do q(a.id)end
end




local g,r={},false




local A=4

local B=4
local i=1


local c={n=0,slowest=0}
a.passStats=c

local function s()return debugprofilestop()end

local function x(b,d,e)
local a=c.cur
if not a then
a={frames=0,ms=0,slowest=0,elements=0}
c.cur=a
end
a.frames,a.ms,a.slowest=a.frames+1,a.ms+b,math.max(a.slowest,b)
a.elements=a.elements+d
if e then
c.cur,c.last,c.n=nil,a,c.n+1
c.slowest=math.max(c.slowest,a.slowest)
end
end
local function y()
local e=s()
local f=r
r=false
local b=d.profile()
if f then
a.rebuild()
wipe(g)
i=1
a.layout()
return
end
local f=b and b.elements or{}
local d=#f
if i>d then i=1 end
local h,b=i,0
for c=0,d-1 do
local d=(h-1+c)%d+1
local c=f[d].id
local f=g[c]
if f then
g[c]=nil
q(c,f=="styles")
b=b+1
if s()-e>=A and next(g)then
i=d+1
a.layout()
x(s()-e,b,false)
j.atFrameEnd("hud",y)
return
end
end
end

for a in pairs(g)do q(a)end
wipe(g)
i=1
a.layout()
if b>=B or c.cur then x(s()-e,b,true)end
end


local function c(a,b)
if a then g[a]=g[a]==true or b or true elseif a==nil then r=true end
j.atFrameEnd("hud",y)
end





function a.rigFor(a,d,h)
local b=type(a)=="table"and a.id
local c=b and e[b]
if not(c and c.isBuilt and f[b]==a)or r or g[b]then return nil end
if d~=o then
for b,a in ipairs(a.sources or{})do
if(not d(a))~=(not o(a))then return nil end
end
end
local a=c:runOf(h)
return a and a.inst and a.rig or nil
end


v.onEnd("hud scale",function()
for a in pairs(l)do c(a)end
wipe(l)
end)




local function f(b)
local a=d.profile()
for d,a in ipairs(a and a.elements or{})do
if e[a.id]or k[a.id]then c(a.id,b)end
end
end

local function g(a)
local d=d.group(a)
for b,a in ipairs(m[a]or{})do c(a)end
m[a]=d and d.members and b.copy(d.members)or nil
for b,a in ipairs(m[a]or{})do c(a)end
c(false)
end

b.onChanged(function(a,e)
if a=="element"and e then
c(e)
elseif a=="group"and e then

g(e)
elseif a=="styles"or a=="group"then
f(a=="styles"and"styles"or nil)
c(false)
elseif a=="profile"or a=="char"then
c(nil)
elseif a=="settings"then
b.Sounds.setChannel(d.settings().soundChannel)

local a=n()
if a~=t then
t=a
c(nil)
else
f()
end
end
end,"hud")








local g=b.keyed("hud repixel")
function a.onRepixel(a,b)g:add(a,b)end

local f={}
local function i()
if not d.ready()then return end
g:call()
local a,b=UIParent:GetSize()
local e=u.truePixel()
if e==f[1]and a==f[2]and b==f[3]then return end
f[1],f[2],f[3]=e,a,b
local a=d.profile()
for b,a in ipairs(a and a.elements or{})do c(a.id)end
c(false)
end
local function c()
u.repixeled()
j.atFrameEnd("hud repixel",i)
end
j.on("UI_SCALE_CHANGED","hud",c)
j.on("DISPLAY_SIZE_CHANGED","hud",c)

hooksecurefunc(UIParent,"SetScale",c)



z.onChange("hud",function()
if not d.ready()then return end
local b=d.profile()
for a,b in ipairs(b and b.elements or{})do
local a=e[b.id]
if a and a.isBuilt then a:respell()end
q(b.id)
end
a.layout()
end)


local function i(c,d)
if k[c.id]then return"its build failed (errors below)"end
local b=h.element(c,d)
if not b then return"unreadable"end
if not b.enabled then return"switched off"end
if b.groupOn==false then return"its group is off"end
if#(b.sources or{})==0 then return"no source"end
if not p(b)then return"not learned"end
if not w(a.viewOf(c,d))then return"nothing to draw (no layer, or every source with a layer is not picked yet or not learned)"end
if a.off()then return"the HUD is off"end
return"not built yet"
end
function a.describe()
local d=d.profile()
local g=d and d.elements or{}
local c,f={},0
for b,a in ipairs(g)do
local b=e[a.id]
local e=a.id..(type(a.name)=="string"and a.name~=""and(" ("..a.name..")")or"")
if b then f=f+1 end
c[#c+1]="  "..(b and b:describe(e)or(e..": not built, "..i(a,d)))
end
table.insert(c,1,string.format("hud: %d of %d built%s%s",f,#g,a.off()and", off (/ihud on)"or"",
b.PreviewMode.isOn()and", preview mode on"or""))
return c
end

b.Debug.register("hud",a.describe)
