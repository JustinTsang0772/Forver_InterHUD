



local a,b=...
local m,f,o,n=b.Combat,b.Store,b.Sounds,b.Schema

local a={}
b.Showing=a

local i={}
local d=false

local k=nil










local c=nil


function a.rule()
return f.ready()and f.settings().cantAct or"usual"
end



function a.cantAct()
if not(f.ready()and m.cantAct())then return nil end
local a=a.rule()
if a~="usual"then return a end
end



function a.holds(a)
local b,a=a.view,a.keys
if not(b and a)then return true end
return a:lookHolds(a:list(b["while"]),a:list(b.unless))
end




function a.alphaOf(b)
if d then return 1 end
if a.holds(b)then return(b.view.opacity or 100)/100 end
return(b.view.otherwise or 0)/100
end






b.Debug.experimental("fading down: an element's root, state holder and layers stepped each frame, an aura element's"
.." root too, in combat (FR-1, FR-3 prove each set; ShamanForever steps its Shield gate, a parent of Blizzard's"
.." button, the same way at its Idle changes; InterHUD's own in combat is untried)","I")
local p=0.2
local j
local g=setmetatable({},{__mode="k"})
local e={}
local l=CreateFrame("Frame")
l:Hide()
local h={}
l:SetScript("OnUpdate",function(a,c)
for b,a in pairs(e)do
local c=math.max(a.to,g[b]-c*a.rate)
g[b]=c
b:SetAlpha(c)
if c==a.to then
e[b]=nil
if a.done then h[#h+1]=a.done end
end
end
if next(e)==nil then a:Hide()end

local a=#h
for a=1,a do
local c=h[a]
h[a]=nil
b.try("fade done",c)
end
end)

function a.fadeSecs()
if j==nil then
j=f.ready()and f.settings().fadeTime or p
end
return j
end


function a.falls(b,c)
local b=g[b]
return b~=nil and c<b and a.fadeSecs()>0
end



function a.fadeTo(b,c,d,f)
if d or not a.falls(b,c)then
e[b]=nil
g[b]=c
b:SetAlpha(c)
return
end
local d=e[b]
if d and d.to==c then
d.done=f or d.done
return
end
e[b]={to=c,rate=(g[b]-c)/a.fadeSecs(),done=f}
l:Show()
end




function a.apply(e)
if not e.view then return end
local f=k=="all"or(k=="alerts"and n.alertFlag(e.view,"lit"))
local g=f or(c=="hide"and not d)
or(c=="grey"and not d and n.alertFlag(e.view,"hidesGreyed"))
local g=g and 0 or a.alphaOf(e)
if e.setGreyed then e:setGreyed(c=="grey")end
a.fadeTo(e.root,g,f or d or b.Sources.editing())
end

function a.add(b)
i[b]=true
a.apply(b)
end

function a.remove(a)
i[a]=nil
end

local function f()
for b in pairs(i)do a.apply(b)end
end


function a.setPlacing(a)
d=a and true or false
f()
end



function a.setVeiled(a)
k=a or nil
f()
end


local g=b.keyed("can't act rule")
function a.onCantAct(a,b)g:add(a,b)end


local function h()
local a=a.cantAct()
if a==c then return end
c=a
o.setMuted(c~=nil,"cantAct")
f()
g:call(c)
end
m.onCanActChange("showing",h)
b.onChanged(function(a)
if a=="settings"or a=="profile"then
j=nil
h()
end
end,"showing")


function a.describe()
local b,f=0,0
for c in pairs(i)do
b=b+1
if not d and not a.holds(c)and(c.view.otherwise or 0)<100 then f=f+1 end
end
local g=0
for a in pairs(e)do g=g+1 end
return{string.format("showing: %d elements, %d faded or hidden by their while and unless%s; while you can't act %s%s;"
.." fade %gs, %d falling",b,f,d and" (placing: all shown)"or"",a.rule(),
c and(" ("..c.." now)")or"",a.fadeSecs(),g)}
end

