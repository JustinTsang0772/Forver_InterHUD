





local b,a=...
local f,i,h,l,e=a.Layers,a.Schema,a.Spells,a.Element,a.Resolve

local b={}
a.Preview=b










local function j(b)
local a=a.Sources.get(b.kind)
if a and a.shownSpell then return a.shownSpell(b)end
return h.firstOf(b.spells)
end
b.shownOf=j

local function d(a)return i.variantOf(a)end
local function g(a,b)
for c,a in ipairs(a.sources or{})do
if a.id==b then return a end
end
end

local function k(a)
local a=d(a)
return a~=nil and a.read=="clip"
end


local function c(b,c)
local a=d(b)
return not(a and a.offersState)or a.offersState(b,c)
end


function b.defaultPick(a,b)
local a=g(a,b)
local b=a and d(a)
if not b then return nil end
for d,b in ipairs(b.stateOrder)do
if c(a,b)then return{state=b,facts={}}end
end
return{state=b.stateOrder[1],facts={}}
end


local m={coolingDown=true,present=true,down=true,draining=true,coming=true,casting=true,
channelling=true,paused=true,swinging=true}



function b.typicalPick(f,h)
local e=g(f,h)
local a=e and d(e)
if not a then return nil end
if type(a.typical)=="function"then
local a=a.typical(f,e)
if a then return a end
elseif a.typical and c(e,a.typical)then
return{state=a.typical,facts={}}
end
for b,a in ipairs(a.stateOrder)do
if m[a]and c(e,a)then return{state=a,facts={}}end
end
return b.defaultPick(f,h)
end


local function n(d,a)
local e={game=a.game,held=a.held}
for f,c in ipairs(d.sources or{})do
e[c.id]=a[c.id]or(a.typical and b.typicalPick(d,c.id))or b.defaultPick(d,c.id)
end
return e
end





local function o(b)
local a={}
for c,b in pairs(type(b.facts)=="table"and b.facts or{})do
if type(b)=="table"and b[1]~=nil then
for c,b in ipairs(b)do
if type(b)=="table"and b.id and b.enabled~=false then a[#a+1]=b.id end
end
elseif not(type(b)=="table"and b.enabled==false)then
a[#a+1]=c
end
end
table.sort(a)
return a
end
function b.litPicks(b)
local f=n(b,{typical=true})
local h={}
for b,a in ipairs(b.customStates or{})do
if type(a.hold)=="table"and a.hold.after~=nil then h[a.id]=true end
end
for c,a in ipairs(b.layers or{})do
if a.kind==i.ALERT_LAYER then
local c=g(b,a.source)
local g=c and d(c)
local i=c and o(c)or{}
local d=false
for c,j in ipairs({false,true})do
for c,k in ipairs(g and g.stateOrder or{})do
for g=0,#i do
local c={}
for a,b in pairs(f)do c[a]=b end
c[a.source]={state=k,facts=g>0 and{[i[g]]=true}or{}}
if j then c.held=h end
if e.lookAt(a,e.holds(b,c)).shown~=false then
f[a.source]=c[a.source]
if j then f.held=h end
d=true
break
end
end
if d then break end
end
if d then break end
end
end
end
return f
end


local function p(a,b)
for c,a in ipairs(a.layers or{})do
local a=e.lookAt(a,b)
if a.shown~=false and a.opacity~=0 then return true end
end
return false
end




local function q(c,b)
if type(b)=="string"then b=c.sources and c.sources[1]and{[c.sources[1].id]=b}end
if type(b)~="table"then return nil end
local c={}


for d,b in pairs(b)do
c[d]=d=="game"and b or type(b)=="string"and{state=b,facts={}}or a.copy(b)
end
return c
end

local function r(c)
local b=c.origin
local a=type(b)=="table"and b.kind=="premade"and a.Blueprints and a.Blueprints.premade(b.id)
return a and q(c,a.preview)
end

local function s(b,c)
local a={}
for b,c in pairs(b or{})do a[b]=c end
for c,b in ipairs(c or{})do a[b]=true end
return a
end








function b.drawing(h,b,i,f,g)
f=f or e.holds(h,b)
for j,a in ipairs(h.sources or{})do
if#(a.layers or{})>0 and not(i and i[a.id])and not p(a,f)then
local function i(g,d)
local c={}
for a,b in pairs(b)do c[a]=b end
c[a.id]=g
if d then c.game=s(b.game,d)end
local e=e.holds(h,c)
if not p(a,e)then return false end
b[a.id],f=g,e
if d then b.game=c.game end
return true
end
local b=g and type(g[a.id])=="table"and i(g[a.id],g.game)
local d=d(a)
local f=(not b)and o(a)or{}
for g=0,#f do
for h,e in ipairs((not b)and d and d.stateOrder or{})do
if c(a,e)and d.states[e].read~="held"
and i({state=e,facts=g>0 and{[f[g]]=true}or{}})then
b=true
break
end
end
if b then break end
end
end
end
return f
end
b.premadeSay=r





function b.showcasePicks(c,a)
local d=q(c,a and a.preview)
local a=b.litPicks(c)
for b,c in pairs(d or{})do
if b=="game"then a.game=s(a.game,c)else a[b]=c end
end
b.drawing(c,a,d)
return a
end




function b.begins(a,b,e)
local b=g(a,b)
local a=b and d(b)
local a=a and a.events and a.events[e]
if not a then return nil end
if a.orBegins and not c(b,a.begins)then return a.orBegins end
return a.begins
end



function b.statesOf(a,b)
local e=g(a,b)
local b=e and d(e)
if not b then return{}end
local a={}
for f,d in ipairs(b.stateOrder)do
if c(e,d)and b.states[d].read~="held"then
a[#a+1]={key=d,label=b.states[d].label,what="state"}
end
end
local d=type(e.facts)=="table"and e.facts or{}
for e,c in ipairs(b.factOrder or{})do
local b=b.facts[c]
if i.isListFact(b)then
for d,c in ipairs(type(d[c])=="table"and d[c]or{})do
if c.enabled~=false then
a[#a+1]={key=c.id,label=c.name or b.label,what="item",within=b.within}
end
end
elseif not(type(d[c])=="table"and d[c].enabled==false)then
a[#a+1]={key=c,label=b.label,what="fact",within=b.within}
end
end
return a
end



local function i(b)
local c=j(b)
if b.kind=="spell"and c~=nil then
local b=a.Sources.get("spell").sampleCooldown({source=b})
if b then return b end

local d,b
if GetSpellBaseCooldown then d,b=a.try("GetSpellBaseCooldown",GetSpellBaseCooldown,c)end
if d and type(b)=="number"and not a.isSecret(b)and b>0 then return b/1000 end
elseif b.kind=="aura"then
local a=a.Sources.get("aura").sampleLength({source=b})
if a then return a end
end
return 30
end

local c={}
c.__index=c





function b.new(a,b)
local a=CreateFrame("Frame",nil,a)
return setmetatable({box=a,runs={},starts={},relative=b or nil,shift=0},c)
end


function c:runFor(b)
local a=self.runs[b]
if not a then
local c=CreateFrame("Frame",nil,self.box)
c:SetAllPoints(self.box)
a=l.newRun("preview "..b,c,b)
a.free={}
self.runs[b]=a
end
return a
end




function c:duration(d,c,b)
local e=GetTime()
b=b or 0
local a=self.starts[d]
if not a or a.length~=c or a.skip~=b or e-a.at>=c-b then
a={at=e,length=c,skip=b}
self.starts[d]=a
end
local d=C_DurationUtil.CreateDuration()
d:SetTimeFromStart(a.at-b,c)
return d
end


function c:ranOut()
local b=GetTime()
for c,a in pairs(self.starts)do
if b-a.at>=a.length-a.skip then return true end
end
return false
end



function c:restart()
local e=GetTime()
for d,a in pairs(self.starts)do
local c=self.runs[d]
local b=c and c.lastFed
if b and b.duration and e-a.at>=a.length-a.skip then
b.duration=self:duration(d,a.length,a.skip)
c:feed(b)
end
end
end




local function o(b,d)
if d.state=="missing"then return false end
local c=a.Sources.get("aura")
local b=type(b.facts)=="table"and b.facts or{}
local a={}
for d,b in ipairs(type(b.stacks)=="table"and b.stacks or{})do
if b.enabled~=false and c.stackRange(b)then a[#a+1]=b end
end
if#a==0 then return 1 end
local e=d.facts or{}
local b=1
for d,a in ipairs(a)do
local a,c=c.stackRange(a)
b=math.max(b,c or a or 1,a or 1)
end
local d
for b=1,b+1 do
local f,g=true,true
for d,a in ipairs(a)do
local c,d=c.stackRange(a)
local b=(c<=1 or b>=c)and(d==nil or b<=d)
if b~=(e[a.id]==true)then f=false end
if e[a.id]and not b then g=false end
end
if f then return b end
if g and not d then d=b end
end
return d or 1
end








function c:data(g,d,e)
local b=j(d)
local c

if b then c=select(2,h.highest(b))or h.icon(b)end
local c={icon=c or false,name=b and h.label(b)or false,gcd=false}

if a.Sources.unset(d)then c.icon=a.Sources.UNSET_ICON end
local b=a.Sources.get(d.kind)
local b=b and b.preview and b.preview(d,e)
if b then
if b.icon~=nil then c.icon=b.icon end
if b.name~=nil then c.name=b.name end
if b.count~=nil then c.count=b.count end
c.channel,c.full=b.channel,b.full
c.amount,c.max,c.percent,c.snap=b.amount,b.max,b.percent,true
c.missing,c.shields,c.heals=b.missing,b.shields,b.heals
c.absorbs,c.absorbsAlone,c.healAbsorbs=b.absorbs,b.absorbsAlone,b.healAbsorbs
c.cost=b.cost
c.range=b.range
end

local f=m[e.state]and not(b and b.length==false)
and not(d.kind=="aura"and a.Sources.get("aura").endless(d))
local a=f and(b and b.length or i(d))

local h=0
local i=type(d.facts)=="table"and d.facts or{}
for c,b in ipairs({"expiring","soon"})do
for c,b in ipairs(type(i[b])=="table"and i[b]or{})do
if e.facts and e.facts[b.id]and a then
local b=b.share and a*b.share/100 or b.seconds
if b and b>0 then h=a-math.min(b,a)end
end
end
end

if not f then self.starts[g]=nil end
c.duration=f and self:duration(g,a,h)or false

if b and b.marks~=nil then c.length=b.marks end
if k(d)then c.stacks=o(d,e)end
return c
end



local function g(a)
local a=f.structureOf(a)
a.level,a.backLevel=nil,nil
return a
end
local function j(b,c)
local d=g(c)
for e,c in ipairs(b.free)do
if a.equal(g(c.part),d)then
table.remove(b.free,e)
return c
end
end
end




local function i(b)
local a={}
for c,b in ipairs(b.visuals)do a[#a+1]=b end
for c,b in ipairs(b.free)do a[#a+1]=b end
b.free,b.visuals=a,{}
end
local function m(a)
for b,a in ipairs(a.free)do a.visual.frame:Hide()end
end





local function o(a,d)
local b,c={},{}
for a,c in pairs(a.compiled)do b[a]=c end
for a,b in ipairs(a.compiled.flags)do
if not d[a]then c[#c+1]=b end
end
b.flags=c
local c={}
for a,b in pairs(a)do c[a]=b end
c.compiled=b
return c
end




local function p(d,i,g,c)
local h=a.Sources.get(d.source.kind)
local f=c~=nil
if f and b.narrowCheck then
local e=h.plan(d)
if not(a.equal(c.covers,e.covers)and a.equal(c.copies,e.copies))then
b.narrowCheck(d,c,e)
end
end
if not f then f,c=a.try("preview plan",h.plan,d)end
local a={}
for f,b in ipairs(f and c and c.covers or{})do
local c=c.copies[b.base]
local d=d.layers[b.layer]
if c and c.skip and d and d.compiled then
local c=e.lookAt(o(d,c.skip),i)
a[#a+1]={part=b,held=g[b.layer],base=c}
end
end
for b,a in ipairs(a)do g[a.part.layer]=a.base end
return a
end



local function o(d,c,g)
c.level=c.level+d.shift
if c.backLevel then c.backLevel=c.backLevel+d.shift end
local h=g and g.visual.frame or d.root
local b=j(d,c)
if not b then
local e
e,b=a.try("preview "..c.kind,d.makeVisual,d,h,c)
return e and b or nil
end
b.part=c
d.visuals[#d.visuals+1]=b
local e=d:parentFor(h,c)
b.fade=e~=h and e or nil
b.visual.frame:SetParent(e)
b.visual.frame:Show()
if g then
b.visual.frame:ClearAllPoints()
b.visual.frame:SetAllPoints(e)
else
f.place(b.visual.frame,d.root,c.rect)
end
b.visual.frame:SetFrameLevel(c.level)
a.try(b.site,b.spec.apply,b.visual,(d:recordOf(c)),c,c.rect)
d:fadeTo(b)
return b
end

function c:drawRun(b,g,l,h)
i(b)
local c=g.source
local j={}
for b,a in ipairs(g.layers)do
j[b]=a.source==c.id and e.lookAt(a,l)or a
end
local e=k(c)and(h.state=="missing"and"missing"or"present")or nil
local i=e=="present"and a.HUD and a.HUD.rigFor(self.from,self.learned,c.id)or nil
local l=e=="present"and p(g,l,j,i)or{}
local i={}
for a,b in pairs(g)do i[a]=b end
i.layers=j
b.view=i
b.shift=self.shift
b.root:Show()
local g={}
for d,c in ipairs(f.allParts(i,e,nil))do

local d=c.side and(self.picks and self.picks[c.onRun]or{})
if not d or c.side==(d.state=="missing"and"missing"or"present")then
local a=a.copy(c)
a.holder,a.underButton,a.sockets="preview",nil,nil
if e then a.target=nil end
local d=a.rides and g[a.rides]
if a.rides and not d then a.rides=nil end
g[c.n]=o(b,a,d)
end
end

b.live={}
for d,c in ipairs(l)do
local a=a.copy(c.part)
a.holder,a.underButton="preview",nil
local d,e={layers={}},{layers={}}
d.layers[a.layer],e.layers[a.layer]=c.held,c.base
b.live[#b.live+1]={view=d}
a.copy=#b.live
b.live[#b.live+1]={view=e}
a.base=#b.live
o(b,a,nil)
end
m(b)
b:feed(self:data(c.id,c,h))



local a=d(c)
local d=self.picks and self.picks.game
local c=k(c)and c.unit=="target"and d and d.hostileTarget==false
b.root:SetAlpha((c or a and a.states[h.state]and a.states[h.state].read=="held")and 0 or 1)
end



local function g()return true end


b.narrowCheck=false
function c:show(c,d)
d=d or{}
local a=d.allKnown and g or(a.HUD and a.HUD.sourceLearned)or g

self.from,self.learned=c,a
c=e.drawn(c,a)
self.box:SetSize(c.baseSize,c.baseSize)
self.box:Show()


self.shift=self.relative and self.box:GetParent():GetFrameLevel()+1-f.level(0,true)or 0
self.box:SetAlpha(1)
local a=d.lit and b.litPicks(c)or n(c,d)
for b,c in pairs(d)do
if type(c)=="table"and b~="game"and b~="held"then a[b]=c end
end

a.game,a.held=d.game or a.game,d.held or a.held
local e=e.holds(c,a)

if d.typical then e=b.drawing(c,a,d,e,r(c))end
self.view,self.picks=c,a

local d={}
for c,b in ipairs(l.split(c))do
if b.view.variant then
d[b.id]=true
self:drawRun(self:runFor(b.id),b.view,e,a[b.id]or{facts={}})
end
end
for b,a in pairs(self.runs)do
if not d[b]then
i(a)
m(a)
a.root:Hide()
self.starts[b]=nil
end
end

if self.drag and self.drag.src~=nil then self:reflow()end
end





local function d(a)
for b,a in pairs(a.runs)do a:reflow()end
end
function c:dragAt(b,c,d,e)
local a=self.drag or{}
self.drag=a
a.src,a.id,a.x,a.y=b,c,d,e
if b~=nil then return self:reflow()end
return true
end
function c:reflow()
local b=self.drag
if b and b.src~=nil then return(f.withDrag(b.src,b.id,b.x,b.y,d,self))end
return(a.try("layer drag",d,self))
end




function c:play(f,e,b)
local c=self.view
if not c then return end
b=b or{}
for g,d in ipairs(c.effects)do
local c=d.at or{}
local b=c.event==e and c.customState==b.customState and(c.item or c.fact)==b.fact
and(b.customState~=nil or c.source==f)
if b then
if d.kind=="sound"then
a.Sounds.play(d.sound,"preview "..tostring(e),true)
else
for c,b in pairs(self.runs)do
for c,b in ipairs(b.visuals)do
if b.part.effect==g and b.spec.play then a.try(b.site,b.spec.play,b.visual)end
end
end
end
end
end
end

function c:hide()
self.box:Hide()
end
