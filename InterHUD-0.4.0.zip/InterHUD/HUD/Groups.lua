


local a,c=...
local i,f,b=c.Store,c.Resolve,c.Layers

local a={}
c.Groups=a


local h=40




local d={}
a.groups=d


local e={}


local function g(a)return a and a.scale or 1 end
a.scaleOf=g


local function k(a,b)
return{x=a.x*b,y=a.y*b,w=a.w*b,h=a.h*b}
end




function a.onPixels(e,c,d,f,g,a,h,i)
local e=b.OFFSETS[e]or b.OFFSETS.CENTER
local e,f=(h or 0)+(c-e[1]*f)*a,(i or 0)+(d+e[2]*g)*a
return c+(b.toPixels(e)-e)/a,d+(b.toPixels(f)-f)/a
end

function a.screenPoint(a)
local c,d=UIParent:GetSize()
local a=b.OFFSETS[a]or b.OFFSETS.CENTER
return a[1]*c,(1-a[2])*d
end


local j={
row={centre="CENTER",start="LEFT",["end"]="RIGHT"},
column={centre="CENTER",start="TOP",["end"]="BOTTOM"},
}
function a.anchorPoint(a)
local b=j[a.arrangement]
return b and b[a.growFrom]or"CENTER"
end

local function n(b)
local a=d[b]
if not a then
a={id=b,frame=CreateFrame("Frame",nil,UIParent),origin=CreateFrame("Frame",nil,UIParent)}
a.origin:SetSize(1,1)
d[b]=a
end
return a
end


local function j(d,a,e)
local c=g(a)
return{id=d,view=a,bounds=k(b.bounds(a,nil,nil,nil,true),c),scale=c,inUse=e}
end


local function o(b,a,g)
local d={}
for f,e in ipairs(b.members)do
local f=a(e)
local a=f and f.view
if not a and b.keepSlots and b.arrangement~="free"then
local b=i.element(e)
a=b and c.HUD.viewOf(b,g)
end
if a then d[#d+1]=j(e,a,f~=nil)end
end
return d
end




local function k(a,d,i)
local c=a.spacing
local b=d
if a.growFrom=="end"and a.arrangement~="grid"then
b={}
for a=#d,1,-1 do b[#b+1]=d[a]end
end
local e,f=0,0
for b,a in ipairs(d)do
e,f=math.max(e,a.bounds.w),math.max(f,a.bounds.h)
end
local f,g

local k={start=0,centre=0.5,["end"]=1}
local function j(b,f)
local j=k[a.align]or 0.5
local c,d,g={},math.huge,-math.huge
for b,e in ipairs(b)do
local b=e.bounds
local h,i
if a.lineUpBy=="element"then
h,i=0,f and b.h or b.w
else
h,i=f and-b.y or-b.x,e.view.baseSize*e.scale
end
local a=-(h+j*i)
c[e]=a
d,g=math.min(d,a),math.max(g,a+(f and b.h or b.w))
end
for b,a in ipairs(b)do c[a]=c[a]-d end
return c,#b>0 and g-d or 0
end
if a.arrangement=="grid"then
local a=math.min(a.columns,math.max(#d,1))
local d=0
for g=1,#b,a do
local f={}
for a=g,math.min(g+a-1,#b)do f[#f+1]=b[a]end
local b,a=j(f,true)
for f,a in ipairs(f)do i(a,(f-1)*(e+c)+(e-a.bounds.w)/2,d+b[a])end
d=d+a+c
end
f,g=a*e+(a-1)*c,math.max(d-c,0)
else

local d=a.arrangement=="row"
local e,h=j(b,d)
local a=0
for f,b in ipairs(b)do
if d then
i(b,a,e[b])
a=a+b.bounds.w+c
else
i(b,e[b],a)
a=a+b.bounds.h+c
end
end
a=math.max(a-c,0)
if d then f,g=a,h else f,g=h,a end
end
if#d==0 then f,g=h,h end
return f,g
end


local function l(c,d)
local g,h=k(d,c.members,function(a,f,g)
if a.inUse then
local b=a.scale
e[a.id]={frame=c.frame,point="TOPLEFT",toPoint="TOPLEFT",x=(f-a.bounds.x)/b,
y=-(g-a.bounds.y)/b,scale=d.scale*b}
end
end)

local e=d.scale
local f=d.position

local b,d,i=a.anchorPoint(d),b.toPixels(g*e),b.toPixels(h*e)
c.frame:ClearAllPoints()
c.frame:SetPoint(b,UIParent,f.point,a.onPixels(b,f.x,f.y,d,i,1,a.screenPoint(f.point)))
c.frame:SetSize(d,i)
c.x,c.y,c.w,c.h=0,0,g*e,h*e
end



local function m(c)
local b,d,e,f
for g,c in ipairs(c)do

local g=c.view.position
local g,h=a.boxFrom(g.point,g.x,g.y,c.view.baseSize*c.scale)
local a=c.bounds
b,d=math.min(b or math.huge,g+a.x),math.min(d or math.huge,h+a.y)
e,f=math.max(e or-math.huge,g+a.x+a.w),math.max(f or-math.huge,h+a.y+a.h)
end
if not b then
local a=h/2
return-a,-a,a,a
end
return b,d,e,f
end


local function h(b,d)
local c=d.position

b.origin:ClearAllPoints()
b.origin:SetPoint("CENTER",UIParent,c.point,a.onPixels("CENTER",c.x,c.y,0,0,1,a.screenPoint(c.point)))
for c,a in ipairs(b.members)do
local c,f=a.view.position,a.scale
e[a.id]={frame=b.origin,point=c.point,toPoint="CENTER",x=c.x/f,y=c.y/f,
scale=d.scale*f}
end

local d=d.scale
local a,c,e,f=m(b.members)
a,c,e,f=a*d,c*d,e*d,f*d
b.frame:ClearAllPoints()
b.frame:SetPoint("TOPLEFT",b.origin,"CENTER",a,-c)
b.frame:SetSize(e-a,f-c)
b.x,b.y,b.w,b.h=a,c,e-a,f-c
end


function a.boxFrom(c,d,e,a)
local b=b.OFFSETS[c]or b.OFFSETS.CENTER
return d-b[1]*a,-e-b[2]*a
end




local function p()end
function a.measure(b,c)
local a=b.scale
if b.arrangement=="free"then
local b,c,d,e=m(c)
return b*a,c*a,(d-b)*a,(e-c)*a
end
local b,c=k(b,c,p)
return 0,0,b*a,c*a
end




function a.measureRecords(b,d,e)
local c={}
for d,a in ipairs(d)do
if a.enabled~=false or(b.keepSlots and b.arrangement~="free")then
c[#c+1]=j(a.id,f.drawn(f.element(a,e)),true)
end
end
return a.measure(b,c)
end



function a.layout(j)
local b=i.profile()
wipe(e)
local g={}
for a,d in ipairs(b and b.groups or{})do
local e=n(d.id)
local a=f.group(d,b)
e.view=a
g[d.id]=true
if a.enabled==false then

e.members={}
else
e.members=o(a,j,b)
c.try("layout "..d.id,a.arrangement=="free"and h or l,e,a)
end
end
for b,a in pairs(d)do
if not g[b]then a.view,a.members=nil,nil end
end
end


function a.slotOf(a)return e[a]end

c.Debug.experimental("an element's root scaled (a group's Scale times its own) over an aura's containers,"
.." clips and Blizzard's buttons, which scale with it (laid out in their own units; untried in game)","I")



function a.place(d,c,f)
d:ClearAllPoints()
local c=e[c]
local e=c and c.scale or g(f)
local b=b.boxSize(f,e)
d:SetScale(e)
if c then
d:SetPoint(c.point,c.frame,c.toPoint,
a.onPixels(c.point,c.x,c.y,b,b,e))
else
local b=f.position
d:SetPoint(b.point,UIParent,b.point,a.looseAt(f,e))
end
d:SetSize(b,b)
end


function a.looseAt(d,c)
local b,d=d.position,b.boxSize(d,c)
return a.onPixels(b.point,b.x/c,b.y/c,d,d,c,a.screenPoint(b.point))
end



function a.preview(b,c,e)
local b=d[b]
local c=setmetatable({scale=c},{__index=b.view})
if b.view.arrangement=="free"then h(b,c)else l(b,c)end
for c,b in ipairs(b.members)do
local c=b.inUse and e(b.id)
if c then a.place(c.root,b.id,c.view)end
end
end


function a.of(a)
local a=e[a]
if not a then return nil end
for c,b in pairs(d)do
if b.frame==a.frame or b.origin==a.frame then return c,b end
end
end

