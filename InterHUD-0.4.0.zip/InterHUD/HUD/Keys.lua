


local a,c=...
local e,h,g,i=c.Schema,c.Game,c.Ticker,c.Quiet

local b={}
c.Keys=b

local a={}
a.__index=a

local f={}
local function d(a)
if a==nil then return f end
if type(a)=="table"then return a end
return{a}
end
b.asList=d






function b.compile(c)
local b=setmetatable({view=c,index=e.keyIndex(c),terms={},conds={},now={},pass=0,
stamps={},held={}},a)
for c,a in ipairs(b.index.sources)do
for d,c in pairs(a.words)do
if c.what=="state"and c.class=="held"then
local c=b.held[a.rec.id]or{}
c[#c+1]=a.rec.id.."."..d
b.held[a.rec.id]=c
end
end
end
for c,a in ipairs(c.customStates or{})do
if a.id then
local c=type(a.hold)=="table"and a.hold.after~=nil and a.hold or nil
b.conds[a.id]={id=a.id,rec=a,all=a.all and d(a.all),any=a.any and d(a.any),
none=a.none and d(a.none),hold=c,off=a.enabled==false}
end
end
return b
end


function a:term(c)
local a=self.terms[c]
if a~=nil then return a or nil end
local b,d=e.splitKey(c)
if d=="#hold"then
a={kind="hold",class="lua",word=b}
elseif d==e.GAME then
a=e.gameFactSpec(b)and{kind="game",class="lua",word=b}or false
elseif d==nil then
a=self.conds[b]and{kind="cond",id=b}or false
else
local c=self.index.sources[d]
local c=c and c.words[b]
if c and c.what~="event"then
a={kind="source",class=c.class,src=d,word=b,within=c.within,on=c.on,what=c.what}
else
a=false
end
end
self.terms[c]=a
return a or nil
end


function a:isLua(b)
local a=self:term(b)
if not a then return true end
if a.kind=="cond"then
for b,a in pairs(self:atomsOf(b).drawn)do
if a then return false end
end
return true
end
return a.class=="lua"
end


function a:heldNow(a)
for b,a in ipairs(self.held[a]or f)do
if self.now[a]==true then return true end
end
return false
end



function a:unknown(b)
local a=self:term(b)
if not a then return false end
if a.kind=="source"then return self:heldNow(a.src)end
if a.kind~="cond"or next(self.held)==nil then return false end
local a=self:atomsOf(b)
for b,a in pairs(a)do
for a in pairs(a)do
local a=self:term(a)
if a and a.kind=="source"and self:heldNow(a.src)then return true end
end
end
return false
end
local function e(a,b)
for c,b in ipairs(b)do
if a:unknown(b)then return true end
end
return false
end






function a:holds(b,c)
if c then
local a=c[b]
if a~=nil then return a end
end
local a=self:term(b)
if not a or a.on==false then return false end
if self:unknown(b)then return false,true end
if a.kind=="cond"then return self:cond(a.id,c)end
if a.kind=="hold"then return self.now[b]==true end
if a.kind=="game"then return h.holds(a.word)end
if a.class~="lua"then return false end
if self.now[b]~=true then return false end
local b=a.within
if type(b)=="table"then
for d,b in ipairs(b)do
if self:holds(a.src.."."..b,c)then return true end
end
return false
end
if b then return self:holds(a.src.."."..b,c)end
return true
end

local function h(a,b,c)
for d,b in ipairs(b)do
if not a:holds(b,c)then return false end
end
return true
end
local function f(a,b,c)
for d,b in ipairs(b)do
if a:holds(b,c)then return true end
end
return false
end
b.allOf,b.anyOf=h,f



function a:cond(c,b)
local a=self.conds[c]
if not a or a.off then return false end
if self:unknown(c)then return false end
if not b and a.at==self.pass then return a.val end
if a.busy then return false end
a.busy=true
local c=(a.all==nil or h(self,a.all,b))and(a.any==nil or f(self,a.any,b))
and(a.none==nil or not f(self,a.none,b))and(a.hold==nil or self.now["#hold."..c]==true)
a.busy=nil
if not b then a.at,a.val=self.pass,c end
return c
end



function a:list(a)
if type(a)~="string"then return d(a)end
self.ones=self.ones or{}
local b=self.ones[a]
if not b then
b={a}
self.ones[a]=b
end
return b
end


function a:bump()self.pass=self.pass+1 end


function a:lookHolds(a,b,c)
if e(self,a)or e(self,b)then return false end
return h(self,a,c)and not f(self,b,c)
end



function a:atomsOf(a)
self.atomCache=self.atomCache or{}
local b=self.atomCache[a]
if b then return b end
local b={lua={},drawn={}}
local e={}
local function d(c)
if e[c]then return end
e[c]=true
local a=self:term(c)
if not a then return end
if a.kind=="cond"then
local c=self.conds[a.id]
for b,a in ipairs({"all","any","none"})do
for b,a in ipairs(c[a]or{})do d(a)end
end
if c.hold then b.lua["#hold."..a.id]=true end
elseif a.on==false then

return
elseif a.class=="lua"then
b.lua[c]=true
for c,b in ipairs(type(a.within)=="table"and a.within or{a.within})do d(a.src.."."..b)end
else
b.drawn[c]=a.class
end
end
d(a)
self.atomCache[a]=b
return b
end






function a:part(a,c,d,e)
local b=self:term(a)
if not b or b.on==false then return false end
if b.kind=="cond"then
local a=self.conds[b.id]
if not a or a.off then return false end
for b,a in ipairs(a.all or{})do
if not self:part(a,c,d,e)then return false end
end
if a.any then
local b=false
for f,a in ipairs(a.any)do
if self:part(a,c,d,e)then b=true end
end
if not b then return false end
end
for b,a in ipairs(a.none or{})do
if self:part(a,not c,d,e)then return false end
end
if a.hold then
if d=="lua"then return c end
if self.now["#hold."..b.id]~=true then return false end
end
return true
end
local b=b.class=="lua"
if(d=="lua")==b then return c end
return self:holds(a,e)
end

function a:lookPart(b,c,a,d)
if a~="lua"and(e(self,b)or e(self,c))then return false end
for c,b in ipairs(b)do
if not self:part(b,true,a,d)then return false end
end
for c,b in ipairs(c)do
if self:part(b,false,a,d)then return false end
end
return true
end


function a:mixedNegative(b,c)
local function e(a)
local a=self:atomsOf(a)
return next(a.lua)~=nil and next(a.drawn)~=nil
end
local function a(c,d)
local b=self:term(c)
if not(b and b.kind=="cond")then return false end
if d and e(c)then return true end
local b=self.conds[b.id]
for c,b in ipairs(b.all or{})do if a(b,d)then return true end end
for c,b in ipairs(b.none or{})do if a(b,true)then return true end end
return false
end
for c,b in ipairs(b)do if a(b,false)then return true end end
for c,b in ipairs(c)do if a(b,true)then return true end end
return false
end




local b={}
local d=false
local function f()
local f=GetTime()
for a in pairs(b)do
local d,e=false,false
for b,g in pairs(a.stamps)do
local c=a.conds[b]
if c and f>=g+c.hold.seconds then
a.stamps[b]=nil
a.now["#hold."..b]=false
d=true
elseif c then
e=true
end
end
if d and a.onEnd then c.try("hold end",a.onEnd)end
if not e then b[a]=nil end
end
if next(b)==nil then
g.unsubscribe(0.1,"custom state holds")
d=false
end
end
function a:stamp(a,c)
if i.isQuiet(nil)then return false end
local e,a=a.."."..c,false
for c,b in pairs(self.conds)do
if b.hold and b.hold.after==e and not b.off then
self.stamps[c]=GetTime()
self.now["#hold."..c]=true
a=true
end
end
if a then
b[self]=true
if not d then
d=true
g.subscribe(0.1,"custom state holds",f)
end
end
return a
end

function a:keepStamps(a)
for c,h in pairs(a and a.stamps or{})do
local e=self.conds[c]
local a=a.conds[c]
if e and a and e.hold and a.hold and e.hold.after==a.hold.after then
self.stamps[c]=h
self.now["#hold."..c]=true
b[self]=true
if not d then
d=true
g.subscribe(0.1,"custom state holds",f)
end
end
end
b[a]=nil
end
function a:stop()b[self]=nil end


function a:describe()
local a,b={},{}
local d=GetTime()
for b in pairs(self.conds)do
if self:cond(b)then a[#a+1]=b end
end
for a,e in pairs(self.stamps)do
local c=self.conds[a]
if c then b[#b+1]=string.format("%s %.1f s left",a,e+c.hold.seconds-d)end
end
table.sort(a)
table.sort(b)
if next(self.conds)==nil then return nil end
return"custom states holding: "..(#a>0 and table.concat(a,", ")or"none")
..(#b>0 and("; holds counting: "..table.concat(b,", "))or"")
end
