









local a,h=...
local f=h.Blueprints
local a=f.kit

local c=a.classKit("ROGUE",{pop=false,glow=false})
local d,g=c.premade,c.cooldown
local b=a.colour



local function e(a,c,e,f,b,h)
local c=g(a,c,e,f)
return d(a,b and b(c)or c,h)
end
local function g(c,e,f,b,g)
b.id,b.name,b.spell=c,e,f
return d(c,a.debuff(b),g)
end
local function n(b,e,f,g,c,h)
local a=a.proc(b,e,f,g)
return d(b,c and c(a)or a,h)
end


local function l(b,c)
return function(d)return a.withBuff(d,{spell=b,time=true,barColour=c})end
end
local function o(b)
return function(c)
return a.withBuff(c,{spell=b,name="Primed",glow=true,pop=false,while_="primed",
as="primed"})
end
end
local function j(b,c,d)
return function(e)return a.withDebuffBar(e,{spell=b,name=c,colour=d})end
end
local function i(a,b,e,f,g)return d(a,c.big(a,b,e,f,g))end



local p="The reagent source (new: unplayed; IT-1 by probe)"
local q="No Ankh and Low or out as looks on a reagent's state and a custom state (never seen)"
local r="Low or out showing a cooldown hidden while Cooling down (never seen)"


local k="Not enough power by energy (CD-8 read on mana and rage only)"
local m="A table-linked debuff ID no run has seen"




d("sliceanddice",a.onlyInCombat(a.extras(f.layout("iconBar").build({id="sliceanddice",
name="Slice and Dice",spell=5171,colour=b.PHYSICAL,barAt="below"}),
{power=true,expiringGlow=true})),
{layout="iconBar"})




g("rupture","Rupture",1943,{colour=b.BLEED,range=true,power=true})
g("garrote","Garrote",703,{colour=b.BLEED,range=true,power=true})
g("hemorrhage","Hemorrhage",16511,{colour=b.BLEED,range=true,power=true})
g("exposearmor","Expose Armor",8647,{colour=b.EARTH,range=true,power=true})
g("sap","Sap",6770,{colour=b.FROST,missing="hidden",range=true,power=true})
g("cheapshot","Cheap Shot",1833,{colour=b.PHYSICAL,missing="hidden",range=true,power=true},
{experimental={k,m}})




e("ghostlystrike","Ghostly Strike",14278,nil,l(14278,b.FROST))
e("kick","Kick",1766,nil,j(18425,"Silence bar",b.ARCANE),{experimental={m}})

a.interruptPremade(c,"kickinterrupt","Kick interrupt",1766,{gcd=true},{k})
e("gouge","Gouge",1776,nil,j(1776,"Gouge bar",b.PHYSICAL))

d("kidneyshot",a.extras(f.layout("iconBar").build({id="kidneyshot",name="Kidney Shot",spell=408,
cooldown=true,with={unit="target",spell=408},colour=b.PHYSICAL,barAt="below"}),
{pop=true,glow=false,gcd=true}),{layout="iconBar"})
e("blind","Blind",2094,{pop=true},j(2094,"Blind bar",b.SHADOW))
e("feint","Feint",1966)


e("distract","Distract",1725,nil,nil,{experimental={k}})

e("redirect","Redirect",438040,{noGcd=true},l(438040,b.PHYSICAL))






d("adrenalinerush",a.extras(f.layout("iconBar").build({id="adrenalinerush",name="Adrenaline Rush",
spell=13750,cooldown=true,with={spell=13750},colour=b.PHYSICAL,barAt="below"}),
{pop=true,glow=false,gcd=true}),
{layout="iconBar"})
i("bladeflurry","Blade Flurry",13877,b.PHYSICAL,{noGcd=false})
i("premeditation","Premeditation",14183,b.SHADOW)
e("coldblood","Cold Blood",14177,{pop=true,noGcd=true},o(14177))
e("preparation","Preparation",14185,{pop=true})



i("evasion","Evasion",5277,b.FROST)
i("sprint","Sprint",2983,b.NATURE)
i("vanish","Vanish",1856,b.SHADOW,{buff=11327})


n("remorseless","Remorseless",14143,{pop=false,glow=false,knownWith=14144})



d("mainhandpoison",a.handEnchant({id="mainhandpoison",name="Main Hand Poison",hand="main"}))
d("offhandpoison",a.handEnchant({id="offhandpoison",name="Off Hand Poison",hand="off"}))






local function e(c,b,e,f)
local b=a.cooldownPremade({id=c,name=b,spell=e,readyOpacity=0})
local e=b.sources[1]
a.look(e,e.layers[1],"coolingDown",{shown=false})
a.withCount(b,{items={f},low=5,name="Powder count",shown="Shown when low"})

return d(c,b,{experimental={p,q,r},
preview={reagent={state="present",facts={low=true}}}})
end
e("flashpowder","Flash Powder",1856,5140)
e("blindingpowder","Blinding Powder",2094,5530)



a.onlyInCombat(a.variant(c,"sliceanddice","icon",{form="reminder",spell=5171}))
a.onlyInCombat(a.variant(c,"sliceanddice","bar",{spell=5171,colour=b.PHYSICAL,hidden=true}))
a.variant(c,"rupture","bar",{unit="target",spell=1943,colour=b.BLEED})
a.variant(c,"adrenalinerush","bar",{cooldown=true,spell=13750,colour=b.PHYSICAL})

a.onlyInCombat(a.variant(c,"sliceanddice","words",{spell=5171,when="missing",words="No Slice and Dice",
late="Slice and Dice fading"}))
a.onlyInCombat(a.variant(c,"sliceanddice","thinBar",{spell=5171,colour=b.PHYSICAL}))
a.onlyInCombat(a.variant(c,"sliceanddice","upright",{spell=5171,colour=b.PHYSICAL}))
local d={cooldown=true,spell=13750,with={spell=13750},colour=b.PHYSICAL}
a.variant(c,"adrenalinerush","twinBars",h.copy(d))
a.variant(c,"adrenalinerush","hourglass",h.copy(d))
local b={cooldown=true,spell=408,with={unit="target",spell=408},colour=b.PHYSICAL}
a.variant(c,"kidneyshot","twinBars",h.copy(b))
a.variant(c,"kidneyshot","bar",h.copy(b))


f.registerUsable({
{"rogue-riposte","Riposte",14251,"ROGUE"},
})


local a=a.art.BLOOD
f.registerAlerts({

{"rogue-riposte-alert","ROGUE",{id="riposte-alert",name="Riposte alert",spell=14251,
picture="genericArc3",colour=a,usable=true}},
})
