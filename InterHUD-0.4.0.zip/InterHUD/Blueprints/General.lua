











local b,a=...
local b=a.Blueprints
local c=b.kit

local g="Another player's copy: untested"
local f="In a group and In a raid (IsInGroup, IsInRaid): unplayed"

local a={
{"fortitude","Fortitude",{1243,21562}},
{"markofthewild","Mark of the Wild",{1126,21849}},
{"arcaneintellect","Arcane Intellect",{1459,23028}},
{"kings","Kings",{20217,25898}},
}

local d={}
for e,a in ipairs(a)do
local e="raidbuff-"..a[1]
local c=c.keepUp({id=e,name=a[2],spell=a[3],quiet=true,lastPercent=5,castBy="anyone"})
c["while"],c.unless="game.inGroup","game.inCombat"
b.registerPremade(e,{label="Raid buff: "..a[2],general=true,record=c,
experimental={g,f}})
d[#d+1]=e
end
b.registerPremadeGroup("general-raidbuffs",{label="Raid buffs",general=true,arrangement="row",
members=d})

local a=c.colour







local d={id="threat",kind="threat",
layers={{id="strip",kind="bar",name="Threat bar",value="full",length=120,thickness=14,
position={point="CENTER",toPoint="CENTER",x=0,y=0},background={colour="#000000b3"},
shown=false,texts={{id="words",content="custom",words="Attacking you",fontSize=11}},
looks={{["while"]="tanking",shown=true,colour=a.ALARM},
{["while"]="slipping",shown=true,colour=a.ALARM},
{["while"]="pulling",shown=true,colour=a.FADING,
texts={words={words="Your threat is highest"}}}}}}}
c.onEvent(d,"gainsAggro",{id="aggro-pop",kind="pop",over={"strip"}},
{id="aggro-sound",kind="sound",enabled=false})
b.registerPremade("general-aggro",{label="Aggro warning",general=true,
experimental={c.THREAT,f},
record={id="aggro",name="Aggro warning",["while"]="game.inGroup",sources={d},
quick={
{label="Words on the bar",part="words",field="enabled"},
{label="Bar while your threat is highest",choices={
{label="Shown",writes={{part="strip",look="pulling",field="shown",value=true}}},
{label="Hidden",writes={{part="strip",look="pulling",field="shown",value=false}}},
}},
{label="Pop when it turns on you",part="aggro-pop",field="enabled"},
{label="Sound when it turns on you",part="aggro-sound",field="enabled"},
}}})




b.registerPremade("general-breath",{label="Breath",general=true,
experimental={"The breath source's warning (new: CA-10 by probe only)",
"Breath's time left as numbers and a bar (a duration from its plain progress: CA-10)"},
record={id="breath",name="Breath",sources={{id="breath",kind="breath",
layers={
{id="icon",kind="icon",sweep={enabled=false},border={ring=true,ringColour=a.ALARM},
glows={{id="glow",name="Glow under water",shown=true}},
looks={{["while"]="notDraining",shown=false}}},
{id="bar",kind="bar",name="Breath bar",thickness=8,
position={point="TOP",toPoint="BOTTOM",x=0,y=0},colour=a.WATER,
looks={{["while"]="notDraining",shown=false}}},
}}},
quick={
{label="Breath bar",part="bar",field="enabled"},
{label="Duration numbers",part="icon",field="time.enabled"},
{label="Glow under water",part="glow",field="enabled"},
}}})






local d={"The swing source's bar (new: CA-8's plain length into a duration)",
"Due after a grace past the swing's end (unplayed)"}
local a="The off hand's and ranged swings (EP-16)"
local a={
{"general-swing","main","Main hand swing timer","#ffcc40"},
{"general-swing-offhand","off","Off hand swing timer","#c9a45a",a},
{"general-swing-ranged","ranged","Ranged swing timer","#9fd0ff",a},
}
for e,a in ipairs(a)do
local d={d[1],d[2],a[5]}
local e={{["while"]="none",shown=false},{["while"]="due",shown=false}}
local f={{id="swing",kind="swing",hand=a[2],layers={
{id="bar",kind="bar",name="Swing bar",value="time",fills=true,length=220,thickness=7,
colour=a[4],time={enabled=false},looks=e}}}}

if a[2]~="ranged"then

table.insert(f,1,{id="range",kind="range",facts={ranges={{id="outofmelee",name="Out of melee range",from=5}}}})
e[#e+1]={["while"]="range.outofmelee",opacity=40}
d[#d+1]="Out of melee range by the range source's estimate (new: UN-7's reads up a ladder)"
end
b.registerPremade(a[1],{label=a[3],general=true,experimental=d,
record={id="swing",name=a[3],sources=f,
quick=c.swingQuick({"bar"})}})
end
