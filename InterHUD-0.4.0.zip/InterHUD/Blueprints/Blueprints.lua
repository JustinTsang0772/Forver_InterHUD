


local a,b=...
local d=b.Schema

local a={}
b.Blueprints=a

local g,e={},{}
local h,c={},{}

local function f(a)return type(a)=="table"and a or{a}end

function a.register(a,b)
assert(not e[a],"blueprint registered twice: "..a)
e[a]=b
g[#g+1]=a
end

function a.keys()return g end
function a.get(a)return e[a]end



function a.make(c,d,g)
local e=assert(e[c],"no blueprint "..tostring(c))
local a=b.copy(e.record)
a.id=g
if d~=nil then a.sources[1].spells=b.copy(f(d))end
a.origin={kind="blueprint",id=c,name=e.label}
return a
end






local j={cooldown=true,buff=true,debuff=true,cooldownBuff=true,cooldownDebuff=true,
cooldownTotem=true,stacks=true,enchant=true,alert=true}
local i,g={},{}
function a.registerLayout(a,b)
assert(not g[a],"layout registered twice: "..a)
assert(type(b.label)=="string"and type(b.word)=="string"and type(b.build)=="function",
"layout "..a..": a label, a word and a builder")
assert(type(b.serves)=="table"and#b.serves>0,"layout "..a..": serves names its combinations")
for c,b in ipairs(b.serves)do assert(j[b],"layout "..a..": no such combination "..tostring(b))end
b.id=a
g[a]=b
i[#i+1]=a
end
function a.layoutKeys()return i end
function a.layout(a)return g[a]end




function a.combination(a)
if d.holdsAlert(a)then return"alert"end
local d,b,c
for e,a in ipairs(a.sources or{})do
if a.layers and#a.layers>0 then
if a.kind=="weaponEnchant"then return"enchant"end
if a.kind=="spell"then d=d or a
elseif a.kind=="totem"or a.kind=="aura"then b=b or a end
if a.kind=="aura"then c=c or a end
end
end


if d and b and b.kind=="aura"and b.unit=="target"then
for b,a in ipairs(b.layers)do
if a.kind=="icon"then d=nil break end
end
end
if d then
if not b then return"cooldown"end
if b.kind=="totem"then return"cooldownTotem"end
return b.unit=="target"and"cooldownDebuff"or"cooldownBuff"
end
if not c then return nil end
if c.facts and c.facts.stacks and#c.facts.stacks>0 then return"stacks"end
return c.unit=="target"and"debuff"or"buff"
end








function a.registerPremade(b,a)
assert(not c[b],"pre-made registered twice: "..b)
assert(a.layout==nil or g[a.layout],"pre-made "..b..": no layout "..tostring(a.layout))
for c,a in ipairs(a.variants or{})do
assert(g[a],"pre-made "..b..": a variant in no layout "..tostring(a))
end
local e=(a.class and 1 or 0)+(a.races and 1 or 0)+(a.general and 1 or 0)
assert(e==1,"pre-made "..b..": tag it with one of class, races or general")
if a.experimental~=nil then
assert(type(a.experimental)=="table"and#a.experimental>0,
"pre-made "..b..": experimental names its routes, a list")
for c,a in ipairs(a.experimental)do
assert(type(a)=="string"and a~="","pre-made "..b..": an experimental route is words")
end
end
local e=a.preview
assert(e==nil or type(e)=="string"or type(e)=="table","pre-made "..b..": preview is a state or a table of states or picks by source")
if type(e)=="table"then
for c,a in pairs(e)do
if c=="game"then
assert(type(a)=="table","pre-made "..b..": preview.game lists game facts")
for c,a in ipairs(a)do assert(d.gameFactSpec(a),"pre-made "..b..": no game fact "..tostring(a))end
else
assert(type(c)=="string"and(type(a)=="string"or type(a)=="table"and type(a.state)=="string"
and type(a.facts)=="table"),"pre-made "..b..": preview[source] is a state or a pick")
end
end
end
assert(type(a.record.sources)=="table","pre-made "..b..": a record of this format, its sources a list")
if d.alertFlag(a.record,"loose")then a.loose=true end
c[b]=a
h[#h+1]=b
end
function a.premadeKeys()return h end
function a.premade(a)return c[a]end




local h={}
function a.signOff(a,b)
assert(c[a],"signed off, but no pre-made "..tostring(a))
assert(not h[a],"pre-made signed off twice: "..a)
h[a]=b
end
function a.isDraft(a)return c[a]~=nil and h[a]==nil end
function a.signedOff(a)return h[a]end





local h,i={},{}
function a.registerPremadeGroup(b,a)
assert(not i[b],"pre-made group registered twice: "..b)
assert((a.class~=nil)~=(a.general==true)and a.label and a.members and#a.members>0,
"pre-made group "..b..": a class or general, a label and its members")
i[b]=a
h[#h+1]=b
end
function a.premadeGroupKeys()return h end
function a.premadeGroup(a)return i[a]end


function a.markExperimental(d,b)
local a=assert(c[d],"marked experimental, but no pre-made "..tostring(d))
assert(type(b)=="string"and b~="","pre-made "..d..": an experimental route is words")
a.experimental=a.experimental or{}
for c,a in ipairs(a.experimental)do
if a==b then return end
end
a.experimental[#a.experimental+1]=b
end

local h={}


function a.routeProven(b)
h[#h+1]=b
for c,a in pairs(g)do
for c=#(a.routes or{}),1,-1 do
if a.routes[c]==b then table.remove(a.routes,c)end
end
end
for a,c in pairs(c)do
local a=c.experimental
if a then
for c=#a,1,-1 do
if a[c]==b then table.remove(a,c)end
end
if#a==0 then c.experimental=nil end
end
end
end

function a.isProven(a)
for c,b in ipairs(h)do
if b:find(a,1,true)then return true end
end
return false
end


function a.experimental(a)return c[a]and c[a].experimental end


function a.experimentalSources(a)
local c=c[a]
if not c then return nil end
local a,e=nil,{}
for f,c in ipairs(c.record.sources or{})do
if b.Sources.experimental(c.kind)and not e[c.kind]then
e[c.kind]=true
local b=d.variantOf(c)
local b=b and b.add and b.add.label or c.kind
a=a or{}
a[#a+1]=b
end
end
return a
end


local function g()
if not UnitRace then return nil end
local b,c,a=UnitRace("player")
return a
end




function a.makePremade(d,e)
local c=assert(c[d],"no pre-made "..tostring(d))
local a=b.copy(c.record)
a.id=e or a.id
a.origin={kind="premade",id=d,name=c.label}
local d=c.races and g()
if d then
local b=false
for c,a in ipairs(c.races)do b=b or a==d end
if not b then a.enabled=false end
end
return a
end







function a.originRecord(f)
local d=f and f.origin
if not d then return nil end
if d.kind=="premade"then
return c[d.id]and a.makePremade(d.id)or nil
end
if d.kind~="blueprint"or not e[d.id]then return nil end
local a=b.copy(e[d.id].record)
local c=f.sources and f.sources[1]
a.sources[1].spells=c and b.copy(c.spells)or nil
return a
end



local e={"id","name","enabled","position","origin"}
function a.resetElement(c)
local a=a.originRecord(c)
if not a then return nil end
for e,d in ipairs(e)do a[d]=b.copy(c[d])end
return a
end



function a.originPart(c,e)
local a=a.originRecord(c)
if not a then return nil end
local c,a,e=d.partOf(a,e)
if not a or c=="element"then return nil end
local b=b.copy(a)
for c,a in ipairs((d.frame(c,a,e)))do
if a.style then b[a.name]=nil end
end
return b
end


function a.empty(a)
return{id=a}
end

a.register("cooldown",{
label="Cooldown",

record={
sources={{id="spell",kind="spell",
layers={{id="icon",kind="icon",glows={{id="ready-glow",name="Ready glow"}},
looks={{["while"]="ready",glows={["ready-glow"]={shown=true}}}}}},
events={comesReady={effects={{id="ready-pop",kind="pop"}}},
reset={effects={{id="reset-pop",kind="pop"}}}}}},
},
})

a.register("keepUpBuff",{
label="Keep-up buff",

record={
sources={{id="buff",kind="aura",unit="player",
layers={{id="icon",kind="icon",glows={{id="expiring-glow",name="Expiring glow"}},
looks={{["while"]="missing",desaturated=true},
{["while"]="expiring",glows={["expiring-glow"]={shown=true}}}}}}}},
},
})

a.register("proc",{
label="Proc",

record={
sources={{id="buff",kind="aura",unit="player",
layers={{id="icon",kind="icon",glows={{id="glow",shown=true}},
looks={{["while"]="missing",shown=false}}}},
events={arrived={effects={{id="arrival-pop",kind="pop"}}}}}},
},
})

a.register("targetDebuff",{
label="Debuff on target",


record={
sources={{id="debuff",kind="aura",unit="target",
layers={{id="icon",kind="icon",glows={{id="expiring-glow",name="Expiring glow"}},
looks={{["while"]="missing",desaturated=true},
{["while"]="expiring",glows={["expiring-glow"]={shown=true}}}}}}}},
},
})




local function d(a)
if a==false then return false end
end


local function e(a,c,...)
a.events=a.events or{}
local b=a.events[c]or{effects={}}
a.events[c]=b
for c,a in ipairs({...})do b.effects[#b.effects+1]=a end
return a
end





local function c(a,c)
a.onlyWhileYouKnow=b.copy(f(c))
return a
end





local function j(g,b,f,a)
local f={id="buff",kind="aura",unit="player",spells={f},
layers={
{id="icon",kind="icon",time={enabled=false},count={enabled=false},
glows={{id="glow",name="Glow while up",enabled=d(a.glow),shown=true}},
looks={{["while"]="missing",shown=false}}},
}}
e(f,"arrived",{id="arrival-pop",kind="pop",enabled=d(a.pop)})
local b={
id=g,name=b,sources={f},
quick={
{label="Pop as "..b.." arrives",part="arrival-pop",field="enabled"},
{label="Glow while "..b.." is up",part="glow",field="enabled"},
},
}
return a.knownWith and c(b,a.knownWith)or b
end






local g=30
local function h()
return{label="Icon while Ready",choices={
{label="Shown",writes={{part="icon",look="ready",field="opacity",clear=true},
{part="icon",look="ready",field="shown",clear=true}}},
{label="Dimmed",writes={{part="icon",look="ready",field="opacity",value=g},
{part="icon",look="ready",field="shown",clear=true}}},
{label="Hidden",writes={{part="icon",look="ready",field="shown",value=false}}},
}}
end
a.readyChoice=h
local function k(a)
local g={id="icon",kind="icon",name="Icon"}
local f={id="spell",kind="spell",spells=b.copy(f(a.spell)),layers={g}}
local b={}
local i={id=a.id,name=a.name,sources={f},quick=b}
local c={}
if a.readyOpacity==0 then c.shown=false else c.opacity=a.readyOpacity end
if a.pop~=nil then
e(f,"comesReady",{id="ready-pop",kind="pop",enabled=d(a.pop)})
b[#b+1]={label="Ready pop",part="ready-pop",field="enabled"}
end
if a.glow~=nil then
g.glows={{id="ready-glow",name="Ready glow",enabled=d(a.glow)}}
c.glows={["ready-glow"]={shown=true}}
b[#b+1]={label="Ready glow",part="ready-glow",field="enabled"}
end
if next(c)~=nil then
c["while"]="ready"
g.looks={c}
end
b[#b+1]=h()
if a.noGcd then g.gcdSweep={enabled=false}end
b[#b+1]={label="GCD sweep",part="icon",field="gcdSweep.enabled"}
return i
end








local function l(c,a)
a=setmetatable({name=a.name or(c.name.." buff")},{__index=a})
local f={id="buff",kind="aura",unit="player",spells=b.copy(f(a.spell)),layers={}}
c.sources[#c.sources+1]=f


local i=a.name:match(" buff$")and a.name or(a.name.." buff")
local b={}
local g={}
for b,a in ipairs(c.quick)do g[#g+1]=a end
g[#g+1]={section=a.name,rows=b}
local h
if not a.barOnly then
h={id="buff-icon",kind="icon",name=a.name,sweep={enabled=false},
time={enabled=false},count={enabled=false},looks={{["while"]="missing",shown=false}}}
f.layers[1]=h
b[#b+1]={label=i.." shown over the icon",part="buff",field="enabled"}
end
if a.time or a.barOnly then
f.layers[#f.layers+1]={id="buff-bar",kind="bar",name=a.name.."'s time",thickness=8,
position={point="TOP",toPoint="BOTTOM",x=0,y=0},colour=a.barColour,
looks={{["while"]="missing",shown=false}}}
b[#b+1]={label=a.name.."'s time bar",part=a.barOnly and"buff"or"buff-bar",field="enabled"}
end
if a.time and not a.barOnly then
f.layers[#f.layers+1]={id="buff-countdown",kind="text",name=a.name.."'s countdown",fontSize=12,
position={point="TOPLEFT",toPoint="TOPLEFT",x=1,y=-1},
looks={{["while"]="missing",shown=false}}}
b[#b+1]={label=a.name.."'s countdown numbers",part="buff-countdown",field="enabled"}
end
if a.barOnly then
c.quick=g
return c
end
if a.glow~=nil then
h.glows={{id="buff-glow",name="Glow while "..a.while_,enabled=d(a.glow),shown=true}}
b[#b+1]={label="Glow while "..a.while_,part="buff-glow",field="enabled"}
end
if a.pop~=nil then
e(f,"arrived",{id="buff-pop",kind="pop",enabled=d(a.pop)})
b[#b+1]={label="Pop when "..a.as,part="buff-pop",field="enabled"}
end
c.quick=g
return c
end




local g={[7384]=true,[5308]=true,[24275]=true}
local function h(a)
return g[a]and"game.hostileTarget"or nil
end



local function i(a)
local b,a=b.Spells.family(a)
return not a or a.kind~="spell"or a.cooldown~=nil
end








local function g(a)
local c=i(a.spell)
local d={id="usable",needsPower=a.needsPower or nil}
e(d,"enters",{id="opens-pop",kind="pop"})
local b={{["while"]={"ready","usable"},glows={["ready-glow"]={shown=true}}}}
if c then b[#b+1]={["while"]={"coolingDown","usable"},opacity=60}end
b[#b+1]={unless="usable",shown=false}
local d={id="spell",kind="spell",spells={a.spell},
facts={usable={d},notUsable={enabled=false},
notEnoughPower=a.needsPower and{enabled=false}or nil},
layers={{id="icon",kind="icon",gcdSweep={enabled=false},
glows={{id="ready-glow",name="Glow while usable"}},looks=b}}}
local b={{label="Pop when usable",part="opens-pop",field="enabled"}}
if c then

e(d,"comesReady",{id="ready-pop",kind="pop",["while"]="spell.usable"})
b[#b+1]={label="Pop when its cooldown ends",part="ready-pop",field="enabled"}
end
b[#b+1]={label="Glow while usable",part="ready-glow",field="enabled"}
if a.needsPower then
b[#b+1]={label="Hidden while short of "..a.power,part="spell.usable",field="needsPower"}
end
return{id=a.id,name=a.name,["while"]=h(a.spell),sources={d},quick=b}
end


















local function i(a)
local d={id="spell-alert",kind="spellAlert",picture=a.picture,
arrangement=a.arrangement or(a.above and"one"or nil),spread=a.spread,colour=a.colour,
opacity=a.opacity or 80}
if a.above then d.position={point="BOTTOM",toPoint="CENTER",x=0,y=a.above}end
local c={id=a.id,name=a.name,scale=a.scale}
local g={id="sound",kind="sound"}
local i=true
if a.afterReset then
c.sources={{id="spell",kind="spell",spells={a.spell},layers={d}}}

c.customStates={{id="just-reset",name="After it ends early",all={"spell.ready"},
hold={after="spell.reset",seconds=a.afterReset},events={enters={effects={g}}}}}
d.shown,d.looks=false,{{["while"]="just-reset",shown=true}}
elseif a.usable then
local b=a.needsPower and{usable={{id="usable",needsPower=true}}}or nil
c["while"]=h(a.spell)
c.sources={{id="spell",kind="spell",spells={a.spell},facts=b,layers={d}}}


c.customStates={{id="ready-and-usable",name="Ready and usable",all={"spell.ready","spell.usable"},
events={enters={effects={g}}}}}
d.shown,d.looks=false,{{["while"]="ready-and-usable",shown=true}}
else
local b={id="buff",kind="aura",unit="player",spells=b.copy(f(a.spell)),layers={d}}
c.sources={b}
if a.stacks then
b.facts={stacks={{id="atStacks",atLeast=a.stacks}}}
d.shown,d.looks=false,{{["while"]="atStacks",shown=true}}
i=false
else
d.looks={{["while"]="missing",shown=false}}
e(b,"arrived",g)
end
end
c.quick={{label="Picture",part="spell-alert",field="picture"},
{label="Colour",part="spell-alert",field="colour"}}
c.quick[#c.quick+1]={label="Size",field="scale"}
if i then c.quick[#c.quick+1]={label="Sound",part="sound",field="sound"}end
return c
end



function a.registerUsable(b)
for c,b in ipairs(b)do
a.registerPremade(b[1],{label=b[2],class=b[4],record=g({id=b[1]:match("%-(.+)$"),
name=b[2],spell=b[3],needsPower=b[5],power=b[6]})})
end
end
function a.registerAlerts(d)
for e,d in ipairs(d)do
local b=b.copy(d[3])
local e=b.knownWith
b.knownWith=nil
local f=i(b)
a.registerPremade(d[1],{label=b.name,class=d[2],record=e and c(f,e)or f})
end
end



a.kit={list=f,shipped=d,onEvent=e,cooldownPremade=k,withBuff=l,
proc=j,usablePremade=g,procArt=i,knownWith=c,
art={FROST="#80b3ff",BLOOD="#ff5c4d",SHADOW="#a77bff",OUTER=410,ABOVE=102.5,HIGHER=205}}
