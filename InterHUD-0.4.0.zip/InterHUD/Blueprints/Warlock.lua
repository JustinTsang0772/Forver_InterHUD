















local b,a=...
local f=a.Blueprints
local a=f.kit


local d=a.classKit("WARLOCK",{pop=false,glow=false})
local k,e=d.premade,d.cooldown
local b=a.colour
local g=b.ALARM



local c=d.add








local function i(c,b)
local d=b.corner=="TOPRIGHT"
c.sources[#c.sources+1]={id="reagent",kind="reagent",items={b.item},reagentFor=b.spell,
layers={{id="reagent-count",kind="text",name=b.label,fontSize=11,
position={point=b.corner or"BOTTOMRIGHT",toPoint=b.corner or"BOTTOMRIGHT",x=-1,
y=d and-1 or 1}}}}
local d=a.layer(c,"icon")
d.looks=d.looks or{}
d.looks[#d.looks+1]={["while"]=b.unless and{"reagent.none",b.unless..".missing"}or"reagent.none",
border={ring=true,ringColour=g}}
return a.quickFirst(c,b.label,"reagent","enabled")
end




local function m(c,b)
c.sources[#c.sources+1]={id=b.source,kind="aura",unit=b.unit,spells={b.spell}}
c.customStates=c.customStates or{}
c.customStates[#c.customStates+1]={id=b.customState,name=b.name,all={b.source..".missing"}}
local d=a.layer(c,"icon")
d.looks=d.looks or{}
d.looks[#d.looks+1]={["while"]=b.customState,desaturated=true}
return a.quickFirst(c,b.label,b.customState,"enabled")
end





local function n(a)
return{
id=a.id,name=a.name,
sources={
{id="buff",kind="aura",unit="player",spells={a.spell},
facts={expiring={{id="expiring",share=5}}},
layers={
{id="icon",kind="icon",name="Icon",sweep={enabled=false},count={enabled=false},
looks={{["while"]="missing",shown=false}}},
{id="bar",kind="bar",name="Time bar",thickness=8,
position={point="BOTTOM",toPoint="BOTTOM",x=0,y=0},colour=a.colour,
looks={{["while"]="missing",shown=false},{["while"]="expiring",colour=g}}},
}},
{id="breath",kind="breath",
layers={
{id="breath-icon",kind="icon",name="Under water",sweep={enabled=false},
time={enabled=false},glows={{id="breath-glow",name="Glow under water",shown=true}},
looks={{["while"]="draining",border={ring=true,ringColour=g}},
{["while"]="notDraining",shown=false}}},
}},
},
quick={
{label="Time bar",part="bar",field="enabled"},
{label="Duration numbers",part="icon",field="time.enabled"},
{label="Warning under water",part="breath",field="enabled"},
{label="Glow under water",part="breath-glow",field="enabled"},
},
}
end




local g="The reagent source (new: unplayed; IT-1 by probe)"
local h="No Ankh and Low or out as looks on a reagent's state and a custom state (never seen)"
local o="Reagent Economy lifting its reagent (never seen taken: IT-4)"
local p="The breath source's warning (new: CA-10 by probe only)"
local j="Shadow and Flame's two buffs, 426311 after Shadowburn and 1293816 after Conflagrate: which"
.." cast gives which, unseen"
local l="Not usable without your Immolate on the target (CD-8: usable ignores some requirements)"
local q="A look on a cooldown's icon keyed on a target aura's Missing (the split pane): no Immolate"
.." (unseen)"
local r="A look joining a reagent's None and a buff's Missing (never seen)"
local s="A warlock stone read as the hand's enchant (IT-2: imbues and a sharpening stone only)"




c(a.extras(f.layout("iconBar").build({id="corruption",name="Corruption",unit="target",spell=172,
colour=b.SHADOW}),{range=true,power=true}),{layout="iconBar"})

c(a.debuff({id="immolate",name="Immolate",spell=348,colour=b.FIRE,range=true,power=true}))

c(a.debuff({id="siphonlife",name="Siphon Life",spell=18265,colour=b.NATURE,range=true,power=true}))


c(a.debuff({id="wrack",name="Wrack",spell=1316697,colour=b.BLEED,range=true,power=true,
lastPercent=35}))


c(a.debuff({id="bane",name="Bane",spell={980,603,1225228},shows="lastSeen",colour=b.SHADOW,
range=true,power=true}))

c(a.debuff({id="curse",name="Curse",spell={440892,702,704,1714,18223},shows="lastSeen",
colour=b.ARCANE,range=true,power=true}))


c(a.knownWith(a.debuff({id="shadowvulnerability",name="Shadow Vulnerability",spell=17794,
colour=b.SHADOW,missing="hidden"}),17793))


c(a.debuff({id="control",name="Fear and Banish",spell={5782,710},shows="lastSeen",colour=b.SHADOW,
missing="hidden",range=true,power=true}))



c(i(a.withBuff(e("shadowburn","Shadowburn",17877),
{spell=426311,name="Flame",time=true,barColour=b.FIRE}),
{item=6265,spell=17877,label="Shard count",corner="TOPRIGHT"}),
{experimental={j,g,h}})



c(a.withBuff(e("conflagrate","Conflagrate",1293817),
{spell=1293816,name="Shadow",time=true,barColour=b.SHADOW}),
{experimental={l,j}})



c(i(a.withBuff(e("soulfire","Soul Fire",6353),
{spell=440873,name="Decimation",glow=true,pop=true,while_="Decimation is up",
as="Decimation comes",time=true,barColour=b.FIRE}),
{item=6265,spell=6353,label="Shard count",corner="TOPRIGHT",unless="buff"}),
{experimental={g,h,r}})

c(a.withDebuffBar(e("baneofdoom","Bane of Doom",603),{spell=603,name="Doom bar",
colour=b.SHADOW}))



c(a.withBuff(e("amplifycurse","Amplify Curse",18288,{pop=true,noGcd=true}),
{spell=18288,name="Amplified",time=true,barColour=b.ARCANE,glow=true,
while_="primed"}))



local l=e("inferno","Inferno",1122,{pop=true})
l.sources[1].facts={outOfRange={enabled=false}}
c(i(l,{item=5565,spell=1122,label="Stone count"}),
{experimental={g,h,o}})


c(a.extras(f.layout("icon").build({id="deathcoil",name="Death Coil",spell=6789,cooldown=true}),
{pop=true,glow=false,gcd=true}),{layout="icon"})
c(a.withDebuffBar(e("howlofterror","Howl of Terror",5484,{pop=true}),
{spell=5484,name="Fear bar",colour=b.SHADOW}))

c(a.withBuff(e("shadowward","Shadow Ward",6229,{pop=false}),
{spell=6229,name="Ward",time=true,barColour=b.SHADOW}))


c(a.withBuff(e("feldomination","Fel Domination",18708,{pop=a.NONE,glow=a.NONE,readyOpacity=0,
noGcd=true}),{spell=18708,name="Primed",glow=true,
while_="primed"}))



c(a.extras(f.layout("icon").build({id="armor",name="Demon Armor",spell={706,687},shows="lastSeen",
lastPercent=5}),{power=true,quiet=true,missingGlow=true,expiringGlow=false}),
{layout="icon"})



c(a.knownWith(a.keepUp({id="demonbuff",name="Soul Link or Sacrifice",
spell={25228,18789,18790,18791,18792},shows="lastSeen",timed=false,quiet=true,missingGlow=true}),
{19028,18788}))

c(a.handEnchant({id="stone",name="Firestone or Spellstone",hand="main",spell=6366}),
{experimental={s}})


c(n({id="unendingbreath",name="Unending Breath",spell=5697,colour=b.WATER}),
{experimental={p}})







local i=a.COUNT_ROUTE

c(a.withCount(a.cooldownPremade({id="healthstone",name="Healthstone",spell=6201,readyOpacity=0}),
{items={9421,19012,19013,5510,19010,19011,5509,19008,19009,5511,19006,19007,5512,19004,19005},
name="Healthstone count",shown="Shown when out"}),
{experimental={i,g,h}})

c(a.withCount(a.cooldownPremade({id="soulstone",name="Soulstone",spell=693,readyOpacity=0}),
{items={16896,16895,16893,16892,5232},name="Soulstone count",shown="Shown when out"}),
{experimental={i,g,h}})


c(a.withCount(a.cooldownPremade({id="soulshards",name="Soul Shards",spell=1120,readyOpacity=0}),
{items={6265},low=2,name="Shard count",shown="Shown when low"}),
{experimental={i,g,h}})


c(a.knownWith(a.extras(f.layout("icon").build({id="shadowtrance",name="Shadow Trance",spell=17941,
hidden=true}),{pop=true,glow=true}),18094),{layout="icon"})



a.variant(d,"corruption","bar",{spell=172,unit="target",colour=b.SHADOW})
a.variant(d,"immolate","bar",{spell=348,unit="target",colour=b.FIRE})
a.variant(d,"bane","bar",{spell={980,603,1225228},unit="target",shows="lastSeen",colour=b.SHADOW})
a.variant(d,"curse","bar",{spell={440892,702,704,1714,18223},unit="target",shows="lastSeen",
colour=b.ARCANE})

a.variant(d,"corruption","barAlone",{spell=172,unit="target",colour=b.SHADOW})
a.variant(d,"corruption","thinBar",{spell=172,unit="target",colour=b.SHADOW})
a.variant(d,"corruption","upright",{spell=172,unit="target",colour=b.SHADOW})
a.variant(d,"deathcoil","bar",{cooldown=true,spell=6789,colour=b.SHADOW})
a.variant(d,"armor","words",{spell={706,687},shows="lastSeen",lastPercent=5,when="missing",
words="No armor",late="Armor fading"})
a.variant(d,"armor","thinBar",{spell={706,687},shows="lastSeen",lastPercent=5,colour=b.SHADOW})
a.variant(d,"shadowtrance","words",{spell=17941,knownWith=18094,when="present"})
a.variant(d,"shadowtrance","bar",{spell=17941,knownWith=18094,colour=b.SHADOW,hidden=true})

k("conflagrate-immolate",m(a.withBuff(e("conflagrate-immolate","Conflagrate with Immolate",
1293817),{spell=1293816,name="Shadow",time=true,barColour=b.SHADOW}),
{spell=348,unit="target",source="immolate",customState="no-immolate",name="No Immolate",
label="Grey with no Immolate"}),{experimental={q,j}})

k("soulfire-proc",a.proc("soulfire-proc","Decimation proc",440873,{knownWith=440870}))


local c=a.art.OUTER
f.registerAlerts({

{"warlock-shadowtrance-alert","WARLOCK",{id="shadowtrance-alert",name="Shadow Trance alert",spell=17941,
knownWith=18094,picture="nightfall"}},
{"warlock-decimation-alert","WARLOCK",{id="decimation-alert",name="Decimation alert",spell=440873,
knownWith=440870,picture="moltenCore",spread=c}},
})

a.variant(d,"shadowtrance-alert","alertBar",{spell=17941,knownWith=18094,picture="nightfall",
barColour=b.SHADOW})
