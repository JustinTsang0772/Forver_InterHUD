






local b,a=...
local g=a.Blueprints
local a=g.kit


local e=a.classKit("HUNTER",{pop=false,glow=false})
local f,h=e.cooldown,e.big
local c=a.colour



local b=e.add
local function i(b,c)
a.main(b).spells=c
return b
end



local j="Your own cast only: another hunter's copy on you may read as missing (EP-28)"
local k="A hostile target's Enrage by dispel type Frenzy (EP-40: unplayed)"
local l="Out of range and Not enough power over a by-type button"
local m="Cooling down greying a by-type button (another source's state over an aura's button)"



local function d(a,c,d,e)b(f(a,c,d,e))end
d("arcaneshot","Arcane Shot",3044)
d("summonhawk","Summon Hawk",1293241)
d("aimedshot","Aimed Shot",19434)
d("multishot","Multi-Shot",2643)
d("concussiveshot","Concussive Shot",5116)
d("scattershot","Scatter Shot",19503)
d("distractingshot","Distracting Shot",20736)

d("tranquilizingshot","Tranquilizing Shot",19801)

d("raptorstrike","Raptor Strike",2973,{noGcd=true})
d("striderkick","Strider Kick",1317257)
d("disengage","Disengage",781)

d("flare","Flare",1543)



b(a.withBuff(f("snipershot","Sniper Shot",1310687),{spell=1310687,barOnly=true,
barColour=c.PHYSICAL}))

b(a.withDebuffBar(f("scarebeast","Scare Beast",1513),{spell=1513,name="Fear bar",
colour=c.NATURE}))




b(a.purge({id="tranquilizingshotenrage",name="Tranquilizing Shot on Enrage",spell=19801,dispel="frenzy",
cooling=true}),{experimental={k,l,m}})



b(f("frosttraps","Frost Traps",{1499,13809}))
b(f("firetraps","Fire Traps",{13795,13813}))



b(h("rapidfire","Rapid Fire",3045,c.PHYSICAL))
b(h("deterrence","Deterrence",19263,c.FROST))
b(f("bestialwrath","Bestial Wrath",19574,{pop=true,noGcd=true}))

b(f("intimidation","Intimidation",19577,{pop=true}))

b(f("feigndeath","Feign Death",5384,{pop=a.NONE,glow=a.NONE,readyOpacity=0,noGcd=true}))




b(a.extras(g.layout("iconBar").build({id="huntersmark",name="Hunter's Mark",unit="target",spell=1130,
colour=c.BLOOD}),{range=true,power=true}),{layout="iconBar"})
b(a.expiringGlow(a.debuff({id="sting",name="Sting",spell={1978,3043,3034},shows="lastSeen",
colour=c.NATURE,range=true,power=true})))
b(a.expiringGlow(a.debuff({id="lacerate",name="Lacerate",spell=24118,colour=c.BLEED,range=true,
power=true})))
b(a.debuff({id="blackarrow",name="Black Arrow",spell=3674,colour=c.SHADOW,range=true}))

b(a.debuff({id="wingclip",name="Wing Clip",spell=2974,colour=c.FROST,missing="hidden",range=true,
power=true}))


b(a.knownWith(a.debuff({id="laceratingstrikes",name="Lacerating Strikes",spell=1310536,colour=c.BLEED,
missing="hidden"}),1310533))




b(a.proc("rapidkilling","Rapid Killing",415407,{knownWith=415405}))
b(a.proc("exposeprey","Expose Prey",1310726,{knownWith=1310532}))
local d={13165,13161,469145}
b(i(a.proc("quickshots","Quick Shots or Strikes",6150,{pop=false,glow=false,knownWith=d}),
{6150,1299448,469144}))



b(a.keepUp({id="aspect",name="Aspect",
spell={13165,415423,13163,5118,13159,13161,20043,469145},shows="lastSeen",timed=false,
missingGlow=true,power=true}),{experimental={j}})

b(a.onlyInCombat(i(a.warnWhileUp({id="cheetah",name="Cheetah in combat",spell=5118}),
{5118,13159})))

b(a.keepUp({id="trueshotaura",name="Trueshot Aura",spell=1299346,quiet=true,lastPercent=5,
missingGlow=true,expiringGlow=false,power=true,castBy="anyone"}))
b(a.keepUp({id="heartofthelion",name="Heart of the Lion",spell=409580,quiet=true,timed=false,
missingGlow=true,power=true}),{experimental={j}})


a.variant(e,"huntersmark","bar",{unit="target",spell=1130,colour=c.BLOOD})
a.variant(e,"lacerate","iconBar",{barAt="below",unit="target",spell=24118,colour=c.BLEED})
a.variant(e,"rapidfire","bar",{cooldown=true,spell=3045,colour=c.PHYSICAL})
a.variant(e,"quickshots","icon",{form="mark",spell={6150,1299448,469144},knownWith=d,
colour=c.PHYSICAL})
a.variant(e,"exposeprey","icon",{form="mark",spell=1310726,knownWith=1310532,colour=c.BLEED})

a.variant(e,"huntersmark","thinBar",{unit="target",spell=1130,colour=c.BLOOD})


g.registerUsable({
{"hunter-mongoosebite","Mongoose Bite",1495,"HUNTER"},
{"hunter-counterattack","Counterattack",19306,"HUNTER"},
})


local a,b=a.art.ABOVE,a.art.HIGHER
g.registerAlerts({

{"hunter-mongoosebite-alert","HUNTER",{id="mongoosebite-alert",name="Mongoose Bite alert",spell=1495,
picture="lockAndLoad",above=a,usable=true}},
{"hunter-counterattack-alert","HUNTER",{id="counterattack-alert",name="Counterattack alert",spell=19306,
picture="masterMarksman",above=b,usable=true}},
})
