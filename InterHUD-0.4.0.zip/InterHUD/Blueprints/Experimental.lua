



local a,c=...
local b=c.Blueprints

local function a(a,c)
for d,c in ipairs(c)do b.markExperimental(c,a)end
end

a("Not usable for a Berserker Stance spell (CD-8 read a stance at rest and in combat, Berserker never)",{
"warrior-whirlwind","warrior-pummel","warrior-intercept","warrior-berserkerrage","warrior-recklessness",
})

a("A table-linked debuff ID no run has seen",{
"warrior-disarm","warrior-hamstring","hunter-laceratingstrikes",
})
a("Water Shield's IDs (408510; 408511 kept by hand): never seen",{
"shaman-shields",
})
a("Not enough power on the Missing icon: a tinted copy of the icon",{
"shaman-shields","warrior-battleshout","hunter-aspect","hunter-trueshotaura",
"hunter-heartofthelion","rogue-sliceanddice",
"mage-armor","mage-arcaneintellect",
})
a("Not enough power over the debuff's button (shown on a buff only)",{
"shaman-flameshock","warrior-rend","hunter-huntersmark",
"hunter-sting","hunter-lacerate","rogue-rupture","rogue-garrote","rogue-hemorrhage",
"rogue-exposearmor","rogue-sap",
"mage-polymorph",
})
a("Out of range and Not enough power on the Missing icon: a tinted copy of the icon",{
"shaman-flameshock","warrior-rend","hunter-huntersmark","hunter-sting","hunter-lacerate",
"hunter-blackarrow","rogue-rupture","rogue-garrote","rogue-hemorrhage","rogue-exposearmor",
})
a("A hostile target's Magic buff by dispel type (AU-13: documented only)",{
"shaman-purge",
})
a("Out of range and Not enough power over a by-type button",{
"shaman-purge",
})
a("Not enough power over a by-type button",{
"shaman-curepoison","shaman-curedisease",
"mage-removelessercurse",
})
a("The reagent source (new: unplayed; IT-1 by probe)",{
"shaman-waterwalking","shaman-waterbreathing","shaman-reincarnation",
"mage-conjuredwater","mage-managem","mage-arcanepowder",
})
a("Low or out within the buff's Missing (a custom state on a reagent, never seen)",{
"shaman-waterwalking","shaman-waterbreathing",
})
a("The breath source's warning (new: CA-10 by probe only)",{
"shaman-waterbreathing",
})
a("Reincarnation's cooldown by 21169 (which ID reports it, unrecorded)",{
"shaman-reincarnation",
})
a("No Ankh and Low or out as looks on a reagent's state and a custom state (never seen)",{
"shaman-reincarnation",
"mage-conjuredwater","mage-managem","mage-arcanepowder",
})
a("Spell Alert art at N stacks (art on a gate: unseen)",{
"shaman-maelstrom-alert","mage-heatingup-alert","druid-eclipse-alert",
})
a("Not usable without Victorious (CD-8: usable ignores some requirements)",{
"warrior-victoryrush",
})


a("Overpower's window read at its events with no poll (CD-8: Revenge's recorded, Overpower's with the poll)",{
"warrior-overpower","warrior-overpower-alert",
})
a("The pressed look on a Usable icon (never seen)",{
"warrior-overpower","warrior-revenge","warrior-execute","hunter-mongoosebite","hunter-counterattack",
"rogue-riposte","paladin-hammerofwrath",
})
a("Shown with no target (CD-8's window read without one: unseen)",{
"warrior-revenge","warrior-revenge-alert","hunter-mongoosebite","hunter-mongoosebite-alert",
"hunter-counterattack","hunter-counterattack-alert","rogue-riposte","rogue-riposte-alert",
})
a("CD-8's window on Execute (unseen on it; its flag follows the target's health, whose event is unseen)",{
"warrior-execute","warrior-execute-alert",
})
a("Shut while short of rage under 20% (needsPower: unseen)",{
"warrior-execute","warrior-execute-alert",
})
a("CD-8's window on Mongoose Bite (unseen on it)",{
"hunter-mongoosebite","hunter-mongoosebite-alert",
})
a("CD-8's window on Counterattack (unseen on it)",{
"hunter-counterattack","hunter-counterattack-alert",
})
a("Not enough power by energy (CD-8 read on mana and rage only)",{
"rogue-ghostlystrike","rogue-kick","rogue-gouge","rogue-kidneyshot","rogue-blind","rogue-feint",
"rogue-rupture","rogue-garrote","rogue-hemorrhage","rogue-exposearmor","rogue-sap","rogue-sliceanddice",
"rogue-riposte",
"rogue-bladeflurry",
})
a("A poison read as the hand's enchant (IT-2: imbues and a stone only)",{
"rogue-mainhandpoison","rogue-offhandpoison",
})
a("The off hand's enchant (IT-2: main hand only)",{
"rogue-offhandpoison",
})
a("CD-8's window on Riposte (unseen on it)",{
"rogue-riposte","rogue-riposte-alert",
})
a("Fingers of Frost's aura: 400669 or 400670, which the client sends unrecorded",{
"mage-fingersoffrost-alert",
})
a("Heating Up at 3 stacks: whether it stacks, unseen",{
"mage-heatingup-alert",
"mage-heatingup",
})
a("CD-8's window on Hammer of Wrath (unseen on it; its flag follows the target's health, whose event is unseen)",{
"paladin-hammerofwrath","paladin-hammerofwrath-alert",
})
a("Shut while short of mana under 20% (needsPower: unseen)",{
"paladin-hammerofwrath","paladin-hammerofwrath-alert",
})
a("Eclipse at 4 stacks: whether its charges come as stacks, unseen",{
"druid-eclipse-alert",
})
a("Reagent Economy lifting its reagent (never seen taken: IT-4)",{
"mage-arcanepowder",
})

a("Another player's copy: untested",{
"druid-markofthewild","druid-markofthewild-reminder","druid-thorns","priest-fortitude","priest-divinespirit",
"mage-arcaneintellect","warrior-battleshout","warrior-battleshout-reminder","hunter-trueshotaura",
"paladin-blessing",
})






b.CAMP_ROUTE="The campfire's object counted by its hidden aura (Camp Benefits' part): unseen"
local c=c.Sources.get("aura")
local function d(a)
for b,a in ipairs(a.sources)do

if a.kind=="aura"and#c.widenedFrom(a.spells,a.unit,a.castBy~="anyone",a.exact).equivalents>0 then
return true
end
end
return false
end
for c,a in ipairs(b.premadeKeys())do
if d(b.premade(a).record)then b.markExperimental(a,b.CAMP_ROUTE)end
end


local a={


"Not enough power on the Missing icon: a tinted copy of the icon",
"Not enough power over the debuff's button (shown on a buff only)",
"Out of range and Not enough power on the Missing icon: a tinted copy of the icon",


"Water Shield's IDs (408510; 408511 kept by hand): never seen",


"Not usable without Victorious (CD-8: usable ignores some requirements)",
}
for c,a in ipairs(a)do b.routeProven(a)end
