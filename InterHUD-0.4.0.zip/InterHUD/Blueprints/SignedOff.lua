

local b,a=...
local a=a.Blueprints

local function b(b,c)
for d,c in ipairs(c)do a.signOff(c,b)end
end


b("2026-10-22, 70450",{
"shaman-shields","shaman-imbue","shaman-shocks","shaman-earthbind","shaman-flameshock","shaman-purge",
"shaman-maelstrom","shaman-elementalfocus","shaman-flurry","shaman-improvedstormstrike","shaman-curepoison",
"shaman-curedisease","shaman-waterwalking","shaman-waterbreathing","shaman-stoneclaw","shaman-firenova",
"shaman-grounding","shaman-manatide","shaman-naturesswiftness","shaman-stormstrike","shaman-farseer",
"shaman-riptide","shaman-chainlightning","shaman-projection","shaman-reincarnation",
"shaman-stormstrike-alert","shaman-elementalfocus-alert","shaman-maelstrom-alert",
})
