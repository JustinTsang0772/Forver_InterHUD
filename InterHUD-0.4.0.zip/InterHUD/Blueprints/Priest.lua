
















local b,a=...
local g=a.Blueprints
local b=g.kit


local e=b.classKit("PRIEST",{pop=false,glow=false})
local a,d,f=e.premade,e.cooldown,e.big
local c=b.colour
local h,k=b.hiddenWhileMissing,b.purge



local i="Not enough power over a by-type button"
local l="Out of range and Not enough power over a by-type button"
local m="A hostile target's Magic buff by dispel type (AU-13: documented only)"
local n="Magic as a dispel type on you (AU-13 shows poison and disease)"
local o="The reagent source (new: unplayed; IT-1 by probe)"
local p="No Ankh and Low or out as looks on a reagent's state and a custom state (never seen)"
local q=b.COUNT_ROUTE
local r="Reagent Economy lifting its reagent (never seen taken: IT-4)"
local j="Shadow Weaving's stacks: another priest's kept out (HARMFUL|PLAYER, unrecorded), and five as its top"
local s="A cooldown list of spells that share no cooldown (showing the first known: proven on shared lists only)"
local t="Another player's copy: untested"






a("shadowwordpain",b.debuff({id="shadowwordpain",name="Shadow Word: Pain",spell=589,colour=c.SHADOW,
range=true,power=true}))


a("holyfire",b.debuff({id="holyfire",name="Holy Fire",spell=14914,colour=c.HOLY,missing="hidden",
range=true,power=true}))

a("mindblast",d("mindblast","Mind Blast",8092))
a("shadowworddeath",d("shadowworddeath","Shadow Word: Death",1309595))


a("devouringplague",b.withDebuffBar(d("devouringplague","Devouring Plague",2944),
{spell=2944,name="Plague bar",colour=c.SHADOW}))
a("vampiricembrace",b.withDebuffBar(d("vampiricembrace","Vampiric Embrace",15286),
{spell=15286,name="Embrace bar",colour=c.SHADOW}))



a("shadowweaving",b.knownWith(b.atStacks(b.countFromOne(b.debuff({id="shadowweaving",
name="Shadow Weaving",spell=15258,colour=c.SHADOW,missing="hidden"})),5,{glow=false}),15257),
{experimental={j}})

a("shadowform",b.keepUp({id="shadowform",name="Shadowform",spell=15473,timed=false,quiet=true,
missingGlow=true,power=true}))


a("spirittap",b.proc("spirittap","Spirit Tap",15271,{pop=false,glow=false,knownWith=15270}))
a("darkinspiration",b.proc("darkinspiration","Dark Inspiration",1326168,{pop=false,glow=false,
knownWith=1326159}))




a("powerwordshield",b.withBuff(d("powerwordshield","Power Word: Shield",17),
{spell=17,name="Shield",time=true,barColour=c.HOLY}))
a("penance",d("penance","Penance",402174))
a("prayerofmending",d("prayerofmending","Prayer of Mending",401859))


a("innerfocus",b.withBuff(d("innerfocus","Inner Focus",14751,
{pop=true,noGcd=true}),
{spell=14751,name="Primed",glow=true,while_="primed",as="primed"}))

a("powerinfusion",f("powerinfusion","Power Infusion",10060,c.HOLY))


a("holypurpose",b.proc("holypurpose","Holy Purpose",1284536,{knownWith=14909}))


a("renewonyou",h(b.keepUp({id="renewonyou",name="Renew on You",spell=139,
colour=c.HOLY})))






a("innerfire",b.keepUp({id="innerfire",name="Inner Fire",spell=588,quiet=true,lastPercent=10,
missingGlow=true,expiringGlow=false,power=true}))

a("fortitude",b.keepUp({id="fortitude",name="Fortitude",spell={1243,21562},shows="lastSeen",
quiet=true,lastPercent=5,missingGlow=true,expiringGlow=false,power=true,castBy="anyone"}))

a("divinespirit",b.keepUp({id="divinespirit",name="Divine Spirit",spell={14752,27681},
shows="lastSeen",quiet=true,lastPercent=5,missingGlow=true,expiringGlow=false,power=true,
castBy="anyone"}))


a("shadowprotection",b.keepUp({id="shadowprotection",name="Shadow Protection",spell={976,27683},
shows="lastSeen",quiet=true,lastPercent=5,missingGlow=false,expiringGlow=false,power=true,
castBy="anyone"}),{experimental={t}})




a("candles",b.withCount(b.cooldownPremade({id="candles",name="Candles",spell=21562,readyOpacity=0}),
{items={17029,17028},reagentFor=21562,low=2,name="Candle count",
shown="Shown when low"}),
{experimental={q,o,p,r}})




a("fade",b.withBuff(d("fade","Fade",586,{glow=b.NONE}),
{spell=586,name="Fade",time=true,barColour=c.SHADOW}))


a("levitate",h(b.keepUp({id="levitate",name="Levitate",spell=1706,
colour=c.HOLY,lastPercent=20})))

a("psychicscream",b.withDebuffBar(d("psychicscream","Psychic Scream",8122,
{pop=true}),{spell=8122,name="Fear bar",colour=c.SHADOW}))

a("fearward",b.withBuff(d("fearward","Fear Ward",6346),
{spell=6346,name="Fear Ward",time=true,barColour=c.HOLY}))

a("silence",b.withDebuffBar(d("silence","Silence",15487),
{spell=15487,name="Silence bar",colour=c.SHADOW}))

b.interruptPremade(e,"silenceinterrupt","Silence interrupt",15487,{gcd=true})


a("shackleundead",b.debuff({id="shackleundead",name="Shackle Undead",spell=9484,colour=c.FROST,
missing="hidden",range=true,power=true}))


a("shadowfiend",d("shadowfiend","Shadowfiend",401977,{pop=true}))

a("curedisease",b.cure("curedisease","Cure Disease",{552,528},"disease","diseased"),
{experimental={i}})
a("curemagic",b.cure("curemagic","Dispel Magic",527,"magic","under magic"),
{experimental={i,n}})
a("dispeltarget",k({id="dispeltarget",name="Dispel Magic on Target",spell=527,dispel="magic"}),
{experimental={m,l}})





a("starshards",b.withDebuffBar(d("starshards","Starshards",10797),
{spell=10797,name="Starshards bar",colour=c.HOLY}))
a("touchofweakness",b.keepUp({id="touchofweakness",name="Touch of Weakness",spell=2652,quiet=true,
lastPercent=10,missingGlow=true,expiringGlow=false,power=true}))
a("shadowguard",b.keepUp({id="shadowguard",name="Shadowguard",spell=18137,quiet=true,
lastPercent=10,missingGlow=true,expiringGlow=false,power=true}))


a("hexofweakness",b.debuff({id="hexofweakness",name="Hex of Weakness",spell=9035,colour=c.SHADOW,
missing="hidden",range=true,power=true}))

a("desperateprayer",d("desperateprayer","Desperate Prayer",13908,{pop=true}))
a("chastise",d("chastise","Chastise",1277331,{pop=true}))

a("divinegrace",d("divinegrace","Divine Grace",1277370,{pop=true}))
a("feedback",f("feedback","Feedback",13896,c.SHADOW,{noGcd=false}))

a("elunesgrace",f("elunesgrace","Elune's Grace",2651,c.FROST,{noGcd=false}))
a("darksacrifice",f("darksacrifice","Dark Sacrifice",1277324,c.SHADOW,{noGcd=false}))

a("confoundingflash",d("confoundingflash","Confounding Flash",1277455,{pop=true,noGcd=true}))
a("contingencyplan",d("contingencyplan","Contingency Plan",1277462,{pop=true}))





b.variant(e,"shadowwordpain","bar",{unit="target",spell=589,colour=c.SHADOW,lastPercent=30})
b.variant(e,"shadowweaving","stacksTime",{form="strip",unit="target",spell=15258,knownWith=15257,
colour=c.SHADOW,icon=true,number=true,stacks=5,hidden=true})
g.markExperimental("priest-shadowweaving-strip",j)
b.variant(e,"shadowfiend","bar",{cooldown=true,spell=401977,colour=c.SHADOW})


local function c(a,c,d,e)
return b.countOn(b.keepUp({id=a,name=c,spell=d,lastPercent=e,missingGlow=true,
expiringGlow=false,power=true}),"icon","Charges")
end
a("innerfire-charges",c("innerfire-charges","Inner Fire charges",588,10),
{experimental={
"Inner Fire's charges as the buff's count (assumed as Lightning Shield's, AU-10)"}})
a("shadowguard-charges",c("shadowguard-charges","Shadowguard charges",18137,10),
{experimental={
"Shadowguard's charges as the buff's count (assumed as Lightning Shield's, AU-10)"}})


a("racecooldown",d("racecooldown","Race Cooldown",{13908,1277370,1277324,1277462},
{pop=true}),{experimental={s}})



g.registerAlerts({

{"priest-searinglight-alert","PRIEST",{id="searinglight-alert",name="Holy Purpose alert",spell=1284536,
knownWith=14909,picture="surgeOfLight"}},
})
