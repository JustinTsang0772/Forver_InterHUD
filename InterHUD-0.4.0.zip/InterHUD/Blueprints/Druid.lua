




















local b,a=...
local j=a.Blueprints
local a=j.kit


local e=a.classKit("DRUID",{pop=false,glow=false})
local b,f=e.premade,e.cooldown
local c=a.colour
local l=a.hiddenWhileMissing



local d="Not usable outside a druid's form (CD-8 shows a warrior's stance only)"
local g="Not enough power over the debuff's button (shown on a buff only)"
local h="Out of range and Not enough power on the Missing icon: a tinted copy of the icon"
local k="Not enough power on the Missing icon: a tinted copy of the icon"
local m="Not enough power by energy (CD-8 read on mana and rage only)"
local n="Not enough power over a by-type button"
local u="A Curse dispel type lighting a cure: AU-13 shows Poison and Disease only"
local o="Eclipse at 4 stacks: whether its charges come as stacks, unseen"
local p="The reagent source (new: unplayed; IT-1 by probe)"
local q="No Ankh and Low or out as looks on a reagent's state and a custom state (never seen)"
local r="Reagent Economy lifting its reagent (never seen taken: IT-4)"
local v="An item's count carried by a spell with no cooldown (CD-3, IT-1): it only ever reads Ready"
local w="A druid form's own aura read in combat (EP-20: no form read yet)"
local x="Shifting Power costs mana while Cat Form shows energy: Not enough power in that form unread (EP-20)"
local y="Feral Charge read in Cat Form, where an override turns it into the leap 414924 (unread)"
local s="Lacerate's five stacks: by the aura data only, no run (AU-38 shows Sunder Armor's)"
local t="The reagent read is the best item carried, not the one your rank takes (each rank takes its own)"



local function i(d,e,c,g,h,b)
b=b or{}
local d=f(d,e,c,{pop=true,noGcd=b.noGcd})
return a.withBuff(d,{spell=b.buff or c,name=g,time=true,barColour=h})
end




b("moonfire",a.debuff({id="moonfire",name="Moonfire",spell=8921,colour=c.ARCANE,range=true,
power=true}),{experimental={g,h}})
b("insectswarm",a.debuff({id="insectswarm",name="Insect Swarm",spell=5570,colour=c.NATURE,
range=true,power=true}),{experimental={g,h}})
b("faeriefire",a.debuff({id="faeriefire",name="Faerie Fire",spell=770,colour=c.NATURE,range=true,
power=true}),{experimental={g,h}})



b("eclipse",a.atStacks(a.countFromOne(a.proc("eclipse","Eclipse",408255,{pop=false,glow=false,
knownWith=408248})),4),
{experimental={o}})

b("naturesgrace",a.proc("naturesgrace","Nature's Grace",16886,{pop=false,glow=false,
knownWith=16880}))


b("moonkinform",a.onlyInCombat(a.keepUp({id="moonkinform",name="Moonkin Form",spell=24858,
timed=false,quiet=true,missingGlow=false,power=true})),{experimental={w,k}})


b("rake",a.debuff({id="rake",name="Rake",spell=1822,colour=c.BLOOD,range=true,power=true}),
{experimental={m,g,h}})
b("rip",a.debuff({id="rip",name="Rip",spell=1079,colour=c.BLEED,range=true,power=true}),
{experimental={m,g,h}})


b("pouncebleed",a.knownWith(a.debuff({id="pouncebleed",name="Pounce Bleed",spell=9007,
colour=c.BLEED,missing="hidden"}),9005))

b("shiftingpower",f("shiftingpower","Shifting Power",1322605),
{experimental={d,x}})

b("dash",i("dash","Dash",1850,"Dash",c.NATURE,{noGcd=true}),
{experimental={d}})



b("demoralizingroar",a.debuff({id="demoralizingroar",name="Demoralizing Roar",spell=99,
colour=c.EARTH,power=true}),{experimental={g,k}})
b("lacerate",a.atStacks(a.countFromOne(a.debuff({id="lacerate",name="Lacerate",spell=1328617,
colour=c.BLEED,range=true,power=true})),5,{glow=false}),
{experimental={g,h,s}})


b("bash",a.withDebuffBar(f("bash","Bash",5211,{pop=true}),
{spell=5211,name="Stun bar",colour=c.PHYSICAL}),{experimental={d}})

a.interruptPremade(e,"bashinterrupt","Bash interrupt",5211,{gcd=true},{d})
b("feralcharge",a.withDebuffBar(f("feralcharge","Feral Charge",1238122,{noGcd=true}),
{spell=19675,name="Root bar",colour=c.NATURE}),{experimental={d,y}})
b("growl",f("growl","Growl",6795,{noGcd=true}),{experimental={d}})


a.threatPremade(e,"growlthreat","Growl with threat",6795,{},{d})

b("challengingroar",f("challengingroar","Challenging Roar",5209,{pop=true}),
{experimental={d}})
b("primalbite",f("primalbite","Primal Bite",407995),{experimental={d}})
b("enrage",i("enrage","Enrage",5229,"Enrage",c.FIRE,{noGcd=true}),
{experimental={d}})
b("frenziedregeneration",i("frenziedregeneration","Frenzied Regeneration",22842,"Frenzied Regeneration",
c.NATURE),{experimental={d}})

b("barkskin",i("barkskin","Barkskin",22812,"Barkskin",c.EARTH))


b("swiftmend",f("swiftmend","Swiftmend",18562),{experimental={d}})
b("wildgrowth",f("wildgrowth","Wild Growth",408120),{experimental={d}})


b("naturesswiftness",a.withBuff(f("naturesswiftness","Nature's Swiftness",17116,
{pop=true,noGcd=true}),
{spell=17116,name="Primed",glow=true,while_="primed",as="primed"}),
{experimental={d}})

b("tranquility",i("tranquility","Tranquility",740,"Channel",c.NATURE),{experimental={d}})
b("innervate",i("innervate","Innervate",29166,"Innervate",c.WATER),{experimental={d}})

b("rebirth",f("rebirth","Rebirth",20484,{readyOpacity=30}),{experimental={d}})

b("rejuvenationself",l(a.keepUp({id="rejuvenationself",name="Rejuvenation on You",
spell=774,colour=c.NATURE})))
b("regrowthself",l(a.keepUp({id="regrowthself",name="Regrowth on You",spell=8936,
colour=c.NATURE})))


b("clearcasting",a.knownWith(a.extras(j.layout("icon").build({id="clearcasting",name="Clearcasting",
spell=16870,hidden=true}),{pop=true,glow=true}),16864),{layout="icon"})


b("markofthewild",a.keepUp({id="markofthewild",name="Mark of the Wild",spell={1126,21849},
shows="lastSeen",quiet=true,missingGlow=true,expiringGlow=false,lastPercent=5,power=true,
castBy="anyone"}),{experimental={k}})
b("thorns",a.keepUp({id="thorns",name="Thorns",spell=467,quiet=true,missingGlow=false,
expiringGlow=false,lastPercent=5,power=true,castBy="anyone"}),{experimental={k}})

b("naturesgrasp",a.withBuff(f("naturesgrasp","Nature's Grasp",16689),
{spell=16689,name="Grasp on you",time=true,barColour=c.NATURE}))


b("entanglingroots",a.debuff({id="entanglingroots",name="Entangling Roots",spell=339,colour=c.NATURE,
missing="hidden",range=true,power=true}),{experimental={g}})
b("hibernate",a.debuff({id="hibernate",name="Hibernate",spell=2637,colour=c.NATURE,
missing="hidden",range=true,power=true}),{experimental={g}})


b("curepoison",a.cure("curepoison","Cure Poison",{2893,8946},"poison","poisoned"),
{experimental={n}})
b("removecurse",a.cure("removecurse","Remove Curse",2782,"curse","cursed"),
{experimental={n,u}})





local d={17038,17037,17036,17035,17034}
e.premade("rebirth-seeds",a.withCount(f("rebirth-seeds","Rebirth with seeds",20484,
{readyOpacity=30}),{items=d,reagentFor=20484,low=2,name="Seed count",
shown="Shown when low"}),
{experimental={p,q,r,t}})
b("giftreagent",a.withCount(a.cooldownPremade({id="giftreagent",name="Gift of the Wild reagent",
spell=21849,readyOpacity=0}),{items={17026,17021},reagentFor=21849,low=2,name="Reagent count",
shown="Shown when low"}),
{experimental={v,p,q,r,t}})


a.variant(e,"faeriefire","bar",{unit="target",spell=770,colour=c.NATURE})
a.variant(e,"lacerate","stacksTime",{form="strip",unit="target",spell=1328617,colour=c.BLEED,stacks=5,icon=true,
number=true})
a.variant(e,"eclipse","stacksTime",{form="strip",spell=408255,knownWith=408248,colour=c.ARCANE,stacks=4,
icon=true,number=true})
j.markExperimental("druid-lacerate-strip",s)
j.markExperimental("druid-eclipse-strip",o)
a.variant(e,"markofthewild","icon",{form="reminder",spell={1126,21849},shows="lastSeen",lastPercent=5})
a.variant(e,"rebirth","bar",{cooldown=true,spell=20484,colour=c.NATURE})
a.variant(e,"rake","icon",{form="mark",unit="target",spell=1822,colour=c.BLOOD})

a.variant(e,"clearcasting","words",{spell=16870,knownWith=16864,when="present"})
a.variant(e,"clearcasting","bar",{spell=16870,knownWith=16864,colour=c.ARCANE,hidden=true})


local a=a.art.OUTER
j.registerAlerts({

{"druid-omenofclarity-alert","DRUID",{id="omenofclarity-alert",name="Omen of Clarity alert",spell=16870,
knownWith=16864,picture="omenOfClarity"}},
{"druid-eclipse-alert","DRUID",{id="eclipse-alert",name="Eclipse alert",spell=408255,
knownWith=408248,picture="eclipseMoon",spread=a,stacks=4}},
})
