








local a,d=...
local b=d.Blueprints
local a=b.kit
local c,j,h,f=a.cooldownPremade,a.withBuff,a.proc,a.onEvent

local k="#ff3333"
local e={ring=true,ringColour=k}








b.registerPremade("shaman-shields",{
label="Shields",class="SHAMAN",
record={
id="shields",name="Shields",
sources={
{id="buff",kind="aura",unit="player",spells={324,408510},shownSpell="lastSeen",
facts={expiring={{id="last",share=10}},stacks={{id="charged",atLeast=2}}},
layers={
{id="icon",kind="icon",
count={enabled=false,fromOne=true},time={enabled=false},
glows={
{id="missing-glow",name="Glow with no shield",style={kind="halo",colour="#ff4040"}},
{id="expiring-glow",name="Glow in its last minute"},
},
looks={
{["while"]="missing",desaturated=true,border=e,
glows={["missing-glow"]={shown=true}}},
{["while"]="spell.notEnoughPower"},

{["while"]={"missing","spell.notEnoughPower"},border=e},
{["while"]="charged",opacity=30},
{["while"]="last",opacity=100,glows={["expiring-glow"]={shown=true}}},
}},

{id="charges",kind="bar",name="Charge bar",value="stacks",segments=3,thickness=12,
position={point="TOP",toPoint="BOTTOM",x=0,y=0},colour="#6bd6ff",
background={colour="#00000099"},border={style={kind="line",thickness=1}},
looks={{["while"]="missing",shown=false},{["while"]="charged",opacity=30},
{["while"]="last",opacity=100}}},
}},
{id="spell",kind="spell",spells={324,408510},shownSpell="lastCast"},
},
quick={
{label="Shield whose icon shows with none up",part="buff",field="shownSpell"},
{section="Charges",rows={
{label="Charge bar",part="charges",field="enabled"},
{label="Charge number",part="icon",field="count.enabled"},
{label="Icon and charge bar at two or more charges",choices={
{label="Dimmed",writes={{part="icon",look="charged",field="opacity",value=30},
{part="charges",look="charged",field="opacity",value=30}}},
{label="Full",writes={{part="icon",look="charged",field="opacity",clear=true},
{part="charges",look="charged",field="opacity",clear=true}}},
}},
}},
{section="With no shield",rows={
{label="Icon with no shield up",choices={
{label="Greyed, with a red ring",writes={{part="icon",look="missing",field="shown",clear=true}}},
{label="Hidden",writes={{part="icon",look="missing",field="shown",value=false}}},
}},
{label="Glow with no shield",part="missing-glow",field="enabled"},
}},
{section="Last minute",rows={
{label="Glow in its last minute",part="expiring-glow",field="enabled"},
}},
},
},
})








b.registerPremade("shaman-imbue",{
label="Weapon Imbue",class="SHAMAN",
record={
id="imbue",name="Weapon Imbue",
sources={
{id="enchant",kind="weaponEnchant",spells={8017,8024,8033,8232},shownSpell="lastSeen",
facts={expiring={{id="expiring",seconds=300}}},
layers={
{id="icon",kind="icon",sweep={enabled=false},
glows={
{id="missing-glow",name="Glow with no imbue"},
{id="expiring-glow",name="Glow while Expiring",enabled=false},
},
looks={
{["while"]="present",shown=false},
{["while"]="missing",desaturated=true,border=e,
glows={["missing-glow"]={shown=true}}},
{["while"]="expiring",shown=true,glows={["expiring-glow"]={shown=true}}},
}},
},
events={removed={effects={{id="removed-pop",kind="pop",style={colour="#59a6ff"}}}}}},
},
quick={
{label="Icon with no imbue",part="enchant",field="shownSpell"},
{label="Icon while an imbue is on",choices={
{label="Only in its last 5 minutes",writes={{part="icon",look="present",field="shown",value=false}}},
{label="Always",writes={{part="icon",look="present",field="shown",clear=true}}},
}},
{section="With none on",rows={
{label="Glow with no imbue",part="missing-glow",field="enabled"},
{label="Pop when it goes",part="removed-pop",field="enabled"},
}},
{section="Last 5 minutes",rows={
{label="Glow while Expiring",part="expiring-glow",field="enabled"},
}},
},
},
})







local function g(a,b,c,d,e)
return{id=a,kind="aura",unit="target",spells={c},
layers={{id=a.."-mark",kind="icon",name=b,width=18,height=18,
position={point=d,toPoint=e,x=0,y=2},time={enabled=false},
count={enabled=false},border={style={kind="line",thickness=1}},
looks={{["while"]="missing",shown=false}}}}}
end
b.registerPremade("shaman-shocks",{
label="Shocks",class="SHAMAN",
record={
id="shocks",name="Shocks",
sources={
{id="spell",kind="spell",spells={8042,8050,8056},
layers={
{id="icon",kind="icon",name="Shock",
glows={{id="ready-glow",name="Ready glow",enabled=false}},
looks={{["while"]="ready",glows={["ready-glow"]={shown=true}}}}},
},
events={comesReady={effects={{id="ready-pop",kind="pop"}}}}},
g("frost","Frost Shock mark",8056,"BOTTOMLEFT","TOPLEFT"),
g("flame","Flame Shock mark",8050,"BOTTOMRIGHT","TOPRIGHT"),
},
quick={
{label="Shock shown",part="spell",field="shownSpell"},
{label="GCD sweep",part="icon",field="gcdSweep.enabled"},
{section="Marks on the target",rows={
{label="Frost Shock mark",part="frost",field="enabled"},
{label="Flame Shock mark",part="flame",field="enabled"},
}},
{section="Ready",rows={
{label="Ready pop",part="ready-pop",field="enabled"},
{label="Ready glow",part="ready-glow",field="enabled"},
}},
},
},
})






local l={id="expiring-pulse",name="Pulse in its last seconds",style={kind="darkPulse"}}
local function g(a)
local b={id="spell",kind="spell",spells={a.spell},
layers={{id="icon",kind="icon",name="Icon",glows={d.copy(l)},
looks={{["while"]="totem.expiring",glows={["expiring-pulse"]={shown=true}}}}}}}
f(b,"comesReady",{id="ready-pop",kind="pop"})
local d={id="totem",kind="totem",slot=a.slot,spells={a.spell},
facts={expiring={{id="expiring",seconds=a.last}}},
layers={{id="bar",kind="bar",name="Totem time",thickness=8,
position={point="TOP",toPoint="BOTTOM",x=0,y=0},colour=a.bar,
looks={{["while"]="empty",shown=false}}}}}
f(d,"killedEarly",{id="killed-flash",kind="flash",over={"icon"},
style={kind="plain",colour=a.early.colour}})
local c={id=a.id,name=a.name,sources={b,d},
quick={{label="Ready pop",part="ready-pop",field="enabled"}}}
if a.dims then
c.customStates={{id="ready-no-totem",name="Ready, no totem down",all={"spell.ready"},
none={"totem.down"}}}
table.insert(b.layers[1].looks,1,{["while"]="ready-no-totem",opacity=30})
c.quick[#c.quick+1]={label="Dim at Ready with no totem down",part="ready-no-totem",field="enabled"}
end

local b={}
c.quick[#c.quick+1]={section="Totem",rows=b}
b[#b+1]={label="Totem duration bar",part="bar",field="enabled"}
b[#b+1]={label="Flash when it ends early",part="killed-flash",field="enabled"}
if a.early.pop then
f(d,"killedEarly",{id="killed-pop",kind="pop",over={"icon"},
style={colour=a.early.colour}})
b[#b+1]={label="Pop when it ends early",part="killed-pop",field="enabled"}
end
if a.ranOut then
f(d,"ranOut",{id="ranout-flash",kind="flash",over={"icon"},
style={kind="plain",colour=a.ranOut}})
b[#b+1]={label="Flash when it runs out",part="ranout-flash",field="enabled"}
else
f(d,"ranOut",{id="ranout-pop",kind="pop",over={"icon"},style={colour="#f2f2f2"}})
b[#b+1]={label="Pop when it runs out",part="ranout-pop",field="enabled"}
end
return c
end










b.registerPremade("shaman-earthbind",{
label="Earthbind Totem",class="SHAMAN",
record=g({id="earthbind",name="Earthbind Totem",spell=2484,slot="earth",bar="#dc9e46",
dims=true,early={colour="#ff2014",pop=true},last=5}),
})









b.registerPremade("shaman-flameshock",{
label="Flame Shock",class="SHAMAN",
record={
id="flameshock",name="Flame Shock",
sources={
{id="debuff",kind="aura",unit="target",spells={8050},
facts={expiring={{id="expiring",share=30}}},
layers={
{id="icon",kind="icon",sweep={enabled=false},count={enabled=false},
glows={{id="missing-glow",name="Glow while not on target",style={kind="soft"}}},
looks={
{["while"]="missing",desaturated=true,glows={["missing-glow"]={shown=true}}},
{["while"]="spell.notEnoughPower"},
{["while"]="spell.outOfRange"},
}},
{id="bar",kind="bar",name="Time bar",thickness=8,
position={point="TOP",toPoint="BOTTOM",x=0,y=0},colour="#ff6f35",
looks={{["while"]="missing",shown=false},{["while"]="expiring",colour="#ff33cc"}}},
}},
{id="spell",kind="spell",spells={8050},shownSpell="lastCast"},
},
quick={
{section="On the target",rows={
{label="Time bar",part="bar",field="enabled"},
{label="Duration numbers",part="icon",field="time.enabled"},
}},
{section="Not on the target",rows={
{label="Icon when Flame Shock is not on the target",choices={
{label="Greyed",writes={{part="icon",look="missing",field="shown",clear=true}}},
{label="Hidden",writes={{part="icon",look="missing",field="shown",value=false}}},
}},
{label="Glow while not on target",part="missing-glow",field="enabled"},
}},
},
},
})






b.registerPremade("shaman-purge",{
label="Purge",class="SHAMAN",
record={
id="purge",name="Purge",
sources={
{id="dispel",kind="dispel",unit="target",spells={370},types={"magic"},
layers={

{id="icon",kind="icon",sweep={enabled=false},time={enabled=false},count={enabled=false},
glows={{id="glow",name="Glow while it has one",shown=true,style={kind="proc"}}},
looks={
{["while"]="missing",shown=false},
{["while"]="spell.notEnoughPower"},
{["while"]="spell.outOfRange"},
}},
}},
{id="spell",kind="spell",spells={370},shownSpell="lastCast"},
},
quick={
{label="Glow while it has one",part="glow",field="enabled"},
{label="Skip long buffs",part="dispel",field="skipLong"},

{label="Skip buffs longer than",part="dispel",field="longest"},
},
},
})






b.registerPremade("shaman-maelstrom",{
label="Maelstrom Weapon",class="SHAMAN",
record={
id="maelstrom",name="Maelstrom Weapon",
sources={
{id="buff",kind="aura",unit="player",spells={408505},
facts={stacks={{id="atStacks",atLeast=5}}},
layers={

{id="icon",kind="icon",count={enabled=false},time={enabled=false,shown=false},
glows={{id="five-glow",name="Glow at five"}},
looks={{["while"]="missing",shown=false},
{["while"]="atStacks",glows={["five-glow"]={shown=true}}}}},
{id="stacks",kind="bar",name="Stack bar",value="stacks",segments=5,thickness=12,
position={point="TOP",toPoint="BOTTOM",x=0,y=0},colour="#85b0ff",
background={colour="#00000099"},looks={{["while"]="missing",shown=false}}},
{id="number",kind="text",name="Stack number",enabled=false,content="stacks",fromOne=true,
fontSize=18,position={point="CENTER",toPoint="CENTER",x=0,y=0},
looks={{["while"]="missing",shown=false},{["while"]="atStacks",colour="#ffd100"}}},
}},
},

onlyWhileYouKnow={408498},
quick={
{label="Stack bar",part="stacks",field="enabled"},
{label="Stack number",part="number",field="enabled"},
{label="Glow at five",part="five-glow",field="enabled"},
},
},
})



b.registerPremade("shaman-elementalfocus",{
label="Elemental Focus",class="SHAMAN",
record=h("elementalfocus","Elemental Focus",16246,{knownWith=16164}),
})




local i=h("flurry","Flurry",16257,{pop=false,glow=false,knownWith=16256})
local m=i.sources[1].layers
m[2]={id="charges",kind="bar",name="Charge bar",enabled=false,value="stacks",segments=3,
thickness=12,position={point="TOP",toPoint="BOTTOM",x=0,y=0},colour="#ffffff",
background={colour="#00000099"},looks={{["while"]="missing",shown=false}}}
m[3]={id="number",kind="text",name="Charge number",content="stacks",fromOne=true,
fontSize=18,position={point="CENTER",toPoint="CENTER",x=0,y=0},
looks={{["while"]="missing",shown=false}}}
table.insert(i.quick,1,{label="Charge number",part="number",field="enabled"})
table.insert(i.quick,2,{label="Charge bar",part="charges",field="enabled"})
b.registerPremade("shaman-flurry",{label="Flurry",class="SHAMAN",record=i})


b.registerPremade("shaman-improvedstormstrike",{
label="Improved Stormstrike",class="SHAMAN",
record=h("improvedstormstrike","Improved Stormstrike",1238931,{pop=false,glow=false,
knownWith=1223031}),
})


b.registerPremade("shaman-curepoison",{label="Cure Poison",class="SHAMAN",
record=a.cure("curepoison","Cure Poison",526,"poison","poisoned")})
b.registerPremade("shaman-curedisease",{label="Cure Disease",class="SHAMAN",
record=a.cure("curedisease","Cure Disease",2870,"disease","diseased")})


















local function i(a,b,d,c,f)
local g={id="buff",kind="aura",unit="player",spells={d},
facts={expiring={{id="expiring",share=5}}},
layers={
{id="icon",kind="icon",name="Icon",sweep={enabled=false},count={enabled=false},
looks={
{["while"]="missing",shown=false},
{["while"]="spell.notEnoughPower"},
{["while"]="running-low",shown=true},
{["while"]={"running-low","reagent.none"},border=e},
}},
{id="bar",kind="bar",name="Time bar",thickness=8,
position={point="TOP",toPoint="BOTTOM",x=0,y=0},colour="#49cae2",
looks={{["while"]="missing",shown=false},{["while"]="expiring",colour=k}}},
}}
local a={
id=a,name=b,
sources={g,{id="spell",kind="spell",spells={d},shownSpell="lastCast"}},
customStates={{id="running-low",name="Low or out",all={"buff.missing"},
any={"reagent.low","reagent.none"}}},
quick={
{section="While it's up",rows={
{label="Time bar",part="bar",field="enabled"},
{label="Duration numbers",part="icon",field="time.enabled"},
}},
{section="Reagent",rows={
{label=c.label.." on the icon",part="reagent",field="enabled"},
{label="Show the icon when "..c.name.." runs low or out",part="running-low",field="enabled"},
}},
},
}
local b={}
if f then
a.quick[#a.quick+1]={section="Under water",rows=b}
a.sources[#a.sources+1]={id="breath",kind="breath",
layers={{id="breath-icon",kind="icon",name="Under water",sweep={enabled=false},
time={enabled=false},glows={{id="breath-glow",name="Glow under water",shown=true}},
looks={{["while"]="draining",border=e},{["while"]="notDraining",shown=false}}}}}
b[#b+1]={label="Warning while your breath drains",part="breath",field="enabled"}
b[#b+1]={label="Glow on the warning",part="breath-glow",field="enabled"}
end

a.sources[#a.sources+1]={id="reagent",kind="reagent",items={c.item},reagentFor=d,
layers={{id="reagent-count",kind="text",name=c.label,fontSize=11,
position={point="BOTTOMRIGHT",toPoint="BOTTOMRIGHT",x=-1,y=1},
looks={{["while"]="present",unless="low",shown=false}}}}}
return a
end

local k={reagent={state="present",facts={low=true}}}
b.registerPremade("shaman-waterwalking",{label="Water Walking",class="SHAMAN",preview=k,
record=i("waterwalking","Water Walking",546,{item=17058,name="Fish Oil",label="Fish Oil count"})})
b.registerPremade("shaman-waterbreathing",{label="Water Breathing",class="SHAMAN",preview=k,
record=i("waterbreathing","Water Breathing",131,{item=17057,name="Shiny Fish Scales",
label="Shiny Fish Scales count"},true)})



b.registerPremade("shaman-stoneclaw",{
label="Stoneclaw Totem",class="SHAMAN",
record=g({id="stoneclaw",name="Stoneclaw Totem",spell=5730,slot="earth",bar="#dc9e46",
dims=true,early={colour="#ff2014",pop=true},last=5}),
})








local i={
id="firenova",name="Fire Nova",
sources={
{id="spell",kind="spell",spells={408341},
layers={
{id="icon",kind="icon",name="Icon",
glows={{id="ready-glow",name="Ready glow",enabled=false}},
looks={
{["while"]="no-fire-totem",desaturated=true},
{["while"]={"ready","totem.down"},glows={["ready-glow"]={shown=true}}},
}},
},
events={comesReady={effects={{id="ready-pop",kind="pop"}}}}},
{id="totem",kind="totem",slot="fire",
layers={
{id="bar",kind="bar",name="Fire totem's time",thickness=8,
position={point="TOP",toPoint="BOTTOM",x=0,y=0},colour="#ff6f35",
looks={{["while"]="empty",shown=false}}},
{id="countdown",kind="text",name="Fire totem's countdown",fontSize=10,
position={point="TOPLEFT",toPoint="TOPLEFT",x=2,y=-2},
looks={{["while"]="empty",shown=false}}},
}},
},
customStates={{id="no-fire-totem",name="No fire totem",none={"totem.down"}}},
quick={
{label="Ready pop",part="ready-pop",field="enabled"},
{label="Ready glow, only with a fire totem down",part="ready-glow",field="enabled"},
{label="Icon greyed with no fire totem down",part="no-fire-totem",field="enabled"},
{section="Fire totem",rows={
{label="Fire totem's duration bar",part="bar",field="enabled"},
{label="Fire totem's countdown numbers",part="countdown",field="enabled"},
}},
},
}
b.registerPremade("shaman-firenova",{label="Fire Nova",class="SHAMAN",record=i})





b.registerPremade("shaman-grounding",{
label="Grounding Totem",class="SHAMAN",
record=g({id="grounding",name="Grounding Totem",spell=8177,slot="air",bar="#a4dfff",
dims=true,early={colour="#8fc2eb",pop=true},ranOut="#8fc2eb",last=5}),
})





b.registerPremade("shaman-manatide",{
label="Mana Tide Totem",class="SHAMAN",
record=g({id="manatide",name="Mana Tide Totem",spell=16190,slot="water",bar="#49cae2",
early={colour="#ff2014"},ranOut="#40b0c4",last=3}),
})




b.registerPremade("shaman-naturesswiftness",{
label="Nature's Swiftness",class="SHAMAN",
record=j(c({id="naturesswiftness",name="Nature's Swiftness",spell=16188,pop=true,
noGcd=true}),
{spell=16188,name="Primed",glow=true,while_="primed",as="primed"}),
})










local g=c({id="stormstrike",name="Stormstrike",spell=17364,pop=true,glow=true})
f(g.sources[1],"reset",
{id="reset-pop",kind="pop",
style={flash="edge",burst="both",motion="bounce",colour="#8cd9ff",size=1.8,reach=1.3}},
{id="reset-words",kind="text",text="Stormstrike!",colour="#ffd100",fontSize=16})
g.sources[2]={id="debuff",kind="aura",unit="target",spells={17364},
layers={{id="debuff-bar",kind="bar",name="Debuff time",thickness=8,
position={point="TOP",toPoint="BOTTOM",x=0,y=0},colour="#a4dfff",
looks={{["while"]="missing",shown=false}}}}}
g.sources[3]={id="improved",kind="aura",unit="player",spells={1238931},enabled=false,
layers={{id="improved-bar",kind="bar",name="Improved Stormstrike time",thickness=8,
position={point="BOTTOM",toPoint="TOP",x=0,y=0},colour="#49cae2",
looks={{["while"]="missing",shown=false}}}}}
g.quick={
{label="GCD sweep",part="icon",field="gcdSweep.enabled"},
{section="Ready",rows={
{label="Ready pop",part="ready-pop",field="enabled"},
{label="Ready glow",part="ready-glow",field="enabled"},
b.readyChoice(),
}},
{section="At a reset",rows={
{label="Pop at a reset",part="reset-pop",field="enabled"},
{label="\"Stormstrike!\" words at a reset",part="reset-words",field="enabled"},
}},
{section="Bars",rows={
{label="Stormstrike debuff bar, on the target",part="debuff",field="enabled"},
{label="Improved Stormstrike mana buff bar",part="improved",field="enabled"},
}},
}
b.registerPremade("shaman-stormstrike",{label="Stormstrike",class="SHAMAN",record=g})




b.registerPremade("shaman-farseer",{
label="Rage of the Farseer",class="SHAMAN",
record=j(c({id="farseer",name="Rage of the Farseer",spell=425336,pop=true,noGcd=true,
glow=false}),{spell=425336,barOnly=true,barColour="#a4dfff"}),
})











b.registerPremade("shaman-riptide",{label="Riptide",class="SHAMAN",
record=c({id="riptide",name="Riptide",spell=408521,pop=true,glow=false})})
b.registerPremade("shaman-chainlightning",{label="Chain Lightning",class="SHAMAN",
record=c({id="chainlightning",name="Chain Lightning",spell=421,pop=true,glow=true})})
b.registerPremade("shaman-projection",{label="Totemic Call",class="SHAMAN",
record=c({id="projection",name="Totemic Call",spell=437009,pop=true,
readyOpacity=30})})
local c=c({id="reincarnation",name="Reincarnation",spell=21169,noGcd=true})
local g=c.sources[1].layers[1]

g.looks=g.looks or{}
g.looks[#g.looks+1]={["while"]="running-low",border=e}
c.sources[2]={id="reagent",kind="reagent",items={17030},reagentFor=21169,
layers={{id="reagent-count",kind="text",name="Ankh count",fontSize=11,
position={point="BOTTOMRIGHT",toPoint="BOTTOMRIGHT",x=-1,y=1}}}}
c.customStates={{id="running-low",name="Low or out",any={"reagent.low","reagent.none"}}}
c.quick[#c.quick+1]={section="Ankhs",rows={
{label="Ankh count on the icon",part="reagent",field="enabled"},
{label="Red ring when Ankhs are low or out",part="running-low",field="enabled"},
}}
b.registerPremade("shaman-reincarnation",{label="Reincarnation",class="SHAMAN",record=c})


local i=a.classKit("SHAMAN",{pop=false,glow=false})
local e,j=i.premade,i.cooldown
local c=a.colour


local g="A totem as an element's only source: proven beside a cooldown (Earthbind, Stoneclaw)"



e("frostshock",a.debuff({id="frostshock",name="Frost Shock",spell=8056,colour=c.FROST,
lastPercent=30,missing="hidden"}))


a.interruptPremade(i,"earthshockinterrupt","Earth Shock interrupt",{8042,8050,8056},{gcd=true})



e("elementalmastery",a.extras(b.layout("iconBar").build({id="elementalmastery",name="Lightning Mastery",
spell=16166,cooldown=true,with={spell=16166},colour=c.NATURE,barAt="below"}),{pop=true,glow=false}),
{layout="iconBar"})


e("astralrecall",j("astralrecall","Astral Recall",556,{pop=true}))




e("elementaldevastation",h("elementaldevastation","Elemental Devastation",30165,{pop=false,
glow=false,knownWith=30160}))





local function h(a)
local b={id="totem",kind="totem",slot=a.slot,
facts={expiring={{id="expiring",seconds=a.last}}},
layers={
{id="icon",kind="icon",name="Icon",glows={d.copy(l)},
looks={{["while"]="empty",shown=false},
{["while"]="expiring",glows={["expiring-pulse"]={shown=true}}}}},
{id="bar",kind="bar",name="Totem time",thickness=8,
position={point="TOP",toPoint="BOTTOM",x=0,y=0},colour=a.bar,
looks={{["while"]="empty",shown=false}}},
}}
f(b,"killedEarly",{id="killed-flash",kind="flash",over={"icon"},
style={kind="plain",colour=c.ALARM}})
f(b,"ranOut",{id="ranout-pop",kind="pop",over={"icon"},style={colour="#f2f2f2"}})
return{
id=a.id,name=a.name,sources={b},
quick={
{label="Totem duration bar",part="bar",field="enabled"},
{label="Duration numbers",part="icon",field="time.enabled"},
{label="Flash when it ends early",part="killed-flash",field="enabled"},
{label="Pop when it runs out",part="ranout-pop",field="enabled"},
},
}
end
e("firetotem",h({id="firetotem",name="Fire Totem",slot="fire",bar=c.FIRE,last=10}),
{experimental={g}})
e("earthtotem",h({id="earthtotem",name="Earth Totem",slot="earth",bar=c.EARTH,last=10}),
{experimental={g}})
e("watertotem",h({id="watertotem",name="Water Totem",slot="water",bar=c.WATER,last=10}),
{experimental={g}})
e("airtotem",h({id="airtotem",name="Air Totem",slot="air",bar=c.FROST,last=10}),
{experimental={g}})








local g="Another player's copy: untested"
local function f(e,c,f,h,d)
local f=a.knownWith(a.onlyInCombat(a.keepUp({id=e,name=c,spell=f,timed=false,quiet=true,
missingGlow=false,castBy="anyone"})),h)
local a={g}
if d then
a[2]=c.."'s buff IDs"..(d==true and""or" "..d).." (the table's): never seen on you"
end
b.registerPremade("shaman-"..e,{label=c,class="SHAMAN",record=f,experimental=a})
end
f("strengthofearth","Strength of Earth Totem",8076,8075,"past rank 1")
f("graceofair","Grace of Air Totem",8836,8835,true)
f("windfurytotem","Windfury Totem",8515,8512,true)
f("manaspring","Mana Spring Totem",5677,5675,"past rank 1")



e("frostbrand",a.knownWith(a.debuff({id="frostbrand",name="Frostbrand Attack",spell=8034,
colour=c.FROST,lastPercent=30,missing="hidden"}),8033),
{experimental={"A table-linked debuff ID no run has seen"}})


local f,g,e=a.art.FROST,a.art.OUTER,a.art.ABOVE
b.registerAlerts({

{"shaman-stormstrike-alert","SHAMAN",{id="stormstrike-alert",name="Stormstrike alert",spell=17364,
picture="fulmination",arrangement="one",spread=315,afterReset=5}},
{"shaman-elementalfocus-alert","SHAMAN",{id="elementalfocus-alert",name="Elemental Focus alert",
spell=16246,knownWith=16164,picture="genericArc2",spread=g,colour=f}},
{"shaman-maelstrom-alert","SHAMAN",{id="maelstrom-alert",name="Maelstrom Weapon alert",spell=408505,
knownWith=408498,picture="maelstromWeapon",above=e,stacks=5}},
})


local b=a.classKit("SHAMAN")
a.variant(b,"flameshock","bar",{unit="target",spell=8050,colour=a.colour.FIRE,lastPercent=30})
a.variant(b,"flameshock","icon",{form="mark",unit="target",spell=8050,colour=a.colour.FIRE,lastPercent=30})
a.variant(b,"maelstrom","stacksTime",{form="strip",spell=408505,knownWith=408498,colour="#85b0ff",
icon=true,number=true})
a.variant(b,"shields","icon",{form="reminder",spell={324,408510},shows="lastSeen",lastPercent=10})

a.variant(b,"naturesswiftness","bar",{cooldown=true,spell=16188,colour=c.NATURE})
a.variant(b,"manatide","bar",{cooldown=true,spell=16190,colour=c.WATER})
a.variant(b,"farseer","bar",{spell=425336,colour=c.FROST,hidden=true,lastPercent=20})
a.variant(b,"stormstrike","bar",{unit="target",spell=17364,colour=c.FROST,hidden=true,
lastPercent=20})
a.variant(b,"flurry","stacksTime",{form="strip",spell=16257,knownWith=16256,stacks=3,colour=c.FROST,
icon=true,number=true})

a.variant(b,"elementalfocus","words",{spell=16246,knownWith=16164,when="present"})
a.variant(b,"elementalfocus","bar",{spell=16246,knownWith=16164,colour=c.FROST,hidden=true})
a.variant(b,"flameshock","barAlone",{unit="target",spell=8050,colour=c.FIRE,lastPercent=30})
a.variant(b,"flameshock","thinBar",{unit="target",spell=8050,colour=c.FIRE,lastPercent=30})
local e={cooldown=true,spell=16166,with={spell=16166},colour=c.NATURE}
a.variant(b,"elementalmastery","twinBars",d.copy(e))
a.variant(b,"elementalmastery","oneBar",d.copy(e))
a.variant(b,"elementalmastery","bar",d.copy(e))
local e={cooldown=true,spell=2484,with={kind="totem",slot="earth",spell=2484},colour=c.EARTH}
a.variant(b,"earthbind","iconBar",d.copy(e))
a.variant(b,"earthbind","twinBars",d.copy(e))
a.variant(b,"earthbind","bar",d.copy(e))
local e={cooldown=true,spell=16190,with={kind="totem",slot="water",spell=16190},colour=c.WATER}
a.variant(b,"manatide","iconBar",d.copy(e))
a.variant(b,"manatide","twinBars",d.copy(e))
a.variant(b,"manatide","oneBar",d.copy(e))
a.variant(b,"maelstrom","stacksTime",{spell=408505,knownWith=408498,stacks=5,colour="#85b0ff",
hidden=true})
a.variant(b,"shields","upright",{spell={324,408510},shows="lastSeen",colour=c.FROST,lastPercent=10})
a.variant(b,"elementalfocus-alert","alertBar",{spell=16246,knownWith=16164,picture="genericArc2",
spread=g,colour=f,barColour=c.FROST})
