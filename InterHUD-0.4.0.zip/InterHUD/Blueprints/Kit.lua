



local a,b=...
local c=b.Blueprints
local g=b.Schema
local a=c.kit
local e,i,h=a.list,a.shipped,a.onEvent

local d="#ff3333"


function a.source(a,b)
for c,a in ipairs(a.sources)do
if a.id==b then return a end
end
end
function a.firstOf(a,c,b)
for d,a in ipairs(a.sources)do
if a.kind==c and(b==nil or(a.unit or"player")==b)then return a end
end
end

function a.layer(a,c)
for b,a in ipairs(a.sources)do
for d,b in ipairs(a.layers or{})do
if b.id==c then return b,a end
end
end
end


local function f(a,b)
local a=g.variantOf(a)
for c,a in ipairs(a and a.stateOrder or{})do
if a==b then return true end
end
return false
end

local function g(c,b)
local a=0
for d,b in ipairs(b.looks or{})do
if type(b["while"])=="string"and b.unless==nil and f(c,b["while"])then a=a+1
else break end
end
return a
end




function a.look(d,b,c,e)
b.looks=b.looks or{}
local a
for d,b in ipairs(b.looks)do
if b["while"]==c and b.unless==nil then a=b end
end
if not a then
a={["while"]=c}
if f(d,c)then
table.insert(b.looks,g(d,b)+1,a)
else
b.looks[#b.looks+1]=a
end
end
for b,c in pairs(e or{})do
if type(c)=="table"and type(a[b])=="table"then
for c,d in pairs(c)do a[b][c]=d end
else
a[b]=c
end
end
return a
end


local j={"notEnoughPower","outOfRange"}

local f=setmetatable({},{__mode="k"})

function a.main(a)
local b=a.sources[1]
return f[b]and a.sources[2]or b
end






function a.factsFrom(c,d,e)
local d=assert(a.source(c,d),"factsFrom: no source "..tostring(d))
assert(not a.source(c,"spell"),"factsFrom: "..tostring(c.id).." has a spell source already")
c.sources[#c.sources+1]={id="spell",kind="spell",spells=b.copy(d.spells),
shownSpell="lastCast"}
for b,a in ipairs(d.layers or{})do
if a.kind=="icon"then
a.looks=a.looks or{}
local c=g(d,a)
local b={}
for c,a in ipairs(j)do
if e[a]then b[#b+1]={["while"]="spell."..a}end
end
if e.notEnoughPower then
for c=1,c do
local c=a.looks[c]
local a=c.border
if a and a.ring then
b[#b+1]={["while"]={c["while"],"spell.notEnoughPower"},
border={ring=true,ringColour=a.ringColour,ringSize=a.ringSize}}
end
end
end
for b,d in ipairs(b)do table.insert(a.looks,c+b,d)end
end
end
return c
end


function a.auraSource(a)
local c=a.unit or"player"
local b={id=c=="target"and"debuff"or"buff",kind="aura",unit=c,spells=b.copy(e(a.spell)),
shownSpell=a.shows,castBy=a.castBy}
if a.lastPercent then b.facts={expiring={{id="expiring",share=a.lastPercent}}}end
return b
end








function a.keepUp(b)
local g=b.timed~=false
local c=a.auraSource({spell=b.spell,shows=b.shows,castBy=b.castBy,
lastPercent=g and b.lastPercent or nil})
local h,e={},{}
local f={id="icon",kind="icon",sweep={enabled=false},count={enabled=false},
time=not g and{enabled=false}or nil}
c.layers={f}
if b.quiet then a.look(c,f,"present",{shown=false})end
a.look(c,f,"missing",{desaturated=true,border=not b.calm and{ring=true,ringColour=d}or nil})
if b.missingGlow~=nil then
h[#h+1]={id="missing-glow",name="Glow while missing",enabled=i(b.missingGlow)}
a.look(c,f,"missing",{glows={["missing-glow"]={shown=true}}})
e[#e+1]={label="Glow while missing",part="missing-glow",field="enabled"}
end
if g and b.quiet then a.look(c,f,"expiring",{shown=true})end
if g and b.expiringGlow~=nil then
h[#h+1]={id="expiring-glow",name="Glow while Expiring",enabled=i(b.expiringGlow)}
a.look(c,f,"expiring",{glows={["expiring-glow"]={shown=true}}})
e[#e+1]={label="Glow while Expiring",part="expiring-glow",field="enabled"}
end
f.glows=h[1]and h or nil
local f={id=b.id,name=b.name,sources={c},quick=e}
if g and b.colour then
local f={id="bar",kind="bar",name="Time bar",thickness=8,
position={point="BOTTOM",toPoint="BOTTOM",x=0,y=0},colour=b.colour}
c.layers[2]=f
if b.quiet then a.look(c,f,"present",{shown=false})end
a.look(c,f,"missing",{shown=false})
a.look(c,f,"expiring",{shown=b.quiet or nil,colour=d})
table.insert(e,1,{label="Time bar",part="bar",field="enabled"})
end
if g then e[#e+1]={label="Duration numbers",part="icon",field="time.enabled"}end
if b.power then a.factsFrom(f,c.id,{notEnoughPower=true})end
return f
end









a.BASE_OPACITY=40
function a.spellBase(c,d)
local e=assert(a.source(c,d),"spellBase: no source "..tostring(d))


for d,a in ipairs(e.spells or{})do
local b,a=b.Spells.family(a)
if not a or a.kind~="spell"then return c end
end

local d
for a,b in ipairs(c.sources)do
if b.id=="spell"then d=table.remove(c.sources,a)break end
end
assert(not(d and d.layers and d.layers[1]),"spellBase: "..tostring(c.id).."'s spell source draws already")
d=d or{id="spell",kind="spell",spells=b.copy(e.spells),shownSpell="lastCast"}
local a={id="spell-icon",kind="icon",name="Spell icon",opacity=a.BASE_OPACITY,
time={enabled=false}}


for c,b in ipairs(e.layers or{})do
if b.kind=="icon"then
for c,b in ipairs(b.looks or{})do
local c=b["while"]
if type(c)=="string"and c:match("^spell%.")and next(b,next(b))==nil then
a.looks=a.looks or{}
a.looks[#a.looks+1]={["while"]=c}
end
end
end
end
d.layers={a}
f[d]=true
table.insert(c.sources,1,d)
c.quick=c.quick or{}
c.quick[#c.quick+1]={label="Spell icon under the debuff",part="spell-icon",field="enabled"}
return c
end








function a.debuff(b)
local c=a.auraSource({unit="target",spell=b.spell,shows=b.shows,lastPercent=b.lastPercent})
local e={id="icon",kind="icon",sweep={enabled=false},count={enabled=false},
looks={b.missing=="hidden"and{["while"]="missing",shown=false}
or{["while"]="missing",desaturated=true}}}
c.layers={
e,
{id="bar",kind="bar",name="Time bar",thickness=8,
position={point="BOTTOM",toPoint="BOTTOM",x=0,y=0},colour=b.colour,
looks={{["while"]="missing",shown=false},{["while"]="expiring",colour=d}}},
}
local d={
id=b.id,name=b.name,sources={c},
quick={
{label="Time bar",part="bar",field="enabled"},
{label="Duration numbers",part="icon",field="time.enabled"},
},
}
if b.range or b.power then a.factsFrom(d,c.id,{outOfRange=b.range,notEnoughPower=b.power})end


if b.missing=="hidden"then return d end
return a.spellBase(d,c.id)
end





function a.withDebuffBar(a,c)
a.sources[#a.sources+1]={id="debuff",kind="aura",unit="target",spells=b.copy(e(c.spell)),
layers={{id="debuff-bar",kind="bar",name=c.name,thickness=8,
position={point="BOTTOM",toPoint="BOTTOM",x=0,y=0},colour=c.colour,
looks={{["while"]="missing",shown=false}}}}}
table.insert(a.quick,1,{label=c.name,part="debuff",field="enabled"})
return a
end







function a.handEnchant(a)
local b={id="enchant",kind="weaponEnchant",hand=a.hand,
facts={expiring={{id="expiring",seconds=300}}},
layers={
{id="icon",kind="icon",sweep={enabled=false},
glows={{id="missing-glow",name="Glow with none on"}},
looks={{["while"]="present",shown=false},
{["while"]="missing",desaturated=true,border={ring=true,ringColour=d},
glows={["missing-glow"]={shown=true}}},
{["while"]="expiring",shown=true}}},
}}
h(b,"removed",{id="removed-pop",kind="pop",style={colour="#59a6ff"}})
return{
id=a.id,name=a.name,
sources={b,a.spell and{id="spell",kind="spell",spells={a.spell}}or nil},
quick={
{label="Glow with none on",part="missing-glow",field="enabled"},
{label="Pop when it goes",part="removed-pop",field="enabled"},
},
}
end









function a.cure(d,f,g,i,c)
local b={id="dispel",kind="dispel",unit="player",spells=b.copy(e(g)),types=b.copy(e(i)),
layers={

{id="icon",kind="icon",time={enabled=false},count={enabled=false},
glows={{id="glow",name="Glow while "..c,enabled=false,shown=true}},
looks={{["while"]="missing",shown=false}}},
}}
h(b,"arrived",{id="arrival-pop",kind="pop"})
local b={
id=d,name=f,sources={b},
quick={
{label="Pop when you are "..c,part="arrival-pop",field="enabled"},
{label="Glow while "..c,part="glow",field="enabled"},
},
}
return a.factsFrom(b,"dispel",{notEnoughPower=true})
end




a.colour={
FIRE="#ff6f35",FROST="#a4dfff",WATER="#49cae2",EARTH="#dc9e46",NATURE="#7fd858",ARCANE="#d6bcff",
SHADOW="#a77bff",HOLY="#ffd100",PHYSICAL="#ffd100",BLOOD="#ff5c4d",BLEED="#c43a3a",ALARM=d,
FADING="#ffb833",OFF="#8c8c8c",TIME="#e6e6e6",

READY="#e6e6e6",
}


local j={"one","two","three","four","five","six","seven","eight","nine","ten"}


function a.quickFirst(a,b,c,d)
a.quick=a.quick or{}
table.insert(a.quick,1,{label=b,part=c,field=d})
return a
end


function a.countFromOne(b)
a.main(b).layers[1].count={fromOne=true}
return b
end



function a.atStacks(d,e,f)
f=f or{}
local b=assert(a.firstOf(d,"aura"),"atStacks: no aura on "..tostring(d.id))
b.facts=b.facts or{}
b.facts.stacks={{id="atStacks",atLeast=e}}
local c=b.layers[1]
local e=j[e]or tostring(e)
local g=e.."-glow"
c.glows=c.glows or{}
c.glows[#c.glows+1]={id=g,name="Glow at "..e,enabled=i(f.glow)}
a.look(b,c,"atStacks",{glows={[g]={shown=true}}})
return a.quickFirst(d,"Glow at "..e,g,"enabled")
end


function a.onlyInCombat(a)
a["while"]="game.inCombat"
return a
end



a.COUNT_ROUTE="An item's count carried by a spell with no cooldown (CD-3, IT-1): it only ever reads Ready"



a.NONE={}







function a.classKit(d,f)
local e=d:lower().."-"
local b={prefix=e}
function b.premade(f,b,a)
c.registerPremade(e..f,{label=b.name,class=d,record=b,
experimental=a and a.experimental,variantOf=a and a.variantOf,
layout=a and a.layout,preview=a and a.preview,line=a and a.line})
return b
end

function b.add(a,c)return b.premade(a.id,a,c)end
function b.cooldown(b,c,d,e)
local b={id=b,name=c,spell=d}
for a,c in pairs(f or{})do b[a]=c end
for c,d in pairs(e or{})do
if d==a.NONE then b[c]=nil else b[c]=d end
end
return a.cooldownPremade(b)
end
function b.big(f,g,e,h,c)
c=c or{}
local d=c.pop
if d==nil then d=true end
local b=b.cooldown(f,g,e,{pop=d,noGcd=c.noGcd~=false})
return a.withBuff(b,{spell=c.buff or e,time=true,barColour=h})
end
return b
end


function a.expiringGlow(c)
local d=a.main(c)
local b=d.layers[1]
b.glows=b.glows or{}
b.glows[#b.glows+1]={id="expiring-glow",name="Glow while Expiring"}
a.look(d,b,"expiring",{glows={["expiring-glow"]={shown=true}}})
return a.quickFirst(c,"Glow while Expiring","expiring-glow","enabled")
end




a.RECAST="A look on a cooldown's icon keyed on Ready and a buff on you Missing (the split pane): proven on a target"
.." debuff only"
function a.recastGlow(c,d)
local b=c.sources[1]
local b=b.layers[1]
b.glows=b.glows or{}
b.glows[#b.glows+1]={id="recast-glow",name=d.label}
b.looks=b.looks or{}
b.looks[#b.looks+1]={["while"]={"ready","buff.missing"},
glows={["recast-glow"]={shown=true}}}
return a.quickFirst(c,d.label,"recast-glow","enabled")
end







function a.withCount(d,c)
local h=d.sources[1]
local e=h.layers[1]
local f={id="reagent-count",kind="text",name=c.name,fontSize=11,
position={point="BOTTOMRIGHT",toPoint="BOTTOMRIGHT",x=-1,y=1}}
for a=1,g(h,e)do
local a=e.looks[a]
if a.shown~=nil or a.opacity~=nil then
f.looks=f.looks or{}
f.looks[#f.looks+1]={["while"]=h.id.."."..a["while"],shown=a.shown,
opacity=a.opacity}
end
end
d.sources[#d.sources+1]={id="reagent",kind="reagent",items=b.copy(c.items),
reagentFor=c.reagentFor,facts=c.low and{low={{id="low",count=c.low}}}or nil,
layers={f}}
d.customStates=d.customStates or{}
d.customStates[#d.customStates+1]={id="running-low",name=c.low and"Low or out"or"Out",
any=c.low and{"reagent.low","reagent.none"}or nil,all=not c.low and{"reagent.none"}or nil}

local g={["while"]="running-low",shown=true,opacity=100}
e.looks=e.looks or{}
e.looks[#e.looks+1]=b.copy(g)
e.looks[#e.looks+1]={["while"]="reagent.none",border={ring=true,ringColour=a.colour.ALARM}}
if f.looks then f.looks[#f.looks+1]=g end
a.quickFirst(d,c.shown,"running-low","enabled")
return a.quickFirst(d,c.name,"reagent","enabled")
end



function a.countOn(b,c,d,e)
local a=assert(a.layer(b,c),"countOn: no layer "..tostring(c))
a.count={fromOne=true}
table.insert(b.quick,e or 1,{label=d,part=c,field="count.enabled"})
return b
end



function a.warnWhileUp(a)
return{
id=a.id,name=a.name,
sources={{id="buff",kind="aura",unit="player",spells={a.spell},
layers={{id="icon",kind="icon",sweep={enabled=false},count={enabled=false},
time={enabled=false},glows={{id="glow",name="Glow",shown=true}},
looks={{["while"]="present",border={ring=true,ringColour=d}},
{["while"]="missing",shown=false}}}}}},
quick={{label="Glow",part="glow",field="enabled"}},
}
end



function a.hiddenWhileMissing(c)
local b,d=a.layer(c,"icon")
for a=#(b.looks or{}),1,-1 do
local c=e(b.looks[a]["while"])
for d,c in ipairs(c)do
if c=="missing"then
table.remove(b.looks,a)
break
end
end
end
a.look(d,b,"missing",{shown=false})
return c
end






function a.purge(b)
local c={id="dispel",kind="dispel",unit="target",spells={b.spell},types={b.dispel},
layers={
{id="icon",kind="icon",sweep={enabled=false},time={enabled=false},
glows={{id="glow",name="Glow while it has one",shown=true,style={kind="proc"}}},
looks={{["while"]="missing",shown=false}}},
}}
local d={
id=b.id,name=b.name,sources={c},
quick={
{label="Glow while it has one",part="glow",field="enabled"},
{label="Skip long buffs",part="dispel",field="skipLong"},
},
}
a.factsFrom(d,"dispel",{outOfRange=true,notEnoughPower=true})
if b.cooling then
local a=c.layers[1].looks
a[#a+1]={["while"]="spell.coolingDown",desaturated=true,glows={glow={shown=false}}}
end
return d
end







function a.extras(e,b)
local f,c=a.layer(e,"icon")
c=c or a.main(e)
local g=c.kind=="spell"
local d={}
if b.pop~=nil then
local a=g and"ready-pop"or"arrival-pop"
h(c,g and"comesReady"or"arrived",{id=a,kind="pop",enabled=i(b.pop)})
d[#d+1]={label=g and"Ready pop"or"Pop as it arrives",part=a,field="enabled"}
end

local function h(h,b,j,g)
if h==nil then return end
assert(f,"extras: a glow, but no icon layer on "..tostring(e.id))
f.glows=f.glows or{}
f.glows[#f.glows+1]={id=b,name=j,enabled=i(h),shown=g==nil or nil}
if g then a.look(c,f,g,{glows={[b]={shown=true}}})end
d[#d+1]={label=j,part=b,field="enabled"}
end
if g then
h(b.glow,"ready-glow","Ready glow","ready")
if b.gcd then
f.gcdSweep=nil
d[#d+1]={label="GCD sweep",part="icon",field="gcdSweep.enabled"}
end
else
h(b.glow,"glow","Glow while "..tostring(e.name).." is up")
h(b.missingGlow,"missing-glow","Glow while missing","missing")
h(b.expiringGlow,"expiring-glow","Glow while Expiring","expiring")
end
if b.quiet then
for d,b in ipairs(c.layers)do
a.look(c,b,"present",{shown=false})
a.look(c,b,"expiring",{shown=true})
end
end
if not g and(b.range or b.power)then
a.factsFrom(e,c.id,{outOfRange=b.range,notEnoughPower=b.power})
end
for b,a in ipairs(e.quick or{})do d[#d+1]=a end
e.quick=d
return e
end






a.TARGET_CAST="The target's cast (CA-4, CA-5: one caster seen; channels, elites and instances unseen: EP-45)"
function a.interrupt(b)
local a,d=a.layer(b,"icon")
assert(a,"interrupt: no icon layer on "..tostring(b.id))
local c={"game.targetCasting","game.hostileTarget"}
a.opacity=0
a.glows=a.glows or{}
a.glows[#a.glows+1]={id="interrupt-glow",name="Glow"}
a.looks=a.looks or{}
a.looks[#a.looks+1]={["while"]={"ready",c[1],c[2]},opacity=100}
a.looks[#a.looks+1]={["while"]={"coolingDown",c[1],c[2]},opacity=100,
desaturated=true}
a.looks[#a.looks+1]={["while"]="interrupt-now",glows={["interrupt-glow"]={shown=true}}}
local a=d.id.."."
b.customStates=b.customStates or{}
b.customStates[#b.customStates+1]={id="interrupt-now",name="Interrupt now",
all={a.."ready",c[1],c[2]},
none={a.."outOfRange",a.."notEnoughPower",a.."notUsable"},

events={enters={effects={{id="interrupt-pop",kind="pop"},
{id="interrupt-sound",kind="sound"}}}}}
local a={{label="Glow while a press would interrupt",part="interrupt-glow",field="enabled"},
{label="Pop as a press would interrupt",part="interrupt-pop",field="enabled"},
{label="Sound as a press would interrupt",part="interrupt-sound",field="sound"},
{label="Icon while your target isn't casting",choices={
{label="Hidden",writes={{part="icon",field="opacity",value=0}}},
{label="Faint",writes={{part="icon",field="opacity",value=30}}},
{label="Shown",writes={{part="icon",field="opacity",clear=true}}}}}}
for c,b in ipairs(b.quick or{})do a[#a+1]=b end
b.quick=a
return b
end



function a.interruptPremade(e,d,b,f,g,h)
local b=a.extras(c.layout("icon").build({id=d,name=b,spell=f,cooldown=true}),g)
local c={a.TARGET_CAST}
for b,a in ipairs(h or{})do c[#c+1]=a end
a.interrupt(b)
local f,a=a.layer(b,"icon")
return e.premade(d,b,{layout="icon",experimental=c,
preview={[a.id]="ready",game={"targetCasting","hostileTarget"}}})
end





a.THREAT="Your threat on your target (UN-14: one ordinary open-world mob's reads; whether each change in combat"
.." sends an event, and elites, bosses and instances, unseen: EP-29)"
local d={{"tanking","#33cc33"},{"slipping","#ffaa00"},{"pulling",d},{"behind",d}}
function a.threatStrip(a)
local b={id="strip",kind="bar",name="Threat strip",value="full",thickness=4,
position={point="TOP",toPoint="BOTTOM",x=0,y=-2},shown=false,looks={}}
for c,a in ipairs(d)do b.looks[#b.looks+1]={["while"]=a[1],shown=true,colour=a[2]}end
local b={id="threat",kind="threat",layers={b}}
h(b,"losesAggro",{id="lost-pop",kind="pop",over={"icon"}},
{id="lost-sound",kind="sound",enabled=false})
a.sources[#a.sources+1]=b
local b={{label="Threat strip",part="strip",field="enabled"},
{label="Pop when you lose it",part="lost-pop",field="enabled"},
{label="Sound when you lose it",part="lost-sound",field="enabled"}}
for c,a in ipairs(a.quick or{})do b[#b+1]=a end
a.quick=b
return a
end


function a.threatPremade(e,d,b,f,g,h)
local c=a.extras(c.layout("icon").build({id=d,name=b,spell=f,cooldown=true}),g)
local b={a.THREAT}
for c,a in ipairs(h or{})do b[#b+1]=a end
return e.premade(d,a.threatStrip(c),{layout="icon",experimental=b})
end





function a.variant(g,h,e,b)
local d=assert(c.premade(g.prefix..h),"a variant of no pre-made: "..g.prefix..h)
local f=assert(c.layout(e),"no such layout: "..tostring(e))

local i=a.firstOf(d.record,"aura")
if b.castBy==nil and i then b.castBy=i.castBy end
local i=f.wordFor and f.wordFor(b)or f.word
b.id=h.."-"..i:gsub(" ","")
b.name=d.label..": "..i
local j=b.knownWith
b.knownWith=nil
local i,k=f.build(b)
if j then a.knownWith(i,j)end
local j,a=c.combination(i),false
for c,b in ipairs(f.serves)do a=a or b==j end
assert(a,"layout "..e.." has no body for "..tostring(j)..": "..b.id)
local a={}
for d,b in ipairs(k or{})do
if not c.isProven(b)then a[#a+1]=b end
end
d.variants=d.variants or{}
local c=false
for b,a in ipairs(d.variants)do c=c or a==e end
if not c then d.variants[#d.variants+1]=e end
return g.premade(b.id,i,{experimental=a[1]and a or nil,
variantOf=g.prefix..h,layout=e})
end




function a.swingQuick(a,f,g)
local function c(b,c,d)
local a={}
for b,e in ipairs(b)do a[b]={part=e,field=c,value=d}end
return a
end
local function d(d,b)
if#a==1 then return{label=d,part=a[1],field=b}end
return{label=d,choices={{label="On",writes=c(a,b,true)},
{label="Off",writes=c(a,b,false)}}}
end

local function e(c,d)
local b={}
for e,a in ipairs(a)do
b[#b+1]={part=a,look="due",field="shown",value=c,clear=c==nil or nil}
if d then b[#b+1]={part=a,field="runOut",value=d}end
end
return b
end
local b={}
for c,a in ipairs(a)do b[#b+1]=a end
for c,a in ipairs(f or{})do b[#b+1]=a end


local function f(d,b,c)
local a
for d=2,#b do
a=a or{}
a[#a+1]={part=b[d],field=c}
end
return{label=d,part=b[1],field=c,also=a}
end
local a={
f("Length",b,"length"),
f("Thickness",a,"thickness"),
d("Time left on the bar","time.enabled"),
d("Spark on the bar","spark.enabled"),
d("Bar fills up","fills"),
{label="Bar grows to the",choices={{label="Right",writes=c(b,"grows","right")},
{label="Left",writes=c(b,"grows","left")}}},
{label="Bar while your swing is due",choices={{label="Hidden",writes=e(false)},
{label="Empty",writes=e(nil,"empty")},{label="Full",writes=e(nil,"full")}}},
{label="When it shows",choices={
{label="Always",writes={{field="while",clear=true},{field="otherwise",clear=true}}},
{label="Only in combat",writes={{field="while",value="game.inCombat"},
{field="otherwise",clear=true}}},
{label="Faded out of combat",writes={{field="while",value="game.inCombat"},
{field="otherwise",value=40}}},
}},
}
for c,b in ipairs(g or{})do a[#a+1]=b end
return a
end
