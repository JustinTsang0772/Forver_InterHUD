








local a,i=...
local f=i.Blueprints
local a=f.kit
local q=a.colour.ALARM


local e=a.classKit("PALADIN",{pop=false,glow=false})
local b,c=e.premade,e.cooldown
local d=a.colour

local g,o=a.countOn,a.warnWhileUp





local h="Not usable while under Forbearance (CD-8 shows stances only)"
local j="Not usable against the wrong creature type (CD-8 shows stances only)"
local k="Not enough power over a by-type button"
local l="Holy Shield's charges as the buff's count (assumed as Lightning Shield's, AU-10)"
local m="Magic as a dispel type on you (AU-13 shows poison and disease)"
local r="A stun stopping your target's cast (the game's rule, unseen on Forever; one immune to stuns lights it"
.." too)"



local n={20154,21082,1311649,20375,20164,20165,20166}
b("seal",a.onlyInCombat(a.keepUp({id="seal",name="Seal",spell=n,shows="lastSeen",
colour=d.HOLY,missingGlow=false,expiringGlow=true,power=true})))

b("aura",a.keepUp({id="aura",name="Aura",spell={465,7294,19746,19876,19888,19891},
shows="lastSeen",timed=false,quiet=true,missingGlow=true}))



b("blessing",a.keepUp({id="blessing",name="Blessing",castBy="anyone",
spell={19740,19742,20217,25782,25894,25898},shows="lastSeen",quiet=true,
lastPercent=5,missingGlow=true,expiringGlow=false,power=true}))


b("righteousfury",a.keepUp({id="righteousfury",name="Righteous Fury",spell=25780,quiet=true,
lastPercent=5,missingGlow=true,expiringGlow=false,power=true}))
b("righteousfuryon",o({id="righteousfuryon",name="Righteous Fury on",spell=25780}))




local o={21183,20185,20186,20184,20232}
b("judgement",a.withDebuffBar(c("judgement","Judgement",20271,{noGcd=true}),
{spell=o,name="Judgement's bar",colour=d.HOLY}))



b("holystrike",c("holystrike","Holy Strike",679))
b("hammeroftherighteous",c("hammeroftherighteous","Hammer of the Righteous",407632))
b("consecration",c("consecration","Consecration",26573))
b("exorcism",c("exorcism","Exorcism",879),{experimental={j}})

b("holywrath",c("holywrath","Holy Wrath",2812,{pop=true}),
{experimental={j}})
b("holyshock",c("holyshock","Holy Shock",1311606))
b("lightsvigil",c("lightsvigil","Light's Vigil",1310911))



b("holyshield",g(a.withBuff(c("holyshield","Holy Shield",20925,
{glow=true}),{spell=20925,name="Holy Shield's buff",time=true,barColour=d.HOLY}),
"buff-icon","Charges",2),{experimental={l}})




local p={642,498}
b("divineshield",a.withBuff(c("divineshield","Divine Shield or Protection",p,
{pop=true}),
{spell=p,name="Shield's buff",time=true,barColour=d.HOLY}),{experimental={h}})
b("templarsbulwark",a.withBuff(c("templarsbulwark","Templar's Bulwark",1311015,
{pop=true,noGcd=true}),
{spell=1311015,name="Bulwark's shield",time=true,barColour=d.HOLY}),
{experimental={h}})
b("voiceoftruth",a.withBuff(c("voiceoftruth","Voice of Truth",1310897,
{pop=true,noGcd=true}),
{spell=1310897,name="Immune to interrupts",time=true,barColour=d.HOLY}))


b("layonhands",c("layonhands","Lay on Hands",633))
b("divineintervention",c("divineintervention","Divine Intervention",19752))


b("blessingofprotection",a.withBuff(c("blessingofprotection","Blessing of Protection",1022),
{spell=1022,name="Protection on you",time=true,barColour=d.PHYSICAL}),{experimental={h}})
b("blessingoffreedom",a.withBuff(c("blessingoffreedom","Blessing of Freedom",1044),
{spell=1044,name="Freedom on you",time=true,barColour=d.FROST}))




b("divinefavor",a.withBuff(c("divinefavor","Divine Favor",20216,
{pop=true,noGcd=true}),
{spell=20216,name="Primed",glow=true,while_="primed",as="primed"}))
b("swiftjudgement",c("swiftjudgement","Swift Judgement",1310994,{pop=true,noGcd=true}))



b("hammerofjustice",a.extras(f.layout("iconBar").build({id="hammerofjustice",name="Hammer of Justice",
spell=853,cooldown=true,with={unit="target",spell=853},colour=d.HOLY}),
{pop=true,glow=false,gcd=true}),{layout="iconBar"})
b("repentance",a.withDebuffBar(c("repentance","Repentance",20066,{pop=true}),
{spell=20066,name="Repentance bar",colour=d.HOLY}))
b("turnundead",a.withDebuffBar(c("turnundead","Turn Undead",2878),
{spell=2878,name="Turn bar",colour=d.HOLY}),{experimental={j}})


a.interruptPremade(e,"hammerofjusticeinterrupt","Hammer of Justice interrupt",853,{gcd=true},{r})


b("purify",a.cure("purify","Purify",1152,{"poison","disease"},"poisoned or diseased"),
{experimental={k}})
b("cleanse",a.cure("cleanse","Cleanse",4987,{"magic"},"under magic"),
{experimental={k,m}})

b("cleanseall",a.cure("cleanseall","Cleanse",4987,{"poison","disease","magic"},
"poisoned, diseased or under magic"),{experimental={k,m}})



b("vengeance",g(a.proc("vengeance","Vengeance",20050,{pop=false,glow=false,knownWith=20049}),
"icon","Stacks"))
b("reckoning",g(a.proc("reckoning","Reckoning",1326084,{pop=true,glow=false,knownWith=20177}),
"icon","Stored attacks"),{experimental={"Reckoning's stored attacks as the buff's count (aura 1326084, unseen)"}})
b("ironcreed",a.proc("ironcreed","Iron Creed",1311033,{pop=false,glow=false,knownWith=1311034}))
b("redoubt",a.proc("redoubt","Redoubt",20128,{pop=false,glow=false,knownWith=20127}))
b("infusionoflight",a.proc("infusionoflight","Infusion of Light",437063,{knownWith=426065}))


b("vindication",a.knownWith(a.debuff({id="vindication",name="Vindication",spell=440667,
colour=d.PHYSICAL,missing="hidden"}),9452))



b("judgementdebuff",a.knownWith(a.debuff({id="judgementdebuff",name="Judgement: debuff",spell=o,
shows="lastSeen",colour=d.HOLY}),20271))


local c=c("sealjudgement","Judgement: with seal",20271,{noGcd=true})
c.sources[2]={id="seal",kind="aura",unit="player",spells=n}
c.customStates={{id="no-seal",name="No seal",all={"seal.missing"}}}
local h=c.sources[1].layers[1]
h.looks=h.looks or{}
h.looks[#h.looks+1]={["while"]="no-seal",desaturated=true,
border={ring=true,ringColour=q}}
table.insert(c.quick,1,{label="Grey with no seal",part="no-seal",field="enabled"})
b("sealjudgement",c,{experimental={"A look on a cooldown's icon keyed on another aura's Missing (the"
.." split pane): no seal (unseen)"}})


b("holyshieldup",g(a.onlyInCombat(a.keepUp({id="holyshieldup",name="Holy Shield: shield up",
spell=20925,colour=d.HOLY,missingGlow=true,expiringGlow=false,power=true})),"icon","Charges",2),
{experimental={l}})

local b={cooldown=true,spell=853,with={unit="target",spell=853},colour=d.HOLY}
a.variant(e,"hammerofjustice","twinBars",i.copy(b))
a.variant(e,"hammerofjustice","bar",i.copy(b))


f.registerUsable({
{"paladin-hammerofwrath","Hammer of Wrath",24275,"PALADIN",true,"mana"},
})


local a=a.art.OUTER
f.registerAlerts({

{"paladin-infusionoflight-alert","PALADIN",{id="infusionoflight-alert",name="Infusion of Light alert",
spell=437063,knownWith=426065,picture="daybreak"}},
{"paladin-hammerofwrath-alert","PALADIN",{id="hammerofwrath-alert",name="Hammer of Wrath alert",
spell=24275,picture="artOfWar",spread=a,usable=true,needsPower=true}},
})
