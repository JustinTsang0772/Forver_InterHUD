


















local a,c=...
local f=c.Blueprints
local b=f.kit
local d,e=b.cooldownPremade,b.withBuff
local a=b.colour


local a={
{"bloodfury",20572,a.FIRE},
{"shattercurse",1299026,a.ARCANE,{"curse"},"a curse"},
{"berserking",20554,a.FIRE},
{"rapidregeneration",1260270},
{"warstomp",20549},
{"stoneform",20594,a.EARTH,{"poison","disease"},"a poison or disease"},
{"walkonair",1259416},
{"skysight",1259686},
{"perception",20600,a.ARCANE},
{"willtosurvive",1259718},
{"shadowmeld",20580},
{"eluneslight",1259799,a.ARCANE},
{"escapeartist",20589},
{"eureka",1259812,a.ARCANE},
{"willoftheforsaken",7744},
{"cannibalize",20577},
{"readleyline",1259705},
}

local h="A look on a cooldown's icon keyed on Ready and a dispel type on you Present (the split pane): unseen"
local i="A Curse on you by dispel type (AU-13: a Poison and a Disease seen, a Curse never)"



local function j(d,a,e)
d.sources[#d.sources+1]={id="dispel",kind="dispel",unit="player",types=c.copy(a)}
local a=d.sources[1].layers[1]
local c="Glow while Ready with "..e.." on you"
a.glows=a.glows or{}
a.glows[#a.glows+1]={id="cleanse-glow",name=c}
a.looks=a.looks or{}
a.looks[#a.looks+1]={["while"]={"ready","dispel.present"},
glows={["cleanse-glow"]={shown=true}}}
return b.quickFirst(d,c,"cleanse-glow","enabled")
end

local b=c.SpellTable.racials or{}
for g,a in ipairs(a)do

local b=b[a[2]]
if b then
local g=b.ids and c.copy(b.ids)or a[2]
local d=d({id=a[1],name=b.name,spell=g,pop=true,glow=false})
if a[3]then d=e(d,{spell=b.ids and c.copy(b.ids)or a[2],time=true,barColour=a[3]})end
local e,g
if a[4]then

g={spell="ready",dispel="present"}
j(d,a[4],a[5])
e={h}
for b,a in ipairs(a[4])do
if a=="curse"then e[2]=i end
end
end
f.registerPremade("racial-"..a[1],{label=b.name,races=c.copy(b.races),record=d,
experimental=e,preview=g})
end
end
