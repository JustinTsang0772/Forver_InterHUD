





local b,a=...
local m=a.Blueprints
local d=m.kit
local a=d.colour

local b,h,g=220,7,3
local e="The swing source's bar (new: CA-8's plain length into a duration)"
local f="Due after a grace past the swing's end (unplayed)"
local p="The off hand's and ranged swings (EP-16)"
local n="Queued on a strike other than Heroic Strike (CA-17 saw Heroic Strike only)"
local q="A buff's stacks bar as a strip over another source's bar (AU-3, AU-38: seen on its own icon)"
local r="A buff's time bar as a strip under another source's bar (AU-8: seen on its own icon)"
local u="The swing's bar under one buff's Present and Missing clips (the split pane: unplayed)"



local function c(a,c,d,e,f)
return{id=a,kind="swing",hand=c,layers={
{id=a=="swing"and"bar"or a.."-bar",kind="bar",name=e,value="time",fills=true,
length=b,thickness=h,colour=d,position=f,time={enabled=false},
looks={{["while"]="none",shown=false},{["while"]="due",shown=false}}}}}
end

local function s(a)return{point="BOTTOM",to=a,toPoint="TOP",x=0,y=1}end
local function i(a)return{point="TOP",to=a,toPoint="BOTTOM",x=0,y=-1}end

local function o(a,c,d,e,f,h)
return{id=a,kind="aura",spells={d},layers={
{id=a.."-pips",kind="bar",name=c,value="stacks",segments=e,length=b,
thickness=g,colour=f,position=h,background={colour="#00000099"},
segmentLines={thickness=1},looks={{["while"]="missing",shown=false}}}}}
end

local function t(a,c,d,e,f)
return{id=a,kind="aura",spells=d,layers={
{id=a.."-time",kind="bar",name=c,value="time",length=b,thickness=g,colour=e,
position=f,background={colour="#00000099"},looks={{["while"]="missing",shown=false}}}}}
end

local function l(a,b)return{id=a,kind="spell",spells={b}}end

local function g(a,b,c)
a.looks[#a.looks+1]={["while"]=b,colour=c}
end





local function j(b,a)
table.insert(b,1,{id="range",kind="range",facts={ranges={{id="outofmelee",name="Out of melee range",from=5}}}})
a.looks[#a.looks+1]={["while"]="range.outofmelee",opacity=40}
end
local k="Out of melee range by the range source's estimate (new: UN-7's reads up a ladder of your spells)"
local function b(a,b)return{label=a,part=b,field="enabled"}end



local v=132223


local function h(c,a,d,e,f)
local b=a:sub(1,1)..a:sub(2):lower().." swing timer"
m.registerPremade(c,{label=b,class=a,experimental=d,
record={id="swing",name=b,menuIcon=v,sources=e,quick=f}})
end



do
local c=c("swing","main","#b3b3b3","Swing bar")
local l=c.layers[1]
local c={c}
for b,a in ipairs({{"rockbiter",8017,a.EARTH},{"flametongue",8024,a.FIRE},{"frostbrand",8033,a.WATER},
{"windfury",8232,"#a5dfff"}})do
c[#c+1]={id=a[1],kind="weaponEnchant",hand="main",spells={a[2]}}
g(l,a[1]..".present",a[3])
end
c[#c+1]=o("flurry","Flurry charges",16257,3,"#ffffff",s("bar"))
c[#c+1]=o("maelstrom","Maelstrom Weapon stacks",408505,5,"#85b0ff",i("bar"))
j(c,l)
h("shaman-swing","SHAMAN",{e,f,q,k},c,
d.swingQuick({"bar"},{"flurry-pips","maelstrom-pips"},
{b("Flurry charges","flurry-pips"),b("Maelstrom Weapon stacks","maelstrom-pips")}))
end



do
local i=c("swing","main","#c9c9c9","Swing bar")
local c=i.layers[1]
g(c,"enrage.present",a.BLOOD)
g(c,"heroicstrike.queued",a.HOLY)
g(c,"cleave.queued",a.NATURE)
c.marks={{id="slam-line",name="Line 1.5 seconds before the end",enabled=false,seconds=1.5}}
local a={i,l("heroicstrike",78),l("cleave",845),
{id="enrage",kind="aura",spells={12880}},
o("flurry","Flurry charges",12966,3,"#ffffff",s("bar"))}
j(a,c)
h("warrior-swing","WARRIOR",{e,f,n,q,u,k},a,
d.swingQuick({"bar"},{"flurry-pips"},
{b("Flurry charges","flurry-pips"),b("Line 1.5 seconds before the end","slam-line")}))
end


do
local g=c("swing","main","#ffcc40","Main hand bar")
local c=c("offhand","off","#c9a45a","Off hand bar",i("bar"))
local a={g,c,
t("sliceanddice","Slice and Dice time",{5171},a.PHYSICAL,i("offhand-bar"))}
j(a,g.layers[1])
c.layers[1].looks[#c.layers[1].looks+1]={["while"]="range.outofmelee",opacity=40}
h("rogue-swing","ROGUE",{e,f,p,r,k},a,
d.swingQuick({"bar","offhand-bar"},{"sliceanddice-time"},
{b("Off hand bar","offhand-bar"),b("Slice and Dice time","sliceanddice-time")}))
end



do
local j=c("swing","ranged","#9fd0ff","Shot bar")
j.layers[1].marks={{id="last",name="Last half second",shape="zone",seconds=0.5,
colour="#ff4d4d99"}}
local c=c("melee","main","#c9c9c9","Melee bar",i("bar"))
g(c.layers[1],"raptorstrike.queued",a.HOLY)
h("hunter-swing","HUNTER",{e,f,p,n},
{j,c,l("raptorstrike",2973)},
d.swingQuick({"bar","melee-bar"},nil,
{b("Last half second","last"),b("Melee bar","melee-bar")}))
end


do
local b=c("swing","main","#ffcc40","Swing bar")
g(b.layers[1],"maul.queued",a.HOLY)
local a={b,l("maul",6807)}
j(a,b.layers[1])
h("druid-swing","DRUID",{e,f,n,k,"Swings in Bear and Cat Form (EP-20)"},a,
d.swingQuick({"bar"}))
end


do
local c=c("swing","main","#ffcc40","Swing bar")
local a={c,t("seal","Seal time",{20154,21082,1311649,20375,20164,20165,20166},a.HOLY,
i("bar"))}
j(a,c.layers[1])
h("paladin-swing","PALADIN",{e,f,r,k},a,
d.swingQuick({"bar"},{"seal-time"},{b("Seal time","seal-time")}))
end





do
local e={"The range source (new: UN-7's reads up a ladder of your own spells, EllesmereUI's technique)",
"The ladder's item rungs (UN-23: open world; a dungeon unread, EP-77)"}
local c={{"melee","In melee range",a.NATURE,{to=5}},
{"near","5 to 20 yards",a.HOLY,{from=5,to=20}},
{"mid","20 to 30 yards","#ff9933",{from=20,to=30}},
{"far","30 yards or more",a.BLOOD,{from=30}}}
local function f()
local b={}
for c,a in ipairs(c)do b[c]={id=a[1],name=a[2],from=a[4].from,to=a[4].to}end
return b
end

local function d(d)
local a={{["while"]="unknown",shown=false}}
for c,b in ipairs(c)do a[#a+1]={["while"]=b[1],[d]=b[3]}end
return a
end
local function a(b,a,c,d)
m.registerPremade(b,{label=a,general=true,experimental=e,
record={id="range",name=a,sources={{id="range",kind="range",
facts={ranges=f()},layers=c}},quick=d}})
end
a("general-range-block","Range to target: block",{
{id="block",kind="bar",name="Range block",length=96,thickness=20,colour="#8c8c8c",
looks=d("colour")},
{id="words",kind="text",name="Range words",fontSize=12,colour="#ffffff",
position={point="CENTER",to="block",toPoint="CENTER",x=0,y=0},
looks={{["while"]="unknown",shown=false}}},
},{b("Range words","words")})
a("general-range-words","Range to target: words",{

{id="words",kind="text",name="Range words",fontSize=14,colour="#c9c9c9",maxWidth=100,
looks=d("colour")},
})


local d={}
for a=1,#c do
local b={{["while"]="unknown",shown=false}}
for e,d in ipairs(c)do
b[#b+1]={["while"]=d[1],colour=e<=#c-a+1 and d[3]or"#00000080"}
end
d[a]={id="segment"..a,kind="bar",name="Segment "..a,length=22,thickness=8,
colour="#00000080",looks=b,
position=a>1 and{point="LEFT",to="segment"..(a-1),toPoint="RIGHT",x=2,y=0}or nil}
end
d[#d+1]={id="words",kind="text",name="Range words",fontSize=12,
position={point="BOTTOM",to="segment2",toPoint="TOPRIGHT",x=1,y=2},
looks={{["while"]="unknown",shown=false}}}
a("general-range-segments","Range to target: segments",d,{b("Range words","words")})
end
