





local b,a=...
local g=a.Blueprints
local a=g.kit

local f=a.classKit("MAGE",{pop=false,glow=false})
local b,c=f.premade,f.cooldown
local d=a.colour

local j,k,i=a.expiringGlow,a.recastGlow,a.withCount






b("fireblast",c("fireblast","Fire Blast",2136))

b("arcanewrath",c("arcanewrath","Arcane Wrath",1326079))




local l="Fingers of Frost's aura: 400669 or 400670, which the client sends unrecorded"
local h=c("icelance","Ice Lance",1312002)
h.sources[#h.sources+1]={id="frozen",kind="aura",unit="target",spells={122,12494}}
local e=a.layer(h,"icon")
e.glows=e.glows or{}
e.glows[#e.glows+1]={id="frozen-glow",name="Glow on a frozen target"}
e.looks=e.looks or{}
e.looks[#e.looks+1]={["while"]={"ready","frozen.present"},
glows={["frozen-glow"]={shown=true}}}
b("icelance",a.quickFirst(h,"Glow on a frozen target","frozen-glow","enabled"),
{experimental={"A look on a cooldown's icon keyed on Ready and a target aura's Present (the split pane):"
.." unseen"}})

b("coneofcold",a.withDebuffBar(c("coneofcold","Cone of Cold",120),
{spell=120,name="Slow bar",colour=d.FROST}))

b("blastwave",c("blastwave","Blast Wave",11113))



b("frostnova",a.withDebuffBar(c("frostnova","Frost Nova",122,{pop=true}),
{spell={122,12494},name="Root bar",colour=d.FROST}))


b("polymorph",a.debuff({id="polymorph",name="Polymorph",spell={118,28270},colour=d.ARCANE,
missing="hidden",range=true,power=true}))

b("counterspell",c("counterspell","Counterspell",2139,{noGcd=true}))

a.interruptPremade(f,"counterspellinterrupt","Counterspell interrupt",2139,{})



b("blink",a.extras(g.layout("icon").build({id="blink",name="Blink",spell=1953,cooldown=true}),
{pop=true,glow=false,gcd=true}),{layout="icon"})
b("iceblock",a.withBuff(c("iceblock","Ice Block",11958,{pop=true}),
{spell=11958,name="Block",time=true,barColour=d.FROST}))


b("icebarrier",k(a.withBuff(a.cooldownPremade({id="icebarrier",name="Ice Barrier",spell=11426}),
{spell=11426,name="Shield",time=true,barColour=d.FROST}),{label="Glow when it can go back up"}),
{experimental={a.RECAST}})



b("frigidpower",a.knownWith(a.onlyInCombat(a.extras(g.layout("iconBar").build({id="frigidpower",
name="Frigid Power",spell=1326891,colour=d.FROST}),{expiringGlow=true})),11426),
{layout="iconBar",experimental={"Frigid Power's aura (1326891, new on build 70707): never seen"}})

b("manashield",a.proc("manashield","Mana Shield",1463,{pop=false,glow=false}))


b("wards",a.withBuff(c("wards","Wards",{543,6143}),
{spell={543,6143},name="Ward",time=true,barColour=d.ARCANE}))


b("arcanepower",f.big("arcanepower","Arcane Power",12042,d.ARCANE))


b("presenceofmind",a.withBuff(c("presenceofmind","Presence of Mind",12043,
{pop=true,noGcd=true}),
{spell=12043,name="Primed",glow=true,pop=false,while_="primed",as="primed"}))



b("combustion",a.withBuff(c("combustion","Combustion",11129,
{pop=true,noGcd=true}),
{spell=11129,name="Primed",glow=true,pop=false,while_="primed",as="primed"}),
{experimental={"A cooldown that starts only when its aura (11129) ends: unseen"}})

b("evocation",c("evocation","Evocation",12051,{pop=true}))

b("coldsnap",c("coldsnap","Cold Snap",12472,{pop=true,noGcd=true}))



b("armor",a.keepUp({id="armor",name="Armor",spell={168,7302,6117},shows="lastSeen",quiet=true,
missingGlow=true,expiringGlow=false,lastPercent=5,power=true}))



b("arcaneintellect",a.keepUp({id="arcaneintellect",name="Arcane Intellect",spell={1459,23028},
shows="lastSeen",quiet=true,missingGlow=false,lastPercent=5,power=true,castBy="anyone"}))



b("winterschill",a.knownWith(a.countFromOne(a.debuff({id="winterschill",name="Winter's Chill",
spell=12579,colour=d.FROST})),11180))
b("firevulnerability",a.knownWith(j(a.countFromOne(a.debuff({id="firevulnerability",
name="Fire Vulnerability",spell=22959,colour=d.FIRE}))),11095))


b("ignite",a.knownWith(a.debuff({id="ignite",name="Ignite",spell=412538,colour=d.FIRE,
missing="hidden"}),11119),{experimental={"A table-linked debuff ID no run has seen"}})




b("clearcasting",a.proc("clearcasting","Clearcasting",12536,{knownWith=11213}))
b("missilebarrage",a.proc("missilebarrage","Missile Barrage",400589,{knownWith=400588}))
b("heatingup",a.atStacks(a.countFromOne(a.proc("heatingup","Heating Up",400625,{pop=false,
glow=false,knownWith=400624})),3))


local c=a.proc("fingersoffrost","Fingers of Frost",400669,{knownWith=400647})
c.sources[1].spells={400669,400670}
b("fingersoffrost",a.countFromOne(c),
{experimental={l,"Fingers of Frost's count (two stacks by the data): unseen"}})


b("removelessercurse",a.cure("removelessercurse","Remove Lesser Curse",475,"curse","cursed"),
{experimental={"A Curse dispel type lighting a cure: AU-13 shows Poison and Disease only"}})






local c=a.COUNT_ROUTE
b("conjuredwater",i(a.cooldownPremade({id="conjuredwater",name="Conjured Water",spell=5504,
readyOpacity=0}),{items={231778,8079,8078,8077,3772,2136,2288,5350},low=4,name="Water count",
shown="Shown when low"}),{experimental={c}})

b("managem",i(a.cooldownPremade({id="managem",name="Mana Gem",spell={10054,10053,3552,759},
readyOpacity=0}),{items={8008,8007,5513,5514},name="Gem count",
shown="Shown when out"}),{experimental={c}})

b("arcanepowder",i(a.cooldownPremade({id="arcanepowder",name="Arcane Powder",spell=23028,
readyOpacity=0}),{items={17020},reagentFor=23028,low=2,name="Powder count",
shown="Shown when low"}),{experimental={c}})


a.variant(f,"blink","bar",{cooldown=true,spell=1953,colour=d.ARCANE})


local b,e,c,h=a.art.FROST,a.art.OUTER,a.art.ABOVE,a.art.HIGHER
g.registerAlerts({


{"mage-clearcasting-alert","MAGE",{id="clearcasting-alert",name="Clearcasting alert",spell=12536,
knownWith=11213,picture="genericTop1",above=c,colour=b}},
{"mage-missilebarrage-alert","MAGE",{id="missilebarrage-alert",name="Missile Barrage alert",
spell=400589,knownWith=400588,picture="arcaneMissiles"}},
{"mage-heatingup-alert","MAGE",{id="heatingup-alert",name="Heating Up alert",spell=400625,
knownWith=400624,picture="hotStreak",spread=e,stacks=3}},
{"mage-fingersoffrost-alert","MAGE",{id="fingersoffrost-alert",name="Fingers of Frost alert",
spell={400669,400670},knownWith=400647,picture="frozenFingers",above=h}},
})

a.variant(f,"clearcasting-alert","alertBar",{spell=12536,knownWith=11213,picture="genericTop1",
above=c,colour=b,barColour=d.FROST})
