













local a,g=...
local e=g.Blueprints
local a=e.kit


local c=a.classKit("WARRIOR",{pop=false,glow=false})
local f,h=c.premade,c.cooldown
local b=a.colour




local function d(a,c,d,e,b,g)
local c=h(a,c,d,e)
return f(a,b and b(c)or c,g)
end
local function h(a,d,e,g,h,b,i)
local c=c.big(a,d,e,g,h)
return f(a,b and b(c)or c,i)
end
local function j(c,e,b,d,g)
b.id,b.name=c,e
local a=a.debuff(b)
return f(c,d and d(a)or a,g)
end
local function l(b,d,e,g,c,h)
local a=a.proc(b,d,e,g)
return f(b,c and c(a)or a,h)
end
local function i(b)return function(c)return a.withDebuffBar(c,b)end end

local function p(b)return a.countOn(b,"buff-icon","Charges",2)end



local q="Shield Block's charges as a stacks bar on its buff (as Lightning Shield's, AU-3, AU-38)"
local r="Sweeping Strikes' charges as the buff's count (assumed as Lightning Shield's, AU-10)"



local k="A table-linked debuff ID no run has seen"

local n="Another player's copy on your target: untested"

local s="Two spells in one place, each hidden while Not usable (CD-8's read, never seen as a look)"
local t="Charge read Out of range inside its 8 yards nearest (unseen)"


local m={pop=false,glow=false,gcd=true}
f("mortalstrike",a.extras(e.layout("icon").build({id="mortalstrike",name="Mortal Strike",spell=12294,
cooldown=true}),m),{layout="icon"})
d("bloodthirst","Bloodthirst",23881)
d("shieldslam","Shield Slam",23922)
d("whirlwind","Whirlwind",1680)
d("slam","Slam",1240193)
d("spearingstrike","Spearing Strike",1310222)


f("thunderclap",a.extras(e.layout("iconBar").build({id="thunderclap",name="Thunder Clap",spell=6343,
cooldown=true,with={unit="target",spell=6343},colour=b.FROST,barAt="below"}),
{pop=false,glow=false,gcd=true}),{layout="iconBar"})





f("victoryrush",{
id="victoryrush",name="Victory Rush",baseSize=44,
sources={
{id="spell",kind="spell",spells={402927},layers={
{id="icon",kind="icon",time={fontSize=17},

glows={{id="glow",name="Ready & usable glow",shown=true}},
looks={{["while"]="coolingDown",opacity=30,glows={glow={shown=false}}},
{["while"]="notUsable",shown=false,glows={glow={shown=false}}}}}}},
{id="buff",kind="aura",unit="player",spells={402975},layers={
{id="bar",kind="bar",name="Victorious time",thickness=8,position={point="BOTTOM",to="icon"},
looks={{["while"]="spell.coolingDown",shown=false},
{["while"]="spell.notUsable",shown=false}}},
{id="text",kind="text",name="Victorious time text",
position={point="TOP",toPoint="BOTTOM",to="icon"},
looks={{["while"]="spell.coolingDown",opacity=40},
{["while"]="spell.notUsable",opacity=40}}}}},
},



customStates={{id="ready-usable",name="Ready and usable",all={"spell.ready"},
none={"spell.notUsable"},
events={enters={effects={{id="pop",kind="pop",over={"icon"}}}}}}},
quick={
{label="Ready & usable glow",part="glow",field="enabled"},
{label="Pop as it becomes usable",part="pop",field="enabled"},
{label="Victorious time bar",part="bar",field="enabled"},
{label="Victorious time text",part="text",field="enabled"},
},
})






d("charge","Charge",100,{pop=true,noGcd=true})
d("intercept","Intercept",20252,{pop=true,noGcd=true},
i({spell=20253,name="Stun bar",colour=b.PHYSICAL}),{experimental={k}})
d("pummel","Pummel",6552)
d("shieldbash","Shield Bash",72,nil,i({spell=18498,name="Silence bar",colour=b.ARCANE}),
{experimental={k}})

d("taunt","Taunt",355,{noGcd=true})


local m="Not usable for a Berserker Stance spell (CD-8 read a stance at rest and in combat, Berserker never)"
local o={gcd=true}
a.interruptPremade(c,"pummelinterrupt","Pummel interrupt",6552,o,{m})
a.interruptPremade(c,"shieldbashinterrupt","Shield Bash interrupt",72,o)


a.threatPremade(c,"tauntthreat","Taunt with threat",355,{})





d("disarm","Disarm",676,nil,i({spell=676,name="Disarm bar",colour=b.PHYSICAL}))
d("mockingblow","Mocking Blow",694,nil,i({spell=694,name="Taunt bar",colour=b.PHYSICAL}))
d("intimidatingshout","Intimidating Shout",5246,{pop=true},
i({spell={5246,20511},name="Fear bar",colour=b.PHYSICAL}))
d("concussionblow","Concussion Blow",12809,{noGcd=true},
i({spell=12809,name="Stun bar",colour=b.PHYSICAL}))




local function o(a)
a.sources[#a.sources+1]={id="root",kind="aura",unit="target",spells={23694},
layers={{id="root-mark",kind="icon",name="Root mark",width=18,height=18,
position={point="BOTTOMRIGHT",toPoint="TOPRIGHT",x=0,y=2},time={enabled=false},
count={enabled=false},border={style={kind="line",thickness=1}},
looks={{["while"]="missing",shown=false}}}}}
a.quick[#a.quick+1]={label="Root mark",part="root",field="enabled"}
return a
end
j("hamstring","Hamstring",{spell=1715,colour=b.FROST,missing="hidden",range=true,power=true},
o)
j("piercinghowl","Piercing Howl",{spell=12323,colour=b.FROST,missing="hidden",power=true})


j("deepwounds","Deep Wounds",{spell=412609,colour=b.BLEED,missing="hidden"},
function(b)return a.knownWith(b,12834)end,{experimental={k}})




h("bloodrage","Bloodrage",2687,b.BLOOD,{buff=29131})
h("berserkerrage","Berserker Rage",18499,b.FIRE,{noGcd=false})
h("sweepingstrikes","Sweeping Strikes",12292,b.PHYSICAL,nil,p,{experimental={r}})

f("deathwish",a.extras(e.layout("iconBar").build({id="deathwish",name="Death Wish",spell=12328,
cooldown=true,with={spell=12328},colour=b.BLOOD,barAt="below"}),
{pop=true,glow=false,gcd=true}),{layout="iconBar"})
h("recklessness","Recklessness",1719,b.FIRE,{noGcd=false})







local function o(a)
a.sources[#a.sources+1]={id="buff",kind="aura",unit="player",spells={2565},
layers={
{id="buff-bar",kind="bar",name="Its time",thickness=8,
position={point="BOTTOM",toPoint="TOP",x=0,y=0},colour=b.FROST,
background={colour="#00000099"},looks={{["while"]="missing",shown=false}}},
{id="charges",kind="bar",name="Charge bar",value="stacks",segments=2,thickness=12,
position={point="TOP",toPoint="BOTTOM",x=0,y=0},colour="#e8e8e8",
background={colour="#00000099"},looks={{["while"]="missing",shown=false}}},
}}
table.insert(a.quick,1,{label="Its time bar",part="buff-bar",field="enabled"})
table.insert(a.quick,2,{label="Charge bar",part="charges",field="enabled"})
table.insert(a.quick,3,{label="Charges",part="charges",field="segments"})
return a
end
d("shieldblock","Shield Block",2565,{noGcd=true},o,
{experimental={q}})
h("shieldwall","Shield Wall",871,b.FROST,{noGcd=false})
h("laststand","Last Stand",12975,b.NATURE,{buff=12976})
h("retaliation","Retaliation",20230,b.PHYSICAL,{noGcd=false})

d("challengingshout","Challenging Shout",1161,{pop=true},
i({spell=1161,name="Taunt bar",colour=b.PHYSICAL}),{experimental={k}})


j("rend","Rend",{spell=772,colour=b.BLEED,range=true,power=true},a.expiringGlow)






local function h(c,d,b,f)
local b=e.layout("iconBar").build({id=c,name=d,spell=b,cooldown=true,
with={unit="target",spell=b},colour=f,barAt="below"})
a.source(b,"debuff").castBy="anyone"

for a=#b.quick,1,-1 do
if b.quick[a].field=="time.enabled"then table.remove(b.quick,a)end
end
return a.extras(b,{gcd=true})
end
local i={["while"]="missing",shown=false}
local d=h("demoshout","Demoralizing Shout",1160,b.EARTH)

table.insert(a.source(d,"debuff").layers,{id="time",kind="text",name="Time",content="time",
fontSize=12,position={point="BOTTOMLEFT",to="icon",toPoint="BOTTOMLEFT",x=1,y=8},
looks={g.copy(i)}})
table.insert(d.quick,2,{label="Time",part="time",field="enabled"})
f("demoshout",d,{layout="iconBar"})

local d=h("sunderarmor","Sunder Armor",7386,b.EARTH)
do
local a=a.source(d,"debuff")
a.facts={stacks={{id="atStacks",atLeast=5}}}
local function c()
return{g.copy(i),{["while"]="atStacks",colour=b.HOLY}}
end
a.layers[#a.layers+1]={id="stacks",kind="bar",name="Stack strip",value="stacks",segments=5,
colour=b.EARTH,background={colour="#000000b3"},looks=c()}
a.layers[#a.layers+1]={id="number",kind="text",name="Stack number",content="stacks",
fromOne=true,fontSize=18,position={point="CENTER",toPoint="CENTER",x=0,y=0},looks=c()}
table.insert(d.quick,1,{label="Stack number",part="number",field="enabled"})
table.insert(d.quick,2,{label="Stack strip",part="stacks",field="enabled"})
end
f("sunderarmor",d,{layout="iconBar",experimental=g.copy(e.layout("stacksTime").routes)})





local h=a.layer
local function i(a)
a.facts=a.facts or{}
a.facts.expiring={{id="expiring",share=20}}
end
local function d(a,c,d)
local a,c=h(a,c)
a.thickness,a.colour=8,b.FROST
a.length,a.position=44,{point="BOTTOM",to="icon"}

if d then return end
i(c)
local b
for c,a in ipairs(a.looks or{})do
if a["while"]=="expiring"then a.colour,b="#ff3333",true end
end
if not b then
a.looks=a.looks or{}
a.looks[#a.looks+1]={["while"]="expiring",colour="#ff3333"}
end
end
local function j(a,b)
local a=h(a,b)
a.thickness,a.length,a.position=10,44,{point="TOP",to="icon"}
return a
end






local k={ring=true,ringColour="#ff3333",ringSize=2}
local function h(b,c)
local f,e=a.layer(b,"with-bar")
d(b,"with-bar")
if c then e.facts.expiring={{id="expiring",share=c}}end
local a=a.layer(b,"icon")
a.time={fontSize=18}
a.looks=a.looks or{}
a.looks[#a.looks+1]={["while"]={"debuff.missing","game.hostileTarget"},
unless={"notEnoughPower","outOfRange"},overlay=true,overlayColour="#0000004d"}
a.looks[#a.looks+1]={["while"]={"debuff.missing","game.hostileTarget"},border=k}
end

local function i(a,b)
local a=e.premade("warrior-"..a).record
a.baseSize=44
for b,a in ipairs(a.sources)do
for b,a in ipairs(a.layers or{})do
if a.kind=="icon"then a.width,a.height=nil,nil end
end
end
if b then b(a)end
return a
end
for a,b in pairs({
shieldblock=function(b)
d(b,"buff-bar",true)
j(b,"charges")
a.layer(b,"icon").time={fontSize=18}
end,
sunderarmor=function(b)
h(b)
local c=j(b,"stacks")

for b,a in ipairs(c.looks or{})do
if a["while"]=="atStacks"then a.colour="#b5e03c"end
end
for b,a in ipairs(a.layer(b,"number").looks or{})do
if a["while"]=="atStacks"then a.colour="#39ff00"end
end
end,
thunderclap=h,


demoshout=function(b)
h(b,15)
local b=a.layer(b,"icon")
b.opacity=a.BASE_OPACITY
b.looks={{["while"]={"debuff.missing","game.hostileTarget"},opacity=80,border=k}}
end,
rend=function(a)d(a,"bar")end,
taunt=false,
})do
i(a,b or nil)
end



l("enrage","Enrage",12880,{pop=false,glow=false,knownWith=12317})
l("flurry","Flurry",12966,{pop=false,glow=false,knownWith=12319},a.countFromOne)
l("bloodcraze","Blood Craze",16488,{pop=false,glow=false,knownWith=16487})



f("battleshout",a.onlyInCombat(a.extras(e.layout("icon").build({id="battleshout",name="Battle Shout",
spell=6673,lastPercent=10,castBy="anyone"}),{power=true,quiet=true,missingGlow=true,
expiringGlow=true})),{layout="icon"})


a.variant(c,"rend","bar",{unit="target",spell=772,colour=b.BLEED})
a.variant(c,"demoshout","bar",{unit="target",spell=1160,colour=b.EARTH})
a.variant(c,"sunderarmor","stacksTime",{form="strip",unit="target",spell=7386,colour=b.EARTH,
icon=true,number=true})
a.variant(c,"battleshout","icon",{form="reminder",spell=6673,lastPercent=10})
a.variant(c,"enrage","icon",{form="mark",spell=12880,knownWith=12317,colour=b.BLOOD})
a.variant(c,"deathwish","bar",{cooldown=true,spell=12328,colour=b.BLOOD})

a.variant(c,"mortalstrike","bar",{cooldown=true,spell=12294,colour=b.PHYSICAL})
local d={cooldown=true,spell=6343,with={unit="target",spell=6343},colour=b.FROST}
a.variant(c,"thunderclap","twinBars",g.copy(d))
a.variant(c,"thunderclap","bar",g.copy(d))
a.variant(c,"thunderclap","hourglass",g.copy(d))
local d={cooldown=true,spell=12328,with={spell=12328},colour=b.BLOOD}
a.variant(c,"deathwish","twinBars",g.copy(d))
a.variant(c,"deathwish","oneBar",g.copy(d))
a.variant(c,"deathwish","hourglass",g.copy(d))
a.variant(c,"battleshout","words",{spell=6673,lastPercent=10,when="missing",words="No shout",
late="Shout fading"})
a.variant(c,"battleshout","thinBar",{spell=6673,lastPercent=10,colour=b.PHYSICAL})
a.variant(c,"sunderarmor","icon",{unit="target",spell=7386,stacks=5})


for b,a in ipairs({"sunderarmor","sunderarmor-strip","sunderarmor-icon","demoshout","demoshout-bar"})do
e.markExperimental(c.prefix..a,n)
end





local d,g=18,96
local function c(e,f,h,i,a,c)
local d={id=e.."-icon",kind="icon",name=f,width=d,height=d,
sweep={enabled=false},time={enabled=false},count={enabled=false},
border={style={kind="line",thickness=1,colour="#000000"}},
looks={{["while"]="missing",desaturated=true}}}
if a then d.position={point="TOP",to=a,toPoint="BOTTOM",x=0,y=-3}end
local a={id=e.."-bar",kind="bar",name=c and"Stack strip"or"Time bar",length=g,
thickness=10,position={point="LEFT",to=d.id,toPoint="RIGHT",x=3,y=0},colour=i,
background={colour="#000000b3"}}
local d={id=e,kind="aura",unit="target",spells={h},castBy="anyone",layers={d,a}}
if c then
a.value,a.segments="stacks",c
d.facts={stacks={{id="atStacks",atLeast=c}}}
a.looks={{["while"]="atStacks",colour=b.HOLY}}
else
d.facts={expiring={{id="expiring",share=20}}}
a.looks={{["while"]="expiring",colour=b.ALARM}}
end
return d
end
f("tankdebuffs",a.knownWith({id="tankdebuffs",name="Tank debuffs",baseSize=d,
sources={
c("sunder","Sunder Armor",7386,b.EARTH,nil,5),
c("clap","Thunder Clap",6343,b.FROST,"sunder-icon"),
c("demo","Demoralizing Shout",1160,b.BLOOD,"clap-icon"),
},
quick={
{label="Sunder Armor row",part="sunder",field="enabled"},
{label="Thunder Clap row",part="clap",field="enabled"},
{label="Demoralizing Shout row",part="demo",field="enabled"},
}},7386),{experimental={n}})








local function b(b)
local d={id=b.id,name=b.name,sources={},customStates={},quick={}}
local g=b.casting and{"game.targetCasting","game.hostileTarget"}or{}
local e=b.casting and"a press would interrupt"or"a press would land"
local f={}
for c,a in ipairs(b.parts)do
local h=a.id.."-now"
local c={id=a.id.."-icon",kind="icon",name=a.name,
gcdSweep=not b.gcd and{enabled=false}or nil,
glows={{id=a.id.."-glow",name=a.name.."'s glow"}},looks={}}
if b.casting then
c.opacity=0
local a,b={"ready"},{"coolingDown"}
for d,c in ipairs(g)do a[#a+1],b[#b+1]=c,c end
c.looks[#c.looks+1]={["while"]=a,opacity=100}
c.looks[#c.looks+1]={["while"]=b,opacity=100,desaturated=true}
f[#f+1]=c.id
end
c.looks[#c.looks+1]={["while"]=h,glows={[a.id.."-glow"]={shown=true}}}

c.looks[#c.looks+1]={["while"]="notUsable",shown=false}
d.sources[#d.sources+1]={id=a.id,kind="spell",spells={a.spell},layers={c}}
local c,f={a.id..".ready"},{a.id..".outOfRange",a.id..".notEnoughPower",a.id..".notUsable"}
for b,a in ipairs(g)do c[#c+1]=a end
for b,a in ipairs(b.all or{})do c[#c+1]=a end
for b,a in ipairs(b.none or{})do f[#f+1]=a end

d.customStates[#d.customStates+1]={id=h,name=a.name..": "..e,all=c,none=f,
events={enters={effects={{id=a.id.."-pop",kind="pop"},
{id=a.id.."-sound",kind="sound"}}}}}
d.quick[#d.quick+1]={section=a.name,rows={
{label="Glow while "..e,part=a.id.."-glow",field="enabled"},
{label="Pop as "..e,part=a.id.."-pop",field="enabled"},
{label="Sound as "..e,part=a.id.."-sound",field="sound"},
}}
end
if b.casting then
local function a(b)
local a={}
for d,c in ipairs(f)do
a[#a+1]=b and{part=c,field="opacity",value=b}
or{part=c,field="opacity",clear=true}
end
return a
end
table.insert(d.quick,1,{label="Icons while your target isn't casting",choices={
{label="Hidden",writes=a(0)},{label="Faint",writes=a(30)},
{label="Shown",writes=a(nil)}}})
end
local a={s}
for c,b in ipairs(b.routes or{})do a[#a+1]=b end
return d,a
end

local c={state="ready",facts={notUsable=true}}


local d,g=b({id="bashorpummel",name="Shield Bash or Pummel",gcd=true,
casting=true,parts={{id="bash",name="Shield Bash",spell=72},{id="pummel",name="Pummel",
spell=6552}},routes={a.TARGET_CAST,m}})
f("bashorpummel",d,{experimental=g,
preview={bash="ready",pummel=c,game={"targetCasting","hostileTarget"}}})


local d,g=b({id="gapcloser",name="Charge or Intercept",
parts={{id="charge",name="Charge",spell=100},{id="intercept",name="Intercept",spell=20252}},
routes={m,t}})
d["while"]="game.hostileTarget"
f("gapcloser",d,{experimental=g,
preview={charge="ready",intercept=c,game={"hostileTarget"}}})



local b,d=b({id="taunts",name="Taunt or Mocking Blow",all={"game.inCombat"},
none={"threat.tanking"},
parts={{id="taunt",name="Taunt",spell=355},{id="mocking",name="Mocking Blow",spell=694}}})
d[#d+1]=a.THREAT
a.threatStrip(b)

a.source(b,"threat").events.losesAggro.effects[1].over={"taunt-icon","mocking-icon"}
f("taunts",b,{experimental=d,
preview={taunt="ready",mocking=c,threat="slipping",game={"inCombat","hostileTarget"}}})


e.registerUsable({
{"warrior-overpower","Overpower",7384,"WARRIOR"},
{"warrior-revenge","Revenge",6572,"WARRIOR"},
{"warrior-execute","Execute",5308,"WARRIOR",true,"rage"},
})









local d,f=60,a.BASE_OPACITY
local function c(b)
local b,c=a.layer(b,"icon")
a.look(c,b,"coolingDown",{opacity=d})
return b
end
local function b(a,b)
a.looks=a.looks or{}
a.looks[#a.looks+1]={unless=b or"game.hostileTarget",opacity=f}
end
b(c(e.premade("warrior-shieldblock").record),{"game.hostileTarget","game.inCombat"})

b(c(e.premade("warrior-thunderclap").record))
b((a.layer(e.premade("warrior-sunderarmor").record,"icon")))



local d=i("tauntthreat")
do
local a=a.layer(d,"strip")
a.thickness,a.length,a.position=8,44,{point="BOTTOM",toPoint="TOP",to="icon"}


a.looks={{["while"]="tanking",shown=true,colour="#33cc33",opacity=50},
{["while"]="slipping",shown=true,colour="#ffaa00"},
{["while"]="behind",shown=true,colour="#ff3333"}}
local a=c(d)
a.time={fontSize=18}
b(a)
a.glows=a.glows or{}
a.glows[#a.glows+1]={id="lost-glow",name="Glow while you've lost aggro"}
for c,b in ipairs({"threat.pulling","threat.behind"})do
a.looks[#a.looks+1]={["while"]=b,glows={["lost-glow"]={shown=true}}}
end
table.insert(d.quick,2,{label="Glow while you've lost aggro",part="lost-glow",field="enabled"})
end




local b=i("revenge")
do
local c=b.sources[1]
local a=c.layers[1]
c.facts.notUsable=nil
a.opacity,a.time=f,{fontSize=18}
a.looks={{["while"]={"ready","usable"},opacity=100,glows={["ready-glow"]={shown=true}}}}
table.insert(b.quick,1,{label="Icon while you can't use Revenge",choices={
{label="Dimmed",writes={{part="icon",field="shown",clear=true},
{part="icon",look="usable",field="shown",clear=true}}},
{label="Hidden",writes={{part="icon",field="shown",value=false},
{part="icon",look="usable",field="shown",value=true}}}}})
end
e.registerPremadeGroup("warrior-tanking",{label="Tanking",class="WARRIOR",arrangement="row",
members={"warrior-shieldblock","warrior-revenge","warrior-sunderarmor","warrior-thunderclap",
"warrior-demoshout","warrior-tauntthreat"}})


local a,b,c,d=a.art.BLOOD,a.art.OUTER,a.art.ABOVE,a.art.HIGHER
e.registerAlerts({


{"warrior-overpower-alert","WARRIOR",{id="overpower-alert",name="Overpower alert",spell=7384,
picture="genericTop1",above=c,colour=a,usable=true}},
{"warrior-revenge-alert","WARRIOR",{id="revenge-alert",name="Revenge alert",spell=6572,
picture="swordAndBoard",usable=true}},
{"warrior-execute-alert","WARRIOR",{id="execute-alert",name="Execute alert",spell=5308,
picture="suddenDeath",spread=b,usable=true,needsPower=true}},
{"warrior-victoryrush-alert","WARRIOR",{id="victoryrush-alert",name="Victory Rush alert",spell=402975,
knownWith=402927,picture="ultimatum",above=d}},
})
