


local a,e=...
local d=e.Blueprints
local o=d.kit
local b=o.colour

local h="A bar's name and time texts beside an aura's button (Layers.lua's own candidate)"
local q="A look on a cooldown's bar keyed on Cooling down and another buff's Present, hiding it (the split pane)"
local r="A stack strip and a time bar on one aura's button (AU-8)"
local s="A text's words and colour by state on an aura (a copy per state)"

local g={style={kind="line",thickness=1,colour="#000000"}}
local c={colour="#000000b3"}
local t=b.READY


local u={spell="an ID or a list, any one counting",unit="\"player\" (default) or \"target\"",
colour="the reading's colour (a named one: K.colour)",lastPercent="Expiring's share of the aura's length",
shows="\"lastSeen\": the last one up's icon while none is",castBy="\"anyone\": another player's copy counts"}
local function i(b)
local a={}
for b,c in pairs(u)do a[b]=c end
for b,c in pairs(b)do a[b]=c end
return a
end
local m="what a cooldown grants, a source of its own: { kind (\"aura\", \"totem\"), unit, spell, slot }"

local f=o.list
local j=o.auraSource
local function k(a)return{id="spell",kind="spell",spells=e.copy(f(a))}end


local function n(a)
if a.kind=="totem"then
return{id="totem",kind="totem",slot=a.slot,spells=a.spell and e.copy(f(a.spell))},"empty",nil
end
local b=a.unit or"player"
return{id=b=="target"and"debuff"or"buff",kind="aura",unit=b,spells=e.copy(f(a.spell))},
"missing",{h}
end

local function e(b,a)
local a={id="icon",kind="icon",sweep={enabled=false},time={enabled=false},
count=not a and{enabled=false}or nil}
for b,c in pairs(b or{})do a[b]=c end
return a
end
local function l(a)
return a.hidden and{["while"]="missing",shown=false}or{["while"]="missing",desaturated=true}
end
local function a(b,a)
a["while"]=b
return a
end


local function f(a,b)return{enabled=true,fontSize=a or 11,x=b}end





local p={}
function p.mark(c)
local d=j(c)
d.layers={e({border={style={kind="line",thickness=2,colour=c.colour}},
looks={a("missing",{shown=false}),
a("expiring",{border={colour=b.ALARM,ring=true,ringColour=b.ALARM,ringSize=2}})}})}
return{id=c.id,name=c.name,baseSize=16,sources={d}}
end
function p.reminder(c)
local d=j(c)
d.layers={e({time={fontSize=11,point="CENTER"},
border={style={kind="line",thickness=2,colour=b.ALARM}},
looks={a("present",{shown=false}),a("missing",{desaturated=true}),
a("expiring",{shown=true,border={colour=b.FADING}})}})}
return{
id=c.id,name=c.name,baseSize=24,sources={d},
quick={{label="Duration numbers",part="icon",field="time.enabled"}},
}
end





local function v(c)
if c.form then return assert(p[c.form],"no icon form "..tostring(c.form))(c)end
if c.cooldown then
local a=k(c.spell)
a.layers={{id="icon",kind="icon",gcdSweep={enabled=false}}}
return{id=c.id,name=c.name,sources={a},
quick={{label="Cooldown numbers",part="icon",field="time.enabled"}}}
end
local d={id="icon",kind="icon",sweep={enabled=false},count={enabled=false},
looks={l(c),a("expiring",{time={colour=b.ALARM}})}}
local e={id=c.id,name=c.name,
quick={{label="Duration numbers",part="icon",field="time.enabled"}}}
if c.hand then
d.looks[1]=a("missing",{desaturated=true,border={ring=true,ringColour=b.ALARM}})
d.count=nil
e.sources={{id="enchant",kind="weaponEnchant",hand=c.hand,
facts={expiring={{id="expiring",seconds=300}}},layers={d}}}
return e
end

d.time={fontSize=16,point="CENTER"}
local f=j(c)
f.layers={d}
e.sources={f}
if c.stacks then
f.facts=f.facts or{}
f.facts.stacks={{id="atStacks",atLeast=c.stacks}}

d.count={fromOne=true,fontSize=18,point="CENTER"}
d.time=nil
d.looks[#d.looks+1]=a("atStacks",{count={colour=b.HOLY}})
table.insert(e.quick,1,{label="Stack count",part="icon",field="count.enabled"})
end
return e
end

d.registerLayout("icon",{
label="Icon",word="icon",wordFor=function(a)return a.form end,
serves={"cooldown","buff","debuff","stacks","enchant"},
options=i({cooldown="true: a cooldown's icon",stacks="an aura's stack range from this many: its count gold",
hand="\"main\", \"off\": a hand's enchant",hidden="true: hidden while missing, not greyed",
form="a folded shape: \"mark\" (a small icon, a border of its colour), "
.."\"reminder\" (hidden while up with time to spare)"}),
quick={"Cooldown numbers","Duration numbers","Stack count"},
build=v,
})





local function p(a)
if a.barAt=="below"then return{point="TOP",toPoint="BOTTOM",x=0,y=-2}end
return{point="BOTTOM",toPoint="BOTTOM",x=0,y=0}
end
local function v(a)return a.barAt=="below"and 8 or 6 end




local function w(d)
if d.cooldown then
local b=k(d.spell)
local e,f=n(d.with)
b.layers={{id="icon",kind="icon",gcdSweep={enabled=false}}}
e.layers={{id="with-bar",kind="bar",name="Its time",thickness=v(d),position=p(d),
colour=d.colour,background=c,looks={a(f,{shown=false})}}}
return{
id=d.id,name=d.name,baseSize=36,sources={b,e},
quick={{label="Its time bar",part="with-bar",field="enabled"},
{label="Cooldown numbers",part="icon",field="time.enabled"}},
}
end
local f=j(d)
f.layers={
e({time={fontSize=16,point="CENTER"},
looks={l(d),a("expiring",{time={colour=b.ALARM}})}}),
{id="bar",kind="bar",name="Time bar",thickness=v(d),position=p(d),colour=d.colour,
background=c,looks={a("missing",{shown=false}),a("expiring",{colour=b.ALARM})}},
}
return{
id=d.id,name=d.name,baseSize=32,sources={f},
quick={{label="Time bar",part="bar",field="enabled"},
{label="Duration numbers",part="icon",field="time.enabled"}},
}
end

d.registerLayout("iconBar",{
label="Icon with a bar",word="icon bar",
wordFor=function(a)return not a.cooldown and a.barAt=="below"and"bar below"or nil end,
serves={"cooldownBuff","cooldownDebuff","cooldownTotem","buff","debuff"},
options=i({barAt="\"foot\" (default: inside the icon's foot) or \"below\"",cooldown="true: a cooldown's",
with=m,hidden="true: hidden while missing, not greyed"}),
quick={"Time bar","Its time bar","Cooldown numbers","Duration numbers"},
build=w,
})






local function p(d)
if d.cooldown and d.with then
local b=k(d.spell)
local e,h,i=n(d.with)
b.layers={{id="icon",kind="icon",gcdSweep={enabled=false},border=g,
time={fontSize=11}}}
e.layers={{id="with-bar",kind="bar",name="Its time",length=150,thickness=24,
position={point="LEFT",toPoint="RIGHT",x=2,y=0},colour=d.colour,background=c,
nameText=f(),time=f(12),looks={a(h,{time={shown=false}})}}}
return{
id=d.id,name=d.name,baseSize=24,sources={b,e},
quick={{label="Name on the bar",part="with-bar",field="nameText.enabled"},
{label="Cooldown numbers",part="icon",field="time.enabled"}},
},i
end
if d.cooldown then
local b=k(d.spell)
b.layers={
e({gcdSweep={enabled=false},border=g},true),
{id="bar",kind="bar",name="Cooldown bar",fills=true,length=150,thickness=24,
position={point="LEFT",toPoint="RIGHT",x=2,y=0},colour=d.colour,background=c,
nameText=f(11,5),time=f(12,-5),looks={a("ready",{time={shown=false}})}},
}
return{
id=d.id,name=d.name,baseSize=24,sources={b},
quick={{label="Name on the bar",part="bar",field="nameText.enabled"},
{label="Cooldown numbers",part="bar",field="time.enabled"}},
}
end
local i=j(d)
i.layers={
e({border=g,looks={l(d)}}),
{id="bar",kind="bar",name="Time bar",length=120,thickness=24,
position={point="LEFT",toPoint="RIGHT",x=2,y=0},colour=d.colour,background=c,
nameText=f(11,5),time=f(12,-5),
looks={a("missing",d.hidden and{shown=false}or{time={shown=false}}),
a("expiring",{colour=b.ALARM,time={colour=b.ALARM}})}},
}
return{
id=d.id,name=d.name,baseSize=24,sources={i},
quick={{label="Name on the bar",part="bar",field="nameText.enabled"},
{label="Duration numbers",part="bar",field="time.enabled"}},
},{h}
end

d.registerLayout("bar",{
label="Bar with its icon",word="bar",
serves={"debuff","buff","cooldown","cooldownBuff","cooldownDebuff","cooldownTotem"},
options=i({cooldown="true: a cooldown's",with=m,hidden="true: hidden while missing, not empty"}),
quick={"Name on the bar","Duration numbers","Cooldown numbers"},
routes={h},
build=p,
})






local function p(d)
local h=k(d.spell)
local i,j,k=n(d.with)
i.layers={{id="with-bar",kind="bar",name="Its time",length=150,thickness=15,
position={point="TOPLEFT",toPoint="TOPRIGHT",x=2,y=0},colour=d.colour,background=c,
nameText=f(10),time=f(10),looks={a(j,{time={shown=false}})}}}
h.layers={
e({gcdSweep={enabled=false},border=g,time={fontSize=11}},true),
{id="cd-bar",kind="bar",name="Cooldown bar",fills=true,length=150,thickness=7,
position={point="BOTTOMLEFT",toPoint="BOTTOMRIGHT",x=2,y=0},colour=b.OFF,
background=c,looks={a("ready",{colour=t})}},
}
return{
id=d.id,name=d.name,baseSize=24,sources={i,h},
quick={{label="Cooldown bar",part="cd-bar",field="enabled"},
{label="Cooldown numbers",part="icon",field="time.enabled"},
{label="Name on the bar",part="with-bar",field="nameText.enabled"}},
},k
end

d.registerLayout("twinBars",{
label="Twin bars",word="twin bars",
serves={"cooldownBuff","cooldownDebuff","cooldownTotem"},
options=i({with=m}),
quick={"Cooldown bar","Cooldown numbers","Name on the bar"},
routes={h},
build=p,
})


local p=170




local function v(d)
local j=k(d.spell)
local h,k,l=n(d.with)
local m=h.kind=="totem"and"down"or"present"
local i={q}
for b,a in ipairs(l or{})do i[#i+1]=a end
h.layers={{id="with-bar",kind="bar",name="Its time",length=p,thickness=24,
position={point="LEFT",toPoint="RIGHT",x=2,y=0},colour=d.colour,background=c,
nameText=f(),time=f(12),looks={a(k,{shown=false})}}}
j.layers={
e({gcdSweep={enabled=false},border=g},true),
{id="cd-bar",kind="bar",name="Cooldown bar",fills=true,length=p,thickness=24,
position={point="LEFT",toPoint="RIGHT",x=2,y=0},colour=b.OFF,background=c,
nameText=f(),time=f(12),
looks={a("ready",{colour=t,time={content="custom",words="Ready"}}),
a({"coolingDown",h.id.."."..m},{shown=false})}},
}
return{
id=d.id,name=d.name,baseSize=24,sources={h,j},
quick={{label="Name on the bar",part="cd-bar",field="nameText.enabled"}},
},i
end

d.registerLayout("oneBar",{
label="One bar, two jobs",word="one bar",
serves={"cooldownBuff","cooldownTotem"},
options=i({with=m}),
quick={"Name on the bar"},
routes={q,h},
build=v,
})




local function p(d)
local f=k(d.spell)
local g,h=n(d.with)
f.layers={
e({gcdSweep={enabled=false},looks={a("coolingDown",{desaturated=true})}},true),

{id="cd-bar",kind="bar",name="Cooldown bar",fills=true,thickness=6,
position={point="BOTTOM",toPoint="BOTTOM",x=0,y=0},colour=b.OFF,background=c,
looks={a("ready",{shown=false})}},
}
g.layers={{id="with-bar",kind="bar",name="Its time",thickness=6,
position={point="TOP",toPoint="TOP",x=0,y=0},colour=d.colour,background=c,
looks={a(h,{shown=false})}}}
return{
id=d.id,name=d.name,baseSize=36,sources={f,g},
quick={{label="Its time bar",part="with-bar",field="enabled"},
{label="Cooldown bar",part="cd-bar",field="enabled"}},
}
end

d.registerLayout("hourglass",{
label="Hourglass",word="hourglass",
serves={"cooldownBuff","cooldownDebuff"},
options=i({with=m}),
quick={"Its time bar","Cooldown bar"},
build=p,
})






local function m(d)
local e=j(d)
e.layers={
{id="bar",kind="bar",name="Time bar",length=170,thickness=16,
position={point="LEFT",toPoint="LEFT",x=0,y=0},colour=d.colour,background=c,
nameText=f(),time=f(),
looks={a("missing",{nameText={colour=b.OFF},time={shown=false}}),
a("expiring",{colour=b.ALARM,time={colour=b.ALARM}})}},
}
return{
id=d.id,name=d.name,baseSize=16,sources={e},
quick={{label="Name on the bar",part="bar",field="nameText.enabled"},
{label="Duration numbers",part="bar",field="time.enabled"}},
},{h}
end

d.registerLayout("barAlone",{
label="Bar alone",word="bar alone",
serves={"debuff","buff"},
options=i({}),
quick={"Name on the bar","Duration numbers"},
routes={h},
build=m,
})



local f=150
local function m(d)
local h=j(d)
h.layers={
e({border=g,looks={l(d)}}),
{id="bar",kind="bar",name="Time bar",length=f,thickness=4,
position={point="BOTTOMLEFT",toPoint="BOTTOMRIGHT",x=3,y=0},colour=d.colour,
background=c,looks={a("missing",{shown=false}),a("expiring",{colour=b.ALARM})}},
{id="name",kind="text",name="Name",content="name",fontSize=11,maxWidth=f-36,
position={point="BOTTOMLEFT",toPoint="BOTTOMRIGHT",x=3,y=6},
looks={a("missing",d.hidden and{shown=false}or{colour=b.OFF})}},
{id="time",kind="text",name="Time",fontSize=11,
position={point="BOTTOMRIGHT",toPoint="BOTTOMRIGHT",x=f+3,y=6},
looks={a("missing",{shown=false}),a("expiring",{colour=b.ALARM})}},
}
return{
id=d.id,name=d.name,baseSize=20,sources={h},
quick={{label="Name",part="name",field="enabled"},{label="Time",part="time",field="enabled"}},
}
end

d.registerLayout("thinBar",{
label="Thin bar",word="thin bar",
serves={"buff","debuff"},
options=i({hidden="true: its icon and name hidden while missing, not greyed"}),
quick={"Name","Time"},
build=m,
})





local function f(d)
local i=d.stacks or 5
local f=j(d)
f.facts={stacks={{id="atStacks",atLeast=i}}}
f.layers={}
local h={id=d.id,name=d.name,baseSize=d.icon and 20 or 14,sources={f},quick={}}
local c={id="stacks",kind="bar",name="Stack strip",value="stacks",segments=i,length=90,
thickness=d.icon and 12 or 14,colour=d.colour,background=c,
looks={a("missing",{shown=false}),a("atStacks",{colour=b.HOLY})}}
if d.icon then
f.layers[1]=e({border=g,looks={l(d)}})
c.position={point="LEFT",toPoint="RIGHT",x=3,y=0}
else
c.position={point="LEFT",toPoint="LEFT",x=0,y=0}
end
f.layers[#f.layers+1]=c
if d.number then
f.layers[#f.layers+1]={id="number",kind="text",name="Stack number",content="stacks",
fromOne=true,fontSize=18,position={point="LEFT",toPoint="LEFT",x=(d.icon and 23 or 0)+96,
y=0},looks={a("missing",{shown=false}),a("atStacks",{colour=b.HOLY})}}
h.quick[#h.quick+1]={label="Stack number",part="number",field="enabled"}
end
return h
end




local function m(d)
if d.form=="strip"then return f(d)end
local g=d.stacks or 5
local f=j(d)
f.facts=f.facts or{}
f.facts.stacks={{id="atStacks",atLeast=g}}
f.layers={
e({looks={l(d)}}),
{id="number",kind="text",name="Stack number",content="stacks",fromOne=true,fontSize=18,
position={point="CENTER",toPoint="CENTER",x=0,y=0},
looks={a("missing",{shown=false}),a("atStacks",{colour=b.HOLY})}},
{id="stacks",kind="bar",name="Stack strip",value="stacks",segments=g,thickness=6,
position={point="TOP",toPoint="BOTTOM",x=0,y=-1},colour=d.colour,background=c,
looks={a("missing",{shown=false}),a("atStacks",{colour=b.HOLY})}},
}
local e={
id=d.id,name=d.name,baseSize=32,sources={f},
quick={{label="Stack number",part="number",field="enabled"},
{label="Stack strip",part="stacks",field="enabled"}},
}
local g={point="TOP",toPoint="BOTTOM",x=0,y=-8}
if d.timeBar==false then



f.layers[4]={id="time",kind="text",name="Time",fontSize=10,
position={point="BOTTOM",toPoint="BOTTOM",x=0,y=-18},
looks={a("missing",{shown=false}),a("expiring",{colour=b.ALARM})}}
e.quick[3]={label="Time",part="time",field="enabled"}
return e
end
f.layers[4]={id="bar",kind="bar",name="Time bar",thickness=5,position=g,colour=b.TIME,
background=c,looks={a("missing",{shown=false}),a("expiring",{colour=b.ALARM})}}
e.quick[3]={label="Time bar",part="bar",field="enabled"}
return e,{r}
end

d.registerLayout("stacksTime",{
label="Stacks and time",word="stacks and time",wordFor=function(a)return a.form end,
serves={"stacks"},
options=i({stacks="the stack range's count: the strip's cells, gold at it",
timeBar="false: no time bar, its time a small number in the bar's place",hidden="true: hidden while missing, not greyed",
form="\"strip\": the cells beside the icon (icon: true), the count after them (number: true)"}),
quick={"Stack number","Stack strip","Time bar","Time"},
routes={r},
build=m,
})




local function f(d)
local f=j(d)
local e=e({border=g})
local c={id="words",kind="text",name="Words",fontSize=16,maxWidth=200,
position={point="LEFT",toPoint="RIGHT",x=5,y=0}}
if d.when=="missing"then
e.looks={a("present",{shown=false}),a("missing",{desaturated=true}),
a("expiring",{shown=true})}
c.content,c.words,c.colour="custom",d.words,b.ALARM
c.looks={a("present",{shown=false}),a("expiring",{shown=true,words=d.late,
colour=b.FADING})}
else
f.facts=nil
e.looks={a("missing",{shown=false})}
c.content,c.colour="name",b.HOLY
c.looks={a("missing",{shown=false})}
end
f.layers={e,c}
return{id=d.id,name=d.name,baseSize=20,sources={f},
quick={{label="Words",part="words",field="enabled"}}},{s}
end

d.registerLayout("words",{
label="Words while it matters",word="words",
serves={"buff"},
options=i({when="\"missing\" (a buff to keep up) or \"present\" (a proc)",
words="while missing: the words (\"No shield\")",late="while running out: the words (\"Shield fading\")"}),
quick={"Words"},
routes={s},
build=f,
})




local m="A cooldown's own bar upright (Bar.lua's mark: CD-5's route, untried upright)"

local n,p=28,80

local function f(a)return{enabled=true,fontSize=a or 11,justify="LEFT",x=0,y=3}end




local function q(d)
local i=d.cooldown
local f={id="bar",kind="bar",name=i and"Cooldown bar"or"Time bar",grows="up",
fills=i or nil,thickness=n,length=p,position={point="BOTTOM",toPoint="TOP",x=0,y=2},
colour=d.colour,background=c,border=g,time=f()}
local c={id=d.id,name=d.name,baseSize=n}
if i then
local b=k(d.spell)
f.looks={a("ready",{shown=false})}
b.layers={e({gcdSweep={enabled=false},border=g},true),f}
c.sources={b}
c.quick={{label="Cooldown numbers",part="bar",field="time.enabled"},
{label="Cooldown bar",part="bar",field="enabled"}}
return c,{m}
end
local i=j(d)

f.looks={a("missing",d.hidden and{shown=false}or{time={shown=false}}),
a("expiring",{colour=b.ALARM})}
i.layers={e({border=g,looks={l(d)}}),f}
c.sources={i}
c.quick={{label="Duration numbers",part="bar",field="time.enabled"},
{label="Time bar",part="bar",field="enabled"}}
return c,{h}
end

d.registerLayout("upright",{
label="Upright bar",word="upright",
serves={"buff","debuff","cooldown"},
options=i({cooldown="true: a cooldown's",hidden="true: hidden while missing, not empty"}),
quick={"Duration numbers","Time bar","Cooldown numbers","Cooldown bar"},
routes={h,m},
build=q,
})



local i="A time bar on a Spell Alert, beside its picture on the aura's button (never seen on an alert)"






local function e(d)
assert(not(d.usable or d.afterReset or d.stacks),"an alert's bar is a buff's time: "..tostring(d.id))
local e=o.procArt(d)



local a={id="bar",kind="bar",name="Time bar",grows="up",thickness=18,colour=d.barColour or b.TIME,
background=c,border=g,time=f(),looks={a("missing",{shown=false})}}
local b=e.sources[1].layers[1].id
if d.above then


a.length=56
a.position={point="TOP",to=b,toPoint="BOTTOM",x=0,y=-4}
else

a.length=120
a.position={point="LEFT",to=b,piece=2,toPoint="RIGHT",x=6,y=0}
end
e.sources[1].layers[2]=a
table.insert(e.quick,1,{label="Duration numbers",part="bar",field="time.enabled"})
table.insert(e.quick,1,{label="Time bar",part="bar",field="enabled"})
return e,{i,h}
end

d.registerLayout("alertBar",{

label="Alert with its bar",word="bar",
serves={"alert"},
options={spell=u.spell,picture="the Spell Alert's picture (Layers/Art.lua's keys)",
spread="a pair's Gap",above="a top picture's height over the centre",colour="the picture's tint",
barColour="the bar's colour (a named one: K.colour)",opacity="the picture's"},
quick={"Time bar","Duration numbers","Picture","Colour","Size","Sound"},
routes={i,h},
build=e,
})
