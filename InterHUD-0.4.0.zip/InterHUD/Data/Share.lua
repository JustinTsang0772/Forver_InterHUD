





































local b,a=...
local m,h,c,b,n,g,z,C=a.JSON,a.Clean,a.Schema,a.Store,a.Resolve,a.Spells,
a.Sounds,a.Combat
local j=a.Migrate

local e={}
a.Share=e



local function o(b)
if#b<=1 then return b[1]and tostring(b[1])or""end
local a={}
for b,c in ipairs(b)do a[b]=tostring(c)end
return table.concat(a,", ",1,#a-1).." and "..a[#a]
end
e.andList=o

local function s()
local b,a=UnitClass("player")
return a
end


local function d(a,b,c,d)return h.message(a,b,c or"",d)end


local k=c.walk
e.walk=k




local function i(b)
local a=#b
while a>0 and b:find("^%s",a)do a=a-1 end
return b:sub(1,a)
end


local function f(a)
if type(a)~="string"then return nil end
a=i(a)
local b=a:match("^.*()%(")
if b and a:find("^%(%s*[Rr]ank%s*%d+%s*%)$",b)then a=i(a:sub(1,b-1))end
return(a:gsub("^%s+","")):lower()
end


local function i()return a.SpellTable and a.SpellTable.families or{}end

local l
local function t(b)
if not l then
l={}
for a,b in pairs(a.SpellTable and a.SpellTable.racials or{})do
for c,b in ipairs(b.ids or{a})do l[b]=a end
end
end
local b=l[b]
if b then return b,a.SpellTable.racials[b]end
end


local l
local function r(a)
l=l or{}
if l[a]==nil then l[a]=g.nameOf(a)or false end
return l[a]or nil
end



local p
local function q(b,c)
p=p or{}
local a=p[b]
if not a then
a={f(c.name)or false,f(r(b))or false}
for c,b in ipairs(c.formerly or{})do
a.was=a.was or{}
a.was[f(b)or""]=true
end
p[b]=a
end
return a
end






local function u(b,e)
local b=f(b)
if not b or b==""then return{}end
local c,d={},{}
for b,a in ipairs({e or false,s()or false,true})do
if a and not d[a]then
d[a]=true
c[#c+1]=a
end
end
for c,d in ipairs(c)do
local c={}
for e,a in pairs(i())do
local a=(d==true or a.class==d)and q(e,a)
if a and(a[1]==b or a[2]==b or a.was and a.was[b])then
c[#c+1]=e
end
end
for a,d in pairs(d==true and a.SpellTable and a.SpellTable.racials or{})do
local d=q(a,d)
if d[1]==b or d[2]==b then c[#c+1]=a end
end
if#c>0 then
table.sort(c)
return c
end
end
return{}
end


function e.familyByName(a,b)
local a=u(a,b)
return#a==1 and a[1]or nil
end


local function w(b)
local a=i()[b]or(a.SpellTable and a.SpellTable.racials or{})[b]
if not a then return""end
local c=a.ranks or{b}
if#c<=1 then return a.name.." is "..b.."."end
local b={}
for a=2,#c do b[#b+1]=c[a]end
return a.name.." is "..c[1].." (Rank 1); its other ranks are "..o(b).."."
end

local function q(a,...)
local b=f(a)
for a=1,select("#",...)do
local a=f((select(a,...)))
if a and a==b then return true end
end
return false
end


local function v(a,b)
local a=u(a,b)
if#a==1 then return" "..w(a[1])end
return""
end



local function w(b)
local a,c={},{}
for e,d in ipairs({"player","target","ally","pet"})do
for d,b in ipairs(b.gives and b.gives[d]or{})do
local b=g.family(b)or b
if not c[b]then
c[b]=true
a[#a+1]=b
end
end
end
return a
end

local f
local function y(a)
if not f then
f={}
local a={}
for b in pairs(i())do a[#a+1]=b end
table.sort(a)
for b,a in ipairs(a)do
for c,b in ipairs(w(i()[a]))do f[b]=f[b]or a end
end
end
return f[a]
end

local function x(a)
return(#a==1 and"spell "or"spells ")..o(a)
end







local function A(a,b,f,h,d,k,l)
local e=r(a)
if not e then
local a=a.." doesn't exist."
if b then a=a..v(b,h.class)end
return nil,a
end
local j,c=g.family(a)
if c then
if b and not q(b,c.name,e,r(j))then

if not q(b,unpack(c.formerly or{}))then
return nil,a.." is "..c.name..", not \""..b.."\"."..v(b,h.class)
end
d[#d+1]=a.." is "..c.name.." now, not \""..b.."\" (the game renamed it); kept."
end
if f=="spell"and c.kind=="passive"then
local b=w(c)
return nil,a.." is "..c.name..", a passive: it can't be cast."
..(#b>0 and(" Watch its buff with an aura source, "..x(b)..".")or"")
end
if(f=="spell"or f=="known")and c.kind=="aura"then
local b=y(j)
return nil,a.." is "..c.name..", a buff or debuff, not a spell you cast"
..(b and("; "..i()[b].name.." ("..b..") gives it.")or".")
end
if f=="aura"and not c.auras then
local b=w(c)
d[#d+1]=a..": the spell table knows no buff or debuff "..c.name
.." puts up, so this may never show."
..(#b>0 and(" It gives "..x(b)..".")or"")
end


if(f=="aura"or f=="spell")and j~=a and not k then
for b,e in ipairs(c.ranks or{})do
if e==a then
d[#d+1]=a.." is "..c.name.." rank "..b..(f=="aura"
and(" and matches that rank alone; "..j.." matches every rank.")
or("; a cooldown casts your highest rank, so "..j.." is the same."))
end
end
end
local e=s()
if c.class and e and c.class~=e and not l then
d[#d+1]=a.." is a "..c.class:lower().." spell; this character is a "
..e:lower().."."
end
return c.name.." ("..a..")"..(b and", its name checked"or"")
end
local c=g.auraFamilies(a)
if c then
local d=i()[c[1]]
if f=="spell"then
return nil,a.." is "..d.name.."'s buff or debuff, not a spell you cast; its cooldown is "
..c[1].."."
end
if b and not q(b,e,d.name)then
return nil,a.." is "..e..", not \""..b.."\"."
end
return e.." ("..a.."), "..d.name.."'s"..(b and", its name checked"or"")
end


local f,c=t(a)
if c then
if b and not q(b,c.name,e)then
if h.locale~=nil and h.locale==GetLocale()then
return nil,a.." is "..c.name..", not \""..b.."\"."..v(b,h.class)
end
d[#d+1]=a.." is "..e.." here, not \""..b
.."\"; kept (it may be another language)."
return c.name.." ("..a..")"
end
return c.name.." ("..a..")"..(b and", its name checked"or"")
end

if b and not q(b,e)then
if h.locale~=nil and h.locale==GetLocale()then
return nil,a.." is "..e.." here, not \""..b.."\"."
end
d[#d+1]=a.." is "..e.." here, not \""..b
.."\"; kept (it may be another language)."
end
return e.." ("..a.."), by its ID alone"
end



local v
local function w(c,b,e,j,f,k,l,g,h)

local i=tostring(c).."\0"..(b and("="..b)or"-").."\0"..(e or"")..(g and"!"or"")
..(h and"*"or"")
local a=v[i]
if not a then
a={notes={}}
a.how,a.why=A(c,b,e,j,a.notes,g,h)
v[i]=a
end
for b,a in ipairs(a.notes)do f[#f+1]=d("note",k,l,a)end
return a.how,a.why
end








local function q(d,b)
if b~="aura"and b~="spell"and b~="known"then return d end
local c={}
for e,d in ipairs(d)do
local a=i()[d]or a.SpellTable.racials[d]
if a and(b=="aura"and a.auras or b=="spell"and a.kind=="spell"
or b=="known"and a.kind~="aura")then
c[#c+1]=d
end
end
return#c==1 and c or d
end
local function x(a,e,g,i,f,j,k)
local c,b=a,nil
if type(a)=="table"and not h.isList(a)then c,b=a.id,a.name end
if type(a)=="string"then c,b=nil,a end
if c==nil and type(b)=="string"then
local a=u(b,type(g.class)=="string"and g.class or nil)
if#a>1 then a=q(a,k)end
if#a==0 then

f[#f+1]=d("refuse",i,e,"\""..b.."\" names no spell this addon knows by"
.." name; give its spell ID.")
return nil,false
elseif#a>1 then
f[#f+1]=d("refuse",i,e,"\""..b.."\" names "..#a.." spells, "
..o(a).."; give the one you mean as its spell ID.")
return nil,false
end
c=a[1]
j[e]={name=b,found=true}
elseif type(b)=="string"then
j[e]={name=b}
end
return(type(a)=="table"and not h.isList(a)or type(a)=="string")and(c or a)or a,true
end


local function u(a,d)
if type(a)~="table"then return false end
local c,b={},0
for d,a in ipairs(d or{})do
c[a]=true
b=b+1
end
if#a==0 then return b==0 end
if#a~=b then return false end
for b,a in ipairs(a)do
if not c[a]then return false end
end
return true
end


local function q(a,e,f,g,b)
if#e==0 then return end
if not c.field("source","exact",a.kind)then
b[#b+1]=d("note",g,f,"This source doesn't take exact; left out.")
return
end
local b,c=type(a.exact)=="table"and h.isList(a.exact)and a.exact or{},{}
for b,a in ipairs(b)do c[a]=true end
for d,a in ipairs(e)do
if not c[a]then
c[a]=true
b[#b+1]=a
end
end
a.exact=b
end
local function D(b,k,m,g,n,o,i)
if type(b.kind)~="string"or not c.has("source")or not c.get("source").variants[b.kind]then return true end
for f,e in ipairs(c.fieldsOf("source",b.kind))do
local f=b[e.name]
if e.type=="spell"and f~=nil then
local a,c=x(f,k.."."..e.name,m,g,n,o)
if not c then return false end
b[e.name]=a

elseif e.type=="spells"and type(f)=="table"and#f<=(e.maxItems or c.MAX_SPELLS)then
local l={}
for p,j in ipairs(f)do
local c=type(j)=="table"and not h.isList(j)and j or nil
local q=c and c.exact==true
local h=k.."."..e.name.."["..p.."]"

if c and c.exact~=nil and type(c.exact)~="boolean"then
i[#i+1]=d("note",g,h..".exact","exact takes true or false; left out.")
end
local e,j=x(j,h,m,g,n,o,b.kind)
if not j then return false end
f[p]=e
if q and type(e)=="number"then l[#l+1]=e end
if c and c.matches~=nil and not u(c.matches,
not q and a.Sources.matchesOf(b,e)or nil)then
i[#i+1]=d("note",g,h,tostring(e).."'s matches differ from this version's;"
.." this version's are used.")
end
end
q(b,l,k.."."..e.name,g,i)
end
end
return true
end



local u={}
for b,a in ipairs(c.fieldsOf("envelope"))do u[a.name]=true end
local y={elements={"elements","groups","styles","presets"},profile={"profile"}}
local A={"class","locale","name","description"}

local function f(a,b)
a.stop=b
a.ok=false
return a
end

local function i(a)
return type(a)=="table"and(a.sources~=nil or a.source~=nil or a.layers~=nil or(a.id~=nil and a.kind==nil))
end

local q='{"kind": "elements", "elements": [ ... ], "interhud": '..b.VERSION..'}'





local function B(b,e)
local f=b.kind=="profile"and b.profile.groups or b.groups
for a,c in ipairs(type(f)=="table"and f or{})do f[a]=j.group(c,b.interhud)end

if b.kind=="profile"and j.dropSwing(b.profile,b.interhud)then
e.notes[#e.notes+1]=d("note",nil,"",j.SWING_GONE)
end
local d=b.kind=="profile"and b.profile.elements or b.elements
if type(d)~="table"
or#d>c.field(b.kind=="profile"and"profile"or"envelope","elements").maxItems then return end
for f,c in ipairs(d)do
local a,b,g=a.try("format step",j.element,c,b.interhud)
if a then
d[f]=b
local b=type(c)=="table"and type(c.id)=="string"and c.id or("elements["..f.."]")
for c,a in ipairs(g)do
a.unit=b
e.notes[#e.notes+1]=a
end
end
end
end


local function E(a,e)
local k,g=m.tidy(a)
if not k then

local a=m.tidyText(a)
if a~=""and not a:find('"interhud"%s*:')then
local b,a=pcall(C_EncodingUtil.DeserializeJSON,a)
if b and type(a)=="table"and(i(a)or i(a[1]))then
f(e,"This is an element without its wrapper: put it inside "..q..".")
return nil
end
end
f(e,g)
return nil
end
local a
a,g=m.decode(k)
if not a then
f(e,g)
return nil
end


if type(a.interhud)=="number"and a.interhud%1~=0 then
f(e,"This text's format number, "..a.interhud..", isn't one InterHUD writes, so it can't be read."
.." Make the export again in InterHUD.")
return nil
end
if type(a.interhud)=="number"and a.interhud>b.VERSION then
f(e,"This was made by a newer InterHUD (format "..a.interhud.."; this one reads "
..b.VERSION.."): update InterHUD first.")
return nil
end
if a.kind==nil then
if i(a)then
f(e,"This is an element without its wrapper: put it inside "..q..".")
else
f(e,'The text has no "kind": add "kind": "elements" (with its "elements": [ ... ]) or "kind": "profile"'
..' (with its "profile": { ... }).')
end
return nil
end
if not y[a.kind]then
local b='"kind" is '..string.format("%q",h.cut(tostring(a.kind),60))
if i(a.element)then

f(e,b..' and "element" holds one element: an element travels in a list, '..q..'.')
else
f(e,b..': use "elements" (as '..q..') or "profile".')
end
return nil
end

if type(a.interhud)=="number"and a.interhud<j.OLDEST then
f(e,"This was made before format "..j.OLDEST..", whose records this InterHUD can't read; make it"
.." again here.")
return nil
end

local i=i(a.element)

local g={}
for a in pairs(a)do g[#g+1]=tostring(a)end
table.sort(g)
for c,b in ipairs(g)do
if not u[b]then
e.notes[#e.notes+1]=d("note",nil,b,"isn't read here; ignored.")
a[b]=nil
end
end


for f,b in ipairs(A)do
if a[b]~=nil then
local f=h.newCtx("import")
if h.cleanValue(c.field("envelope",b),a[b],f,b)==h.FAIL then
local c=f.messages[1]and f.messages[1].text or"can't be read."
e.notes[#e.notes+1]=d("note",nil,b,(c:gsub("%.$","")).."; ignored.")
a[b]=nil
end
end
end

for b,c in pairs(y)do
if b~=a.kind then
for c,b in ipairs(c)do
if a[b]~=nil then
e.notes[#e.notes+1]=d("note",nil,b,"is ignored: \"kind\" is \""..a.kind.."\".")
a[b]=nil
end
end
end
end
if a.kind=="elements"and type(a.elements)~="table"then
f(e,(i and'"element" holds one element: put it in a list, "elements": [ { ... } ]. '
or"")..'An "elements" text carries its elements in a list: '..q..".")
return nil
end
if a.kind=="profile"and type(a.profile)~="table"then
f(e,'A "profile" text carries the profile as "profile": { ... }, before "interhud".')
return nil
end
if type(a.interhud)=="number"and a.interhud<b.VERSION then B(a,e)end
return a
end


local function i(a)
if a.name then return a.name end
local a=type(a.sources)=="table"and a.sources[1]
local a=type(a)=="table"and type(a.spells)=="table"and a.spells[1]

return type(a)=="number"and(r(a)or g.label(a))or nil
end


local function A(a)return i(a)or a.id end




local function q(a,f,c)
local e={}
for a,b in ipairs(a or{})do
local a=type(b.members)=="table"and b.members or{}
local g=#a
for e=#a,1,-1 do
if not f(a[e])then
c[#c+1]=d("note",b.id,"","member \""..tostring(a[e])
.."\" isn't arriving; left out.")
table.remove(a,e)
end
end
if g>0 and#a==0 then
c[#c+1]=d("note",b.id,"","none of its members arrive; left out.")
else
if#a==0 then b.members=nil end
e[#e+1]=b
end
end
return e
end




local function r(b,e,f,c)
local a=g.alias(b)
if a~=b then
c.notes[#c.notes+1]=d("note",e,f,b.." is now "..a.." (the game moved its ID); read as "
..a..".")
end
return a
end

local function F(b,l,c,n)
local f,i={},{}
for e,b in ipairs(b or{})do
local e=b.id
local h

local j={}
local function m(a)
if j[a]then return end
j[a]=true
c.spells[#c.spells+1]=d("note",e,"",a)
end
local n=n[e]or{}
k("element",b,{},"",function(i,b,j,f)
if h then return false end
if i.type=="spells"then
local o=a.Sources.exactSet(j.exact)
for g,k in ipairs(b)do
local p=k
b[g]=r(k,e,f.."["..g.."]",c)
k=b[g]
local f=f.."["..g.."]"
local b=n[f]
local g=i.name=="onlyWhileYouKnow"and"known"or j.kind
local a,c=w(k,b and not b.found and b.name or nil,g,l,c.notes,
e,f,o and o[p],
g=="aura"and j.castBy=="anyone"and not a.Sources.get("aura").onEnemy(j.unit))
if not a then
h=d("refuse",e,f,c)
return false
end

m(a..(b and b.found and", found by its name"or"")..".")
end
elseif i==a.Sources.EXACT then

for a,c in ipairs(b)do b[a]=g.alias(c)end
elseif i.type=="spell"then
b=r(b,e,f,c)
j[i.name]=b
local a=n[f]
local b,c=w(b,a and not a.found and a.name or nil,nil,l,c.notes,e,f)
if not b then
h=d("refuse",e,f,c)
return false
end
m(b..(a and a.found and", found by its name"or"")..".")
end
end)
if h then
c.refused[#c.refused+1]=h
i[b.id]=true
else
f[#f+1]=b
end
end
return f,i
end




local r


local function G(b,a)
for c,b in ipairs(b or{})do
k("element",b,{},"",function(e,c,g,f)
if e.type=="sound"then
local e=z.missing(c)
a.sounds[#a.sounds+1]=d("note",b.id,f,"plays a sound, "..(z.label(c)or c)
..(e and"; it isn't here, so it plays nothing until it is."or"."))
for c,a in ipairs(a.arrivals)do
if a.kind=="element"and a.id==b.id then
a.sound=true
a.missing=a.missing or e
end
end
end
end)
end
end


local function H(b,e,i)


local f,j={kids={}},{}
for b,k in ipairs(b or{})do
local b,h=a.try("share: resolve",n.element,k,e)
local l={}

local e={}

local function m(a,f,g,b)
if f>8 then return end
b.sit=b.sit or c.caveatsSitting(e,j)
for b,a in ipairs(b.sit)do
if not l[a.key]and a.applies(h,e,j)then
l[a.key]=true
i.caveats[#i.caveats+1]=d("note",k.id,"",a.text)
end
end
if type(a)~="table"or g[a]then return end
g[a]=true
for a,d in pairs(a)do

if type(d)=="table"or type(a)~="number"then
local c=b.kids[a]
if not c then
c={kids={}}
b.kids[a]=c
end
e[f+1]=a
m(d,f+1,g,c)
e[f+1]=nil
end
end
g[a]=nil
end

if b and h then a.try("share: caveats",m,h,0,{},f)end
end
end





local function I(f,g,e)
local b={}
if type(f)~="table"then return b end
for c,a in ipairs(c.fieldsOf("specials"))do
local c=(a.label or a.name).." settings"
if type(g)=="table"and g[a.name]~=nil then
b[#b+1]=c
elseif f[a.name]~=nil then
local a="profile.specials."..a.name
for f,b in ipairs(e.refused)do
if b.path==a or b.path:sub(1,#a+1)==a.."."or b.path:sub(1,#a+1)==a.."["then
e.refused[#e.refused+1]=d("refuse",nil,"",c.." refused; the profile arrives without them.")
break
end
end
end
end
return b
end



local function j(a,c)
if not c[a]then return a end
local b=2
while true do
local d="-"..b
local a=a:sub(1,32-#d)..d
if not c[a]then return a end
b=b+1
end
end
e.freeId=j




local function J(a,c)
for c,a in ipairs({a or false,c or false,"Imported"})do
local b=a and b.freeName(a)
if b then return b,a end
end
return"Imported","Imported"
end




local function z(c,e,a)
a=a or{}
local b={}
for d,c in ipairs({"elements","groups"})do
for c,a in ipairs(a[c]or{})do b[a.id]=true end
end
for c,a in ipairs(c)do b[a.id]=b[a.id]or"arriving"end
for c,a in ipairs(e)do b[a.id]=b[a.id]or"arriving"end
local d={element={},group={}}
for b,a in ipairs(a.elements or{})do d.element[a.id]=a end
for b,a in ipairs(a.groups or{})do d.group[a.id]=a end
local f,g={},0
local function a(e,a)
local h=b[a.id]==true
local c={kind=e,id=a.id,label=e=="element"and A(a)or(a.name or a.id),
clash=h,replaces=d[e][a.id]and true or nil}
if e=="group"and c.replaces then
local b={}
for c,a in ipairs(a.members or{})do b[a]=true end
for d,a in ipairs(d.group[a.id].members or{})do
if not b[a]then
c.leaving=c.leaving or{}
c.leaving[#c.leaving+1]=a
end
end
end
if h then
g=g+1
c.newId=j(a.id,b)
b[c.newId]="arriving"
end
f[#f+1]=c
end
for c,b in ipairs(c)do a("element",b)end
for c,b in ipairs(e)do a("group",b)end
return f,g
end






function e.newNames(a,b,d)
if not(a and a.kind=="elements")then return{}end
local e={}
for c,a in ipairs(a and a.arrivals or{})do
if a.kind=="element"and a.replaces and b and b.replace then e[a.id]=true end
end
local b={}
for c,a in ipairs(type(d)=="table"and d.elements or{})do
local a=not e[a.id]and i(a)
if a then b[a:lower()]=true end
end
local function e(a)return b[a:lower()]==true end
local d,f={},{}
for a,c in ipairs(a and a.elements or{})do
local a=i(c)
if a and e(a)then
d[#d+1]=c
elseif a then
b[a:lower()]=true
end
end
local g=c.field("element","name").max
for d,a in ipairs(d)do
local c=c.numberedName(i(a),g,e)
b[c:lower()]=true
f[a.id]=c
end
return f
end



function e.duplicateName(d,a)
local b={}
for c,a in ipairs(type(a)=="table"and a.elements or{})do
local a=i(a)
if a then b[a:lower()]=true end
end
local a=i(d)
if not a then return nil end
return c.numberedName(a,c.field("element","name").max,function(a)return b[a:lower()]==true end)
end






local A={differs=true,renamed=true,added=true}
local function B(b,f,d)
local g=type(d)=="table"and type(d.presets)=="table"and d.presets or{}
b=type(b)=="table"and b or{}

local e,d={},{}
for a,f in ipairs(f or{})do
c.eachStyleField("element",f,{},function(c,a,b,g)
if a.preset==nil then return end
local b=e[c.style]or{}
e[c.style]=b
if not b[a.preset]then
b[a.preset]={}
d[#d+1]={part=c.style,id=a.preset}
end
table.insert(b[a.preset],{unit=f.id,path=g})
end)
end
local n=c.field("stylePreset:border","name").max
local f,h={},{}
for i,d in ipairs(c.STYLE_PARTS)do
local i,k=g[d]or{},b[d]or{}
local g,b,l={},{},{}
for c,a in ipairs(i)do
g[a.id],b[a.name:lower()],l[a.id]=true,true,a
end
for b,a in ipairs(k)do g[a.id]=g[a.id]or"arriving"end
local function m(a)return b[a:lower()]end
h[d]={}
local i={}
for c,b in ipairs(k)do
h[d][b.id]=true
local c={part=d,id=b.id,name=b.name,style=a.copy(b.style)}
local h=l[b.id]
if not(e[d]and e[d][b.id])then
c.outcome="unused"
elseif h and a.equal(h.style or{},b.style or{})then
c.outcome,c.yours="same",h.name
else
if h then
c.newId=j(b.id,g)
g[c.newId]="arriving"
end
c.differs=h~=nil
i[#i+1]=c
end
f[#f+1]=c
end

for c,a in ipairs(i)do
if not m(a.name)then
b[a.name:lower()],a.keeps=true,true
end
end
for d,a in ipairs(i)do
if not a.keeps then

a.newName=c.numberedName(a.name,n,m)
b[a.newName:lower()]=true
end
a.outcome=a.differs and"differs"or(a.keeps and"added"or"renamed")
a.differs,a.keeps=nil,nil
end
end
for b,a in ipairs(d)do
if not(h[a.part]and h[a.part][a.id])then
local b
for d,c in ipairs(g[a.part]or{})do
if c.id==a.id then b=c end
end
f[#f+1]={part=a.part,id=a.id,outcome=b and"yours"or"missing",
yours=b and b.name or nil,at=e[a.part][a.id]}
end
end
return f
end



local function K(b,a)
local f=type(a)=="table"and type(a.presets)=="table"and a.presets or{}
b=type(b)=="table"and b or{}
local d={}
for a,c in ipairs(c.STYLE_PARTS)do
local a,e={},{}
for c,b in ipairs(b[c]or{})do
a[#a+1],e[b.id]=b,true
end
for c,b in ipairs(f[c]or{})do
if not e[b.id]then a[#a+1]=b end
end
if#a>0 then d[c]=a end
end
return d
end

local function i(b)
local a=a.Styles.spec(b)
return a and a.label or b
end

local function j(a,b)return a.." "..b..(a==1 and""or"s")end

function e.presetLines(a,e)
local c=a and a.presets or{}
local b={}
if not e then
local a=0
for c,b in ipairs(c)do
if b.outcome~="yours"and b.outcome~="missing"then a=a+1 end
end
if a==1 then return{"Its preset is left out: it takes your styles."}end
if a>1 then b[1]="Its "..a.." presets are left out: it takes your styles."end
return b
end
local a={}
for c,b in ipairs(c)do
if b.outcome=="added"then a[#a+1]=b.name.." ("..i(b.part)..")"end
end
if#a>0 then b[1]="Adds "..j(#a,"preset")..": "..o(a).."."end
local e={}
for c,a in ipairs(c)do
local c=a.name and(a.name.." ("..i(a.part)..")")
if a.outcome=="differs"then
b[#b+1]=c.." differs from yours: arrives "
..(a.newName and("as "..a.newName)or"beside it").."."
elseif a.outcome=="renamed"then
b[#b+1]=c..": arrives as "..a.newName.."."
elseif a.outcome=="same"then
b[#b+1]="Uses your "..a.yours.." ("..i(a.part).."): the same."
elseif a.outcome=="yours"then
b[#b+1]="Uses your "..a.yours.." ("..i(a.part)..")."
elseif a.outcome=="unused"then
b[#b+1]=c..": nothing arriving follows it; left out."
elseif a.outcome=="missing"then
for c,b in ipairs(a.at)do
e[#e+1]=d("note",b.unit,b.path,string.format("names no %s preset %q; left out.",
i(a.part),a.id))
end
end
end
for c,a in ipairs(h.lines(e))do b[#b+1]=a end
return b
end



local function L(c,d)
if b.profileName()~=c.checkedIn then return false end
if c.kind=="elements"and d.styles
and not a.equal(B(c.presetsIn,c.elements,b.profile()),c.presets or{})then
return false
end
local d=z(c.elements,c.groups,b.profile())
if#d~=#c.arrivals then return false end
for c,b in ipairs(c.arrivals)do
local c=d[c]
if c.kind~=b.kind or c.id~=b.id or c.clash~=b.clash or c.replaces~=b.replaces or c.newId~=b.newId
or not a.equal(c.leaving,b.leaving)then
return false
end
end
return true
end




function e.overCap(a,d)
if not(a and a.kind=="elements"and a.arrivals)then return nil end
local e=b.ready()and b.profile()or{}
if d and d.styles then
for b,d in ipairs(c.STYLE_PARTS)do
local b=0
for c,a in ipairs(a.presets or{})do
if a.part==d and A[a.outcome]then b=b+1 end
end
local a=#(type(e.presets)=="table"and e.presets[d]or{})
if b>0 and a+b>c.PRESETS_MAX then
return"A style holds at most "..c.PRESETS_MAX.." presets; "..i(d).." has "..a
..", and this adds "..b.."."
end
end
end
for f,b in ipairs({{"elements","element"},{"groups","group"}})do
local f=c.field("profile",b[1]).maxItems
local e,c=#(e[b[1]]or{}),0
for e,a in ipairs(a.arrivals)do
if a.kind==b[2]and not(d and d.replace and a.replaces)then c=c+1 end
end
if f and e+c>f then
return"A profile holds at most "..f.." "..b[1].."; this one has "..e..", and this adds "
..c.."."
end
end
end

local function o()
l,p,v={},nil,{}
return{refused={},notes={},spells={},sounds={},caveats={},arrivals={},elements={},groups={},
clashes=0}
end
local i


local function l(d,b)
local c=a.SFImport
local e,a,d=a.try("ShamanForever import",c.read,d)
if not e then return f(b,c.FAULT)end
if not a then return f(b,d)end
b=i(a,b)
b.shamanForever=true
b.opening=c.OPENING
for c,a in ipairs(d.notes)do b.notes[#b.notes+1]=a end
return b
end
function e.check(c)
local b=o()
if a.SFImport.isExport(c)then return l(c,b)end
local a=E(c,b)
if not a then return b end
return i(a,b)
end



function e.checkEnvelope(a)
assert(type(a)=="table"and y[a.kind],"an envelope of kind elements or profile")
assert(type(a.kind=="profile"and a.profile or a.elements)=="table","the envelope's payload")
for a in pairs(a)do assert(u[a],"not an envelope field: "..tostring(a))end
return i(a,o())
end
function i(d,a)
a.kind=d.kind

local g=d.kind=="profile"and(type(d.profile.elements)=="table"and d.profile.elements or{})
or d.elements
local k,l={},{}


local i=c.field(d.kind=="profile"and"profile"or"envelope","elements").maxItems
if type(g)=="table"and#g<=i then
for i=#g,1,-1 do
local b=g[i]
if type(b)=="table"then
local f=type(b.id)=="string"and b.id or("elements["..i.."]")
local h,j,e={},{},true

local m=type(b.sources)=="table"and#b.sources<=c.field("element","sources").maxItems
and b.sources or{}
for c,b in ipairs(m)do
if e and type(b)=="table"then
e=D(b,"sources["..c.."]",d,f,j,h,a.notes)
end
end

local b=b.onlyWhileYouKnow
if e and type(b)=="table"and#b<=c.field("element","onlyWhileYouKnow").maxItems then
for a,c in ipairs(b)do
local c,d=x(c,"onlyWhileYouKnow["..a.."]",d,f,j,h,"known")
if not d then
e=false
break
end
b[a]=c
end
end
if not e then
for c,b in ipairs(j)do table.insert(a.refused,1,b)end
l[f]=true
table.remove(g,i)
elseif next(h)then
k[f]=h
end
end
end
end

a.sentStyles={}
for b in pairs(type(d.styles)=="table"and d.styles or{})do a.sentStyles[b]=true end

local g,i=h.clean("envelope",d,"import",
{buttonCues=d.kind=="elements"and b.ready()and b.profile().buttonCues or false})
for c,b in ipairs(i.messages)do a.refused[#a.refused+1]=b end
for c,b in ipairs(i.notes)do a.notes[#a.notes+1]=b end
if not g then
return f(a,"Nothing in it could be read; fix what's listed and check again.")
end
a.name,a.description,a.class,a.locale=g.name,g.description,g.class,g.locale
local f=d.kind=="profile"and(g.profile or{})or g
local i
f.elements,i=F(f.elements,g,a,k)
for a in pairs(l)do i[a]=true end
if d.kind=="elements"then

local d={}
for b,a in ipairs(f.elements or{})do d[a.id]=true end
local d={elements=f.elements,
groups=q(g.groups,function(a)return d[a]end,a.notes)}
if#d.groups==0 then d.groups=nil end
local e=h.newCtx("import")
for b,a in ipairs(c.get("profile").rules)do a.fn(d,e,"")end
for c,b in ipairs(e.messages)do a.refused[#a.refused+1]=b end
for c,b in ipairs(e.notes)do a.notes[#a.notes+1]=b end
a.elements,a.groups,a.styles=d.elements or{},d.groups or{},g.styles
a.presetsIn=g.presets
a.presets=B(g.presets,a.elements,b.ready()and b.profile()or nil)
else
f.groups=q(f.groups,function(a)return not i[a]end,a.notes)
if#f.groups==0 then f.groups=nil end
a.profile=f
a.elements,a.groups=f.elements or{},f.groups or{}
r(f,g,a)
a.specials=I(d.profile.specials,f.specials,a)
a.profileName,a.profileBase=J(f.name,g.name)
end
a.checkedIn=b.ready()and b.profileName()or nil

a.arrivals,a.clashes=z(a.elements,a.groups,
d.kind=="elements"and b.ready()and b.profile()or nil)
G(a.elements,a)
local c=d.kind=="profile"and a.profile
or{elements=a.elements,groups=a.groups,styles=b.ready()and b.profile().styles or nil,
presets=K(a.presetsIn,b.ready()and b.profile()or nil)}
H(a.elements,c,a)
if d.kind=="profile"then
a.ok=true
local c={j(#a.elements,"element"),j(#a.groups,"group")}
local d=0
for b,a in pairs(type(a.profile.presets)=="table"and a.profile.presets or{})do d=d+#a end
if d>0 then c[#c+1]=j(d,"preset")end

local function d(a)return type(a)=="table"and next(a)~=nil end
if d(a.profile.styles)and d(a.profile.buttonCues)then
c[#c+1]="Global styles and fact looks"
end
for b,a in ipairs(a.specials)do c[#c+1]=a end
a.lands="A new profile, \""..a.profileName.."\" ("..table.concat(c,", ")..")."

local b=b.profilesFull()
if b then a.ok,a.lands=false,b end
else
a.ok=#a.elements+#a.groups>0

a.lands=a.ok and("Adds to this profile"..(b.ready()and(", \""..b.profileName().."\"")or"")
..": "..j(#a.elements,"element")..", "..j(#a.groups,"group")..".")
or"Nothing in it can be added."

local b=a.ok and e.overCap(a,{replace=true})
if b then a.ok,a.lands=false,b end
end
return a
end





local function i(a)
c.eachStyleField("element",a,{},function(a,c,b)b[a.name]=nil end)
end
e.dropStyles=i


function e.dropOwnStyles(a)
c.eachProfileStyleField(a,function(a,c,b)b[a.name]=nil end)
end



local function l(a,d)
c.eachStyleField("element",a,{},function(a,c,e)
local b
if c.preset~=nil and d[a.style]then b=d[a.style][c.preset]end
if b==false then
e[a.name]=nil
elseif b then
e[a.name]={preset=b}
end
end)
end




local function o(b,d,f,g)
local e={}
for b in pairs(f or{})do
local c=n.styles({styles={[b]=d and d[b]or{}}})[b]
if not a.equal(c,g[b])then e[b]=true end
end
if next(e)==nil then return end
c.eachStyleSlot("element",b,{},function(b,c,f)
if c==nil and e[b.style]then f[b.name]=a.Styles.asOwn(b.style,d and d[b.style])end
end)
end








function e.merge(g,c,d)
local b=a.copy(g or{})
b.elements,b.groups=b.elements or{},b.groups or{}
local m=n.styles(g or{})


local f={}
if d.styles then
for d,c in ipairs(c.presets or{})do
f[c.part]=f[c.part]or{}
if A[c.outcome]then
b.presets=b.presets or{}
local d=b.presets[c.part]or{}
b.presets[c.part]=d
d[#d+1]={id=c.newId or c.id,name=c.newName or c.name,style=a.copy(c.style)}
if c.newId then f[c.part][c.id]=c.newId end
elseif c.outcome=="missing"then
f[c.part][c.id]=false
end
end
end
local j,k={},{}
for b,a in ipairs(c.groups)do
for b,a in ipairs(a.members or{})do k[a]=true end
end
local h={}
for b,a in ipairs(c.arrivals)do h[a.kind..":"..a.id]=a end
local n=e.newNames(c,d,g)
local function e(a,b)
for a,c in ipairs(a)do
if c.id==b then return a end
end
end
for p,g in ipairs(c.elements)do
local a=a.copy(g)
a.name=n[g.id]or a.name
if d.styles then
l(a,f)
o(a,c.styles,c.sentStyles,m)
else
i(a)
end
local c=h["element:"..a.id]

local d=c and c.replaces and d.replace and e(b.elements,a.id)
if d then
if k[a.id]then
for c,b in ipairs(b.groups)do
for c=#(b.members or{}),1,-1 do
if b.members[c]==a.id then table.remove(b.members,c)end
end
end
else
a.position=b.elements[d].position
end
b.elements[d]=a
else
if c and c.clash then
j[a.id]=c.newId
a.id=c.newId
end
b.elements[#b.elements+1]=a
end
end
for f,c in ipairs(c.groups)do
local a=a.copy(c)
for c,b in ipairs(a.members or{})do a.members[c]=j[b]or b end
local f={}
for b,a in ipairs(a.members or{})do f[a]=true end
local c=h["group:"..a.id]
local d=c and c.replaces and d.replace and e(b.groups,a.id)or nil

for b,a in ipairs(b.groups)do
if b~=d then
for b=#(a.members or{}),1,-1 do
if f[a.members[b]]then table.remove(a.members,b)end
end
end
end
if d then
b.groups[d]=a
else
if c and c.clash then a.id=c.newId end
b.groups[#b.groups+1]=a
end
end


local g={}
for b,a in ipairs(b.groups)do
for b,a in ipairs(a.members or{})do g[a]=true end
end
for f,c in ipairs(c.arrivals)do
if c.kind=="group"and c.replaces and d.replace then
for c,f in ipairs(c.leaving or{})do
local c=e(b.elements,f)
local d=d.places and d.places[f]
if c and d and not g[f]then
b.elements[c]=a.copy(b.elements[c])
b.elements[c].position=a.copy(d)
end
end
end
end
for b,a in ipairs(b.groups)do
if a.members and#a.members==0 then a.members=nil end
end

for c,d in pairs(d.specials or{})do
b.specials=b.specials or{}
b.specials[c]=a.copy(d)
end
if#b.elements==0 then b.elements=nil end
if#b.groups==0 then b.groups=nil end
return b
end

local i="Your profile changed since Check: check again."
e.STALE=i
e.IN_COMBAT="Imports wait until combat ends."

function e.apply(c,f)
f=f or{}
if C.inCombat()then
return false,{d("refuse",nil,"",e.IN_COMBAT)}
end
if not b.ready()then return false,{d("refuse",nil,"","Settings aren't loaded yet.")}end
if not(c and c.ok)then return false,{d("refuse",nil,"","Nothing to import.")}end
if c.kind=="profile"then
if b.freeName(c.profileBase)~=c.profileName then
return false,{d("refuse",nil,"","The name \""..c.profileName
.."\" was taken since Check: check again.")}
end
local d=a.copy(c.profile)
d.name=nil
if f.styles then
d.styles=a.copy(b.profile().styles)
d.buttonCues=a.copy(b.profile().buttonCues)
d.presets=a.copy(b.profile().presets)
e.dropOwnStyles(d)
end
local a,d=b.addProfile(c.profileBase,d)
if not a then return false,d end
c.profileName=a
if f.use then b.useProfile(a)end
return true,d
end
if not L(c,f)then return false,{d("refuse",nil,"",i)}end
local a=e.overCap(c,f)
if a then return false,{d("refuse",nil,"",a)}end
return b.replaceProfile(e.merge(b.profile(),c,f))
end







local function i(b)
k("element",b,{},"",function(d,b,c)
if d.type=="spell"and type(b)=="number"then
local e,a=g.family(b)
if not a then a=select(2,t(b))end
local a=a and a.name or g.nameOf(b)
c[d.name]=a and{id=b,name=a}or b
elseif d.type=="spells"then
local e,f={},a.Sources.exactSet(c.exact)
for h,b in ipairs(b)do
local i,d=g.family(b)
if not d then d=select(2,t(b))end
local d=d and d.name or g.nameOf(b)
local f=f and f[b]or nil
local a=a.Sources.matchesOf(c,b)
e[h]=(d or f or a)and{id=b,name=d,exact=f,matches=a}or b
end
c[d.name]=e
c.exact=nil
end
end)
return b
end



local f={}
local function j(a)
if f[a]==nil then
local c,b=c.field(a,"spell"),c.field(a,"name")
f[a]=(c and c.type=="spell"and b and b.exportOnly and b.type=="string")
and true or false
end
return f[a]
end
local function f(a,b)
k("specials",a,{},"specials",function(a,c,e,d)
if a.type=="record"and a.record and j(a.record)then
b(c,d)
elseif a.type=="list"and a.record and j(a.record)then
for c,a in ipairs(c)do
if type(a)=="table"then b(a,d.."["..c.."]")end
end
end
end)
end
function r(e,g,a)
local b=e.specials
if type(b)~="table"then return end
local c={}
f(b,function(b,f)
local e=f:match("^specials%.([^%.%[]+)")
if not e or c[e]or type(b.spell)~="number"then return end
local f="profile."..f..".spell"
local b,g=w(b.spell,type(b.name)=="string"and b.name or nil,nil,g,a.notes,nil,f)
if b then
a.spells[#a.spells+1]=d("note",nil,"",b..".")
else
a.refused[#a.refused+1]=d("refuse",nil,f,g)
c[e]=true
end
end)
for a in pairs(c)do b[a]=nil end
if not next(b)then e.specials=nil end
end
local function j(a)
f(a,function(a)
if type(a.spell)~="number"then return end
local c,b=g.family(a.spell)
a.name=b and b.name or g.nameOf(a.spell)
end)
end



local function l(b,c)
for d,b in ipairs(b)do
k("element",b,{},"",function(b,e,f,d)
if d=="styles"then return false end
if b.style and not a.Styles.isLook(b.style)then c[b.style]=true end
end)
end
return c
end



local function k(b,f)
local e={}
for b,a in ipairs(b)do
c.eachStyleField("element",a,{},function(a,b)
if b.preset~=nil then
e[a.style]=e[a.style]or{}
e[a.style][b.preset]=true
end
end)
end
local d={}
for c,b in ipairs(c.STYLE_PARTS)do
for f,c in ipairs(type(f.presets)=="table"and f.presets[b]or{})do
if e[b]and e[b][c.id]then
d[b]=d[b]or{}
d[b][#d[b]+1]=a.copy(c)
end
end
end
return next(d)and d or nil
end

local function g(a,c)
return{kind=a,class=s(),locale=GetLocale(),name=c,interhud=b.VERSION}
end




function e.exportElements(c)
if not b.ready()then return nil,"Settings aren't loaded yet."end
local d=b.profile()
local f={}
for b,a in ipairs(c or{})do f[a]=true end
local c=g("elements")
local b,g={},{}
for e,c in ipairs(d.elements or{})do
if f[c.id]then
b[#b+1]=i(a.copy(c))
g[#g+1]=n.element(c,d)
end
end
if#b==0 then return nil,"Pick at least one element."end
local e={}
for c,b in ipairs(d.groups or{})do
local c=b.members and#b.members>0
for b,a in ipairs(b.members or{})do c=c and f[a]end
if c then e[#e+1]=a.copy(b)end
end
local f=n.styles(d)
local a={}
for b in pairs(l(g,{}))do
a[b]=h.clean("style:"..b,f[b],"load",{ownStyle=true})or{}
end
c.elements=b
c.groups=#e>0 and e or nil
c.styles=next(a)and a or nil
c.presets=k(b,d)
if#b==1 then c.name=b[1].name end
return m.write(c,"envelope")
end


function e.exportProfile(c,d)
if not b.ready()then return nil,"Settings aren't loaded yet."end
d=d or b.profileName()
c=a.copy(c or b.profile())
c.name=d
for b,a in ipairs(c.elements or{})do i(a)end
if type(c.specials)=="table"then j(c.specials)end
local a=g("profile",d)
a.profile=c
return m.write(a,"envelope")
end
