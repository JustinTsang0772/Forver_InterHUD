


local a,d=...
local a=d.Schema

local b={}
d.Check=b


b.MAX_FAULTS=20
b.MAX_BITS=3
b.MAX_GATES=2
b.MAX_DISPLAYS=64


b.DRIVER_MOST=38400
local w=2



b.RULES={
{"I1","No id is game; a custom state's is no kind's state, fact or event word; a fact item's is no other word of"
.." its source."},
{"I2","Ids are unique across the element (a fact item's among its source's items); a custom state's is no fact"
.." item's."},
{"K1","A key names something in the element; a look's glows and texts keys name its layer's parts; an effect's"
.." over names layers."},
{"K2","A bare key is the layer's own source's, and is written only in a look."},
{"K3","Outside a look a source's key is qualified: source.word."},
{"K4","A group's while and unless take game facts only."},
{"K5","An event is no key; a hold follows an event whose code runs in combat (a plain source's, never an"
.." aura's)."},
{"K6","No custom state refers to itself through others."},
{"E1","An element's own while and unless take lua keys only."},
{"R1","Another aura's facts (its Expiring, its stack ranges) key only that aura's own layers."},
{"R2","Another aura's state keys no aura's layer yet; a plain layer follows one other aura's state."},
{"R3","Nothing that plays rests on a key the game draws: a drawn fact's events, a custom state's events or hold over"
.." one, an effect's while and unless; none under an aura's event."},
{"R4","any joins only lua keys; a custom state names at most one aura's keys."},
{"R5","Size, place and segments never change by look."},
{"R6","A look holding only while its aura is missing sets no colour of a text the button draws."},
{"R7","A look or custom state that can never hold is refused: two states of one source, a key in both while and"
.." unless, an item outside its state, a held key, no keys."},
{"R8","A look with no values only borrows a Global fact look: its while is one fact that has one."},
{"N1","An aura that never ends has no Expiring."},
{"U1","A source names what it watches (its spells, slot, items or types)."},
{"A1","One Spell Alert picture an element."},
{"A2","A sound is a shipped one, \"file:<id>\" or \"media:<name>\"; at an aura's event, a shipped one or a file."},
{"A3","A Spell Alert plays sounds only: no pop, flash or text on an element holding its picture."},
{"L1","A layer's place sits against another layer of its element, never itself or one that sits against it."},
{"L2","Its picture is one the target layer has."},
{"C1",function()return"At most "..d.Sources.get("aura").MAX_RANGES.." stack ranges a buff or debuff."end},
{"C2","At most "..b.MAX_BITS.." switched sets of lua keys a buff's or debuff's layer; outside stack ranges and"
.." Expiring a look changing only tint, overlay and ring costs none."},
{"C3","At most "..b.MAX_GATES.." keys a layer that the game itself draws (a timer, a level, or something it"
.." doesn't tell addons)."},
{"C4","At most "..b.MAX_DISPLAYS.." displays a buff or debuff: its cells times 2 per switched set of its most"
.." switched layer."},
{"C5","One Expiring share a buff or debuff."},
{"C6","A stack range's edge fits the stacks driver: "..b.DRIVER_MOST.." units over the cell's width."},
}

local function h(a)
if a==nil then return{}end
if type(a)=="table"then return a end
return{a}
end
local function c(a)return"\""..tostring(a).."\""end
local function f(a)return d.Clean.orList(a)end
local function e(a,b)return a==""and b or(a.."."..b)end





local function g(b,c,e)
local a={index=e or a.keyIndex(b),summaries={}}
function a.view()
a.resolved=a.resolved or d.Resolve.element(b,c and{buttonCues=c}or nil)
return a.resolved
end
return a
end



local function s(b)
local a={}
for c,b in ipairs(b.order)do
if b.what~="event"then a[#a+1]=b end
end
return a
end
local function m(b)
local a={}
for b,c in ipairs(s(b))do a[b]=c.word end
return a
end
local function j(b)
local a={}
for b,c in ipairs(b.index.sources)do a[b]=c.rec.id end
return a
end
local function q(a)
if#a<=1 then return a[1]or"none"end
return table.concat(a,", ",1,#a-1).." and "..a[#a]
end

local function n(b,c)
local a
for d,b in ipairs(b.index.sources)do
if b.rec.kind==c or b.spec.key==c then
if a then return nil end
a=b
end
end
return a
end
local function i(a)return a~=nil and a.spec.read=="clip"end
local function r(a)return a.spec.noun or("a "..tostring(a.spec.kind))end
local function l(a)return(a.spec.stateOrder or{})[1]end


local function o(b)
local d={"\"id\": "..c(b.id)}
local a={}
for b in pairs(b)do
if b~="id"then a[#a+1]=b end
end
table.sort(a)
for a,e in ipairs(a)do
local a=b[e]
d[#d+1]=c(e)..": "..(type(a)=="string"and c(a)or tostring(a))
end
return"{ "..table.concat(d,", ").." }"
end



local function k(g,e,h)
local i,b=a.splitKey(e)
local d=b and g.index.sources[b]or(not b and h)or nil
if b==a.GAME then
local b={}
for a,c in ipairs(a.gameFacts())do b[a]="game."..c end
return c(e).." names no game fact; use "..f(b).."."
end
if b and not d then
local a=n(g,b)
return c(b).." is no source of this element; its sources are "..q(j(g))
..(a and(" ("..b.." is "..a.rec.id.."'s kind)")or"").."."
end
local j=d and d.spec.facts[i]
if a.isListFact(j)then
local a={}
for c,b in ipairs(d.order)do
if b.fact==j and b.what=="item"then a[#a+1]=b.word end
end
if#a>0 then return c(e).." is a list; key one of its items by id: "..f(a).."."end
return c(e).." needs an item first: add \"facts\": { "..c(i)..": [ "..o(j.example or{id=i})
.." ] } to "..d.rec.id..", then key its id."
end
if b and d then
return c(e).." names nothing; "..b.."'s keys are "..f(m(d)).."."
end
local a={}
if h then
for c,b in ipairs(s(h))do a[#a+1]=b.word end
end
a[#a+1]="a custom state's id"
local b
for c,a in ipairs(g.index.sources)do
if a~=h and l(a)and not b then b=a end
end
local b=b and("or another source's key as "..b.rec.id.."."..l(b))
or"or a game fact as game.inCombat"
return c(e).." names nothing in this element; use "..table.concat(a,", ")..", "..b.."."
end


local function t(e,b,a)
if a and i(a)then
return c(e).." can't key a look on another buff's or debuff's layer; use this one's own states and facts."
end
local d={}
for c,a in ipairs(b.spec.stateOrder or{})do d[#d+1]=b.rec.id.."."..a end
return c(e).." can't key a look on "..(a and a.rec.id or"this").."'s layer: a buff's or debuff's"
.." Expiring and stacks key only its own layers. Move the look to a layer under "..b.rec.id
..", or key it on "..f(d).."."
end




local function j(g,e,d)
local b,h=a.splitKey(e)
if h==a.GAME then
local a=a.gameFactSpec(b)
if not a then return nil,"K1",k(g,e,d)end
return{canonical=e,what="game",word=b,class=a.read,label=a.label}
end
if h then
local f=g.index.sources[h]
local a=f and f.words[b]
if not a then return nil,"K1",k(g,e,d)end
if a.what=="event"then
return nil,"K5",c(e).." is an event: a look keys on states, facts and custom states; play effects under "
..h.."'s events."
end
return{canonical=e,what=a.what,word=b,class=a.class,src=f,entry=a}
end
if d then
local a=d.words[b]
if a and a.what~="event"then
return{canonical=d.rec.id.."."..b,what=a.what,word=b,class=a.class,src=d,entry=a}
end
if a then
return nil,"K5",c(e).." is an event: a look keys on states, facts and custom states; play effects under "
..d.rec.id.."'s events."
end
end
local h=g.index.customStates[b]
if h then return{canonical=b,what="customState",word=b,cond=h}end
local h,i={},nil
for c,a in ipairs(g.index.sources)do
local b=a.words[b]
if b and b.what~="event"then h[#h+1]=a elseif b then i=i or a end
end
if#h>0 then
local a=h[1]
if d then
if a.words[b].class=="cell"and a~=d then return nil,"R1",t(a.rec.id.."."..b,a,d)end
return nil,"K2",c(b).." is "..a.rec.id.."'s; write "..a.rec.id.."."..b.."."
end
local a={}
for c,d in ipairs(h)do a[c]=d.rec.id.."."..b end
return nil,"K3",c(b).." needs its source here: "..f(a).."."
end
if a.gameFactSpec(b)then return nil,"K3",c(b).." needs its source here: game."..b.."."end
if i then
return nil,"K5",c(b).." is an event: a look keys on states, facts and custom states; play effects under "
..i.rec.id.."'s events."
end
return nil,"K1",k(g,e,d)
end
b.resolve=j






local p={clip=true,cell=true,gate=true}
local function l(e,c,d)
local b=e.summaries[c]
if b then return b end
d=d or{}
local g=e.index.customStates[c]
local b={classes={},auras={},cells={},gates={},lua={},missing={}}
if not g then return b end
if d[c]then
b.cycle=true
return b
end
d[c]=true
for a,f in ipairs(a.keyFieldsOf("customState"))do
for c,a in ipairs(h(g.rec[f]))do
local a=j(e,a,nil)
if a and a.what=="customState"then
local c=l(e,a.word,d)
if c.cycle then b.cycle=c.cycleThrough or a.word end
for a in pairs(c.classes)do b.classes[a]=true end
for a in pairs(c.auras)do b.auras[a]=true end
for a in pairs(c.cells)do b.cells[a]=true end
for a in pairs(c.gates)do b.gates[a]=true end
if f=="all"then for a in pairs(c.missing)do b.missing[a]=true end end
b.secret=b.secret or c.secret
b.secretKey=b.secretKey or c.secretKey
for c,a in ipairs(c.lua)do b.lua[#b.lua+1]=a end
elseif a then
b.classes[a.class]=true
if p[a.class]then
b.secret=true
b.secretKey=b.secretKey or a.canonical
end
if a.src and i(a.src)then b.auras[a.src.rec.id]=true end
if a.class=="cell"then b.cells[a.src.rec.id]=true end
if a.class=="gate"then b.gates[a.canonical]=true end
if a.class=="lua"then b.lua[#b.lua+1]=(f=="none"and"!"or"")..a.canonical end
if f=="all"and a.what=="state"and a.word=="missing"and i(a.src)then
b.missing[a.src.rec.id]=true
end
end
end
end
d[c]=nil
if not b.cycle then e.summaries[c]=b end
return b
end
b.summary=l


local function x()
local b={}
for a,c in ipairs(a.gameFacts())do b[a]="game."..c end
return b
end



local function o(m,b,d,k,h,q)
local r={}
for s,e in ipairs(b)do
local u=d.."["..s.."]"
local b,d,g
if k=="group"then
local h,i=a.splitKey(e)
if i~=a.GAME or not a.gameFactSpec(h)then
d,g="K4",c(e).." isn't a game fact; a group's while takes "..f(x()).."."
else
b={canonical=e,what="game",word=h,class="lua"}
end
else
b,d,g=j(m,e,k=="look"and h or nil)

local c,a=a.splitKey(e)
local a=d=="K1"and a and not m.index.sources[a]and n(m,a)
if a then
local b={}
o(m,{a.rec.id.."."..c},"",k,h,b)
if b[1]then g=g.." Written "..a.rec.id.."."..c..", it "..b[1].text:gsub("^\"[^\"]*\" ","")end
end
end
if b then
local a=b.what=="customState"and l(m,b.word).secret
if k=="element"and(p[b.class]or a)then
d="E1"
g=c(e).." can't decide whether the whole element shows: the game draws it in combat, where InterHUD"
.." can't read it. Key a look on each layer instead: \"while\": "..c(e)..", \"shown\": false."
elseif k=="effect"and(p[b.class]or a)then
d="R3"
g=c(e).." is drawn by the game in combat, where InterHUD can't read it, so nothing can play on"
.." it; key it on what InterHUD reads."
elseif k=="look"and b.src and b.src~=h and i(b.src)then
if b.class=="cell"then
d,g="R1",t(b.canonical,b.src,h)
elseif i(h)then
d="R2"
g=c(e).." can't yet key a look on another buff's or debuff's layer (unproven on Forever). Put the"
.." look on a layer under "..b.src.rec.id..", or under a spell, totem or other source InterHUD reads"
.." itself."
end
elseif k=="look"and b.what=="customState"then
local a=l(m,b.word)
for a in pairs(a.cells)do
if not d and(h==nil or a~=h.rec.id)then
d="R4"
g=c(e).." names "..a.."'s Expiring or stacks, which key only "..a.."'s own"
.." layers; move the look to a layer under "..a.."."
end
end
for a in pairs(a.auras)do
if not d and i(h)and a~=h.rec.id then
d="R2"
g=c(e).." names "..a.."'s state, which can't yet key a look on another buff's or"
.." debuff's layer (unproven on Forever). Put the look on a layer under "..a.."."
end
end
end
end
if d then q[#q+1]={rule=d,path=u,text=g}end
r[s]=(not d)and b or nil
end
return r
end



local function y(b,g,d,h)
local e,f={},{}
for b,a in pairs(b)do
if a.what=="state"then
local b=e[a.src.rec.id]
if b and b~=a.word then
return d..": "..c(b).." and "..c(a.word).." are both "..a.src.rec.id
.."'s states; one holds at a time."
end
e[a.src.rec.id]=a.word
end
if a.class=="held"then return c(a.word).." draws nothing; a look on it never shows."end
f[a.canonical]=true
end
for d,b in pairs(b)do
local d=b.entry and b.entry.within
local e=b.src and e[b.src.rec.id]
if d and e and not a.holdsWithin(d,e)then
local a={}
for d,c in ipairs(type(d)=="table"and d or{d})do
a[#a+1]=(b.src.spec.states[c]and b.src.spec.states[c].label or c):lower()
end
local d=table.remove(a)
local a=#a>0 and(table.concat(a,", ").." or "..d)or d
return c(b.word).." holds only while "..b.src.rec.id.." is "..a.."."
end
end
for b,a in pairs(g)do
if f[a.canonical]then return c(a.word).." is in both "..d.." and "..h.."."end
end
return nil
end



local z={tint=true,overlay=true,overlayColour=true}
local A={ring=true,ringColour=true,ringSize=true}
local function B(a)
if not a then return true end
for a,b in pairs(a)do
if a=="border"and type(b)=="table"then
for a in pairs(b)do
if not A[a]then return false end
end
elseif not z[a]then
return false
end
end
return true
end
b.coverOnly=B





local function C(b,g)
local c,d,h,e={},nil,nil,nil
for i,f in ipairs(b.factOrder)do
local b=b.facts[f]
if a.isListFact(b)and b.read=="cell"then
e=e or b.within
for e,a in ipairs(type(g[f])=="table"and g[f]or{})do
if a.enabled~=false then
if b.range then
if b.range(a)then
c[#c+1]=a
h=b.range
end
elseif not d then
d=a
end
end
end
end
end
return c,d,h,e
end




local function k(a,b,c)
local d=d.Layers
if b=="colour"then
local b=d.get(a.kind)
return b~=nil and b[c]~=nil and b[c]({content=a.content})==true
end
local b,f=b:match("^([^%.]+)%.(.+)$")
for g,e in ipairs(b and d.partsOf(a.kind)or{})do
if e.key==b then
local d=d.part(e.kind)
if not d[c]then return false end
if not e.list then
return f=="colour"and d[c](type(a[b])=="table"and a[b]or{})==true
end
local e,f=f:match("^([^%.]+)%.([^%.]+)$")
for b,a in ipairs(f=="colour"and type(a[b])=="table"and a[b]or{})do
if tostring(a.id)==e then return d[c](a)==true end
end
return false
end
end
return false
end
local function D(a,b)return k(a,b,"colourByCount")end
local function E(a,b)return D(a,b)or k(a,b,"colourByTime")end



local function t(b,c,f,a)
a=a or d.Resolve.lookAt(b,c)
local e={}
for d,c in ipairs(d.Resolve.leafPaths(b))do
local a=a
for b in c:gmatch("[^%.]+")do
if type(a)~="table"then a=nil break end
if a[b]==nil and type(a)=="table"and a[1]~=nil then
local c
for d,a in ipairs(a)do
if a.id==b then c=a end
end
a=c
else
a=a[b]
end
end
if not f(b,c)then e[c]=a end
end
return e
end

local function u(a,b)
return a==b or(type(a)=="table"and type(b)=="table"and d.equal(a,b))
end
local function n(a,b)
for a,c in pairs(a)do
if not u(c,b[a])then return false end
end
for b in pairs(b)do
if a[b]==nil then return false end
end
return true
end





local function H(c,b,a)
local f=d.Layers
local d={}
for b,a in ipairs(f.partsOf(c.kind))do d[a.key]=a.kind end
for a,e in pairs(a)do
if not u(e,b[a])then
local g=a:match("^([^%.]+)")
local b
if a=="shown"then
b=e==true and not(c.kind=="bar"and c.value~="stacks")
elseif a:match("%.shown$")then
b=e==true and d[g]~=nil and f.part(d[g]).routes~=nil
else
b=a=="border.colour"
end
if not b then return false end
end
end
return true
end

local m,k,v

local function I(e,a,b)
local c={}
for f,a in ipairs(type(a.looks)=="table"and a.looks or{})do
local f=m(e,a,b)
local e=false
for c,a in pairs(f)do
if a.src==b and a.what=="item"and a.entry.fact.range then e=true end
end
if e then
for a in pairs(d.Resolve.valuesOf(a)or{})do c[a]=true end
end
end
return c
end

local function J(b,a,c)
for e,d in ipairs(type(a.looks)=="table"and a.looks or{})do
if k(b,d,c,false,a)then return true end
end
return false
end







local function F(a,d)
local b,c={},{}
for e,a in ipairs(a)do
local d,a=d(a)
for d,a in ipairs({d,a and a+1})do
if a and a>=2 and not c[a]then
c[a]=true
b[#b+1]=a
end
end
end
table.sort(b)
return b
end


local function K(b,a)
local a,b,c=C(b,type(a)=="table"and a or{})
return(#F(a,c)+1)*(b and 2 or 1)
end


local function G(c,e)
local g=type(e.facts)=="table"and e.facts or{}
local b,f=0,1
for h,d in ipairs(c.factOrder)do
local c,d=c.facts[d],g[d]
if a.isListFact(c)and c.read=="cell"then
if d~=nil and type(d)~="table"then return nil end
if not c.range then
f=2
elseif d then
b=b+2*#d
elseif c.default and c.default(e)then
b=b+2
end
end
end
return(b+1)*f
end






local function L(a)
local b={}
for a,d in ipairs(a.sources or{})do
local c={}
for a,b in pairs(d)do
if a~="layers"and a~="events"then c[a]=b end
end
b[a]=c
end
return{sources=b,customStates=a.customStates}
end
function b.cells(c,e,b)
local f=b and b.keys or L(e)
local g=b and b.index or a.keyIndex(f)
if b then b.keys,b.index=f,g end
local e={index=g,summaries={},view=function()return e end}
local a=e.index.sources[c.id]
if not a then return 1,false end
local k,h,m,o=C(a.spec,type(c.facts)=="table"and c.facts or{})
local l=F(k,m)
local i=c.layers or{}
local j={}
for e=0,#l do
local a=l[e]or 1

local l={}
for c,b in ipairs(k)do
local c,d=m(b)
if(c<=1 or a>=c)and(d==nil or a<=d)then l[b.id]=true end
end
local a=b and b.holds[c.id.."|"..e]
if not a then
local i={}
for a in pairs(l)do i[a]=true end
if h then i[h.id]=true end
a={d.Resolve.holds(f,{[c.id]={state=o,facts=l}},g),
d.Resolve.holds(f,{[c.id]={state=o,facts=i}},g)}
if b then b.holds[c.id.."|"..e]=a end
end
local g,k=a[1],a[2]
local f={early={},late={},base={}}
for i,a in ipairs(i)do
local c=b and b.values[a]and b.values[a][e]
if not c then
local d=d.Resolve.lookAt(a,g)
c={t(a,g,D,d)}
if h then c[2],c[3]=t(a,k,E),t(a,g,E,d)end
if b then
b.values[a]=b.values[a]or{}
b.values[a][e]=c
end
end
f.early[i],f.late[i],f.base[i]=c[1],c[2],c[3]
end
j[#j+1]=f
end

local d=false
for b,c in ipairs(h and j or{})do
for f,b in ipairs(i)do
local c,f=c.base[f],c.late[f]
if not d and not n(c,f)then
local g=#k>0 and I(e,b,a)or{}
local h=g.shown or g.opacity
for a,b in pairs(f)do
if not u(b,c[a])and g[a:match("^([^%.]+)")]then h=true end
end
d=h or not H(b,c,f)or J(e,b,a)
end
end
end
local e,b=0,nil
for c,a in ipairs(j)do
local c=false
for b in ipairs(d and i or{})do
if not n(a.base[b],a.late[b])then c=true end
end
a.cut=c
local f=b~=nil and b.cut==c
for d in ipairs(f and i or{})do
if not n(b.early[d],a.early[d])or(c and not n(b.late[d],a.late[d]))then
f=false
end
end
if not f then e=e+(c and 2 or 1)end
b=a
end
return e,d
end



function m(a,b,e)
local c=a.terms and a.terms[b]
if c then return c[1],c[2]end
local c,d={},{}
for b,d in ipairs(h(b["while"]))do c[b]=j(a,d,e)end
for b,c in ipairs(h(b.unless))do d[b]=j(a,c,e)end
if a.terms and b~=a.changing then a.terms[b]={c,d}end
return c,d
end

local function n(c,a,b)
local a,d=h(a["while"]),h(a.unless)
if#a~=1 or#d~=0 then return false end
local a=j(c,a[1],b)
return a~=nil and a.src==b and a.what=="state"
end
b.isStateLook=function(a,b,c)
local a=g(a)
return n(a,b,a.index.sources[c])
end






function k(c,f,e,g,b)
if n(c,f,e)then return nil end
if not g and b and not d.Layers.onButtonPresent(b,c.view().baseSize)then return nil end
local h,i=m(c,f,e)
local a={}
for d,b in pairs(h)do
if b.src==e and b.what=="state"and b.word=="missing"then return nil end
if b.what=="customState"then
local c=l(c,b.word)
if c.missing[e.rec.id]then return nil end
if#c.lua>0 then a[#a+1]="w:"..b.canonical end
elseif b.class=="lua"then
a[#a+1]="w:"..b.canonical
end
end
for d,b in pairs(i)do
if b.class=="lua"or(b.what=="customState"and#l(c,b.word).lua>0)then
a[#a+1]="u:"..b.canonical
end
end
if#a==0 then return nil end
table.sort(a)
local c=d.Resolve.valuesOf(f)
if c==nil and b then

local a=h[1]
c=a and b.borrowed and b.borrowed[a.canonical]or nil
end
if not g and B(c)then return nil end
return table.concat(a,"&")
end

b.bitOf=function(...)return k(...)end
b.check=function(a,b)return g(a,b)end

local function t(c,b,d)
local a={}
local b,d=m(c,b,d)
for d,b in ipairs({b,d})do
for d,b in pairs(b)do
if b.class=="gate"then a[#a+1]=b.canonical end
if b.what=="customState"then
for b in pairs(l(c,b.word).gates)do a[#a+1]=b end
end
end
end
return a
end



local function u(b,a,c)
for d,a in ipairs(a.layers or{})do
local d=b.index.sources[a.source]
if d and a.source~=c then
for e,a in ipairs(type(a.looks)=="table"and a.looks or{})do
local a,d=m(b,a,d)
for d,a in ipairs({a,d})do
for d,a in pairs(a)do
if a.src and a.src.rec.id==c and a.what=="state"then return true end
if a.what=="customState"and l(b,a.word).auras[c]then return true end
end
end
end
end
end
return false
end




function b.cellOf(a,c)
return b.cellInto(a,b.cellRun(a,c),{})
end

function b.cellRun(b,c)
local a={index=a.keyIndex(b),summaries={}}
return not u(a,b,c.id)and c.id or nil
end


local m,B={},{}
function b.cellInto(a,c,b)

m.baseSize,m.layers,m.allLayers,m.run=a.baseSize,a.layers,a.allLayers,c
local a=d.Layers.bounds(m,true,nil,B,true)
m.layers,m.allLayers=nil,nil
local c=math.floor(math.max(a.w,a.h)/2)+4
b.x,b.y,b.w,b.h=a.x-c-w,a.y-c,a.w+2*c+w,a.h+2*c
return b
end



function v(c)
local b={}
for c,a in ipairs(c.index.sources)do
if a.spec.moment=="plain"then
for d,c in ipairs(a.spec.eventOrder)do b[#b+1]=a.rec.id.."."..c end
end
end
if#b>0 then return"a hold follows "..f(b).."."end
local b,c={},{}
for e,d in ipairs(a.sourceKeys())do
local a=a.source(d)
if a.moment=="plain"and#a.eventOrder>0 and a.noun and not c[a.noun]then
c[a.noun]=true
b[#b+1]=a.noun
end
end
return"a hold follows an event of "..f(b)..", and this element has none."
end






local function B(n,a,i)
local j=d.Layers
local d,f,g=j.layersOf(a),{},{}
for b,a in ipairs(type(a.sources)=="table"and a.sources or{})do
for a,c in ipairs(type(a)=="table"and type(a.layers)=="table"and a.layers or{})do
if type(c)=="table"then f[#f+1]="sources["..b.."].layers["..a.."].position"end
end
end
for b,a in ipairs(d)do
if a.id~=nil and g[a.id]==nil then g[a.id]=b end
end
local k={}
for b,l in ipairs(d)do
local a=type(l.position)=="table"and l.position or{}
local h,e=a.to,a.to~=nil and g[a.to]or nil
local o={what="fields",owner=a,keys={"to","piece"}}
local m,f=f[b],nil
if h~=nil and not e then
local a={}
for d,c in ipairs(d)do
if d~=b and c.id~=nil then a[#a+1]=tostring(c.id)end
end
f=c(h).." names no layer of this element; "
..(#a>0 and("its layers are "..q(a))or"it has no other").."."
elseif e==b then
f=c(h).." is this layer; a layer sits against another."
elseif e and j.anchoredTo(d,b)[e]then
if not k[b]then
local a,e={c(l.id)},b
repeat
k[e]=true
e=g[d[e].position.to]
a[#a+1]=c(d[e].id)
until e==b or#a>#d
f=a[1].." sits against "..table.concat(a,", which sits against ",2).."."
end
end
if f then
i({rule="L1",path=m..".to",text=f,drop=o})
elseif a.piece~=nil and not k[b]then
local d={what="fields",owner=a,keys={"piece"}}
local b,c=e and n.view(),nil
for b,a in ipairs(b and b.layers or{})do
if a.id==h then c=a end
end
local b=c and#j.pieces(c,b.baseSize)
if not e then
i({rule="L2",path=m..".piece",note=true,fix={owner=a,key="piece"},drop=d,
text="names a picture, but to names no layer; left out."})
elseif b and a.piece>b then
i({rule="L2",path=m..".piece",note=true,fix={owner=a,key="piece",value=b},
drop=d,text=tostring(a.piece).." is above "..b.."; set to "..b.."."})
end
end
end
end


local function w(a,b)
local b,a=a.range(b)
return b and math.max(b,a and a+1 or 0),a
end






local function m(j,k,f,n)
local g=g(j,k,n)
if f and f.view then
function g.view()
g.resolved=g.resolved or f.view()
return g.resolved
end
g.kept=f.kept
end
if f and f.terms then g.terms,g.changing=f.terms,f.changing end
local m={}
local function k(a)m[#m+1]=a end
n=g.index

for b,d in ipairs((f==nil or f.customStates)and type(j.customStates)=="table"and j.customStates
or{})do
local f="customStates["..b.."]"
local b={}
local m={}
for c,a in ipairs(a.keyFieldsOf("customState"))do
m[a]=o(g,h(d[a]),e(f,a),"customState",nil,b)
end
local h=type(d.id)=="string"and l(g,d.id)or{auras={},lua={},classes={}}
if h.cycle then
local a=h.cycle==true and d.id or h.cycle
b[#b+1]={rule="K6",path=f,text=c(d.id).." refers to itself through "..c(a)
.."."}
end
for d,a in pairs(m.any)do
if p[a.class]or(a.what=="customState"and l(g,a.word).secret)then
b[#b+1]={rule="R4",path=e(f,"any"),text=c(a.canonical).." is drawn by"
.." the game, and any joins only keys InterHUD reads; write a look for each key, with the same values."}
break
end
end
local i={}
for a in pairs(h.auras)do i[#i+1]=a end
table.sort(i)
if#i>1 then
b[#b+1]={rule="R4",path=f,text="names two buffs' or debuffs' keys ("..i[1]..", "
..i[2].."); a custom state takes one's."}
end
local i=y(m.all,m.none,"all","none")
if i then b[#b+1]={rule="R7",path=f,text=i}end

local i=false
for b,a in pairs(type(d.events)=="table"and d.events or{})do
if type(a)=="table"and type(a.effects)=="table"and#a.effects>0 then i=true end
end



local function l()
local c,b=a.splitKey(h.secretKey or"")
local b=b and n.sources[b]
return a.customStateName(d),b and a.sourceName(j.sources,b.rec)or"a buff or debuff"
end
if h.secret and i then
local c,a=l()
b[#b+1]={rule="R3",path=e(f,"events"),text=c.." can't play effects and read "
..a..", which the game draws in combat. Take its effects out, or leave "..a.." out."}
end
if h.secret and d.hold then
local c,a=l()
b[#b+1]={rule="R3",path=e(f,"hold"),text=c.." can't wait after an event and"
.." read "..a..", which the game draws in combat. Set its After to None, or leave "..a.." out."}
end

if type(d.hold)=="table"and d.hold.after~=nil then
local h,a=a.splitKey(d.hold.after)
local a=a and n.sources[a]
local h=a and a.words[h]
if not(h and h.what=="event")then
b[#b+1]={rule="K5",path=e(f,"hold.after"),text=c(d.hold.after).." names no"
.." event of this element; "..v(g)}
elseif a.spec.moment~="plain"then
b[#b+1]={rule="K5",path=e(f,"hold.after"),text=c(d.hold.after)
.." runs no code in combat; "..v(g)}
end
end
for b,a in ipairs(b)do
a.drop=a.drop or{what="item",owner=j.customStates,item=d}
k(a)
end
end

local p={}
for b,a in ipairs((f==nil or f.element)and a.keyFieldsOf("element")or{})do
p[a]=o(g,h(j[a]),a,"element",nil,p)
end


for c,b in ipairs(p)do
b.drop={what="fields",owner=j,keys=a.SHOWING}
k(b)
end

local s=0

for p,m in ipairs(type(j.sources)=="table"and j.sources or{})do
local t="sources["..p.."]"
local j=type(m)=="table"and n.sources[m.id]
if j then
local n=type(m.facts)=="table"and m.facts or{}
for c,i in ipairs((f==nil or f.facts[p])and j.spec.factOrder or{})do
local c=j.spec.facts[i]
local e=n[i]
local h=t..".facts."..i
local a=a.isListFact(c)
if a and type(e)=="table"and c.max and#e>c.max then

local a=(c.capText or("has %d items; "..r(j).." takes %d.")):format(#e,c.max)
.." Keep "..c.max..", and take out the looks keyed on the rest."
k({rule=c.capRule or"C1",path=h,text=a,
drop={what="trim",owner=e,keep=c.max}})
end

local l=a and c.none and c.none(m)
if l and type(e)=="table"and#e>0 then
local a=d.Spells.label(d.Spells.firstOf(m.spells))or"It"
k({rule="N1",path=h,text=a.." "..l.."; leave it out.",
drop={what="field",owner=n,key=i}})
end

local d=a and(type(e)=="table"and e or{})or{e}
for e,b in ipairs(d)do
local d=false
for b,a in pairs(type(b)=="table"and type(b.events)=="table"and b.events or{})do
if type(a)=="table"and type(a.effects)=="table"and#a.effects>0 then d=true end
end
if d and c.read~="lua"then
k({rule="R3",path=(a and(h.."["..e.."]")or h)..".events",
text=r(j).."'s "..c.label.." is drawn by the game in combat, where InterHUD can't read"
.." it; it takes looks only.",drop={what="field",owner=b,key="events"}})
end
end

if c.range and type(e)=="table"and#e>0 then
local d
local a=f and f.widths and f.widths[p]
if a~=nil then
d=a and math.floor(b.DRIVER_MOST/(u(g,f.layers,m.id)and a.all
or a.own))or 255
else
local a=g.view()
local c=a.sourcesById[m.id]
d=c and math.floor(b.DRIVER_MOST/b.cellOf(a,c).w)or 255
end
for f,a in ipairs(e)do
local b,g=w(c,a)
if b and b>d and a.enabled~=false then
local b
for d,c in ipairs(c.setting)do
if b==nil and a[c.name]~=nil then b=c.name end
end
k({rule="C6",path=h.."["..f.."]",text=b..": "
..tostring(a[b]and(type(a[b])=="table"and math.max(a[b][1],a[b][2])
or a[b])).." is too many stacks for a display this wide: at most "
..(g and d-1 or d).." here.",drop={what="item",owner=e,item=a}})
end
end
end
end

for r,n in ipairs(type(m.layers)=="table"and m.layers or{})do
local t=t..".layers["..r.."]"
if n.kind==a.ALERT_LAYER then
s=s+1
if s>1 then
k({rule="A1",path=t,text="is a second Spell Alert picture: an element holds one.",
drop={what="item",owner=m.layers,item=n}})
end
end
local s={}
local f=f==nil or f.looks[p.."."..r]
for f,m in ipairs(f and type(n.looks)=="table"and n.looks or{})do
local p=t..".looks["..f.."]"
local f={}
local r=o(g,h(m["while"]),e(p,"while"),"look",j,f)
local o=o(g,h(m.unless),e(p,"unless"),"look",j,f)

for b,a in ipairs(d.Layers.partsOf(n.kind))do
local f=a.list and m[a.key]
if type(f)=="table"then
local e,g={},{}
for b,a in ipairs(type(n[a.key])=="table"and n[a.key]or{})do
if type(a)=="table"and a.id~=nil then
e[#e+1]=tostring(a.id)
g[a.id]=true
end
end
local b={}
for a in pairs(f)do b[#b+1]=a end
table.sort(b,function(a,b)return tostring(a)<tostring(b)end)
for h,b in ipairs(b)do
if not g[b]then
local d=d.Layers.part(a.kind).label:lower()
local c=#e>0 and(c(b).." names no "..d.." of this layer; its "..a.key
.." are "..q(e)..".")or(c(b).." names no "..d.." of this layer, which has"
.." none: add one to its "..a.key..", as [ { \"id\": "..c(b).." } ].")
k({rule="K1",path=p.."."..a.key.."."..tostring(b),text=c,
drop={what="field",owner=f,key=b,map=true}})
end
end
end
end
if#f==0 then
local e=y(r,o,"while","unless")
if m["while"]==nil and m.unless==nil then e="holds always; set its values on the layer."end
if e then f[#f+1]={rule="R7",path=p,text=e}end

local d=d.Resolve.valuesOf(m)
if d==nil then
local b=r[1]
local b=#h(m["while"])==1 and m.unless==nil and b and b.what=="fact"
and b.entry.fact and type(b.entry.fact.look)=="string"
if not b then

local b={}
for c,a in ipairs(a.fieldsOf("buttonCues"))do b[#b+1]=a.label or a.name end

f[#f+1]={rule="R8",path=p,importOnly=true,text="sets nothing; give it values, or"
.." key it on one fact with a button cue ("..table.concat(b,", ")..") to take its cue here."}
end
end

if not i(j)then
for b,a in ipairs({r,o})do
for b,a in pairs(a)do
local b={}
if a.src and i(a.src)and a.src~=j then b[#b+1]=a.src.rec.id end
if a.what=="customState"then
for a in pairs(l(g,a.word).auras)do b[#b+1]=a end
end
for b,a in ipairs(b)do
if not s[a]then
local b=next(s)
if b then
f[#f+1]={rule="R2",path=p,text="names a second buff or debuff ("..c(a)
.."); a layer follows one other buff's or debuff's state. Key this look on "..b
.."'s only, or move it to a layer under "..a.."."}
else
s[a]=true
end
end
end
end
end
end

if i(j)then
local c=false
for b,a in pairs(r)do
if a.src==j and a.what=="state"and a.word=="missing"then c=true end
end
local d,e
if c then d,e=b.missingTexts(n,m)end
if d then
f[#f+1]={rule="R6",path=p,text="A look for Missing can't colour the "
..e..", which "..a.subjectOf(j.spec,true).." doesn't show while it's missing. Take the colour out of that"
.." look first."}
end
end
end
for b,a in ipairs(f)do
a.drop={what="item",owner=n.looks,item=m}
k(a)
end
end
end
end
end
if f==nil or f.places then B(g,j,k)end
if f~=nil and not f.effects then return m,g end

local p=a.holdsAlert(j)
a.eachRecord("element",j,function(b,f,j,i)
if b~="effect"then return end
local b={}
local l=i.moment
for c,a in ipairs(a.keyFieldsOf("effect"))do
if f[a]~=nil and l=="engine"then

local c=i.source and n.sources[i.source.id]
b[#b+1]={rule="R3",path=e(j,a),text="isn't taken at "..(c and r(c)
or"this").."'s event: it plays in the game, with no code to read it."}
else
o(g,h(f[a]),e(j,a),"effect",nil,b)
end
end
local g={}
for b,a in ipairs(n.sources)do
if not(l=="engine"and i.source and a.rec.id~=i.source.id)then
for b,a in ipairs(type(a.rec.layers)=="table"and a.rec.layers or{})do
if type(a)=="table"and a.id then g[#g+1]=tostring(a.id)end
end
end
end

local m=l=="engine"and i.source~=nil
if m and f.over==nil and#g==0 and a.field("effect","over",f.kind)then
k({rule="K1",path=j,note=true,text="plays over "..tostring(i.source.id).."'s own layers,"
.." and it has none."})
end
for d,a in ipairs(h(f.over))do
local h=n.layers[a]
if not h then
b[#b+1]={rule="K1",path=e(j,"over["..d.."]"),text=c(a).." names no layer of "
..(m and tostring(i.source.id)or"this element").."; "
..(#g>0 and("its layers are "..q(g))or"it has none")..".",
drop={what="item",owner=f.over,item=a}}
elseif l=="engine"and i.source and h.source~=i.source.id then
b[#b+1]={rule="K1",path=e(j,"over["..d.."]"),text="is another source's layer;"
.." a buff's or debuff's moment plays only over its own.",drop={what="item",owner=f.over,item=a}}
end
end

if f.kind~="sound"and p then
b[#b+1]={rule="A3",path=j,text="is a "..tostring(f.kind).." on a Spell Alert, which"
.." plays sounds only; make it a sound, or move it to an element without the alert's picture."}
end
if f.kind=="sound"and type(f.sound)=="string"then
local a=f.sound
if not a:match("^file:")and not a:match("^media:")and not d.Sounds.label(a)then
b[#b+1]={rule="A2",path=e(j,"sound"),text=c(a).." isn't a sound InterHUD ships; use "
..table.concat(d.Sounds.names(),", ").." or \"file:<id>\"."}
elseif l=="engine"and a:match("^media:")then
b[#b+1]={rule="A2",path=e(j,"sound"),text="is a shared-media sound, which an aura's"
.." event can't play; use a shipped sound or \"file:<id>\"."}
elseif l=="engine"and not d.Sounds.fileID(a)then
b[#b+1]={rule="A2",path=e(j,"sound"),text="has no sound file the game can play at an"
.." aura's change; use raid, ready, ping or \"file:<id>\"."}
end
end
for b,a in ipairs(b)do
a.drop=a.drop or{what="effect",item=f}
k(a)
end
return false
end)
return m,g
end


local function l(a,b,c)
if a.missingNoun then return a.missingNoun(c)end
return b=="count"and"count"or"time"
end


function b.missingTexts(b,e)
local c=d.Layers
local a=c.get(b.kind)
local d={content=e.content or b.content}
if a and a.buttonText and e.colour~=nil and a.buttonText(d)then
return"colour",a.missingNoun and a.missingNoun(d)or"time"
end
for d,a in ipairs(c.partsOf(b.kind))do
local c=c.part(a.kind)
local d=e[a.key]
if c.buttonText and type(d)=="table"then
if a.list then
for e,b in ipairs(type(b[a.key])=="table"and b[a.key]or{})do
local d=d[b.id]
local e=type(d)=="table"and{content=d.content or b.content}
if e and d.colour~=nil and c.buttonText(e)then
return a.key.."."..tostring(b.id)..".colour",l(c,a.key,e)
end
end
elseif d.colour~=nil then
local b=type(b[a.key])=="table"and b[a.key]or{}
local b={content=d.content or b.content}
if c.buttonText(b)then return a.key..".colour",l(c,a.key,b)end
end
end
end
end



local function l(f,d,g)
local a,b,h,c=0,0,{},0
for d,i in ipairs(type(d.layers)=="table"and d.layers or{})do
local j,d,l,e={},0,{},0
for a,b in ipairs(type(i.looks)=="table"and i.looks or{})do
local a=k(f,b,g,true,nil)
if a and not j[a]then
j[a]=true
d=d+1
end
for b,a in ipairs(t(f,b,g))do
if not l[a]then
l[a]=true
e=e+1
end
if not h[a]then
h[a]=true
c=c+1
end
end
end
a,b=math.max(a,d),math.max(b,e)
end
return a,b,c
end

local function p(a,c,d,e)
local a,c,d=l(a,c,d)
return a<=b.MAX_BITS and c<=b.MAX_GATES and e*2^a*2^d<=b.MAX_DISPLAYS
end






local function q(a,e,g,d,h)
local f
for j,a in ipairs(type(a.sources)=="table"and a.sources or{})do
local d=type(a)=="table"and(d==nil or d[j])and e.index.sources[a.id]
local h=d and h and i(d)and h[j]
if h and((h.atMost and p(e,a,d,h.atMost))or p(e,a,d,h.exact()))then
d=nil
end
if d then
local h=i(d)
local l=1
if h then
f=f or e.view()
local a=f.sourcesById[a.id]
l=a and b.cells(a,f,e.kept)or 1
end
local m,p,n=0,{},nil
for q,o in ipairs(type(a.layers)=="table"and a.layers or{})do
local u="sources["..j.."].layers["..q.."]"
local r,i,s,j={},0,{},0
local q=h and f and f.sourcesById[a.id]and f.sourcesById[a.id].layers[q]
for a,f in ipairs(type(o.looks)=="table"and o.looks or{})do
local m=u..".looks["..a.."]"
local a={what="item",owner=o.looks,item=f}
if h then
local c=k(e,f,d,l>1,q)
if c and not r[c]then
r[c]=true
i=i+1
if i>b.MAX_BITS then
g[#g+1]={rule="C2",path=m,text="is a fourth switched set of keys on a buff's or"
.." debuff's layer; it takes three (8 copies of its display). Give two looks the same keys to share"
.." one, or, outside stack ranges and Expiring, change only tint, overlay and ring.",drop=a}
end
end
if c then n=a end
end
for e,d in ipairs(t(e,f,d))do
if not s[d]then
s[d]=true
j=j+1
if j>b.MAX_GATES then
g[#g+1]={rule="C3",path=m,text=c(d).." is a third key on this layer that the"
.." game itself draws (a timer, a level, or something it doesn't tell addons); a layer"
.." takes two.",drop=a}
end
end


if h then
p[d]=true
n=a
end
end
end
m=math.max(m,math.min(i,b.MAX_BITS))
end
if h then
local c=0
for a in pairs(p)do c=c+1 end
local e=l*2^m*2^c
if e>b.MAX_DISPLAYS then
local d=n
local c=type(a.facts)=="table"and a.facts.stacks
if not d and type(c)=="table"and#c>0 then
d={what="item",owner=c,item=c[#c]}
end
g[#g+1]={rule="C4",path="sources["..j.."]",text=a.id.." needs "..e
.." slots; a buff or debuff has "..b.MAX_DISPLAYS..". Fewer stack ranges or fewer switched looks on"
.." its layers bring it down.",drop=d}
end
end
end
end
end


function b.displaysOver(d,e,c,f)
local g=g(d,f)
local a=g.index.sources[e]
if not(a and i(a))then return c>b.MAX_DISPLAYS end
local h=G(a.spec,a.rec)
local a,i,g=l(g,a.rec,a)
if h and h*2^a*2^g*c<=b.MAX_DISPLAYS then return false end
return b.displays(d,e,f)*c>b.MAX_DISPLAYS
end


function b.displays(a,d,c)
local c=g(a,c)
local a=c.index.sources[d]
if not(a and i(a))then return 1 end
local e=c.view()
local d=e.sourcesById[d]
local f=d and b.cells(d,e)or 1
local b,g=0,{}
for j,h in ipairs(type(a.rec.layers)=="table"and a.rec.layers or{})do
local i,e={},0
for b,h in ipairs(type(h.looks)=="table"and h.looks or{})do
local b=k(c,h,a,f>1,d and d.layers[j])
if b and not i[b]then
i[b]=true
e=e+1
end
for b,a in ipairs(t(c,h,a))do g[a]=true end
end
b=math.max(b,e)
end
local a=0
for b in pairs(g)do a=a+1 end
return f*2^b*2^a
end



local function p(a,e,b)
for f,a in ipairs(type(a.sources)=="table"and a.sources or{})do
local d=type(a)=="table"and e.index.sources[a.id]
for g,a in ipairs(d and type(a.layers)=="table"and a.layers or{})do
local f="sources["..f.."].layers["..g.."]"
if a.shown==false then
local c=false
for b,a in ipairs(type(a.looks)=="table"and a.looks or{})do
if a.shown==true then c=true end
end
if not c then b[#b+1]={rule="R7",path=f,note=true,
text="is hidden and no look shows it, so it never draws."}end
end
for i,a in ipairs(type(a.looks)=="table"and a.looks or{})do
for a,g in ipairs(h(a["while"]))do
local a=j(e,g,d)
local e=a and((a.entry and a.entry.on==false)or(a.cond and a.cond.rec.enabled==false))

if e and a.src==d and d.rec.enabled==false then e=false end
if e then
b[#b+1]={rule="R7",path=f..".looks["..i.."]",note=true,
text=c(g).." is switched off, so this look never holds; kept."}
end
end
end
end
end
end



local function l(a,e)
local b={}
for i,a in ipairs(type(a.sources)=="table"and a.sources or{})do
local f=type(a)=="table"and e.index.sources[a.id]
for j,a in ipairs(f and type(a.layers)=="table"and a.layers or{})do
local c=type(a.looks)=="table"and a.looks or{}
local a,d,g,h={},{},false,false
for c,b in ipairs(c)do
if n(e,b,f)then
a[#a+1]=b
if g then h=true end
else
d[#d+1]=b
g=true
end
end
if h then
b[#b+1]="sources["..i.."].layers["..j.."]"
for a,b in ipairs(a)do c[a]=b end
for b,d in ipairs(d)do c[#a+b]=d end
end
end
end
return b
end



function b.problems(a,b)
local b,c=m(a,b)
q(a,c,b)
p(a,c,b)
return b
end



local function n(e,b,c)
if not b then return false end
if b.what=="item"then
for a=#b.owner,1,-1 do
if b.owner[a]==b.item then
table.remove(b.owner,a)
if#b.owner==0 then c[b.owner]=true end
return true
end
end
elseif b.what=="effect"then
local d=false
a.eachRecord("element",e,function(e,a)
if d or e~="event"or type(a.effects)~="table"then return end
for e=#a.effects,1,-1 do
if a.effects[e]==b.item then
table.remove(a.effects,e)
if#a.effects==0 then c[a.effects]=true end
d=true
end
end
end)
return d
elseif b.what=="field"then
if b.owner[b.key]==nil then return false end
b.owner[b.key]=nil
if b.map and next(b.owner)==nil then c[b.owner]=true end
return true
elseif b.what=="fields"then
local a=false
for d,c in ipairs(b.keys)do
a=a or b.owner[c]~=nil
b.owner[c]=nil
end
return a
elseif b.what=="trim"then
if#b.owner<=b.keep then return false end
for a=#b.owner,b.keep+1,-1 do b.owner[a]=nil end
return true
end
return false
end




function b.unpicked(b)
local g={}
for i,b in ipairs(type(b.sources)=="table"and b.sources or{})do
local e=type(b)=="table"and d.Sources.get(b.kind)
if e and e.target and d.Sources.unset(b)then
local h=e.target.field
local a=a.field("source",h,b.kind)or{}
local e
if a.type=="spells"then
e="[ a spell's ID or name ]"
elseif a.type=="choice"then
e=f(d.Clean.choicesOf(a,b,{}))
elseif a.type=="list"and a.item and a.item.choices then
e="[ "..f(a.item.choices).." ]"
else
e="[ its ID ]"
end
g[#g+1]={rule="U1",path="sources["..i.."]",text="watches nothing, so it reads and draws"
.." nothing; give it "..c(h)..": "..e.."."}
end
end
return g
end



function b.listFaults(a,g,h,i,c)
local d,f=0,0
for j,a in ipairs(a)do
if a.note and not(c and c(a))then
g:note(e(h,a.path),a.text)
elseif not(c and c(a))then
d=d+1
if i+d<=b.MAX_FAULTS then g:fault(e(h,a.path),a.text)else f=f+1 end
end
end
if f>0 then g:fault(h,"…and "..f.." more; fix these and check again.")end
return d
end







function b.stateLooksFirst(a)return l(a,g(a))end

local p={C2=true,C4=true}
local function r(d,c,f)
local g=g(d)

local k=c.vars.buttonCues or nil
for b,a in ipairs(l(d,g))do
c:note(e(f,e(a,"looks")),"moved its looks keyed on one state to its head: they apply first.")
end
if c:strict()then
local a=b.problems(d,k)
for b,a in ipairs(a)do
if a.fix then a.fix.owner[a.fix.key]=a.fix.value end
end
if c.mode=="import"then
for c,b in ipairs(b.unpicked(d))do a[#a+1]=b end
else
for b,a in ipairs(a)do
if a.importOnly then a.note,a.text=true,"sets nothing yet."end
end
end
if b.listFaults(a,c,f,0)>0 then c.failed=true end
return
end



local g={}
local m=#(type(d.customStates)=="table"and d.customStates or{})
local h,i=nil,0
repeat
i=i+1
local l=false
local j=0
for b,a in ipairs(b.problems(d,k))do


if(not a.note or a.fix)and not a.importOnly and not p[a.rule]then
j=j+1
if n(d,a.drop,g)then
c.dropped=c.dropped+1
if#c.droppedPaths<10 then c.droppedPaths[#c.droppedPaths+1]=e(f,a.path)end
l=true
end
end
end
h=h or(j+m+4)
until not l or i>=h


if next(g)or c.dropped>0 then
for b=1,4 do
a.walk("element",d,{},"",function(a,b,c)
if type(b)~="table"then return end
if g[b]or(a.type=="record"and not a.keepEmpty and next(b)==nil)then c[a.name]=nil end
end)
end
end
end








local v={source="source",layer="layer",customState="custom state",effect="effect",["part:glow"]="glow",
["part:barText"]="text"}

local function l(c)
local b={}
for f,c in ipairs(type(c.sources)=="table"and c.sources or{})do
local e=type(c)=="table"and a.variantOf(c)
local g=e and type(c.facts)=="table"and c.facts or{}
for h,d in ipairs(e and e.factOrder or{})do
local e=e.facts[d]
local f="sources["..f.."].facts."..d
if a.isListFact(e)then
local a=g[d]
if a==nil and e.default and e.default(c)then b[d]=b[d]or f end
for c,a in ipairs(type(a)=="table"and a or{})do
if type(a)=="table"and type(a.id)=="string"then b[a.id]=b[a.id]or(f.."["..c.."]")end
end
end
end
end
return b
end

local function y(b,c)
local d=b.kind or"its source"
if b.states and b.states[c]then return d.."'s state"end
local e=b.facts and b.facts[c]
if e and not a.isListFact(e)then return d.."'s fact"end
if b.events and b.events[c]then return d.."'s event"end
end
a.rule("element","ids",function(f,d,s)
local m=a.reserved()
local i,j,g={},{},{}
local n=l(f)
local t=false
a.eachId(f,function(b,u,o,h,k,l)
local i=i
if h=="source"then
local a=l.source
j[a]=j[a]or{}
i=j[a]
end
local p={owner=u,pool=i,recordName=k,vars=l,space=h,at=o}
if b==nil then
g[#g+1]=p
return
end
local v=v[k]or(h=="source"and"fact item")or"part"
local f,q

local j=h=="source"and a.variantOf(l.source)
local r=j and j.facts[b]
local m=b==a.GAME and m[b]or k=="customState"and m[b]
or j and y(j,b)
if m then

f,q=c(b).." is "..m.."; give this "..v.." another id.",h~="source"
elseif a.isListFact(r)and r~=l.fact then
f=c(b).." is "..(j.kind or"its source").."'s "..r.label.."; give this "..v
.." another id."
elseif i[b]then
f=c(b).." is already "..i[b].."'s id."
elseif k=="customState"and n[b]then

f,q=c(b).." is already "..n[b].."'s id.",true
end
if f then
if d:strict()then
d:fault(e(s,e(o,"id")),f)
t=true
else


d.dropped=d.dropped+1
p.renames=q and b or nil
g[#g+1]=p
u.id=nil
end
return
end
i[b]=o
end)
if t then
d.failed=true
return
end
local e={}
for c,b in ipairs(g)do
local c=a.get(b.recordName)
local g=c.madeId and c.madeId(b.owner,b.vars)or b.recordName
local c={}
for a in pairs(b.pool)do c[a]=true end
local d
if b.recordName=="customState"then
for a in pairs(n)do c[a]=true end
d=m
elseif b.space=="source"then
local b=a.variantOf(b.vars.source)
for a in pairs(b and b.states or{})do c[a]=true end
for a in pairs(b and b.events or{})do c[a]=true end
for b,d in pairs(b and b.facts or{})do
if not a.isListFact(d)then c[b]=true end
end
end
local c=a.partId(g,c,d)
if b.renames then
b.owner.id=b.renames
a.renameId(f,b.renames,c,b.space=="source"and b.vars.source.id or nil)
end
b.owner.id=c
b.pool[c]="made"
e[#e+1]=(b.at==""and""or(b.at.." "))..c
end
if#e>0 and d.mode=="import"then
d:note(s,"gave ids where left out: "..table.concat(e,", ")..".")
end
end)

a.rule("element","checker",r)





a.get("element").faultsPast=function(e,f,g,c,i)
local e=d.copy(e)
if type(e.id)~="string"then e.id="element"end
local h=d.Clean.newCtx("load",c)
h.noRules="element"
local e=d.Clean.cleanRecord("element",e,h,"")
if e==d.Clean.FAIL or(h.recordsDropped or 0)>0 then return end
local d=d.Clean.newCtx("import",c)
for b,a in ipairs(a.get("element").rules)do
if a.name=="ids"then a.fn(e,d,"")end
end
if d.failed then return end
local d={}
for a=i+1,#f.messages do d[#d+1]=f.messages[a].path end
local function h(a)
for c,b in ipairs(d)do
local b=g==""and b or b:sub(#g+2)
if b:sub(1,#a.path)==a.path then return true end
end
return false
end
local a={}
for c,b in ipairs(b.problems(e,c and c.buttonCues or nil))do
if not b.note then a[#a+1]=b end
end
for c,b in ipairs(b.unpicked(e))do a[#a+1]=b end
b.listFaults(a,f,g,#d,h)
end






a.rule("element","quick",function(h,i,k)
local g=h.quick
if type(g)~="table"then return end
local function j(a,b)
if i:strict()then
i:note(e(k,a),b.."; left out.")
else
i.dropped=i.dropped+1
end
end

local function e(e)
local b,g=b.quickTarget(h,e,true)
if not b then return g end
if(e.clear==true)==(e.value~=nil)then return"sets no value: give it a value, or clear"end
if e.value~=nil and b.field.type=="keys"then
local b,d=a.splitKey(e.value)
if type(e.value)~="string"or d~=a.GAME or not a.gameFactSpec(b)then
return"sets "..c(e.field).." to something other than one game fact; use "..f(x())
end
elseif e.value~=nil then
local a=d.Clean.newCtx("import",b.ownVars)
local b=d.Clean.cleanValue(b.field,e.value,a,"",b.target)
if b==d.Clean.FAIL or#a.messages>0 then
return"has a value that "..c(e.field).." doesn't take"..(a.messages[1]and(": "..a.messages[1].text)or"")
end
e.value=b
end
end
local function i(a,c)
if a.section~=nil then
if c then return"is a section inside a section"end
if not(type(a.rows)=="table"and#a.rows>0)then return"is a section with no rows"end
elseif a.choices~=nil then
if a.label==nil then return"is a choice with no label"end
for b,a in ipairs(a.choices)do
local b="choice "..b
if a.label==nil then return b.." has no label"end
if#(a.writes or{})==0 then return b.." writes nothing"end
for c,a in ipairs(a.writes)do
local a=e(a)
if a then return b.."'s write "..c.." "..a end
end
end
if#a.choices<2 then return"offers fewer than two choices"end
else
if a.field==nil then return"names no field"end
local b,a=b.quickTarget(h,a)
return a
end
end



local e={number=true,integer=true,percent=true}
local function f(f,d)
if type(d)~="table"or type(d.field)~="string"then return"names no setting: give it a field"end
local a,b=b.quickTarget(h,d)
if not a then return b end
local a,b=f.field,a.field
if not e[a.type]then return"is only for a row that sets a number"end
if a.type~=b.type or a.step~=b.step then
return"names "..c(d.field)..", which isn't a number set in the same steps as the first"
end
if(b.min and(a.min==nil or a.min<b.min))or(b.max and(a.max==nil or a.max>b.max))then
return"names "..c(d.field)..", which doesn't take every value the first does"
end
end
local function k(a,c)
if a.also==nil or a.choices~=nil or a.section~=nil then
if a.also~=nil then
j(c..".also","is only for a pointer")
a.also=nil
end
return
end
local d=b.quickTarget(h,a)
for b=#a.also,1,-1 do
local d=d and f(d,a.also[b])
if d then
table.remove(a.also,b)
j(c..".also["..b.."]",d)
end
end
if#a.also==0 then a.also=nil end
end
local function e(b,d,f)
for c=#b,1,-1 do
local a=b[c]
local d=d.."["..c.."]"
if a.section~=nil and not f and type(a.rows)=="table"then
e(a.rows,d..".rows",true)
if#a.rows==0 then a.rows=nil end
end
local e=i(a,f)
if e then
table.remove(b,c)
j(d,e)
else
k(a,d)
end
end
end
e(g,"quick",false)

local b,c=0,{}
for d,e in ipairs(g)do
if e.section~=nil then
for f=1,#e.rows do
b=b+1
if b>a.QUICK_MAX then c[#c+1]={e.rows,f,"quick["..d.."].rows["..f.."]"}end
end
else
b=b+1
if b>a.QUICK_MAX then c[#c+1]={g,d,"quick["..d.."]"}end
end
end
for b=#c,1,-1 do
local b=c[b]
table.remove(b[1],b[2])
j(b[3],"is past the "..a.QUICK_MAX.." quick settings an element can have")
end
for a=#g,1,-1 do
if g[a].section~=nil and#g[a].rows==0 then table.remove(g,a)end
end
if#g==0 then h.quick=nil end
end)


a.rule("group","keys",function(c,b,f)
local g={index=a.keyIndex({}),summaries={}}
local d={}
for b,a in ipairs(a.keyFieldsOf("group"))do o(g,h(c[a]),a,"group",nil,d)end
for g,d in ipairs(d)do
b:problem(e(f,d.path),d.text,function()
for b,a in ipairs(a.SHOWING)do c[a]=nil end
end)
if b.failed then return end
if not b:strict()then return end
end
end)






function b.partOf(d,h)
if h==nil then return"element",d,{},""end
local c,e=a.splitKey(h)
local b,i
a.eachRecord("element",d,function(f,g,j,d)
if b then return false end
local a=a.get(f)
if f=="element"then i=d end
if e then
if a.idSpace=="source"and d.source and d.source.id==e and g.id==c then
b={f,g,d,j}
end
elseif a.idSpace=="element"and g.id==h then
b={f,g,d,j}
end
end)
if b then return b[1],b[2],b[3],b[4]end
if not e then return end
for g,d in ipairs(type(d.sources)=="table"and d.sources or{})do
local e=type(d)=="table"and d.id==e and a.variantOf(d)
local e=e and e.facts[c]
local f=type(d.facts)=="table"and d.facts or nil
if a.isListFact(e)and(f==nil or f[c]==nil)and e.default and e.default(d)then

local e={}
for a,b in pairs(d)do e[a]=b end
e.facts={}
for a,b in pairs(f or{})do e.facts[a]=b end
e.facts[c]={{id=c}}
a.eachRecord("source",e,function(f,d,g,h)
if b then return false end
if a.get(f).idSpace=="source"and d.id==c and d==e.facts[c][1]then
b={f,d,h,g}
end
end,i,"sources["..g.."]")
if b then return b[1],b[2],b[3],b[4]end
end
end
end
a.partOf=b.partOf




function b.quickPlain(a,b)
if a~=nil and a.type=="keys"then return b==true and not a.exportOnly end
return a~=nil and not a.exportOnly and a.name~="id"and a.name~="kind"and a.type~="record"
and a.type~="keys"and not(a.type=="list"and a.record)
end









function b.quickTarget(n,e,o)
local j,h,k,f=b.partOf(n,e.part)
if not j then return nil,"names no part "..c(e.part)end
local i=e.part~=nil and c(e.part)or"the element"
local f={name=j,rec=h,vars=k,path=f}
local l,g,m=j,h,k
if e.look~=nil then
if j~="layer"then return nil,"names a look of "..i..", which is no layer"end
local b=k.source
local n=a.keyIndex(n)
local j=b and n.sources[b.id]
local o=j and j.words[e.look]
local j=o and o.what~="event"or(n.customStates[e.look]~=nil and not(j and j.words[e.look]))
if not j then
return nil,"names no key "..c(e.look).." of "..i.."'s source, and no custom state"
end
local j,k,a=a.frame("layer",h,k)
f.lookWord,f.srcId=e.look,b.id
f.lookIndex=d.Resolve.lookOn(h,e.look,b.id)
l,g,m="look:"..h.kind,f.lookIndex and h.looks[f.lookIndex]or{},a
i="the "..c(e.look).." look of "..i
end
local h,d=a.fieldAt(l,g,e.field,m)
if not b.quickPlain(h,o)then return nil,"names no setting "..c(e.field).." of "..i end
local c,e,b=a.frame(l,g,m)
if#d==2 then
local c=type(g)=="table"and g[d[1]]or nil
local f
for b,a in ipairs((a.frame(l,g,m)))do
if a.name==d[1]then f=a end
end
e,e,b=a.frame(f.record,type(c)=="table"and c or{},b)
g=c
end
f.field,f.names,f.target,f.ownVars=h,d,g,b
return f
end


local function c(b)
local a={}
for b in tostring(b or""):gmatch("[^%.]+")do
local c,d=b:match("^([^%[]+)%[(%d+)%]$")
if c then
a[#a+1],a[#a+2]=c,tonumber(d)
else
a[#a+1]=b
end
end
return a
end
b.pathList=c
local function n(a,b)
for c,b in ipairs(b)do
if type(a)~="table"then return nil end
a=a[b]
end
return a
end
local function l(a,b,c)
local a=a
for c=1,#b-1 do
local b=b[c]
if type(a[b])~="table"then a[b]={}end
a=a[b]
end
a[b[#b]]=d.copy(c)
end





function b.setLookField(f,b,h)
local e
for a=#b-2,1,-1 do
if b[a]=="looks"then e=a break end
end
if not e then return false end
local a={}
for c=1,e-1 do a[c]=b[c]end
local a=n(f,a)
if type(a)~="table"then return false end
local c=b[e+1]
if type(c)=="string"then
local b=type(f.sources)=="table"and f.sources[b[2]]or nil
local b=d.Resolve.lookOn(a,c,type(b)=="table"and b.id or nil)
if not b then
if h==nil then return true end
a.looks=type(a.looks)=="table"and a.looks or{}
a.looks[#a.looks+1]={["while"]=c}
b=#a.looks
end
c=b
end
local f=type(a.looks)=="table"and a.looks[c]or nil
if type(f)~="table"then return false end
local g={}
for a=e+2,#b do g[#g+1]=b[a]end
l(f,g,h)
if d.Resolve.valuesOf(f)==nil then
table.remove(a.looks,c)
if#a.looks==0 then a.looks=nil end
end
return true
end



function b.quickPath(a,d,e)
local a=b.quickTarget(a,d,e)
if not a then return nil end
local b=c(a.path)
if a.lookWord~=nil then
b[#b+1]="looks"
b[#b+1]=a.lookIndex or a.lookWord
end
if#a.names==2 then b[#b+1]=a.names[1]end
b[#b+1]=a.field.name
return b,a
end



function b.quickApply(a,c)
local d,e=b.quickPath(a,c,true)
if not d then return false end
local c=c.clear and nil or c.value
if e.lookWord~=nil then return b.setLookField(a,d,c)end
l(a,d,c)
return true
end


local function c(b)
local a={}
for b,c in pairs(b)do a[b]=c end
return a
end



function b.relook(b,f,e,g,h,i)
local a=c(b)
a.looks=c(b.looks or{})
local b=c(a.looks[f]or{})
b["while"],b.unless,b.shown=e["while"],e.unless,e.shown
a.looks[f]=b
a.compiled,a.borrowed=nil,nil
d.Resolve.compileLayer(a,g,h,i)
return a
end


local function l(a,b)
local a=a
for c in tostring(b):gmatch("[^%.]+")do
local b,d=c:match("^([^%[]+)%[(%d+)%]$")
if b then
a=type(a)=="table"and type(a[b])=="table"and a[b][tonumber(d)]or nil
else
a=type(a)=="table"and a[c]or nil
end
if a==nil then return nil end
end
return a
end
b.at=l








local function t(b,c,a,d)
local c,d=m(b,c,a,d)
q(b,d,c,a and a.caps,a and a.cellsAt)
local a={}
for c,b in ipairs(c)do

if not b.note and not b.importOnly then a[#a+1]=b end
end
return a
end




local function m(a,b)
local d={}
for a in tostring(b):gmatch("[^%.]+")do d[#d+1]=a end
local b=c(a)
local e,f=a,b
for g,b in ipairs(d)do
local i,a=b:match("^([^%[]+)%[(%d+)%]$")
local j=g==#d
if i then
a=tonumber(a)
local b=e[i]
if type(b)~="table"and not(j and a==#h(b)+1)then return nil end
local g=type(b)=="table"and b[a]or nil
local d=h(b)
d=d==b and c(b)or d
f[i]=d
if g==nil and j and a==#d+1 then g={}end
if type(g)~="table"then return nil end
d[a]=c(g)
e,f=g,d[a]
else
if type(e[b])~="table"then return nil end
f[b]=c(e[b])
e,f=e[b],f[b]
end
end
return b,f
end


local function e(b,c)
for d,b in ipairs(h(b))do
local a,b=a.splitKey(b)
if b==nil and a~=nil and c[a]then return true end
end
return false
end









local function x(d,c,f,i,h)
local b={facts={},caps={},looks={}}
local g=type(d.sources)=="table"and d.sources or{}
if c=="look"then
b.looks[f.."."..i]=true
b.caps[f]=true
for a in ipairs(g)do b.facts[a]=a~=f or nil end
elseif c=="customState"then
b.customStates=true
local c,i={},a.keyFieldsOf("customState")
if type(h)=="string"then c[h]=true end
local h=type(d.customStates)=="table"and d.customStates or{}
local f=next(c)~=nil
while f do
f=false
for b,a in ipairs(h)do
if type(a)=="table"and type(a.id)=="string"and not c[a.id]then
for d,b in ipairs(i)do
if not c[a.id]and e(a[b],c)then
c[a.id],f=true,true
end
end
end
end
end
for f,a in ipairs(a.keyFieldsOf("element"))do
if e(d[a],c)then b.element=true end
end
a.eachRecord("element",d,function(d,f)
if d~="effect"then return end
for d,a in ipairs(a.keyFieldsOf("effect"))do
if e(f[a],c)then b.effects=true end
end
return false
end)
local d=false
for f,a in ipairs(g)do
for g,a in ipairs(type(a)=="table"and type(a.layers)=="table"and a.layers or{})do
for h,a in ipairs(type(a)=="table"and type(a.looks)=="table"and a.looks or{})do
if type(a)=="table"and(e(a["while"],c)or e(a.unless,c))then
b.looks[f.."."..g],b.caps[f],d=true,true,true
end
end
end
end
for a in ipairs(d and g or{})do b.facts[a]=true end
elseif c=="element"then
b.element=true
elseif c=="effect"then
b.effects=true
else
return nil
end
return b
end








local function v(a,g,j,h,e)
local f
local m=h and{buttonCues=h}or nil
local function k()
f=f or d.Resolve.element(g,m)
return f
end
local h=type(g.sources)=="table"and g.sources or{}
a.cellsAt,a.widths={},{}
for e,c in ipairs(h)do
local d=type(c)=="table"and j.sources[c.id]
if d and a.caps[e]and i(d)then
local b
a.cellsAt[e]={atMost=G(d.spec,c),exact=function()
if not b then
local a=k().sourcesById[c.id]
b=a and K(d.spec,a.facts)or 1
end
return b
end}
end
if d and a.facts[e]then
local g=false
local i=type(c.facts)=="table"and c.facts or{}
for j,h in ipairs(d.spec.factOrder)do
local h,d=d.spec.facts[h],i[h]
if h.range and type(d)=="table"and#d>0 then
local i=k().sourcesById[c.id]
local c=i and{own=b.cellInto(f,c.id,{}).w,all=b.cellInto(f,nil,{}).w}
a.widths[e]=c or false
local c=c and math.floor(b.DRIVER_MOST/math.max(c.own,c.all))or 255
for b,a in ipairs(d)do
local b=w(h,a)
if b and b>c and a.enabled~=false then g=true end
end
end
end
a.facts[e]=g or nil
end
end

if next(a.facts)then
a.layers={layers={}}
for c,b in ipairs(h)do
for d,c in ipairs(type(b)=="table"and type(b.layers)=="table"and b.layers or{})do
if type(c)=="table"then
a.layers.layers[#a.layers.layers+1]={source=b.id,looks=c.looks}
end
end
end
end
local l=false
for a in pairs(a.caps)do
local a=type(h[a])=="table"and j.sources[h[a].id]
if a and i(a)then l=true end
end
local f=e and e.si and h[e.si]
if l and f then
local h,i=j.sources[f.id],e.k
a.kept={holds={},values={}}
function a.view()
local a=k()
local g=a.sourcesById[f.id]
local k=g and g.layers[e.li]
if not(h and k)then return a end
local d=c(a)
d.sourcesById=c(a.sourcesById)
d.sourcesById[f.id]=c(g)
d.sourcesById[f.id].layers=c(g.layers)
d.sourcesById[f.id].layers[e.li]=b.relook(k,i,f.layers[e.li].looks[i],h,j,
a.buttonCues)
return d
end
elseif l and e and e.ci then

local b={id=g.id,customStates={g.customStates[e.ci]}}
function a.view()
local f=k()
local b=d.Resolve.element(b,m).customStates[1]
local a=c(f)
a.customStates=c(f.customStates)
a.customStates[e.ci]=b
a.customStatesById=c(f.customStatesById)
if b.id~=nil then a.customStatesById[b.id]=b end
return a
end
end
return a
end





local function n(a,b)
local c=a.path:sub(#b+1)

return not a.note and not a.importOnly and a.path:sub(1,#b)==b and(c==""or c:match("^[%.%[]")~=nil)
end
function b.refusedAt(e,d,f)
d=tostring(d)
local c={facts={},caps={},looks={}}
local g,i=d:match("^sources%[(%d+)%]%.layers%[(%d+)%]%.looks%[%d+%]$")
local h
if g then
c.looks[g.."."..i],c.caps[tonumber(g)]=true,true
elseif d:match("^customStates%[%d+%]$")then
c.customStates,c.effects=true,true
else
c=nil
end
if c then
local a=a.keyIndex(e)
v(c,e,a,f)
h=t(e,f,c,a)
else
h=b.problems(e,f)
end
for b,a in ipairs(h)do
if n(a,d)then return true end
end
return false
end

function b.keysFor(e,f,k,b,u)
local i={}
if b then
for c,b in ipairs(a.gameFacts())do
i[#i+1]={key="game."..b,label=a.gameFactSpec(b).label,section="game",status="offered"}
end
return i
end

local c
e,c=m(e,f)
if not e then return i end
local p=a.keyIndex(e)
local q=g(e,nil,p)
local r,b,m,n,o
local w=tostring(f):match("^(sources%[%d+%])")
local g=tostring(f):match("^(sources%[%d+%]%.layers%[%d+%])%.looks%[%d+%]$")
if g then
b="look"
local a=l(e,w)
r=a and q.index.sources[a.id]
m="look:"..tostring(l(e,g).kind)
n,o=g:match("^sources%[(%d+)%]%.layers%[(%d+)%]$")
n,o=tonumber(n),tonumber(o)
elseif f==""then
b="element"
elseif tostring(f):match("^customStates%[%d+%]$")then
b="customState"
else
b="effect"
end
m=m or b
k=k or a.keyFieldsOf(m)[1]
local g=x(e,(b~="effect"or tostring(f):match("effects%[%d+%]$"))and b or nil,n,o,
c.id)
if g then g.terms,g.changing={},c end
if g then
v(g,e,p,u,(b=="look"and{si=n,li=o,
k=tonumber(tostring(f):match("%[(%d+)%]$"))})
or(b=="customState"and{ci=tonumber(tostring(f):match("%[(%d+)%]$"))})or nil)
end
local n={}
for b,a in ipairs(t(e,u,g,p))do n[a.path.."\0"..a.text]=true end

local m=a.keyFieldsOf(m)
local l,o={"hold","shown"},{}
for b,a in ipairs(m)do l[#l+1]=a end
for b,a in ipairs(l)do o[a]=c[a]end
local w=h(c[k])
local f={}

local function v(i,h)
if h then
for b,a in ipairs(m)do c[a]=nil end

if b=="customState"then c.hold=nil end
if b=="look"and d.Resolve.valuesOf(c)==nil then c.shown=true end
end
local a=0
for c,b in ipairs(w)do
if not h then
a=a+1
f[a]=b
end
end
f[a+1]=i
for a=a+2,#f do f[a]=nil end
c[k]=f
local a
for c,b in ipairs(t(e,u,g,p))do
if not a and not n[b.path.."\0"..b.text]then a=b end
end
for b,a in ipairs(l)do c[a]=o[a]end
return a
end
local e={}
for b,a in ipairs(h(c[k]))do e[a]=true end
local function d(c,h,f)
if e[c]then return end
local a=j(q,c,b=="look"and r or nil)
local d,e="offered",nil
local g=v(c)
if g then
if v(c,true)then return end
d,e="greyed",g.text
elseif a and((a.entry and a.entry.on==false)or(a.cond and a.cond.rec.enabled==false))then
d,e="greyed",f.." is switched off."
end
local g
if b=="look"then g=(a and a.src==r and a.what=="state")and"state"or"flag"end
i[#i+1]={key=c,label=f,section=h,status=d,line=e,band=g}
end
for a,c in ipairs(q.index.sources)do
local e=c==r
for f,a in ipairs(s(c))do
if a.what~="event"then
d((e and b=="look")and a.word or(c.rec.id.."."..a.word),e and"own"or c.rec.id,
a.label or a.word)
end
end
end
for c,b in ipairs(a.gameFacts())do d("game."..b,"game",a.gameFactSpec(b).label)end

local a={}
for c,b in pairs(q.index.customStates)do a[#a+1]=b end
table.sort(a,function(a,b)return a.i<b.i end)
for e,a in ipairs(a)do
if not(b=="customState"and a.rec==c)then d(a.rec.id,"customStates",a.rec.name or a.rec.id)end
end
return i
end







local function n(a,c)
local d={["while"]=a["while"],unless=a.unless}
local b,a=d,{}
for b in c:gmatch("[^%.]+")do a[#a+1]=b end
for c=1,#a-1 do
b[a[c]]=b[a[c]]or{}
b=b[a[c]]
end
b[a[#a]]=c:match("colour$")and"#ffffff"or true
return d
end
function b.lookFields(a,e,o,m)
local c=l(a,e)
local e,q=tostring(e):match("^(sources%[%d+%])%.layers%[(%d+)%]$")
local f=e and l(a,e)
if type(c)~="table"or type(f)~="table"then return{}end
local e=g(a,m)
local a=e.index.sources[f.id]
local g=type(c.looks)=="table"and c.looks[o]or{}
local p=e.view()
local f=p.sourcesById[f.id]
local l=f and f.layers[tonumber(q)]or c

local m
if a and i(a)then
local function d(f,g)
local b,d={},0
for c,h in ipairs(type(c.looks)=="table"and c.looks or{})do
local a=c~=o and k(e,h,a,f,g)
if a and not b[a]then
b[a]=true
d=d+1
end
end
return b,d
end


local h,c=d(true,nil)
if c>=b.MAX_BITS then
local c=f~=nil and b.cells(f,p)>1
local d,f=d(c,l)
local a=k(e,n(g,"opacity"),a,c,l)
if a and not d[a]and f>=b.MAX_BITS then
m="A buff's or debuff's layer takes three switched sets of keys; past them a look changes only tint,"
.." overlay and ring."
end
end
end
local f=false
for c,b in ipairs(a and i(a)and h(g["while"])or{})do
local b=j(e,b,a)
if b and b.src==a and b.word=="missing"then f=true end
end
local e={}
for d,a in ipairs(d.Resolve.leafPaths(l))do
if not(f and b.missingTexts(c,n(g,a))==a)then
local b,f=a:match("^([^%.]+)%.?(.*)$")
local c,d="offered",nil
if m and not(z[b]or(b=="border"and A[f]))then c,d="greyed",m end
e[#e+1]={path=a,status=c,line=d}
end
end
return e
end
