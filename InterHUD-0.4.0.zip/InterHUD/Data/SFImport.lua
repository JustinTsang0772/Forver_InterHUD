












local a,h=...
local q,D,l,a,w=h.Schema,h.Store,h.Clean,h.Debug,h.Check
local r=h.Migrate

local b={}
h.SFImport=b

b.PREFIX="!SF1!"

b.VERSION_MIN,b.VERSION_MAX=9,10
b.NAME="ShamanForever"


b.OLDER="This export is from an older ShamanForever: update ShamanForever, export again, then paste."
b.NEWER="This export is from a newer ShamanForever than InterHUD knows: update InterHUD."
b.CUT="That paste was cut short: clear the box and paste it again."
b.UNREADABLE="This ShamanForever export can't be read."
b.FAULT="InterHUD couldn't read this ShamanForever profile: a fault on our side. Tell us on Discord or CurseForge."
b.EMPTY="Nothing in this ShamanForever profile comes across: no group with an element InterHUD has."
b.OPENING="This is a ShamanForever profile. Some of its settings don't have an equivalent in InterHUD, listed in"
.." the moving over note."

a.experimental("the ShamanForever export's decode: C_EncodingUtil's DecodeBase64, DecompressString and DeserializeCBOR"
.." are on no playbook row (CL-16 proves JSON, CompressString and EncodeBase64 at rest); ShamanForever's own import"
.." has shipped them since 0.4.0 (C)")



local c={
profile={iconSize=44,idleFade=0.2},
group={point="CENTER",x=0,y=-160,scale=1,alpha=0.8,sizeFollow=true,size=44,
orientation="horizontal",growth="forward",spacing=2,show="always",fadeAfter=0},
element={on=true,show="always"},
border={show=true,look="line",size=2,color={0,0,0,1}},
glow={look="spark",color={1,0.8,0.25,1},speed=0.5,low=0.25,width=0.2,lap=1.6},
pop={flash="edge",burst="both",motion="shakeV",size=1.6,speed=1,reach=1},
text={font="",outline="OUTLINE",shadow=true},
bar={texture="Blizzard"},
mana={look="both",overlay=0.25,tint=0.8,ring=0.6},
range={look="tint",overlay=0.45,tint=0.7},
totemBar={mode="everything",point="CENTER",x=-353,y=-182,scale=1,alpha=1,show="always",
fadeAfter=0,order={"fire","earth","water","air"},hidden={},dir="row",pop="up",spacing=2,
cast=true,arrows=true,arrowSize=20,tips="ooc",keys=false,keySize=13,keyX=0,keyY=0,
keyColor={0.85,0.85,0.85,1},call=true,recall=true,setSwitch="popout",setNumber=true,
extras="after",extrasScale=0.8,extrasGap=8,extrasSpacing=2,sizeFollow=true,size=44,
empty="pick",idleGrey=false,idleAlpha=0.35,offPick=true,badgeSize=0.45,badgeAlpha=0.75,
badgeSat=0.5,badgeX=0,badgeY=0,mana={on=true},range=true,rangeHeight=7,
rangeOut={0.9,0.12,0.08,0.8},rangeShow="out",rangeInColor={0.2,0.8,0.25,0.8},
rangeShape="strip",rangeGrey=false,rangeDotSize=12,rangeDotX=0,rangeDotY=0,rangePlace="in",rangeGap=3,
rangeOrder="after",pickHover=true,dropWith="shift",skin="default",barPlace="in",
expire={secs=10,grey=false,ring=false,fade=true,glow=false,over={}},
ended={pop=true,sound="none"},killed={flash=true,pop=true,glow=true,mark=true}},
swingBar={show="combat"},

uptimeTimer={text=true,textSize=12,textColor={0.5,1,0.4,1},textPos="auto",swipe=false,
swipeAlpha=0.6,bar=true,barHeight=8,barColor={0.46,1,0.35,1},barEdge="bottom",barPlace="in",
soon=10,soonColor={1,0.85,0.1,1},now=3,nowColor={1,0.25,0.2,1},timeColors=false},
}
b.DEFAULTS=c


local m={}
for b,a in ipairs({"shield","shock","flameshock","maelstrom","elementalfocus","flurry","improvedstormstrike",
"stormstrike","earthbind","stoneclaw","grounding","manatide","elementalmastery","firenova","naturesswiftness",
"farseer","riptide","chainlightning","projection","reincarnation","imbue","purge","curepoison",
"curedisease","waterwalking","waterbreathing"})do
m[a]="shaman-"..a
end

m.shield,m.shock="shaman-shields","shaman-shocks"
for b,a in ipairs({"berserking","bloodfury","rapidregeneration","shattercurse","skysight","stoneform",
"walkonair","warstomp"})do
m[a]="racial-"..a
end

local s={
tremor="Tremor Totem: not in InterHUD.",
lavaburst="Lava Burst: no longer in the game.",
}
b.PREMADE,b.GONE=m,s




local function f(a)
if type(a)~="table"or#a<3 or#a>4 then return false end
for b=1,#a do
if type(a[b])~="number"or a[b]~=a[b]then return false end
end
return true
end
local function a(c,d,b)

local a
if type(c)=="table"then a=c[d]end
if type(b)=="table"then
if f(b)then return f(a)and a or b end
return type(a)=="table"and a or b
end
if type(a)==type(b)and(type(a)~="number"or a==a)then return a end
return b
end

local function o(a,b)
local a=type(a)=="table"and a[b]
return type(a)=="table"and a or nil
end

local function j(c,d,b,e)
local a=a(c,d,b)
for c,b in ipairs(e)do
if a==b then return a end
end
return b
end
local function k(a)return math.floor(math.min(math.max(a,0),1)*100+0.5)end


local function p(a)return math.floor(math.min(math.max(a,-4000),4000)*2+0.5)/2 end
local function v(a,b,c)return math.min(math.max(a,b),c)end
local x={"TOPLEFT","TOP","TOPRIGHT","LEFT","CENTER","RIGHT","BOTTOMLEFT","BOTTOM","BOTTOMRIGHT"}
local d={"fire","earth","water","air"}


local function g(b)
if type(b)~="table"then return nil end
local c,e={},{}
local f=#b>0
for g,a in ipairs(f and b or d)do
local f=f or b[a]==true
local b=false
for d,c in ipairs(d)do b=b or c==a end
if f and b and not e[a]then
e[a]=true
c[#c+1]=a
end
end
return c
end
local function d(a)return math.floor(math.min(math.max(a,0),1)*255+0.5)end

local function i(a,b)
local b=b or a[4]or 1
local a=string.format("#%02x%02x%02x",d(a[1]),d(a[2]),d(a[3]))
if b<1 then a=a..string.format("%02x",d(b))end
return a
end

local function n(b,c,d)
local a
for c in c:gmatch("[^%.]+")do
if a then
b[a]=type(b[a])=="table"and b[a]or{}
b=b[a]
end
a=c
end
b[a]=d
end

local function E(a)
local a=tostring(a or""):lower():gsub("[^%w%-]+","-"):gsub("^%-+",""):gsub("%-+$","")
if a==""then a="group"end
return a:sub(1,32)
end
local function e(a,b,c)
a[#a+1]=l.message("note",b,"",c)
end



local t={"line","hairline","bevel","button","cdm"}
local u={"spark","halo","soft","heartbeat","proc","ants","cdmAnts","cdmGlow","darkPulse"}
local y={OUTLINE="outline",THICKOUTLINE="thick",NONE="none",[""]="none"}



local z={pop="grow",none="none",grow="grow",bounce="bounce",hop="hop",shake="shake",
shakeV="shakeV"}
local A={none=true,ring=true,star=true,both=true,rune=true}
local B={size={1.1,1.8},speed={0.5,2},reach={0.6,1.3}}
function b.popStyle(d,g,h)
local b=c.pop
local c={flash=j(d,"flash",b.flash,{"none","plain","edge"})}
local f=a(d,"burst",b.burst)
if A[f]then
c.burst=f
else
c.burst=b.burst
if f~=b.burst then e(g,h,"The pop burst "..tostring(f).." isn't in InterHUD.")end
end
c.motion=z[a(d,"motion",b.motion)]or b.motion
for e,f in pairs(B)do c[e]=v(a(d,e,b[e]),f[1],f[2])end
return c
end



local function F(h,j)
local d={}
local g=a(h,"border",c.border)
local f=a(g,"look",c.border.look)
d.border={colour=i(a(g,"color",c.border.color)),thickness=a(g,"size",c.border.size)}
for b,a in ipairs(t)do
if f==a then d.border.kind=a end
end
if not d.border.kind and f~=c.border.look then e(j,"Global","Border style "..f.." isn't in InterHUD.")end
if a(g,"show",true)==false then e(j,"Global","Border off: InterHUD's borders are per layer.")end
local g=a(h,"glowStyle",c.glow)
f=a(g,"look",c.glow.look)
d.glow={colour=i(a(g,"color",c.glow.color)),speed=a(g,"speed",c.glow.speed),
low=a(g,"low",c.glow.low),reach=a(g,"width",c.glow.width),lap=a(g,"lap",c.glow.lap)}
for b,a in ipairs(u)do
if f==a then d.glow.kind=a end
end
if not d.glow.kind and f~=c.glow.look then e(j,"Global","Glow style "..f.." isn't in InterHUD.")end
d.pop=b.popStyle(a(h,"popStyle",c.pop),j,"Global")
local b=a(h,"textStyle",c.text)
d.font={outline=y[a(b,"outline",c.text.outline)]or"outline",shadow=a(b,"shadow",c.text.shadow)}
local b=a(b,"font",c.text.font)
if b~=""then d.font.face=b end
d.barTexture={texture=a(a(h,"barStyle",c.bar),"texture",c.bar.texture)}
return d
end



local function G(b)
local function d(b,c,d,h)
local g=j(c,"look",d.look,{"tint","overlay","both"})
local function e(a)return q.field("buttonCue:"..b,a).default end
local function f(a,b)return i({tonumber(a:sub(2,3),16)/255,tonumber(a:sub(4,5),16)/255,
tonumber(a:sub(6,7),16)/255},b)end
local b={overlay=g~="tint"}
b.tint=f(e("tint"),g=="overlay"and 0 or a(c,"tint",d.tint))
if b.overlay then b.overlayColour=f(e("overlayColour"),a(c,"overlay",d.overlay))end
if h then
b.ring=true
b.ringColour=f(e("ringColour"),a(c,"ring",d.ring))
end
return b
end
return{notEnoughPower=d("notEnoughPower",a(b,"mana",c.mana),c.mana,true),
outOfRange=d("outOfRange",a(b,"range",c.range),c.range,false)}
end



local d={center="centre",topleft="topLeft",bottom="bottom"}

local function t(b)
local b=a(a(b,"timers",{}),"uptime",c.uptimeTimer)
local c=c.uptimeTimer
return{text=a(b,"text",c.text),textSize=a(b,"textSize",c.textSize),timeColours=a(b,"timeColors",c.timeColors),
textColour=i(a(b,"textColor",c.textColor)),
textPlace=d[tostring(a(b,"textPos",c.textPos)):lower()]or"centre",
swipe=a(b,"swipe",c.swipe),swipeDarkness=k(a(b,"swipeAlpha",c.swipeAlpha)),
bar=a(b,"bar",c.bar),barHeight=a(b,"barHeight",c.barHeight),
barColour=i(a(b,"barColor",c.barColor)),barEdge=j(b,"barEdge",c.barEdge,{"bottom","top"}),
soon=a(b,"soon",c.soon),soonColour=i(a(b,"soonColor",c.soonColor)),
now=a(b,"now",c.now),nowColour=i(a(b,"nowColor",c.nowColor))}
end



local function d(b)
return function(a)
for c,b in ipairs(b)do
if a==b then return a end
end
return nil
end
end
local function q(a)return math.floor(a*100+0.5)end
local u={
{"scale","scale"},{"alpha","opacity",k},{"order","order",g},{"hidden","hidden",g},
{"dir","direction",d({"row","column"})},{"pop","pickerSide",d({"up","down","right","left"})},
{"spacing","spacing"},{"cast","cast"},{"arrows","arrows"},
{"arrowSize","arrowSize"},{"tips","tooltips",d({"always","ooc","never"})},{"keys","keyText.shown"},
{"keySize","keyText.size"},
{"keyX","keyText.x"},{"keyY","keyText.y"},{"keyColor","keyText.colour",i},{"call","call"},
{"recall","recall"},{"setNumber","sets.number"},{"extras","extras.place"},
{"extrasScale","extras.size",q},{"extrasGap","extras.gap"},{"extrasSpacing","extras.between"},
{"idleGrey","notDown.greyed"},{"idleAlpha","notDown.opacity",k},{"offPick","otherPick.shown"},
{"badgeSize","otherPick.size",k},{"badgeAlpha","otherPick.opacity",k},
{"badgeSat","otherPick.saturation",k},{"badgeX","otherPick.x"},{"badgeY","otherPick.y"},
{"range","range.shown"},{"rangeShow","range.marks",d({"out","both"})},
{"rangeShape","range.shape",d({"strip","dot","none"})},{"rangeGrey","range.greyed"},
{"rangeOut","range.colour",i},{"rangeInColor","range.inColour",i},
{"rangeHeight","range.thickness"},{"rangeDotSize","range.dotSize"},{"rangeDotX","range.x"},
{"rangeDotY","range.y"},{"rangeGap","range.gap"},{"rangeOrder","range.order",d({"after","before"})},
{"pickHover","hoverPickers"},{"dropWith","dropWith",d({"shift","alt","ctrl","off"})},
}
local y={pick="pick",frame="colour",blank="blank"}

local function H(q,k,r)
local f=o(q,"totemBar")
if not f then return nil end
local d=c.totemBar
local l="Totem bar"
local g={}
local m=j(f,"mode",d.mode,{"blizzard","active","everything"})
g.enabled=m~="blizzard"
if m=="active"then e(k,l,"Active totems mode isn't in InterHUD: the bar is on, Everything's way.")end
g.position={point=j(f,"point",d.point,x),x=p(a(f,"x",d.x)),y=p(a(f,"y",d.y))}
for c,b in ipairs(u)do
local a=a(f,b[1],d[b[1]])
if b[3]then
a=b[3](a)
if a==nil then a=b[3](d[b[1]])end
elseif type(a)=="table"then
a=h.copy(a)
end
if a~=nil then n(g,b[2],a)end
end
g.gcdSweep=a(a(q,"gcdStyle",{}),"show",true)
g.size=a(f,"sizeFollow",d.sizeFollow)and r or a(f,"size",d.size)
g.sets=g.sets or{}
g.sets.switch=a(f,"setSwitch",d.setSwitch)=="cycle"and"cycle"or"picker"
n(g,"notDown.show",y[a(f,"empty",d.empty)]or"pick")
n(g,"range.place",a(f,"rangePlace",d.rangePlace)=="out"and"beside"or"in")
g.noPower=a(a(f,"mana",d.mana),"on",d.mana.on)
local j=a(f,"expire",d.expire)
g.expiring={seconds=a(j,"secs",d.expire.secs),grey=a(j,"grey",d.expire.grey),
ring=a(j,"ring",d.expire.ring),pulse=a(j,"fade",d.expire.fade),glow=a(j,"glow",d.expire.glow)}

local n={}
local m={}
for a in pairs(a(j,"over",d.expire.over))do
if type(a)=="string"then m[#m+1]=a end
end
table.sort(m)
for b,a in ipairs(m)do
local b=j.over[a]
local c=type(b)=="number"and h.Share.familyByName(a,"SHAMAN")
if c then
n[#n+1]={spell=c,name=a,seconds=math.min(math.max(b,0),30)}
elseif type(b)=="number"then
e(k,l,a.."'s own Expiring time: no spell by that name here.")
end
end
if#m>0 then g.expiring.totems=n end
local h=a(f,"ended",d.ended)
g.ranOut={pop=a(h,"pop",d.ended.pop)}
local h=a(h,"sound",d.ended.sound)
if h~="none"then g.endSound=b.sound(h,k,l)end
local b=a(f,"killed",d.killed)
g.killed={flash=a(b,"flash",d.killed.flash),pop=a(b,"pop",d.killed.pop),
glow=a(b,"glow",d.killed.glow),cross=a(b,"mark",d.killed.mark)}
g.timeLeft=t(q)
g.timeLeft.barPlace=a(f,"barPlace",d.barPlace)=="out"and"beside"or"in"
local b=o(f,"border")
if b and a(b,"follow",true)==false then
g.styles={border={colour=i(a(b,"color",c.border.color)),thickness=a(b,"size",c.border.size)}}
end
if a(f,"show",d.show)~="always"then e(k,l,"Show: the bar always shows while it's on.")end
if a(f,"fadeAfter",d.fadeAfter)>0 then e(k,l,"Stay after combat isn't in InterHUD.")end
if a(f,"skin",d.skin)~="default"then e(k,l,"Totem themes aren't in InterHUD.")end
return g
end



local function n(a,b)
local a=o(a,"swingBar")
if a and j(a,"show",c.swingBar.show,{"never","always","combat"})~="never"then
e(b,"Swing timer",r.SWING_GONE)
end
end



local d={raid="raid",ready="ready",alarm="alarm",ping="ping"}
local g={emote="Boss emote",queue="Queue pop",invite="Group invite",quest="Quest complete",
toast="Friend online"}
function b.sound(a,b,c)
if type(a)~="string"or a=="none"or a==""then return nil end
if d[a]then return d[a]end
if g[a]then e(b,c,"The sound "..g[a].." isn't in InterHUD.")end
return nil
end




local function d(b,e,d)
local b=b
local c
for a in tostring(e):gmatch("[^%.]+")do
if c then b=type(b)=="table"and b[c]or nil end
c=a
end
if type(b)~="table"then return d end
local e=b[c]
if d==nil then return e end
return a(b,c,d)
end
b.sfGet=d


local g={
pct=function(a)return type(a)=="number"and k(a)or nil end,
colour=function(a)return f(a)and i(a)or nil end,
sound=function(c,a)return b.sound(c,a.notes,a.unit)end,
["not"]=function(a)return type(a)=="boolean"and not a or nil end,

secs=function(a)return type(a)=="number"and a>0 and math.min(math.max(math.floor(a+0.5),1),30)or nil end,
nonzero=function(a)return type(a)=="number"and a>0 end,
num=function(a)return type(a)=="number"and a==a and a or nil end,
minsToSecs=function(a)return type(a)=="number"and a>0 and math.min(a*60,600)or nil end,
}
b.CONVERT=g


local function i(a,c,d)
if d==nil then return false end
for a,b in ipairs(a.sources or{})do
if b.id==c.src then
b.events=type(b.events)=="table"and b.events or{}
local a=b.events[c.moment]
if type(a)~="table"then
a={}
b.events[c.moment]=a
end
a.effects=type(a.effects)=="table"and a.effects or{}
for b,a in ipairs(a.effects)do
if a.id==c.id then
a.sound=d
return true
end
end
a.effects[#a.effects+1]={id=c.id,kind="sound",sound=d}
return true
end
end
return false
end



function b.rowsFor(a)
local c=b.TABLE and b.TABLE[a]
if not c then return nil end
local f={["$aura"]=c.aura,["$icon"]=c.icon or"icon",["$upBar"]=c.upBar,
["$spell"]=c.spell or"spell"}
local d,e={},{}
local function a(a)
for a,b in ipairs(a or{})do
local a={}
for b,c in pairs(b)do a[b]=c end

if c.d and a.sf and c.d[a.sf]~=nil then a.d=c.d[a.sf]end
if type(a.part)=="string"and a.part:sub(1,1)=="$"then a.part=f[a.part]end
if type(a.sound)=="table"and type(a.sound.src)=="string"and a.sound.src:sub(1,1)=="$"then
a.sound={src=f[a.sound.src],moment=a.sound.moment,id=a.sound.id}
end

if(a.part~=nil or a.sound==nil or a.sound.src~=nil)and(a.part~=nil or a.sound~=nil or a.set~=nil or a.drop~=nil)then

if a.set and a.sf and e[a.sf]then
d[e[a.sf]]=a
else
d[#d+1]=a
if a.set and a.sf then e[a.sf]=#d end
end
end
end
end
a(c.kind and b.KIND[c.kind])
a(c.rows)
return d,c
end


local function y(f,h,c)
local a,b=b.rowsFor(h)
if not a then return end
c.spec=b
for b,a in ipairs(a)do
if a.drop then
local b=d(c.o,a.sf,nil)
if b~=nil and b~=a.d then e(c.notes,c.unit,a.drop)end
elseif a.set then
if a.set(f,d(c.o,a.sf,a.d),c)==false then
e(c.notes,c.unit,a.sf.." didn't carry.")
end
else
local b=true
if a.when then b=d(c.o,a.when[1],a.when[3])==a.when[2]end
if b then
local b=d(c.o,a.sf,a.d)
if b~=nil and a.as then b=g[a.as](b,c)end


if a.d==nil and not a.as and type(b)~="number"and type(b)~="boolean"and type(b)~="string"then b=nil end
if a.d~=nil and not a.as and type(b)~=type(a.d)then b=nil end
if b~=nil then
local d
if a.sound then
d=i(f,a.sound,b)
else
d=w.quickApply(f,{part=a.part,look=a.look,field=a.field,value=b})
end
local b=a.opt==true or(type(a.opt)=="table"and a.opt[h]==true)
if not d and not b then e(c.notes,c.unit,a.sf.." didn't carry.")end
end
end
end
end
end
b.applyRows=y



local I={horizontal="row",vertical="column"}

function b.map(i,d)
local z=h.Blueprints
local f={}
local q={notes=f,left=0}
local A=a(i,"iconSize",c.profile.iconSize)
local J=a(i,"elementOpts",{})
local t,r,B,u={},{},{},{}

local C={}
for g,d in ipairs(a(i,"groups",{}))do
if type(d)=="table"then
local g=c.group

local n=l.cut(tostring(a(d,"name","Group")),61)
local l={name=n}
local v=v(a(d,"scale",g.scale),0.25,4)
l.scale=v
l.position={point=j(d,"point",g.point,x),x=p(a(d,"x",g.x)*v),
y=p(a(d,"y",g.y)*v)}
l.opacity=k(a(d,"alpha",g.alpha))
local k=a(d,"spacing",g.spacing)
if k<0 then
e(f,n,"A spacing under 0 becomes 0.")
k=0
end
l.spacing=k
l.arrangement=I[a(d,"orientation",g.orientation)]or"row"
local k=j(d,"show",g.show,{"always","combat","target"})
if k~="always"then l["while"]={"game.inCombat"}end
if k=="target"then e(f,n,"\"In combat or with an enemy target\" becomes In combat.")end
if a(d,"fadeAfter",g.fadeAfter)>0 then e(f,n,"Stay after combat isn't in InterHUD.")end
local k=o(d,"groupFrameStyle")
if k and a(k,"look","none")~="none"then e(f,n,"The group's art frame isn't in InterHUD.")end
local o=a(d,"sizeFollow",g.sizeFollow)and A or a(d,"size",g.size)
local k={}
for g,d in ipairs(a(d,"members",{}))do
if type(d)=="string"and not B[d]then
B[d]=true
local l=m[d]
if l and z.premade(l)then
local g=z.makePremade(l)
local d=a(J,d,{})
local b=b.TABLE and b.TABLE[l]
local b=b and b.d and b.d.on
if b==nil then b=c.element.on end

g.enabled=g.enabled~=false and a(d,"on",b)
if j(d,"show",c.element.show,{"always","combat"})=="combat"then
g["while"]={"game.inCombat"}
end
g.baseSize=o

local a=g.name or l
local b=h.try("ShamanForever import rows",y,g,l,
{o=d,profile=i,notes=f,unit=a})
if not b then e(f,a,"Its settings didn't carry; the pre-made's stand.")end

w.stateLooksFirst(g)
t[#t+1]=g
u[g.id]=true
k[#k+1]=g.id
elseif not C[d]then
C[d]=true
q.left=q.left+1
e(f,s[d]and nil or d,s[d]or"No pre-made for it in this InterHUD.")
end
end
end
if a(d,"growth",g.growth)=="backward"then
local a={}
for b=#k,1,-1 do a[#a+1]=k[b]end
k=a
end
l.members=k

if#k>0 then
r[#r+1]=l
else
e(f,n,"None of its elements come across; left out.")
end
end
end

for b,a in ipairs(r)do
a.id=h.Share.freeId(E(a.name),u)
u[a.id]=true
end
local a={elements=t,groups=r,styles=F(i,f),buttonCues=G(i),
settings={fadeTime=math.min(math.max(a(i,"idleFade",c.profile.idleFade),0),1)}}
n(i,f)
local c={totemBar=H(i,f,A)}
if next(c)then a.specials=c end
local a={kind="profile",name=b.NAME,class="SHAMAN",interhud=D.VERSION,profile=a}
q.version=d
return a,q
end



function b.isExport(a)
return type(a)=="string"and a:match("^%s*!SF")~=nil
end

function b.read(c)
c=tostring(c or""):gsub("%s","")
if c:sub(1,#b.PREFIX)~=b.PREFIX then return nil,b.NEWER end
local a=C_EncodingUtil
if not a or not a.DeserializeCBOR or not a.DecompressString or not a.DecodeBase64 then
return nil,b.UNREADABLE
end
local a,c=pcall(function()
local d=Enum.CompressionMethod and Enum.CompressionMethod.Deflate
return a.DeserializeCBOR(a.DecompressString(a.DecodeBase64(c:sub(#b.PREFIX+1)),d))
end)
if not a then return nil,b.CUT end
if type(c)~="table"or type(c.profile)~="table"then return nil,b.UNREADABLE end
local a=c.v
if type(a)~="number"or a~=a or a<b.VERSION_MIN then return nil,b.OLDER end
if a>b.VERSION_MAX then return nil,b.NEWER end
local c,d=b.map(c.profile,a)

local a=c.profile
if#a.elements==0 and#a.groups==0 and not a.specials then return nil,b.EMPTY end
return c,d
end
