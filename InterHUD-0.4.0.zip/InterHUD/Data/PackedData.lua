












local b,a=...

a.PackedData={
format=1,
build=70888,
spells=[==[
id|name|icon|where|length|dispel|from|class|flags
11|Swiftness|136106|p|30|magic|o||
12|Hot Foot (TEST)|136235||10||o||ip
13|Swim Speed (TEST)|136235|p|30||o||ip
16|Fear (NYI)|136183|t|15|magic|o||i
22|Super Food (TEST)|136235|p|10||o||ip
25|Stun|135860|t|5||o||
47|Sprint (TEST)|136235|p|10||i||ip
56|Stun|133477|t|3||i||
65|Haste|136047|p|30|magic|i||
66|Lesser Invisibility|135994|p|120||i||
67|Vindication|135985|t|10|magic|o||
77|Turtle's Shell|136235|p|-1||o||p
87|Windwalk|135863|p|300||o||
89|Cripple|136135|t|20|magic|i||
91|Savage Assault|132316|t|30|magic|o||
96|Dismember|132090|t|10||o||
101|Trip|132309|t|3||o||
111|Time Step|136235|p|10||o||p
112|Reflect Magic (TEST)|136235|p|10||o||ip
113|Chains of Ice|135834|t|15|magic|i||
128|Spellstone|134131|p|60|magic|o||
134|Fire Shield|135817|a|60|magic|o||
184|Fire Shield II|135817|a|60|magic|o||
228|Polymorph: Chicken|135996|t|10|magic|o||
246|Slow|136091|t|10|magic|i||
260|Charm (TEST)|136235|a|-1||o||ip
302|Savage Assault II|132316|t|30|magic|o||
409|Shadowskin|136235|p|60|magic|o||p
410|Shadowskin II|136235|p|60|magic|o||p
411|Shadowskin III|136235|p|60|magic|o||p
424|Earthquake|136025|p|8|magic|o||
430|Drink|132794|p|18||i||
431|Drink|132794|p|21||i||
432|Drink|132794|p|24||i||
433|Food|134062|p|18||i||
434|Food|134062|p|21||i||
435|Food|134062|p|24||i||
450|Fast Cast (NYI)|136235|p|5||o||ip
454|Gallop (TEST)|0|p|10||o||ip
457|Feeblemind|136175|t|30|magic|o||
458|Brown Horse|132261|p|-1||i||
459|Gray Wolf|132266|p|-1||i||
461|Righteous Flame On|135926|p|-1||o||
468|White Stallion|132261|p|-1||i||
470|Black Stallion|132251|p|-1||i||
471|Palomino Stallion|132261|p|-1||i||
472|Pinto Horse|132261|p|-1||i||
474|Fumble|136159|t|30|magic|o||
507|Fumble II|136159|t|30|magic|o||
509|Feeblemind II|136175|t|30|magic|o||
512|Chains of Ice|135834|t|20|magic|i||
530|Charm (Possess)|135994|a|-1||i||
550|Nullify Poison|136067|a|30|magic|i||
553|Bloodlust II|136012|a|30|magic|o||
568|Arcane Burst|136116|t|8||o||
578|Black Wolf|132224|p|-1||i||
579|Red Wolf|132224|p|-1||i||
580|Large Timber Wolf|132224|p|-1||i||
581|Winter Wolf|132266|p|-1||i||
595|Prayer of Protection|135923|p|30|magic|o||
606|Mind Rot|136174|t|30|magic|i||
673|Elixir of Minor Defense|134843|p|3600||i||
692|Terror (TEST)|136122|t|10||o||i
700|Sleep|136090|t|20|magic|i||
720|Entangle|136113|t|8||o||
731|Entangle|136113|t|8||o||
739|Debuff Fire Resist (TEST)|136235|p|||o||ip
744|Poison|136016|t|30|poison|o||
745|Web|132149|t|10||o||
746|First Aid|135915|a|6||i||
775|Tree Form|136064|p|8||o||
776|Abolish Magic|136006|a|5|magic|i||
785|True Fulfillment|136129|t|20||o||
800|Twin Teleport|135736|p|0.25||o||
802|Mutate Bug|132195|t|240||o||
804|Explode Bug|135805|t|4||o||
806|Fervor|136224|p|60|magic|i||
812|Periodic Mana Burn|136170|a|-1||o||
822|Magic Resistance|136120|p|60||o||
829|Thickskull|0|p|30||o||p
830|Fearless|0|p|30||o||p
833|Green Tea|132794|p|10||i||
834|Lesser Armor|134866|p|3600||i||
835|Tidal Charm|135861|t|3|magic|i||
839|Haste II|136047|p|30|magic|o||
849|Elemental Armor|135841|e|60|magic|o||
851|Polymorph: Sheep|136071|t|10|magic|i||
855|Feeblemind III|136175|t|30|magic|o||
863|Blur III|136047|p|60|magic|o||
867|Fumble III|136159|t|30|magic|o||
877|Elemental Fury|135806|e|30|magic|o||
885|Invisibility|136047|p|120||i||
974|Earth Shield|136089|a|600|magic|o||
994|Prayer of Protection II|135923|p|30|magic|o||
1009|Savage Pummel|132189|t|5||o||
1010|Curse of Idiocy|136174|t|120|curse|o||
1056|Slow Poison II|136093|t|30|poison|o||
1090|Sleep|136090|t|30|magic|i||
1116|Chaos Shield|135817|a|-1|magic|o||
1121|Entangle|136113|t|8||o||
1127|Food|134062|p|27||i||
1129|Food|134062|p|30||i||
1131|Food|134062|p|30||i||
1133|Drink|132794|p|27||i||
1135|Drink|132794|p|30||i||
1137|Drink|132794|p|30||i||
1138|Crystal Protection|136051|p|60|magic|i||
1139|Cold Eye|133884|t|15|magic|i||
1159|First Aid|135915|a|6||i||
1179|Beast Claws|136078|p|10||o||
1234|Tony's God Mode|135724||-1||o||
1302|Damage Immunity Test|136235|p|45||o||ip
1386|Echoes of Lordaeron|132486|a|-1||o||
1450|Arcane Spirit II|135932|a|1800|magic|o||
1451|Arcane Spirit III|135932|a|1800|magic|o||
1452|Arcane Spirit IV|135932|a|1800|magic|o||
1453|Arcane Spirit V|135932|a|1800|magic|o||
1528|Free Master|136064||1||o||
1557|Full Speed|132347|p|-1||o||
1604|Dazed|135860|t|4||o||
1630|Windwalk|135863|p|10||o||
1663|Savage Assault III|132316|t|30|magic|o||
1664|Savage Assault IV|132316|t|30|magic|o||
1665|Savage Assault V|132316|t|30|magic|o||
1731|Defensive Strike|132316|p|15||o||
1732|Defensive Strike II|132316|p|15||o||
1834|Gathering Speed|132347|p|180||o||
1849|Beast Claws II|136078|p|30||o||
1852|Silenced|136071|a|-1||o||
1906|Debilitating Charge|132122|t|8||o||
1908|Uber Heal Over Time|135923|a|-1||o||
2140|Stasis Effect|136069|t|15|magic|o||
2147|Mending|136085|a|-1||o||
2148|Periodic Shadow Storm|136163|a|-1||o||
2336|Draught of Tongues|134743|p|3600||i||
2351|Sanctuary|135926|p|30|magic|o||
2353|Sanctuary II|135926|p|30|magic|o||
2354|Sanctuary III|135926|p|30|magic|o||
2361|Tracking (TEST)|136235|p|300||o||ip
2367|Lesser Strength|134836|p|3600||i||
2374|Lesser Agility|134871|p|3600||i||
2376|Lesser Intellect|134721|p|3600||o||
2378|Health|134822|p|3600||i||
2379|Speed|132219|p|15|magic|i||
2380|Resistance|134719|p|180|magic|i||
2381|Resistance (OLD)|136101|p|600|magic|i||i
2383|Find Herbs|133939|p|-1||o||
2425|Spotted|136173||5||o||
2479|Honorless Target|135994|p|30||o||
2537|Crusader Strike|135924|t|30|magic|o||
2564|Dodge!|136235|p|5||o||p
2580|Find Minerals|136025|p|-1||o||
2584|Waiting to Resurrect|135955|p|-1||o||
2601|Fire Shield III|135817|a|30|magic|o||
2602|Fire Shield IV|135817|a|15|magic|o||
2639|Food|134062|p|21||i||
2647|Freeze III PROC|135860|t|5|magic|o||
2691|Mana Burn|136170|t|0.001||o||
2766|KJORDAN (TEST)|136235|p|30||o||ip
2818|Deadly Poison|132290|t|12|poison|e||
2819|Deadly Poison II|132290|t|12|poison|e||
2834|Periodic Thunderclap|132326|a|-1||o||
2871|Nullify Disease|136083|a|30|magic|i||
2880|Stun|135860|t|10||o||
2882|Bear Form (PT) (NYI)|132276|p|-1||o||i
2969|Aura Leech (PT)|136235|t|15||o||p
3017|Immune Effect (TEST)|136235|p|||o||ip
3019|Enrage|136224|p|15|magic|o||
3023|Debuff Nature (TEST)|136235|p|30||o||ip
3105|Curse of Stalvan|136203|t|600|curse|o||
3109|Presence of Death|136195|t|10|magic|o||
3120|Sol L|135859|t|5||o||
3130|Ice Claw|135853|t|6|magic|o||
3132|Chilling Breath|135864|t|12|magic|o||
3133|Beast Claws III|136078|p|30||o||
3136|Frenzied Command|132277|p|10|magic|o||
3143|Glacial Roar|135848|t|3|magic|o||
3145|Icy Grasp|135858|t|5|magic|o||
3146|Daunting Growl|132278|t|30||o||
3147|Rend Flesh|132152|t|12||o||
3148|Head Crack|132325|t|20||o||
3149|Furious Howl|136101|p|15||o||
3150|Rabies|135914|t|600|disease|o||
3151|Crazed Hunger|132278|p|6||o||
3157|Lesser Agility|134873|p|3600||o||
3158|Lesser Agility|134873|p|3600||o||
3159|Agility|134873|p|3600||o||
3160|Agility|134872|p|3600||i||
3161|Lesser Strength|134838|p|3600||o||
3162|Lesser Strength|134838|p|3600||o||
3163|Strength|134838|p|3600||o||
3164|Strength|134837|p|3600||i||
3165|Lesser Intellect|134721|p|3600||o||
3166|Lesser Intellect|134717|p|1800||i||
3167|Intellect|134721|p|3600||o||
3168|Intellect|134721|p|3600||o||
3169|Invulnerability|135896|p|6|magic|i||
3219|Minor Troll's Blood Elixir|134858|p|3600||i||
3220|Armor|134844|p|3600||i||
3221|Regeneration|134859|p|3600||o||
3222|Lesser Troll's Blood Elixir|134859|p|3600||i||
3223|Troll's Blood Elixir|134860|p|3600||i||
3229|Quick Bloodlust|136012|a|5|magic|o||
3232|Gouge Stun Test|136235|p|60||o||ip
3237|Curse of Thule|136203|t|240|curse|o||
3238|Nimble Reflexes|132223|p|8||o||
3242|Ravage|132152|t|2||o||
3245|Chicken|136235|p|-1||o||p
3246|Chicken Other|135996|a|-1|magic|o||
3247|Agonizing Pain|132152|t|15|magic|o||
3248|Improved Blocking|135806|p|6||o||
3252|Shred|132152|t|12||o||
3256|Plague Cloud|136127|t|240|disease|o||
3258|Savage Rage|136224|p|4|magic|o||
3260|Violent Shield Effect|136173|p|8||o||
3261|Ignite|135805|t|20|magic|o||
3263|Touch of Ravenclaw|136188|t|5|magic|o||
3264|Blood Howl|136168|t|15|magic|o||
3267|First Aid|135915|a|7||i||
3268|First Aid|135915|a|7||i||
3269|Blessing of Thule|136157|p|8|magic|o||
3271|Fatigued|136157|p|2||o||
3287|Ghoul Form|136224|p|-1||o||
3288|Moss Hide|136065|p|10||o||
3329|Creature - Frog Form|136232|p|60||o||
3332|Slow Poison|136093|t|30|poison|o||
3335|Dark Sludge|136134|t|300|disease|o||
3356|Flame Lash|135807|t|45|magic|o||
3358|Leech Poison|136067|t|40|poison|o||
3363|Summon Riding Gryphon|132091|p|-1||i||
3369|Potion Strength II|136101|p|120|magic|o||
3385|Boar Charge|136231|p|4||o||
3387|Rage of Thule|136224|t|120|curse|o||
3388|Deadly Leech Poison|136067|t|45|poison|o||
3389|Ward of the Eye|136232|p|6|magic|o||
3396|Corrosive Poison|136016|t|30|poison|o||
3409|Crippling Poison|132274|t|12|poison|e||
3416|Fiend Fury|136224|p|10|magic|o||
3419|Improved Blocking|135806|p|6||o||
3424|Tainted Howl|136188|p|120||o||
3427|Infected Wound|136066|t|300|disease|o||
3429|Plague Mind|136127|t|600|disease|o||
3436|Wandering Plague|136127|t|300|disease|o||
3439|Wandering Plague|136127|p|300|disease|o||
3442|Enslave|136129|t|15|magic|o||
3443|Enchanted Quickness|136047|p|15|magic|o||
3446|Ravage|132152|t|6||o||
3485|Wail of Nightlash|136183|t|15|magic|o||
3490|Frenzied Rage|136224|p|5||o||
3510|Sloth Effect|136188|t|3||o||
3514|Sludge|136188|t|3||o||
3542|Naraxis Web|136100|t|30|magic|o||
3547|Enraging Memories|136224|p|8||o||
3551|Skull Crack|135860|t|2||o||
3574|Skin of Rock|132154|p|8|magic|o||
3583|Deadly Poison|136067|t|120|poison|o||
3584|Volatile Infection|135914|t|120|disease|o||
3586|Volatile Infection|135914|t|180|disease|o||
3589|Deafening Screech|136122|t|8||o||
3593|Health II|134823|p|3600||i||
3602|Torch Burst|135817|t|30|magic|o||
3603|Distracting Pain|132278|t|15||o||
3604|Tendon Rip|132109|t|8||o||
3609|Paralyzing Poison|132274|t|8|poison|o||
3631|Battle Fury|132277|p|240|magic|o||
3635|Crystal Gaze|132154|t|6|magic|o||
3636|Crystalline Slumber|136090|t|15|magic|o||
3639|Improved Blocking|135806|p|6||o||
3648|Phase Out|136047|p|45||o||
3650|Sling Mud|136090|t|15||o||
3651|Shield of Reflection|136222|p|10|magic|o||
3671|Cracking Stone|136025|p|180||o||
3672|Crumbling Stone|136025|p|180||o||
3673|Reduced to Rubble|136025|p|180||o||
3680|Lesser Invisibility|134798|p|15||i||
3719|Debuff Holy Resist (TEST)|136235|p|30||o||ip
3815|Poison Cloud|136077|t|45|poison|o||
3826|Ward of Laze effect|136157|t|3|magic|o||
4057|Fire Resistance|135806|p|60|magic|i||
4058|Reverse Transformation|136235|a|3||o||p
4060|Discombobulate|136203|t|12|curse|i||
4064|Rough Copper Bomb|135826|t|1||i||
4065|Large Copper Bomb|135826|t|1||i||
4066|Small Bronze Bomb|135826|t|2||i||
4067|Big Bronze Bomb|135826|t|2||i||
4068|Iron Grenade|135826|t|3||i||
4069|Big Iron Bomb|135826|t|3||i||
4077|Frost Resistance|135843|p|60|magic|i||
4079|Cloaking|136047|p|10||i||
4092|Advanced Target Dummy Spawn Effect|136222|t|10||o||
4101|Enraging Bite|136224|t|6||o||
4102|Gore|136231|t|15||o||
4104|Flight of the Peregrine|136107|p|15||o||
4105|Rapid Gallop|132319|p|15||o||
4107|Tough Shell|132110|p|10||o||
4108|Tough Shell|132110|p|10||o||
4109|Tough Shell|132110|p|12||o||
4111|Tough Shell|132110|p|12||o||
4134|Bruise|136222|p|10||o||
4135|Bruise|136222|p|10||o||
4137|Bruise|136222|p|10||o||
4139|Bruise|136222|p|10||o||
4146|Enraged Howl|136101|p|15||o||
4147|Enraged Howl|136101|p|30||o||
4148|Growl of Fortitude|132091|p|300||o||
4149|Toughen Hide|132111|p|10||o||
4150|Eye Peck|132156|t|12||o||
4153|Guile of the Raptor|134295|p|30||o||
4154|Ferocity|132152|p|8||o||
4159|Tight Pinch|132152|t|5||o||
4166|Vulnerable|135860|t|3||o||
4167|Web|132149|t|8||o||
4168|Web II|132149|t|10||o||
4169|Web III|132149|t|12||o||
4238|Roar of Fortitude|132091|p|120||o||
4240|Vital Wound|132109|t|8||o||
4242|Pester|136128|p|15||o||
4243|Pester Effect|136128|t|3||o||
4244|Open Wound Effect|136168|t|8||o||
4246|Clenched Pinchers|132109|t|15||o||
4282|Stomp|132368|t|10||o||
4285|Tendon Slice|132109|t|8||o||
4286|Poisonous Spit|136016|t|15|poison|o||
4316|Rabid Maw|136182|t|30|disease|o||
4318|Guile of the Raptor|136063|p|1800|magic|i||
4320|Trelane's Freezing Touch|136230|t|12|magic|o||
4321|Stasis Test|136235|t|5||o||ip
4504|Jeff Dummy 1|135926|t|30||o||
4505|Jeff Dummy 2|135926|t|30||o||
4507|Target Dummy Spawn Effect|136222|t|5||o||
4514|Consuming Rage|136146|p|12||o||
4524|Demonic Immolation|135826|p|3||o||
4538|Extract Essence|135956|t|12||o||
4539|Strength of the Ages|136188|p|10||o||
4805|Distracting Spit|135989|t|15||o||
4932|Ward of Myzrael|136222|p|20||o||
4933|Prismatic Form: Fire|136160|p|-1||o||
4934|Prismatic Form: Earth|136160|p|-1||o||
4935|Prismatic Form: Water|136160|p|-1||o||
4936|Prismatic Form: Thunder|136160|p|-1||o||
4940|Spider Poison|136016|t|30|poison|o||
4941|Stoneshield|134847|p|90||i||
4948|Kinelory's Bear Form|132276|p|15||o||
4952|Helcular's Ward|136230||5||o||
4955|Fist of Stone|132154|p|12||o||
4962|Encasing Webs|136022|t|6||o||
4970|Draw from the Earth|136025|p|10||o||
4974|Wither Touch|136020|t|120|curse|o||
4979|Quick Flame Ward|135824|a|10|magic|o||
4980|Quick Frost Ward|135824|a|10|magic|o||
5003|Bunyanize|136235|a|90||o||p
5004|Food|134062|p|18||i||
5005|Food|134062|p|21||o||
5006|Food|134062|p|24||i||
5007|Food|134062|p|27||i||
5020|Stormstout|132800|p|300||i||
5021|Trogg Ale|132796|p|300||i||
5024|Flee|135996|p|10||i||
5101|Dazed|136175|p|30||o||
5105|Minor Scorpion Venom Effect|136016|t|60|poison|o||
5106|Crystal Flash|136222|t|15|magic|o||
5115|Battle Command|132277|p|6|magic|o||
5119|Beast Tracking|132328|p|180||o||
5120|Undead Tracker|132328|p|60||o||
5121|Giant Tracker|132328|p|60||o||
5122|Demon Tracker|132328|p|60||o||
5123|Dragon Tracker|132328|p|60||o||
5124|Elemental Tracker|132328|p|60||o||
5134|Flash Bomb|136142|t|10||i||
5137|Call of the Grave|136130|t|60|curse|o||
5142|Trogg Form|136224|p|-1|magic|o||
5159|Melt Ore|135826|t|20||o||
5164|Knockdown|132154|t|2||o||
5165|Knockdown /Stun (TEST)|132154|a|8||o||i
5169|Defias Disguise|132288|p|-1||i||
5202|MHTest01|132350|p|1800|magic|o||i
5208|Poisoned Harpoon|132273|t|60|poison|o||
5213|Molten Metal|135807|t|15||o||
5217|Tiger's Fury|132242|p|6||o||
5219|Draw of Thistlenettle|136163|t|8||o||
5220|Frenzied Capo the Mean|136129|p|15||o||
5250|Stromgarde Militia Call|136235|p|30||o||p
5254|Polymorph (TEST)|136071|t|30|magic|o||i
5256|Claw Cover|136104|p|20||o||
5257|Thunderbrew|132792|p|300||i||
5259|Disarm (TEST)|136235|t|15||o||ip
5260|Distract (TEST)|136235|t|15||o||ip
5262|Fanatic Blade|135817|p|10|magic|o||
5264|South Seas Pirate Disguise|132288|p|-1||i||
5265|Stonesplinter Trogg Disguise|132288|p|-1||i||
5266|Syndicate Disguise|132288|p|-1||i||
5267|Dalaran Wizard Disguise|132288|p|-1||i||
5268|Dark Iron Dwarf Disguise|132288|p|-1||i||
5271|Cursed Blade|136020|t|20|curse|o||
5276|Freeze|135852|t|15|magic|o||
5280|Razor Mane|136104|p|45||o||
5306|ImmuneSleep (JEFFTEST)|135844|a|120||o||
5337|Wither Strike|136052|t|8|magic|o||
5363|Thick Skin|132110|p|20||o||
5365|Thick Skin|132110|p|20||o||
5366|Thick Skin|132110|p|20||o||
5367|Thick Skin|132110|p|20||o||
5376|Hand Snap|136168|t|8||o||
5402|Gazban Transform|136235|p|300||o||p
5403|Crash of Waves|135848|t|10|magic|o||
5413|Noxious Catalyst|135914|t|120|disease|o||
5416|Venom Sting|132274|t|45|poison|o||
5422|Lacerate|136231|t|8||o||
5424|Claw Grasp|133708|t|4||o||
5426|Quick Sidestep|136047|p|6||o||
5480|Cleave Armor|132109|t|15||o||
5508|Cleave Armor|132109|t|15||o||
5514|Darken Vision|136159|t|12|magic|o||
5515|Savagery|132369|p|8|magic|o||
5543|Fade Out|136047|p|2||o||
5567|Miring Mud|136100|t|5|magic|o||
5579|Immune Root/Snare/Stun|135894|p|0.1||i||
5597|Serious Wound|136168|t|10||o||
5598|Serious Wound|136168|t|10||o||
5628|Gnarlpine Vengeance|136224|t|6|magic|o||
5648|Stunning Blast|135860|t|3||o||
5649|Stunning Blast|135860|t|5||o||
5665|Fury of the Bogling|136101|p|600|magic|i||
5668|Peasant Disguise|132288|p|-1||o||
5669|Peon Disguise|132288|p|-1||o||
5703|Stunning Strike|132326|t|4||o||
5708|Swoop|132338|t|2||o||
5726|Stunning Blow|135860|t|5||o||
5727|Stunning Blow|135860|t|8||o||
5759|Cat Form|132115|p|240||o||
5760|Mind-numbing Poison|136066|t|10|poison|e||
5781|Threatening Growl|132278|t|30||o||
5784|Summon Felsteed|136103|p|-1||o||
5810|Stone Skin|132154|p|6||o||
5862|Blessing of Aman|135881|a|1800|magic|o||
5884|Banshee Curse|136020|t|12|curse|o||
5909|Watered-down Beer|132791|p|600||i||
5915|Crazed|136215|p|60||o||
5916|Shadowstalker Stealth|132320|p|-1||o||
5917|Fumble|136159|t|10|magic|i||
5918|Shadowstalker Stab|132092|t|5||o||
5934|Flourish|132147|p|6||o||
5951|Knockdown|132154|t|2||o||
5990|Nimble Reflexes|132223|p|8||o||
6016|Pierce Armor|136231|t|20||o||
6114|Raptor Punch|132794|p|300||i||
6115|Far Sight (PT)|136235|p|60||o||p
6145|Eagle Eye (PT)|132150|p|-1||o||
6146|Slow|136091|t|15|magic|i||
6238|Speak with Animals|132163|p|20||o||
6239|Bloodtooth's Totum|132277|p|-1||o||
6240|Dispell Bloodtooth|136116|t|0.001||o||
6253|Backhand|132939|t|2||o||
6257|Torch Toss|135808|t|30||o||
6264|Nimble Reflexes|132223|p|8||o||
6266|Kodo Stomp|132368|t|3||o||
6268|Rushing Charge|132368|p|3||o||
6271|Naralex's Awakening|136107|p|-1||o||
6272|Eye of Yesmur (PT)|136235|p|60||o||p
6277|Bind Sight (PT)|136235|p|120||o||p
6278|Creeping Mold|136134|t|60|disease|o||
6298|Form of the Moonstalker|132156|p|300||i||
6304|Rhahk'Zor Slam|132939|t|3||o||
6306|Acid Splash|132793|t|30||o||
6405|Furbolg Form|134297|p|180||i||
6408|Faded|136047|p|-1||o||
6409|Cheap Shot|132092|t|5||o||
6410|Food|134062|p|21||i||
6411|Scorpid Poison|136016|p|21|poison|i||
6422|Ashcrombe's Teleport|135826|p|3||o||
6432|Smite Stomp|132368|t|10||o||
6434|Slice and Dice|132306|p|10||o||
6435|Smite Slam|132939|t|3||o||
6466|Axe Toss|132395|t|3||o||
6468|Skeletal Miner Berserk|136187|p|6||o||
6507|Battle Roar|132277|p|60||o||
6512|Detect Lesser Invisibility|136153|p|600||i||
6513|Resist Poison|136067|p|60||o||
6514|Sharp Weapon +2|132223|p|-1||o||
6515|Sharp Weapon +3|132223|p|-1||o||
6516|Sharp Weapon +5|132223|p|-1||o||
6524|Ground Tremor|136025|t|2||o||
6530|Sling Dirt|136090|t|10||o||
6531|Overseer's Poison|136016|t|60|poison|o||
6533|Net|132149|t|10||o||
6537|Call of the Forest|136107|p|-1||o||
6538|Dig Trap|136025|p|60||o||
6558|Debuff|132094|t|-1|poison|o||
6576|Intimidating Growl|132278|t|5||o||
6580|Pierce Ankle|132109|t|3||o||
6581|Pierce Ankle|132109|t|10||o||
6584|Jin'Zil's Curse|136066|p|10||o||
6600|Salt Flats Racer Speed|134063|p|5||o||
6601|Salt Flats Racer Slow|134063|p|5||o||
6602|Salt Flats Racer Normal|134063|p|5||o||
6605|Terrifying Screech|136218|t|4|magic|o||
6607|Lash|132109|t|2||o||
6608|Dropped Weapon|132343|p|5||o||
6615|Free Action|134715|p|30|magic|i||
6634|Phasing Stealth|132320|p|8||o||
6648|Chestnut Mare|132261|p|-1||i||
6653|Dire Wolf|132266|p|-1||i||
6654|Brown Wolf|132224|p|-1||i||
6664|Survival Instinct|132179|t|2||o||
6669|Survival Instinct|132179|p|2||o||
6672|Toxic Contagion|136235|t|60|disease|o||p
6685|Piercing Shot|132312|t|15||o||
6711|Pathfinding|132181|p|360||o||
6713|Disarm|132343|t|6||o||
6714|Test of Faith|136022|p|4||o||
6716|Test of Faith|136022|a|3||o||
6724|Light of Elune|135954|p|10||i||
6726|Silence|135975|t|6|magic|o||
6727|Poison Mushroom|136016|p|30|poison|i||
6728|Enveloping Winds|136018|t|10|magic|o||
6730|Head Butt|132939|t|2||o||
6742|Bloodlust|136012|a|30|magic|o||
6749|Wide Swipe|132408|t|5||o||
6751|Weak Poison|136016|t|12|poison|o||
6754|Slap!|132940|a|3||o||
6755|Tell Joke|136168|t|0.001||o||
6758|Party Fever|136142|p|120||i||
6767|Mark of Shame|136122|a|600||o||
6772|Trip|132309|t|3||o||
6777|Gray Ram|132248|p|-1||i||
6814|Sludge Toxin|136077|t|45|poison|o||
6816|Corrupted Strength|135914|t|4|disease|o||
6817|Corrupted Agility|135914|t|4|disease|o||
6818|Corrupted Intellect|135914|t|4|disease|o||
6819|Corrupted Stamina|135914|t|4|disease|o||
6864|Strength of Stone|132154|p|8|magic|o||
6866|Moss Covered Hands|136052|t|180|magic|o||
6869|Fall down|132219|p|2||o||
6870|Moss Covered Feet|136052|t|180|magic|o||
6873|Foul Chill|135864|t|120|magic|o||
6894|Death Bed|136223|t|10|magic|o||
6896|Black Ram|132248|p|-1||i||
6897|Blue Ram|132248|p|-1||i||
6898|White Ram|132248|p|-1||i||
6899|Brown Ram|132248|p|-1||i||
6902|Sneezing Fit|134374|p|120||i||
6903|Krazek's Drug|134374|p|10||o||
6907|Diseased Slime|136134|t|120|disease|o||
6909|Curse of Thorns|136121|t|180|curse|o||
6917|Venom Spit|136016|t|10|poison|o||
6920|Hide|132320|p|-1||o||
6921|Shadowhorn Charge|132368|p|6||o||
6922|Curse of the Shadowhorn|136020|t|300|curse|o||
6927|Shadowstalker Slash|132092|t|5||o||
6942|Overwhelming Stench|136119|t|6|magic|o||
6945|Chest Pains|136119|p|5||o||
6946|Curse of the Bleakheart|136130|t|180|curse|o||
6950|Faerie Fire|136033|t|60|magic|o||
6951|Decayed Strength|135914|t|300|disease|o||
6955|Gnome Car Camera|136235|p|300||i||p
6957|Frostmane Strength|136109|a|180|magic|o||
6960|Lightning Barrier|136051|a|180|magic|o||
6964|Echoes of Lordaeron|132486|a|-1||o||
6965|Polymorphic Ray|136048|t|4||o||
6966|Echoes of Lordaeron|132485|a|-1||o||
6969|Free Master|136064||1||o||
6974|Gnome Camera Connection|136235|p|1||i||p
6982|Gust of Wind|136022|t|4||o||
6984|Frost Shot|135989|t|10|magic|o||
6985|Frost Shot|135989|t|10|magic|o||
6998|Echoes of Lordaeron|132485|a|-1||o||
7020|Stoneform|132275|p|15|magic|o||
7022|Goblin Car Camera|136235|p|300||i||p
7023|Goblin Camera Connection|136235|p|1||i||p
7033|Charm+ (TEST)|136235|p|-1||o||ip
7035|Goblin Racer Cheer|132484||5||o||
7036|Gnome Racer Cheer|132484||5||o||
7038|Forsaken Skill: Swords|135274|p|60|curse|o||
7039|Forsaken Skill: Axes|132395|p|60|curse|o||
7040|Forsaken Skill: Daggers|135429|p|60|curse|o||
7041|Forsaken Skill: Maces|133479|p|60|curse|o||
7042|Forsaken Skill: Staves|135145|p|60|curse|o||
7043|Forsaken Skill: Bows|135490|p|60|curse|o||
7044|Forsaken Skill: Guns|135610|p|60|curse|o||
7045|Forsaken Skill: 2H Axes|132408|p|60|curse|o||
7046|Forsaken Skill: 2H Maces|133040|p|60|curse|o||
7047|Forsaken Skill: 2H Swords|135327|p|60|curse|o||
7048|Forsaken Skill: Defense|134950|p|60|curse|o||
7049|Forsaken Skill: Fire|135805|p|60|curse|o||
7050|Forsaken Skill: Frost|135856|p|60|curse|o||
7051|Forsaken Skill: Holy|135920|p|60|curse|o||
7053|Forsaken Skill: Shadow|136123|p|60|curse|o||
7054|Forsaken Skills|136121|t|300|curse|o||
7057|Haunting Spirits|136123|t|300|curse|o||
7068|Veil of Shadow|136160|t|15|curse|o||
7069|Enraging Aura|136146|p|-1||o||
7072|Wild Rage|136162|p|60||o||
7074|Screams of the Past|136164|t|5|magic|o||
7081|Encage|136222|a|300||o||
7082|Barrel Explode|135826|t|3||o||
7083|Quillboar Channeling|136121|p|-1||o||
7084|Damage Car|135805|a|-1||o||
7090|Bear Form|132276|p|300||o||
7093|Intimidation|136122|t|4|magic|o||
7098|Curse of Mending|136121|t|180|curse|o||
7102|Contagion of Rot|136127|t|240|disease|o||
7103|Contagion of Rot|136127|p|240|disease|o||
7104|Sneak|132320|p|10||o||
7120|Proudmoore's Defense|135880|a|1800||o||
7121|Anti-Magic Shield|136120|p|10||o||
7124|Arugal's Gift|136130|t|300|curse|o||
7125|Toxic Saliva|136016|t|120|poison|o||
7127|Wavering Will|136119|t|60|magic|o||
7136|Shadow Port|136121|p|10||o||
7137|Shadow Charge|132368|p|6||o||
7139|Fel Stomp|132368|t|3||o||
7140|Expose Weakness|132109|t|5|magic|o||
7144|Stone Slumber|136031|p|15||o||
7164|Defensive Stance|132341|p|180||o||
7165|Battle Stance|132349|p|-1||o||
7178|Water Breathing|135859|p|1800||i||
7184|Lost Control|132281|p|300||o||
7211|Devilsaur Barb|135125|t|10||i||
7230|Fire Protection|135806|p|120|magic|o||
7231|Fire Protection|135806|p|120|magic|o||
7232|Fire Protection|135806|p|120|magic|o||
7233|Fire Protection|135806|p|120|magic|i||
7234|Fire Protection|135806|p|120|magic|o||
7235|Shadow Protection|136185|p|120|magic|o||
7236|Frost Protection|135843|p|120|magic|o||
7237|Frost Protection|135843|p|120|magic|o||
7238|Frost Protection|135843|p|120|magic|o||
7239|Frost Protection|135843|p|120|magic|i||
7240|Frost Protection|135843|p|120|magic|o||
7241|Shadow Protection|136185|p|120|magic|o||
7242|Shadow Protection|136185|p|120|magic|i||
7243|Shadow Protection|136185|p|120|magic|o||
7244|Shadow Protection|136185|p|120|magic|o||
7245|Holy Protection|135880|p|120|magic|i||
7246|Holy Protection|135880|p|120|magic|o||
7247|Holy Protection|135880|p|120|magic|o||
7248|Holy Protection|135880|p|120|magic|o||
7249|Holy Protection|135880|p|120|magic|o||
7250|Nature Protection|136094|p|120|magic|o||
7251|Nature Protection|136094|p|120|magic|o||
7252|Nature Protection|136094|p|120|magic|o||
7253|Nature Protection|136094|p|120|magic|o||
7254|Nature Protection|136094|p|120|magic|i||
7272|Dust Cloud|132156|t|12|magic|o||
7279|Black Sludge|136127|t|120|disease|o||
7288|Immolate Cumulative (TEST)|135817|t|20|magic|o||i
7289|Shrink|136121|t|120|curse|o||
7290|Soul Siphon|136169|t|10|magic|o||
7291|Food (TEST)|134062|p|30||i||i
7293|Zombie Form|136224|p|-1|magic|o||
7295|Soul Drain|136169|t|10|magic|o||
7331|Healing Aura (TEST)|135917|p|-1||o||i
7344|Recombobulate|135996|p|-1||o||
7353|Cozy Fire|135805|p|60||o||
7357|Poisonous Stab|136077|t|15|poison|o||
7358|Cozy Fire|135805|p|60||o||
7363|Fire's Glow|135805|p|-1||i||
7365|Bottle of Poison|136016|t|30|poison|o||
7366|Berserker Stance|132275|p|240||o||
7367|Infected Bite|136127|t|180|disease|o||
7383|Water Bubble|135864|p|30|magic|o||
7389|Attack|132150|e|15||o||
7396|Fishliver Oil|133892|p|30|magic|i||
7399|Terrify|132270|t|4|magic|o||
7481|Howling Rage|132091|p|300||o||
7483|Howling Rage|132091|p|300||o||
7484|Howling Rage|132091|p|300||o||
7586|Shadow Port|136121|p|10||o||
7587|Shadow Port|136121|p|10||o||
7621|Arugal's Curse|136160|t|10|curse|o||
7638|Potion Toss|135999|a|3||o||
7645|Dominate Mind|136206|t|10|magic|o||
7656|Hex of Ravenclaw|136129|t|30|magic|o||
7657|Hex of Ravenclaw|136129|p|30||o||
7713|Wailing Dead|136183|t|6|curse|o||
7737|Food|134062|p|15||i||
7739|Inferno Shell|135826|p|10|magic|o||
7750|Consuming Rage|136146|p|12||o||
7761|Shared Bonds|136230|p|4|magic|o||
7764|Wisdom of Agamaggan|135736|a|1800|magic|o||
7803|Thundershock|135990|t|5||o||
7806|Flameblade|135811|a|180||o||
7807|Flameblade|135811|a|180||o||
7808|Flameblade|135811|a|180||o||
7840|Swim Speed|134754|p|20|magic|i||
7844|Fire Power|134835|p|1800||i||
7901|Decayed Agility|135914|t|300|disease|o||
7914|Capture Spirit|136163|t|9||i||
7926|First Aid|135915|a|8||i||
7927|First Aid|135915|a|8||i||
7947|Localized Toxin|136016|t|60|poison|o||
7948|Wild Regeneration|136081|p|20|magic|o||
7950|Pause|132149|p|3||o||
7961|Azrethoc's Stomp|132368|t|5||o||
7964|Smoke Bomb|132156|t|4|magic|o||
7965|Cobrahn Serpent Form|136040|p|300||o||
7966|Thorns Aura|136104|p|60||o||
7967|Naralex's Nightmare|136090|t|15|magic|o||
7974|Azrethoc's Flight|136018|p|-1||o||
7992|Slowing Poison|136093|t|25|poison|o||
7997|Sap Might|136119|t|300|magic|o||
7998|Soot Covering|132156|t|10|magic|o||
8014|Tetanus|135914|t|1200|disease|o||
8016|Spirit Decay|135914|t|1200|disease|o||
8040|Druid's Slumber|136090|t|15|magic|o||
8041|Serpent Form|132276|p|10||o||
8064|Sleepy|136090|p|30|magic|o||
8066|Shrink|136121|p|120|curse|o||
8067|Party Time!|136142|p|120|magic|o||
8068|Healthy Spirit|135932|a|1800|magic|o||
8070|Rejuvenation|136081|a|12|magic|i||
8078|Thunderclap|136105|t|10|magic|o||
8091|Armor|132341|a|1800|magic|i||
8094|Armor|132341|a|1800|magic|i||
8095|Armor|132341|a|1800|magic|i||
8096|Intellect|135932|a|1800|magic|i||
8097|Intellect|135932|a|1800|magic|i||
8098|Intellect|135932|a|1800|magic|i||
8099|Stamina|136112|a|1800|magic|i||
8100|Stamina|136112|a|1800|magic|i||
8101|Stamina|136112|a|1800|magic|i||
8112|Spirit|136126|a|1800|magic|i||
8113|Spirit|136126|a|1800|magic|i||
8114|Spirit|136126|a|1800|magic|i||
8115|Agility|135879|a|1800|magic|i||
8116|Agility|135879|a|1800|magic|i||
8117|Agility|135879|a|1800|magic|i||
8118|Strength|136101|a|1800|magic|i||
8119|Strength|136101|a|1800|magic|i||
8120|Strength|136101|a|1800|magic|i||
8137|Silithid Pox|136066|t|1800|disease|o||
8138|Mirkfallon Fungus|135914|t|2700|disease|o||
8139|Fevered Fatigue|136066|t|1800|disease|o||
8140|Befuddlement|136175|t|15|magic|o||
8142|Grasping Vines|136025|t|10|magic|o||
8147|Thunderclap|136105|t|10|magic|o||
8148|Thorns Aura|136104|p|60||o||
8150|Thundercrack|136105|t|2.5|magic|o||
8151|Surprise Attack|132092|t|2.5||o||
8152|Prowl|132320|p|-1||o||
8153|Owl Form|136076|p|-1||o||
8178|Grounding Totem|136039|p|-1||o||
8191|Zeal|135926|p|15|magic|i||
8202|Sapta Sight|132092|p|1200|magic|i||
8203|Elemental Spirit Invisibility|135994|p|-1||o||
8212|Enlarge|136101|p|120||i||
8213|Savory Deviate Delight|134302|p|3600||i||
8215|Rapid Cast|132369|p|120||o||
8218|Sneak|132320|p|-1||o||
8219|Flip Out|132288|p|3600||o||
8220|Flip Out|132288|p|3600||o||
8221|Yaaarrrr|132288|a|3600||o||
8222|Yaaarrrr|132288|a|3600||o||
8223|Oops!|136016|p|10||o||
8224|Cowardice|132092|p|600|magic|o||
8225|Run Away!|136183|p|5|magic|o||
8226|Fake Death|136187|p|300||o||
8242|Shield Slam|132357|t|2||o||
8245|Corrosive Acid|136007|t|300|magic|o||
8255|Strong Cleave|132338|t|10||o||
8256|Lethal Toxin|136016|t|180|poison|o||
8257|Venom Sting|132274|t|30|poison|o||
8258|Devotion Aura|135893|p|240||o||
8260|Rushing Charge|132368|p|4||o||
8267|Cursed Blood|136020|t|600|curse|o||
8269|Enrage|136224|p|120||o||
8272|Mind Tremor|136025|t|600|magic|o||
8275|Poisoned Shot|132273|t|75|poison|o||
8277|Voodoo Hex|136138|t|120|curse|i||
8281|Sonic Burst|136222|t|10|magic|o||
8282|Curse of Blood|136189|t|600|curse|o||
8285|Rampage|136063|t|2.5||o||
8299|Perm. Illusion Slime|132311|p|-1||i||
8312|Trap|134325|t|10|magic|i||
8313|Poison|136016|t|9|poison|i||
8314|Rock Skin|136025|a|3600|magic|o||
8315|Perm. Illusion Succubus|132311|p|-1||i||
8321|Perm. Illusion Dreadlord|132311|p|-1||o||
8324|Perm. Illusion HE Hunter|132311|p|-1||i||
8326|Ghost|132331|p|-1||o||
8338|Defibrillated!|136075|p|2||o||
8345|Control Machine|132997|p|60||o||
8346|Mobility Malfunction|132996|t|20||o||
8348|Julie's Blessing|135953|p|12|magic|i||
8357|Perm. Illusion Shade|132311|p|-1||i||
8359|Left for Dead|136187|p|300||o||
8360|Perm. Illusion Dreaming Whelp|132311|p|-1||i||
8361|Purity|135920|p|2||o||
8362|Renew|135953|a|20|magic|o||
8363|Parasite|132273|t|75|poison|o||
8365|Enlarge|136101|a|60|magic|o||
8373|Mana Shield (PT)|136235|p|-1||o||p
8377|Earthgrab|136064|t|4||o||
8379|Disarm|132343|t|10||o||
8382|Leech Poison|136067|t|45|poison|o||
8383|Burning Tenacity|135805|a|3600|magic|o||
8384|Pure Water|135864|a|3600|magic|o||
8385|Swift Wind|136022|a|3600|magic|o||
8387|Find Herbs|134183|p|-1||o||
8388|Find Minerals|136025|p|-1||o||
8391|Ravage|132152|t|3||o||
8394|Striped Frostsaber|132267|p|-1||i||
8395|Emerald Raptor|132253|p|-1||i||
8396|Summon Ivory Tallstrider|132253|p|-1||o||
8398|Frostbolt Volley|135846|t|8|magic|o||
8399|Sleep|136090|t|10|magic|o||
8510|Large Seaforium Backfire|135805|p|2||o||
8511|Small Seaforium Backfire|135805|p|2||o||
8516|Windfury Totem|136114|p|1||e||
8552|Curse of Weakness|136138|t|120|magic|i||
8553|Barleybrew Scalder|132792|p|600||o||
8554|Drinking Barleybrew Scalder|132792|a|2||o||
8599|Enrage|136224|p|120||o||
8600|Fevered Plague|136066|t|180|disease|o||
8602|Vengeance|136224|p|10|magic|o||
8611|Phase Shift|136164|p|6||o||
8646|Snap Kick|132219|t|2||o||
8672|Challenger is Dazed|136175|p|30||o||
8692|Mind-numbing Poison II|136066|t|12|poison|e||
8699|Unholy Frenzy|136012|a|20|magic|o||
8713|Overwhelming Musk|136128|p|-1||o||
8715|Terrifying Howl|132111|t|3||o||
8716|Low Swipe|132109|t|12||o||
8733|Blessing of Blackfathom|135850|a|3600||o||
8734|Blackfathom Channeling|136121|p|-1||o||
8788|Lightning Shield|136051|a|600|magic|o||
8806|Poisoned Shot|132273|t|60|poison|o||
8817|Smoke Bomb|136047|p|3||o||
8818|Garrote|132297|t|18||o||
8822|Stealth|132320|p|30||o||
8823|Crusader Strike|135924|t|30|magic|o||
8824|Crusader Strike|135924|t|30|magic|o||
8872|Perm. Illusion FelGuard|132311|p|-1||o||
8874|Stealth (TEST)|132320|p|-1||o||i
8878|Echoes of Lordaeron UNUSED|132486|a|-1||o||i
8892|Goblin Rocket Boots|135805|p|20||i||
8898|Sapta Sight|132092|p|1200|magic|i||
8899|Sapta Sight|132092|p|1200|magic|i||
8900|Sapta Sight|132092|p|1200|magic|i||
8901|Gas Bomb|133581|t|20||o||
8902|Gas Bomb|133581|p|20||o||
8909|Unholy Shield|136153|p|600||o||
8980|Skeletal Horse|132264|p|-1||i||
8988|Silence|135975|t|10|magic|o||
8989|Whirlwind|132369|p|10||o||
8990|Retribution Aura|135873|p|-1||o||
8994|Banish|136135|t|15|magic|o||
9034|Immolate|135817|t|21|magic|o||
9080|Hamstring|132316|t|10||o||
9084|Magic Stone Helmet|136245|p|-1||o||
9095|Cantation of Manifestation|135994|t|600||i||
9127|Transform: Peasant w/ wood|135996|p|-1||o||
9159|Sleep|136090|t|10|magic|i||
9175|Running Speed|132307|p|15||i||
9176|Holy Sunder|136139|t|60|magic|i||
9177|Tigule's Strawberry Ice Cream|133987|p|24||o||
9178|Brain Freeze|135842|p|120||o||
9179|Stun|136222|p|3||o||
9192|"Plucky" Resumes Human Form|132276|p|120||o||
9199|Attack Power %|133951|p|300||o||
9220|"Plucky" Resumes Chicken Form|132276|p|120||o||
9234|Armor Debuff (TEST)|132341|a|1800|magic|o||i
9256|Deep Sleep|136090|t|10||o||
9275|Immolate|135817|t|21|magic|o||
9347|Mortal Strike|132355|a|-1||o||
9373|Soul Siphon|136169|t|12|magic|o||
9436|Invisibility Detection|136129|p|-1||o||
9438|Arcane Bubble|135896|p|8||o||
9454|Freeze|136090|a|-1||o||
9458|Smoke Cloud|136047|p|3||o||
9459|Corrosive Ooze|136119|t|60|magic|o||
9462|Mirefin Fungus|136100|t|8|magic|o||
9482|Amplify Flames|135807|t|30|magic|o||
9552|Searing Flames|135817|t|9|magic|o||
9574|Flame Buffet|135807|t|45|magic|o||
9576|Lock Down|132995|p|10||o||
9587|Magic Potion|136047|p|180||o||
9612|Ink Spray|136090|t|15|magic|o||
9614|Rift Beacon|136006|t|60|magic|o||
9616|Wild Regeneration|136081|p|20|magic|o||
9632|Bladestorm|132369|p|9||i||
9657|Shadow Shell|136121|p|10|magic|o||
9658|Flame Buffet|135807|t|45|magic|o||
9672|Frostbolt|135846|t|4|magic|o||
9712|Thaumaturgy Channel|136163||5||i||
9733|Arantir's Anger|132369|p|4||o||
9735|Sapta Sight|132092|p|1200|magic|o||
9736|Arantir's Deception|132331|p|30||o||
9738|Rift Spawn Becomes Visible|136235|p|120||o||p
9740|Arantir's Deception|132331|p|-1||o||
9741|Arantir's Rage|132336|t|6||o||
9773|Defias Tower II|135812|p|8||o||
9774|Immune Root|136115|p|5||i||
9775|Irradiated|135914|t|60|disease|o||
9779|Defias Tower III|135812|p|8||o||
9782|Mithril Shield Spike|136235|p|-1||e||p
9784|Iron Shield Spike|136235|p|-1||e||p
9791|Head Crack|132325|t|20||o||
9796|Blight|136066|t|60|disease|i||
9798|Radiation|136133|p|-1||o||
9800|Holy Shield|135940|p|60|magic|i||
9806|Phantom Strike|136033|t|20|magic|i||
9810|Touch of Zanzil|136235|p|10||o||p
9906|Reflection|136222|p|5|magic|o||
9915|Frost Nova|135848|t|10|magic|o||
9930|Empathy of Stone|136025|a|30|magic|o||
9991|Touch of Zanzil|136230|a|604800|poison|o||
9992|Dizzy|136222|p|10||o||
10017|Frost Hold|135848|t|10|magic|o||
10018|Rat Nova|133946|t|10|magic|o||
10032|Uber Stealth|132320|p|-1||o||
10072|Splintered Obsidian|136126|p|3600||o||
10092|Sand Storm|136022|p|-1||o||
10093|Harsh Winds|136022|t|1||o||
10096|Shrink|136121|t|120|curse|o||
10134|Sand Storm|136022|p|7||o||
10136|Magenta Cap Sickness|132154|t|1200|disease|o||
10228|Greater Invisibility|136047|p|120||o||
10236|Humanoid Tracking|132089|p|180||o||
10238|Demon Tracking|136219|p|180||o||
10240|Undead Tracking|134179|p|180||o||
10241|Dragon Tracking|134295|p|180||o||
10242|Elemental Tracking|135861|p|180||o||
10250|Drink|132805|p|30||o||
10251|Biletoad Infection|135914|t|180|disease|o||
10252|Awaken Earthen Guardians|136025|t|5||o||
10253|Chemical Peel|134321|t|10|magic|o||
10255|Stoned|136018|p|-1||o||
10256|Food|134062|p|30||i||
10257|Food|134062|p|30||o||
10259|Awaken Earthen Dwarf|136025||2||o||
10260|Reconstruct|136168||20||o||
10266|Lung Puncture|132302|p|2||o||
10267|Slush|134167|p|-1||o||
10268|Decimate|136235|p|180||o||p
10336|Crusader Strike|135924|t|30|magic|o||
10337|Crusader Strike|135924|t|30|magic|o||
10342|Guardian Effect|135893|p|15||o||
10345|Rebuild|136168||20||o||
10348|Tune Up|132996||20||o||
10351|Basilisk Skin|134314|p|5||i||
10368|Uther's Light Effect|135940|p|15|magic|i||
10370|Lacerations|132155|t|60||i||
10371|Slow|132306|t|10||o||
10451|Implosion|135826|t|||o||
10452|Flame Buffet|135807|t|20|magic|o||
10454|Into the Rift|132331|p|-1||o||
10455|Minor Tremor|136025|t|0.001||o||
10576|Piercing Howl|132117|t|6||o||
10578|Fireball|135812|t|8||i||
10608|Windfury Totem|136114|p|1||e||
10610|Windfury Totem|136114|p|1||e||
10618|Elemental Protection|135880|p|120|magic|i||
10651|Curse of the Eye|136224|t|120|curse|o||
10653|Curse of the Eye|136224|t|120|curse|o||
10654|TEST - DBUCKLER|135999|p|10||o||i
10665|Water Walk|136235|p|-1||o||p
10667|Rage of Ages|136101|p|3600||i||
10668|Spirit of Boar|136075|p|3600||i||
10669|Strike of the Scorpok|136036|p|3600||i||
10670|Rage of Ages|136101||3600||o||
10671|Spirit of Boar|136075||3600||o||
10672|Strike of the Scorpok|136036||3600||o||
10690|Infallible Mind|135988||3600||o||
10691|Spiritual Domination|135818||3600||o||
10692|Infallible Mind|135988|p|3600||i||
10693|Spiritual Domination|135818|p|3600||i||
10729|Feather Fall|136235|p|-1||o||p
10730|Pacify|132311|t|10|magic|o||
10732|Supercharge|135990||10||o||
10734|Hail Storm|135846|t|3||o||
10767|Rising Spirit|136053|a|1800||o||
10787|Panther|132225|p|-1||i||
10788|Leopard|132242|p|-1||i||
10789|Spotted Frostsaber|132267|p|-1||i||
10790|Tiger|132242|p|-1||i||
10792|Spotted Panther|132225|p|-1||i||
10793|Striped Nightsaber|132225|p|-1||i||
10794|Spirit Shock|136140|p|30||o||
10795|Ivory Raptor|132253|p|-1||i||
10796|Turquoise Raptor|132253|p|-1||i||
10798|Obsidian Raptor|132253|p|-1||i||
10799|Violet Raptor|132253|p|-1||i||
10800|Summon Brown Tallstrider|132253|p|-1||o||
10801|Summon Gray Tallstrider|132253|p|-1||o||
10802|Summon Pink Tallstrider|132253|p|-1||o||
10803|Summon Purple Tallstrider|132253|p|-1||o||
10804|Summon Turquoise Tallstrider|132253|p|-1||o||
10805|Shackle Shatter|136168||3||o||
10831|Reflection Field|132361|p|5|magic|o||
10834|Shackle Shatter|136168||3||o||
10835|Shackle Shatter|136168||3||o||
10836|Shackle Shatter|136168||3||o||
10838|First Aid|135915|a|8||i||
10839|First Aid|135915|a|8||i||
10848|Shroud of Death|132331|p|-1||o||
10851|Grab Weapon|132343|t|15||o||
10852|Battle Net|132149|t|10||o||
10855|Lag|132996|t|10|magic|o||
10856|Link Dead|132995|p|8||o||
10857|Flames of Chaos|135826|t|35||o||
10873|Red Mechanostrider|132247|p|-1||i||
10967|Echoing Roar|132366|t|20||o||
10968|Demoralizing Roar|132121|t|30||o||
10969|Blue Mechanostrider|132247|p|-1||i||
10987|Geyser|135836|t|5|magic|o||
11010|Hover|136235|p|-1||o||p
11013|Sneak|132320|p|120||o||
11014|Flow of the Northspring|135953|a|15|magic|o||
11020|Petrify|132154|t|8|magic|o||
11048|Perm. Illusion Bishop Tyriona|132288|p|-1||o||
11067|Perm. Illusion Tyrion|132288|p|-1||o||
11089|Theka Transform|136121|p|30||o||
11131|Icicle|135846|t|10||o||
11196|Recently Bandaged|133678|a|60||o||
11201|Crippling Poison|132274|t|12|poison|e||
11206|Uldaman Boss Object Visual|136130|p|600||o||
11264|Ice Blast|135848|t|10|magic|o||
11319|Water Walking|134776|p|1800||i||
11328|Agility|134873|p|3600||i||
11330|Agility|134873|p|3600||o||
11331|Strength|134838|p|3600||o||
11332|Great Strength|134838|p|3600||o||
11333|Greater Agility|134873|p|3600||o||
11334|Greater Agility|134874|p|3600||i||
11348|Greater Armor|134846|p|3600||i||
11349|Armor|134845|p|3600||i||
11350|Fire Shield|135817|p|15|magic|i||
11353|Deadly Poison III|132290|t|12|poison|e||
11354|Deadly Poison IV|132290|t|12|poison|e||
11359|Restoration|135894|p|30|magic|i||
11363|Resistance|134719|p|180|magic|o||
11364|Resistance|134744|p|180|magic|i||
11371|Gift of Arthas|134808|p|1800|magic|i||
11374|Gift of Arthas|136066|t|180|disease|i||
11389|Detect Undead|134179|p|3600||i||
11390|Arcane Elixir|134810|p|1800||i||
11391|Roach Shift|134321|a|30||o||
11392|Invisibility|134798|p|18||i||
11393|Intellect|134721|p|3600||o||
11394|Greater Intellect|134721|p|3600||o||
11395|Greater Intellect|134721|p|3600||o||
11396|Greater Intellect|134721|p|3600||i||
11397|Diseased Shot|136127|t|300|disease|o||
11398|Mind-numbing Poison III|136066|t|14|poison|e||
11403|Dream Vision|135994|p|120||i||
11404|Great Strength|134838|p|3600||o||
11405|Greater Strength|134839|p|3600||i||
11406|Potion of Demon Slaying|134807|p|300||i||
11407|Detect Demon|136219|p|3600||i||
11413|Echoes of Lordaeron|132486|a|-1||o||
11414|Echoes of Lordaeron|132486|a|-1||o||
11415|Echoes of Lordaeron|132486|a|-1||o||
11428|Knockdown|132154|t|2||o||
11430|Slam|132357|t|2||o||
11436|Slow|136091|t|10|magic|o||
11442|Withered Touch|136134|t|180|disease|o||
11443|Cripple|136135|t|15|magic|o||
11444|Shackle Undead|136091|t|20|magic|o||
11445|Bone Armor|136225|p|60|magic|o||
11446|Mind Control|136206|p|300||o||
11469|Deadly Toxin IV|132290|t|12|poison|o||
11470|Deadly Toxin III|132290|t|12|poison|o||
11471|Deadly Toxin II|132290|t|12|poison|o||
11474|Shadow Power|134828|p|1800||i||
11481|TWEEP|135826|t|11||o||
11515|Lordaeron Tower|132483|p|60||o||
11534|Leper Cure!|135907|p|20||o||
11538|Frostbolt|135846|t|4|magic|o||
11539|Deadly Toxin|132290|t|12|poison|o||
11638|Radiation Poisoning|136133|p|25|poison|i||
11639|Shadow Word: Pain|136207|t|18|magic|o||
11640|Renew|135953|a|15|magic|o||
11641|Hex|136071|t|10|magic|o||
11647|Power Word: Shield|135940|p|30||o||
11649|Detect Invisibility|136152|p|-1||o||
11650|Head Butt|132939|t|3||o||
11657|Jang'thraze|132110|p|20|magic|i||
11658|Sul'thraze|136145|t|15||i||
11790|Poison Cloud|136077|t|12|poison|i||
11791|Puncture Armor|132109|t|30||o||
11816|Land Mine Arming|132996|p|-1||o||
11820|Electrified Net|132149|t|10||o||
11831|Frost Nova|135848|t|8|magic|o||
11835|Power Word: Shield|135940|a|30|magic|o||
11836|Freeze Solid|135852|t|10|magic|o||
11841|Static Barrier|136051|p|300|magic|i||
11876|War Stomp|132091|t|5||o||
11877|Capture Treant|136235|t|5||o||p
11879|Disarm|132343|t|5||i||
11890|Antu'sul's Salvation|136235|p|-1||o||p
11892|Shrink|136121|t|120|curse|o||
11918|Poison|136016|t|15|poison|o||
11922|Entangling Roots|136100|t|15|magic|o||
11960|Curse of the Dreadmaul|136020|t|60|curse|o||
11962|Immolate|135817|t|21|magic|o||
11963|Enfeeble|136138|t|120|curse|o||
11971|Sunder Armor|132363|t|30||o||
11974|Power Word: Shield|135940|a|30|magic|o||
11977|Rend|132155|t|15||o||
11980|Curse of Weakness|136138|t|120|curse|o||
11983|Steam Jet|132156|t|10|magic|o||
12001|Plague Cloud|136127|t|240|disease|o||
12020|Call of the Grave|136130|t|60|curse|o||
12021|Fixate|136129|p|10||o||
12022|Admiral's Hat|134229|p|600|magic|i||
12023|Web|132149|t|5||o||
12024|Net|132149|t|5||o||
12040|Shadow Shield|136121|p|30|magic|o||
12054|Rend|132155|t|15||o||
12096|Fear|136183|t|8|magic|o||
12097|Pierce Armor|136231|t|20||o||
12098|Sleep|136090|t|20|magic|o||
12134|Atal'ai Corpse Eat|132122|p|12||o||
12160|Rejuvenation|136081|a|12|magic|o||
12166|Muscle Tear|132155|t|5||o||
12169|Shield Block|132110|p|5||o||
12174|Agility|135879|a|1800|magic|i||
12175|Armor|132341|a|1800|magic|i||
12176|Intellect|135932|a|1800|magic|i||
12177|Spirit|136126|a|1800|magic|i||
12178|Stamina|136112|a|1800|magic|i||
12179|Strength|136101|a|1800|magic|i||
12187|Disease Cloud|136006|p|-1||o||
12241|Twin Colossals Teleport|136022|p|4||o||
12242|Twin Colossals Teleport|136022|a|3||o||
12245|Infected Spine|136127|t|300|disease|o||
12248|Amplify Damage|136006|t|10|magic|o||
12251|Virulent Poison|136016|t|30|poison|o||
12252|Web Spray|132149|t|10||o||
12255|Curse of Tuten'kash|136020|t|900|curse|o||
12257|Breath of Fire|135818|p|5||i||
12279|Curse of Blood|136189|t|600|curse|o||
12280|Acid of Hakkar|136007|t|60||o||
12332|Lathoric the Black|132331|p|||o||
12380|Shadow Channeling|136121|p|-1||o||
12421|Mithril Frag Bomb|135826|t|2||i||
12438|Slow Fall|135992|p|10||i||
12461|Backhand|132939|t|2||o||
12479|Hex of Jammal'an|136232|t|10||o||
12480|Hex of Jammal'an|136121|t|15|curse|o||
12483|Hex of Jammal'an|136232|t|15||o||
12493|Curse of Weakness|136138|t|120|curse|o||
12495|Eranikus the Chained Invisiibility|135994|p|-1||o||
12509|Teleport to Azshara Tower|136011|a|3||o||
12520|Teleport from Azshara Tower|136022|p|4||o||
12521|Teleport from Azshara Tower|136022|a|3||o||
12528|Silence|135975|t|10|magic|o||
12530|Frailty|136119|t|60|magic|o||
12531|Chilling Touch|135842|t|8|magic|o||
12533|Acid Breath|136007|t|45||o||
12540|Gouge|132155|t|4||o||
12541|Ghoul Rot|136134|t|600|disease|o||
12542|Fear|136183|t|4|magic|o||
12543|Hi-Explosive Bomb|135826|t|3||i||
12544|Frost Armor|135843|p|1800|magic|o||
12545|Spitelash|136152|t|20|magic|o||
12548|Frost Shock|135849|t|8|magic|o||
12550|Lightning Shield|136051|p|600|magic|o||
12551|Frost Shot|135989|t|10|magic|o||
12557|Cone of Cold|135852|t|8|magic|o||
12561|Fire Protection|135806|p|60|magic|i||
12562|The Big One|135826|t|5||i||
12565|Wyatt Test|136163|p|-1|curse|o||i
12566|Plainsrunning|132091|p|-1||o||
12567|Plainsrunning|132091|p|-1||o||
12568|Plainsrunning|132091|p|-1||o||
12608|Stealth Detection|132150|p|600||i||
12611|Cone of Cold|135852|t|8|magic|o||
12623|Suppression|136121||-1||o||
12627|Disease Cloud|136006|p|-1||o||
12655|Enlightenment|136159|p|4||o||
12674|Frost Nova|135848|t|8|magic|o||
12675|Frostbolt|135846|t|4|magic|o||
12685|Fade|135994|p|10|magic|i||
12686|Enrage|136224|p|15||i||
12705|Long Daze|135860|t|6||o||
12733|Fearless|133435|p|30||i||
12734|Ground Smash|135906|t|3||o||
12737|Frostbolt Volley|135846|t|4|magic|o||
12738|Amplify Damage|136006|t|10|magic|o||
12741|Curse of Weakness|136138|t|120|curse|o||
12742|Immolate|135817|t|21|magic|o||
12747|Entangling Roots|136100|t|10|magic|o||
12748|Frost Nova|135848|t|5|magic|o||
12766|Cloud of Chained Essence|136077|p|20||i||
12774|(DND) Belnistrasz Idol Shutdown Visual|136235||-1||o||ip
12795|Enrage|136224|p|120||o||
12843|Mordresh's Shield|136121|p|60|magic|o||
12845|Lesser Invisibility|135994|p|30||o||
12881|Poison State|136182|p|-1||o||
12883|Longsight|132327|p|-1||i||
12884|Acid Breath|136007|t|45||o||
12888|Cause Insanity|136206|t|6|magic|o||
12889|Curse of Tongues|136140|t|15|curse|o||
12890|Deep Slumber|136135|t|15|magic|o||
12891|Acid Breath|136007|t|45||o||
12941|Fel Curse Effect|135899|p|15||o||
12942|Fell Curse Effect|135899|p|10||o||
12943|Fell Curse Effect|135899|p|10||o||
12946|Putrid Stench|136127|t|10|disease|o||
13003|Shrink Ray|135989|t|20||o||
13004|Grow|135989|p|30||o||
13005|Hammer of Justice|135963|t|4|magic|o||
13007|Divine Protection|135954|p|8||o||
13008|Retribution Aura|135873|p|-1||o||
13010|Shrink|135989|p|30||o||
13013|Dissolve Armor|136007|t|20||o||
13022|Fire and Arcane Reflect|135736|a|-1||o||
13099|Net-o-Matic|132149|t|10||o||
13119|Net-o-Matic|132149|t|20||o||
13138|Net-o-Matic|132149|t|20||o||
13141|Gnomish Rocket Boots|135805|p|20||i||
13158|Rocket Boots Malfunction|135805|p|5||o||
13168|Chicken Fury|136224|p|10||o||
13181|Gnomish Mind Control Cap|135995|t|20|magic|o||
13183|Goblin Dragon Gun|135818|p|10||i||
13218|Wound Poison|134197|t|15|poison|e||
13222|Wound Poison|134197|t|15|poison|e||
13223|Wound Poison|134197|t|15|poison|e||
13224|Wound Poison|134197|t|15|poison|e||
13234|Harm Prevention Belt|135940|p|600||i||
13235|Forcefield Collapse|136135|p|20|magic|o||
13236|Nature Channeling|136041|p|-1||o||
13237|Goblin Mortar|135826|t|3||i||
13238|Goblin Mortar|135826|p|3||o||
13278|Gnomish Death Ray|136197|p|4||i||
13298|Poison|136016|t|30|poison|o||
13318|Rend|132155|t|30||i||
13322|Frostbolt|135846|t|2|magic|o||
13323|Polymorph|136071|t|20|magic|o||
13327|Reckless Charge|136010|t|30|magic|i||
13338|Curse of Tongues|136140|t|15|curse|o||
13360|Knockdown|132154|p|2||o||
13424|Faerie Fire|136033|t|30|magic|i||
13438|Fireball|135810|t|6||i||
13439|Frostbolt|135846|t|5|magic|i||
13443|Rend|132155|t|15||o||
13444|Sunder Armor|132363|t|30||o||
13445|Rend|132155|t|15||o||
13459|Decimate|134947|a|30||o||
13466|Goblin Dragon Gun|135818|p|7||o||
13488|Firegut Fear Storm|135902|t|50||o||
13490|Howling Blade|132117|t|30||i||
13493|Gnomish Death Ray|136197|p|4||o||
13494|Haste|136047|p|30||i||
13496|Dazed|135860|t|10||i||
13518|Poison|136016|t|15|poison|i||
13524|Curse of Stalvan|136203|t|60|curse|i||
13526|Corrosive Poison|136016|t|14|poison|i||
13528|Decayed Power|136006|t|30|disease|i||
13530|Corruption|136118|t|3|magic|i||
13532|Thunder Clap|136105|t|10||i||
13533|Haste|136047|p|10||i||
13534|Disarm|132343|t|10||i||
13540|Green Channeling|136120|p|-1||o||
13541|Knockback 500 Triggers|136235|p|-1||o||p
13566|Knockback 500 Triggers|136235|a|8||o||p
13578|Jadefire|135824|p|8|magic|o||
13579|Gouge|132155|t|4||o||
13582|Deadly Poison|136016|t|120|poison|o||
13583|Curse of the Deadwood|136160|t|120|curse|o||
13585|Lightning Shield|136051|a|600|magic|o||
13589|Haste Aura|135906|p|-1||o||
13608|Hooked Net|132149|t|10||o||
13619|Wracking Pains|136139|t|180|curse|o||
13692|Dire Growl|132278|t|15||o||
13704|Psychic Scream|136184|t|6||o||
13716|AOD|136195|p|-1||o||
13729|Flame Shock|135813|t|12|magic|o||
13730|Demoralizing Shout|132366|t|30||o||
13736|Whirlwind|132369|p|2||o||
13737|Mortal Strike|132355|t|5||o||
13738|Rend|132155|t|15||o||
13744|Blazing Emblem|135806|p|15||i||
13747|Slow|136091|t|10|magic|o||
13752|Faerie Fire|136033|t|30|magic|i||
13787|Demon Armor|136185|p|1800|magic|o||
13808|M73 Frag Grenade|135826|t|3||i||
13819|Summon Warhorse|136103|p|-1||o||
13847|Recklessness|132109|p|15||o||
13874|Divine Shield|135896|p|8||o||
13880|Magma Splash|135817|t|30||o||
13884|Withering Poison|136016|t|180|poison|o||
13902|Fist of Ragnaros|135971|t|5||o||
13903|Seal of Sacrifice|135966|a|30|magic|o||
13907|Smite Demon|135920|t|5|magic|e||
13910|Force Create Elemental Totem|135225|t|0.001||o||
13951|Rebuild|136168||20||o||
14030|Hooked Net|132149|t|10||o||
14032|Shadow Word: Pain|136207|t|18|magic|o||
14087|Rend|132155|t|30||o||
14100|Terrifying Roar|132111|t|5||o||
14102|Head Smash|132111|t|2||o||
14110|Bloodpetal Poison|136016|t|30|poison|o||
14118|Rend|132155|t|7||i||
14120|Tunneler Acid|136007|t|30||o||
14130|Muculent Fever|135914|t|600|disease|o||
14147|Acid Slime|136007|t|30||o||
14180|Sticky Tar|132343|t|4||o||
14253|Abolish Poison|136068|a|8|magic|i||
14331|Vicious Rend|132155|t|15||o||
14514|Blink|135736|p|1||o||
14515|Dominate Mind|136206|t|15|magic|o||
14517|Crusader Strike|135924|t|30|magic|o||
14518|Crusader Strike|135924|t|30|magic|o||
14530|Speed|132307|p|10||i||
14532|Creeper Venom|136067|t|300|poison|o||
14533|Disjunction|135990|t|300|magic|o||
14534|Barbed Sting|136067|t|300|poison|o||
14535|Dredge Sickness|136066|t|300|disease|o||
14538|Aural Shock|136183|t|300|curse|o||
14539|Putrid Enzyme|136066|t|300|disease|o||
14621|Polymorph|136071|p|20|magic|o||
14744|Burning Spirit|135805|p|180||o||
14775|Stilled|136018|p|-1||o||
14792|Venomhide Poison|136016|t|30|poison|o||
14795|Venomhide Poison|132290|t|12|poison|e||
14797|Burning Tar|135817|p|21||o||
14822|Drunken Rage|136224|p|15||o||
14868|Curse of Agony|136139|t|30|curse|o||
14870|Drunken Stupor|132791|p|3||o||
14871|Shadow Bolt Misfire|136197|p|1||o||
14872|Drunken Rage|136224|p|15||o||
14874|Rupture|132302|t|10||o||
14875|Curse of Agony|136139|t|30|curse|o||
14890|Dismounting Blow|136222|t|0.001||o||
14897|Slowing Poison|136093|t|25|poison|o||
14902|Cheap Shot|132092|t|4||o||
14903|Rupture|132302|t|2||o||
14907|Frost Nova|135848|t|8|magic|o||
15007|Resurrection Sickness|136147|p|60||o||
15039|Flame Shock|135813|t|12|magic|o||
15041|Fire Ward|135806|p|60|magic|o||
15042|Curse of Blood|136189|t|600|curse|o||
15043|Frostbolt|135846|t|4|magic|o||
15044|Frost Ward|135850|p|60|magic|o||
15056|Distract Move|136235|t|7||o||p
15061|Enrage|136224|p|5||o||
15062|Shield Wall|132362|p|10||o||
15063|Frost Nova|135848|t|8|magic|o||
15087|Evasion|136205|p|15||o||
15089|Frost Shock|135849|t|8|magic|o||
15091|Blast Wave|135903|t|6||o||
15096|Flame Shock|135813|t|12|magic|o||
15123|Resist Fire|135806|a|3600|magic|o||
15128|Mark of Flames|135807|t|120|magic|o||
15167|Windsor's Frenzy|132277|p|600||o||
15229|Crystal Restore|134095|a|15|magic|i||
15231|Crystal Force|134088|a|1800|magic|i||
15233|Crystal Ward|134129|a|1800|magic|i||
15235|Crystal Yield|134074|t|120||i||
15244|Cone of Cold|135852|t|8|magic|o||
15252|Keg Trap|132622|t|2||o||
15277|Seal of Reckoning|135971|a|30|magic|o||
15279|Crystal Spire|134134|a|600|magic|i||
15280|Cleave Armor|132355|t|20||i||
15281|Encage Emberseer|136121||-1||o||
15283|Stunning Blow|135899|t|8||i||
15288|Fury of Ragnaros|135933|a|1800|magic|o||
15346|Seal of Reckoning|135971|a|30|magic|o||
15366|Songflower Serenade|135934|a|3600||i||
15398|Psychic Scream|136184|t|8||o||
15470|Curse of Tongues|136140|t|15|curse|o||
15471|Enveloping Web|136022|t|8||o||
15474|Web Explosion|132149|t|10||o||
15475|Baneful Poison|136016|t|120|poison|o||
15494|Fury of Forgewright|135818|p|10||i||
15497|Frostbolt|135846|t|4|magic|o||
15499|Frost Shock|135849|t|8|magic|o||
15502|Sunder Armor|132363|t|30||o||
15505|Immolate|135817|t|21|magic|o||
15507|Lightning Shield|136051|p|600|magic|o||
15529|Gout of Flame|135818|p|10||o||
15530|Frostbolt|135846|t|4|magic|o||
15531|Frost Nova|135848|t|8|magic|o||
15532|Frost Nova|135848|t|8|magic|o||
15533|Stoned - Channel Cast Visual|136018|p|-1||o||
15534|Polymorph|136071|t|20|magic|o||
15535|Enveloping Winds|136018|t|10|magic|o||
15548|Thunderclap|136105|t|10|magic|o||
15570|Immolate|135817|t|21|magic|o||
15572|Sunder Armor|132363|t|30||o||
15583|Rupture|132302|t|10||o||
15588|Thunderclap|136105|t|10|magic|o||
15593|War Stomp|132091|t|8||o||
15595|Force of Will|133276|p|10||i||
15602|Lord General's Sword|132275|p|10||i||
15604|Second Wind|133439|p|10|magic|i||
15609|Hooked Net|132149|t|10||o||
15616|Flame Shock|135813|t|12|magic|o||
15618|Snap Kick|132219|t|2||o||
15621|Skull Crack|135860|t|2||o||
15636|Avatar of Flame|135818|p|10||o||
15642|Ironfoe|135873|p|5||o||
15646|Burst of Knowledge|133282|p|10|magic|i||
15652|Head Smash|132111|t|2||o||
15654|Shadow Word: Pain|136207|t|18|magic|o||
15655|Shield Slam|132357|t|2||o||
15656|Poisonous Stab|136077|t|15|poison|o||
15660|Princess Saved|136235|p|10||o||p
15661|Immolate|135817|t|21|magic|o||
15662|Fireball|135810|t|6||i||
15664|Venom Spit|136016|t|10|poison|o||
15708|Mortal Strike|132355|t|5||o||
15716|Enrage|136224|p|120||o||
15727|Demoralizing Roar|132121|t|30||o||
15728|Plague Cloud|136127|t|240|disease|o||
15730|Curse of Mending|136121|t|180|curse|o||
15732|Immolate|135817|t|21|magic|o||
15735|Arcane Missiles|136096|p|5||o||
15742|Ashcrombe's Teleport|135826|p|3||o||
15744|Blast Wave|135903|t|6||o||
15752|Disarm|132343|t|10||i||
15753|Knockdown|132154|t|2||i||
15779|White Mechanostrider|132247|p|-1||i||
15780|Green Mechanostrider|132247|p|-1||o||
15781|Steel Mechanostrider|132247|p|-1||o||
15784|Frost Armor|135843|a|60|magic|o||
15790|Arcane Missiles|136096|p|5||o||
15798|Moonfire|136096|t|12|magic|o||
15802|Shrink|136121|t|120|curse|o||
15822|Dreamless Sleep|136090|p|12|magic|i||
15848|Festering Rash|136066|t|1800|disease|o||
15850|Chilled|135836|t|5|magic|o||
15852|Dragonbreath Chili|135818|p|600|poison|i||
15859|Dominate Mind|136206|t|5|magic|o||
15860|Impale|132324|t|9||o||
15878|Ice Blast|135840|t|3||o||
15970|Sleep|136090|t|10|magic|o||
15971|Demoralizing Roar|132121|t|30||o||
15976|Puncture|132155|t|10||o||
15981|Rejuvenation|136081|a|12|magic|o||
16001|Impale|132324|t|9||o||
16037|Mind Probe|135736|t|2||o||
16045|Encage|132325|t|30||o||
16046|Blast Wave|135903|t|6||o||
16048|Emberseer Growing|135819|p|60||o||
16049|Emberseer Growing|132154|p|604800||o||
16050|Slowing Ooze|136091|t|10|magic|o||
16051|Barrier of Light|136235|p|2||o||p
16053|Dominion of Soul|136206|p|60||i||
16055|Nightsaber|132225|p|-1||i||
16056|Frostsaber|132267|p|-1||i||
16058|Primal Leopard|132242|p|-1||i||
16059|Tawny Sabercat|132242|p|-1||i||
16060|Golden Sabercat|132242|p|-1||i||
16068|Encage|136121||-1||o||
16071|Curse of the Firebrand|132095|t|300|curse|o||
16075|Throw Axe|132399|t|2||o||
16080|Red Wolf|132224|p|-1||i||
16081|Arctic Wolf|132266|p|-1||i||
16082|Palomino Stallion|132261|p|-1||i||
16083|White Stallion|132261|p|-1||i||
16084|Mottled Red Raptor|132253|p|-1||i||
16094|Frost Breath|135848|t|10||o||
16095|Vicious Rend|132155|t|15||o||
16096|Cowering Roar|132111|t|5||o||
16097|Hex|136071|t|10|magic|o||
16098|Curse of Blood|136189|t|600|curse|o||
16099|Frost Breath|135848|t|10||o||
16104|Crystallize|136222|t|6|magic|o||
16122|Phasing|132320|p|4||o||
16128|Infected Bite|136127|t|180|disease|o||
16143|Cadaver Worms|136134|t|600|disease|o||
16145|Sunder Armor|132363|t|30||o||
16147|Burning Flesh|135817|p|21||o||
16167|Rend Blackhand Mounts|135990|p|-1||o||
16168|Flame Buffet|135807|t|20|magic|o||
16170|Bloodlust|136012|a|30|magic|o||
16172|Head Crack|132325|t|20||o||
16186|Fevered Plague|136066|t|180|disease|o||
16231|Curse of Recklessness|136225|t|120|curse|o||
16244|Demoralizing Shout|132366|t|30||o||
16245|Freeze Anim|136235|p|-1||o||p
16247|Curse of Thorns|136121|t|180|curse|o||
16249|Frostbolt|135846|t|4|magic|o||
16321|Juju Escape|134319|p|10||i||
16322|Juju Flurry|134319|a|20|magic|i||
16323|Juju Power|134313|a|1800|magic|i||
16325|Juju Chill|134311|a|600|magic|i||
16326|Juju Ember|134317|a|600|magic|i||
16327|Juju Guile|134315|a|1800|magic|i||
16329|Juju Might|134309|a|600|magic|i||
16333|Debilitating Touch|136157|t|120|magic|o||
16336|Haunting Phantoms|136123|t|300|curse|o||
16337|Chromatic Chaos|135753||300|magic|o||
16340|Frost Breath|135848|t|10||o||
16345|Disease Cloud|136006|p|-1||o||
16350|Freeze|135852|t|10|magic|o||
16359|Corrosive Acid Breath|136007|t|30||o||
16366|Enlarge|136101|a|60|magic|o||
16373|Chromatic Protection: Fire|134563|a|30||o||
16380|Greater Invisibility|136047|p|-1||o||
16391|Chromatic Protection: Nature|134563|a|30||o||
16392|Chromatic Protection: Frost|134563|a|30||o||
16393|Rend|132155|t|30||o||
16400|Poison|136016|t|15|poison|i||
16401|Poison|136016|t|30|poison|i||
16402|Corruption|136118|t|3|magic|o||
16403|Rend|132155|t|30||i||
16404|Banishment of Scale|136235||10||o||p
16406|Rend|132155|t|30||i||
16412|Fireball|135810|t|6||o||
16413|Fireball|135810|t|7||i||
16415|Fireball|135810|t|8||i||
16420|Crypt Scarab Confuse|136235|p|0.5||o||p
16421|Vaelastrasz Dragon Form|135990|p|-1||o||
16427|Virulent Poison|136016|t|30|poison|o||
16429|Piercing Shadow|136130|t|1800|curse|o||
16430|Soul Tap|136169|t|12|magic|o||
16431|Bone Armor|136225|a|60|magic|o||
16432|Plague Mist|136066|t|8|disease|o||
16448|Black Rot|135935|t|1800|disease|o||
16449|Maggot Slime|136134|t|1800|disease|o||
16451|Judge's Gavel|132507|t|10|magic|o||
16452|Kill Urok Minion|136235||3||o||p
16454|Searing Blast|135807|t|30||i||
16455|Lava|135805||-1||o||
16456|Slime|136006||-1||o||
16458|Ghoul Plague|135914|t|1800|disease|o||
16460|Festering Bites|136067|t|1800|poison|o||
16461|Slime Dysentery|135914|t|1800|disease|o||
16467|Kirtonos Transform|136122|p|-1||o||
16468|Mother's Milk|132104|t|-1|poison|o||
16469|Web Explosion|132149|p|10||o||
16470|Gift of Stone|132154|p|10|magic|i||
16497|Stun Bomb|135826|t|5||o||
16498|Faerie Fire|136033|t|60|magic|o||
16499|Thistle Kinship|136235|a|1800|curse|o||p
16508|Intimidating Roar|132154|t|8||o||
16509|Rend|132155|t|15||o||
16528|Numbing Pain|136016|t|10|poison|i||
16532|Emberseer Object Visual|136130|p|600||o||
16536|Flame Buffet|135807|t|45|magic|o||
16551|Felstriker|132090|p|3||i||
16552|Venom Spit|136016|t|10|poison|o||
16555|Drowning Death|135861|t|300|magic|o||
16557|Destroy Spear|136130|p|10||o||
16560|Flame Wrath|135826|p|15||i||
16561|Regrowth|136085|a|21|magic|o||
16566|Net-o-Matic|132149|p|30||o||
16567|Tainted Mind|136203|t|600|curse|o||
16568|Mind Flay|136208|t|3||o||
16569|Health Funnel|136168|p|10||o||
16573|Putrid Bile|136077|t|45|poison|o||
16577|Disease Cloud|136006|p|-1||o||
16587|Dark Whispers|136163|a|600|magic|o||
16591|Noggenfogger Elixir|136187|p|600|magic|o||
16592|Shadowform|136221|p|-1||o||
16593|Noggenfogger Elixir|135992|p|120|magic|o||
16595|Noggenfogger Elixir|136162|p|600|magic|o||
16597|Curse of Shahram|135994|t|10||o||
16598|Will of Shahram|135934||20|magic|o||
16599|Blessing of Shahram|135928|p|20|magic|o||
16600|Might of Shahram|136116|t|5||o||
16601|Fist of Shahram|132369|p|8|magic|o||
16603|Demonfork|136169|t|5|magic|i||
16608|Drain Life|136169|t|4|magic|i||
16609|Warchief's Blessing|135759|p|3600||o||
16610|Razorhide|136104|a|600||o||
16612|Agamaggan's Strength|136101|a|1800||o||
16617|Lionheart|134966|p|600|magic|o||
16618|Spirit of the Wind|136022|a|300||o||
16621|Self Invulnerability|135915|p|3||i||
16624|Thorium Shield Spike|136235|p|-1||e||p
16627|Capture Felhound Spirit|136163|t|9||i||
16628|Capture Infernal Spirit|136163|t|9||i||
16629|Attuned Dampener|135972||30||i||
16637|Mend Dragon|136168||20||o||
16707|Hex|136071|a|20|magic|o||
16708|Hex|136071|a|20|magic|o||
16709|Hex|136071|a|20|magic|o||
16711|Grow|135871|a|300|magic|o||
16712|Special Brew|135999|a|300||o||
16713|Ghostly|135864|a|60||o||
16714|Smokey|136160|a|60||o||
16716|Launch|135819|a|5||o||
16717|Launch|135819|p|5||o||
16723|Hold Rifle|132222|p|-1||o||
16727|War Stomp|132091|t|5||o||
16739|Orb of Deception|136121|p|300||i||
16789|Rage|136224|p|15||o||
16790|Knockdown|132154|t|2||o||
16791|Furious Anger|136224|p|60||o||
16794|Transformation|132311|p|-1||o||
16798|Enchanting Lullaby|136209|t|10|magic|o||
16799|Frostbolt|135846|t|4|magic|o||
16803|Flash Freeze|135848|t|5|magic|o||
16804|Flame Shock|135813|t|12|magic|o||
16805|Conflagration|135818|t|10||o||
16838|Banshee Shriek|136164|t|5|magic|o||
16843|Crimson Fury|135818|p|4|magic|o||
16856|Mortal Strike|132355|t|5||o||
16866|Venom Spit|136016|t|10|poison|o||
16867|Banshee Curse|136020|t|12|curse|o||
16869|Ice Tomb|135852|t|10||o||
16871|Bleakwood Curse|136160|t|60|curse|i||
16873|Holy Word: Fortitude|135987|p|1800|magic|o||
16874|Shadow Protection|136121|p|600|magic|o||
16881|Water Breathing|136148|p|600|magic|o||
16882|Detect Invisibility|136152|p|600|magic|o||
16883|Elixir of the Giants|134841|p|1200|magic|o||
16884|Health II|134824|p|3600|magic|o||
16885|Agility VIII|134873|p|3600|magic|o||
16887|Armor IV|134866|p|3600||o||
16888|Intellect IX|134721|p|3600|magic|o||
16889|Greater Arcane Elixir|134827|p|1800|magic|o||
16890|Regeneration IV|134859|p|3600||o||
16898|Blaze|135818|t|30|magic|i||
16916|Strength of the Champion|135349|p|30|magic|i||
16927|Chilled|135864|t|5|magic|i||
16928|Armor Shatter|132403|t|45||i||
16939|Ancestor's Vengeance|135131|p|20|magic|i||
17008|Drain Mana|136208|t|5|magic|o||
17011|Freezing Claw|135853|t|5||o||
17013|Agamaggan's Agility|136114|a|1800||o||
17014|Bone Shards|136191|p|10||o||
17038|Winterfall Firewater|134872|p|1200|magic|i||
17052|Decay|136132|p|300||o||
17057|Furor|135881|p|3||o||
17105|Banshee Curse|136020|t|12|curse|o||
17131|Hover|132150|p|-1||o||
17134|Musty Tome Trap|136129|a|60||o||
17136|Onyxia Trans|136235|p|-1||o||p
17139|Power Word: Shield|135940|a|30|magic|o||
17140|Holy Fire|135972|t|8|magic|o||
17141|Holy Fire|135972|t|8|magic|o||
17142|Holy Fire|135972|t|8|magic|o||
17145|Blast Wave|135903|t|6||o||
17146|Shadow Word: Pain|136207|t|18|magic|o||
17148|Brain Hacker|136174|t|30||i||
17150|Arcane Might|135933|a|1800|magic|o||
17151|Shadow Barrier|136121|a|600|magic|o||
17152|Destiny|136101|p|12||i||
17153|Rend|132155|t|15||i||
17154|The Green Tower|136104|p|30|magic|i||
17158|Venom Spit|136016|t|10|poison|o||
17165|Mind Flay|136208|t|3||o||
17168|Haleh's Will|135744|a|10||o||
17170|Fatal Sting|136016|t|12|poison|o||
17172|Hex|136071|t|5|magic|o||
17173|Drain Life|136169|t|5|magic|o||
17174|Concussive Shot|135860|t|3|magic|o||
17175|Resist Arcane|135736|a|3600|magic|o||
17177|Seal of Protection|135964|a|8|magic|o||
17179|Boon of Life|135903||20||i||
17183|Poison|136016|t|15|poison|o||
17186|Ras Becomes a Boy!|136235|p|-1||o||p
17189|Frostwhisper's Lifeblood|136235|p|20||o||p
17196|Seeping Willow|136016|t|10|poison|i||
17197|Maggot Goo|132104|t|6|poison|o||
17205|Winterfall Firewater|134872|p|1200|magic|o||
17207|Whirlwind|132369|p|2||o||
17213|Curse of Vengeance|136138|t|900|curse|o||
17227|Curse of Weakness|136138|t|120|curse|o||
17229|Winterspring Frostsaber|132252|p|-1||i||
17230|Infected Wound|136066|t|300|disease|o||
17232|Devotion Aura|135893|p|240||i||
17238|Drain Life|136169|t|5|magic|o||
17243|Drain Mana|136208|t|5|magic|o||
17244|Possess|136129|t|120||o||
17246|Possessed|136122|a|120||o||
17252|Mark of the Dragon Lord|134153|p|1800||i||
17273|Pyroblast|135808|t|12||o||
17274|Pyroblast|135808|t|12||o||
17275|Heart of the Scale|135817|p|300||i||
17276|Scald|135807|t|4||o||
17277|Blast Wave|135903|t|6||o||
17281|Crusader Strike|135924|t|30|magic|o||
17286|Crusader's Hammer|135963|t|4|magic|o||
17292|Poison|136016|t|30|poison|o||
17293|Burning Winds|136018|t|8|magic|o||
17307|Knockout|132939|t|6||o||
17308|Stun|133477|t|1||i||
17315|Puncture Armor|132109|t|30||i||
17330|Hanging Thread|136113|p|10||i||
17331|Fang of the Crystal Spider|136113|t|10|magic|i||
17333|Spider's Kiss|134321|t|10|magic|s||
17351|Argent Dawn|135893|p|10||i||
17352|Argent Avenger|135990|p|10||i||
17368|Egan's Blaster|135990|a|3||i||
17398|Balnazzar Transform Stun|136191|t|5||o||
17400|Perm. Illusion DeathKnight|132311|p|-1||o||
17405|Domination|136206|t|15||o||
17407|Wound|132155|t|10||i||
17443|Air Bubbles|136148|t|4||o||
17445|Bone Smelt|136187|t|20||o||
17446|The Black Sleep|136143|t|10||o||
17447|Circle of Flame|135824|p|10||i||
17450|Ivory Raptor|132253|p|-1||i||
17453|Green Mechanostrider|132247|p|-1||i||
17454|Unpainted Mechanostrider|132247|p|-1||i||
17455|Purple Mechanostrider|132247|p|-1||i||
17456|Red & Blue Mechanostrider|132247|p|-1||i||
17458|Fluorescent Green Mechanostrider|132247|p|-1||i||
17459|Icy Blue Mechanostrider|132247|p|-1||i||
17460|Frost Ram|132248|p|-1||i||
17461|Black Ram|132248|p|-1||i||
17462|Red Skeletal Horse|132264|p|-1||i||
17463|Blue Skeletal Horse|132264|p|-1||i||
17464|Brown Skeletal Horse|132264|p|-1||i||
17465|Green Skeletal Warhorse|132264|p|-1||i||
17467|Unholy Aura|136225|p|-1||o||
17473|Raise Dead|136187|p|12||o||
17481|Rivendare's Deathcharger|132264|p|-1||i||
17483|Shadow Bolt|136145|t|6||i||
17484|Skullforge Brand|136160|p|10|curse|i||
17492|Hand of Thaurissan|135807|t|5||o||
17494|Slavedriver's Cane|136013|p|30||o||
17499|Surge of Strength|136101|p|20||o||
17500|Malown's Slam|132340|t|2||i||
17503|Frostbolt|135846|t|4|magic|o||
17504|Rend|132155|t|15||i||
17506|Soul Breaker|136163|t|10|magic|i||
17510|Corruption|136118|t|3|magic|i||
17511|Poison|136016|t|20|poison|i||
17528|Mighty Rage|132347|p|20|magic|i||
17533|Perm. Illusion Pig|132311|p|-1||o||
17535|Elixir of the Sages|134809|p|3600||i||
17537|Elixir of Brute Force|134820|p|3600||i||
17538|Elixir of the Mongoose|134812|p|1800||i||
17539|Greater Arcane Elixir|134731|p|3600||i||
17540|Greater Stoneshield|134849|p|120||i||
17543|Fire Protection|135806|p|120|magic|i||
17544|Frost Protection|135843|p|120|magic|i||
17545|Holy Protection|135880|p|120|magic|i||
17546|Nature Protection|136094|p|120|magic|i||
17547|Mortal Strike|132355|t|5||o||
17548|Shadow Protection|136185|p|120|magic|i||
17549|Arcane Protection|135943|p|120|magic|i||
17620|Drain Life|136169|t|5|magic|o||
17623|Visions of the Past|135974|p|-1||i||
17624|Petrification|134806|p|60||i||
17626|Flask of the Titans|134842|p|7200||i||
17627|Distilled Wisdom|134877|p|7200||i||
17628|Supreme Power|134821|p|7200||i||
17629|Chromatic Resistance|134828|p|7200||i||
17633|Arcane Focus|135757|a|30|magic|o||
17639|Wail of the Banshee|136183|t|12|curse|i||
17650|Altered Cauldron Toxin|135903|p|-1||o||
17651|Image Projection|136164|p|6||o||
17670|Argent Dawn Commission|133440|p|-1||i||
17680|Spirit Spawn-out|136235|p|60||o||p
17682|Drain Mana|136208|t|5|magic|o||
17686|Deadly Acid|136007|t|10||o||
17687|Flurry|132152|p|15||o||
17691|Time Out|136222|p|300||o||
17692|Marduk's Curse|136235|t|5|curse|o||p
17695|Defiling Aura|136225|p|-1||o||
17697|Defiling Aura|136163|t|5||o||
17715|Consuming Shadows|136163|p|15||o||
17716|Consuming Shadows|136163|t|1.5|magic|o||
17729|Greater Spellstone|134131|p|60|magic|o||
17730|Major Spellstone|134131|p|60|magic|o||
17734|Fool's Curse|136129|a|3600|magic|o||
17738|Curse of the Plague Rat|136224|t|14|curse|o||
17740|Mana Shield|136153|p|60|magic|o||
17741|Mana Shield|136153|p|60|magic|o||
17743|Peon Sleeping|136235|p|120||o||p
17745|Diseased Spit|136134|t|10|disease|o||
17771|Curse of Agony|136139|t|30|curse|o||
17775|Air Bubbles|136148|t|4||o||
17820|Veil of Shadow|136160|t|15|curse|o||
17831|Call of the Grave|136130|t|60|curse|o||
17883|Immolate|135817|t|21|magic|o||
17961|Scarlet Illusion|135942||1800|magic|o||
17963|Sundering Cleave|132363|t|30||o||
18070|Earthborer Acid|136007|t|30||o||
18075|Rend|132155|t|7||i||
18077|Poison|136016|t|15|poison|i||
18078|Rend|132155|t|30||i||
18082|Fireball|135810|t|6||i||
18088|Corruption|136118|t|3|magic|i||
18099|Chill Nova|135848|t|10|magic|o||
18100|Frost Armor|135843|p|1800|magic|o||
18101|Chilled|135843|t|5|magic|o||
18103|Backhand|132939|t|2||o||
18105|Fireball|135810|t|8||o||
18106|Rend|132155|t|30||o||
18108|Fireball|135810|t|8||o||
18115|Viewing Room Student Transform - Effect|136235|p|-1||o||p
18124|Blessed Sunfruit|134062|p|27||i||
18125|Blessed Sunfruit|135892|p|600||i||
18140|Blessed Sunfruit Juice|132794|p|30||i||
18141|Blessed Sunfruit Juice|135928|p|600||i||
18142|Peasant Transform|136235|p|-1||o||p
18144|Swoop|132338|t|2||o||
18149|Volatile Infection|135914|t|120|disease|o||
18151|Noxious Catalyst|135914|t|120|disease|o||
18159|Curse of the Vengeful Centaur|136224|t|900|curse|o||
18163|Strength of Arko'narin|136010|p|1800||o||
18165|Holy Fire|135972|t|8|magic|o||
18172|Kodo Kombobulator|132488|a|300||o||
18173|Burning Adrenaline|132937|t|20||o||
18191|Increased Stamina|132584|p|600||i||
18192|Increased Agility|132953|p|600||o||
18193|Increased Spirit|134335|p|600||o||
18194|Mana Regeneration|136053|p|600||o||
18197|Poison|136016|t|15|poison|i||
18199|Fireball|135810|t|6||i||
18200|Rend|132155|t|10||i||
18202|Rend|132155|t|14||i||
18203|Poison|136016|t|15|poison|i||
18208|Poison|136016|t|25|poison|i||
18209|Test Grow|136235|a|604800||o||ip
18210|Test Shrink|136235|a|604800||o||ip
18222|Health Regeneration|135917|p|600||o||
18229|Food|134062|p|27||o||
18230|Food|134062|p|27||o||
18231|Food|134062|p|27||o||
18232|Food|134062|p|27||o||
18233|Food|134062|p|27||o||
18234|Food|134062|p|27||o||
18264|Headmaster's Charge|136232|p|900|magic|i||
18266|Curse of Agony|136139|t|15|curse|o||
18267|Curse of Weakness|136138|t|30|curse|o||
18270|Dark Plague|136066|t|90|disease|o||
18278|Silence|135975|t|6|magic|i||
18289|Creeping Mold|135914|t|12|disease|i||
18309|Bear Form|132276|p|-1||o||
18327|Silence|135975|t|10|magic|o||
18328|Incapacitating Shout|132366|t|60||o||
18347|Haunted|136122|a|600||o||
18348|Poltergeist Periodic Schedule (DND)|136235|p|-1||o||ip
18362|Kodo Kombobulator|136235|a|-1||o||p
18363|Riding Kodo|132245|p|-1||i||
18364|Cloak of Fire|135806|p|15||i||
18371|Soul Siphon|136163|p|10|magic|o||
18373|Aynasha's Root|136235|p|-1||o||p
18376|Corruption|136118|t|24|magic|o||
18377|Kodo Kombobulator|136245|p|300||o||
18381|Cripple|136138|t|30|magic|i||
18383|Poltergeist Despawn Schedule (DND)|136235|p|-1||o||ip
18395|Dismounting Shot|136222|t|2||o||
18396|Dismounting Blast|136222|t|0.001||o||
18400|Piccolo of the Flaming Fire|133942|p|-1||i||
18430|Dragon Hover|136235|p|-1||o||p
18443|Safe Fall|136235|p|-1||o||p
18469|Counterspell - Silenced|135856|t|4|magic|o||
18501|Enrage|136224|p|5||o||
18502|Curse of Hakkar|136160|t|120|curse|o||
18503|Hex|135996|t|10|magic|o||
18520|Charisma|135967|p|30|magic|o||
18543|Flame Lash|135817|t|21|magic|o||
18545|Scorpid Sting|132169|t|20|poison|o||
18546|Overdrive|133002|p|6||o||
18557|Drain Life|136169|t|5|magic|o||
18608|First Aid|135915|a|8||i||
18610|First Aid|135915|a|8||i||
18633|Weakening Disease|136118|t|14|disease|i||
18652|Siphon Health|136082|t|5|magic|i||
18654|Siphon Health|136082|t|15||o||
18656|Corruption|136118|t|9|magic|i||
18671|Curse of Agony|136139|t|30|curse|o||
18702|Curse of the Darkmaster|136121|t|60|curse|o||
18733|Air Bubbles|136148|t|5||o||
18747|Blue Dragon Immunity (PT)|136235|p|300||o||p
18763|Freeze|135852|t|15|magic|o||
18765|Sweeping Strikes|132306|p|20||o||
18787|Heaven's Blessing|135906|p|30|magic|i||
18794|Young Tirion|136235|p|-1||o||p
18795|Peon Sleeping (Stun emote)|136235|p|-1||o||p
18796|Fireball|135810|t|6||i||
18798|Freeze|135852|t|5|magic|i||
18800|Light Test|136245|p|-1||o||i
18802|Frost Shot|135989|t|10|magic|o||
18803|Focus|135972|p|4||i||
18810|Taelan's Suffering|136235|p|3600||o||p
18811|Taelan's Suffering Effect|136133|t|2||o||
18812|Knockdown|132154|t|2||o||
18820|Insight|135932|p|12|magic|i||
18826|Savior's Sacrifice|135893|p|20||i||
18828|Bone Armor|136225|p|20|magic|i||
18946|The Lion Horn of Stormwind|134229|p|30||i||
18948|Dark Energy|136203|t|300|curse|o||
18949|Atal'ai Poison|136067|t|30|poison|o||
18953|Ranshalla Waiting|136235|p|-1||o||p
18956|Restore Life|134335|p|30|magic|i||
18957|Restore Life|134335|p|30|magic|i||
18958|Flame Lash|135807|t|45|magic|o||
18968|Fire Shield|135817|a|600|magic|o||
18972|Slow|136091|t|20|magic|o||
18977|Frost|135849|t|10|magic|o||
18989|Gray Kodo|132243|p|-1||i||
18990|Brown Kodo|132245|p|-1||i||
18991|Green Kodo|132244|p|-1||i||
18992|Teal Kodo|132244|p|-1||i||
19030|Bear Form|132276|p|300||o||
19128|Knockdown|132154|t|2||o||
19133|Frost Shock|135849|t|8|magic|o||
19134|Intimidating Shout|132154|t|8||o||
19135|Avatar|132275|p|15||o||
19136|Stormbolt|132325|t|5||o||
19137|Slow|136091|t|20|magic|o||
19185|Entrapment|136100|t|5|magic|o||
19307|Crystal of Zin-Malor|134334|p|-1||i||
19364|Ground Stomp|132368|t|5||o||
19365|Ancient Dread|136140|t|900|magic|o||
19366|Cauterizing Flames|135830|t|900|magic|o||
19367|Withering Heat|135805|t|900|magic|o||
19369|Ancient Despair|136175|t|5|magic|o||
19372|Ancient Hysteria|136224|t|900|curse|o||
19393|Soul Burn|135827|t|16|magic|o||
19397|Incinerate|135813|t|60||o||
19408|Panic|136147|t|8|magic|o||
19428|Conflagration|135818|t|8||o||
19448|Poison|136016|t|30|poison|o||
19450|Magma Spit|135821|t|30||o||
19451|Frenzy|132117|p|8|frenzy|o||
19463|Corrosive Acid Spit|136007|t|10||o||
19469|Poison Mind|136016|t|15|poison|o||
19474|Rain of Fire|136186|p|8||o||
19482|War Stomp|132368|t|2||o||
19496|Magma Shackles|136022|t|15|magic|o||
19514|Lightning Shield|136051|p|600|magic|o||
19516|Enrage|132333|p|1800||o||
19548|Tame Ice Claw Bear|132164|t|20||i||
19595|Shadow and Frost Reflect|135736|a|-1||o||
19597|Tame Ice Claw Bear|132164|t|900||o||
19631|Melt Armor|135817|t|60||o||
19634|Mana Rejuvenation|136077|p|15|magic|i||
19635|Incite Flames|135811|t|60|magic|o||
19636|Fire Blossom|135818|p|6||o||
19638|Prismstone|134139|p|30|magic|i||
19641|Pyroclast Barrage|135808|t|6||o||
19643|Mortal Strike|132355|t|5||o||
19645|Anti-Magic Shield|136120|p|10||o||
19659|Ignite Mana|135818|t|300|magic|o||
19674|Tame Large Crag Boar|132164|t|20||i||
19676|Tame Snow Leopard|132164|t|900||o||
19677|Tame Large Crag Boar|132164|t|900||o||
19678|Tame Adult Plainstrider|132164|t|900||o||
19679|Tame Prairie Stalker|132164|t|900||o||
19680|Tame Swoop|132164|t|900||o||
19681|Tame Dire Mottled Boar|132164|t|900||o||
19682|Tame Surf Crawler|132164|t|900||o||
19683|Tame Armored Scorpid|132164|t|900||o||
19684|Tame Webwood Lurker|132164|t|900||o||
19685|Tame Nightsaber Stalker|132164|t|900||o||
19686|Tame Strigid Screecher|132164|t|900||o||
19687|Tame Snow Leopard|132164|t|20||i||
19688|Tame Adult Plainstrider|132164|t|20||i||
19689|Tame Prairie Stalker|132164|t|20||i||
19690|Scarlet Illusion|135942|p|900|magic|i||
19692|Tame Swoop|132164|t|20||i||
19693|Tame Webwood Lurker|132164|t|20||i||
19694|Tame Dire Mottled Boar|132164|t|20||i||
19695|Inferno|135818|p|8||o||
19696|Tame Surf Crawler|132164|t|20||i||
19697|Tame Armored Scorpid|132164|t|20||i||
19699|Tame Nightsaber Stalker|132164|t|20||i||
19700|Tame Strigid Screecher|132164|t|20||i||
19702|Impending Doom|136179|t|10|magic|o||
19703|Lucifron's Curse|136123|t|300|curse|o||
19705|Well Fed|136000|p|900||i||
19706|Well Fed|136000|p|900||o||
19708|Well Fed|136000|p|900||i||
19709|Well Fed|136000|p|900||i||
19710|Well Fed|136000|p|900||i||
19711|Well Fed|136000|p|900||o||
19713|Shazzrah's Curse|136121|t|300|curse|o||
19714|Deaden Magic|135967|p|30|magic|o||
19716|Gehennas' Curse|136160|t|300|curse|o||
19725|Turn Undead|135983|t|20||o||
19726|Resistance Aura|135865|p|-1||o||
19727|Aquatic Miasma|136184|t|3600|curse|o||
19748|Charismatic Aura|135923|p|-1||o||
19755|Frightalon|136203|t|60|curse|i||
19769|Thorium Grenade|135826|t|3||i||
19770|Gizelton Caravan|135996|p|||o||
19771|Serrated Bite|132155|t|30||o||
19776|Shadow Word: Pain|136207|t|18|magic|o||
19778|Demoralizing Shout|132366|t|30||o||
19779|Inspire|132333|a|10||o||
19780|Hand of Ragnaros|135807|t|2||o||
19784|Dark Iron Bomb|135826|t|4||i||
19812|Frenzy|132117|p|8|frenzy|o||
19820|Mangle|132122|t|20||o||
19821|Arcane Bomb|135975|t|5|magic|i||
19822|Play Dead|136119|p|10||o||
19824|Summon Blackwing Legionnaires|136235|p|-1||o||p
19832|Possess|136222||90||o||
19872|Calm Dragonkin|136046|a|30||o||
19937|Illusion: Black Dragonkin|135942|p|900|magic|i||
19952|Heal Ragnaros|135827||10||o||
19953|Enrage|136224|p|10||o||
20005|Chilled|135864|t|5||e||
20006|Unholy Curse|136138|t|12|magic|e||
20007|Holy Strength|135882|p|15|magic|e||
20019|Engulfing Flames|135818|t|6||o||
20218|Sanctity Aura|135934|p|-1||o||
20223|Magic Reflection|135849|a|10|magic|o||
20228|Pyroblast|135808|t|12||o||
20229|Blast Wave|135903|t|8||o||
20272|Illumination|135913|p|15||o||
20273|Windsor's Inspriation DND|136225|p|-1||o||i
20276|Knockdown|132154|t|2||o||
20277|Fist of Ragnaros|135971|t|4||o||
20294|Immolate|135817|t|21|magic|o||
20297|Frostbolt|135846|t|4|magic|o||
20367|Tag: Purple Cloud|135995|a|-1||o||
20368|Tag: Red Skulls|135819|a|-1||o||
20369|Tag: Purple Ball|136210|a|-1||o||
20370|Tag: Red Glow|135824|a|-1||o||
20371|Tag: Green Glow|136006|a|-1||o||
20372|Tag: Hearts|136209|a|-1||o||
20373|Tag: Sleep|132156|a|-1||o||
20374|Tag: Arrow|132212|a|-1||o||
20376|Reduced Frost Cost|136235|p|-1||o||p
20409|Lady Prestor Transforms DND|136235|p|-1||o||ip
20436|Drunken Pit Crew|136235|p|30||o||p
20475|Living Bomb|132863|t|8||o||
20478|Armageddon|135826|p|8||o||
20481|Garr Armor Debuff|136235|p|1800||o||p
20508|Charge|132337|t|0.001||o||
20510|TEST AVATAR FORM|136235|p|15||o||ip
20512|Creeping Plague|136012|t|20||o||
20514|Ruul Snowhoof Shapechange (DND)|136235|p|-1||o||ip
20540|Ashenvale Outrunner Sneak|132320|p|-1||o||
20541|Fetch!|132165|t|0.1||o||
20542|Static Conduit|136014|t|15||o||
20545|Lightning Shield|136051|p|600|magic|o||
20547|Fun Bomb|132863|a|8||o||
20553|Golemagg's Trust|132164|t|2||o||
20564|Elemental Fire|135814|t|8||o||
20567|Ragnaros Submerge Visual|135830|p|-1||o||
20570|Superheated Flames|135817|p|10||o||
20586|Windreaper|136022|t|10||i||
20587|Ragged John's Neverending Cup|132792|p|125||i||
20590|Ragged John's Neverending Cup|132792|p|600||o||
20604|Dominate Mind|136206|t|15|magic|o||
20619|Magic Reflection|135849|t|10||o||
20620|Aegis of Ragnaros|136121|p|300||o||
20624|Test Mod Water Breathing (PT)|136235|p|3600||o||ip
20629|Corrosive Venom Spit|136016|t|10|poison|o||
20631|Furbolg Medicine Pouch|133644|p|10|magic|i||
20654|Entangling Roots|136100|t|15|magic|o||
20655|Barkskin|136063|a|60|magic|o||
20656|Faerie Fire|136033|t|60|magic|o||
20663|Sleep|136090|t|10|magic|o||
20664|Rejuvenation|136081|a|12|magic|o||
20665|Regrowth|136085|a|21|magic|o||
20667|Corrosive Acid Breath|136007|t|30||o||
20668|Sleepwalk|136152|t|10||o||
20669|Sleep|136090|t|10|magic|o||
20672|Fade|136047|p|3||o||
20683|Highlord's Justice|135963|t|5|magic|o||
20685|Storm Bolt|133038|t|8||o||
20690|Moonfire|136096|t|12||o||
20697|Power Word: Shield|135940|p|30|magic|o||
20699|Entangling Roots|136100|t|15|magic|o||
20701|Rejuvenation|136081|p|12|magic|o||
20706|Power Word: Shield 500|135940|p|30|magic|o||
20707|Soulstone Resurrection|136210|a|1800||i||
20708|Emote State Ready|136235|p|-1||o||p
20716|Sand Breath|135831|t|10||o||
20717|Sand Breath|135831|t|10||o||
20733|Black Arrow|132323|t|60||o||
20740|Dominate Mind|136206|t|15|magic|o||
20743|Drain Life|136169|t|5|magic|o||
20753|Demoralizing Roar|132121|t|30||o||
20762|Soulstone Resurrection|136210|a|1800||i||
20763|Soulstone Resurrection|136210|a|1800||i||
20764|Soulstone Resurrection|136210|a|1800||i||
20765|Soulstone Resurrection|136210|a|1800||i||
20786|Destroy Karang's Banner|136235|p|10||o||p
20787|Immolate|135817|t|21|magic|o||
20792|Frostbolt|135846|t|4|magic|o||
20798|Demon Skin|136185|p|1800|magic|o||
20800|Immolate|135817|t|21|magic|o||
20806|Frostbolt|135846|t|4|magic|o||
20812|Cripple|136135|t|15|magic|o||
20819|Frostbolt|135846|t|4|magic|o||
20822|Frostbolt|135846|t|4|magic|o||
20826|Immolate|135817|t|21|magic|o||
20828|Cone of Cold|135852|t|8|magic|o||
20875|Rumsey Rum|132790|p|900||i||
20936|Spirit of Greater Healing|135913|p|-1||o||
20939|Undying Soul|136235|p|||o||p
20988|Nature's Ally|136095|e|4||o||
20989|Sleep|136090|t|10|magic|o||
21007|Curse of Weakness|136138|t|120|curse|o||
21008|Mocking Blow|132350|t|6||o||
21030|Frost Shock|135849|t|8|magic|o||
21047|Corrosive Acid Spit|136007|t|10||o||
21048|Curse of the Tribes|136138|t|1800|curse|o||
21049|Bloodlust|136012|a|30|magic|o||
21051|Melodious Rapture Visual (DND)|136235|p|-1||o||ip
21055|Crush Armor|132340|t|30||o||
21056|Mark of Kazzak|136121|t|60|curse|o||
21060|Blind|136175|t|10||o||
21062|Putrid Breath|135914|t|30|disease|o||
21063|Twisted Reflection|135741|t|45|magic|o||
21066|Void Bolt|136163|t|10||o||
21067|Poison Bolt|136016|t|10|poison|o||
21068|Corruption|136118|t|24|magic|o||
21069|Larva Goo|132104|t|6|poison|o||
21075|Damage Shield|136121|t|10||o||
21079|Echo of Archimonde|136172|p|-1||i||
21081|Sunder Armor|132363|t|30||o||
21086|Encouragement|136146|t|1800||o||
21087|Immunity|136157|t|1800||o||
21090|Champion|136172||1800||o||
21091|Retributive Smite|135924|p|10||o||
21095|Separation Anxiety|135819|p|5||o||
21098|Chill|135852|t|30|magic|o||
21099|Frost Breath|135848|t|5||o||
21129|Aura of Battle|135968|p|-1||o||
21130|Grip of Command|135962|p|-1||o||
21134|Will of Ragnaros|135826|p|-1|magic|o||
21141|Shadow Bolt|136145|t|30||o||
21149|Egg Nog|134062|p|18||i||
21151|Gutgore Ripper|136197|t|30|curse|i||
21152|Earthshaker|133477|t|3||i||
21153|Bonereaver's Edge|136139|p|10|curse|i||
21157|Dark Channeling|136121|p|-1||o||
21159|Fireball|135810|t|8||i||
21162|Fireball|135810|t|10||i||
21163|Polished Armor|134956|a|1800||o||
21165|Haste|136047|p|10||i||
21167|Snowball|132387|a|1||o||
21171|Ryson's Eye in the Sky|132172|p|120||i||
21172|Grip of Command|135962|p|10||o||
21173|Aerie Gryphon Hover|136235|p|-1||o||p
21174|Aura of Battle|135968|p|10||o||
21188|Stun Bomb Attack|135826|t|2||o||
21190|Aerie Gryphon Speed Buff|135831|p|-1||o||
21227|Fire & Ice Channeling|135753|p|-1||o||
21230|Fireball, Improved DoT|136235|p|-1||o||p
21307|Swell of Souls|136235|p|7200||o||p
21330|Corrupted Fear|136183|t|2|curse|i||
21331|Entangling Roots|136100|t|15|magic|o||
21340|Frenzy|136146|p|600||o||
21353|Mount Speed Buff DND|135831|p|-1||o||i
21369|Frostbolt|135846|t|4|magic|o||
21389|Fire Channeling|135805|p|-1||o||
21391|Syndicate Tracker (MURP) DND|136235||-1||i||ip
21392|Fire Channeling|135805|p|-1||o||
21397|Syndicate Tracker (MURP) DND|135736|p|-1||o||i
21401|Frost Shock|135849|t|8|magic|o||
21403|Ryson's All Seeing Eye|132089||1800||o||
21425|Ryson's Eye in the Sky|132172|p|120||i||
21540|Improved Block Value|136235|p|10||o||p
21546|Ryson's All Seeing Eye|136152|a|900||o||
21547|Spore Cloud|136021|t|5||o||
21556|Control Shredder|133001|p|1800||i||
21566|Control Shredder|133001|p|1800||i||
21653|Vipore Cat Form DND|136235|p|-1||o||ip
21655|Blink|135736|p|1||o||
21669|Moonfire|136096|t|12||o||
21670|Faerie Fire|136033|t|60|magic|o||
21687|Toxic Volley|136016|t|15|poison|o||
21736|Winterax Wisdom|132089|a|7200||o||
21737|Periodic Knock Away|132330|a|-1||o||
21740|Demonic Ally|136225|e|4||s||
21748|Thorn Volley|136063|t|2||o||
21749|Thorn Volley|136063|t|2||o||
21751|Perm. Illusion Skeleton|132311|p|-1||i||
21787|Deadly Poison|136016|t|120|poison|o||
21791|Tranquility|136107|p|10||o||
21793|Twisted Tranquility|136107|t|10||o||
21794|Frostwolf Muzzle DND|136235|p|16||i||ip
21808|Summon Shardlings|136025|p|8||o||
21827|Frostwolf Aura DND|136235|a|600||o||ip
21833|Goblin Dragon Gun|135818|p|8||o||
21835|Gizlock's Dummy Charm Effect|136235|a|-1||o||p
21840|Battlegear of Might|132366|t|6||o||
21847|Snowman|132387|a|6||o||
21848|Snowman|132387|p|-1||i||
21863|Alterac Ram Aura DND|136235|a|600||o||ip
21866|Alterac Ram Collar DND|136235|p|16||i||ip
21869|Repulsive Gaze|132154|t|8||o||
21878|Evasion TEST|136205|p|15||o||i
21887|Warrior's Wrath|132355|p|10||o||
21892|Arcane Protection|135835|a|2||o||
21896|Zaetar's Release (DND)|136100|p|5||o||i
21898|Warlock Terror|136183|t|2|magic|o||
21909|Dust Field|136018|p|8||o||
21916|Celebras Waiting|136235|p|-1||o||p
21920|Frost Power|134856|p|1800||i||
21921|Demonic Ally|136225|e|4||s||
21925|Nature's Ally|136095|e|4||s||
21927|Nature's Ally|136095|e|4||s||
21929|Giantstalker|136063|e|4||o||
21932|Giantstalker|136095|e|4||o||
21936|Reindeer|132387|p|60||o||
21949|Rend|132155|t|7||i||
21952|Poison|136016|t|7|poison|i||
21955|Razorlash Root|134187|p|10||i||
21956|Physical Protection|135893|p|10|magic|i||
21961|Wound|132155|t|30||i||
21970|Mark of the Chosen|133441|p|60|magic|i||
21971|Poison Bolt|136016|t|10|poison|o||
21976|Reactive Fade|135994|p|4|magic|s||
21980|Snowman|132387|p|60||o||
21989|Waiting to Resurrect|135934|a|-1||o||
21990|Tornado|136022|t|4||o||
21992|Thunderfury|136018|t|12|magic|i||
22008|Netherwind Focus|136222|p|10||s||
22009|Greater Heal|135953|a|15|magic|s||
22011|Spirit Heal Channel|135955|p|30||o||
22067|Reflection|136222|p|10|magic|o||
22127|Entangling Roots|136100|t|10|magic|o||
22168|Renew|135953|a|20|magic|o||
22187|Power Word: Shield|135940|a|30|magic|o||
22203|Blue Beam|136208|t|-1||o||
22206|Moonfire|136096|t|12|magic|o||
22247|Suppression Aura|135831|t|6||o||
22272|Arcane Missiles|136096|p|5||o||
22274|Greater Polymorph|136013|t|20|magic|o||
22277|Elemental Shield|136011|p|-1||o||
22278|Elemental Shield|136011|p|-1||o||
22279|Elemental Shield|136011|p|-1||o||
22280|Elemental Shield|136011|p|-1||o||
22281|Elemental Shield|136011|p|-1||o||
22284|Brood Power: Red|135805|t|5||o||
22289|Brood Power: Green|136010|t|6||o||
22290|Brood Power: Blue|136010|t|6||o||
22291|Brood Power: Bronze|136022|t|5||o||
22335|Bottle of Poison|136016|t|30|poison|o||
22356|Slow|136039|t|10|magic|o||
22357|Icebolt|135846|t|2|magic|o||
22371|Curse of Impotence|136020|t|120|curse|o||
22373|Regrowth|136085|a|21|magic|o||
22412|Virulent Poison|136016|t|30|poison|o||
22415|Entangling Roots|136100|t|10|magic|o||
22417|Shadow Shield|136121|p|30|magic|o||
22418|Chaotic Focus|135824|p|1800|magic|o||
22419|Riptide|132343|t|4|magic|o||
22420|Submersion|136148|t|60|magic|o||
22423|Flame Shock|135813|t|12|magic|o||
22424|Blast Wave|135903|t|6||o||
22426|Crush Armor|132340|t|30||o||
22427|Concussion Blow|132325|t|5||o||
22428|Frenzy|132117|a|8|frenzy|o||
22433|Flame Buffet|135807|t|20|magic|o||
22436|Aura of Flames|135805|p|-1||o||
22438|Mark of Detonation|135826|t|30|magic|o||
22440|Commanding Shout|132351|p|0.001||o||
22442|Growing Flames|135805|t|6||o||
22478|Intense Pain|136207|t|15|magic|o||
22479|Frost Breath|135848|t|6||o||
22483|PvP Herald Alpha Transform (DND)|136235|p|-1||o||ip
22519|Ice Nova|135848|t|2|magic|o||
22538|Nef Trans|136235|p|-1||o||p
22558|Brood Power: Red|135805|t|5||o||
22559|Brood Power: Blue|136010|t|6|magic|o||
22561|Brood Power: Green|136010|t|1|magic|o||
22566|Hex|136071|t|8|magic|o||
22567|Summon Ar'lia|136039|p|-1||i||
22572|Bruising Blow|132298|t|5||o||
22582|Frost Shock|135849|t|8|magic|o||
22592|Knockdown|132154|t|2||o||
22639|Eskhandar's Rake|132152|t|5||i||
22640|Eskhandar's Rage|134296|p|6||i||
22642|Brood Power: Bronze|136010|t|6|magic|o||
22643|Frostbolt Volley|135846|t|4|magic|o||
22645|Frost Nova|135848|t|8|magic|o||
22651|Sacrifice|136120|t|8||o||
22660|Dire Wolf Form|136095|p|30||o||
22661|Enervate|132105|t|10|poison|o||
22662|Wither|136066|t|21|disease|o||
22663|Nefarian's Barrier|136120|p|-1||o||
22666|Silence|135975|t|6|magic|o||
22667|Shadow Command|136224|t|15||o||
22678|Fear|136183|t|6|magic|o||
22682|Shadow Flame|135818|t|10||o||
22685|Defense TEST|136235|p|1800||o||ip
22686|Bellowing Roar|136129|t|4||o||
22687|Veil of Shadow|136160|t|6|curse|o||
22688|Tree Form|136095|p|30||o||
22689|Mangle|132122|t|20||o||
22690|Test Charge|136235|p|4||o||ip
22691|Disarm|132343|t|6||o||
22692|Petrify|132154|t|8|magic|o||
22693|Harden Skin|136018|p|10|magic|o||
22695|Regrowth|136085|a|21|magic|o||
22703|Inferno Effect|135860|t|2||o||
22710|Enlarge|136101||30|magic|o||
22713|Flame Buffet|135807|t|20|magic|o||
22717|Black War Steed|132251|p|-1||i||
22718|Black War Kodo|132243|p|-1||i||
22719|Black Battlestrider|132247|p|-1||i||
22720|Black War Ram|132248|p|-1||i||
22721|Black War Raptor|132253|p|-1||i||
22722|Red Skeletal Warhorse|132264|p|-1||i||
22723|Black War Tiger|132225|p|-1||i||
22724|Black War Wolf|132224|p|-1||i||
22730|Increased Intellect|134340|p|600||o||
22731|Food|134062|p|27||o||
22734|Drink|132805|p|30||i||
22735|Spirit of Runn Tum|134011|p|7200||o||
22736|Gordok Ogre Suit|132288|p|600||i||
22739|Goblin Dragon Gun|135818|p|8||o||
22742|Super Shrink Ray|135989|t|20||o||
22744|Chains of Ice|135834|t|10|magic|o||
22746|Cone of Cold|135852|t|8|magic|o||
22751|Fury of the Frostwolf|136087|a|120||o||
22752|Fevered Exhaustion|136106||900||o||
22766|Sneak|132320|p|-1||o||
22789|Gordok Green Grog|132790|p|900||i||
22790|Kreeg's Stout Beatdown|132792|p|900||i||
22799|King of the Gordok|132768|a|-1||o||
22800|Entangling Roots|136100|t|8|magic|o||
22805|r-h|136235|p|-1||o||p
22807|Greater Water Breathing|135859|p|3600||i||
22817|Fengus' Ferocity|136109|a|7200||i||
22818|Mol'dar's Moxie|136054|a|7200||i||
22820|Slip'kik's Savvy|135930|a|7200||i||
22822|Starshards|135753|t|6||o||
22823|Starshards|135753|t|6||o||
22833|Booze Spit|132792|t|10||o||
22835|Drunken Rage|136190|p|60||o||
22850|Sanctuary|135824|p|10|magic|i||
22856|Ice Lock|135834|a|-1||o||
22857|Retaliation|132336|p|15||o||
22859|Mortal Cleave|132355|t|5||o||
22863|Speed|132307|p|10||i||
22884|Psychic Scream|136184|t|4||o||
22888|Rallying Cry of the Dragonslayer|134153|p|7200||o||
22901|Body Switch|136192|a|30||o||
22909|Eye of Immol'thar|136120|t|4||o||
22911|Charge|132337|t|2||o||
22914|Concussive Shot|135860|t|3|magic|o||
22915|Improved Concussive Shot|135860|t|3||o||
22917|Shadowform|136221|p|240||o||
22919|Mind Flay|136208|t|3||o||
22924|Grasping Vines|136025|t|10|magic|o||
22935|Planted|136064||3||o||
22937|Poison Bolt|136016|t|10|poison|o||
22948|Spore Cloud|136021|t|5||o||
22969|Quest - Kodo Fade Out (DND)|136235|p|5||o||ip
22988|Illidan's Fury|136164|p|-1||o||
22992|Shadow Flame|135805|p|11||o||
22994|Entangle|136100|t|10||o||
22997|Plague|136140|t|40||o||
22998|Battle Standard|132483|p|3||o||
23006|Battle Standard|132484|p|3||o||
23009|Tendrils of Air|136022|t|2||o||
23010|Tendrils of Air|136022|p|1||o||
23014|Possess|136222||-1||o||
23015|Crystal Prison|134075|t|18||i||
23016|Lash of Submission|136235||18||o||p
23017|Arcane Channeling|135743|p|-1||o||
23018|Use Dragon Orb|135743||-1||o||
23020|Crystal Imprisonment|134075|p|-1||o||
23021|Dragon Orb|136129|p|-1||o||
23023|Conflagration|135818|t|10||o||
23038|Flame Shock|135813|t|12|magic|o||
23039|Blast Wave|135903|t|6||o||
23055|Defibrillated!|136075|p|2||o||
23060|Battle Squawk|133707|p|240||o||
23072|Seething Plague|136127|p|-1|disease|o||
23097|Fire Reflector|135824|p|5||i||
23101|Eye of Divinity|135933|p|-1||i||
23102|Frostbolt|135846|t|4|magic|o||
23103|Enveloping Winds|136018|t|10|magic|o||
23107|Enter the Light DND|136235|p|-1||o||ip
23108|Blessing of Nordrassil|135972|p|10||o||
23113|Blast Wave|135903|t|6||o||
23115|Frost Shock|135849|t|8|magic|o||
23120|Black March Blessing|136120|p|6||o||
23126|World Enlarger|136121|p|300|magic|i||
23127|Death's Door|136145|p|-1|disease|o||
23128|Frenzy|132117|p|8|frenzy|o||
23131|Frost Reflector|135850|p|5||i||
23132|Shadow Reflector|136121|p|5||i||
23153|Brood Affliction: Blue|134155|t|600|magic|o||
23154|Brood Affliction: Black|134154|t|600|curse|o||
23155|Brood Affliction: Red|134153|t|600|disease|o||
23161|Summon Dreadsteed|132238|p|-1||o||
23162|Harass|132175|t|10||o||
23164|Harass|132175|t|20||o||
23165|Harass|132175|t|30||o||
23169|Brood Affliction: Green|134157|t|600|poison|o||
23170|Brood Affliction: Bronze|134156|t|600||o||
23171|Time Stop|134156|p|4||o||
23174|Chromatic Mutation|136172|t|300||o||
23179|Taint of Shadow|132288|p|1200||i||
23182|Mark of Frost|135834|p|900||o||
23186|Aura of Frost|135835|p|90||o||
23187|Frost Burn|135836|t|15||o||
23188|trans|136235|p|-1||o||p
23189|Frost Burn|135836|t|15||o||
23197|Copy of Visions of the Past|135974|p|-1||o||
23200|Precious Transform to Felhound DND|136235|p|-1||o||ip
23205|Temptress' Kiss|135736|a|45||o||
23207|Silence|135975|p|10|magic|o||
23214|Summon Charger|132226|p|-1||o||
23219|Swift Mistsaber|132225|p|-1||i||
23220|Swift Dawnsaber|132242|p|-1||i||
23221|Swift Frostsaber|132267|p|-1||i||
23222|Swift Yellow Mechanostrider|132247|p|-1||i||
23223|Swift White Mechanostrider|132247|p|-1||i||
23224|Veil of Shadow|136160|t|8|curse|o||
23225|Swift Green Mechanostrider|132247|p|-1||i||
23226|Ritual Candle Aura|135805|t|6||o||
23227|Swift Palomino|132261|p|-1||i||
23228|Swift White Steed|132261|p|-1||i||
23229|Swift Brown Steed|132261|p|-1||i||
23238|Swift Brown Ram|132248|p|-1||i||
23239|Swift Gray Ram|132248|p|-1||i||
23240|Swift White Ram|132248|p|-1||i||
23241|Swift Blue Raptor|132253|p|-1||i||
23242|Swift Olive Raptor|132253|p|-1||i||
23243|Swift Orange Raptor|132253|p|-1||i||
23244|Corrupted Stamina|135914|t|4|disease|o||
23246|Purple Skeletal Warhorse|132264|p|-1||i||
23247|Great White Kodo|132243|p|-1||i||
23248|Great Gray Kodo|132243|p|-1||i||
23249|Great Brown Kodo|132245|p|-1||i||
23250|Swift Brown Wolf|132224|p|-1||i||
23251|Swift Timber Wolf|132266|p|-1||i||
23252|Swift Gray Wolf|132266|p|-1||i||
23257|Demonic Frenzy|136172|p|30|frenzy|o||
23260|Entropic Sting|136014|p|20|poison|o||
23262|Demoralize|132366|t|30||o||
23268|Shadow Word: Pain|136207|t|18|magic|o||
23269|Holy Blast|135903|p|4||o||
23271|Ephemeral Power|135934|p|15||i||
23272|Soul Flame|135818|p|-1||o||
23273|Immune Charm/Fear/Polymorph|135894|p|0.1||i||
23274|Immune Fear/Polymorph/Snare|135894|p|0.1||i||
23275|Dreadful Fright|136122|a|5||o||
23276|Immune Fear/Polymorph/Stun|135894|p|0.1||i||
23277|Immune Charm/Fear/Stun|135894|p|0.1||i||
23279|Crippling Clip|136039|p|30||o||
23298|Demonic Doom|136221|a|45|magic|o||
23299|Stinging Trauma|136067|p|18|poison|o||
23310|Time Lapse|135744|t|8||o||
23312|Time Lapse|135744|t|8||o||
23313|Corrosive Acid|136007|t|15||o||
23314|Corrosive Acid|136007|t|15||o||
23315|Ignite Flesh|135805|t|60||o||
23316|Ignite Flesh|135805|t|60||o||
23327|Trigger Trap|136235|p|-1||o||p
23331|Blast Wave|135903|t|8||o||
23332|trans2|136235|p|-1||o||p
23333|Warsong Flag|132485|a|-1||o||
23335|Silverwing Flag|132486|a|-1||o||
23338|Swift Stormsaber|132225|p|-1||i||
23340|Shadow of Ebonroc|136160|t|8||o||
23341|Flame Buffet|135807|t|20||o||
23342|Frenzy|132117|p|10|frenzy|o||
23355|Feed Pet Effect (Quest Test)|132165|e|20||o||i
23364|Tail Lash|132109|t|2||o||
23365|Dropped Weapon|132343|p|8||o||
23379|Magma Splash|135817|t|30||o||
23380|Moonfire|136096|t|12|magic|o||
23387|Alliance Flag Capture Test|136235|p|1||o||ip
23388|Horde Flag Capture Test|136235|p|2||o||ip
23397|Berserk|136129|t|30||o||
23398|Involuntary Transformation|136129|p|30||o||
23401|Corrupted Healing|136129|t|30||o||
23402|Corrupted Healing|136152|a|30||o||
23409|Soft Landin'|133612|p|-1||i||
23410|Wild Magic|136129|t|30||o||
23411|Fireball|135808|p|8||o||
23412|Frostbolt|135846|p|9||o||
23414|Paralyze|136129|t|30||o||
23415|Improved Blessing of Protection|135964||5||o||
23417|Smother|134343|t|6|magic|o||
23418|Siphon Blessing|136129|t|30||o||
23425|Corrupted Totems|136129|t|30||o||
23427|Summon Infernals|136129|t|0.001||o||
23444|Transporter Malfunction|135899|p|10||o||
23445|Evil Twin|136129|p|7200||o||
23447|Transporter Malfunction|135899|p|5||o||
23449|Transporter Malfunction|135818|p|24||o||
23451|Speed|132870|a|10||o||
23452|Invisibility|132866|a|90||o||
23454|Stun|133477|t|1||i||
23456|Transporter Malfunction|135899|p|10||o||
23457|Transporter Malfunction|135899|p|10||o||
23461|Flame Breath|135805|t|15||o||
23492|Separation Anxiety|135819|p|5||o||
23493|Restoration|134062|a|10||o||
23505|Berserking|136012|a|60||o||
23506|Aura of Protection|135893|p|20|magic|i||
23509|Frostwolf Howler|132266|p|-1||i||
23510|Stormpike Battle Charger|132248|p|-1||i||
23511|Demoralizing Shout|132366|t|15||o||
23513|Essence of the Red|135819|t|180||o||
23537|Enrage|136224|p|600||o||
23547|Parry|132269|p|-1||s||
23552|Lightning Shield|136051|a|600|magic|o||
23567|First Aid|135915|a|8||i||
23568|First Aid|135915|a|8||i||
23569|First Aid|135915|a|8||i||
23577|Expose Weakness|132212|t|7|magic|s||
23580|Bloodfang|136168|p|6||s||
23600|Piercing Howl|136147|t|6||o||
23601|Scatter Shot|132153|t|4||o||
23603|Wild Polymorph|136071|p|20|magic|o||
23605|Spell Vulnerability|135900|t|5||i||
23618|scaler test|135805|t|10|magic|o||i
23619|Burning Adrenaline|132937|p|15||o||
23620|Burning Adrenaline|132937|t|20||o||
23642|Corruption|136208|t|-1||o||
23676|Minigun|134538|p|-1||o||
23684|Aura of the Blue Dragon|134155|p|15||i||
23693|Stormpike's Salvation|136087|a|120||o||
23696|First Aid|135915|a|8||i||
23697|Alterac Spring Water|135928|p|600||i||
23698|Alterac Spring Water|132794|p|30||i||
23719|Untamed Fury|136012|p|8||i||
23720|Blessing of the Black Book|136224|e|30||i||
23721|Arcane Infused|136116|p|10||i||
23723|Mind Quickening|136115|p|20||i||
23724|Metamorphosis Rune|134419|p|20||i||
23726|Venomous Totem|136232|p|20||i||
23733|Blinding Light|135972|p|20||i||
23734|Nature Aligned|136094|p|20||i||
23735|Sayge's Dark Fortune of Strength|134334|a|7200||o||
23736|Sayge's Dark Fortune of Agility|134334|a|7200||o||
23737|Sayge's Dark Fortune of Stamina|134334|a|7200||o||
23738|Sayge's Dark Fortune of Spirit|134334|a|7200||o||
23758|Speak Draconic|136036|p|-1||o||
23759|Master Demonologist|136203|p|-1||o||
23760|Master Demonologist|136203|p|-1||o||
23761|Master Demonologist|136203|p|-1||o||
23762|Master Demonologist|136203|p|-1||o||
23766|Sayge's Dark Fortune of Intelligence|134334|a|7200||o||
23767|Sayge's Dark Fortune of Armor|134334|a|7200||o||
23768|Sayge's Dark Fortune of Damage|134334|a|7200||i||
23769|Sayge's Dark Fortune of Resistance|134334|a|7200||o||
23770|Sayge's Carnie Buff|136232|a|14400||o||
23775|Stun Forever|132310|t|-1|magic|o||
23779|Resurgence DND|136235|p|-1||o||ip
23780|Aegis of Preservation|135880|p|20||i||
23782|Gift of Life|134124|p|20||o||
23790|Stoneclaw Totem Effect TEST|136097|t|3600||o||i
23848|Test Strike W50|132355|t|10||o||i
23849|Venoxis Transform|136077|p|-1||o||
23850|Test Strike W35|132355|t|10||o||i
23860|Holy Fire|135972|t|8|magic|o||
23862|Venom Spit|136016|t|10|poison|o||
23865|Parasitic Serpent|134301|t|10||o||
23895|Renew|135953|a|15|magic|o||
23918|Sonic Burst|136222|t|10|magic|o||
23919|Swoop|132338|t|2||o||
23920|Spell Reflection|132361|p|5||o||
23931|Thunderclap|136105|t|10|magic|o||
23951|Bloodlust|136012|t|15|magic|o||
23952|Shadow Word: Pain|136207|t|18|magic|o||
23953|Mind Flay|136208|t|10||o||
23958|Mind Exhaustion|136222|a|60||o||
23964|Bloodrager's Requiem|135845|a|600||o||
23966|Jeklik Transform|132288|p|-1||o||
23968|Throw Liquid Fire|136235|p|-1||o||p
23973|Root Self|136235|p|-1||o||p
23978|Speed|132870|a|10||o||
23991|Damage Absorb|135893|p|15|magic|i||
24002|Tranquilizing Poison|132105|t|8|poison|o||
24003|Tranquilizing Poison|132105|t|8|poison|o||
24004|Sleep|136090|p|10||o||
24005|Food|134062|p|25||i||
24011|Venom Spit|136016|t|10|poison|o||
24018|Axe Flurry|132397|p|10||o||
24020|Axe Flurry|132397|t|2||o||
24021|Anti-Magic Shield|136120|p|8||o||
24043|Test Fury|132242|p|6||o||i
24048|Whirling Trip|135128|t|2||o||
24049|Impale|132324|t|10||o||
24053|Hex|136071|t|5|magic|o||
24054|Shrink|136121|t|120|curse|o||
24057|Confused|136122|p|2||o||
24065|Toad Explode|136006|p|5||o||
24066|Toad Explode|136006|p|4||o||
24084|Mar'li Transform|136172|p|-1||o||
24086|Growth|136235|p|604800||o||p
24087|Growth|136235|p|20||o||p
24088|Full Grown|136101|p|-1||o||
24089|Full Grown|136101|p|-1||o||
24097|Poison|136016|t|30|poison|o||
24099|Poison Bolt Volley|136016|t|10|poison|o||
24109|Enlarge|136101|a|60|magic|o||
24110|Enveloping Webs|136022|t|8||o||
24111|Corrosive Poison|136016|t|30|poison|o||
24152|Whipweed Roots|136100|t|15|magic|o||
24169|Thekal Transform|132288|p|-1||o||
24170|Whipweed Entangle|136100|t|18||o||
24178|Will of Hakkar|136206|t|20||o||
24185|Bloodlust|136012|a|30|magic|o||
24190|Arlokk Transform|136172|p|-1||o||
24192|Speed Slash|132152|t|6||o||
24193|Charge|132337|t|2||o||
24210|Mark of Arlokk|132212|t|120||o||
24212|Shadow Word: Pain|136207|t|18|magic|o||
24213|Ravage|132152|t|2||o||
24221|Quest - Teleport Spawn-out|136235|p|60||o||p
24223|Vanish|132331|p|10||o||
24225|Exhaustion|136039|p|6||o||
24235|Super Invis|135994|p|-1||o||
24236|Whirlwind|132369|p|2||o||
24238|Test Rip|132152|t|12||o||i
24242|Swift Razzashi Raptor|132253|p|-1||i||
24244|Grow|135871|p|300||o||
24247|Summon Zulian Prowlers|136235|p|-1||o||p
24249|Summon Zulian Stalkers|136235|p|-1||o||p
24252|Swift Zulian Tiger|132242|p|-1||i||
24255|Primal Blessing|132175|p|12||s||
24261|Brain Wash|136120|t|-1||o||
24265|Killer Bees!|136067|p|-1||o||
24268|Mar'li's Brain Boost|135723|p|30||i||
24300|Drain Life|136169|t|7|magic|o||
24306|Delusions of Jin'do|136224|t|20|curse|o||
24310|Powerful Healing Ward|136222|p|-1||o||
24312|Level Up|135926|p|604800||o||
24313|Shade Visual|136123|p|-1||o||
24314|Threatening Gaze|136129|t|6||o||
24317|Sunder Armor|132363|t|20||o||
24318|Enrage|136224|p|90||o||
24321|Poisonous Blood|136077|p|90|poison|o||
24322|Blood Siphon|136168|p|8||o||
24323|Blood Siphon|136006|p|8||o||
24324|Blood Siphon|136168|p|8||o||
24327|Cause Insanity|136206|t|10||o||
24328|Corrupted Blood|136133|t|10||o||
24331|Rake|132122|t|9||o||
24332|Rake|132122|t|9||o||
24333|Ravage|132152|t|2||o||
24335|Wyvern Sting|135125|t|12|poison|o||
24336|Wyvern Sting|135125|t|12|poison|o||
24339|Infected Bite|136127|t|180|disease|o||
24345|Bloodlord's Aura|136235|t|5||o||p
24346|Copy of Master Angler|132288|p|-1||o||
24347|Hook of the Master Angler|133890|p|-1||i||
24348|Cheetah Sprint|132185|p|4||o||
24352|Devilsaur Glare|136243|p|10||i||
24353|Devilsaur Tooth|133724|p|30||i||
24355|Drink|132794|p|30||i||
24360|Greater Dreamless Sleep|136090|p|12|magic|i||
24361|Major Troll's Blood Elixir|134862|p|3600||i||
24363|Mana Regeneration|134762|p|3600||i||
24364|Living Free Action|134718|p|5|magic|i||
24375|War Stomp|132091|t|5||o||
24378|Berserking|136012|a|60||o||
24379|Restoration|134062|a|10||o||
24382|Spirit of Zanza|134810|p|7200||i||
24383|Swiftness of Zanza|134811|p|7200||i||
24388|Brain Damage|132155|t|30||o||
24389|Chaos Fire|134085|p|60|magic|i||
24402|Deafened|132182|p|||o||
24408|Charge|132337|t|2||o||
24412|First Aid|135915|a|8||i||
24413|First Aid|135915|a|8||i||
24414|First Aid|135915|a|8||i||
24415|Slow|136091|t|20|magic|o||
24417|Sheen of Zanza|134809|p|7200||i||
24425|Spirit of Zandalar|132107|p|7200||o||
24427|Diamond Flask|132788|p|60|magic|o||
24435|Drain Life|136169|a|5|magic|o||
24438|Battle Shout|132333|p|20||o||
24498|Brilliant Light|135934|p|15||i||
24499|Energized Shield|136014|p|20||i||
24529|Spirit Bond|132121|p|-1||o||
24542|Nimble Healing Touch|136077|p|15||i||
24543|Massive Destruction|135831|p|20||i||
24544|Arcane Potency|135753|p|20||i||
24546|Rapid Healing|135917|p|15||i||
24573|Mortal Strike|132355|t|5||o||
24574|Brittle Armor|136235|p|20||i||p
24575|Brittle Armor|136162|p|20||o||
24576|Chromatic Mount|134154|p|-1||i||
24594|Mesmerize|136235|p|7||o||p
24596|Intoxicating Venom|132103|t|120||o||
24600|Web Spin|136022|t|7||o||
24610|Pagle's Broken Reel|135865|p|15||i||
24611|Fireball|135812|t|9||o||
24614|Consuming Shadows|136163|p|15||o||
24615|Consuming Shadows|136163|t|1.5|magic|o||
24617|Blood Funnel|136168|a|10||o||
24618|Drain Life|136169|t|5|magic|o||
24619|Soul Tap|136169|t|12||o||
24646|Avatar|132097|p|15||o||
24647|Stun|136222|p|2||o||
24648|Entangling Roots|136100|t|10|magic|o||
24653|TEST 100 STR DND|136235|p|-1||o||ip
24658|Unstable Power|136235|p|20||i||p
24659|Unstable Power|135990|p|20||o||
24661|Restless Strength|136235|p|20||i||p
24662|Restless Strength|132109|p|20||o||
24664|Sleep|136090|t|6||o||
24671|Snap Kick|132219|t|2||o||
24672|Unholy Frenzy|136012|a|20|magic|o||
24673|Curse of Blood|136189|t|600|curse|o||
24674|Veil of Shadow|136160|t|10|curse|o||
24686|Aspect of Mar'li|132318|t|6||o||
24687|Aspect of Jeklik|136222|t|5|magic|o||
24688|Aspect of Venoxis|136016|t|10|poison|o||
24689|Aspect of Thekal|132117|p|8|frenzy|o||
24690|Aspect of Arlokk|132331|t|2||o||
24692|Hakkar Power|136235|p|604800||o||p
24698|Gouge|132155|t|4||o||
24699|Vanish|132331|p|20||o||
24700|Vanish|135743|a|2||o||
24701|Burning Adrenaline|132937|p|15||o||
24705|Invocation of the Wickerman|135462|a|7200||o||
24707|Food|133984|p|25||i||
24708|Pirate Costume|132288|a|3600||o||
24709|Pirate Costume|132288|a|3600||o||
24710|Ninja Costume|132219|a|3600||o||
24711|Ninja Costume|132219|a|3600||o||
24712|Leper Gnome Costume|134164|a|3600||o||
24713|Leper Gnome Costume|134165|a|3600||o||
24716|Happy Pet|132161|p|3||o||
24721|Buru Transform|136129|p|-1||o||
24723|Skeleton Costume|132288|a|3600||i||
24725|Debilitate|132274|t|15|poison|o||
24732|Bat Costume|132288|a|3600||i||
24735|Ghost Costume|136163|a|3600||o||
24736|Ghost Costume|136163|a|3600||o||
24740|Wisp Costume|132288|a|3600||i||
24742|Magic Wings|135992|a|18||o||
24743|Cannon Prep|136235|a|5||o||p
24745|Summon Templar, Trigger|136235|a|1||o||p
24747|Summon Templar Fire, Trigger|136235|a|1||o||p
24753|Trick|132118|a|45||o||
24754|Cannon Prep|136235|a|6||o||p
24755|Tricked or Treated|134015|a|3600||o||
24757|Summon Templar Air, Trigger|136235|a|1||o||p
24759|Summon Templar Earth, Trigger|136235|a|1||o||p
24761|Summon Templar Water, Trigger|136235|a|1||o||p
24762|Summon Duke,Trigger|136235|a|1||o||p
24766|Summon Duke Fire, Trigger|136235|a|1||o||p
24769|Summon Duke Air, Trigger|136235|a|1||o||p
24771|Summon Duke Earth, Trigger|136235|a|1||o||p
24773|Summon Duke Water, Trigger|136235|a|1||o||p
24776|Summon Player|136235|a|0.001||o||p
24778|Sleep|136090|t|5||o||
24783|Copy of Summon Duke|136235|p|4||o||p
24785|Summon Royal, Trigger|136235|a|1||o||p
24787|Summon Royal Fire, Trigger|136235|a|1||o||p
24791|Summon Royal Air, Trigger|136235|a|1||o||p
24792|Summon Royal Earth, Trigger|136235|a|1||o||p
24793|Summon Royal Water, Trigger|136235|a|1||o||p
24799|Well Fed|136000|p|900||o||
24800|Food|134062|p|30||o||
24803|Abyssal Punishment|136235|a|4||o||p
24809|Spirit Shade Visual|136123|p|-1||o||
24811|Draw Spirit|136219|t|5||o||
24818|Noxious Breath|136169|t|30||o||
24826|Infernal Fire|135818|t|-1||o||
24828|Shatter Soul Gem|134076|p|3||i||
24832|Cannon Prep|136235|a|5||o||p
24833|Holy Mightstone|135871|p|600||i||
24834|Shadow Bolt Whirl|136197|p|-1||o||
24839|Acid Breath|136007|t|45||o||
24869|Food|134062|p|24||i||
24870|Well Fed|136000|p|900||o||
24871|Spore Cloud|136021|t|5||o||
24884|Earthen Sigil|136057|p|10|magic|i||
24893|Black Sapphire|134072|p|11||o||
24906|Emeriss Aura|136235|t|10||o||p
24910|Corruption of the Earth|132095|t|10||o||
24918|Stink Trap|136006|t|120||o||
24919|Nauseous|136006|p|5||o||
24920|Flag Guard|136235|a|2||o||p
24924|Hallow's End Candy|134015|p|1200|magic|o||
24925|Hallow's End Candy|132094|p|1200|magic|o||
24926|Hallow's End Candy|133148|p|1200|magic|o||
24927|Hallow's End Candy|136184|p|1200|magic|o||
24928|Volatile Infection|135914|t|120|disease|o||
24931|100 Health|136235|p|-1||o||p
24935|Summon RC Tank|136235|a|300||o||p
24937|Using Control Console|132995|p|300||o||
24942|Frostbolt|135846|t|4|magic|o||
24957|Moonfire|136096|t|12|magic|o||
24959|500 Health|136235|p|-1||o||p
24992|Demonic Transformation|136218|p|15||o||
24998|Healing of the Ages|136042|p|15||i||
24999|Malfurion's Shade|136123|p|-1||o||
25006|Summon RC Blimp|136235|a|300||o||p
25020|Lightning Shield|136051|p|600|magic|o||
25022|Hallow's End Fright|135842|t|6|magic|o||
25026|Activate MG Turret|135619|p|-1||o||
25027|Flamethrower|134535|p|-1||o||
25029|Flamethrower|135818||2||o||
25037|Rumsey Rum Light|132795|p|900||i||
25040|Mark of Nature|136094|p|900||o||
25043|Aura of Nature|136094|p|90||o||
25049|Blast Wave|135903|t|6||o||
25050|Mark of Flames|135807|t|120|magic|o||
25051|Sunder Armor|132363|t|20||o||
25053|Venom Spit|136016|t|30|poison|o||
25056|Stomp|132091|t|2||o||
25057|Dropped Weapon|132343|p|10||o||
25058|Renew|135953|a|15|magic|o||
25059|Dmg Shield|136104|p|-1||o||
25098|Transform Hero|136235|p|8||o||p
25102|Water Mastery|136057|p|60||o||
25105|Green Dragon Transform DND|136235|p|-1||o||ip
25106|Red Dragon Transform DND|136235|p|-1||o||ip
25107|Blue Dragon Transform DND|136235|p|-1||o||ip
25108|Bronze Dragon Transform DND|136235|p|-1||o||ip
25148|Sleep Visual DND|132156|p|-1||o||i
25152|Agro Drones|136235|p|-1||o||p
25160|Sand Storm|136022|p|-1||o||
25161|Harsh Winds|136022|t|1||o||
25164|Vengeance|136224|p|30|magic|o||
25168|Frost Tomb|136235|p|-1||o||p
25169|Fiery Justice|136235|p|-1||o||p
25171|Time Stop Visual DND|136235|p|-1||o||ip
25172|Merithra's Wake Visual DND|136235|p|-1||o||ip
25174|Sundering Cleave|132363|t|30||o||
25176|Strength of Ossirian|136140|p|-1||o||
25177|Fire Weakness|134396|t|45||o||
25178|Frost Weakness|134398|t|45||o||
25180|Nature Weakness|134397|t|45||o||
25181|Arcane Weakness|134395|t|45||o||
25183|Shadow Weakness|134399|t|45||o||
25185|Itch|136064|t|8||o||
25187|Hive'Zara Catalyst|132104|t|30|poison|o||
25189|Enveloping Winds|136018|t|10||o||
25195|Curse of Tongues|136140|t|15|curse|o||
25199|Frog Self (TEST)|136203|p|1800||o||i
25247|Longsight|132327|p|-1||i||
25260|Wings of Despair|136184|t|6||o||
25262|Abomination Spit|136016|t|10|poison|o||
25282|Shield of Rajaxx|135964|a|6||o||
25348|Copy of Deadly Poison IV|132290|t|12|poison|o||
25349|Deadly Poison V|132290|t|12|poison|e||
25371|Consume|136020|t|15||o||
25374|Consume|136020|p|15||o||
25410|Consume|136020|p|15||o||
25424|Poison Bolt|136016|t|10|poison|o||
25425|Shockwave|136105|t|2||o||
25462|Enlarge|136101|a|60|magic|o||
25471|Attack Order|132212|t|10||o||
25473|Attack Order|136235|t|10||o||p
25495|Firework Effect, Lunar Festival Minion|136168|p|8||o||
25497|Venom Spit|136016|t|8|poison|o||
25515|Bash|132340|t|5||o||
25516|Aura of Command|132484|p|30||o||
25565|ClearAll|136235|p|0.1||o||p
25605|Poison|136016|t|15|poison|o||
25645|Poison|136016|t|30|poison|o||
25646|Mortal Wound|132109|t|15||o||
25651|Flame Buffet|135807|t|20|magic|o||
25654|Tail Lash|132109|t|2||o||
25655|Dropped Weapon|132343|p|8||o||
25656|Sand Trap|133849|t|20||o||
25660|Food|134062|p|30||i||
25661|Increased Stamina|132584|p|900||i||
25668|Flame Buffet|135807|t|20|magic|o||
25675|Reindeer|134400|p|-1||o||
25678|Siren's Song|132322||180||o||
25685|Energize|136018|p|604800||o||
25688|Narain!|134164|p|1800||i||
25694|Well Fed|136000|p|900||o||
25695|Food|134062|p|30||i||
25696|Drink|132794|p|30||i||
25697|Old Enriched Manna Biscuit|134062|p|30||o||
25698|Explode|135826|p|7||o||
25700|Food|133906|p|21||i||
25701|Brain Food|133906|p|21||i||
25702|Food|133906|p|21||o||
25703|Brain Food|133906|p|21||o||
25722|Rumsey Rum Dark|132791|p|900||i||
25725|Paralyze|132107|t|10||o||
25746|Damage Absorb|135893|p|15|magic|i||
25747|Damage Absorb|135893|p|15|magic|i||
25748|Poison Stinger|134324|t|10||o||
25750|Damage Absorb|135893|p|15|magic|i||
25751|Copy of Judgement of Light|135917|t|30|magic|o||
25756|Purge|136039|t|2||o||
25768|Mystical Disjunction|135990|p|8||i||
25772|Mental Domination|136172|t|120||o||
25773|Will of Weavil|135727|p|120||o||
25774|Mind Shatter|136025|t|3|magic|o||
25790|Vengeance|136224|t|600||o||
25794|Ahn'Qiraj Reward Buff (Melee - 20)|134969|p|3600||o||
25795|Ahn'Qiraj Reward Buff (Melee - 40)|134969|p|3600||o||
25796|Ahn'Qiraj Reward Buff (Melee - 60)|134969|p|3600||o||
25797|Ahn'Qiraj Reward Buff (Caster - 20)|134969|p|3600||o||
25798|Ahn'Qiraj Reward Buff (Caster - 40)|134969|p|3600||o||
25799|Ahn'Qiraj Reward Buff (Caster - 60)|134969|p|3600||o||
25801|Frenzy Aura|135906|p|-1||o||
25804|Rumsey Rum Black Label|132791|p|900||i||
25805|Soul Corruption|136159|t|15||o||
25806|Creature of Nightmare|136206|t|30||o||
25809|Crippling Poison|132274|t|12|poison|o||
25810|Mind-numbing Poison|136066|t|12|poison|o||
25811|Poison Bolt|136016|t|10|poison|o||
25812|Toxic Volley|136016|t|16|poison|o||
25815|Frightening Shriek|136184|t|6||o||
25816|Hex of Weakness|136157|t|120|curse|o||
25817|Tranquility|136107|p|10||o||
25818|Aura of Rot|136064|p|-1||o||
25821|Charge|132337|t|2||o||
25824|Spotlight|135926|p|604800||o||
25838|Smothering Sands|136235|a|20||o||p
25839|Mass Healing|135913|p|12||o||
25846|Eranikus Night Elf DND|136235|p|-1||o||ip
25848|Test Enemy Crit Bonus - 10%|136101|t|-1||o||i
25851|Lightheaded|132792|p|30||i||
25852|Lash|132109|t|2||o||
25858|Reindeer|133749|p|-1||o||
25859|Reindeer|133749|p|-1||o||
25863|Summon Black Qiraji Battle Tank|134399|p|-1||o||
25864|Will Drain Festive Mug|136235|p|1||o||p
25886|Food|133907|p|21||i||
25887|Brain Food|133907|p|21||i||
25888|Food|133907|p|21||o||
25889|Brain Food|133907|p|21||o||
25891|Earthstrike|136006|p|20||i||
25893|Viscidus Shrinks|136006|p|604800||o||
25900|Stun Self|136235|p|-1||o||p
25905|Invis Self|136235|p|-1||o||p
25907|Spell Blasting|135990|p|10||i||
25926|Viscidus Frost Weakness|136006|p|-1||o||
25937|Viscidus Freeze|135840|p|15||o||
25941|Well Fed|136000|p|900||o||
25947|Infatuation|135975|a|1800||o||
25953|Summon Blue Qiraji Battle Tank|134398|p|-1||i||
25990|Graccu's Mince Meat Fruitcake|132934|p|20||i||
25991|Poison Bolt Volley|136016|t|10|poison|o||
26000|Snowball Cloud|136235|p|-1||o||p
26004|Mistletoe|136041|a|1800||i||
26008|Toast|134376|a|1800||i||
26009|Rotate 360|136235|p|300||o||p
26013|Deserter|132118|a|900||o||
26014|In Battleground|132091|a|-1||o||
26015|Ended Battleground|132091|a|1||o||
26025|Impale|132155|t|8||o||
26030|Windblossom Berries|134062|p|27||i||
26034|Viscidus Slowed|136006|p|-1||o||
26035|Celebrate Good Times!|136101|a|1800||o||
26036|Viscidus Slowed More|136006|p|-1||o||
26038|Whirlwind|132369|p|8||o||
26041|Frenzy|132117|p|10|frenzy|o||
26042|Psychic Scream|136184|t|4||o||
26043|Battle Shout|132333|p|30||o||
26044|Mind Flay|136208|t|8||o||
26049|Mana Burn|136170|t|8||o||
26050|Acid Spit|136016|t|30||o||
26051|Frenzy|132117|p|8|frenzy|o||
26053|Noxious Poison|136016|t|8||o||
26054|Summon Red Qiraji Battle Tank|134396|p|-1||i||
26055|Summon Yellow Qiraji Battle Tank|134395|p|-1||i||
26056|Summon Green Qiraji Battle Tank|134397|p|-1||i||
26061|Summon Ouro|136235|p|-1||o||p
26063|Ouro Submerge Visual|135830|p|-1||o||
26068|Berserk|132117|p|3600||o||
26069|Silence|135975|t|10|magic|o||
26070|Fear|136183|t|8|magic|o||
26071|Entangling Roots|136100|t|15|magic|o||
26072|Dust Cloud|132156|t|12|magic|o||
26077|Itch|136064|t|8||o||
26078|Vekniss Catalyst|132104|t|30|poison|o||
26079|Cause Insanity|136206|t|10||o||
26083|Whirlwind|132369|p|15||o||
26092|Dirt Mound Passive|136235|p|-1||o||p
26099|Battle Shout|132333|p|30||o||
26102|Sand Blast|136018||5||o||
26108|Glimpse of Madness|136175|t|3|magic|i||
26115|Bruiser Sleeping|136235|p|-1||o||p
26121|Stormcaller's Wrath|136096|p|8|magic|s||
26129|Enigma's Answer|136011|p|20|magic|s||
26132|Enigma's Solitude|135845|p|8|magic|o||
26136|Rotate -360|136235|p|300||o||p
26141|Hamstring|132316|t|10||o||
26143|Mind Flay|136208|t|10||o||
26152|Summon Eye Tentacles|136235|p|-1||o||p
26156|Carapace of C'Thun|136235|p|-1||o||p
26157|PX-238 Winter Wondervolt|135849|p|1800||o||
26166|Obsidian Insight|133573|p|30||i||
26168|Chitinous Spikes|133571|p|30||i||
26180|Wyvern Sting|135125|t|12|poison|o||
26195|Whisperings of C'Thun|136206|t|20||o||
26196|Consume|136020|t|15||o||
26197|Whisperings of C'Thun|136206|t|20||o||
26198|Whisperings of C'Thun|136206|t|30||o||
26199|Darkmaster Gandling Christmas Disguise|135849|a|1800||o||
26200|Christmas Darkmaster Gandling|135849|p|-1||o||
26209|Christmas Cannon Master Willey|135849|p|-1||o||
26210|Christmas Prince Tortheldrin|135849|p|-1||o||
26211|Hamstring|132316|t|10||o||
26212|Christmas Emperor Dagran Thaurissan|135849|p|-1||o||
26213|Summon Giant Hook Tentacles|136235|p|-1||o||p
26214|Christmas Warchief Rend Blackhand|135849|p|-1||o||
26215|Christmas War Master Voone|135849|p|-1||o||
26218|Mistletoe|133749|a|3600||o||
26222|Super Invis|135994|p|1.5||o||
26226|Widow Bite|132196|t|4||o||
26231|Christmas Goraluk Anvilcrack|135849|p|-1||o||
26232|Transform C'Thun -> Phase 2|136235|p|-1||o||p
26234|Submerge Visual|135830|p|-1||o||
26235|Cthun Vulnerable|136235||45||o||p
26236|Summon Mouth Tentacles|136235|p|-1||o||p
26239|Winter Reveler - Human Male|135849|p|-1||o||
26240|Winter Reveler - Human Female|135849|p|-1||o||
26241|Winter Reveler - Dwarf Male|135849|p|-1||o||
26242|Winter Reveler - Dwarf Female|135849|p|-1||o||
26243|Winter Reveler - Goblin Female|135849|p|-1||o||
26244|Winter Reveler - Goblin Male|135849|p|-1||o||
26245|Winter Reveler - Night Elf Female|135849|p|-1||o||
26246|Winter Reveler - Night Elf Male|135849|p|-1||o||
26247|Winter Reveler - Orc Female|135849|p|-1||o||
26248|Winter Reveler - Orc Male|135849|p|-1||o||
26249|Winter Reveler - Tauren Female|135849|p|-1||o||
26250|Winter Reveler - Tauren Male|135849|p|-1||o||
26251|Winter Reveler - Troll Female|135849|p|-1||o||
26252|Winter Reveler - Troll Male|135849|p|-1||o||
26253|Winter Reveler - Undead Female|135849|p|-1||o||
26254|.Winter Reveler - Undead Male|135849|p|-1||o||
26255|Check Reset|136235|p|-1||o||p
26258|Whisperings of C'Thun|136206|t|20||o||
26259|Whisperings of C'Thun|136206|t|12||o||
26260|Food|134062|p|30||i||
26261|Drink|132794|p|30||i||
26263|Dim Sum|134056|p|25||i||
26272|PX-238 Winter Wondervolt|135849|p|1800||o||
26273|PX-238 Winter Wondervolt|135849|p|1800||o||
26274|PX-238 Winter Wondervolt|135849|p|1800||o||
26276|Greater Firepower|134842|p|1800||o||
26331|Vengeance|136224|p|20|magic|o||
26332|Summon Mouth Tentacle|136235|p|3.8||o||p
26379|Piercing Shriek|136147|t|6||o||
26381|Burrow|132331|p|10||o||
26382|Burrow|135743|a|3||o||
26383|Night Elf Harbinger|135849|p|-1||o||
26384|Night Elf Lunar Festival Vendor|135849|p|-1||o||
26386|Copy of Moonfire|136096|t|12|magic|o||
26387|Copy of Hallow's End Candy|134015|p|1200|magic|o||
26393|Elune's Blessing|134121|t|3600||o||
26397|Summon Hook Tentacles|136235|p|-1||o||p
26400|Arcane Shroud|135994|p|20|magic|i||
26401|Food|134062|p|30||i||
26402|Drink|132794|p|30||i||
26419|Acid Spray|136007|t|10||o||
26462|Festival Fortune!|136101|t|1800||o||
26463|Mercurial Shield|136235|p|60||i||p
26464|Mercurial Shield|136162|p|60||o||
26467|Persistent Shield|133575|p|30||i||
26470|Persistent Shield|136094|a|8|magic|o||
26472|Food|134062|p|30||i||
26473|Drink|132794|p|30||i||
26474|Food|134062|p|30||i||
26475|Drink|132794|p|30||i||
26476|Digestive Acid|132099|a|-1||o||
26480|Badge of the Swarmguard|133573|p|30||i||
26481|Insight of the Qiraji|134899|p|-1||i||
26489|Entering Battleground|132091|p|-1||o||
26520|Night Elf Lunar Festival Emissary|135849|p|-1||o||
26522|Lunar Fortune|134280|t|1800||o||
26527|Enrage|136224|p|120||o||
26542|Sprint|136235|p|10||o||p
26543|Sprint|136235|p|-1||o||p
26548|Impale|132324|t|8||o||
26552|Nullify|136039|t|8||o||
26556|Plague|136140|t|40||o||
26580|Fear|136183|t|8|magic|o||
26601|Poison Bolt|136016|t|10|poison|o||
26613|Unbalancing Strike|132340|t|6||o||
26615|Berserk|132117|p|3600||o||
26619|Summon Ouro Scarabs Periodic|136235|p|45||o||p
26633|Glob Speed|136235|p|-1||o||p
26634|Glob Speed|136235|p|604800||o||p
26641|Aura of Fear|136163|t|3|magic|o||
26642|Summon Ouro|136235|p|-1||o||p
26652|Copy of Mortal Strike|132355|t|10||o||
26655|Summon Black Qiraji Battle Tank|134399|p|-1||o||
26662|Berserk|136224|p|300||o||
26664|The Power of Friendship|133345|p|3600||o||
26666|Dmg Shield2|136104|p|-1||o||
26680|Adored|135450|p|3600||o||
26681|Cologne|135446|p|3600||i||
26682|Perfume|135447|p|3600||i||
26740|Gnomish Mind Control Cap|135995|t|20||o||
26766|Summon Giant Eye Tentacles|136235|p|-1||o||p
26769|Summon Eye Tentacles|136235|p|-1||o||p
26787|Nullify|136039|a|0.001||o||
26802|Detect Amore|133884|p|3600||o||
26869|Amorous|135453|p|-1||o||
26898|Heartbroken|135767|p|3600||o||
26977|Curse of the Elemental Lord|135819|t|60|curse|o||
27177|Defile|136160|t|10||o||
27183|Defile|136160|p|300||o||
27192|Defile|136160|p|300||o||
27193|Defile|136160|p|300||o||
27194|Defile|136160|p|300||o||
27195|Defile|136160|p|300||o||
27196|Defile|136160|p|300||o||
27197|Defile|136160|p|300||o||
27198|Defile|136160|p|300||o||
27199|Defile|136160|p|300||o||
27200|Defile|136160|p|300||o||
27204|QADebug Instant Cast|132369|p|-1|magic|o||i
27382|Shadow Bolt Volley|136197|p|-1||o||
27420|Ectoplasmic Distiller|135990|p|3||o||
27499|Crusader's Wrath|136039|p|10|magic|s||
27532|Rejuvenation|136081|a|12|magic|o||
27533|Fire Resistance|135806|p|6|magic|o||
27534|Frost Resistance|135843|p|6|magic|o||
27535|Shadow Resistance|136185|p|6|magic|o||
27536|Holy Resistance|135880|p|6|magic|o||
27538|Nature Resistance|136051|p|6|magic|o||
27540|Arcane Resistance|135998|p|6|magic|o||
27543|Bear Form|132276|p|10||o||
27545|Cat Form|132276|p|10||o||
27546|Faerie Dragon Form|136036|p|-1||o||
27551|Demoralizing Roar|132121|t|30||o||
27553|Maul|132136|t|2||o||
27555|Shred|132122|t|10||o||
27556|Rake|132122|t|15||o||
27559|Silence|135975|t|3|magic|i||
27564|Reflection|136222|p|5|magic|o||
27565|Banish|136135|t|10|magic|o||
27568|Picnic Blanket Effect|135926|p|604800||o||
27569|Flower Shower|135926|p|604800||o||
27571|Cascade of Roses|133851|a|120||i||
27572|Smitten|132382|a|3600||o||
27573|Picnic Feast|136235|a|-1||o||p
27575|Picnic Feast Channel|134062|p|600||o||
27579|Demoralizing Shout|132366|t|30||o||
27580|Mortal Strike|132355|t|10||o||
27581|Disarm|132343|t|10||o||
27582|Dirk's Rememberin' Poison|136116|t|30||o||
27584|Hamstring|132316|t|15||o||
27603|Goblin Dragon Gun|135818|p|8||o||
27605|Shadow Word: Pain|136207|t|18|magic|o||
27606|Renew|135953|a|15|magic|o||
27607|Power Word: Shield|135940|a|30|magic|o||
27610|Psychic Scream|136184|t|8||o||
27615|Kidney Shot|132298|t|5||o||
27616|Extra-Dimensional Ghost Revealer|135974|p|600||i||
27619|Ice Block|135841|p|10||o||
27620|Snap Kick|132219|t|4||o||
27633|Wing Clip|132309|t|10||o||
27634|Concussive Shot|135860|t|3|magic|o||
27636|Starshards|135753|t|6||o||
27637|Regrowth|136085|a|21|magic|o||
27638|Rake|132122|t|15||o||
27640|Baron Rivendare's Soul Drain|136208||3||o||
27641|Fear|136183|t|6|magic|o||
27648|Thunderfury|136018|t|12|magic|i||
27650|Vengeance|136224|p|-1||o||
27652|Elixir of Resistance|134801|p|1800||i||
27653|Elixir of Dodging|134832|p|1800||i||
27664|Stormwind Gift of Friendship|134142|p|3600||i||
27665|Ironforge Gift of Friendship|134140|p|3600||i||
27666|Darnassus Gift of Friendship|133203|p|3600||i||
27669|Orgrimmar Gift of Friendship|134140|p|3600||i||
27670|Thunder Bluff Gift of Friendship|134144|p|3600||i||
27671|Undercity Gift of Friendship|134143|p|3600||i||
27672|Initiate Secret Technique|136235|p|5||o||p
27673|Five Fat Finger Exploding Heart Technique|136133|t|30||o||
27675|Chromatic Infusion|135934|p|15||o||
27680|Berserk|136224|p|600||o||
27688|Bone Shield|136127|p|300|magic|o||
27689|Bloodlust|136012|p|30|magic|o||
27720|Buttermilk Delight|135457|p|3600||i||
27721|Very Berry Cream|135458|p|3600||i||
27722|Sweet Surprise|135459|p|3600||i||
27723|Dark Desire|135460|p|3600||i||
27737|Moonfire|136096|t|12|magic|o||
27741|Love is in the Air|135453|p|-1||o||
27746|Nitrous Boost|134797|p|-1||o||
27748|100 Mana|136235|p|-1||o||p
27758|War Stomp|132091|t|5||o||
27759|Shield Generator|134430|p|30||o||
27760|Polymorph|136071|t|15|magic|o||
27775|The Furious Storm|136014|p|10|magic|s||
27779|Divine Protection|135940|p|30|magic|s||
27784|Nature's Bounty|133439|p|5|magic|o||
27793|Disease Cloud|136006|p|-1||o||
27807|Bile Vomit|136007|t|20||o||
27808|Frost Blast|135840|t|5||o||
27814|Kick|132219|t|6||o||
27819|Detonate Mana|136116|t|5||o||
27825|Shadow Mark|136205|t|15||o||
27852|[PH] Kill Summoner Buff|136235|a|0.1||o||p
27857|Copy of Wandering Plague|136127|p|300|disease|o||
27861|The Baron's Ultimatum|136129|a|2700||o||
27863|The Baron's Ultimatum|136129|a|600||o||
27864|The Baron's Ultimatum|136129|a|300||o||
27865|The Baron's Ultimatum|136129|a|60||o||
27868|Freeze|135852|t|3|magic|i||
27879|Mount Speed+ DND|136235|p|-1||o||ip
27880|Stun|136222|p|3||o||
27881|Mount Speed++ DND|136235|p|-1||o||ip
27882|Mount Speed+++ DND|136235|p|-1||o||ip
27888|Minion Spawner, Buttress|136235|p|-1||o||p
27891|Disease Buffet|136022|t|20||o||
27897|Enrage|136224|p|600||o||
27933|Invis Stalker|136235|p|-1||o||p
27987|Unholy Aura|136225|p|-1||o||
27990|Fear|136183|t|4|magic|o||
27991|Sunder Armor|132363|t|30||o||
27993|Stomp|132368|t|12||o||
27994|Drain Life|136169|t|5|magic|o||
27995|Unholy Frenzy|136012|a|20|magic|o||
27999|Land Mine Periodic|135805|p|-1||o||
28018|[PH] Crystal Corpse Timer|136235|t|7200||o||p
28059|Positive Charge|135769|p|60||o||
28078|Buttress Channel|136235||-1||o||p
28084|Negative Charge|135768|p|60||o||
28090|Minion Despawn Timer|136235|p|-1||o||p
28095|Controller Timer|136235|p|3600||o||p
28096|Stalagg Chain|136235||-1||o||p
28111|Feugen Chain|136235||-1||o||p
28114|Mark of Didier|132212|p|-1||o||
28126|Spirit Particles (purple)|135864|p|-1||o||
28127|Flash|136049|t|8||o||
28131|Enrage|136224|p|300||o||
28134|Power Surge|136215|p|10||o||
28137|Slime Stream|136144|t|3||o||
28139|Stalagg Passive|136235|p|-1||o||p
28140|Taunt|136235|t|-1||o||p
28142|Power of the Guardian|136057|p|-1||i||
28143|Power of the Guardian|136057|p|-1||i||
28144|Power of the Guardian|136057|p|-1||i||
28145|Power of the Guardian|136057|p|-1||i||
28158|Poison|136064|p|60||o||
28160|Thadius Spawn|136235|p|-1||o||p
28169|Mutating Injection|136127|t|10|disease|o||
28190|Mutate Effect|136235|a|30||o||p
28197|Camp Type: Ghost/Skeleton|136235|p|-1||o||p
28198|Camp Type: Ghost/Ghoul|136235|p|-1||o||p
28199|Camp Type: Ghoul/Skeleton|136235|p|-1||o||p
28200|Ascendance|134123|p|20||i||
28204|Ascendance|135990|p|-1||i||
28225|AE Charm|136235|t|300||o||p
28235|Zombie Chow Search|136235|p|-1||o||p
28237|Immune Poly/Fear/|136235|a|-1||o||p
28282|Ashbringer|135331|p|-1||i||
28292|Minion Despawn Timer, Uncommon|136235|p|-1||o||p
28309|Copy of Corruption|136208|t|-1||o||
28310|Mind Flay|136208|t|8||o||
28311|Slime Bolt|136016|t|10|poison|o||
28314|Flameshocker's Touch|135990|t|3||o||
28315|Aura of Fear|136163|t|2|magic|o||
28316|Tent Prot (DND)|136235|p|3||o||ip
28323|Flameshocker's Revenge|135903|t|2||o||
28334|Whirlwind|132369|p|6||o||
28335|Whirlwind|132369|t|2||o||
28340|Unholy Aura|136225|p|-1||o||
28342|Breath of Sargeras|136172|t|90|curse|o||
28346|Communique Timer, camp|136235|p|-1||o||p
28347|Dimensional Siphon|136153|p|-1||i||
28348|Dimensional Siphon|136123|p|-1||o||
28350|Veil of Darkness|136160|t|7|curse|o||
28362|Disease Cloud|136006|p|604800||o||
28371|Frenzy|132117|p|8|frenzy|o||
28374|Decimate|136235|p|3||o||p
28391|Blink|135736|p|1||o||
28395|Communique Timer, Necropolis|136235|p|-1||o||p
28406|Polymorph Backfire|136071|p|8|magic|o||
28409|Chains of Kel'Thuzad|132507|p|20||o||
28410|Chains of Kel'Thuzad|132507|t|20||o||
28412|Death Coil|136145|t|3||o||
28413|Aura of Agony|136139|t|8||o||
28418|General's Warcry|136087|a|120||o||
28419|General's Warcry|136087|a|120||o||
28420|General's Warcry|136087|a|120||o||
28425|Summon Type A Periodic (3 sec)|136235|p|-1||o||p
28426|Summon Type B Periodic (30 sec)|136235|p|-1||o||p
28427|Summon Type C Periodic (30 sec)|136235|p|-1||o||p
28431|Poison Charge|136016|t|9|poison|o||
28434|Spider Web|136022|t|1||o||
28440|Veil of Shadow|136160|t|6|curse|o||
28443|Transform Ghost|136235|p|-1||o||p
28445|Improved Concussive Shot|135860|t|3||o||
28450|Arcane Explosion|136116|p|0.1|magic|o||
28453|Summon Type D Periodic|136235|p|-1||o||p
28456|Gouge|132155|t|6||o||
28467|Mortal Wound|132109|t|15||o||
28468|Enrage|136224|p|-1||o||
28469|Ghost Vision|135918|p|-1||o||
28470|Blood Tap|136168|p|-1||o||
28478|Frostbolt|135846|t|4|magic|o||
28479|Frostbolt|135846|t|4|magic|o||
28498|Berserk|136224|p|300||o||
28522|Icebolt|135852|t|25||o||
28529|Frost Aura|136235|p|-1||o||p
28531|Frost Aura|135849|p|-1||o||
28533|Transform|136172|p|-1||o||
28542|Life Drain|136169|t|12|curse|o||
28559|Untrackable|132252|p|-1||o||
28608|Test Curse of Agony|136139|t|24|curse|o||i
28616|Food|134062|p|30||o||
28618|Web Wrap|136235|a|1||o||p
28619|Web Wrap|136235|a|2||o||p
28620|Web Wrap|136235|a|2||o||p
28621|Web Wrap|136235|a|2||o||p
28622|Web Wrap|136113|p|60||o||
28627|Summon Web Wrap|136235|p|55||o||p
28663|Plague Claw Submerge Visual|135830|p|-1||o||
28679|Harvest Soul|136137|t|60||o||
28681|Soul Revival|135907|t|1800||o||
28701|Haste|136075|p|20||o||
28725|War Stomp|132091|t|5||o||
28727|Mind Exhaustion|136222|p|30||o||
28732|Widow's Embrace|135736|t|30|magic|o||
28747|Enrage|136224|p|600||o||
28750|Blessing of the Claw|135879|a|4||o||
28754|Fury of the Ashbringer|136129|p|15|magic|o||
28758|Stalker's Ally|132127|p|4||o||
28762|Not There|135894|p|8|magic|s||
28765|Fire Resistance|135806|p|30|magic|o||
28766|Frost Resistance|135843|p|30|magic|o||
28768|Nature Resistance|136061|p|30|magic|o||
28769|Shadow Resistance|136121|p|30|magic|o||
28770|Arcane Resistance|135995|p|30|magic|o||
28772|Elemental Vulnerability|135899|t|30|magic|s||
28773|Glyph of Deflection|135443|p|20||i||
28776|Necrotic Poison|132105|t|30|poison|o||
28777|Slayer's Crest|135441|p|20||i||
28778|Loatheb's Reflection|135443|p|20||i||
28779|Essence of Sapphiron|135444|p|20||i||
28780|The Eye of the Dead|135439|p|30|magic|i||
28782|Stun Self + Immune|136235|p|-1||o||p
28785|Locust Swarm|136045|p|20||o||
28786|Locust Swarm|136045|t|6||o||
28790|Holy Power|135995|a|8||o||
28791|Holy Power|135892|a|8||o||
28793|Holy Power|135922|a|8||o||
28795|Holy Power|135977|a|8||o||
28796|Poison Bolt Volley|136016|t|8|poison|o||
28798|Enrage|136224|p|1800||o||
28801|Slime|132108|p|-1||o||
28804|Epiphany|136075|p|30||s||
28810|Armor of Faith|135880|a|30|magic|o||
28815|Revealed Flaw|132353|p|-1||s||
28819|Submerge Visual|135830|p|-1||o||
28824|Totemic Power|135977|a|8||o||
28825|Totemic Power|135922|a|8||o||
28826|Totemic Power|135892|a|8||o||
28827|Totemic Power|135995|a|8||o||
28832|Mark of Korth'azz|136172|t|75||o||
28833|Mark of Blaumeux|135900|t|75||o||
28834|Mark of Mograine|136192|t|75||o||
28835|Mark of Zeliek|136137|t|75||o||
28846|Cheat Death|136119|p|5|magic|s||
28858|Entangling Roots|136100|t|15||o||
28862|The Eye of Diminution|135994|p|20|magic|i||
28866|Kiss of the Spider|135442|p|15|magic|i||
28882|Righteous Fire|135880|t|8||o||
28911|Copy of Garrote|132297|t|18||o||
28913|Flesh Rot|132152|t|10||o||
28969|Acid Spit|136016|t|10||o||
28987|Plague Slime (Black)|136121|p|-1||o||
28988|Plague Slime (Blue)|135835|p|-1||o||
28989|Plague Slime (Green)|136094|p|-1||o||
28990|Plague Slime (Red)|135824|p|-1||o||
28991|Web|132149|t|10||o||
28995|Stoneskin|136031|p|6||o||
29001|Transformed|135468|a|3600||o||
29002|Transformed|135468|a|3600||o||
29003|Transformed|135468|a|3600||o||
29006|Bubbly Refreshment|132799|p|1800||i||
29007|Drink|132794|p|30||i||
29008|Food|134062|p|30||i||
29035|Bloodlord's Aura|136235|p|15||o||p
29038|Fizzy Energy Drink|133949|p|21||i||
29039|Fizzy Energy Drink|132800|p|21||i||
29040|Fizzy Energy Drink|132489|p|900||o||
29041|Tasty Summer Treat|133984|p|30||i||
29051|Mind Exhaustion|136222|p|60||o||
29055|Refreshing Red Apple|133975|p|25||i||
29059|Skeletal Steed|132264|p|-1||i||
29060|Taunt|136080|t|20||o||
29061|Shield Wall|132362|p|20||o||
29073|Food|134062|p|30||i||
29103|Anub'Rekhan's Aura|136235|p|-1||o||p
29104|Anub'Rekhan's Aura|136235|t|5||o||p
29124|Polymorph|136071|p|20||o||
29125|Hopeless|132366|p|-1||o||
29127|Maypole Buff|136235|a|||o||p
29134|Maypole|136223|p|5||o||
29153|Gargoyle Stoneform Visual|135727|p|-1||o||
29163|Copy of Frostbolt|135846|t|5|magic|o||
29164|Stygian Grasp|136143|t|5|magic|i||
29168|Fear|136183|t|6|magic|o||
29169|Copy of Poison Bolt Volley|136016|t|10|poison|o||
29172|Ribbon Pole Channel|135270||-1||o||
29175|Ribbon Dance|135270|a|3600||o||
29183|Polymorph Immunity|136235|p|60||o||p
29184|Corrupted Mind|136122|p|60||o||
29185|Corrupted Mind|136140|a|120||o||
29194|Corrupted Mind|136140|a|120||o||
29195|Corrupted Mind|136122|p|60||o||
29196|Corrupted Mind|136140|a|120||o||
29197|Corrupted Mind|136122|p|60||o||
29198|Corrupted Mind|136140|a|120||o||
29199|Corrupted Mind|136122|p|60||o||
29204|Inevitable Doom|136179|t|10||o||
29207|Copy of Blink|135736|p|1||o||
29208|Blink|135736|p|1||o||
29209|Blink|135736|p|1||o||
29210|Blink|135736|p|1||o||
29211|Blink|135736|p|1||o||
29212|Cripple|136135|t|15|magic|o||
29213|Curse of the Plaguebringer|136119|t|10|curse|o||
29214|Wrath of the Plaguebringer|136121|t|10||o||
29220|Fiery Festival Brew|135818|p|300|poison|o||
29232|Fungal Bloom|136112|t|90||o||
29233|Beast of the Unseen Path|132133|e|4||s||
29235|Fire Festival Fortitude|135265|p|3600||o||
29241|Midsummer Merchant - Dwarf Female|135849|p|-1||o||
29242|Midsummer Merchant - Orc Female|135849|p|-1||o||
29243|Festival Flamekeeper - Troll Male|135849|p|-1||o||
29244|Festival Flamekeeper - Tauren Female|135849|p|-1||o||
29245|Festival Flamekeeper - Dwarf Male|135849|p|-1||o||
29246|Festival Flamekeeper - Human Female|135849|p|-1||o||
29252|Summon Skeletons|136235|p|5||o||p
29261|Summon Skeletons|136235|p|5||o||p
29264|Copy of Summon Skeletons|136235|p|-1||o||p
29265|Summon Skeletons|136235|p|5||o||p
29270|Summon Skeletons|136235|p|5||o||p
29296|Naxxramas Entry Flag Trigger  DND|136235||2||o||ip
29306|Infected Wound|136066|t|60||o||
29325|Acid Volley|136007|t|25||o||
29331|Copy of Dark Desire|135460|p|3600||o||
29332|Fire-toasted Bun|133964|p|3600||i||
29333|Midsummer Sausage|134009|p|3600||i||
29334|Toasted Smorc|135267|p|3600||i||
29335|Elderberry Pie|133952|p|3600||i||
29338|Fire Festival Fury|134468|p|3600||i||
29350|Plague Cloud|132099|p|45||o||
29351|Plague Wave Controller (Slow)|135805|p|-1||o||
29388|Breath of Fire|135818|p|12||i||
29391|Summon Type A Periodic (4 sec)|136235|p|-1||o||p
29392|Summon Type A Periodic (2 sec)|136235|p|-1||o||p
29393|Summon Type B Periodic (25 sec)|136235|p|-1||o||p
29394|Summon Type B Periodic (20 sec)|136235|p|-1||o||p
29398|Summon Type B Periodic (15 sec)|136235|p|-1||o||p
29399|Summon Type C Periodic (40 sec)|136235|p|-1||o||p
29400|Summon Type C Periodic (35 sec)|136235|p|-1||o||p
29401|Summon Type C Periodic (20 sec)|136235|p|-1||o||p
29407|Mind Flay|136208|t|10||o||
29409|Summon Type A Periodic (1 sec)|136235|p|-1||o||p
29410|Summon Type A Periodic (5 sec)|136235|p|-1||o||p
29411|Summon Type B Periodic (10 sec)|136235|p|-1||o||p
29412|Summon Type C Periodic (15 sec)|136235|p|-1||o||p
29419|Flash Bomb|136142|t|10||o||
29423|Kel'Thuzad Channel|136235|p|-1||o||p
29432|Fire Protection|135820|p|3600|magic|i||
29484|Web Spray|136113|t|10||o||
29506|The Burrower's Shell|135893|p|20||i||
29519|Silithyst|135867|p|-1||o||
29520|Echoes of Lordaeron|132485|a|-1||o||
29530|Sillithus Flag Capture Test (DND)|136235|a|1||o||ip
29531|Ribbon Pole Channel|135270||-1||o||
29532|Ribbon Pole Channel Effect Trigger|135270|p|-1||o||
29534|Traces of Silithyst|136106|p|1800||o||
29544|Intimidating Shout|132154|t|8||o||
29604|Jom Gabbar|132273|p|-1||i||
29607|Debug Frost Spell|135846|t|0.001||o||
29659|Positive Charge|135769|p|-1||o||
29660|Negative Charge|135768|p|-1||o||
29681|Call All Zombie Chow|136235|p|-1||o||p
29685|Terrifying Roar|132111|t|5||o||
29705|Test Ribbon Pole Channel|135270|p|-1||o||i
29726|Test Ribbon Pole Channel|135270|p|-1||o||i
29727|Test Ribbon Pole Channel|135270|p|-1||o||i
29846|Fire Festival Fury|134468|t|3600||o||
29848|Polymorph|136071|t|20|magic|o||
29849|Frost Nova|135848|t|8|magic|o||
29851|Whirlwind|132369|p|2||o||
29865|Poison Aura|136016|t|12|poison|o||
29871|Ice Bolt Prot|136235|t|5||o||p
29894|Sillithus Flag, Alliance, and speed limit (DND)|132486|p|-1||o||i
29895|Sillithus Flag, Horde, and speed limit (DND)|132486|p|-1||o||i
29910|Clear All Shackels|136235|p|1||o||p
29915|Flesh Rot|132152|t|10||o||
29943|Silence|135975|t|8||o||
29998|Decrepit Fever|132100|t|21|disease|o||
30001|Copy of Fear|136183|t|8|magic|o||
30002|Fear|136183|t|6|magic|o||
30020|First Aid|135915|a|10||i||
30025|Mind Exhaustion Passive|136235|p|-1||o||p
30080|Retching Plague|136127|p|300|disease|o||
30081|Retching Plague|136127|t|300|disease|o||
30082|Charge Protection|136235|a|3||o||p
30088|Lesser Mark of the Dawn|134499|p|3600||i||
30089|Mark of the Dawn|134500|p|3600||i||
30090|Greater Mark of the Dawn|134501|p|3600||i||
30092|Blast Wave|135903|t|8||o||
30094|Frost Nova|135848|t|8|magic|o||
30095|Cone of Cold|135852|t|8|magic|o||
30109|Slime Burst|136007|t|5||o||
30110|Mutated Spores|136006|p|604800||o||
30112|Frenzied Dive|132182|t|2||o||
30113|Putrid Bite|132100|t|30|disease|o||
30114|Plague Wave Controller (Fast)|135805|p|-1||o||
30164|Permanent Lung Juice Cocktail|136075|a|-1||i||
30167|Purple Ogre Costume|132288|p|600||i||
30173|Permanent Ground Scorpok Assay|136075|a|-1||i||
30174|Riding Turtle|132199|p|-1||i||
30175|Permanent Cerebral Cortex Compound|136075|a|-1||i||
30177|Permanent Gizzard Gum|136075|a|-1||i||
30178|Permanent R.O.I.D.S.|136075|a|-1||i||
30225|Silence|135975|t|8||o||
30238|Lordaeron's Blessing|135946|a|1800||o||
30285|Eagle Claw|132155|t|15||o||
30297|Heightened Senses|136235|p|1800||i||p
30331|Permanent Sheen of Zanza|134809|p|7200||i||
30336|Permanent Spirit of Zanza|134810|p|7200||i||
30338|Permanent Swiftness of Zanza|134811|p|7200||i||
30682|Echoes of Lordaeron|132485|a|-1||o||
30683|Echoes of Lordaeron|132485|a|-1||o||
30754|Cenarion Favor|136086|a|-1||o||
30803|Unleashed Rage|136009|p|10||o||
30804|Unleashed Rage|136009|p|10||o||
30805|Unleashed Rage|136009|p|10||o||
30806|Unleashed Rage|136009|p|10||o||
30807|Unleashed Rage|136009|p|10||o||
30839|Debuff Uber Heal Over Time|135923|a|-1||o||
30880|Echoes of Lordaeron|132485|a|-1||o||
31309|Spirit Particles (red, big)|135864|p|-1||o||
31316|Summon Boss Buff|136235|a|0.1||o||p
31365|Self Fear|136183|p|-1|magic|o||
31366|RAF|136235|a|-1||o||p
31565|I can't drive 55|136235|p|-1||o||p
31599|Netherwalk|136163|p|-1||o||
31688|Frost Breath|135781|t|6|magic|o||
31700|Summon Black Qiraji Battle Tank|134399|p|-1||o||
31800|Icebolt|135852|p|27||o||
31817|Buff|136101|p|-1|magic|o||
31906|Lordaeron's Blessing Effect (DND)|136235|a|-1||o||ip
31951|Spirit Particles (red, super big) (DND)|135864|p|-1||o||i
32309|Slime Bolt|136016|t|6|poison|o||
34074|Aspect of the Viper|132160|p|-1||o||
43308|Find Fish|133888|p|-1||i||
43680|Idle|132156|a|180||o||
43681|Inactive|136072|p|180||o||
43869|You're a Zombie!|136179|a|-1||o||
43945|You're a ...! (Effects1)|136243|p|-1||o||
43949|Lurch!|136194|t|10||o||
43958|You're Infected!|136206|p|-1|disease|o||
43963|Wretched!|134437|t|15||o||
44305|You're a ...! (Effects2)|136243|p|-1||o||
45440|Steam Tonk Controller|133878|p|300||i||
46598|Ride Vehicle Hardcoded|252181|p|-1||o||
48050|You're a ...! (Effects3)|136243|p|-1||o||
48108|Hot Streak|236218|p|10||o||
48198|Righteous Fire|135920|a|10||o||
48200|Healer Aura|136243|p|-1||o||
50015|Zombie Spawn|136243|a|5||o||
51241|ZP - Retch! (Bunny Aura)|136243|p|15||o||
53489|The Art of War|236246|p|15|magic|o||
53601|Sacred Shield|236249|a|30|magic|o||
53672|Infusion of Light|236254|p|15||o||
54059|You're a ...! (Effects4)|136243|p|-1||o||
54145|You're a ...! (Effects5)|136243|p|-1||o||
54147|You're a ...! (Effects6)|136243|p|-1||o||
54162|You're a ...! (Effects7)|136243|p|-1||o||
55743|Lurch!|136194|p|8||o||
56528|Zombie Explosion!|136133|p|5||o||
56543|Wretched! IsIn Fog Checker|134437|t|0.5||o||
56608|Beckoned|136147|p|18||o||
57346|Ride Vehicle|135995|a|-1||o||
57526|Lurch! Immunity Effect|135894|p|0.1||o||
57596|Mangle!|136228|t|12||o||
58597|Sacred Shield|236252|a|6|magic|o||
64659|Venomhide Ravasaur|132253|p|-1||i||
77747|Totemic Wrath|135829|p|43200||o||
86457|Mount Speed Mod: Standard Ground Mount|132261|p|-1||o||
86458|Mount Speed Mod: Epic Ground Mount|132224|p|-1||o||
167152|Refreshment|134062|p|20||o||
219003|Idle|132156|a|180||o||
219004|Inactive|136072|p|180||o||
285224|BlizzCon Exhaustion|135724|p|-1||o||
301089|Horde Flag|132485|a|-1||o||
301091|Alliance Flag|132486|a|-1||o||
301100|Recently Dropped Flag|132484|p|3||o||
301101|Recently Dropped Flag|132484|p|3||o||
324270|Corrupted Blood|136133|t|4||o||
324271|Corrupted Blood|136133|p|4||o||
335924|Winds of Wisdom|1120721|p|-1||o||
345919|No Man's Land|135724|p|-1||o||
346285|Just Pretend|136090|p|-1||o||
348005|Poison|136016|t|30|poison|o||
348232|Pet Teleport Check|136243|p|30||o||
349981|Supercharged Chronoboon Displacer|133881|p|-1||o||
350025|Frostbolt|135846|t|6|magic|e||
353694|Sayge's Dark Fortune|136243|p|-1||o||
355363|Rallying Cry of the Dragonslayer|134153|a|7200||i||
355365|Spirit of Zandalar|132107|a|7200||i||
355366|Warchief's Blessing|135759|a|3600||i||
362859|Adventure Awaits|132327|p|-1||o||
363731|Volcanic Unrest|135819|p|-1||o||
363881|CHUG! CHUG! CHUG! CHUG!|132788|p|5|magic|i||
364001|Soul of Iron|134902|a|-1||o||
364090|Never Known Defeat|135976|a|-1||o||
364106|Relentless Dead|136119|p|-1||o||
364107|Relentless Dead|136119|p|-1||o||
364204|Mirror Name|136243|a|-1||o||
364212|Blessing of Theradras|136026|p|-1||o||
364214|Blessing of Theradras|136026|p|-1||o||
364226|Tarnished Soul|136208|a|-1||o||
364350|Debuff|136235|a|-1||o||p
364456|Perished at Level|135767|a|-1||o||
364459|Shroud of Death|132331|p|-1||o||
364658|THIEF!|133644|a|1800||o||
364784|Share Health|136243|p|-1||o||
364785|Share Health|136243|t|-1||o||
364786|Share Health|136243|p|-1||o||
364792|Share Health|136243|p|-1||o||
364820|Living Fallout|135826|a|-1||o||
364838|Inferno|135818|a|-1||o||
365122|Berserk|136224|p|300||o||
365123|Call Meteor|136243|p|-1||o||
365188|Rain of Fire|136186|a|-1||o||
365196|Rain of Fire|136186|p|18||o||
365663|Sunder Armor|132363|t|30||o||
366305|Static Electricity|136048|a|-1||o||
366541|Static Electricity|136051|a|-1||o||
366587|Soulflayer's Fervor|135727|p|-1||o||
366588|Soulflayer's Fervor|135727|p|-1||o||
366590|Soulflayer's Fervor|135727|p|-1||o||
366719|Static Charge|135990|p|-1||o||
366909|Ruby Flames|135805|a|-1||o||
366969|Emerald Breath|132104|a|-1||o||
366994|Obsidian Breath|135821|a|-1||o||
366995|Bronze Breath|132862|a|-1||o||
366996|Azure Breath|135836|a|-1||o||
367063|Ruby Essence|134158|p|-1||o||
367064|Emerald Essence|134157|p|-1||o||
367065|Azure Essence|134155|p|-1||o||
367066|Obsidian Essence|134154|p|-1||o||
367067|Bronze Essence|134156|p|-1||o||
367070|Tranquility|136107|p|45||o||
367179|Chromatic Essence|134563|p|-1||o||
367187|Chromatic Essence|134139|p|-1||o||
367369|Tactical Charge|132212|t|5||o||
367427|Suppression Aura|135831|p|-1||o||
367476|Faulty Wiring|133859|p|1.5||o||
367671|Hiding Behind Ice|135841|a|-1||o||
367688|Flame Patch|135805|a|-1||o||
367692|Flame Patch|135805|p|-1||o||
367701|Time Stop|136106|t|6||o||
367720|Dream Fog|136006|p|-1||o||
367724|Dream Fog|136006|a|10||o||
367728|Dream Fog|136090|a|6||o||
367740|Creeping Chill|135836|a|-1|magic|o||
367741|Frozen Solid|135836|a|10|magic|o||
367756|Temporal Acceleration|134376|a|30|magic|o||
367792|Temporal Acceleration|134376|a|-1||o||
367873|Blinding Ash|136197|a|-1||o||
367887|Dream Breath|136006|p|-1||o||
367888|Dream Breath|136006|a|-1||o||
367897|Dream Breath|136006|a|6||o||
367928|Corrupted Slam|135860|a|2||o||
367955|Chromatic Essence|134563|p|-1||o||
367985|Burning Adrenaline|132937|t|-1||o||
367986|Burning Adrenaline|132937|t|-1||o||
367987|Burning Adrenaline|132937|p|-1||o||
368000|Faulty Wiring|133859|p|-1||o||
368003|Faulty Wiring|133859|a|-1||o||
368007|Tactical Flurry|132152|p|10||o||
368087|Faulty Wiring|136243|p|-1||o||
368218|Consecration|135926|p|-1||o||
368226|Shadowrush|136136|p|2.5||o||
368235|Consecration|135926|a|-1||o||
368292|Mind Flay|136208|t|-1||o||
368315|Mind Flay|136208|t|-1||o||
368329|Nightmare Brambles|136100|t|10|magic|o||
368371|Obsidian Fury|135824|p|-1||o||
368388|Berserk|136224|p|-1||o||
368515|Brand of Shadow|136121|t|40||o||
368521|Brand of Flame|135824|t|40||o||
368615|Pulse Lightning|135990|p|15|magic|o||
368623|Holy Bolt|135920|p|-1||o||
368632|Corrupted Weapon|136189|a|45||o||
368659|Chromatic Shield|134563|p|-1||o||
368713|[DNT] Firemaw Cosmetic Electricity|136243|p|-1||o||i
368925|Burning Adrenaline|132937|t|-1||o||
369533|Hiding Behind Ice|135841|p|-1||o||
369982|Touch of Madness|133574|p|-1||o||
370066|Visions of Madness|136224|a|8||o||
370091|Uber Invis|135994|p|-1||o||
370100|Illusionary Rot|134910|p|-1||o||
370146|Real Clone|136243|p|-1||o||
370171|Summon Eye of C'Thun|136235|p|-1||o||p
370180|Summon Claw Tentacles|136235|p|-1||o||p
370189|Summon Eye Tentacles|136235|p|-1||o||p
370192|Summon Giant Claw Tentacles|136235|p|-1||o||p
370287|Undying Vanquisher|136142|p|-1||o||
370290|Bonus Difficulty - Friendly (Green)|134397|p|-1||o||
370293|Bonus Difficulty - Honored (Blue)|134398|p|-1||o||
370294|Bonus Difficulty - Revered (Purple)|134399|p|-1||o||
370295|Bonus Difficulty - Exalted (Red)|134396|p|-1||o||
370303|Orb of Corruption|134120|p|1800||i||
370308|Rod of Necromancy|135474|t|300||i||
370336|Fungal Spore Cluster|134530|p|3600||i||
370337|Fungal Bloom|134202|t|15||o||
370417|Failsafe Phylactery|135441|p|3||o||
370427|Mask of Death|136147|p|600|magic|o||
370431|Mask of Death|136147|p|600|magic|o||
370434|Mask of Death|136147|p|600|magic|o||
370435|Mask of Death|136147|p|600|magic|o||
370436|Mask of Death|136147|p|600|magic|o||
370439|Gooped|132108|a|180|poison|o||
370490|Skeletal Artifact|132116|p|3600||o||
370496|Glyph of Madness|133571|p|-1||o||
370497|Glyph of Darkness|133424|p|-1||o||
370498|Glyph of Chaos|133574|p|-1||o||
370507|Glyph of the Void|133387|p|-1||o||
370544|Skeletal Artifact|136083|p|3600||o||
370548|Skeletal Artifact|136083|p|3600||o||
370550|Skeletal Artifact|136083|p|3600||o||
370552|Skeletal Artifact|136083|p|3600||o||
370603|Rune of Fortune|134418|a|-1||o||
370637|Summon Skeletal Steed|132264|p|-1||o||
370759|Vanquisher|135974|p|-1||o||
370767|Essence of C'Thun|133572|t|-1||o||
370831|Thaddius' Lightning Bolts|134068|p|3600||i||
370832|Gift of the Spider|135367|p|3600||i||
370835|Positive Charge|135769|p|60||o||
370836|Negative Charge|135768|p|60||o||
370863|Mask of Death|136147|p|600|magic|o||
370864|Mask of Death|136147|p|600|magic|o||
370877|Ritual Dagger|135341|p|3600||o||
370904|Web Wrap|136235|a|1||o||p
371075|Summon Illusory Claw Tentacles|136235|p|-1||o||p
371100|Summon Illusory Eye Tentacles|136235|p|-1||o||p
371106|Summon Illusory Giant Claw Tentacles|136235|p|-1||o||p
371206|Servant of Chaos|136206|a|-1||o||
371626|[DNT] Transform to Small Portal|135994|p|-1||o||i
371627|[DNT] Transform to Giant Portal|135994|p|-1||o||i
371628|[DNT] Transform to Claw|135994|p|-1||o||i
371629|[DNT] Transform to Eye|135994|p|-1||o||i
371630|[DNT] Transform to Giant Claw|135994|p|-1||o||i
371656|Quick Sand|133853|t|20||o||
371740|Quick Sand|136243|p|-1||o||
381598|Summon Skeletal Steed|132264|p|-1||o||
398117|Pockets of Treats|132165|t|120||i||
398196|Quick Draw|134536|t|6||o||
398198|Storm of Swords|132336|p|5||o||
398199|Hubris Tunic|136243|p|10||o||
400009|Between the Eyes|135610|t|||o||
400012|Blade Dance|132269|p|10||o||
400015|Rolling with the Punches|132301|p|30||e||
400023|Cheat Death|132285|p|60||o||
400024|Cheating Death|132293|p|3||o||
400613|Living Bomb|236220|t|12|magic|o||
400730|Fireball!|236206|p|15|magic|e||
400735|Temporal Beacon|136106|a|30|magic|o||
401417|Regeneration|132869|a|3|magic|o||
401460|Rapid Regeneration|132868|a|1.5|magic|o||
401556|Living Flame|135820|p|10||o||
401558|Living Flame|135820|a|2||o||
401956|Cryomantic Mishap|135852|p|-1||o||
401962|Shadow Word: Death|136149|p|1||o||
401981|Applying Heat|135805|p|1.5||o||
401990|Shadowcrawl|136130|p|5||o||
402004|Pain Suppression|135936|a|8|magic|o||
402010|Polymorph Cured|133937|p|300||o||
402277|Penance|237545|p|2||o||
402362|White|134127|p|15|magic|o||
402368|Black|134120|p|15|magic|o||
402668|Vampiric Touch|135978|t|15|magic|o||
402686|Wild Polymorph|136071|p|-1||o||
402791|Curse of Shadow|136137|t|180|curse|o||
402792|Curse of the Elements|136130|t|180|curse|o||
402794|Curse of Tongues|136140|t|180|curse|o||
402808|Cripple|136135|t|15||o||
402811|Demoralize|237561|t|15||o||
402818|Degrade|132358|t|15||o||
402906|Flagellation|236310|p|12||o||
402913|Enraged Regeneration|132175|p|10||o||
403215|Commanding Shout|132351|p|300||i||
403233|Meathook|132507|p|2||o||
403501|Haunt|236298|t|12|magic|o||
403619|Fel Armor|136156|p|1800|magic|i||
403677|Drain Life|136169|t|15|magic|o||
403685|Drain Life|136169|t|15|magic|o||
403686|Drain Life|136169|t|15|magic|o||
403687|Drain Life|136169|t|15|magic|o||
403688|Drain Life|136169|t|15|magic|o||
403689|Drain Life|136169|t|15|magic|o||
403789|Metamorphosis|237558|p|-1||o||
403828|Menace|136214|t|3||o||
404275|Aqua Strike|135848|t|8|magic|o||
404316|Greater Frostbolt|135846|t|5|magic|o||
404373|Bubble Beam|136148|p|10||o||
404806|Depth Charge|132866|t|8||o||
405092|Underwater Pressure|136148|p|-1||o||
405168|Riptide|135860|p|-1||o||
405194|Riptide|135860|p|1||o||
405321|Riptide|135860|p|1||o||
405324|Riptide|135860|p|-1||o||
405663|Greater Ice Barrier|135843|p|-1||o||
405688|Riptide Bubbles|132112|t|15||o||
405695|Riptide Bubbles|132112|p|-1||o||
405951|Whirlpool|135860|p|10||o||
405953|Torrential Downpour|136018|a|-1||o||
406634|Animated Lobster Molt|133900|p|-1||o||
406680|Frostbolt|135846|t|3|magic|o||
406722|Shadowstep|132303|p|3||o||
406970|Aqua Shell|134564|p|-1||o||
407025|Exposed|132127|p|60||o||
407077|Triple Chomp|132270|p|3.5||o||
407095|Crunch Armor|132363|t|20||o||
407546|Freezing Arrow|135836|a|10|magic|o||
407548|Freezing Arrow|135836|a|-1||o||
407627|Righteous Fury|135962|p|-1|magic|o||
407653|Forked Lightning|237587|t|8||o||
407767|Forked Lightning|237587|a|-1||o||
407788|Avenging Wrath|135875|p|20|magic|i||
407791|Aku'mai's Rage|136224|p|15|frenzy|o||
407794|Triple Puncture|132155|t|15||o||
407798|Seal of Martyrdom|135961|p|30|magic|i||
407804|Divine Sacrifice|253400|p|10|magic|o||
407805|Sacrifice Redeemed|253400|p|10|magic|o||
407812|Immunity to Freezing Arrow|135818|p|30||o||
407813|Frost Arrow|132222||5||o||
407819|Frost Arrow|135152|a|5||o||
407880|Inspiration Exemplar|135938|p|120|magic|o||
407973|Wild Strike|132143|p|1.5||o||
407975|Wild Strikes|132143|p|-1||o||
407988|Savage Roar|236167|p|9|frenzy|o||
408024|Survival Instincts|236169|p|20||o||
408124|Lifebloom|134206|a|7|magic|o||
408261|Dreamstate|132123|p|8||e||
408307|Nature's Fury|136094|p|30||o||
408309|Grace of Elune|135900|p|30||o||
408501|Maelstrom Ready!|237584|p|-1|frenzy|o||
408514|Earth Shield|136089|a|600|magic|o||
408525|Shield Mastery|134963|p|15||o||
408680|Way of Earth|136025|p|10||o||
408681|Earth Shock|136026|t|2||o||
408683|Earth Shock|136026|t|2||o||
408685|Earth Shock|136026|t|2||o||
408687|Earth Shock|136026|t|2||o||
408688|Earth Shock|136026|t|2||o||
408689|Earth Shock|136026|t|2||o||
408690|Earth Shock|136026|t|2||o||
408693|Earth Shock|136026|t|3||o||
408696|Spirit of the Alpha|132203|a|1800|magic|o||
408699|Waylay|236286|t|8||e||
408755|Blood Offering|136008|p|600||i||
408828|Inspired|136116|p|-1||o||
408953|Building Inspiration|237556|p|-1||i||
409064|Rune Scrying|136208||-1||o||
409324|Ancestral Guidance|132132|p|10|magic|o||
409372|Growl|132270|t|3||o||
409379|Kill Command|132176|p|30||o||
409396|Kill Command|132176|p|30||o||
409418|Kill Command|132176|e|30||o||
409495|Chimera Shot - Scorpid|134156|t|10||o||
409507|Expose Weakness|132295|p|7|magic|e||
409918|Inspiration (Judgement)|134916|p|-1||o||
410140|Spider Venom|136016|p|-1|poison|o||
410144|Savage Defense|132278|p|10||s||
410163|Necrotic Infection|136182|p|-1|disease|o||
410412|Tease|236550|t|3||o||
410881|Sanctified Area|135934|p|-1||o||
410935|Meditation on the Light|135934|p|14400||o||
410970|Meditation on the Void|136129|p|14400||o||
411608|Tame Prairie Dog|134010|p|600||o||
411622|Prairie Dog Musk|134743|p|600||i||
411631|Tame Beast|132164|p|20||o||
411684|Charge|132337|p|0.1||o||
411688|Charge Stun|135860|t|1||o||
411774|Whirlwind|132369|p|2||o||
411956|Curse of Blackfathom|136139|t|12|curse|o||
411959|Fear|136183|a|4|magic|o||
411993|Shoddy Camouflage|132320|p|-1||o||
411995|Shadow Crash|136197|a|-1||o||
412018|Sacred Shield|236252|a|6|magic|o||
412019|Sacred Shield|236249|a|60|magic|o||
412020|Flash of Light|135907|a|12|magic|o||
412072|Shadow Strike|132323|t|12||o||
412079|Shadow Strike|132323|t|12||o||
412080|Shadow Strike|132323|t|12||o||
412096|Crimson Tempest|135315|t|2||o||
412116|Mana Shield|136153|a|60|magic|o||
412118|Mana Shield|136153|a|60|magic|o||
412120|Mana Shield|136153|a|60|magic|o||
412121|Mana Shield|136153|a|60|magic|o||
412122|Mana Shield|136153|a|60|magic|o||
412123|Mana Shield|136153|a|60|magic|o||
412179|Cunning Disguise?|132288|p|900||i||
412202|Frost Ward|135850|a|30|magic|o||
412205|Frost Ward|135850|a|30|magic|o||
412207|Frost Ward|135850|a|30|magic|o||
412209|Frost Ward|135850|a|30|magic|o||
412210|Frost Ward|135850|a|30|magic|o||
412214|Fire Ward|135806|a|30|magic|o||
412218|Fire Ward|135806|a|30|magic|o||
412230|Fire Ward|135806|a|30|magic|o||
412231|Fire Ward|135806|a|30|magic|o||
412232|Fire Ward|135806|a|30|magic|o||
412248|Void Empowerment|136221|p|-1||o||
412325|Enlightenment|135738|p|10||o||
412326|Enlightenment|135977|p|10||o||
412456|March of the Murlocs|132834|p|-1||o||
412510|Mass Regeneration|132868|p|3|magic|o||
412513|Gladiator Stance|236541|p|-1||o||
412526|Mind Flay|136208|t|10||o||
412532|Spellfrost Bolt|135780|t|9|magic|o||
412735|Demonic Knowledge|136172|p|15||o||
412789|Demonic Howl|132091|t|6||o||
412790|Infernal Strike|136219|t|2||o||
412800|Dance of the Wicked|236295|p|15||o||
413247|Serendipity|237549|p|20|magic|e||
413259|Mind Sear|237565|t|6||o||
413399|Blood Surge|236306|p|15||e||
413548|Degreelessness Mode|135939||-1||o||
413589|Thunder Clap|136105|t|30||o||
413664|Bubble Beam|136148|p|3||o||
413685|Path of Arthas|133730|p|10||o||
414680|Living Seed|236155|a|15|magic|o||
414684|Sunfire|236216|t|12|magic|o||
414687|Sunfire|236216|t|12|magic|o||
414689|Sunfire|236216|t|12|magic|o||
414722|Slumbering Spirit|136074|p|-1||o||
414786|Corrupted Molten Fury Totem|136243|p|-1||o||
414800|Fury of Stormrage|237472|p|15|magic|e||
414824|Attuned|136061|p|-1||o||
414827|Ursine Rage|132941|p|-1||i||
414900|Corrupted Molten Fury Totem|135805|a|-1||o||
414907|Corrupted Molten Fury|136186|a|-1||o||
414908|Corrupted Molten Fury|134564|t|1||o||
414923|Feral Charge|135860|t|3||o||
415004|Unpowered|135894|p|-1||o||
415005|Powered|136057|p|30||o||
415058|Guarded by the Light|237537|p|15|magic|o||
415105|Power Surge|134337|p|10|magic|e||
415144|Mental Dexterity|136055|p|30||o||
415233|Ghost Wolf|136095|p|-1|magic|o||
415236|Healing Rain|136107|p|10||o||
415240|Healing Rain|136107|a|-1||o||
415292|Earthliving|237575|a|12|magic|o||
415320|Flanking Strike|132175|p|10||o||
415362|Raptor Fury|132253|p|30|frenzy|o||
415401|Sniper's Aim|236187|p|-1||o||
415414|Lock and Load|236185|p|20||o||
416837|Tame Adder|134010|p|600||o||
416861|Adder Pheromone|134743|p|600||i||
417057|Rejuvenation|136081|a|12|magic|o||
417058|Rejuvenation|136081|a|12|magic|o||
417059|Rejuvenation|136081|a|12|magic|o||
417060|Rejuvenation|136081|a|12|magic|o||
417061|Rejuvenation|136081|a|12|magic|o||
417062|Rejuvenation|136081|a|12|magic|o||
417063|Rejuvenation|136081|a|12|magic|o||
417064|Rejuvenation|136081|a|12|magic|o||
417065|Rejuvenation|136081|a|12|magic|o||
417066|Rejuvenation|136081|a|12|magic|o||
417068|Rejuvenation|136081|a|12|magic|o||
417141|Berserk|236149|p|15||o||
417146|Efflorescence|134222|a|-1||o||
417147|Efflorescence|134222|p|15||o||
417157|Starsurge|135730|p|15||o||
417192|Loa Altar|134232|p|-1||o||
417316|Meditation on the Loa|136077|p|14400||o||
417441|Thrash (Bear)|136168|t|15||o||
417448|Thrash (Cat)|135853|t|15||o||
417463|Near Death Experience|132331|p|300||o||
417803|Emberglow Vision|136215|p|300||o||
417856|Altar of the Light|135923|p|-1||o||
418232|Tame Rabbit|134010|p|600||o||
418236|Rabbit Musk|134743|p|600||i||
418334|Polymorph Cured|133937|p|300||o||
418441|Encroaching Leprosy|136182|p|-1|disease|o||
418442|Toxic Gas|136016|p|-1|poison|o||
418459|Meditation on Undeath|237569|p|14400||o||
418460|Chill of the Grave|237569|p|-1||o||
418506|Deep Rend|132090|t|24.5||o||
418508|Primal Bloodthirst|136012|p|-1||o||
418510|Moa'kin Band|136116|p|-1|magic|o||
419126|String of Ears|133854|p|-1||o||
419307|Meditation on Elune|136057|p|14400||o||
419308|Moonwell's Blessing|136057|p|-1||o||
420526|Frostbolt|135846|t|4|magic|o||
420536|Stealth|132320|p|4||o||
420543|On the Move|132120|p|-1||o||
420576|Adventure Admission|134392|p|-1||o||
420667|Horde Warbanner|132485|p|-1||i||
420744|Altar of Thorns|136104|p|-1||o||
420818|Desert Mirage|135994|p|-1|magic|o||
420825|Mirage|135994|p|-1|magic|o||
420843|Mirage Blink|135736|p|1||o||
420861|Creeping Nightmare|136186|a|-1||o||
420868|Dream Copy|136243|a|-1||o||
420877|Helping Hand|236248|p|-1||i||
420878|Helping Hand|135917|p|-1||i||
420964|Fishing Harpoon|135129|t|-1||i||
420998|Retribution Aura|135873|p|-1||i||
421041|No Steps Puzzle Aura|136243|p|-1||o||
421063|Path of no Steps|236168|p|-1||o||
421084|Path of no Steps|236168|p|1||o||
421239|Heretic Idol|237237|p|-1||o||
421248|Shadowguard|136051|a|600|magic|o||
421262|Hellish Indigestion|132108|p|10||i||
421311|Deer Musk|134743|p|600||i||
421312|Tame Deer|134010|p|600||o||
421322|Cursed Discovery|237561|p|-1||o||
421406|Battle Totem|134920|t|-1||i||
422397|Gnarled Harpoon|135129|t|-1||i||
422410|Malfunctioning|134070|p|-1||o||
422498|Sun's Blessing|236248|p|-1||o||
422549|Back to Work!|236365|p|10||o||
422598|Escape Plan|132307|p|-1||o||
422621|Preparation|136116|p|-1||o||
422746|Gillsbane|133044|p|-1||i||
422978|Coward!|132118|p|259200||o||
422996|Ancient Corrosive Poison|136016|t|15|poison|i||
423135|Sleep|132123|p|-1||o||
423191|Power of the Moon|136096|p|-1||o||
423192|Power of the Emerald Dream|136085|p|-1||i||
423194|Power of the Wild|236161|p|-1||i||
423253|Indiscriminate Outburst|132295|p|6||o||
423300|M'grrgl's Protection|237000|p|1800||i||
423434|Tim's Test Invis|136243|p|-1||o||i
423435|Tim's Test Invis Detection|136243|a|10||o||i
423478|Wyvern Taming Wand|135471|p|-1||i||
423481|Minor Stealth Detection|132150|p|-1||i||
423953|Impatient|298651|p|30||o||
424181|Twin Owl Aura|237178|a|100||o||
424182|Twin Owl Aura|237178|a|100||o||
424190|Unbalanced Idol|134903|t|12||i||
424308|Hidden Spirit|136243|p|-1||o||
424310|Eyes of the Owl|132150|a|3600||o||
424397|Summon Corrupt Spirit Beasts|136243|p|-1||o||
424472|Near Death Experience|132331|p|300||i||
424553|Call Your Shot|236188|p|-1||o||
424573|Wounded|136168|p|-1||o||
424574|Out of breath!|319458|p|9||o||
424785|Saber Slash|132375|t|12||o||
424919|Main Gauche|237531|p|5||o||
425098|Master of Subtlety|132299|p|-1||o||
425121|Icy Veins|135838|p|20|magic|o||
425124|Arcane Surge|135734|p|8||o||
425147|Quest Invisibility|136243|p|-1||o||
425204|Void Plague|237514|t|18|disease|o||
425205|Power Word: Barrier|253400|a|-1||o||
425218|Crazed|136215|p|604800||o||
425225|Fire Damage Check|135806|p|-1|magic|o||
425226|Burning|135818|p|10||o||
425234|Orbs of Shadow|132843|p|-1||o||
425235|Polished Iceblock|135835|t|180||o||
425239|Shadowy Chains|236296|t|15|magic|o||
425268|Renew|135953|a|15|magic|o||
425269|Renew|135953|a|15|magic|o||
425270|Renew|135953|a|15|magic|o||
425271|Renew|135953|a|15|magic|o||
425272|Renew|135953|a|15|magic|o||
425273|Renew|135953|a|15|magic|o||
425274|Renew|135953|a|15|magic|o||
425275|Renew|135953|a|15|magic|o||
425276|Renew|135953|a|15|magic|o||
425277|Renew|135953|a|15|magic|o||
425284|Spirit of the Redeemer|132864|p|10||o||
425294|Dispersion|237563|p|6||o||
425415|Enrage|136224|p|12||e||
425460|Dream Eater|136167|t|15||o||
425462|Dream Eater|136167|a|3||o||
425463|Demonic Grace|236293|p|6||o||
425467|Demonic Pact|237562|p|45|magic|o||
425600|Horn of Lordaeron|134229|p|120||i||
425714|Cobra Strikes|236177|p|30||e||
425718|Cobra Strikes|236177|e|30||o||
425728|Serpent Sting|132204|t|12|poison|o||
425729|Serpent Sting|132204|t|12|poison|o||
425730|Serpent Sting|132204|t|12|poison|o||
425732|Serpent Sting|132204|t|12|poison|o||
425733|Serpent Sting|132204|t|12|poison|o||
425734|Serpent Sting|132204|t|12|poison|o||
425735|Serpent Sting|132204|t|12|poison|o||
425736|Serpent Sting|132204|t|12|poison|o||
425737|Serpent Sting|132204|t|12|poison|o||
425798|Arena Fatigue|133645|p|7200||i||
425876|Decoy Totem|136069|p|10||o||
425887|Rot Bane|132155|p|-1||i||
425891|Scared|237552|p|5|magic|o||
425893|Grease-Matted Fur|237422|p|-1||o||
425894|Deep Rend|132090|t|24.5||o||
425895|Frost Breath|135848|t|6||o||
426019|Marshroom|134052|p|900||i||
426062|Quest Invisibility|136243|p|-1||o||
426080|Omni Diffusion Armor|134883|p|-1||o||
426084|Bulky Protective Ironweave|252173|p|-1||o||
426086|Electrostatic Discharge Shielding|133862|p|-1||o||
426097|Auxiliary Anti-Tamper Mechanism|132622|p|-1||o||
426101|Central Reaping Function 9000|237290|p|604800||o||
426162|Fanaticism|135905|a|12|magic|o||
426192|Diver Helm Test|133151|a|-1||o||i
426195|Vengeance|236299|p|20||o||
426199|Shadow Crash|136201|a|-1||o||
426223|Shadowform|136221|p|-1||o||
426301|Grimoire of Synergy|133738|e|-1|magic|o||
426303|Grimoire of Synergy|236292|a|15||o||
426320|Shadowflame|236302|t|15|magic|o||
426325|Shadowflame|236302|t|8|magic|o||
426489|Manifesting Dreams|132123|p|-1||o||
426490|Rallying Cry|132339|p|10||o||
426495|Shadowy Chains|236296|t|30|magic|o||
426604|Rebooting|135860|p|7||o||
426606|Speak with the Dead?|134799|p|7200||i||
426640|Offering of Blood|136168|p|20||i||
426694|Bear Form|132276|p|-1||o||
426764|Only Pain|237567|p|-1||o||
426811|Battlefield Inspiration|132484|p|-1||o||
426917|Nature Form|136074|p|-1||o||
426923|Fire Form|135819|p|-1||o||
426925|Water Form|135861|p|-1||o||
426940|Rampage|132352|p|30||o||
426969|Taste for Blood|236276|p|9|magic|e||
426972|Vigilance|236318|a|1800||o||
426979|Sword and Board|236315|p|5||e||
427066|Enrage|136224|p|12||e||
427086|Battlefield Genius|255131|p|-1||o||
427087|Battlefield Genius|255131|p|-1||o||
427088|Battlefield Genius|255131|p|-1||o||
427089|Battlemaster Supreme|255132|p|-1||o||
427090|Battlemaster Supreme|255132|p|-1||o||
427091|Battlemaster Supreme|255132|p|-1||o||
427116|Battlefield Genius|255141|p|-1||o||
427117|Battlefield Genius|255141|p|-1||o||
427118|Battlefield Genius|255141|p|-1||o||
427119|Battlefield Genius|255142|p|-1||o||
427120|Battlefield Genius|255142|p|-1||o||
427121|Battlefield Genius|255142|p|-1||o||
427143|Curse of Vulnerability|132094|t|15|curse|i||
427592|Scarlet Initiate's Uniform|132665|p|-1||i||
427625|Corrosion|132848|a|-1||o||
427714|Backdraft|236290|p|15||e||
427717|Unstable Affliction|136228|t|18|magic|o||
427719|Unstable Affliction|135975|a|5|magic|o||
427726|Immolation Aura|135802|p|-1||o||
427750|Cleansing Pool|132852|p|-1||o||
427751|Cleansing Pool|132852|p|-1||o||
427753|Corrosion|132848|p|-1||o||
427774|Crushing Darkness|237567|p|-1||o||
428238|Dark Ritual|136194|p|600||o||
428279|Dark Ritual Failed|136194|p|300||o||
428482|Shadow Seep|136181|a|-1||o||
428483|Shadow Seep|132851|p|-1||o||
428489|Planar Shift|136164|p|6||i||
428708|Frenzied Regeneration|132091|p|10||o||
428710|Elemental Instability|136028|p|-1||o||
428713|Barkskin|136097|a|15|magic|o||
428726|Focus Fire|135548|p|20||o||
428728|Frenzy|132152|p|10|frenzy|o||
428732|Corrosive Pool|136030|p|-1||o||
428733|Corrosive Pool|136030|a|-1||o||
428739|Deep Freeze|236214|t|5|magic|o||
428741|Molten Armor|132221|p|1800||o||
428865|Blinked|135736|p|10||o||
428878|Balefire Bolt|135809|p|30||o||
428895|Temporal Anomaly|135782|p|15||o||
428912|Light's Grace|135931|p|15|magic|e||
428996|Tim's Test Sanctuary|237554|p|-1||o||i
429125|Icy Veins|135838|p|20|magic|o||
429168|Corrosive Blast|132104|p|5||o||
429327|Aku'mai Phase Transition|136243|p|60||o||
429328|Aku'mai Phase Transition|136243|p|2||o||
429350|Destroy The Box - After Phase|135949|p|-1||o||
429356|Void Blast|136201|p|5||o||
429391|Pool of Shadow|132851|p|-1||o||
429394|Pool of Shadow|132851|a|-1||o||
429407|Bough of Shadows|237567|p|-1||i||
429541|Dark Protection|236407|p|-1||o||
429687|Dominate Mind|136206|t|15|magic|o||
429688|Dominate Mind|136206|t|10|magic|o||
429823|Moonfire|136096|t|12||o||
429836|Anointed By Light|236247|p|-1||o||
429856|Summon Sentinel Nightsaber|132225|p|-1||i||
429857|Summon Outrider Wolf|132266|p|-1||i||
429867|Void Madness|136221|p|10||i||
429868|Void Madness|136221|p|10||i||
429958|Blackfathom Teleporter Activation Visual|136243|p|-1||o||
429959|Well-Rested|132802|p|7200||o||
430025|Demonic Grace|236293|p|6||o||
430139|Arcane Charge|135734|p|1800||o||
430352|Ashenvale Rallying Cry|136005|p|7200||i||
430420|Anointed By Elune|236247|p|-1||o||
430421|Anointed By The Loa|236247|p|-1||o||
430422|Anointed By Undeath|236247|p|-1||o||
430432|Battle Hardened|136004|p|-1||i||
430491|WoW Variety Show - Health Drain!|237552|t|300||o||
430492|WoW Variety Show - Healthy Competition!|237554|t|300||o||
430493|WoW Variety Show - Unhealthy!|237555|t|300||o||
430494|WoW Variety Show - Blazing Speed!|135788|t|300||o||
430495|WoW Variety Show - Lethargy!|136091|t|300||o||
430496|WoW Variety Show - The Winds of Inspiration!|135833|t|300||o||
430497|WoW Variety Show - Back to Goldshire!|236761|t|300||o||
430499|WoW Variety Show - Back to Razor Hill!|236756|a|300||o||
430723|Triple Puncture|132155|t|15||o||
430947|Boon of Blackfathom|236403|p|7200||o||
430948|Arcane Recovery|237551|p|1800|magic|i||
430949|Arcane Accuracy|136099|p|1800|magic|i||
430950|Arcane Protection - Fire|135806|p|1800|magic|i||
430951|Arcane Protection - Frost|135779|p|1800|magic|i||
430952|Arcane Power|136115|p|1800|magic|i||
431060|Flight Insurance|134414|p|20||o||
431111|Boon of Blackfathom|236403|a|7200||o||
431567|Self-Found Adventurer|5588107|p|-1||o||
431606|Frenzy|132152|p|10||o||
431655|Mind Spike|136181|t|10|magic|o||
431666|Surge of Light|135981|p|15|magic|e||
431681|Void Zone|132886|p|10||o||
431688|Void Zone|132886|a|-1||o||
431839|Off Balanced|252175|a|-1||o||
431946|Gear Toss|134063|p|30||o||
432041|Tidal Waves|237590|p|20|magic|e||
432062|The Claw!|236316|p|2||o||
432064|The Claw!|236316||10||o||
432069|Tangled Causality|237432|p|300||o||
432143|Lightning Shield|136048|p|3||o||
432144|Lightning Shield|136048|p|3||o||
432145|Lightning Shield|136048|p|3||o||
432146|Lightning Shield|136048|p|3||o||
432147|Lightning Shield|136048|p|3||o||
432148|Lightning Shield|136048|p|3||o||
432149|Lightning Shield|136048|p|3||o||
432268|Honor Among Thieves|236275|p|1||o||
432275|Carnage|236268|t|-1||o||
432308|The Claw!|236316|t|10||o||
432330|Channel|136194|p|-1||o||
432467|Transform|132368|t|0.5||o||
433251|Static Arc|237587|t|20||o||
433255|Shamanistic Rage|136088|p|15||o||
433273|Sand Vortex|136018|p|-1||o||
433357|Coming of the Storm|237589|p|-1||o||
433359|Magnetic Pulse|135768|t|12||o||
433427|Squall-breakers Potion|134800|p|1800||i||
433546|Radiation Burn|136145|t|15|disease|o||
433551|Give Water|134800|a|60||i||
433672|Loathing|136214|t|3||o||
433797|Bladestorm|236303|p|7||o||
433804|Blood for the Blood Loa|237513|p|-1||o||
433813|Neverending Soul Vessel|133254|p|20|magic|i||
433819|Green Holiday Hat Visual|0|p|-1||o||p
433834|Red Holiday Hat Visual|0|p|-1||o||p
434165|Irradiated Cloud|132099|a|-1||o||
434166|Irradiated Cloud|132099|p|-1||o||
434312|Deadly Poison|132290|t|12|poison|o||
434313|Deadly Poison II|132290|t|12|poison|o||
434314|Deadly Poison III|132290|t|12|poison|o||
434315|Deadly Poison IV|132290|t|12|poison|o||
434316|Deadly Poison V|132290|t|12|poison|o||
434356|Charged|252174|p|10||o||
434399|Toxic Emission|136030|p|-1||o||
434409|Green Holiday Hat Visual|0|p|-1||o||p
434416|Red Holiday Hat Visual|0|p|-1||o||p
434433|Sludge|236271|p|300||o||
434443|Pyroblast|135808|t|12||o||
434488|Spicy!|136196|p|30||i||
434508|Reindeer|133749|p|-1||o||
434724|Radiation Sickness|132099|t|-1|disease|o||
434754|Polymorph|133978|t|20|magic|i||
434837|Puncture Armor|132109|t|30||i||
434841|Mekkatorque's Arcano-Shredder|135990|t|20|curse|i||
434851|Minor Evocation|136075|p|4||i||
434869|Shadow Ritual of Sacrifice|136194|p|5||o||
434907|Amplified Circuitry|133874|p|15|frenzy|o||
434927|Ambient Radiation|135799|p|-1||o||
434941|Toxic Vigor|237535|t|30||o||
434942|Irradiated Cloud|237535|p|-1||o||
434947|Irradiated Cloud|237535|p|-1||o||
435081|Beastly Effigy|134912|p|-1||o||
435112|Vengeance|236299|p|20|magic|o||
435117|Meditation on the Abyss|136077|a|30||o||
435167|Miniaturized Combustion Chamber|236220|p|10||i||
435168|Guard of the Innovator|135733|p|1800||o||
435169|Poison Cloud|136077|t|15|poison|i||
435180|Water of Elune'ara|132852|p|-1||i||
435204|Cooling Down|135852|p|1.5||o||
435205|Pyromantic Mishap|135826|p|-1||o||
435218|Offering to the Wind Spirit|133291|p|30||i||
435359|Hardened to the Core|133018|p|10||i||
435428|Danger!|132118|a|-1||o||
435445|DNT SF Phase|132886|p|-1||i||i
435450|Rune Scrying|136208||-1||o||
435546|Danger!|132118|a|-1||o||
435548|Danger!|132118|a|-1||o||
435563|Comprehension|135933|p|3600||i||
435869|Jani's Blessing|136243|p|-1||i||
435892|Burned Alive|135818|p|-1||o||
435893|Gniodine Side Effect|135446|a|60||i||
435895|Gniodine Dispel|135446|a|5||i||
435896|Cluck Cluck??|135996|p|5||o||
435897|Whirlwind Backfire|132369|p|9||o||
435899|Gyroscopic Acceleration|132999|p|20||o||
435901|Retricutioner|136235|p|-1||e||p
435968|Ez-Thro Radiation Bomb|132100|t|10|magic|i||
435973|Mildly Irradiated|132108|p|20||i||
435978|Energized Hyperconductor|136099|p|10|magic|s||
435986|Trogg Transfigurator 3000|132288|p|300||i||
435991|Entangling Roots|136100|t|9|magic|o||
436027|Grubbis Mad!|132318|p|5||o||
436041|World Shrinker|135981|p|300|magic|i||
436059|Radiation?|135867|p|3||o||
436068|Radiation?|135867|t|600||o||
436074|Trogg Rage|132277|p|10|frenzy|o||
436097|Blood Moon|236364|p|-1||o||
436100|Petrify|132154|t|8|magic|o||
436103|Sooty|133849|p|300||i||
436288|Mottled Blood Raptor|132253|p|-1||i||
436289|Ivory Raptor|132253|p|-1||i||
436327|Bengal Tiger|132242|p|-1||i||
436329|Golden Sabercat|132242|p|-1||i||
436332|Exsanguination|132090|t|30||i||
436351|Zandalari Ward|236456|p|-1||o||
436365|Two-Handed Mastery|135792|p|10||o||
436373|Sanguine Sanctuary|135966|a|20||i||
436374|Infernal Pact|136225|e|4||i||
436376|Chain Heal Cost Reduced|136052|p|20||o||
436378|Tigerblood Talisman|136168|e|4||i||
436387|Blessing of the Blood Loa|236413|p|7200||i||
436390|Decoy Totem|136069|p|-1||o||
436391|Decoy Totem|136075|a|10|magic|o||
436412|Discoverer's Delight|1120721|p|-1||o||
436430|Avenging Wrath|136224|p|15||o||
436432|Trail Snack|136075|p|12||i||
436437|Commander|236587|p|120||o||
436444|Veteran of the Third War|136002|p|-1||o||
436471|Bloodlash|237515|p|15|magic|i||
436473|Stun|133477|t|2||i||
436475|Longsight|132327|p|-1||o||
436482|Bloodbark Cleave|236164|p|20||i||
436508|TEST DEVELOPER DEBUG SPELL|135724|p|20||o||i
436513|TEST DEVELOPER DEBUG SPELL|135724|p|20||o||i
436514|TEST DEVELOPER DEBUG SPELL|135724|p|20||o||i
436515|TEST DEVELOPER DEBUG SPELL|135724|p|20||o||i
436516|Chronostatic Preservation|135729|a|20||o||
436534|Defense Protocol: Goodbye|236171|t|10||o||
436537|GM Freeze|136090|p|10||o||
436563|DNT Void Phase|132886|p|-1||i||i
436641|Blood Moon Copy|236364|p|-1||o||
436693|Explosive Egg|133717|p|-1||o||
436739|Cluck!|135996|a|15||o||
436741|Overheat|133862|a|15||o||
436816|Sprocketfire Breath|135805|p|5||o||
436817|Sprocketfire Breath|135805|a|-1||o||
436821|Slag Embers|132386|p|-1||o||
436823|Slag Embers|132386|a|-1||o||
436825|Frayed Wiring|237587|a|15||o||
436828|Binary Bleat|136071|t|10||o||
436829|Static Fleece|135860|p|-1||o||
436831|Static Fleece|135860|a|1|magic|o||
436835|Nutty Shield|132360|p|-1||o||
436837|Widget Fortress|252184|a|-1||o||
436937|Regrowth|136085|a|21|magic|o||
436938|Regrowth|136085|a|21|magic|o||
436939|Regrowth|136085|a|21|magic|o||
436940|Regrowth|136085|a|21|magic|o||
436941|[DNT] Monastery Bust Active|136115|p|-1||o||i
436942|Regrowth|136085|a|21|magic|o||
436943|Regrowth|136085|a|21|magic|o||
436944|Regrowth|136085|a|21|magic|o||
436945|Regrowth|136085|a|21|magic|o||
436946|Regrowth|136085|a|21|magic|o||
436981|[DNT] Monastery Bust Failed|136115|p|-1||o||i
437002|Paladin's Lament|134503|p|-1||o||
437132|Dreamstate|136111|t|12|magic|o||
437146|Mage's Lament|134503|p|-1||o||
437147|Warrior's Lament|134503|p|-1||o||
437148|Priest's Lament|134503|p|-1||o||
437324|Deep Slumber|136135|p|15||o||
437327|Charged Inspiration|236219|p|12||i||
437340|Radical Rad Resistance|136030|p|3||i||
437349|Gneuro-Logical Shock|237587|p|10||i||
437353|Corrosive Breath|136016|t|20||o||
437357|Gneuromantic Meditation|136090|p|20||i||
437362|Hyperconductive Shock|237587|p|10||i||
437367|Razor-Sharp Gears|136235|p|-1||i||p
437377|Intense Concentration|136125|p|10||i||
437382|Reinforced Willpower|134340|p|10||i||
437390|Lethargic Poison|132107|t|15|poison|o||
437410|Deep Slumber|136090|p|20||o||
437425|Lethargic Poison|132107|t|15|poison|o||
437479|Carrion Swarm|136128|a|20||o||
437532|Screeching Fear|136195|t|8|magic|o||
437585|Pillars of Might|136025|p|60||o||
437617|Demolishing Smash|135860|p|2||o||
437622|Prey on the Weak|136122|p|-1||o||
437698|Coin Flip|252172|p|30||o||
437699|Coin Flip|132307|p|30||o||
437711|Blood Drive|136124|p|4||o||
437713|Blood Craze|136218|p|-1||o||
437716|Primal Bloodthirst|136012|p|2||o||
437739|Suppressing Darkness|136194|a|-1||o||
437751|Bruised|132311|p|1800||o||
437764|Consume|136020|p|12||o||
437791|Ritual Leader|135883|p|-1||o||
437799|String of Ears|133854|p|-1||o||
437801|Light's Hope|135878|a|-1||o||
437802|Light's Hope|135878|p|-1||o||
437809|Holy Fire|135972|t|10|magic|o||
437813|Screeching Frenzy|136224|p|30|frenzy|o||
437846|Infernal Presence|136219|p|-1||o||
437847|Mortal Lash|136160|t|12||o||
437868|Agonizing Weakness|136139|t|16|curse|o||
437877|Infusion of Light|135973|p|-1||o||
437881|Infusion of Shadow|237532|p|-1||o||
437888|Summom Bomb Periodic|133712|p|-1||o||
437891|Holy Strike|135924|t|30||o||
437915|Hammers of Justice|135963|t|6|magic|o||
437921|Mass Penance|237545|p|3||o||
437922|Infernal Presence|136219|a|-1||o||
437927|Shadow Sermon: Pain|136207|t|12|magic|o||
437928|Psychic Scream|136184|t|6|magic|o||
437930|Power Word: Shield|135940|p|20|magic|o||
437933|Summon Infernal|135860|t|4||o||
437984|Circle of Domination|136206|a|6||o||
437987|Circle of Domination|136206|a|15||o||
438089|Poison Dart|236200|t|30|poison|o||
438101|Devour|132103|t|10||o||
438136|Nauseous Gas|132099|t|2||o||
438142|Gunk|132104|t|20|disease|o||
438170|Suppressing Darkness|136194|p|-1||o||
438262|Channel|136099|p|-1||o||
438273|PvP Trinket|135894|p|0.1||i||
438288|Dark Presence|237534|p|-1||o||
438295|Ariden's Sigil|136243|p|-1||i||
438341|Renew|135953|a|20|magic|o||
438487|Ride Vehicle|136243|a|-1||o||
438501|Inevitable Doom|134372|t|10||o||
438505|Mech Pilot Transform (Red)|132996|p|-1||o||
438536|Spark of Inspiration|236424|p|7200||o||
438537|Spark of Inspiration|236424|a|7200||o||
438538|Charge|132337|p|1||o||
438541|Charge|132337|p|1||o||
438551|Feast of Blood|132334|t|20||o||
438602|Mech Pilot Transform (Blue)|132996|p|-1||o||
438603|Mech Pilot Transform (Green)|132996|p|-1||o||
438604|Mech Pilot Transform (Gray)|132996|p|-1||o||
438710|Sprocketfire|133862|a|30||o||
438714|Furnace Surge|236188|a|10||o||
438715|Furnace Surge|133862|p|10||o||
438718|Incendiary Bomb|252172|a|-1||o||
438720|Freezing|135848|a|30|magic|o||
438721|Frozen Solid|135841|a|30|magic|o||
438727|Radiation Sickness|132099|a|-1|disease|o||
438732|Toxic Ventilation|136030|t|-1||o||
438735|High Voltage!|237290|a|30||o||
439155|Sigil of Innovation|254884|p|1800|magic|i||
439471|Sebacious Poison|132108|t|15|poison|e||
439472|Numbing Poison|132098|t|15|poison|e||
439473|Atrophic Poison|132100|t|15|poison|e||
439733|Tree of Life|132145|p|-1||o||
439745|Tree of Life|132145|p|-1||o||
439748|Starfall|236168|p|10||o||
439958|Kill, Maim, Bleed!|132094|t|30||o||
439959|Lesser Arcane Elixir|134730|p|1800||i||
440014|Sprocketfire|133862|a|15||o||
440028|Nutty Shield|132360|p|-1||o||
440072|Ghostly|135864|a|-1||o||
440114|Sudden Death|132346|p|10||e||
440213|Fury of the Blood Loa|236226|p|300||o||
440414|Widget Volley|134520|t|30||o||
440483|Enrage|136224|p|12||o||
440488|Shockwave|236312|t|4||o||
440505|Invisibility|134798|p|30||i||
440531|Hit and Run|132171|p|15||e||
440574|Earthgrab|136100|t|5|magic|o||
440586|Bash|132114|t|2||o||
440589|Twin Howl|132130|p|6||o||
440591|Spirit Walk|132328|p|15||o||
440656|High Voltage!|133860|a|0.5||o||
440668|Vindication|135985|p|30|magic|o||
440675|Righteous Judgement|236260|t|8|magic|o||
440720|Scooty's Not-Quite-Divine Shield|252184|p|30||o||
440809|Frozen Orb|135851|t|5||o||
440813|Frozen Orb|135851|a|-1||o||
440841|Ward of the Dead|136232|p|-1||i||
440882|Infernal Armor|236418|p|10|magic|o||
440895|Mark of Chaos|136226|p|10|magic|o||
441100|Ride Kaiju|236192||-1||o||
441215|Ride Meka|387415||-1||o||
441448|Charged|132536|a|5||o||
441453|Electrified Net|132149|t|10||o||
441739|Ghostly|135864|a|-1||o||
441785|Drained of Blood|236363|p|20||o||
442225|Static Arc|237587|a|20||o||
442226|Menace|136214|t|3||o||
442233|Menace|136214|t|3||o||
442622|Acid Breath|136007|t|45||o||
442947|Feeling much better, thank you!|237554|p|-1||o||
442948|Blessing of Protection|135964||10|magic|o||
443265|Infernal Lasso|136091|t|12|magic|i||
443278|Seed of Renewal|236155|p|-1||i||
443302|Emerald Ward|136030|p|-1||o||
443320|Loyal Beta|132224|p|1800||o||
443369|Chronostatic Preservation|237432|p|20||o||
443469|[DNT] Grow Healing Blossom|236160|p|-1||o||i
443630|PvP Trinket|135894|p|0.1||o||
443678|Seed of Renewal|236160|t|30||i||
443813|High-Yield Radiation Bomb|132100|a|10|poison|o||
443856|Caustic Overflow|135794|p|-1||o||
443917|Tides of Blood|134086|p|-1||o||
443953|Bubbling Blood|237513|p|10||o||
443964|Spirit Chains|132097|t|8|curse|o||
443975|Spirit Chains|342917|t|18|curse|o||
443990|Frightsome Howl|136183|t|4|magic|o||
444039|Insanity|236299|t|20|magic|o||
444046|Curse of Tongues|136140|t|15|curse|o||
444165|Skeletal|136187|t|6||o||
444255|Corrupted Blood|136133|a|600||o||
444273|Corrupted Blood|136133|p|60||o||
444285|Corrupted Blood|136133|a|60||o||
444290|Corrupted Blood|136133|a|60||o||
444509|Shield of the Elements|136027|p|-1||i||
444522|Threatening Roar|237552|t|30||o||
444758|Emerald Nightmare|134157|p|-1||o||
444759|Emerald Nightmare|134157|p|-1||o||
444760|Emerald Nightmare|134157|p|-1||o||
444762|Emerald Nightmare|134157|p|-1||o||
444892|Deathly Chill|135834|t|45||o||
444893|Shadow Ritual|136121|p|-1||o||
444895|Holy Smite|135924||21||o||
444938|Parasomnia|134414|p|-1||o||
444975|Statue Empowerment|237237|p|-1||o||
445080|Incite Madness|132345|t|15||o||
445081|Burning Madness|132345|p|600|magic|o||
445158|Lucid Dreaming|136233|p|-1||o||
445181|Murky Sapta Sight|132092|p|1200|magic|i||
445190|[DNT] Sleeping Copy|136243|a|-1||o||i
445282|Disarm|132343|t|10||o||
445284|Fervor|135727|p|2||o||
445442|[DNT] AoE Damage Reduction|136243|p|20||o||i
445461|Test - Duel Talent - Grant Talent Groups|136243|p|30||o||i
445498|Bellowing Roar|134154|t|6|magic|o||
445522|Imp on a Mission|136164|p|1200||o||
445551|Devour|132103|p|-1||o||
445555|On Fire!!|135818|p|10||o||
445801|Prismatic Shell|134964|p|600||o||
445853|[DNT] Dream Portal|136243|p|-1||o||i
445867|Recurrent Nightmare|136127|t|300|disease|o||
445870|Eye of Ysera|136155|p|45||o||
445875|Gloom|136194|p|6||o||
445914|[DNT] Flower Growth|136243|p|-1||o||i
445940|Unstable Cask|134798|t|2||o||
446069|Tame Groddoc Infant|133980|p|600||o||
446070|Tame Groddoc Infant|133980|p|600||o||
446088|Leyline Attunement|132841|t|7200||o||
446091|Aura of Paralyzing Dread|136147|p|-1||o||
446092|Gneurostatic Protection|236225|p|-1||i||
446093|The Nightmare|135747|p|-1||o||
446097|Nightmare Resonance Crystal|134108|p|3600||i||
446098|Unorthodox Hex Stick|236197|p|300||i||
446100|Inanimate|132622|p|300||i||
446103|Blood Loa's Blessing|236413|p|-1||o||
446104|Atal'alarion's Enchanted Boulder|298678|p|300||i||
446106|Gun Axe Shot|134538|t|10||i||
446150|DNT SF Phase|132886|p|-1||o||i
446219|Cries of Corrupted Ancestry|134919|p|12||i||
446228|Nightmarish Power|136225|p|3600||i||
446231|Serpent's Ascension|135461|p|12||s||
446240|Sigil of Living Dreams|254882|p|1800|magic|i||
446256|Atal'ai Mojo of Forbidden Magic|236885|p|7200||i||
446274|Dream Fog|136006|a|7||o||
446275|Dream Fog|136006|p|-1||o||
446286|Relentless Strength|132109|p|20||o||
446287|Unbound Soul|135767|p|8||o||
446288|Elune's Favor|135900|p|10||o||
446289|Relentless Strength|136235|p|20||i||p
446292|Sorrowful Wilting|136155|p|45||o||
446294|Virulent Breath|136182|t|15|poison|o||
446296|Wake Up Dead|136090|p|5||o||
446297|Unrestrained Power|136235|p|20||i||p
446299|Familiar Chaos|136218|p|1||o||
446301|Conceptualize Dreamscapes|133785|p|-1||o||
446305|Unrestrained Power|135990|p|20||o||
446310|Fragile Armor|136235|p|20||i||p
446311|Slime Time|132104|p|-1||o||
446313|Fragile Armor|136162|p|20||o||
446319|Triple Bolt|136016|t|6|poison|o||
446322|Emerald Shroud|135994|p|20|magic|i||
446327|Enrage|136224|p|15||i||
446335|Voodoo Frenzy|298678|p|10||o||
446336|Atal'ai Mojo of War|236882|p|7200||i||
446354|Shield Slam|132357|t|2||o||
446356|Improved Blocking|135806|p|6||o||
446362|Curse of Blood|136189|t|600|curse|o||
446364|Frailty|136119|t|60|magic|o||
446373|Corrupted Slam|135860|a|2||o||
446382|Attuned to the Void|132886|p|15||i||
446383|[DNT] Troll Object - Drum Death|136243|p|-1||o||i
446391|Torment|236295|t|3|magic|i||
446396|Atal'ai Mojo of Life|236883|p|7200||i||
446397|Rainbow Generator|237185|a|25||i||
446398|Perceive|236709|p|2||i||
446448|Duty of the Warden|132145|a|-1||o||
446456|Anvilrage Armor|133233|p|600||o||
446460|Warden of Life|236166|p|-1||o||
446461|Warden of Spirit|236166|p|-1||o||
446466|Fire Crown|132839||121200||o||
446467|Mark of the Warden|236157|p|-1||o||
446468|Dreamer's Lament|136193|t|10||o||
446487|Corrupted Breath|136007|t|20||o||
446506|Spreading Corruption|134154|p|-1||o||
446528|Echoes of Madness|237561|p|10||i||
446541|Echoes of Insanity|237561|p|10||i||
446572|Echoes of the Depraved|237561|p|10||i||
446573|Plagued Shot|134925|t|16|disease|o||
446577|Echoes of Dread|237561|p|10||i||
446578|Dreamharvest|237554|t|30||o||
446580|Murky Sapta Sight|132092|p|1200|magic|i||
446581|Murky Sapta Sight|132092|p|1200|magic|i||
446582|Murky Sapta Sight|132092|p|1200|magic|i||
446586|Dizzying Spin|236303|p|3||o||
446597|Echoes of Fear|237561|p|10||i||
446618|Echoes of of the Damned|237561|p|10||i||
446630|Echoes of the Corrupt|237561|p|10||o||
446631|Spare Change|133784|t|2||o||
446639|Dessicated Dreams|136021|t|3|magic|o||
446685|Blood-crazed Spirit|132193|p|-1||o||
446687|Anguish of the Dream|134125|p|20||i||
446695|Fervor of the Temple Explorer|236368|t|7200||o||
446698|Fervor of the Temple Explorer|236368|a|7200||o||
446699|Gore|304501|p|3||o||
446702|Searing Gaze|136224|t|30||o||
446703|Keen Eyes|236484|p|-1||o||
446706|Roar of the Dream|132123|p|10||i||
446707|Parasomnia|136175|t|2|magic|i||
446709|Roar of the Guardian|136094|p|20||i||
446710|Roar of the Grove|237556|p|15||i||
446712|Roar of the Grove|237556|p|15||o||
446713|Food|134062|p|30||i||
446714|Drink|132794|p|30||i||
446716|Egg Thief|294479|p|-1||i||
446720|Stinky!|132104|p|120||i||
446722|Call of the Arena|133790|p|15|magic|i||
446728|Judgement of the Loa|135963|t|6|magic|o||
446729|Troll Speed|132307|p|10||i||
446731|Headhunter's Barbed Spear|135129|t|5||i||
446733|Sleepwalk|136152|t|10||o||
446762|[DNT] Dream Fog|136243|p|-1||o||i
446806|Sunken Hex|237237|p|300||i||
446860|Emerald Nightmare|132101|p|-1||o||
446888|Totem Challenge|136092|p|120||o||
446912|Dreamscape|237188|p|2.5||o||
447259|Charged Air|136075|p|-1||o||
447267|Static Buildup|135990|p|10||o||
447302|Emerald Nightmare|132101|p|-1||o||
447397|Rift-ripping Roar|134157|t|2||o||
447409|Emerald Nightmare|132101|p|-1||o||
447483|Satyr Corruption|136134|p|-1||o||
447544|Dizzy|236695|p|2||o||
447548|Twisted Tranquility|136107|p|10||o||
447549|Feedback|136189|p|35|magic|o||
447550|Emerald Nightmare|132101|p|-1||o||
447554|Undying Slumber|136090|p|-1||o||
447555|Chest Pains|136119|p|3||o||
447563|Blind|136175|p|30|poison|o||
447578|Gloom|136194|t|1||o||
447579|Gloom|136194|t|2||o||
447581|Gloom|136194|t|2||o||
447585|Creeping Nightmare|136125|t|24||o||
447588|Wake Up Dead|136091|t|8||o||
447589|Deafening Screech|132339|t|2||o||
447590|Infernal Lasso|136091||24|magic|i||
447591|Undying Fel Fire|135794|p|-1||o||
447890|Wake Up Dead|136090|t|0.5||o||
447891|Bash|135234|t|2||o||
447892|Skin of Rock|132154|p|8|magic|o||
447894|Sting of the Serpent|136070|t|20|poison|i||
448084|Restless Dreams|136225|p|3600||i||
448107|Blood Howl|136168|t|15|magic|o||
448156|Spare Change|133784|p|-1||o||
448283|[DNT] Cosmetic - Alpha Fade 0.2|136116|p|-1||o||i
448406|Lledra's Vehicle Test [DNT]|136243|p|-1||o||i
448415|Lledra's Vehicle Test [DNT]|132622|p|-1||o||i
448450|Lledra's Vehicle Test [DNT]|136243|p|-1||o||i
448471|Lledra's Vehicle Test [DNT]|132622|a|-1||o||i
448510|[DNT] Fel Portal Visual Aura|136116|p|-1||o||i
448572|Sleep|136090|t|30|magic|i||
448573|Triple Bolt|135781|t|5|magic|o||
448574|Triple Bolt|136190|t|3||o||
448575|Triple Chomp|132270|p|3.5||o||
448603|[DNT] Wing Buffet Visuals Test - Stalker|136243|p|-1||o||i
448614|Bargain Bush|236153|p|300||i||
448618|Empty Supply Crate|132622|p|300||i||
448642|Dreamharvest|237554|t|3||o||
448653|Dreamharvest|237554|p|30||o||
448686|Zila Gular|132887|p|20||i||
448779|Wake Up Dead|136090|p|4||o||
448824|Devour|132103|p|-1||o||
448828|Overdrive|133002|p|6||o||
448995|Rune Scrying|136212||-1||o||
449005|Shrine of the Watcher|237298|p|-1||o||
449006|Voidsight|237298|p|14400||o||
449009|Protected by Shadows|134971|p|-1||o||
449011|Fire Crown|236202|p|-1||o||
449014|Fire Crown|236202|t|600||o||
449379|Decay|237170|p|-1||o||
449409|Voodoo Frenzy|298678|p|10||o||
449432|Curse of Doom|136122|t|60|curse|o||
449669|Retribution Aura|135873|p|-1||o||
449825|Out of Bounds|136212|p|10||o||
449869|Corrosive Acid Breath|136007|t|30||o||
449879|Dream Fog|136090|a|6||o||
449907|Arcane Explosion|136116|t|24|magic|o||
449920|Malevolence|236299|t|30|magic|s||
449923|Benevolence|237550|p|15|magic|s||
449925|Power Shredder|236161|p|10||s||
449927|Blood Corruption|236305|t|15||s||
449932|Fiery Strength|236290|p|12||s||
449934|The Furious Storm|136014|p|10|magic|s||
449975|Stalwart Block|236307|p|6||s||
449982|Libram of Holy Alacrity|236261|p|10||i||
450005|Spare Change|133784|t|2||o||
450013|Shadow Spark|136196|p|12||s||
450084|Rapid Cutting|132376|p|15||s||
450085|Fire Crown|132277||300||o||
450108|Mind Vision|135934|p|60||o||
450600|Hex|136071|t|10|magic|o||
450607|Wandering Plague|136127|t|300|disease|o||
450640|Wandering Plague|136127||300|disease|o||
450643|Volatile Infection|135914|t|120|disease|o||
450646|Shadow Word: Pain|136207|t|18|magic|o||
450654|Shadow Shield|136121|p|30|magic|o||
450658|Renew|135953|a|20|magic|o||
450662|Sleep|136090|t|20|magic|o||
450667|Stealth|132320|p|-1||o||
451398|Fire Crown|236202|p|14400||o||
452454|Boon of Water|136037|p|120||o||
452456|Boon of Air|236154|p|120||o||
452460|Boon of Fire|132221|p|120||o||
452464|Boon of Earth|237002|p|120||o||
452474|Defense of the Dragonflights|5904997|p|5||i||
452745|Dream Eater|237507|t|15||o||
452857|Knockdown|134982|t|2||o||
453341|[DNT] Overture|136243|t|-1||o||i
454042|Burn|135822|p|-1||o||
454204|Destination: Vosh'Aranas|255348|p|120||o||
454207|Destination: Cen'gar|255348|p|120||o||
454208|Destination: Niskara|255348|p|120||o||
454209|Destination: Zzalrukh|255348|p|120||o||
454210|Destination: Evasilier|255348|p|120||o||
455868|Revealed Weakness|236278|t|40|magic|e||
455987|Decisive Strike|135305|p|0.25||o||
455989|Decisive Strike|135400|p|0.25||o||
455991|Thunder Stomp|133031|p|0.35||o||
455994|Crescent Smash|135900|p|0.35||o||
456010|Higher Power|136075|p|10||o||
456195|Innervate|136048|p|20|magic|o||
456339|Ferocity|132180|p|8||e||
456344|Undead Slaying|254094|p|-1||o||
456347|Beast Slaying|298659|p|-1||o||
456348|Dragon Slaying|254650|p|-1||o||
456349|Elemental Slaying|254652|p|-1||o||
456352|Demon Slaying|236431|p|-1||o||
456360|Giant Slaying|254091|p|-1||o||
456361|Humanoid Slaying|236409|p|-1||o||
456382|Precision|236179|p|12||e||
456393|Stalked|132174|t|30||e||
456397|Evocation|136075|p|8||o||
456399|Selfless|252267|p|15||o||
456400|Noble|252268|p|15||o||
456401|Fool|252270|p|15||o||
456403|Molten Armor|132221|p|-1||o||
456496|Judgement of the Crusader|135924|t|10|magic|o||
456549|Melting Faces|136204|p|15|magic|e||
456694|[DNT] Frijidar Scale|136243|p|-1||o||i
456881|Diplomatic Immunity|132485|a|-1||o||
457191|Decisive Strike|135400|a|10||o||
457326|Hex|136071|p|-1|curse|o||
457331|Avoidance|132285|p|6||e||
457342|Clearcasting|136170|p|15|magic|e||
457437|Vanish|132331|p|10||o||
457469|Resilient|132356|p|10||e||
457534|Frostbitten|135988|p|300||o||
457558|Fire Trance|135831|p|10|magic|o||
457569|Banish|136135|a|20|magic|o||
457612|Decisive Strike|135305|a|10||o||
457613|Crescent Smash|135900|a|10||o||
457614|Thunder Stomp|135980|t|4||o||
457643|Soul Fire!|135831|p|10|magic|e||
457699|Echoes of Defensive Stance|132341|p|15||o||
457706|Echoes of Battle Stance|132349|p|15||o||
457708|Echoes of Berserker Stance|132275|p|15||o||
457814|Defensive Forecast|132360|p|15||o||
457816|Battle Forecast|132336|p|15||o||
457817|Berserker Forecast|132175|p|15||o||
457819|Echoes of Gladiator Stance|132341|p|15||o||
457851|Overconfidence|136088|p|60||o||
458176|[DNT] Stratholme Puzzle Aura|136115|p|-1||o||i
458285|Consecration|135926|p|8||o||
458312|Divine Protection|135954|p|9||o||
458321|Sandworm Submerge Visual|135830|p|-1||o||
458371|Divine Protection|135954|p|12||o||
458403|Stalker|132167|p|30||o||
458407|Eruption|136025|t|3||o||
458436|Wyvern Strike|135125|a|8||o||
458481|Wyvern Strike|135125|a|8||o||
458482|Wyvern Strike|135125|a|8||o||
458488|Astral Beacon|136243|p|-1||o||
458491|Attack|135280|t|45||o||
458590|Infinite Midnight|237566|p|-1||o||
458808|[DNT] Stratholme Clue Active|136115|p|-1||o||i
458809|[DNT] Stratholme Clue Failed|136115|p|-1||o||i
458819|Tim's Test Fireball|135812|t|10||o||i
458820|Occult Poison I|135935|t|12|poison|e||
458841|Sweltering Heat|135805|p|-1||o||
458842|Blistering Heat|135790|p|-1||o||
458843|Molten Heat|254652|p|-1||o||
458857|Divine Light|135981|a|15|magic|o||
458872|Infinite Midnight|237566|a|420||o||
458877|Infinite Midnight|237566|a|420||o||
458878|Infinite Midnight|237566|a|420||o||
458880|Disarm|132343|p|-1||o||
458881|Disarmed|132343|p|-1||o||
458882|Recycle|132354|t|11||o||
458902|Bulky Protective Ironweave|133596|p|-1||o||
458965|Interrupt|136243|p|60||o||
458979|Sand Bomb|237002|t|15||o||
458987|Summon Zotl|132182|p|-1||o||
459153|Fireworks|136235|p|4||o||p
459160|Teleport|135743|p|420||o||
459161|Omni Diffusion Armor|134883|p|-1||o||
459164|Reployer Malfunction|135805|p|2||o||
459165|Force Dampeners|134064|p|30||o||
459166|Central Reaping Function 9000|237290|p|1296000||o||
459170|Summon Squire|135942|p|-1||i||
459178|Self Explosion|133035|p|8||o||
459197|Bolster Girdle-Jerry Bolts|136075|p|2||o||
459198|Flex Tandem Press Task Apparatus|136075|p|2||o||
459200|Full-field System Flap Latch|136075|p|2||o||
459207|Summon Squire|135942|p|-1||i||
459232|Summon Squire|135942|p|-1||i||
459280|Transiting Realities|237556|p|10||o||
459290|Thunder Stomp|237552|t|7||o||
459293|Activate Auxiliary Anti-Tamper Grapplers|237499|p|24||o||
459360|Hanging Bat|132182|p|-1||o||
459481|Rumbling Sand|133878|t|1||o||
459499|Crippling Clip|136039|p|4||o||
459592|Cropchop|132369|p|10||o||
459610|Wanderer's Resolve|132107|a|7200||o||
459611|Astral Victory|135900|p|7200||o||
459612|Astral Perfect Victory|135900|p|-1||o||
459613|Guided Buoyancy Accelerant|134731|p|240|magic|i||
459614|Dedication|136012|p|-1||o||
459616|Rhythm of War|132353|p|-1||o||
459617|Legacy of Valor|135934|p|14400||o||
459618|Legacy of Valor|236666|p|120||o||
459619|Smite|236553|p|2940||o||
459622|Holy Fire|135924||21||o||
459837|Shadow Ritual of Great Sacrifice|136194|p|5||o||
459845|Shadow Ritual of Great Sacrifice|136194|p|5||o||
460084|Spectral Shout|132154|t|3||o||
460086|Spectral Shout|132154|t|8||o||
460119|Mortal Combo|132344|a|2||o||
460171|Defender's Resolve|132335|p|15||o||
460200|Defender's Resolve|132335|p|15||o||
460248|Spiritstorm|136243|p|-1||o||
460310|Shimmering Light|135864|p|-1||o||
460328|(DNT) Hellscream's Phantom Spooky Visuals|136243|p|-1||o||i
460332|Warmed Rumsey with Cream|132790|p|2700||i||
460338|Purged by Fire|133066|t|10||i||
460362|Protection of Kel'Thuzad|136120|p|-1||i||
460402|Abysmal Aura|236293|t|10||o||
460403|Kerosene Kick|252176|t|2.5||o||
460417|(DNT) Randomize Threat Target|136243|t|10||o||i
460455|Haste|136047|p|30||i||
460515|Corrupted Tears|132108|a|-1||o||
460545|Enshrouding Fog|132331|t|-1||o||
460585|Chaos Chopper|134427|p|-1||o||
460631|(DNT) Pyranis Add Fog Stealth|136243|p|-1||o||i
460658|Thorn Whip|134218|t|-1||o||
460673|Demonskin|237558|p|15|magic|o||
460684|Nature's Grip|136063|p|-1||o||
460690|Entangling Roots|136100|t|10|magic|o||
460692|Rain of Fire|136186|p|8||o||
460698|Rain of Fire|136186|p|8||o||
460699|Rain of Fire|136186|p|8||o||
460700|Rain of Fire|136186|p|8||o||
460703|Tender's Rage|132117|p|8|frenzy|o||
460725|Gloom|136194|p|8||o||
460726|Gloom|136194|t|1||o||
460727|Gloom|136194|t|4||o||
460750|Orbs of Shadow|132843|p|-1||o||
460755|Veil of Shadow|136160|t|15|curse|o||
460756|Sleep|136090|t|10|magic|o||
460759|Carrion Swarm|136045|a|5||o||
460760|Carrion Swarm|136045|p|-1||o||
460761|Carrion Swarm|136045|a|-1||o||
460764|Mannoroth's Fury|135802|p|-1||o||
460767|Berserker Charge|135860|a|2||o||
460845|Drawing Fire|136243|p|-1||o||
460848|Magma Spit|135821|t|30||o||
460856|Reflect Magic|132361|p|5|magic|o||
460858|Pyroblast|135808|t|8||o||
460860|Pyroblast|135808|t|12||o||
460862|Enrage|136243|p|-1||o||
460865|Sweltering Heat|236228|p|-1||o||
460866|Crushing Stone|132846|t|5||o||
460878|Heating Up|132847|p|-1||o||
460880|Flare|236228|p|-1||o||
460890|Melt Armor|135817|a|30||o||
460895|Heart of Cinder|135813|p|-1||o||
460898|Heart of Ash|134385|p|-1||o||
460899|Frigid Current|135854|p|-1||o||
460907|Demonic Frenzy|136146|p|10||o||
460931|Impending Doom|136179|t|10|magic|o||
460932|Lucifron's Curse|136123|t|300|curse|o||
460939|Might of Stormwind|135763|p|3600||o||
460940|Might of Stormwind|135763|a|3600||i||
460975|Drawing Fire|136243|p|-1||o||
461027|Drawing Fire|136243|p|-1||o||
461028|Drawing Fire|136243|p|-1||o||
461035|Drawing Fire|136243|p|-1||o||
461038|Drawing Fire|136243|p|-1||o||
461043|Sundering Shout|132366|t|30||o||
461046|Drawing Fire|136243|p|-1||o||
461053|Immolation Aura|135817|p|-1||o||
461055|Drawing Fire|136243|p|-1||o||
461061|(DNT) Check for dead Protectors|136243|p|-1||o||i
461062|Pool of Fire|135826|a|-1||o||
461075|(DNT) Check for dead Protectors|136243|p|5||o||i
461087|Inferno|135818|p|8||o||
461090|Living Bomb|132863|t|8||o||
461103|Living Fallout|135826|a|-1||o||
461105|Living Bomb|132863|t|8||o||
461110|Inferno|135818|p|8||o||
461111|Inferno|135818|a|-1||o||
461113|Duke's Domain|132852|a|-1||o||
461120|Treading Water|135863|p|600||i||
461121|Armageddon|135826|p|-1||o||
461125|Panic|136147|t|8|magic|o||
461137|Oath of the Sea|135862|p|300||i||
461140|Magma Pool|135818|p|-1||o||
461146|Magma Spit|135821|t|30||o||
461152|Flame Wrath|135826|p|15||i||
461155|Mark of Korth'azz|136172|t|60||o||
461196|Hot Blooded|237553|p|-1||o||
461197|Eruption!|135919|p|-1||o||
461217|Conflagration|135807|a|30||o||
461224|Demon-Tainted Blood|136150|p|20||i||
461226|Heart of the Treant|252271|p|30||i||
461227|Guardian of Nature|134217|p|20||i||
461232|Gehennas' Curse|136160|t|300|curse|o||
461235|Moonstalker Fury|133236|p|15||i||
461252|Shadowflame Fury|236297|p|-1||i||
461256|Diplomatic Immunity|132486|a|-1||o||
461270|Magmadar's Return|236191|p|20||s||
461272|Rune Scrying|136208||-1||o||
461289|Shadowtooth Illusion Ward|136243|p|-1||i||
461290|Libram of the Consecrated|135878|p|10||i||
461297|Totem of Raging Fire|135818|p|12||i||
461303|Smoldering Aegis|132360|p|-1||o||
461314|Oath of Protection|133384|a|1800||i||
461317|Prestor's Hairpin|133800|p|20|magic|i||
461318|Gift of Gob|236685|a|3600||i||
461324|Sleep|132123|p|600||i||
461329|Levitate|135928|p|-1||o||
461330|Decisive Strike|135126|p|0.25||o||
461333|Rune Scrying|136208|p|-1||o||
461343|Shazzrah's Curse|136121|t|300|curse|o||
461345|Crushing Stone|132846|p|-1||o||
461346|Sweltering Heat|236228|t|5||o||
461347|Enrage|136224|p|-1||o||
461348|Enrage|136224|p|-1||o||
461352|Crescent Smash|135900|a|10||o||
461383|Chaos Chopper|134427|t|3||o||
461384|Chaos Chopper|134427|p|-1||o||
461402|Chaos Chopper|134427|p|-1||o||
461470|Single-Minded|236309|p|10||o||
461475|Valor of Azeroth|132347|p|7200||i||
461477|Fireworks|237554|a|3||o||
461555|Fiery Justice|136235|p|-1||o||p
461607|Divine Steed|135890|p|3||i||
461615|Mark of Chaos|136226|t|120||o||
461632|Stratholme Holy Water|236211|p|30||i||
461680|Ephemeral Power|135934|p|15||i||
461682|Gutgore Ripper|136197|t|30|curse|i||
461701|Geddon's Grace|135819|p|-1||i||
461761|Destructor's Devastation|236292|p|0.1||o||
461773|Destructor's Devastation|236292|t|6|magic|o||
461810|Thunder Clap|136105|t|30||o||
461826|Thunder Clap|136105|t|26||o||
461827|Thunder Clap|136105|t|22||o||
461828|Thunder Clap|136105|t|18||o||
461829|Thunder Clap|136105|t|14||o||
461830|Thunder Clap|136105|t|10||o||
461839|From the Firelands|132101|p|5||o||
461862|Armageddon|135826|p|5||o||
461874|Scorching Fetters|236154|p|2||o||
461966|Vampiric Embrace|136230|t|60|curse|o||
462058|Sleep|136090|t|7||o||
462149|Speed|236224|p|10||i||
462160|Destructor's Devastation|236292|p|0.1||o||
462161|Destructor's Devastation|236292|t|6|magic|o||
462178|Enfeeble|136157|t|120|curse|i||
462214|Primal Instinct|132193|e|-1||i||
462222|Destructor's Devastation|236292|p|0.1||o||
462223|Destructor's Devastation|236292|t|6|magic|o||
462224|Destructor's Devastation|236292|p|3||o||
462225|Destructor's Devastation|236292|p|3||o||
462226|Destructor's Devastation|236292|p|3||o||
462228|Cursed Blade|136140|p|-1||i||
462230|Defender's Resolve|132335|p|-1||o||
462250|Curse of Agony|136139|t|30|curse|o||
462259|Ground Stomp|252176|t|3||o||
462272|Pool of Fire|135826|p|-1||o||
462274|Pool of Fire|135826|a|-1||o||
462287|(DNT) Lasher Counter Pulse|136243|p|-1||o||i
462344|Gift of the Wisp|136243|p|120||o||
462370|(DNT) Cogs|136243|p|-1||o||i
462374|Dive|136126|p|15||o||
462395|Pyroclast Barrage|135808|t|6||o||
462400|Incinerate|135813|t|60||o||
462402|Living Bomb|132863|t|8||o||
462467|Flex Tandem Press Task Apparatus|136075|p|8||o||
462498|Rift Beacon|136006|p|-1|magic|o||
462504|Rune Scrying|136208||6||o||
462509|Rune Scrying|136208||6||o||
462543|Flare|236228|p|-1||o||
462546|Flare|236228|p|-1||o||
462548|Flare|236228|p|-1||o||
462577|Sleep|136090|t|10|magic|o||
462584|Unbalancing Strike|132340|t|6||o||
462586|Shadowstalker Slash|132092|t|5||o||
462636|Chromatic Infusion|135934|p|15||i||
462664|Arcane Bomb|135975|t|8|magic|o||
462666|Scatter Shot|132153|t|4||o||
462707|Cutthroat|236281|p|10||o||
462724|Garrote|132297|t|18||o||
462726|Garrote|132297|t|18||o||
462727|Garrote|132297|t|18||o||
462728|Garrote|132297|t|18||o||
462729|Garrote|132297|t|18||o||
462730|Garrote|132297|t|18||o||
462752|Main Gauche|136189|p|20||o||
462832|Shock and Awe|252188|p|60||o||
462853|Hand of Sacrifice|135966|a|12|magic|o||
462858|Circle of Flame|135824|p|10||i||
462872|Unholy Frenzy|136012|a|20|magic|o||
462873|Cloak of Shadows|136177|p|5||o||
462937|Charge|132337|t|2||o||
462999|Carrion Swarm|236595|a|9||o||
463000|Dedication|236370|p|-1||o||
463005|Fluorescent Green Mechanostrider|132247|p|-1||i||
463006|Golden Sabercat|132242|p|-1||i||
463007|Mottled Blood Raptor|132253|p|-1||i||
463105|Sanctuary|135824|p|10|magic|i||
463171|Fixate|136129|t|10||o||
463365|Summon Siopi|132182|p|-1||o||
463448|Frost Nova|135848|t|8|magic|i||
463564|Broodmother's Block|236311|p|20||i||
463661|Meteor|136243|p|-1||o||
463864|Sigil of Flowing Waters|254883|p|3600|magic|i||
464241|Tactician|132345|p|10||o||
464629|Manastorm|135857|p|-1||o||
464630|Manastorm|135857|a|-1||o||
464650|Frozen Solid|135841|a|-1|magic|o||
464658|Frozen Solid|135841|a|-1||o||
464743|Force Dampeners|134064|p|30||o||
465108|Frigid Current|135854|p|-1||o||
465124|(DNT) TMC Summoning Steam|136243|p|-1||o||i
465230|Entrapment|136100|t|5|magic|o||
465352|Banish|136135|a|30|magic|o||
465414|Crusader's Zeal|135958|p|8||i||
465483|Mangle|132122|t|20||o||
465725|Living Bomb|132863|t|8||o||
465787|Prophetic Insight|136243|p|-1||i||
465994|(DNT) Overture|136243|t|-1||o||i
466061|Infiltration|136177|p|-1||o||
466062|Spotted!|132178|p|-1||o||
466071|Bronze Trial|134156|a|-1||o||
466072|Summon Estelenn|132182|p|-1||o||
466084|(DNT) Bronze Affix Manager|136243|t|-1||o||i
466195|Blazing Wounds|236218|p|-1||o||
466211|Tendrils of Air|132845|t|30||o||
466261|Red Trial|134153|a|-1||o||
466270|Tendrils of Air|136022|p|1||o||
466272|Tendrils of Air|136022|p|10||o||
466277|Blue Trial|134155|a|-1||o||
466307|(DNT) Experimental AoE - Spell School Check|136243|t|12||o||i
466312|(DNT) Experimental Boss Buff - Strength|136243|t|3600||o||i
466357|Arcane Bomb|135754|t|8||o||
466416|Green Trial|134157|a|-1||o||
466435|Nature's Fury|237556|t|8||o||
466448|Toxic Pool|236271|a|-1||o||
466552|Ninja Costume|133143|p|1800||o||
466583|Ninja Costume|133143|p|1800||o||
466655|Convalescence|236392|p|-1||o||
466662|Ninja Costume|133143|p|1800||o||
466669|(DNT) Experimental Boss Buff - Attack Speed|136243|t|3600||o||i
466670|(DNT) Experimental Boss Buff - Bonus Armor|136243|t|3600||o||i
466672|(DNT) Experimental Boss Buff - Health Regeneration|136243|t|3600||o||i
466674|(DNT) Experimental Boss Buff - Spell Power|136243|t|3600||o||i
466675|(DNT) Experimental Boss Buff - Spell Resistance|136243|t|3600||o||i
466739|Lightning Shield|136051|p|600|magic|o||
466746|Ninja Costume|133143|p|1800||o||
466749|Ninja Costume|133143|p|1800||o||
466764|(DNT) Varmot moustache visual|0|p|-1||o||ip
466774|Cyclonic Winds|236154|p|6||o||
466841|Meathook|132507|p|1.5||o||
466842|Combo|134919|p|1||o||
466843|Combo|132344|p|1||o||
466850|Combo|132344|p|1||o||
466853|Combo|132344|p|6||o||
466870|Zephyr|132837|p|-1||o||
466903|Blessing of Hethiss|135461|p|-1||o||
466924|[DNT] Evocation Dummy|136243|p|7||o||i
467042|Blessing of Bethekk|133236|p|-1||o||
467047|Black Essence|134154|a|-1||o||
467049|Blessing of Bethekk|133236|p|-1||o||
467079|Force of Nature|132129|p|15||o||
467085|[DNT] Elsewhen Torch Active|136115|p|-1||o||i
467088|Astral Power|237551|p|15|magic|e||
467101|Blessing of Hir'eek|132182|p|-1||o||
467125|Blessing of Shirvallah|132242|p|-1||o||
467127|Blessing of Shirvallah|136012|t|15|magic|o||
467141|Mind Quickening|136115|p|20||i||
467204|Healing Grace|136062|p|15|magic|e||
467259|Blessing of Shadra|132196|p|-1||o||
467264|[DNT] Elsewhen Torch Control - Periodic|136115|p|-1||o||i
467275|Tempest|136243|p|10||o||
467331|Clever Strikes|132193|p|5|magic|e||
467347|Ninja Costume|133143|p|1800||o||
467360|Blue Flight|134155|p|-1||o||
467362|Red Flight|134158|p|-1||o||
467363|Green Flight|134157|p|-1||o||
467366|Lightning|136048|p|2|magic|o||
467367|Frost Tomb|236214|t|4||o||
467410|Brood Boon: Bronze|134156|p|10|magic|o||
467411|Brood Boon: Black|134154|p|10|magic|o||
467412|Brood Boon: Blue|134155|p|10|magic|o||
467413|Brood Boon: Green|134157|p|10|magic|o||
467414|Brood Boon: Red|134158|p|10|magic|o||
467446|Arcane Infused|136116|p|15||i||
467449|Burning Adrenaline|132937|t|-1||o||
467457|Tempest|132845|p|30||o||
467459|Blessing of the Black Book|136224|e|30||i||
467467|Shapeshifter's Sigil|134419|p|20||i||
467468|Tempest|132845|p|10||o||
467488|[DNT] Tempest Tracking|136243|p|5||o||i
467491|Wildfire|136243|p|-1||o||
467498|Gift of Life|134124|p|20||o||
467511|Venomous Totem|136232|p|20||i||
467522|Blinding Light|135972|p|20||i||
467523|Nature Aligned|136094|p|20||i||
467525|Aegis of Preservation|135880|a|20||i||
467530|Swift Judgement|252270|p|8||o||
467534|Holy Fortitude|236252|p|10||o||
467543|Deliverance|135872|p|-1|magic|e||
467548|Knockback|136243|p|-1||o||
467554|The Storm|136243|t|-1||o||
467566|Poison Bolt Volley|136016|p|4|poison|o||
467588|Healing Echoes|136044|a|15|magic|o||
467632|Harness the Spirit|136212|p|15||o||
467732|Stop!|236219|t|5||o||
467735|Clearcasting|136170|p|15|magic|e||
467742|Primal Blessing|132175|p|12||s||
467754|Serpentine Spirit|132211|p|20||i||
467764|Go!|132301|t|5||o||
467827|Lightning|252174|t|1|magic|o||
467829|Lightning|136048|p|6|magic|o||
467839|Void Slam|134430|p|6|magic|o||
467840|Void Slam|134430|t|2|magic|o||
467880|Stormfury|237588|p|10|magic|o||
467891|Shield Block|132110|p|5||e||
467899|[DNT] Lightning Strike|136243|p|2||o||i
467910|Elemental Shield|136094|p|6||o||
467995|Aspect of Jeklik|132182|p|-1||o||
467997|Aspect of Venoxis|135461|p|-1||o||
467999|Aspect of Mar'li|132196|p|-1||o||
468000|Aspect of Thekal|132242|p|-1||o||
468001|Aspect of Arlokk|133236|p|-1||o||
468012|Sonic Burst|132182|t|10|magic|o||
468027|Fetch!|132103|a|5||o||
468071|Retaliate|132215|t|30||o||
468076|Vicious Strike|132109|t|24||o||
468078|Nullify|134430|p|1.5||o||
468156|Thunderfury|136018|t|12|magic|i||
468157|Thunderfury|136018|t|12|magic|i||
468164|Pagle's Broken Reel|135865|p|15||i||
468183|Frenzy Effect|134296|p|8|frenzy|o||
468387|Aligned with Nature|136233|p|20||i||
468388|Locked In|132177|p|20||i||
468408|Bloodlust|136012|t|10|magic|o||
468460|Energized Shield|136014|p|20||i||
468461|Brilliant Light|135934|p|15||i||
468462|Gri'lek's Guard|132360|p|20||i||
468466|Unmaking the Simulacrum|136075|p|8||o||
468474|Parasitic Serpent|134301|t|10||o||
468475|Poison|136016|t|30|poison|o||
468478|Growth|136235|p|20||o||p
468479|Growth|136235|p|604800||o||p
468481|Full Grown|136101|p|-1||o||
468491|Aspect of Arlokk|133236|a|5||o||
468512|Frost Potency|236209|p|20||i||
468526|Power Surge|132870|p|10|magic|o||
468531|Rapid Healing|135917|p|15||i||
468540|Massive Destruction|135831|p|20||i||
468543|Demonic Destruction|237561|e|20||i||
468591|Sleep|136090|p|60||o||
468594|Roll Over!|136243|p|-1||o||
468746|Power of Hakkar|236413|p|-1||o||
468767|Drink|132805|p|30||i||
468768|Wrath of Wray|236392|p|20||i||
468769|Nature Reflector|136030|p|5||i||
468774|Memory of Gri'lek|298678|p|30||o||
468775|Memory of Hazza'rah|136090|p|30||o||
468776|Memory of Renataki|132331|p|30||o||
468777|Memory of Wushoolay|136049|p|30||o||
468781|Gathering Storm|237587|p|-1||o||
468784|Echoes of Betrayal|338667|p|20||o||
468843|Lacerate|132141|t|5||o||
468879|Stealth|132320|p|-1||o||
468925|Caustic Slime|132104|t|5|magic|o||
468971|Windstriker|132090|p|3||o||
469005|<DNT> Senna's Test Spell|136243|p|18||o||i
469010|Shadow Ritual of Sacrifice|136194|p|5||o||
469025|Rage of the Suzerain|254650|p|10||o||
469047|(DNT) Cosmetic Chains - Bear|134326|t|-1||o||i
469055|Fire Volley|136186|p|3||o||
469056|Frost Volley|135857|p|3||o||
469057|Earth Volley|132846|p|3||o||
469058|Lightning Volley|136050|p|3||o||
469065|Ground Tremor|136183|t|6|magic|o||
469075|Fel Portal Creation|135854|p|-1||o||
469091|Corrupted Blood|136243|a|-1||o||
469110|Corrupted Blood|136133|a|10||o||
469112|(DNT) Cosmetic Chains - Tiger|134326|t|-1||o||i
469113|(DNT) Cosmetic Chains - Silithid|134326|t|-1||o||i
469132|Broodling Venom|132274|t|3|poison|o||
469146|Sleep|136090|p|-1||o||
469148|Kestrel|132158|p|10||i||
469155|Deep Sleep|136090|t|20|magic|o||
469161|Blast Wave|135903|t|6||o||
469166|You're a Ghoul!|237524|p|-1||o||
469182|Lying Low|132320|p|-1||o||
469190|DNT|136243|p|0.1||o||i
469191|Cassandra's Tome|5933402|p|15|magic|i||
469208|Boon of Earth|237002|p|120||o||
469209|Boon of Fire|132221|p|120||o||
469210|Boon of Water|136037|p|120||o||
469220|Scythe of Chaos|5905006|p|20||i||
469222|Impish Delight|236294|p|15||o||
469224|Void Walking|136221|p|15||o||
469225|Seduction of the Shadows|4352493|p|15||o||
469227|Felhunted|136217|t|3||o||
469229|Hunter of Chaos|136217|p|15||o||
469230|Fel Invigoration|136216|p|15||o||
469239|Guarded by Ice|132097|p|-1||o||
469260|Thrill of Battle|136243|p|-1||o||
469261|Burning Adrenaline|132937|p|-1||o||
469262|Gobmogrified|132288|p|3600||i||
469271|Astral Form|237572|p|-1||i||
469278|(DNT) Bear Sleep Anim|136243|p|-1||o||i
469305|(DNT) Silithid Sleep Anim|136243|p|-1||o||i
469357|Immolation Aura|135802|p|-1||o||
469433|Poison Bolt|136016|t|6|poison|o||
469486|[DNT] Magma Charge|134337|p|3||o||i
469521|Fear|136183|t|10|magic|o||
469537|Bile Vomit|136007|t|45|poison|o||
469548|Disease Buffet|136022|t|45|disease|o||
469606|[DNT] Magma Spawn|136243|p|3||o||i
469624|On Fire!!|135818|p|10||o||
469626|[DNT] Magma Spawn|136243|p|8||o||i
469647|Consecrated Weapon|236262|p|3600||i||
469670|Ending Azgaloth|5906169|p|-1||o||
469699|Pepe|132150|p|-1||i||
469793|Fear|136183|t|8|magic|o||
469828|Untamed Fury|136012|p|8||i||
469865|Applying Heat|135805|p|2.5||o||
469869|Cooling Down|135852|p|2.5||o||
469879|Fear|136183|t|8|magic|o||
469891|Call Aeonas|5906169|p|-1||i||
469985|Illusion Passive|134158|p|3600||i||
470009|Root Self|136235|p|5||o||p
470018|Flare Breath|135809|p|40||o||
470026|Flare Breath|135809|a|-1||o||
470031|War Stomp|132368|t|2||o||
470037|Fire Cat Form|304287|p|-1||i||
470085|Sated|136090|a|60||o||
470108|Petrification|134806|p|60||o||
470265|Avenger's Shield|135874|t|5|magic|o||
470271|Libram of Wrath|135902|p|15|magic|i||
470272|Totem of Conductive Currents|237589|p|15|magic|i||
470279|Demonic Aegis|132221|a|12|magic|o||
470280|Umbral Slash|132291|t|30||o||
470338|[DNT] Effect|132320|p|2.5||o||i
470345|First Aid|135915|a|8||i||
470361|Increased Spell Damage|133943|p|600||i||
470362|Food|134062|p|30||i||
470367|Increased Healing Power|133943|p|600||i||
470369|Food|134062|p|30||i||
470455|[DNT] Effect|132320|p|2.5||o||i
470459|Teleport|135743|p|-1||o||
470495|Vulnerable|135860|p|-1||o||
470500|[DNT] Dummy Aura Warrior|136243|p|-1||o||i
470535|Nether Strike|136181|t|5||o||
470868|Wisp Costume|132288|p|-1||o||
471149|Out of Bounds|236232|p|3||o||
471513|(DNT) Darkness Test|136122|p|-1||o||i
471516|(DNT) Darkness Test - Within Light|136243|p|-1||o||i
471698|Soul of the Demon|236300|p|-1||i||
472642|Gilded Scarab Visual|133784|p|-1||o||
472692|Escape!|136243|p|22||o||
472717|Treasure Scarab - Spawn|136243|p|2||o||
472870|Squall|136243|p|15||o||
473387|Horn of the Dawn|134229|p|7200||o||
473399|Songflower Lullaby|135934|p|3600||o||
473403|Blessing of Neptulon|135861|p|7200||o||
473441|Might of Blackrock|236718|p|3600||o||
473450|Dark Fortune of Damage|134334|p|7200||o||
473469|Cleansed Firewater|134872|a|3600|magic|o||
473476|Dreams of Zandalar|132107|p|7200||o||
473482|Elemental Disjunction|136102|t|120|magic|i||
473496|Explosive Sand Trap|135813|t|15|magic|o||
473525|Freez-O-Matic Ray|135989|t|60||i||
473544|Sneaking|132320|p|60||i||
473570|Lasso|132507|p|2||o||
473687|Argent Dawn|236690|t|10||o||
473701|Taunt|136080|t|3||o||
473848|Summon Light Green Qiraji Battle Tank|237207|p|-1||o||
473849|Gilded Demise|136243|p|2||o||
473853|Summon Light Green Qiraji Battle Tank|237207|p|-1||o||
473855|Summon Light Green Qiraji Battle Tank|237207|p|-1||o||
473858|Summon Dark Blue Qiraji Battle Tank|237193|p|-1||o||
473859|Summon Dark Blue Qiraji Battle Tank|237193|p|-1||o||
473860|Summon Dark Blue Qiraji Battle Tank|237193|p|-1||o||
473869|Summon Light Blue Qiraji Battle Tank|237212|p|-1||o||
473870|Summon Light Blue Qiraji Battle Tank|237212|p|-1||o||
473871|Summon Light Blue Qiraji Battle Tank|237212|p|-1||o||
473874|Summon Orange Qiraji Battle Tank|237208|p|-1||o||
473875|Summon Orange Qiraji Battle Tank|237208|p|-1||o||
473877|Summon Orange Qiraji Battle Tank|237208|p|-1||o||
473882|Summon Twilight Qiraji Battle Tank|237211|p|-1||o||
473886|Summon Twilight Qiraji Battle Tank|237211|p|-1||o||
473887|Summon Twilight Qiraji Battle Tank|237211|p|-1||o||
473900|Summon Tamed Silithid Tank|236195|p|-1||i||
474116|Amulet of Fowl Warding|133299|p|15|magic|i||
474126|Immersed|136035|p|10|magic|i||
474146|Swarming Thoughts|136128|p|15||o||
474148|Swarming Thoughts|136128|p|15||o||
474204|Mind Flay|136208|t|5||o||
474236|Blessing of Ji'zhi|132102|p|6||i||
474268|Mind Flay|236296|t|5||o||
474386|PvP Trinket|135894|p|0.1||i||
474400|Cause Insanity|136206|t|6||o||
474564|Thunder|136105|p|-1||o||
474565|Shadow|136197|p|-1||o||
474570|Fire|135821|p|-1||o||
474571|Plague|136182|p|-1||o||
1213145|Censer of the False Prophet|236414|p|300||i||
1213147|Healing of the Ages|136042|p|15||i||
1213155|Volatile Infection|135914|t|120|disease|o||
1213169|Spore Cloud|136021|t|5||o||
1213170|Noxious Breath|136169|t|30||o||
1213176|Tooth and Claw|134298|t|4||o||
1213190|Animal Fury|132139|p|10||e||
1213209|Mercurial Shield|136235|p|60||i||p
1213221|Mercurial Shield|136162|p|60||o||
1213232|Necklace of Purity|133342|p|15|magic|i||
1213234|Recomposed|136030|p|3||i||
1213240|Resolve of the Battleguard|136174|p|15||o||
1213241|Resolve of the Battleguard|136174|p|15||o||
1213253|Entangling Roots|136100|t|15|magic|o||
1213254|Curse of Despair|237555|p|-1||o||
1213255|Curse of Despair|237552|p|-1||o||
1213256|Curse of Despair|236366|p|-1||o||
1213257|Curse of Decay|136182|p|-1||o||
1213258|Curse of Decay|132099|p|-1||o||
1213259|Curse of Decay|132108|p|-1||o||
1213260|Curse of Madness|136131|p|-1||o||
1213261|Curse of Madness|136122|p|-1||o||
1213263|Curse of Madness|236407|p|-1||o||
1213268|Hunter's Mark|132212|t|120|magic|o||
1213276|Frostbolt|135846|t|4|magic|o||
1213278|Ice Barrier|135988|p|60|magic|o||
1213297|Badge of the Swarmguard|133573|p|6||i||
1213300|Divine Protection|135954|p|8||o||
1213301|Hammer of Justice|135963|t|4|magic|o||
1213317|Fire Blast|135807|p|10|magic|o||
1213332|Mind Control|136206|t|15|magic|o||
1213334|Shadowform|136221|p|-1||o||
1213335|Earthen Shroud|135234|p|10|magic|i||
1213342|Temp MC test|136243|t|15||o||i
1213356|Dominate Mind|136206|t|5||o||
1213362|Test MC|136243|t|-1||o||i
1213367|Jom Gabbar|132273|p|-1||i||
1213375|The Burrower's Shell|135893|p|20||i||
1213415|Shielded in Righteousness|236265|p|10|magic|o||
1213422|Aura of the Blue Dragon|134155|p|15||i||
1213442|Garrote|132297|t|18||o||
1213450|Corruption|136118|t|24|magic|o||
1213452|Fear|136183|t|4|magic|o||
1213462|Shield Slam|132357|t|2||o||
1213464|Thunderclap|136105|t|10|magic|o||
1213465|Intimidating Shout|132154|t|8||o||
1213479|Lightning Shield|136051|p|600|magic|o||
1213482|Flame Shock|135813|t|12|magic|o||
1213725|Light Column|136243|p|-1||o||
1213761|Blood Barrier|236305|p|15|magic|o||
1213886|Flask of Unyielding Sorrow|236877|p|7200||i||
1213892|Flask of Ancient Knowledge|236878|p|7200||i||
1213897|Flask of Madness|236880|p|7200||i||
1213901|Flask of the Old Gods|236879|p|7200||i||
1213904|Elixir of the Honey Badger|134731|p|3600||i||
1213914|Elixir of the Mage-Lord|134733|p|3600||i||
1213915|Burning|135789|t|4||o||
1213917|Elixir of the Ironside|134730|p|3600||i||
1213922|Elixir of Alacrity|134735|p|3600||i||
1213924|Arcane Megabomb|135975|t|5|magic|i||
1213934|Stormbraced|136075|p|10||e||
1213939|Pack Leader|132266|p|-1||o||
1213967|Innovation Unleashed|252174|p|3||i||
1213972|Speed|132307|p|10||i||
1213996|Draw Spirit|136219|t|5||o||
1213997|Shadow Bolt Whirl|136197|p|-1||o||
1214001|Scroll: Wrath of the Swarm|237449|p|3600|magic|i||
1214002|Draw Spirit|136219|t|5||o||
1214028|Bellowing Roar|136129|t|4||o||
1214088|Infernalist|236215|p|20||e||
1214098|Master Demonologist|136203|p|-1||o||
1214100|Master Demonologist|136203|p|-1||o||
1214101|Master Demonologist|136203|p|-1||o||
1214102|Master Demonologist|136203|p|-1||o||
1214136|Divergent Lightning|135990|t|8||o||
1214156|Spreading Pain|236216|p|6||e||
1214166|Bloodthirsty|236215|p|6||o||
1214170|Occult Poison II|135935|t|12|poison|e||
1214179|Furbolg Form|134297|p|300||i||
1214205|Glimpse of Madness|136175|t|3|magic|i||
1214223|Shard of the Fallen Star|135808|t|1.5||o||
1214233|Obsidian Insight|133573|p|30||i||
1214263|Chitinous Spikes|133571|p|30||i||
1214273|Silence|135975|t|3|magic|i||
1214278|Earthstrike|136006|p|20||i||
1214279|Spell Blasting|135990|p|10||i||
1214281|Naga Form|237551|p|300||i||
1214283|Swift Spectral Tiger|298591|p|-1||i||
1214284|Drakonid Form|236469|p|300||i||
1214298|Libram of Sanctity|135934|p|60||o||
1214451|Spiritual Protection|236223|t|-1||o||
1214691|[DNT] Illusion of Despair|136243|a|-1||o||i
1214725|[DNT] Illusion Selection|136243|p|9||o||i
1214727|[DNT] Illusion Selection|136243|p|9||o||i
1214844|[DNT] Copy|136243|a|-1||o||i
1214851|[DNT] Speed|136243|p|-1||o||i
1214867|[DNT] Periodic Demon Checker|136243|p|-1||o||i
1214956|Curse of Despair|132095|p|10|curse|o||
1214958|[DNT] Modify Health & Damage|136243|p|-1||o||i
1215061|[DNT] Curse of Decay|132108|p|5||o||i
1215202|Noxious Burst|132108|p|3||o||
1215358|Spiritual Protection|236223|p|-1||o||
1215375|Spirit Shade Visual|136123|p|-1||o||
1215378|Blood-Caked Tiger|132267|p|-1||i||
1215380|Blood-Caked Raptor|132253|p|-1||i||
1215421|Toxic Pool|236271|a|-1||o||
1215425|[DNT] Character Visual|255344|p|30||o||i
1215428|[DNT] Character Visual|255344|p|30||o||i
1215430|[DNT] Character Visual|255344|p|30||o||i
1215432|[DNT] Character Visual|255344|p|30||o||i
1215435|[DNT] Character Visual|255344|p|30||o||i
1215436|[DNT] Character Visual|255344|p|30||o||i
1215438|[DNT] Character Visual|255344|p|30||o||i
1215440|[DNT] Character Visual|255344|p|30||o||i
1215442|[DNT] Character Visual|255344|p|30||o||i
1215445|[DNT] Character Visual|255344|p|30||o||i
1215447|[DNT] Character Visual|255344|p|30||o||i
1215448|[DNT] Character Visual|255344|p|30||o||i
1215450|[DNT] Character Visual|255344|p|30||o||i
1215452|[DNT] Character Visual|255344|p|30||o||i
1215455|[DNT] Character Visual|255344|p|30||o||i
1215491|[DNT] Madness Tracker|136243|p|-1||o||i
1215509|Fire Resistance|135806|p|6|magic|o||
1215510|Frost Resistance|135843|p|6|magic|o||
1215511|Nature Resistance|136051|p|6|magic|o||
1215512|Shadow Resistance|136185|p|6|magic|o||
1215513|Holy Resistance|135880|p|6|magic|o||
1215514|Arcane Resistance|135998|p|6|magic|o||
1215516|[DNT] Find Players|136199|p|6||o||i
1215554|Share Health|136243|p|-1||o||
1215555|Share Health|136243|t|-1||o||
1215557|Share Health|136243|p|-1||o||
1215559|Share Health|136243|p|-1||o||
1215736|Viscidus Frost Weakness|136006|p|-1||o||
1215737|Viscidus Freeze|135840|p|15||o||
1215740|Mind Flay|136208|t|5||o||
1215744|Blinding Admiration|136206|t|5||o||
1215752|Noxious Poison|136016|t|8||o||
1215753|Wyvern Sting|135125|t|12|poison|o||
1215755|Frenzy|132117|p|8|frenzy|o||
1215756|[DNT] Frenzy Ramp|136243|p|-1||o||i
1215757|Acid Spit|136016|t|30||o||
1215885|Berserk|132117|p|3600||o||
1215978|Enter Hyjal|134421|p|2.5||o||
1215980|Exit Hyjal|134421|p|2.5||o||
1216028|[DNT] Madness Tracker|237555|p|-1||o||i
1216029|[DNT] Madness Tracker|136243|p|-1||o||i
1216030|[DNT] Madness Tracker|136243|p|-1||o||i
1216031|[DNT] Madness Tracker|136243|p|-1||o||i
1216032|[DNT] Madness Tracker|136243|p|-1||o||i
1216033|[DNT] Find Players|237555|p|1||o||i
1216047|[DNT] Find Players|237555|p|1||o||i
1216049|[DNT] Find Players|237555|p|1||o||i
1216051|[DNT] Find Players|237555|p|1||o||i
1216053|[DNT] Find Players|132108|p|1||o||i
1216119|Dark Offering|136122||30||o||
1216141|Summon Mouth Tentacle|136235|p|3.8||o||p
1216566|Traces of Silithyst|136106|p|1800||o||
1216928|Guiding Torchlight|135432|p|-1||o||
1216932|Oppressive Darkness|136122|p|-1||o||
1216982|Within Light|236252|t|-1||o||
1217084|Draught of the Sands|133214|p|3600||i||
1217142|Summon Flawless Yellow Qiraji Battle Tank|134395|p|-1||o||
1217143|Summon Flawless Yellow Qiraji Battle Tank|134395|p|-1||o||
1217144|Summon Flawless Yellow Qiraji Battle Tank|134395|p|-1||o||
1217146|Summon Flawless Green Qiraji Battle Tank|134397|p|-1||o||
1217147|Summon Flawless Green Qiraji Battle Tank|134397|p|-1||o||
1217148|Summon Flawless Green Qiraji Battle Tank|134397|p|-1||o||
1217150|Summon Flawless Blue Qiraji Battle Tank|134398|p|-1||o||
1217151|Summon Flawless Blue Qiraji Battle Tank|134398|p|-1||o||
1217152|Summon Flawless Blue Qiraji Battle Tank|134398|p|-1||o||
1217154|Summon Flawless Red Qiraji Battle Tank|134396|p|-1||o||
1217155|Summon Flawless Red Qiraji Battle Tank|134396|p|-1||o||
1217156|Summon Flawless Red Qiraji Battle Tank|134396|p|-1||o||
1217185|Guiding Torchlight|135432|p|-1||o||
1217289|[DNT] Blinding Admiration|136243|p|8||o||i
1217333|Twin Teleport|135736|p|6||o||
1217348|[DNT] Dummy Aura|136243|p|5||o||i
1217376|Mirror Name|136243|t|-1||o||
1217424|Fel Pervasion|136118|p|-1||o||
1217724|Scorching Torchlight|135433|p|-1||o||
1217775|Intolerable Heat|135817|p|-1||o||
1217844|Charred Skin|135871|p|-1||o||
1217848|(DNT) Charred Skin Periodic|135871|p|-1||o||i
1217927|Excommunication|135903|p|20|magic|e||
1217952|Dreadful Visage|237569|t|5||o||
1217959|Fading Hope|136194|t|20||o||
1218038|Inhume|135834|t|45||o||
1218089|Illimitable Dominion|136214|t|120||o||
1218092|Quietude|136243|p|-1||o||
1218154|Strikes of the Sinister|132305|p|10||o||
1218184|(DNT) Bonus Bar Test|136243|p|-1||o||i
1218198|Abhorrent Infestation|298663|a|-1||o||
1218216|Subjugated Spinners|132196|t|30||o||
1218271|Authority of the Frozen Wastes|236491|a|-1||o||
1218275|Authority of the Frozen Wastes|236493|a|-1||o||
1218276|Authority of the Frozen Wastes|254094|a|-1||o||
1218283|Authority of the Frozen Wastes|343637|a|-1||o||
1218285|Locked and Loading|135621|p|60||o||
1218345|Glaciate|236208|t|15||e||
1218358|Rabid Frenzy|132101|t|120|disease|o||
1218366|Living Darkness|136194|p|-1||o||
1218479|Undead Slaying|135914|p|30||s||
1218485|Draught of the Sands|133213|p|3600||i||
1218506|Growl|132270|t|3||o||
1218574|Critical Aim|236286||30||o||
1218585|[DNT] Dummy Aura|136243|p|-1||o||i
1218587|Undead Slaying|135914||30||s||
1218695|Overclocked|134378|a|15||o||
1218701|Evoker|236693|a|45||o||
1219020|Creeping Darkness|132291|t|30|magic|i||
1219058|Marching Orders|298647|a|-1||o||
1219060|Marching Orders|134331|p|10||o||
1219072|Orders complete!|132351|p|300||o||
1219085|Give me laps!|132333|p|5||o||
1219090|Strangulate|136214|t|3|magic|e||
1219114|Fungal Contagion|298662|a|-1||o||
1219121|Blood Plague|237514|t|15|disease|e||
1219124|Frost Fever|237522|t|21|disease|e||
1219125|(DNT) Mushroom Growth|136243|p|-1||o||i
1219150|Bolstering Spores|132125|t|30||o||
1219153|Mark of Blood|132205|t|20|magic|e||
1219164|(DNT) Mushroom Growth|136243|p|10||o||i
1219206|Hand of Reckoning|135984|t|3||o||
1219229|Overcharged|298675|a|-1||o||
1219232|Mind's Eye|135740|a|15||s||
1219234|Overcharged|252174|t|10||o||
1219235|Overcharged|237587|p|30||o||
1219243|Crushing Despair|132097|t|-1||o||
1219270|Stygian Grasp|136143|t|6|magic|o||
1219291|Undead Slaying|135914|p|30||o||
1219325|(DNT) Sapphiron Ice Floor|136243|p|120||o||i
1219338|Frozen Ground|237528|a|-1||o||
1219355|Tease|236550|t|3||o||
1219370|Undead Slaying|135914|p|30||o||
1219375|Undead Slaying|135914|p|30||o||
1219379|Earth Shock|136026|t|3||o||
1219387|Flame Whirl|135812|p|5||o||
1219389|Immolation|135817|p|-1||o||
1219397|Smothering Darkness|136194|p|-1||o||
1219403|[DNT] Fiery Spawn|136243|p|12||o||i
1219420|Pull of the damned|236290|p|10||o||
1219475|Menace|136214|t|3||o||
1219485|Undead Slaying|135914|p|30||s||
1219500|Kiss of the Spider|135442|p|15|magic|i||
1219501|Loatheb's Reflection|135443|p|15||i||
1219503|The Eye of Diminution|135994|p|20|magic|i||
1219513|The Eye of the Dead|135439|p|30|magic|i||
1219515|Essence of Sapphiron|135444|p|20||i||
1219519|Slayer's Crest|135441|p|20||i||
1219520|Glyph of Deflection|135443|p|20||i||
1219539|Seal of the Dawn|236690|p|-1||i||
1219541|Taunt|136080|t|3||o||
1219548|Seal of the Dawn|134501|p|-1||i||
1219552|Power of the Guardian|136057|p|-1||i||
1219553|Power of the Guardian|136057|p|-1||i||
1219557|Power of the Guardian|136057|p|-1||i||
1219558|Power of the Guardian|136057|p|-1||i||
1219682|Slip|136243|p|2||o||
1219729|Glacial Crash|135783|t|8||o||
1219732|Glacial Crash|135783|t|8||o||
1219741|Grasping Spirits|237535|a|-1||o||
1220410|Dragon's Breath|134153|t|4||o||
1220514|Seal of the Dawn|236689|p|-1||i||
1220517|Bone Armor|136225|a|60||o||
1220520|Stygian Grasp|136143|t|5|magic|i||
1220533|Stygian Grip|136143|t|6|magic|i||
1220534|Fading Knowledge|134943|p|180||o||
1220538|Fire Protection|135820|p|3600|magic|i||
1220542|Holy Power|135977|a|8||o||
1220543|Holy Power|135922|a|8||o||
1220545|Holy Power|135892|a|8||o||
1220546|Holy Power|135995|a|8||o||
1220560|Ghoul Form|237524|p|300||i||
1220561|Skeleton Form|237273|p|300||i||
1220562|Human Form|237432|p|300||i||
1220563|Troll Form|236697|p|300||i||
1220564|Bone Golem Form|133719|p|300||i||
1220565|War|298647|p|-1||i||
1220566|Conquest|298647|p|-1||i||
1220567|Death|298647|p|-1||i||
1220568|Famine|298647|p|-1||i||
1220659|Loatheb's Reflection|298662|p|15||i||
1220668|Unholy Might|135775|p|10||i||
1220680|Howling Blast|236214|t|20||o||
1220683|Totemic Power|135995|a|8||o||
1220684|Totemic Power|135922|a|8||o||
1220685|Totemic Power|135977|a|8||o||
1220686|Totemic Power|135892|a|8||o||
1220708|Displaced|236287|p|10||i||
1220744|Earth Shock|136026|t|2||o||
1220746|Earth Shock|136026|t|2||o||
1220747|Earth Shock|136026|t|2||o||
1220748|Earth Shock|136026|t|2||o||
1220749|Earth Shock|136026|t|2||o||
1220750|Earth Shock|136026|t|2||o||
1220751|Earth Shock|136026|t|2||o||
1220829|Flame Wreath|136243|p|-1||o||
1220836|Spectral Fangs|339822|a|15|poison|o||
1220845|Cursed Webbing|237431|t|10|magic|o||
1220853|Frostbolt Volley|135846|t|8|magic|o||
1220854|Frostbolt|135846|t|4|magic|o||
1220855|Frost Nova|135848|t|8|magic|o||
1220882|Freezing Field|135838|p|10||o||
1220885|Freezing Field|135852|p|2||o||
1220886|Freezing Burst|135849|p|1||o||
1220900|Rushing Dark Riders|132251|p|-1||o||
1220913|Torment's Illusion|135740|a|-1||o||
1220914|DNT - Camera|136235|p|6||o||ip
1220915|Army of the Dead|136243|p|-1||o||
1220918|Dwindling Hope|236252|a|-1||o||
1220920|Necrotic Breath|135775|p|10||o||
1220921|Overwhelming Dread|136194|a|-1||o||
1220922|Necrotic Breath|136131|p|1||o||
1220926|Curse of Decay|132095|t|6|curse|o||
1220927|Inferno|135903|t|6||o||
1220928|Torment's Illusion|135740|t|-1||o||
1220929|Torment's Illusion|135740|a|-1||o||
1220930|Phantom's Veil|136047|p|-1||o||
1220935|Ethereal Charge|135945|p|-1||o||
1220936|Ethereal Charge|135945|p|-1||o||
1220937|Ethereal Charge|135945|p|-1||o||
1220938|Ethereal Charge|135789|a|-1||o||
1220939|Ethereal Charge|135945|p|-1||o||
1220940|Ethereal Charge|135945|p|-1||o||
1220971|Ultravision|132280|p|-1||o||
1220972|Oppressive Darkness|136122|p|-1||o||
1220976|Oppressive Darkness|136122|p|-1||o||
1220980|Creepy Censor Sensors|133023|p|-1||i||
1220983|Low-light Vision|132142|p|-1||o||
1221069|[DNT] Shadow Channeling|136121|p|-1||o||i
1221135|Torment's Illusion|135740|a|-1||o||
1221136|Torment's Illusion|135740|a|-1||o||
1221212|[DNT] Ignore Fog of War Aura - Small|135432|p|-1||o||i
1221213|[DNT] Ignore Fog of War Aura - Medium|135432|p|-1||o||i
1221214|[DNT] Ignore Fog of War Aura - Large|135432|p|-1||o||i
1221287|Creeping Malison Spell|136243|p|-1||o||
1221309|Scarlet Insignia|134503|p|-1||i||
1221322|(DNT) Bubble Visual|135432|p|-1||o||i
1221325|Burning|136196|p|10||o||
1221341|Poorly Camouflaged|237425|a|-1||o||
1221420|[DNT] Skeleton Sleep Rise|136243|p|3||o||i
1221421|Mind Vision|132172||7||o||
1221422|Mind Vision|132172|p|60||o||
1221433|[DNT] Shadow Channeling 2|136121|p|-1||o||i
1221453|[DNT] Spawn|136243|p|3||o||i
1221458|[DNT] Warden Light|136243|p|-1||o||i
1221466|Transformation|132311|p|-1||o||
1221467|Transformation|132311|p|-1||o||
1221468|Transformation|132311|p|-1||o||
1221507|(DNT) Naxx Orbs Chain Passive|136243|p|900||o||i
1221571|Frightening Lore|136183|p|6||o||
1221575|Summoning|134430|p|6||o||
1221576|Demonic Frenzy|136172|p|-1|frenzy|o||
1221577|Doom|237557|t|30|curse|o||
1221578|Mark of the Master|236293|p|900||o||
1221579|Super Invis|135994|p|5||o||
1221580|Portal|136243|p|2||o||
1221581|[DNT] Animate Book Open|136243|p|-1||o||i
1221582|[DNT] Animate Book Open|136243|p|4||o||i
1221583|[DNT] Kharon Light|136243|p|-1||o||i
1221584|Mysterious Sword|136243|p|-1||o||
1221585|[DNT] Relic 1 Activated|136243|p|-1||o||i
1221586|Mysterious Scythe|136243|p|-1||o||
1221587|[DNT] Relic 2 Activated|136243|p|-1||o||i
1221588|Mysterious Staff|136243|p|-1||o||
1221589|[DNT] Relic 3 Activated|136243|p|-1||o||i
1221762|Mimic Chomp|136243|a|7||o||
1221795|[DNT] Blossoming|136243|p|3||o||i
1221796|Blossoming Starlight|135432|p|-1||o||
1221797|Within Starlight|136057|t|-1||o||
1221798|Mending|136081||5||o||
1221799|Boulder Destroy|136243|p|2||o||
1222097|Burning Webs|132910|a|-1||o||
1222207|Nether Strike|136181|t|5||o||
1222240|Transformation|132311|p|-1||o||
1222241|Transformation|132311|p|-1||o||
1222261|[DNT] Transform|236295|t|3||o||i
1222273|Transformation|132311|p|-1||o||
1222280|Transformation|132311|p|-1||o||
1222282|Transformation|132311|p|-1||o||
1222283|Transformation|132311|p|-1||o||
1222430|Rapid Decomposition|132095|p|-1||o||
1222476|(DNT) Plague Orb Goo Visuals|136243|p|-1||o||i
1222563|Fear|136183|t|4|magic|o||
1222564|Bloodlust|136012|p|15|magic|o||
1222567|War Stomp|132368|t|3||o||
1222578|Sleep|136090|t|10|magic|o||
1222581|Domination|136206|t|5||o||
1222688|Fixate|136129|t|-1||o||
1222772|Within Light|236252|t|-1||o||
1222930|Immolation|135817|p|-1||o||
1222932|Light|133750|p|-1||o||
1222933|Immolation|135817|p|-1||o||
1222934|Tormented|237569|p|-1||o||
1222939|Fiery Remnant|135805|a|-1||o||
1222942|Flame Shock|135813|t|12|magic|o||
1222950|Light|133750|p|-1||o||
1222951|Within Light|236252|t|-1||o||
1222989|Blight|132099|p|-1|disease|o||
1223009|Diseased|136243|p|-1||o||
1223037|Concord of the Challenger|236681|p|8||o||
1223047|Blight|132099|p|-1||o||
1223048|Last Rites|135976|p|900||o||
1223095|Emerald Nightmare|132123|p|-1||o||
1223265|Frailty|136119|t|15|magic|o||
1223278|Sword|136243|p|-1||o||
1223311|Guiding Torchlight|135432|p|-1||o||
1223342|Scarlet Inquisition|134503|p|15|magic|i||
1223348|Seal of the Dawn|236690|p|-1||i||
1223349|Seal of the Dawn|236690|p|-1||i||
1223350|Seal of the Dawn|236690|p|-1||i||
1223351|Seal of the Dawn|236690|p|-1||i||
1223352|Seal of the Dawn|236690|p|-1||i||
1223353|Seal of the Dawn|236690|p|-1||i||
1223354|Seal of the Dawn|236690|p|-1||i||
1223355|Seal of the Dawn|236690|p|-1||i||
1223357|Seal of the Dawn|236690|p|-1||i||
1223367|Seal of the Dawn|236689|p|-1||i||
1223368|Seal of the Dawn|236689|p|-1||i||
1223370|Seal of the Dawn|236689|p|-1||i||
1223371|Seal of the Dawn|236689|p|-1||i||
1223372|Seal of the Dawn|236689|p|-1||i||
1223373|Seal of the Dawn|236689|p|-1||i||
1223374|Seal of the Dawn|236689|p|-1||i||
1223375|Seal of the Dawn|236689|p|-1||i||
1223376|Seal of the Dawn|236689|p|-1||i||
1223379|Seal of the Dawn|134501|p|-1||i||
1223380|Seal of the Dawn|134501|p|-1||i||
1223381|Seal of the Dawn|134501|p|-1||i||
1223382|Seal of the Dawn|134501|p|-1||i||
1223383|Seal of the Dawn|134501|p|-1||i||
1223384|Seal of the Dawn|134501|p|-1||i||
1223385|Seal of the Dawn|134501|p|-1||i||
1223386|Seal of the Dawn|134501|p|-1||i||
1223387|Seal of the Dawn|134501|p|-1||i||
1223437|(DNT) Empower Quarter Visuals|136243|p|30||o||i
1223457|[DNT] Bounding Shadow Periodic|136243|p|5||o||i
1223458|Enrage|136224|p|120||o||
1223459|War Stomp|132091|t|5||o||
1223461|Flamethrower|135818||2||o||
1223462|Flamethrower|134535|p|4||o||
1223657|[DNT] Find Buzzkettle|136243||1||o||i
1223963|Corruption|136118|t|12|magic|o||
1223975|Eskhandar's Rage|134296|p|5||i||
1223997|Guiding Torchlight|135432|p|-1||o||
1224102|Ruins Near Xavian|134356|p|3||o||
1224125|Silence|135975|p|10|magic|o||
1224313|[DNT] Dark Rider Charge|136243|p|5||o||i
1224315|Grasping Spirits|237535|a|1.5||o||
1224316|[DNT] Grasping Spirits|136243|p|20||o||i
1224324|[DNT] Torment's Rage|136172|p|-1||o||i
1224428|Authority of the Frozen Wastes|236489|a|-1||o||
1224919|[DNT] Wiggling Spider Light|136243|p|-1||o||i
1225419|Necrotic Aura|132102|t|17||o||
1225420|Summon Enraged Tempest|136243|p|600||o||
1225423|Disarm|132343|t|8||o||
1225425|(DNT) Necrotic Aura Warning|136243|p|17||o||i
1225428|Disarm|132343|p|8||o||
1225430|(DNT) Necrotic Aura Warning|136243|p|14||o||i
1225769|Food|134062|p|30||i||
1225771|Food|134062|p|30||i||
1225772|Food|134062|p|30||i||
1225774|Food|134062|p|30||o||
1225778|Well Fed|133943|p|900||i||
1225779|Well Fed|133943|p|900||i||
1225780|Well Fed|133943|p|900||i||
1225782|Well Fed|133943|p|2700||o||
1225841|Curse of Recklessness|136225|t|120||o||
1225924|Balnazzar Encounter - Success|136243|p|1||o||
1225972|Catastrophe|133035|p|1||o||
1225987|Tinker: Nitro Boosts|135788|p|8||o||
1225994|Tinker: Nitro Boosts|135788|p|8||o||
1226035|Swiftbloom|136074|p|15||o||
1226038|Rejuvenating|132124|a|-1||o||
1226045|Demagnetized|133012|a|120||o||
1226105|Sunsurge|237537|p|15||o||
1226106|Moonsurge|136057|p|15||o||
1226127|Savage Flurry|132152|p|10||s||
1226136|Wicked Shot|236174|p|10||s||
1226218|Mark of Zeliek|136137|t|25||o||
1226219|Mark of Blaumeux|135900|t|25||o||
1226220|Mark of Mograine|136192|t|25||o||
1226221|Mark of Korth'azz|136172|t|25||o||
1226310|Acidic Burn|136118|p|-1||i||
1226357|Wicked Fast|135788|p|10||s||
1226369|(DNT) Empower Quarter Visuals|136243|p|30||o||i
1226372|(DNT) Empower Quarter Visuals|136243|p|30||o||i
1226373|(DNT) Empower Quarter Visuals|136243|p|30||o||i
1226377|Timey-Bearimy|237432|a|6||o||
1226396|Apple Scope|132327|p|-1||i||
1226406|Arcane Tunneling|135188|p|20||s||
1226414|Temporal Anchor|135127|a|8||o||
1226451|Emergency|135889|p|30||o||
1226461|Holy Power|252269|p|15||s||
1226464|Templar|236264|p|10||o||
1226466|Righteous Shield|134993|p|6||s||
1226500|Absolution|237550|p|15||o||
1226502|Devotion|135920|a|4||o||
1226529|Fish Barrel|132622|p|-1||o||
1226739|Undead Slaying|135914||30||s||
1226808|Food|133989|p|20||o||
1227022|Demonic Shade Vision|237561|p|300|magic|i||
1227088|Swiftearth|136074|p|15||o||
1227177|Burn|236302|t|4||o||
1227200|Wickedness|136214|p|15||s||
1227358|Retrieve the Blade|132219|p|2||o||
1227369|Searing Flames|135265|p|15|magic|i||
1227393|Carrion Swarm|136243|p|-1||o||
1227417|Eradication|136243|p|5||o||
1227435|Sleep|136090|t|90||o||
1227520|Lightforge|237541|p|-1||o||
1227696|Hallowed Dive|135887|p|-1||o||
1227700|Invisibility|135994|p|3||o||
1227703|Teleport|136243|p|1||o||
1227739|Hallowed Dive|136025|t|3||o||
1227772|Rapid Fire|132208|p|300||o||
1227820|Might of Menethil|133502|t|4||o||
1227879|Hallowed Dive|135887|p|5||o||
1228000|Lock On|135775||-1||o||
1228001|Lock On 2|135775||-1||o||
1228002|Divine Bulwark|237541|p|-1||o||
1228005|Ritual|236254|p|-1||o||
1228006|Ritual Burst|135880|p|0.75||o||
1228007|Ritual Light|136243|p|-1||o||
1228008|Divine Reach|135980|t|2||o||
1228009|Resurrection|135920|p|3||o||
1228063|Cremation|135926|a|30||o||
1228237|Shadow of Death|136160|p|-1||o||
1228262|Rend|132127|t|5||o||
1228267|Righteous Fire|135880|t|8||o||
1228295|Stomp|132368|p|3||o||
1228365|Sweeping Strikes|132306|p|10||o||
1228374|Oil Spill|252178|p|-1||o||
1228375|Fuse Lit|136243|p|5||o||
1228463|Cannon Fire|135805|a|5||o||
1228493|Explosive Shell|252172|t|3||o||
1228509|Burning Oil|252176|a|30||o||
1229005|Mortal Wound|132109|t|15||o||
1229045|Friend of Pupper|237554|a|7200||o||
1229228|Pounce|132142|t|2||o||
1229271|Fishing|136245|p|30||o||
1229272|Divine Conflagration|135826|t|5||o||
1229305|Climhazzard|6725876|p|-1||i||
1229308|Scarlet Steed|132238|p|-1||i||
1229397|Divine Conflagration|236228|a|30||o||
1229409|Overflowing Light|135872|a|-1||o||
1229423|[DNT] Tim's Test Visual|135126|p|-1||o||i
1229451|Boosted Rest|1001982|p|3600||o||
1229487|Camp Tent|134250|p|30||o||
1229503|Execution Sentence|236256|t|8||o||
1229508|Execution Sentence|236257|p|3||o||
1229704|Divine Conflagration|236228|a|-1||o||
1229730|Blinding Flare|135895|t|5||o||
1229739|Welcoming Campfire|135805|p|60||o||
1229741|Camp Benefits|7808144|p|3600||o||
1229754|Fish|4777763|p|-1||o||
1229760|Authoritative Slam|133046|t|4||o||
1230086|Threat of Arrest|134471|t|6|magic|o||
1230102|Open Wound|236304|t|5||o||
1230125|Wrath of the Crusade|135878|t|-1||o||
1230137|Wrath of the Crusade|136243|p|-1||o||
1230145|Wrath of the Crusade|136243|t|0.5||o||
1230200|Enervate|132848|t|30||o||
1230203|Incite Truth|136196|t|8|magic|o||
1230206|Snuff Out|133750|t|60|curse|o||
1230228|Pity|135975|t|-1|magic|o||
1230239|Deep Slumber|132156|p|-1||o||
1230242|Enkindle|132847|t|30||o||
1230268|Dying Light|237539|p|-1||o||
1230276|Blessed Fetters|136091|t|5||o||
1230279|Entangling Shot|136100|p|-1||o||
1230283|Entangling Shot|136100|t|5||o||
1230314|Cat Form|132115|p|240||o||
1230319|Vengeful Rage|136088|t|-1||o||
1230328|Glacial Aegis|135843|a|-1||o||
1230330|Glacial Aegis|135843|p|-1||o||
1230509|Collapsing Cathedral|136243|p|-1||o||
1230512|Collapsing Cathedral|135860|t|1||o||
1230576|Panic|135903|p|-1||o||
1230579|Holding on For Dear Life|237567|p|3.5||o||
1230596|Ashbringer|1109508|p|30||i||
1230647|Holding on For Dear Life|237567|p|3.5||o||
1230711|Cat Form|132115|p|240||o||
1230796|Tim's Test Weapon Visual|136243|p|10||o||i
1230809|Bloodflame|236305|a|-1||o||
1230895|Ruinous Presence|132291|p|-1||o||
1230897|Ruinous Presence|132291|a|-1||o||
1230908|Judge Unworthy|236258|a|2||o||
1230914|Flight Form|132128|p|-1||o||
1230942|Heart of Light|135980|p|20||i||
1230943|Abandoned Experiment|236886|p|-1||i||
1230944|Sir Dornel's Didgeridoo|133942|p|30||i||
1230990|Molten Armaments|236289|t|10||o||
1230992|Fel Fumes|132100|p|-1||o||
1230996|Imbued Assault|135811|a|30|magic|o||
1231000|Molten Remnant|135805|p|-1||o||
1231010|Tortuous Rebuke|132178|t|20||o||
1231012|Torment|236300|a|6||o||
1231040|Place Portiporter|135444|a|3||o||
1231087|Stock Break|236392|t|5||o||
1231091|Prototype Nitro Boosts|132996|p|5||i||
1231094|Fan of Knives|236273|t|20||o||
1231095|Peeled Secrets|136211|t|15||o||
1231102|Whirlwind|132369|p|20||o||
1231113|Target: Avenger's Shield|135874|t|5||o||
1231123|Bird Whistle|132161|p|3600||i||
1231124|Righteous Strength|135986|p|20|magic|e||
1231133|Molten Basin|237583|p|-1||o||
1231138|Righteous Fire|135986|p|20|magic|e||
1231147|Battering Ram|136243|p|-1||o||
1231162|Righteous Blasting|135986|p|20|magic|e||
1231201|Vengeance|132353|p|-1||o||
1231202|Scarlet Rally|5210047|p|-1||o||
1231203|Scarlet Rally|5210047|p|-1||o||
1231204|Scarlet Rally|5210047|p|-1||o||
1231212|Glorious Polymorph|135858|t|5||o||
1231215|Glorious Polymorph|136071|t|8||o||
1231227|Reborn Inspiration|5210047|p|2||o||
1231230|Reborn Inspiration|134503|p|2||o||
1231231|Reborn Inspiration|132769|p|2||o||
1231249|Wyvern's  Breath|134153|p|10||o||
1231254|Scarlet Bulwark|135874|p|10||i||
1231261|Rot|136134|t|12|disease|i||
1231264|Blades of Light|236250|p|6||o||
1231266|En Garde!|134537|p|15||i||
1231273|Peeled Secrets|136211|t|21||o||
1231278|Righteous Pursuit|136224|t|20||o||
1231280|Citizen's Arrest|134325|t|6||o||
1231289|Avatar of the Mountain|132275|p|15||i||
1231292|Detonation|134337|p|10||o||
1231301|Ablaze|135432|t|12|magic|o||
1231310|Watchman's Mark|132212|t|45|magic|o||
1231314|Radiant Divide|236263|t|5||o||
1231317|Rabid Bite|132127|t|9||o||
1231324|Rabies|132103|t|120|disease|o||
1231339|Corrupted Strength|135331|p|20||o||
1231343|Prey on the Weak|136122|p|-1||o||
1231375|Berserk|136206|p|-1||o||
1231376|Molten Basin|237583|a|-1||o||
1231381|Feral Dedication|132167|p|-1||o||
1231383|Divine Avatar|132275|p|15||o||
1231384|Stalk|132299|p|12||o||
1231387|Garrote|132297|a|30||o||
1231389|Vanish|132089|p|3||o||
1231397|Chew Hamstring|132316|t|10||o||
1231399|Legislate|237448|t|10||o||
1231402|Lightfist Flurry|133519|p|15||i||
1231406|Corrupted Agility|135331|p|20||o||
1231409|Ashbringer|1109508|p|30||o||
1231416|Coup|135397|t|15||o||
1231424|Coup|135397|t|15||o||
1231431|Toss|133976|t|1.5||o||
1231436|Regicide|343637|p|10||o||
1231444|Eat Apple|133977|p|10|magic|o||
1231503|Time is Money|237281|p|3600||o||
1231505|Thirst of Vis'era|132177|t|10||i||
1231509|Curse of Shame|132097|t|30|curse|o||
1231538|Blast Wave|135824|t|3||o||
1231541|Might of Vis'era|135277|p|1.5||o||
1231547|Bladestorm|132369|p|9||i||
1231548|Holy Might|135937|p|15||i||
1231551|Holy Might|135937|p|15||i||
1231561|Melting Point|135819|a|10||o||
1231579|Rapid Poison|132104|p|6|poison|o||
1231580|Foul Disease|136127|p|12|disease|o||
1231582|Dying Light|237539|t|20||o||
1231585|Tidal Force|237590|p|60||o||
1231587|Tidal Force|136148|p|-1||o||
1231590|Bestial Focus|135575|e|20|frenzy|o||
1231591|Bestial Focus|135575|p|20|frenzy|o||
1231592|Drowning Shallows|132322|t|10|curse|o||
1231601|Strand of Fate|135510|p|20||o||
1231604|Strand of Fate|135510|p|30||i||
1231605|EXPERIMENT-8OOM!!!|252185|p|20||i||
1231612|Soporific Strike|135275|p|20||i||
1231616|Soporific|136090|t|20|magic|o||
1231618|Wake of Ashes|135891|t|9||o||
1231623|Tyr's Return|237048|p|15||o||
1231625|Flames of the Red|133886|p|15||o||
1231651|Quietus|237531|t|9||o||
1231681|Spire of Sacrifice|133536|p|-1||i||
1231683|Spire of Sacrifice|135982|p|-1||o||
1231695|Condemned|304286|t|20|magic|i||
1231700|Fealty|135197|p|7||o||
1231712|Thundering Hooves|132226|t|1||o||
1231765|Coup|135397|t|15||o||
1231775|Scarlet Phalanx|132155|t|5||o||
1231776|Suppressing Darkness|136194|p|-1||o||
1231777|Suppressing Darkness|136194|a|-1||o||
1231836|Carrion Swarm|136128|a|20||o||
1231837|Carrion Swarm|136045|p|30||o||
1231843|Circle of Domination|136206|t|1||o||
1231844|Circle of Domination|136206|a|6||o||
1231845|Circle of Domination|136206|a|10||o||
1231854|Spirit Bond|136079|p|-1||o||
1231855|Spirit Bond|136243|p|-1||o||
1231858|Spirit Bond|136243|t|-1||o||
1231873|Confession|135975|t|3|magic|o||
1231874|Abandoned Experiment|236886|p|30||i||
1231883|Strength of the Bear|132183|p|-1||o||
1231884|Accuracy of the Owl|132192|p|-1||o||
1231885|Screeching Fear|136195|t|8|magic|o||
1231886|Speed of the Cat|132185|p|-1||o||
1231888|Agility of the Raptor|132193|p|-1||o||
1231891|Power of the Gorilla|132189|p|-1||o||
1231894|Ferocity of the Crocolisk|132187|p|-1||o||
1231896|Brilliance of Mr. Bigglesworth|236547|p|-1||o||
1231898|Infernal Presence|136219|p|-1||o||
1231904|Scarlet Bastion|5210047|p|15||i||
1231906|Summon Infernal|135860|t|4||o||
1231929|Scarlet Illusion|132288|p|600||o||
1231993|Tarnished Breath|135597|t|30||o||
1232013|Chains of Zeal|136091|p|-1|magic|o||
1232014|Scarlet Dominion|5210047|a|-1||o||
1232018|Blistering Vent|236228|t|10||o||
1232021|Aura of Dread|236293|a|-1||o||
1232026|Cleave|136243|p|-1||o||
1232030|Mystical Refraction|134094|p|60||o||
1232031|Mystical Refraction|134094|p|60||o||
1232037|Resilience of the Dawn|236689|a|-1||o||
1232038|Blue Coalescence|133244|p|300||o||
1232039|Red Coalescence|133238|p|300||o||
1232040|Violet Coalescence|133265|p|300||o||
1232043|Ambition|236310|p|-1||o||
1232051|Ambitious Pursuit|132178|p|-1||o||
1232052|Heads!|4638725|p|15||o||
1232062|Crimson Flare|236216|t|1.5||o||
1232064|Crimson Flare|236216|p|8||o||
1232088|Crimson Flare|236216|p|-1||o||
1232097|Crimson Flare|236216|a|-1||o||
1232117|Revitalize|236885|a|15|magic|o||
1232141|Green Coalescence|133263|p|300||o||
1232142|Yellow Coalescence|133248|p|300||o||
1232144|Orange Coalescence|133260|p|300||o||
1232146|Distracted|135737|p|-1||o||
1232169|Righteous Inquisition|236246|p|20|magic|e||
1232177|Light's Hope|135878|p|-1||o||
1232178|Light's Hope|135878|a|-1||o||
1232180|Screeching Frenzy|136224|p|30|frenzy|o||
1232187|Infernal Presence|136219|a|-1||o||
1232190|Debilitating Strike|135774|t|0.6||o||
1232192|Debilitate|135774|t|-1||o||
1232218|Armistice|236681|p|-1||o||
1232291|Calamity|236293|p|30||o||
1232312|Caladboulder|133540|t|4||i||
1232322|Caladbolg|252172|p|20||i||
1232333|Aberrant Bloat|135879|p|-1||o||
1232364|Divine Retribution|136243||3||o||
1232378|Body Swap|442272|p|7200||o||
1232383|Dominance Aura|135885|a|-1||o||
1232389|Unwavering Blade|135877|t|25||o||
1232390|Rose's Thorn|133436|t|-1||o||
1232575|Guardian Aura|135884|a|-1||o||
1232581|Liberation Aura|135901|a|-1||o||
1232637|Stock Break|236392|t|5||o||
1232678|Whirlwind|132369|p|4||o||
1232686|Crippling Wound|132109|a|15||o||
1232692|Stampede|6725876|p|2||o||
1232697|Stampede|136243|a|2||o||
1232702|Shockwave|236312|t|2||o||
1232703|Retribution Aura|135873|p|-1||o||
1232710|Seal of Protection|135964|a|8|magic|o||
1232734|Renew|135953|p|20|magic|o||
1232749|Holy Radiance|136243|p|2.5||o||
1232762|Fireball|135812|a|10||o||
1232842|Might of Vis'era|135277|t|5||o||
1232893|Crimson Crusade|135963|p|12||o||
1232959|Strand of Fate|135510|p|20||o||
1232969|Strand of Fate|135510|p|20||o||
1232976|Strand of Fate|237530|p|20||o||
1232979|Serpent Sting|132204|t|21|poison|o||
1232980|Serpent Sting|132204|t|42|poison|o||
1232981|Serpent Sting|132204|t|63|poison|o||
1232982|Serpent Sting|132204|t|84|poison|o||
1233028|No Man's Land|132210|p|-1||o||
1233029|Imprisonment|134235|t|2||o||
1233077|Curse of Agony|136139|t|15|curse|o||
1233079|Radiant Missiles|136096|p|5||o||
1233293|Battle Cry|132351|p|30|frenzy|o||
1233344|Devotion Aura|135893|p|-1||o||
1233361|Divine Hammer|236262|a|10||o||
1233451|Trick Shots|132330|p|12||s||
1233525|Avenging Shield|135875|p|35||o||
1233835|Thunder and Lava|237589|p|15||s||
1233842|Fire's Glow|136057|p|7||o||
1233847|Scarlet Grasp|134515|t|1||o||
1233849|Unstable Concoction|134799|t|7||o||
1233853|Serrated Blades|132290|p|30||o||
1233880|Toxic Coagulant|134761|p|15||o||
1233883|Intoxicating Venom|134761|t|6||o||
1233884|Sludge Toxin|134806|p|5||o||
1233901|Noxious Poison|134763|t|8|poison|o||
1233988|Infernalist Armor|236418|p|20||s||
1234005|Slammin'|132340|p|15||o||
1234031|Reckless Strength|132109|p|-1||o||
1234067|Gladiator's Cunning|236535|p|15||s||
1234069|Punch Harder|132334|p|30||o||
1234071|Flurry of Blades|236303|p|15||o||
1234320|Epoch's End|134234|p|7||o||
1234347|Ignite Flesh|135805|t|10||o||
1234540|Ignite|135818|t|15||o||
1234542|Redeemed|132865|p|10||o||
1234545|Immolation Aura|135817|p|15||o||
1234595|Vanish|132331|p|20||o||
1234708|Toxic Pool|236271|a|-1||o||
1234722|Carrion Swarm|136128|p|-1||o||
1234893|Crusader Strike|135924|t|30|magic|o||
1235119|Ninja Costume|133143|p|7200||o||
1235122|Ninja Costume|133143|p|7200||o||
1235140|Ride Gryphon|136243|a|-1||o||
1235317|Immolate|135817|t|15|magic|o||
1235318|Blast Wave|135903|t|6||o||
1235321|Imbued Assault|135811|a|30|magic|o||
1235327|Decrepit Fever|132100|t|20|disease|o||
1235328|Curse of Impotence|136020|t|120|curse|o||
1235336|Crimson Crusade|135963|p|12||o||
1235341|Crimson Crusade|135963|p|12||o||
1235348|Crimson Crusade|135963|p|12||o||
1235353|Mercy by Fire|305703|p|12||o||
1235355|Mercy by Fire|305703|p|12||o||
1235359|Mercy by Fire|305703|p|12||o||
1235390|Mercy by Fire|305703|e|12||o||
1235492|[DNT] Tim's Test Visual|135126|p|-1||o||i
1235538|Charge|132337|t|2||o||
1235689|Transformation|132311|p|-1||o||
1235805|[DNT] Frozen Emote|136243|p|-1||o||i
1236125|Rend Flesh|132152|t|60||o||
1236151|Renew|135953|a|15|magic|o||
1236152|Volcanic Unrest|135819|p|-1||o||
1236154|Power Word: Shield|135940|a|30|magic|o||
1236157|Volcanic Unrest|237582|a|-1||o||
1236162|Holy Fire|135972|t|10|magic|o||
1236173|Pyroblast|135808|t|12||o||
1236174|Polymorph|136071|t|20|magic|o||
1236175|Blink|135736|p|1||o||
1236176|Disarm|132343|t|10||o||
1236177|Hamstring|132316|t|5||o||
1236179|Shield Slam|132357|t|1||o||
1236182|Crusader Strike|135924|t|30|magic|o||
1236191|Concussive Shot|135860|t|3|magic|o||
1236220|Slow|136091|t|20|magic|o||
1236265|Veil of Darkness|136160|t|-1||o||
1236270|Goblin Dragon Gun|135818|p|8||o||
1236287|Holy Fire|135972|t|10|magic|o||
1236290|Polymorph|136071|t|20|magic|o||
1236291|Pyroblast|135808|t|12||o||
1236306|Divine Avatar|132275|p|-1||o||
1236307|Rejuvenation|136081|a|15|magic|o||
1236318|Crimson Flare|236216|p|5||o||
1236339|Veil of Darkness|136160|t|-1||o||
1236879|Fire's Glow|135939|p|-1||o||
1237171|Crimson Flare|135822|a|-1||o||
1237317|Twisting Nether|236296|p|-1||o||
1237632|Divine Steed|135890|p|3||o||
1237702|Transformation|132311|a|-1||o||
1237726|(DNT) Ride Vehicle Camera Test|136243|p|-1||o||i
1237939|Berserk|132117|p|3600||o||
1238097|Ninja Costume|133143|p|1800||o||
1238319|Shadow Crash|136197|a|-1||o||
1238320|Shadow Barrier|136121|p|600||o||
1239045|Holy Radiance|237541|t|5||o||
1239100|Shadow Barrier|136121|p|-1||o||
1239456|Cannon Fire|252185|t|3||o||
1239543|Sunlight|135878|p|10||o||
1239832|Impact|135807|p|15||o||
1240330|Rediscovering the Light|135914|p|-1||o||
1240574|Templar|236264|p|10||o||
1240686|Slow|136091|t|5|magic|o||
1240688|Entangle|136100|t|6|magic|o||
1240732|Penance|237545|p|2||o||
1240733|Penance|237545|p|2||o||
1240734|Penance|237545|p|2||o||
1240736|Penance|237545|p|2||o||
1240738|Drain Vitality|132146|t|10|magic|o||
1240750|Debilitate|136130|t|1||o||
1240822|Channeling|136243|p|-1||o||
1240830|Disruption|136243||-1||o||
1240848|Prayer of Mending|135944|a|30|magic|o||
1240849|Prayer of Mending|135944|a|30|magic|o||
1240869|Manamorph|136116|t|8|magic|o||
1241115|Sense Undead|135974|p|-1||o||
1241329|Malfunction|135735|p|6||o||
1241501|Focal Blast|4667417|p|6||o||
1241514|Focal Blast|4667417|a|-1||o||
1241523|Bounding Mana|236222|a|6||o||
1241695|Arcane Ward|136243|p|-1||o||
1241810|Cutthroat|236280|p|-1||o||
1242163|Transfusion|135730|p|-1||o||
1242436|Raise Dead|136187|p|12||o||
1242871|Solar Burst|2175503|t|10|magic|o||
1242884|Intimidating Roar|132154|t|8||o||
1242913|Harvest Curse|615099|t|20|magic|o||
1242971|Unstable Affliction|136228|t|18|magic|o||
1242972|Unstable Affliction|136228|t|18|magic|o||
1242979|Rejuvenation|136041|p|10||o||
1243030|Demonic Tactics|136150|p|-1||o||
1243120|Demonic Knowledge|136165|p|-1||o||
1243170|Slipped!|135860|p|2||o||
1243229|Impair|132102|t|20||o||
1243268|Impervious|1851463|p|-1||o||
1243419|Flee|237552|p|1||o||
1243845|Sated|237331|p|1800||o||
1243846|Soothed|133686|p|1800||o||
1243847|Quenched|136088|p|1800||o||
1244416|Stomp|132368|t|2||o||
1244447|[DNT] Leyline Rift Visual Aura|136116|p|-1||o||i
1244482|Improvised Weapon|648803|t|-1||o||
1244484|Whirlwind|132369|p|10||o||
1244493|Best Served Cold|135817|p|-1||o||
1244967|Hallow's Curse|136189|t|60|curse|o||
1244970|Frostbolt|135846|t|4|magic|o||
1245095|Best Served Cold|136049|p|-1||o||
1245119|Bestial Roar|463283|t|15||o||
1245130|Flame Roar|615339|t|15||o||
1245154|Thunder Roar|136050|t|3||o||
1245164|Vicious Maul|136168|t|10||o||
1245244|Minor Arcane Elixir|134728|p|1800||i||
1245249|Elixir of Minor Force|134857|p|1800||i||
1245747|Shadow Channeling - Channel Cast Visual|132303|p|-1||o||
1245883|Purge|136075|t|3||o||
1245940|Bloodlust|136012|p|-1||o||
1246026|Herbal Soil Poultice|133690||6||i||
1246031|Hunting Kobolds|134168|p|900||i||
1246362|Nightmare Detonation|1357798|t|10||o||
1246367|Nightmare Detonation|1357799|a|-1||o||
1246456|Crimson Wrest|237564|t|6||o||
1246989|Planting Seed|236160|a|10||o||
1247087|Fear|136183|t|4|magic|o||
1247169|Devour|136027|p|-1||o||
1247237|Profane Protection|1357807|p|-1||o||
1247252|Purify|1538775|t|-1||o||
1248000|Flame Shock|135813|t|12|magic|o||
1248001|Frost Shock|135849|t|8|magic|o||
1248148|Frostbolt|135846|t|4|magic|o||
1248406|Well Fed|133943|p|900||i||
1248420|Well Fed|133943|p|900||i||
1248421|Well Fed|133943|p|900||i||
1248422|Well Fed|133943|p|900||i||
1248633|FX Test Aura|136243|a|10||o||i
1248688|Well Fed|133943|p|900||i||
1248808|Revelation|135934|p|15||o||
1248947|Fel-Tainted Spittle|136016|t|10|poison|o||
1249012|Fury of the Ancestors|134919|p|12||o||
1249033|Lingering Fel Disease|132101|t|900|disease|o||
1249110|Chthonic Power|134131|p|15||i||
1249113|Molten Fury|134128|p|15||i||
1249119|Eternal Power|134094|p|15||i||
1249519|Well Fed|133943|p|900||i||
1249520|Well Fed|133943|p|900||i||
1249521|Well Fed|133943|p|900||i||
1249523|Well Fed|133943|p|900||i||
1249755|Summoning Disorientation|135860|p|6||o||
1249834|Scared|237552|p|3|magic|o||
1249907|Well Fed|133943|p|900||i||
1249926|Well Fed|133943|p|900||i||
1249927|Well Fed|133943|p|900||i||
1250421|Withering Link|3154546|p|-1||o||
1250423|Demonic Frenzy|136172|p|10|frenzy|o||
1250887|Revealing Draught|967559|p|1800||i||
1250889|Potion of Predatory Senses|967555|p|90||i||
1250918|Elixir of Cunning|134794|p|1800||i||
1250920|Elixir of the Phalanx|967529|p|1800||i||
1250922|Minor Cleric's Elixir|967524|p|1800||i||
1250924|Lesser Cleric's Elixir|134752|p|1800||i||
1250925|Cleric's Elixir|134764|p|1800||i||
1250926|Greater Cleric's Elixir|134777|p|1800||i||
1250928|Elixir of Fortitude|134824|p|1800||i||
1250931|Elixir of Greater Fortitude|134825|p|1800||i||
1250932|Elixir of Wicked Regeneration|967526|p|1800||i||
1250940|Elixir of the Owl|134792|p|1800||i||
1250941|Elixir of Sages|134793|p|1800||i||
1250942|Minor Mageblood Elixir|967519|p|1800||i||
1250944|Lesser Mageblood Elixir|134750|p|1800||i||
1250948|Greater Mageblood Elixir|134796|p|1800||i||
1250971|Lesser Arcane Elixir|134729|p|1800||i||
1250972|Elixir of Nature Power|134877|p|1800||i||
1250974|Elixir of Minor Spirit|134736|p|1800||i||
1250976|Elixir of Lesser Spirit|134737|p|1800||i||
1250978|Elixir of Spirit|134738|p|1800||i||
1250979|Elixir of Greater Spirit|134739|p|1800||i||
1250981|Elixir of the Whale|134791|p|1800||i||
1250984|Elixir of Strength|134838|p|1800||i||
1250985|Elixir of Ferocity|134789|p|1800||i||
1250986|Elixir of the Grizzly|134788|p|1800||i||
1250988|Elixir of Lesser Intellect|134823|p|1800||i||
1250989|Elixir of Intellect|134824|p|1800||i||
1251286|Unstable Package|132489|p|-1||i||
1251362|Unstable Fuel Cell|135805|p|6||o||
1251364|Misfire|135805|p|-1||o||
1251394|Parachute|135992|p|-1||o||
1251474|Paeonia's Melody|133941|t|180||o||
1251563|Paeonia's Melody|133941|p|600||o||
1251657|Stoneskin|135034|p|-1||o||
1251691|Dry|132839|p|1800||o||
1251692|Grounded|399040|p|1800||i||
1251693|Cooled|893777|p|1800||o||
1251791|Drying Off|135805|p|10||o||
1251919|Minor Spellblasting Potion|967557|p|30||i||
1251922|Lesser Spellblasting Potion|463545|p|30||i||
1251923|Spellblasting Potion|463921|p|30||i||
1251924|Greater Spellblasting Potion|464027|p|30||i||
1251931|Superior Spellblasting Potion|463859|p|30||i||
1251932|Major Spellblasting Potion|463929|p|30||i||
1251933|Minor Frenzy Potion|967555|p|30||i||
1251935|Lesser Frenzy Potion|463548|p|30||i||
1251936|Frenzy Potion|463922|p|30||i||
1251937|Greater Frenzy Potion|464024|p|30||i||
1251938|Superior Frenzy Potion|463863|p|30||i||
1251940|Major Frenzy Potion|463931|p|30||i||
1251942|Minor Mender's Potion|967556|p|30||i||
1251944|Lesser Mender's Potion|463547|p|30||i||
1251945|Mender's Potion|463925|p|30||i||
1251946|Greater Mender's Potion|464026|p|30||i||
1251947|Superior Mender's Potion|463860|p|30||i||
1251948|Major Mender's Potion|463927|p|30||i||
1251986|Venomous Blood|134799|p|20||i||
1251993|Venomous Blood|134799|t|20||o||
1252000|Test Bleed|4554445|a|300||o||i
1252017|Drying Off|135805|p|5||o||
1252100|(DNT) TEST Mini Visuals|237285|p|-1||o||i
1252106|Cooling Down|135864|p|5||o||
1252188|(DNT) TEST Skeleton Mini Visuals|237285|p|-1||o||i
1252543|Caustic Smog Potion|967550|t|-1||o||
1252546|Disorienting Smog Potion|967548|t|-1||o||
1252554|Dragonfire Potion|134813|t|8|magic|i||
1252558|Potion of Elemental Purging|2057575|p|300||i||
1252559|Potion of Beast Slaying|2057578|p|300||i||
1252576|Savory Whimsyfin Delight|237320|p|3600||i||
1253151|Sanctuary of the Shen'dorei|5922053|p|-1|magic|o||
1253200|Fly Away!|451170|p|5||o||
1253317|Slam|132357|t|2||o||
1253348|You Smell Like Garbage|132098|p|900||o||
1253351|Garbage Smell|136243|t|15||o||
1253365|Hard Pull|2437249|a|7||o||
1253366|Hard Pull|2437249|a|7||o||
1253414|Dying Will|136187|p|-1||o||
1253552|Foul Volley|136016|t|6|poison|o||
1253568|Tranquility|136107|p|15||o||
1253772|Digging|132098|p|10||o||
1253931|Blue Beam|136208||-1||o||
1254480|Bloodfury|236310|p|30||o||
1254492|Buzzing Insects|132104|p|-1||o||
1254516|Wild Detonation|2065634|p|20||o||
1254546|Cleansed|132851|p|1800||i||
1254565|On Thin Ice|612394|a|30||o||
1254832|Mark of Akir|606549|p|-1||o||
1255229|Recently Dropped Flag|132484|p|3||o||
1255770|[DNT] Vehicle Force Cast|236316|p|-1||o||i
1255936|Miniature Morphologic Mimic Encabulate|319458|p|120||i||
1255938|Skunk Spray|132100|t|10|magic|o||
1255944|Spirit of Wind|136121|p|-1||o||
1255945|Wind Hollow|136121|p|-1||o||
1255946|Forest Gale|136121|p|-1||o||
1256138|Allstrike|135400|p|0.25||o||
1256139|Allstrike|135400|p|0.25||o||
1256140|Allstrike|135400|p|0.25||o||
1256141|Allstrike|135400|p|0.25||o||
1256142|Allstrike|135400|p|0.25||o||
1256143|Allstrike|135400|p|0.25||o||
1256144|Allstrike|135400|p|0.25||o||
1256145|Allstrike|135400|p|0.25||o||
1256146|Allstrike|135400|p|0.25||o||
1256147|Allstrike|135400|p|0.25||o||
1256148|Allstrike|135400|p|0.25||o||
1256158|Weightless|135863|p|-1||o||
1256161|Tow Beam|136235||-1||o||p
1256187|Priestess Levitation|136243|p|10||o||
1256717|Wind Bridge|135863|p|9||o||
1256867|Stealth|132320|p|-1||o||
1256991|Sneak|132320|p|-1||o||
1257055|Fly Away!|136183||6|magic|o||
1258428|Saving Fillion Flamebreeze|136243||-1||o||
1258429|Saving Fillion Flamebreeze|236440|p|300||o||
1258446|Saving Fillion Flamebreeze|136243|p|1||o||
1258447|Standing Stone Study|136208||-1||o||
1258510|Blessing of Zephras|132307|p|300||o||
1258520|Pounce|132142|t|3||o||
1259338|Entangle|136100|p|30||o||
1259630|Newborn Shriekling|4630415|p|-1||o||
1259907|Drums of War|133841|p|15||o||
1260168|Gelkis Banner|136243|p|-1||o||
1260248|Mod Pet Spell Power Test|236294|e|120||o||i
1260639|Carry Stag|136243||-1||o||
1260650|Bash|132340|t|3||o||
1261177|Eavesdrop|132320||30||o||
1261425|Repairing|132098|p|10||o||
1261483|Thrill of Adventure|236180|p|10||o||
1261854|Personal Banking|413587|p|3600||o||
1262044|Second Home|1041860|p|-1||o||
1262050|Second Home|1041860|p|-1||o||
1262149|Small Target|133749|p|-1||o||
1262229|The Quick and the Dead|413591|p|-1||o||
1262243|The Quick and the Dead|413591|p|120||o||
1262307|The Quick and the Dead|413591|p|120||o||
1262309|The Quick and the Dead|413591|p|120||o||
1262310|The Quick and the Dead|413591|p|120||o||
1262312|The Quick and the Dead|413591|p|120||o||
1262315|The Quick and the Dead|413591|p|120||o||
1262316|The Quick and the Dead|413591|p|120||o||
1262317|The Quick and the Dead|413591|p|120||o||
1262321|Pearl of Elune|237371|p|60||o||
1262528|Rathiril's Water Waltz|135863|p|600||o||
1262542|Scale Design Considerations|134164|p|-1||o||
1262777|Second Chance|132151|a|-1||o||
1262926|Trample|136243|a|3||o||
1262943|Fearful|133208|t|3||o||
1262962|Vengeful|960698|t|12||o||
1263086|Boiling Scream|1035041|t|30||o||
1263129|Vicious Bite|132278|a|20||o||
1263260|Thornwhip|960682|t|12|poison|o||
1263284|Siphoned Mana|135738|p|-1|magic|o||
1263388|Theater Lightning|136243|p|10||o||
1263389|Theater Lightning|136243|p|3||o||
1263390|Theater Lightning|136243|p|2.5||o||
1263407|Theater Lightning|136243|p|2.5||o||
1263629|Battle Snort|132184|p|120||o||
1263640|Entangling Roots|136100|t|6|magic|o||
1263738|Rotting Spit|576312|a|-1||o||
1263985|Fel Timbers|135794|a|-1||o||
1263989|Poison Dart|236200|p|30|poison|o||
1264118|Speak With Animals|464604|a|600||o||
1264340|Forgotten Memories|136243|p|30||o||
1264366|Creeping Darkness|136122|t|10||o||
1264377|Blue Eyes|4630418|p|-1||o||
1264400|Green Eyes|4630421|p|-1||o||
1264401|Red Eyes|4622453|p|-1||o||
1264413|Statue Shake|136243|p|2||o||
1264437|Extremely Loud Bark|1709931|t|8||o||
1264530|Apparition|135994|p|-1||o||
1264548|Pounce|132142|t|2||o||
1264747|Serpent Sting|132204|t|15|poison|o||
1265304|Deep-Sea Waders|134776|p|60||i||
1265376|MRN Test Spell|136243|a|10||o||i
1265416|Badwind Slam|132340|t|2||o||
1265500|Watchful Eye|132284|a|-1||o||
1265557|Conqueror of Corpsefeeder|132184|p|-1||o||
1265889|Wind Channeling|236154|p|-1||o||
1265896|Channel Winds|136121|p|-1||o||
1265981|Birth|136243|p|4||o||
1265983|Ghost Light|136243|p|-1||o||
1266011|Life Drain|136169|t|16|magic|o||
1266050|Apparition|135994|p|-1||o||
1266240|Corroding Spit|136007|t|20||o||
1266369|Grow|135871|p|300|magic|o||
1266641|Frost Breath|135848|t|6||o||
1266642|Frostbolt Volley|135846|t|8|magic|o||
1266680|Bone Armor|136225|a|60|magic|o||
1267113|Abyssal Shield|1320371|p|-1||o||
1267193|Dismissal|237508|a|1.5||o||
1267199|Arcane Transference|237508|a|2||o||
1268774|Dread Raven Form|136076|p|30||o||
1268813|Arcane Animation|135994|p|-1||o||
1268815|Spider Form|2027952|p|30||o||
1268826|Thunder Lizard Form|2027952|p|30||o||
1269045|Dreamfall|1033487|p|75||o||
1269047|Convoke the Spirits|136116|p|60||o||
1269048|Assimilation|840405|p|60||o||
1269135|Apparition|135994|p|-1||o||
1269140|Prototype Recalibrator|133282|p|7200||o||
1269150|Wild Form|2011150|p|-1||o||
1269161|SAF-T Copper Bomb|135826|t|1||i||
1269192|EZ-Thro Copper Bomb XL|135826|t|1||i||
1269216|SAF-T Bronze Bomb|135826|t|2||i||
1269268|EZ-Thro Bronze Mortar|135826|t|2||i||
1269272|SAF-T Bomb|135826|t|3||i||
1269278|Tru-Trigger Frag Bomb|135826|t|2||i||
1269330|EZ-Thro Thorium Grenade|135826|t|3||i||
1269334|EZ-Thro Dark Bomb|135826|t|4||i||
1269337|EZ-Thro Mana Bomb|135975|t|5|magic|i||
1269354|Ketharas' Hyjal Stew|134062|p|30||i||
1269404|Shrouding Bolt|4226154|t|30||o||
1269433|Earthgrab|136064|t|-1||o||
1269532|Assimilation|840405|a|-1||o||
1269555|Soul Rip|136163|t|5||o||
1269557|Fractured Soul|4914675|p|2||o||
1269585|Dreadful Screech|3163624|t|10|magic|o||
1269603|Dire Laceration|1035041|a|20||o||
1269624|Malignancy|132108|t|30|poison|o||
1269767|Silken Tomb|237430|a|90||o||
1269872|Haunt|236298|p|5||o||
1269877|Savage Slam|135860|a|4||o||
1269929|Dust Storm|796635|p|3600||o||
1269934|Crown of the Heavens|236160|p|-1||o||
1269955|Fel Ash|132843|p|3600||o||
1269957|Sweltering Heat|136196|p|3600||o||
1269958|Torrential Rain|132844|p|3600||o||
1269960|Sleeting Snow|236209|p|3600||o||
1269962|Scorching Sun|5927633|p|3600||o||
1269966|Galeforce Wind|1029585|p|3600||o||
1270035|Stealth|132320|p|-1||o||
1270105|[DNT] Illusion|136243|a|-1||o||i
1270187|Soul Vigor|4914678|p|-1||o||
1270257|Rootbound Agony|134413|p|-1||o||
1270422|Levitate|135928|p|-1||o||
1270427|Malady|132291|t|5||o||
1270462|Lightning Shield|136051|p|600|magic|o||
1270498|Soul Tether|4914679|p|30||o||
1270585|Stun Self|136235|p|3||o||p
1270593|Snare Limit|136243|p|-1||o||
1270602|Blue Beam|136208||-1||o||
1270643|Unstable Dream|840198|p|30||o||
1270648|Dreamless Waking|1394953|p|10||o||
1270650|Lunar Fire|136096|t|20|magic|o||
1270651|Umbral Fire|136096|t|20|magic|o||
1270781|Enchanted|135939|p|-1||o||
1270803|Lunar Decay|135731|a|4||o||
1270810|Unstable Dream|840198|a|-1||o||
1270811|Intimidating Shout|132154|t|5||o||
1270825|Furious Breach|4643994|a|30||o||
1270942|Poultryized!|133028|t|15|magic|o||
1270943|Poultryized!|133028|p|15|magic|o||
1270944|Poultryized!|133028|t|15|magic|o||
1271000|Crushing Brambles|136100|a|90||o||
1271007|Umbral Decay|237566|a|4||o||
1271020|Gliding on Air|237276|p|10||o||
1271044|Jammed Mechanism|135899|p|5||o||
1271102|Tame Vuldren|132164|t|900||o||
1271103|Tame Vuldren|132164|t|20||i||
1271266|Stealth Field|133862|p|60||i||
1271351|Lunar Mark|136057|t|-1|magic|o||
1271352|Umbral Mark|1392545|t|-1|magic|o||
1271357|Collapsing Star|136057|p|180||o||
1271394|Blizzard|135857|t|-1||o||
1271412|Lunar Mark Protection|136243|p|20||o||
1271414|Collapsing Star|136116|p|-1||o||
1271427|Lunar Mark Search Periodic|136243|a|60||o||
1271513|Venom Spit|136016|t|10|poison|o||
1271514|Rupture|132302|t|10||o||
1271565|Umbral Mark Protection|136243|p|20||o||
1271567|Umbral Collapse|1394892|p|-1||o||
1271593|Fear|136183|t|4|magic|o||
1271604|Searing Scales|134310|t|18||o||
1271632|Astral Bulwark|135733|p|60||o||
1271759|Starfall|1392544|p|15||o||
1271761|Grievous Garrote|236268|t|90||o||
1271816|Unnerving Mist|1778226|a|-1||o||
1271844|Revolting Strike|136145|a|45||o||
1271868|Writhing Agony|463286|p|604800||o||
1271952|Leyline Convergence|4226150|p|10||o||
1271953|Elemental Convergence|4226150|p|10||o||
1272014|Halaan's Gift|132150|p|60||o||
1272112|Red Eyes|4622453|p|-1||o||
1272366|Everlasting Bond|132265|p|-1||o||
1272371|Everlasting Bond|132265|t|-1||o||
1272446|Everlasting Bond|236449|t|-1||o||
1272447|Everlasting Bond|236449|p|-1||o||
1272606|Rain of Arrows|132381|a|-1||o||
1272794|Elune's Grace|135900|p|-1||o||
1272804|Elune's Grace|135900|p|-1||o||
1272962|Storm Leap|839983|t|10||o||
1272973|Ruination|132095|t|10|curse|o||
1272982|Rupture|132141|t|45||o||
1273320|Hearty Stew|237331|p|30||o||
1275511|Wounded|237513|p|-1||o||
1275553|Growing Flames|135805|p|25||o||
1275832|No Man's Land|135724|p|-1||o||
1275865|No Man's Land|135724|p|-1||o||
1276442|Resting|132792|p|-1||o||
1277018|Grow|134712|p|480||o||
1277329|Green Skeletal Horse|132264|p|-1||i||
1277330|Dark Skeletal Horse|132264|p|-1||i||
1277336|Purple Skeletal Horse|132264|p|-1||i||
1277364|Desecration|136154|p|-1||o||
1277406|Profane Bulwark|237180|p|-1||o||
1277417|Desecration|136154|p|-1||o||
1277424|Shield Wall|132362|p|10||o||
1277431|Desecration|136154|p|-1||o||
1277741|Command: Bite!|237395|t|15||o||
1277794|Tame Beast|132164|t|20||i||
1277851|Tame Boar|132164|t|900||o||
1278028|Tame Beast|132164|t|20||i||
1278029|Tame Beast|132164|t|20||i||
1278060|Tame Wolf|132164|t|900||o||
1278061|Tame Bear|132164|t|900||o||
1278162|Ghost|132331|p|-1||o||
1278201|Sing|237540|p|1.5||o||
1278910|Always Injured|132311|a|-1||o||
1279399|Summon Warhorse|136103|p|-1||o||
1279522|Color Test|136243|p|-1||o||i
1279692|Flare|135815|t|30||o||
1280003|Tame Crawler|132164|t|20||i||
1280004|Tame Crawler|132164|t|900||o||
1280011|Rending Whirl|1035055|t|15||o||
1280044|Tame Galestrider|132164|t|900||o||
1280046|Tame Galestrider|132164|t|20||i||
1280259|Convert|237566|t|20||o||
1280262|Shadow Infusion|134923|p|12|magic|o||
1280341|Uncommon Fishing|133899|p|3600||o||
1280342|Rare Fishing|5976329|p|3600||o||
1280353|Consecration|135926|t|0.6||o||
1280468|Moonfire|136096|t|20|magic|o||
1280481|Fox-Catching Net|132149||10||i||
1280533|Lunar Trace|5976942|t|5||o||
1280540|Lunar Strike|1041233|a|1||o||
1280564|Rejuvenation|136081|p|15|magic|o||
1280634|Tranquility|136107|p|10||o||
1280662|Boar's Delight|132184|p|-1||o||
1280857|Champion of the Bloodmaster's Ring|236695|p|900||o||
1281530|[TEST] Mount Rental - Alliance|132247|p|120||o||i
1281640|Sing|237540|p|3||o||
1281778|Force of Nature|136100|p|30||o||
1281781|Entangling Roots|136100|a|5|magic|o||
1281782|Force of Nature|132129|p|3||o||
1281887|Recently Entangled|136243|p|8||o||
1282071|Frightening Howl|136183|t|4||o||
1282082|Command: Kill!|841383|t|10||o||
1282387|Mugg's Fury|1058933|p|-1||o||
1282393|Set of Maces|458797|p|-1||o||
1282394|Set of Mauls|132349|p|-1||o||
1282448|Sky|136243|p|-1||o||
1282482|Searing Wound|135902||12|magic|i||
1282495|Unnatural Resilience|1392566|p|-1||o||
1282504|Monstrous Slam|132318|t|3||o||
1282511|Undying Oath|298678|p|-1||o||
1282519|Rotted Strike|305703|t|10|magic|o||
1282571|Swim|136243|p|-1||o||
1282843|Embrine|512902|a|-1||o||
1283027|Poisoned Blood|132108|p|-1||o||
1283081|Shield Slam|132357|t|2||o||
1283082|Well Fed|133943|p|120||o||
1283087|Curse of Blood|136189|t|600|curse|o||
1283098|Meat Tracking|136243|p|10||o||
1283101|Scolded|237555|p|300||o||
1283233|Deluge|135787|p|10||o||
1283266|Drain Blood|1035037|t|6||o||
1283295|Transform|2399269|p|-1||o||
1283313|Poison Bolt Volley|136016|t|20|poison|o||
1283348|Horrifying Presence|136147|a|-1||o||
1283361|Curse of Weakness|136138|t|120|curse|o||
1283364|Net|132149|t|5||o||
1283366|Shadow Shell|136121|p|10|magic|o||
1283390|Sunder Armor|132363|t|30||o||
1283405|Muscle Tear|1508489|t|5||o||
1283409|Hex|136071|a|20|magic|o||
1283410|Frostbolt|135846|t|4|magic|o||
1283414|Mortal Strike|132355|t|5||o||
1283416|Poisonous Stab|136077|t|15|poison|o||
1283419|Frost Armor|135843|p|1800|magic|o||
1283420|Frostbolt|135846|t|4|magic|o||
1283423|Rend|132155|t|15||o||
1283701|Boosted Disenchanting|237020|p|-1||o||
1283792|Dark Binding|3717602|p|10||o||
1283793|Fel Smoke|135794|p|-1||o||
1283888|[DNT] Aura Never Secret Test Spell|136243|p|10||o||i
1283894|[DNT] Aura Always Secret Test Spell|136243|p|10||o||i
1283919|Totally A Warlock|132288|p|-1||o||
1283934|Fear|136183|t|4|magic|o||
1284017|Track Beasts|132328|p|3600||o||
1284191|Ride Hippogryph|1610261|a|-1||o||
1284376|Frost Aura|135833|p|-1||o||
1284381|Heavy Stomp|132368|t|2||o||
1284435|Enrage|136224|p|30||o||
1284450|Stasis|2000859|p|-1||o||
1284543|Theramore Marine Disguise|133070|p|-1||i||
1284560|Darkspear Islands Flag|132487|a|-1||o||
1285368|Gathering Intelligence|132288|a|60||o||
1285369|Standing "Guard"|132320||60||o||
1285372|Vanish|132331|p|6||o||
1285835|Channeling Crystal|5929569|p|5||o||
1285903|Being Hunted...|132270|p|-1||o||
1285982|Channeling Crystal|5929571|p|5||o||
1285983|Channeling Crystal|5929572|p|5||o||
1285995|Attuned|136243|p|5||o||
1285996|Attuned|136243|p|5||o||
1285997|Attuned|136243|p|5||o||
1286011|Swift Empyrean Galestrider|7754707|p|-1||i||
1286021|Swift Regal Galestrider|7754705|p|-1||i||
1286022|Swift Stormy Galestrider|7754704|p|-1||i||
1286024|Empyrean Galestrider|7754724|p|-1||i||
1286025|Regal Galestrider|7813746|p|-1||i||
1286026|Stormy Galestrider|7813745|p|-1||i||
1286050|Crystallize|429385|t|5||o||
1286090|Resting|6403297|p|-1||o||
1286114|Starfall|236168|p|5||o||
1286251|(DNT) Blessing of Salvation - TEST RAID SPELL|135967|a|1800|magic|o||i
1286252|(DNT) Blessing of Wisdom - TEST RAID SPELL|135970|a|1800|magic|o||i
1286253|(DNT) Blessing of Might - TEST RAID SPELL|135906|a|1800|magic|o||i
1286254|(DNT) Blessing of Kings - TEST RAID SPELL|135995|a|1800|magic|o||i
1286257|(DNT) Prayer of Spirit - TEST RAID SPELL|135946|p|3600|magic|o||i
1286298|Soul Rip|136163|t|5||o||
1286299|Soul Rip|136163|t|5||o||
1286304|Berserking|136012|p|60||o||
1286338|Howling Wind|136243|p|5||o||
1286344|Restoration|134062|p|10||o||
1286345|Speed|132870|p|10||o||
1286358|Howling Wind|136243|p|10||o||
1286462|Stealth|132320|p|-1||o||
1286580|Lots of Love|236709|p|2||o||
1286582|Emote State - Dance|133836|p|-1||o||
1286599|Greeting Bark|1033494|p|1||o||
1286699|Twilight Empowerment|136221|p|-1||o||
1286814|Hoof-Shaped Foot Pedal|1534178|p|1200||i||
1287080|Webbed!|136113|p|-1||o||
1287127|Cosmetic Lightning|136243|p|3||o||
1287151|Eating|136243|p|15||o||
1287162|Stealth|132320|p|-1||o||
1287444|Stealth|132320|p|-1||o||
1287571|Monkey Business|133980|p|15||i||
1287573|Tapped|3154546|p|-1||o||
1287664|Unstable Possession|2492256|p|-1||o||
1287672|On Break|461267|p|-1||o||
1287704|Authority|134420|p|-1||i||
1287735|Piercing Wail|136184|t|8||o||
1287747|Berserk|132117|p|60||o||
1287756|Fiery Talons|237582|t|12|magic|o||
1287768|Unholy Might|134309||600|magic|i||
1287773|Blessed Water|1385912|p|-1||o||
1287801|Preternatural Evasion|132285|p|10||o||
1287808|Blood of the Broodmother|136168|p|15||i||
1287813|Burying|133718|p|3||o||
1287840|Eye of the Beast|133441|p|20|magic|i||
1287842|Bastion of Tyranny|133442|p|15||i||
1287872|Tail Lash|4622486|t|1.5||o||
1287886|Puncture|132358|t|30||o||
1287976|Serpent Sting|132204|t|15|poison|o||
1288007|Phase Transition Primer|136243|p|60||o||
1288008|Phase Transition Primer|136243|p|60||o||
1288015|Royal Mandate|133443|p|20|magic|o||
1288016|Royal Mandate|133443|p|20|magic|o||
1288020|Royal Mandate|133443|p|20|magic|o||
1288021|Royal Mandate|133443|p|20|magic|o||
1288024|Royal Mandate|133443|p|20|magic|o||
1288387|Umbral Bulwark|135733|p|5||o||
1288388|Lunar Cascade|135753|p|12||o||
1288392|Lunar Bombardment|136096|p|3.5||o||
1288447|Debilitate|136169|p|-1||o||
1288462|Spectral Rend|136158|t|15|curse|o||
1288479|Strength of the Moon|135138|p|-1||o||
1288524|Spinning Glaive|2200994|t|15||o||
1288548|Thorns Aura|136104|p|-1||o||
1288558|Enfeeble|237564|t|10|curse|o||
1288559|Bloom|136067|t|10|poison|o||
1288560|Wither|538516|t|10|magic|o||
1288561|Faerie Fire|136033|t|15||o||
1288700|[DNT] Anim Replacement Template|136243|p|-1||o||i
1288702|[DNT] Anim Replacement Despawn -> Stand|136243|p|-1||o||i
1288849|Freezing Trap|537467|p|-1||o||
1288851|Freezing Trap|537467|p|-1||o||
1288908|Pierce Armor|132354|a|15||o||
1288961|Multi-Shot|6352451|p|4||o||
1288972|Enrage|136224|p|120||o||
1289121|Emerald Communion|4867492|p|-1||o||
1289122|Emerald Communion|4867492|t|-1||o||
1289123|Emerald Communion|4867492|p|-1||o||
1289125|Berserk|136224|p|-1||o||
1289126|Emerald Weakness|136079|a|-1||o||
1289127|Emerald Influence|136079|p|-1||o||
1289128|Barkskin|136097|p|30||o||
1289130|Hurricane|136018|t|-1||o||
1289131|Astral Weakness|136057|a|-1||o||
1289132|Astral Influence|136057|p|-1||o||
1289133|Mass Insect Swarm|136045|t|20|poison|o||
1289134|Lunar Guidance|611423|p|-1||o||
1289135|Lunar Guidance|611423|a|-1||o||
1289136|Dire Cat Form|132115|p|30||o||
1289137|Dire Bear Form|132276|p|30||o||
1289138|Savage Guidance|135879|p|-1||o||
1289139|Savage Guidance|135879|a|-1||o||
1289140|Rake|132122|t|6||o||
1289141|Rip|132152|t|21||o||
1289143|Stun|136222|p|10||o||
1289145|Empowering Roar|463283|p|-1||o||
1289238|Tiger's Fury|132242|p|10|frenzy|o||
1289249|Rooted|134187|p|-1||o||
1289250|Impaled|136168|t|60||i||
1289280|Souldrained|895888|p|-1||o||
1289375|Biting Chill|135833|a|-1||o||
1289378|Warmth|135806|t|20||o||
1289422|Explorers' League Drawing Kit|237382|t|1||i||
1289425|Interesting Landmark|237382|p|-1||o||
1289433|Shadow Vent|132291|t|-1||o||
1289434|Cause Insanity|136183|t|-1||o||
1289435|Tortured Mind|136183|t|12|curse|o||
1289447|Frost Nova|135848|t|8|magic|o||
1289448|Frostbolt Volley|135846|t|4|magic|o||
1289450|Renew|135953|a|15|magic|o||
1289452|Faerie Fire|136033|t|60|magic|o||
1289453|Shadowmeld|132320|p|-1||o||
1289531|Blooming Rot|136127|t|240|disease|o||
1289532|Blooming Rot|136127|p|240|disease|o||
1289537|Stormcrow|136076|p|-1||o||
1289546|Bear Form|132276|p|-1||o||
1289610|Roar|132121|p|30|frenzy|o||
1289654|Gift of Galloping|136103|p|1296000||i||
1289681|Bloodthrill|135271|p|5||o||
1289714|Power Sap|136121|a|60||i||
1289723|Welcoming Campfire|135805|p|60||o||
1289927|Renewing Fog|627487|a|-1||o||
1289941|Cyclonic Winds|132119|a|6||o||
1289999|RAF No AI Re-evaluate|136243|p|-1||o||
1290013|Recuperating|1408837|p|-1||o||
1290040|Enfeeble|237564|a|15||o||
1290041|Bloom|136100|p|10||o||
1290042|Revitalization|611426|p|5||o||
1290043|Crystallize|135841|a|10||o||
1290044|Crystallize|135841|a|1||o||
1290045|Crystallize Trigger|1387352|p|-1||o||
1290046|Revitalization Trigger|611426|p|-1||o||
1290052|Spore Cloud|5789326|p|-1||o||
1290054|Spore Cloud|5789326|a|-1||o||
1290060|Infected Bite|136127|t|180|disease|o||
1290120|By'zaali's Favor|237179|a|300||o||
1290186|[DNT] Can Have By'zaali's Favor|237237|a|-1||o||i
1290188|[DNT] Emote State - Dance|133836|p|-1||o||i
1290235|Illness|136182|p|-1||o||
1290240|Bleeding|136168|p|-1||i||
1290463|Powerful Slam|135860|t|2||o||
1290506|Energize|134396||3||o||
1290507|Energize|134398||3||o||
1290508|Energize|134397||3||o||
1290509|Energize|134395||3||o||
1290510|Energized|134396|p|-1||o||
1290511|Energized|134398|p|-1||o||
1290512|Energized|134397|p|-1||o||
1290513|Energized|134395|p|-1||o||
1290536|Rend|132155|t|15||o||
1290708|Stealth|132320|p|300||o||
1290732|Root Self|136235|p|4||o||p
1290800|Deft Digits|134470|p|-1||o||
1290818|Powering Up|134396||-1||o||
1290819|Powering Up|134398||-1||o||
1290822|Powering Up|134397||-1||o||
1290823|Powering Up|134395||-1||o||
1290858|Pylon Powered|1711324|p|-1||o||
1290863|First Aid|135915|a|8||i||
1290865|First Aid|135915|a|8||i||
1290867|First Aid|135915|a|8||i||
1290950|Brain Damage|136125|t|30|curse|i||
1290980|Freeze Water|612394|p|10||o||
1290983|Freeze Water|612394|t|10||o||
1291097|Damage Sigmoid|135893|p|15|magic|i||
1291101|Analyzing Weaknesses|135934|p|20||i||
1291103|Serenity|5771177|p|15|magic|i||
1291105|Stabilized|236307|p|15||i||
1291168|Blizzard|135857|t|-1||o||
1291176|Blast Wave|135903|t|2|magic|o||
1291301|Poison|5764921|a|-1||o||
1291499|Dismissal|2000855|p|1.5||o||
1291515|Germinate|348548|p|-1||o||
1291516|Spores|348548|p|-1||o||
1291545|Reanimated!|134174||4.5||o||
1291554|Blinded|348548|p|-1||o||
1291644|Unstable Mana Rift|132861|p|300||o||
1291663|Poison|136016|t|12|poison|i||
1291712|Head Smash|132111|t|2||o||
1291730|Pierce Armor|136231|t|20||o||
1291782|Skum's Bucket|1063033|p|24||i||
1291797|Embrace of the Viper|132160|p|5|magic|s||
1291806|Dream Venom|136090|t|1|poison|s||
1291816|Recently Embraced|135461|p|300||o||
1291834|Roiling Wind|136121|p|-1||o||
1291908|Gold-plated|134948|p|20||i||
1291928|Partially Digested|134174|p|-1||o||
1291932|Necrotic Poison|132105|t|15|poison|o||
1292008|Tenderized|132906|t|60||i||
1292011|Staff of Westfall|135147|p|-1||i||
1292029|Devious Strike|132090|t|5||s||
1292052|Bag of Ashen Warlock Bones|133667||60||i||
1292121|Lord of Shadowfang Keep|132518|p|-1||i||
1292139|Slimy Pinecone|656444||30||i||
1292252|Worgenbane|133439|t|4|magic|i||
1292399|Aviana's Blessing of the Feather|135992|p|60|magic|o||
1292575|Nightskulker|133364|p|-1||i||
1292598|Debt Collection|135325|p|15||i||
1292602|Anvilmar's Curse|236366|t|600|curse|o||
1292648|Pierce Heart|132155|t|2||o||
1292657|Corrosive Poison|136016|t|12|poison|i||
1292739|Hydra Strike|135846|t|5|magic|o||
1292749|Martyrdom|1360762|p|-1||i||
1292804|Memory of the Mist|135864||3||i||
1292997|Archmagister's Wisdom|135998|p|300|magic|i||
1293003|Petrolspill|134588|p|-1||i||
1293005|Puncture Armor|132109|t|30||i||
1293199|Agamaggan's Clutch|133722|p|-1||i||
1293228|Combust|135818|t|12|magic|o||
1293306|Grim Fetish|134172|t|5||i||
1293308|Grim Fetish|135975|t|5||o||
1293327|Plague Nova|136182|t|8|magic|o||
1293345|Guardian's Durability|134956|p|12|magic|i||
1293451|Tortured|135807|t|10||o||
1293483|Tough Love|135860|t|3||o||
1293515|Cleanse Heart|237414|p|60||o||
1293654|Silence|135975|t|6|magic|i||
1293673|Enraging Light|135957|p|10||s||
1293681|Farsen's Far Sight|132150|p|60||o||
1293682|Shark Attack!|294472|p|-1||o||
1293693|Haunt|236298|t|12|magic|o||
1293694|Haunt|236298|t|12|magic|o||
1293700|Painwalker Buckler|134953|p|10||i||
1293733|Scarlet Guardian|5366050|p|10|magic|s||
1293734|Recently Guarded|5366050|p|240||o||
1293736|Archmagister's Perception|135998|p|300|magic|o||
1293740|Flask of Natural Accuracy|463902|p|7200||i||
1293741|Flask of Natural Aggression|463898|p|7200||i||
1293742|Flask of Natural Precision|463900|p|7200||i||
1293743|Flask of Natural Accuracy|463901|p|7200||i||
1293790|Frostbolt|135846|t|5|magic|i||
1293801|Emanating Mist|1778226|p|-1||o||
1293803|Pyroclasm|136194|p|10|magic|o||
1293820|Toy Soldier|458241|p|20|magic|i||
1293874|Debilitate|136169||-1||o||
1293885|Pendulum of Doom|960903|p|-1||o||
1293886|Pendulum of Doom|960904|p|-1||o||
1293889|Crystallize|429385|p|10||o||
1293928|Mistrot|464162|a|60|magic|o||
1293987|Eternal Night|136223|p|-1||o||
1293991|Singularity|3610499|a|-1||o||
1294007|Well Fed|133943|p|900||i||
1294058|White Obsidian|135469|p|10||i||
1294065|Rock Sentinel|454065|a|10||i||
1294070|Wisdom of the Timbermaw|1509620|p|15||o||
1294071|Ferocity of the Barkskin|1509622|p|15||s||
1294092|Bear Form|132276|p|10||o||
1294111|Nature's Grip|136063|p|-1||o||
1294112|Entangling Roots|136100|t|10|magic|o||
1294199|Dire Bear Mastery|611424|p|30||o||
1294204|Cat Mastery|611425|p|30||o||
1294206|Tim's Test Dummy Aura|136243|p|-1||o||i
1294208|Slow Poison|136093|t|5|poison|o||
1294212|Stormcrow|136076|p|-1||o||
1294243|Deflecting|132269|p|9||i||
1294246|Rowboat|136243|p|3||o||
1294248|Rowboat|136243|p|3||o||
1294254|Ward of Zum'rah|136232|p|40||o||
1294256|Ward of Zum'rah|136157|p|20|magic|o||
1294269|Burning Blade|135814|t|10|magic|o||
1294270|Fiery Armaments|462326|p|-1||o||
1294273|Chilling Blade|135847|p|6|magic|o||
1294274|Frosted Armaments|462327|p|-1||o||
1294310|Mortal Strike|132355|t|5||o||
1294313|Terrifying Roar|132111|t|5|magic|o||
1294340|Farraki Enforcement|135860|t|1.5||o||
1294343|Farraki Enforcement|135860|t|3||o||
1294353|Freezing Trap|135852|t|6||o||
1294426|Rend|132155|t|7||i||
1294430|Rage of Sul'thraze|136145|t|15|magic|i||
1294431|Shadow Lash|136189|t|5|magic|i||
1294444|Freezing Trap|135848|p|-1||o||
1294462|Shadowmeld|132279|p|-1||o||
1294477|Static Electricity|136075|p|-1|magic|i||
1294498|Biting Chill|135849|a|-1||o||
1294510|Kingly Conviction|136038|p|-1||o||
1294537|Incinerator|135811|t|3|magic|i||
1294617|Theka's Last Breath|133570|t|10|curse|i||
1294620|Aura of Fear|136183|a|3||o||
1294626|Theka's Last Breath|135860|t|5|curse|o||
1294645|Blood Sacrifice|136169|t|6|magic|i||
1294646|The Desert Rose|134128|p|-1||i||
1294683|Lunar Suffusion|1392542|p|-1||o||
1294684|Lunar Suffusion|1392542|p|-1||o||
1294690|Umbral Suffusion|1392545|p|-1||o||
1294692|Umbral Suffusion|1392545|p|-1||o||
1294897|Striped Dawnsaber|132242|p|-1||i||
1294914|Umbral Collapse|3610499|p|-1||o||
1294915|Umbral Collapse|1394892|p|-1||o||
1294929|Umbral Collapse|136057|a|1||o||
1295039|Serpentbane|135808|t|10||i||
1295233|Heart of the Primeval|132852|p|30||i||
1295271|Everlook Delivery Bot|133861|t|20||i||
1295279|Feathered Fury|133707|p|-1||o||
1295387|Ochre Skeletal Warhorse|132264|p|-1||i||
1295579|Poison Trap|132108|t|-1||o||
1295661|Parachute-Priest Pager|133863|p|15||i||
1295678|Umber Galestrider|7813747|p|-1||i||
1295683|Swift Umber Galestrider|7754706|p|-1||i||
1295744|Rot|135914|t|7|disease|i||
1295778|Refinance|135953|a|15|magic|o||
1295780|Power Word: Deal|135940|a|12|magic|o||
1296059|Rope|1119937|a|-1||o||
1296072|Caught Sheep|1119937|a|60||o||
1296076|Caught Sheep|1119937|a|300||o||
1296140|Sheep Caught!|538563|p|-1||o||
1296202|Rat Familiar|647701|p|3600||i||
1296223|Chilled|135864|t|3||e||
1296330|Transplanar Dislocation|135747|p|13||o||
1296344|Zephras Cosmetic Vortex|136208|p|13||o||
1296534|Summon Forsaken Charger|132226|p|-1||o||
1296564|Lichbane|133439|t|6|magic|i||
1296664|Irresistible Scent|463480|t|20|magic|i||
1297068|Comprehension Failure|136071|p|8|magic|o||
1297082|Eye of Influence|134132|t|30|magic|i||
1297109|Foxtail Ward|134322|t|10||i||
1297328|Fade to Black|136223|p|3||o||
1297357|Reforged Spear|135126|p|14|magic|i||
1297448|Field Agent Beverage|132150|p|10||i||
1297449|Dizzy|136090|p|20||o||
1297517|Breath|135805|p|10||o||
1297589|Engulfing Flames|135805|a|6||o||
1297594|[DNT] Emote State - Dance|133836|p|-1||o||i
1297653|Foul Breath|132104|t|6||o||
1297705|Syndicate Uniform|133694|p|-1||i||
1297762|Propellerstorm|135355|p|15||i||
1297774|Magical Awareness|4638533|p|7200||i||
1297813|Summon Imp|236452|p|10||o||
1297958|Transform: Dock Worker w/ Bag|136243|p|-1||o||
1297994|Spirit of Wind|136121|p|-1||o||
1298231|Stoneform Shoulders|135237|p|20||i||
1298416|Frostbolt|135846|t|5|magic|i||
1298437|Ignite Weapon|135811|p|10||o||
1298450|White Kodo|132243|p|-1||i||
1298496|Black Skeletal Horse|132264|p|-1||i||
1298503|Drain Blood|1035037|t|6||o||
1298593|Delirious Whispers|136122|p|-1||o||
1298627|Reeking Miasma|132103|t|-1||o||
1298776|Craft From Bank|413587|p|-1||o||
1298841|Decaying Spirit|2027951|p|-1||o||
1298845|Decaying Spirit|4008178|p|-1||o||
1298847|Decaying Spirit|1094600|p|-1||o||
1298874|Royal Defiance|1670851|p|-1||o||
1298896|Burning|135818|p|30||o||
1299003|Energizing Winds|136147|p|-1||o||
1299005|Rustling Winds|614747|p|-1||o||
1299038|Plainsrunning|236717|p|-1||o||
1299048|Explosive Runeshard|133573|t|30||o||
1299094|BB Shot|132384|a|2.5||o||
1299095|Fair Game!|135614|p|-1||i||
1299098|Air Rifle Score|236179|p|-1||o||
1299099|Quitter|135996|p|40||o||
1299202|Test Mod Bonus Armor by Defense|136243|p|-1||o||i
1299291|Snacking on Tastyfish|133907|p|-1||o||
1299303|Stormcharged|237589|p|-1||o||
1299323|Master Angler!|132931|p|561600||o||
1299351|Water Walking|132539|p|300||i||
1299440|Demonbane|133442|t|6||i||
1299443|Ramstein's Lightning Bolts|135990|t|2|magic|i||
1299444|Electrocuted|136148|t|30|magic|o||
1299449|Find it!|134400|p|120||o||
1299739|Bloodmail|132155|t|10||s||
1299746|Deathbone Surge|133730|p|10||s||
1299796|Insight|135740|p|10||e||
1299850|Fireball|135810|t|6||i||
1299943|Blood Siphon|136168|t|8||i||
1300087|Grow|134712|p|15||o||
1300108|[DNT] Node Check|136243|p|-1||o||i
1300140|Wit's End|136170|p|15|magic|i||
1300180|Stealth|132320|p|20||i||
1300211|Bludgeon|135860|t|3||o||
1300240|Cloud of Chained Essence|136077|a|-1||o||
1300241|Essence Chained|136090|p|8|magic|o||
1300364|Guarded|133438|p|15||i||
1300424|Dark Channeling|136121|p|-1||o||
1300441|DNT Grow Pine Tree Visual|236160||30||o||i
1300493|Devilsaur Glare|133884|t|2.5||o||
1300496|Devilsaur Glare|133884|t|5||o||
1300678|Lunar Suffusion|1392542|p|5||o||
1300692|First Ward|136243|p|-1||o||
1300715|Frostbolt|135846|t|4|magic|o||
1300716|Frost Nova|135848|t|8|magic|o||
1300752|Heart of the Mountain|134084|p|20|magic|i||
1300754|Enthralled Sphere|134335|t|20|magic|i||
1300764|Skinned to the Bone|2032171|t|14400||o||
1300784|Crippling Dread|135576|t|4||o||
1300787|Rend|132155|t|7||i||
1300821|Lucent Beam|1408832|a|-1|magic|o||
1300844|Lunar Effusion|1052602|p|-1||o||
1300846|Lunar Effusion|136243|p|-1||o||
1300875|Lunar Saturation|1033477|p|-1||o||
1300890|Grace of the Seven|135931|p|-1||i||
1300952|Heal Health 1.0 Coefficient Over Time|135913|a|10||o||
1300996|Parrotmorph|5578050|t|8||o||
1301001|Arcane Fury|1041231|t|30||o||
1301016|Frost Nova|135848|t|8||o||
1301017|Arcane Idiocy|237555|t|1800|magic|o||
1301019|Shrunk|1041231|t|30||o||
1301023|Keelhauler's Curse|5559627|t|30||o||
1301124|Roar of the Crowd|1322720|p|10||s||
1301167|Transformative Cocoon|237431|p|5||i||
1301168|Transformative Cocoon|237431|p|8||i||
1301195|Everlasting Silvermoon Shimmerwine|463544|p|-1||i||
1301265|Restorative Essence|237551|t|10||o||
1301404|Lightning Cloud|136014|a|-1||o||
1301625|Flame Walker|132536|p|15|magic|i||
1301635|Anti-Magic Shield|136120|p|3||o||
1301636|Pack Kodo|132243|p|-1||i||
1301683|Harvester Override Signalcaster|132996|t|180||i||
1301818|Carrying Smoldering Incense|5931165|p|600||i||
1301833|Gather Power|136243|p|-1||o||
1301928|Flammable|135805|p|-1||o||
1302039|Curse of Tongues|136140|t|15|curse|o||
1302064|Well Fed|133943|p|900||i||
1302112|Bearing the Flame|135432|p|300||i||
1302113|Trail Snack|132307|p|0.75||i||
1302127|Charged Winds|136099|p|-1||o||
1302205|Mindtap|132489|p|10|magic|i||
1302206|Tapped Mind|134340|p|120||i||
1302264|Vigilant|134458|p|20||i||
1302285|Frog Familiar|2399247|p|3600||i||
1302301|Rebuke Elemental|136027|t|20|magic|i||
1302303|Cat Familiar|656575|p|3600||i||
1302342|Carved Mind|237527|t|30|magic|i||
1302343|Xorothian Fire|135811|t|3||i||
1302347|Channel the Flames|132863|p|-1||o||
1302356|Magnetize|135228|p|10|magic|i||
1302357|Magnetize|135228|t|8|magic|i||
1302359|Forbidden Magic|135894|t|8|magic|i||
1302362|Eidolon Ward|133447|p|30|magic|i||
1302363|Pimgib's Collar|135809|e|-1||o||
1302378|Return to Sender|133460|p|6||s||
1302379|Recently Returned|133471|p|180||o||
1302497|Corpse Explosion|136133|t|30|disease|o||
1302500|Ravage|132152|t|2||o||
1302605|Mend|133678|p|8||o||
1302661|Spectral Bear|3753812|p|-1||i||
1302707|Wild Heart|538771|p|8||s||
1302715|Rebuked|523893|t|3|magic|s||
1302717|Electrocute|237587|t|4|magic|s||
1302767|Dark Plague|136066|t|90|disease|o||
1302780|Writhing Mass|236553|p|-1||o||
1302787|Dying Throes|2141735|p|-1||o||
1302833|Mirage Mirror|458243|p|10||i||
1302834|Mirror's Mirage|458243|p|10||i||
1302838|Maggot Slime|136134|t|600|disease|o||
1302874|Mysticbloom Seed|133436|p|8||i||
1302875|Photosynthesized|134205|p|600||i||
1302937|Consuming Fel Energies|133594||10||i||
1303075|Lavender Kodo|132243|p|-1||i||
1303136|Net|132149|t|3||o||
1303140|Print Threat Per Target Periodic|134520|p|-1||o||
1303209|Plague Mind|136127|t|600|disease|o||
1303215|Caravan Kodo|132245|p|-1||i||
1303226|Frostbolt|135846|t|4|magic|o||
1303264|Unholy Frenzy|136224|a|20|magic|o||
1303286|Blind|5656675|p|-1||o||
1303308|Entangling Roots|136100|t|6|magic|o||
1303309|Venom Spit|136016|t|10|poison|o||
1303315|Ritual Circle|136121|p|-1||o||
1303350|Slow|136091|t|3|magic|o||
1303458|Reflection Field|132361|a|-1||o||
1303499|Arcane Missiles|136096|p|6||o||
1303505|Mana Leak|132841|p|-1||o||
1303598|Mass Polymorph|575586|t|8|magic|o||
1303599|Evocation|136075|p|6||o||
1303755|Toss Hearthstone|1041860|t|-1||o||
1303869|Toss Hearthstone|1041860|t|15||i||
1303979|Enrage|136224|p|600||o||
1304281|Tracking|236188|p|1||o||
1304310|Visitor|135750|p|-1||o||
1304401|Silence|135975|t|3|magic|o||
1304473|Curse of Thorns|136121|t|180|curse|o||
1304982|Allistarj's Resolve|136146|p|-1||o||
1304986|Grol's Rage|458971|p|-1||o||
1304989|Defiled Soul|136214|p|-1||o||
1304998|Sevine's Tether|136160|p|-1||o||
1305047|Recently Bandaged|133678|p|-1||o||
1305189|Soul of Stromgarde|236586|p|30|magic|o||
1305418|Deceit|132288|a|15||o||
1305422|Deceived|133564|t|5||o||
1305819|Curse of Twilight|425957|t|1800|curse|o||
1305855|Blind|132284|p|-1||o||
1306076|Grovewalker|132539|p|-1||i||
1306160|Moonweave|136096|p|-1||o||
1306224|Drowning Grasp|136141|t|12|magic|o||
1306455|Reduce Block, Dodge, and Parry Chance by 100%|136243|p|-1||o||
1306456|Reduce Block and Parry Chance by 100%|136243|p|-1||o||
1306620|Frozen|135848|t|3|magic|e||
1306632|Fallen Grove Walker|132586|p|-1||i||
1306672|Sporebloom|132611|p|-1||i||
1306691|Astraea's Promise UNUSED|2403540|p|8||o||i
1306699|Living Granite|7699050|p|-1||i||
1306749|Steadfast|134915|p|10||o||
1306762|Zephras Isle|409599|p|-1||o||
1306794|Lunar Rage|5927624|p|15||o||
1306800|Alcaz Operative|236409|p|600||i||
1306816|Bigger Rock to the Face|236304|t|20||i||
1306891|Lunar Rage|5927624|p|-1||o||
1306905|Fang of the Forlorn|135689|p|-1||i||
1306908|Froststrider|132588|p|-1||i||
1306955|Add Summons Druid of the Talon|132172|p|-1||o||
1306956|Add Summons|132276|p|-1||o||
1306957|Add Summons Sentinel|236449|p|-1||o||
1306983|Banshee Curse|136020|t|30|curse|o||
1307007|Lightning Aura|136048|p|-1||o||
1307014|Old Gloomlurker Eye|132848|p|5||i||
1307067|Bladestorm|132369|p|2||o||
1307068|Terenas' Wisdom|132768|p|3600||o||
1307072|(DNT) Wild King Intro Theater|136243|p|-1||o||i
1307132|Shadowmeld|132320|p|1||o||
1307178|Dark Channeling|136121|p|8||o||
1307199|Loop of Lingering Echoes|133381|p|-1||i||
1307334|Phantomspeaker Mask|133158|p|-1||i||
1307370|Mark of Ala'ro|611424||7200||o||
1307411|Lightheaded|132792|p|45||i||
1307426|Goaz Stone|134457||5||o||
1307519|Rootbinder's Will|132561|p|10|magic|i||
1307520|Rootbinder's Will|136100|t|10|magic|i||
1307694|[DNT] Pain|237554|p|-1||o||i
1307762|Weight of Duty|132747|p|-1||o||
1307848|Strength of the Moon|135138|a|-1||o||
1307882|Debilitate|136169||-1||o||
1308021|Nightsaber Leggings|134602|p|-1||o||
1308022|Foreststalker|132559|p|-1||i||
1308024|Dawnbloom|134123|p|-1||o||
1308027|Camping|136090|p|3600||o||
1308118|Seed of Eternity|132129|p|20|magic|i||
1308171|Blue Aura|136243|p|-1||o||
1308172|Red Aura|136243|p|-1||o||
1308174|Yellow Aura|136243|p|-1||o||
1308175|Green Aura|136243|p|-1||o||
1308177|Weakened|136221|p|300||o||
1308250|Gift of Cenarius|132129|p|300||i||
1308318|Dominate Will|136154||-1||o||
1308352|Snowrunners|132592|p|-1||i||
1308463|Split|135792|t|5||i||
1308473|Poisoned Blades|1373909|p|-1||o||
1308511|Bitter Cold|134667|p|-1||i||
1308520|Guidance of Ursoc|133760|p|-1||i||
1308527|Goaz Stone|134457||5||o||
1308531|Wisdom of Ursol|133757|p|-1||i||
1308568|Rejuvenation|136081|a|12|magic|o||
1308663|Walk on Air|132845|p|60|magic|o||
1308704|Curse of the Eye|136224|p|120|curse|o||
1308705|Curse of the Eye|136224|p|120|curse|o||
1308733|Overdrive|4548872|p|10|magic|o||
1308764|Might of Bedrock|135058|p|-1||i||
1308770|Talusguard|134584|p|-1||i||
1308817|Stillwater Striders|132569|p|-1||o||
1308843|Hexcalibur|7816780|p|10|magic|i||
1309005|Buriza-Do Spike|135845|t|5|magic|i||
1309054|Feline Blessing of the Silent Shadow|514640|p|300||o||
1309069|Rend Flesh|132152|t|12||o||
1309072|Intense Heat|135817|p|10||o||
1309170|[DNT] Can't Be Healed|132109|p|15||o||i
1309208|Cerulean Prideclaw|7749904|p|-1||i||
1309243|Legwraps of Suspended Time|134591|p|-1||o||
1309268|Black Warden Saber Mount|7967612|p|-1||i||
1309270|Brown Warden Saber Mount|7967613|p|-1||i||
1309271|Gray Warden Saber Mount|7967614|p|-1||i||
1309272|White Warden Saber Mount|7967615|p|-1||i||
1309283|!deepS|965900|p|10||i||
1309315|Poison|136016|t|10|poison|i||
1309318|Avatar of Vengeance|7816729|p|10|magic|i||
1309346|Black Devilsaur Mount|7962715|p|-1||i||
1309347|Blue Devilsaur Mount|7962716|p|-1||i||
1309348|Green Devilsaur Mount|7962717|p|-1||i||
1309349|Purple Devilsaur Mount|7962718|p|-1||i||
1309350|White Devilsaur Mount|7962719|p|-1||i||
1309369|Forsaken Weapons|135147|p|-1||i||
1309377|Black Druid Moose Mount|7949967|p|-1||i||
1309379|White Druid Moose Mount|7949968|p|-1||i||
1309380|Green Druid Moose Mount|7949969|p|-1||i||
1309381|Gray Druid Moose Mount|7949972|p|-1||i||
1309405|Veteran Adventurer's Loyal Companion|7931167|p|-1||i||
1309410|Night Watchman's Torch|135432|p|300||i||
1309551|Scalding Flamehoof|134060|p|20||i||
1309719|Axe Pin|460959|t|4||o||
1309728|Speed|132219|p|15|magic|i||
1309761|Quickening|135473|p|10||e||
1309788|Confuse Beast|1120424|t|20|magic|i||
1309823|Deafening Shriek|136122|a|4||o||
1309967|Rock to the Face|236304|t|20||i||
1310015|Krol'dok Speed|134584|p|-1||i||
1310023|Shadowmeld|132279|p|5||o||
1310077|Greater Firepower|134842|p|1800||i||
1310087|Drain Life|136169|t|5|magic|o||
1310142|Lightning Strike|135990|p|5||o||
1310167|Loose Clearcutter Blade|134427|t|18||i||
1310180|Wing Clip|132309|t|10||o||
1310189|Ground Stomp|132368|t|3||o||
1310195|Pierce Armor|136231|t|20||o||
1310243|Rend|132155|t|15||o||
1310267|Radiating Heat|135817|p|-1||o||
1310285|Curse of the Satyr|615099|t|300|curse|o||
1310353|Frostbolt|135846|t|4|magic|o||
1310354|Frost Nova|135848|t|8|magic|o||
1310365|Poison Bolt Volley|136016|t|15|poison|o||
1310377|[DNT] Greenhouse|136243|p|-1||o||i
1310429|[DNT] Greenhouse|136243|p|-1||o||i
1310438|Stun|135860|p|5||o||
1310499|Rejuvenation|136081|p|15|magic|o||
1310502|Rejuvenation|136081|p|15|magic|o||
1310505|Desaturate|136243|p|-1||o||
1310506|Activate|136243|p|-1||o||
1310507|Activate|136243|p|-1||o||
1310508|Activate|136243|p|-1||o||
1310509|Activate|136243|p|-1||o||
1310512|Conflagration|135818|t|4||o||
1310514|Howling Blast|135852|t|6|magic|o||
1310515|Demoralizing Roar|132121|t|8||o||
1310516|Lightning Strike|136243|p|3||o||
1310655|Winterspring Shroud|134776|p|600||i||
1310684|Lone Wolf|132266|p|-1||o||
1310723|Thousand Cuts|132302|p|10||o||
1310725|Spirit Bond|132121|p|-1||o||
1310831|Bestial Wrath|132127|p|18||o||
1310910|Light's Vigil|236256|t|30|magic|o||
1310927|Light's Fury|134951|p|10|magic|o||
1310993|Corrupted Healing|136129|p|30||o||
1311594|Light's Vigil|236256|t|30|magic|o||
1311599|Light's Vigil|236256|t|30|magic|o||
1311703|Echo of Command|132347|p|15||o||
1311704|Echo of Righteousness|132325|p|15||o||
1311705|Echo of Justice|135971|p|15||o||
1311895|Hyjal Speed|132501|p|-1||i||
1312052|Infernal Lasso|136091|t|6|magic|i||
1312340|Rooted|136169|p|-1||o||
1312719|Restorative Bread|134062|p|20||i||
1312869|Leech Poison|136067|t|16|poison|o||
1312934|Wake of Fire|135819|p|30||o||
1313471|Fear|136183|t|4|magic|o||
1313543|Arcane Marker|629694|a|-1||o||
1313978|Frigid Depths|135864|a|-1||o||
1314003|Arcane Marker|629694|a|-1||o||
1314017|Arcane Marker|629694|a|-1||o||
1314040|Burning Shell|514016|t|9||i||
1314065|Mount Speed|132501|p|-1||i||
1314174|[DNT] Herb Event|134183|p|3600||o||i
1314190|Cleansing|134333|p|10||i||
1314281|Flamestrike|135826|t|0.6||o||
1314412|Renewing Flame|135806|p|10||i||
1314829|Spirit of Eskhandar|134297|p|-1||o||
1314842|Blessed by the Great Cat Spirit|132142|p|300||o||
1314888|Poison Sting|132272|t|9|poison|i||
1314923|Binding|7789512|p|10||o||
1314931|Binding|7789512|p|10||o||
1314956|Beckon Ancient Spirit|454050|p|10||o||
1315056|Ancient Wisdom|135864|p|10||o||
1315080|Mount Speed|132501|p|-1||s||
1315286|Crystallize|429385|p|5||o||
1315330|Moon's Touch|136194|p|-1||o||
1315408|Blessed by the Great Windborne Cat Spirit|7749896|p|300||o||
1315448|Fixate|136243|a|60||o||
1315557|Charm|136129|t|15|magic|i||
1315767|Howler's Cry|132121|t|30|magic|i||
1315778|Mount Speed|132501|p|-1||i||
1315844|Lucky Shovelnose Snout|132184|p|15||i||
1315878|Flamebreak Talisman|134396|p|30||i||
1315971|Rune of Perfection|134418|p|-1||i||
1315972|Slammed|135860|p|3|magic|i||
1315990|Rune of Duty|134415|p|-1||i||
1316048|Transformative Cocoon|237431|p|5||i||
1316052|Raider's Seal|134421|p|-1||i||
1316054|Enriched Seal|134419|p|-1||i||
1316056|Darkspear Voodoo Seal|134419|p|-1||i||
1316058|Volunteer's Lucky Seal|134421|p|-1||i||
1316346|Sliced Ankle|1033474|t|6||i||
1316379|Cosmetic - Sleep Zzz|136090|p|-1||o||
1316382|Dust Storm|136175|t|5||o||
1316387|Muculent Rot|135914|a|1800|disease|o||
1316474|Moonfire|136096|t|12|magic|o||
1316480|Entangling Roots|136100|t|15|magic|o||
1316489|Highland Venom|135914|t|600|disease|o||
1316865|Immolate|135817|t|15|magic|i||
1316992|Penance|237545|p|2||o||
1316994|Penance|237545|p|2||o||
1317040|Angry|133732|p|10||s||
1317253|Spirit of Wind|136121|p|-1||o||
1317272|Righteous Indignation|132325|p|30|magic|o||
1317285|Arena Master|133608|p|-1||i||
1317288|Tidal Charm|135861|t|5|magic|o||
1317442|Rune of Duty|134415|p|-1||i||
1317444|Rune of Perfection|134418|p|-1||i||
1317450|Slammed|135860|t|5|magic|o||
1317472|Slammed|135860|p|3|magic|o||
1317486|Swamp Speed|135147|p|-1||i||
1317516|Rejuvenation|136081|a|18|magic|o||
1317583|Poison|136016|t|9|poison|i||
1317591|Light Lamp|134123|p|1.5||o||
1317604|Luffa|136243|p|0.1||o||
1317999|Authority|133792|p|-1||i||
1318002|Stolen Power|134891|p|-1||i||
1318003|Stolen Power|133791|p|-1||i||
1318070|Diamond Flask|132788|p|60|magic|o||
1318084|Fingerbreaker Stamp|133597|p|-1||o||
1318103|Volunteer's Lucky Seal|134421|p|-1||i||
1318110|Lydros' Inspection|7816729|p|10||o||
1318125|Darkspear Voodoo Seal|134419|p|-1||i||
1318130|Relentless Raider's Seal|134421|p|-1||i||
1318132|Enriched Seal|134419|p|-1||i||
1318151|Stealth|132320|p|-1||o||
1318163|Concussed|135860|t|6||i||
1318178|Cracked Skull|135899|t|1||i||
1318217|Portal|135748|p|-1||o||
1318318|Arena Grand Master|133598|p|-1||i||
1318327|Briarwood Reed|134413|p|-1||i||
1318477|Royal Seal of Eldre'Thalas|133443|p|-1||i||
1318478|Royal Seal of Eldre'Thalas|133443|p|-1||i||
1318480|Royal Seal of Eldre'Thalas|133443|p|-1||i||
1318807|Cloud of Chained Essence|136077|p|20||o||
1318930|Draconic Infused Emblem|133442|p|10||i||
1318944|Blackhand's Breadth|133604|t|20|magic|i||
1318987|Mod Creature Hit Chance|136243|a|-1||o||
1319114|DNT Green Glow|4622453|p|-1||o||i
1319206|Mod Creature Spell Hit Chance|136243|a|-1||o||
1319259|Crusader Strike|135924|t|30|magic|o||
1319260|Aura of Zeal|523893|p|15||o||
1319310|Well Fed|133943|p|900||i||
1319382|Waning Moon|135354|p|10||o||
1319421|Motivated|133490|a|30||i||
1319423|Krol'dok Speed|132574|p|-1||i||
1319426|Krol'dok Speed|133121|p|-1||i||
1319427|Krol'dok Speed|132717|p|-1||i||
1319446|Mod Creature Haste|461119|a|-1||o||
1319539|Tomb Weed|134219|a|60|disease|o||
1320095|Entangling Roots|136100|t|8|magic|o||
1320105|They Love Me!|135450|p|600||o||
1320107|They Love Me Not|135767|p|600||o||
1320332|Black Horn Necklace|133296|p|-1||i||
1320379|Polymorph|136071|p|50||o||
1320512|Cosmetic Lightning|136243|p|3||o||
1320579|Desert Winds|796638|t|10|magic|i||
1320580|Desert Winds|796638|t|10|magic|o||
1320658|Unleash Swarm|136243|p|10||i||
1320824|Rend|132155|t|14||i||
1320925|Ablaze|135432|t|9|magic|i||
1320965|Mend Windstone|136208|p|1||o||
1320972|Gather Data|136208|p|3||o||
1321200|Verdant Sea Turtle|8517112|p|-1||i||
1321221|Crimson Rooster|8426877|p|-1||i||
1321233|Spectral Wolf Pack|8408196|p|-1||i||
1321323|Shiny Silver Coin|237282|p|1800||i||
1321504|Shen'dorei Spirit|454050|p|20|magic|i||
1321558|Siphon the Grave|136179|p|10|magic|s||
1321586|Rotmending|237563|a|15||s||
1321861|Resting|134377|p|300||o||
1322297|(DNT) Mod Armor No Mods|134847|p|90||o||i
1322299|(DNT) Mod Resistance by Bonus Defense|134847|p|90||o||i
1322311|Recently Siphoned the Grave|136179|p|300||o||
1322587|Yay|237359|p|1200||i||
1323184|Shark Attack|6642735|p|-1||o||
1323243|Rain of Arrows|132381|a|-1||o||
1323289|Enrage|136224|p|-1||o||
1323377|Revelation|135934|p|15||o||
1323390|Tapped|3154546|p|-1||o||
1323392|Revelation|135934|p|15||o||
1323400|Revelation|135934|p|15||o||
1323410|Revelation|135934|p|15||o||
1323418|Revelation|135934|p|15||o||
1323419|Revelation|135934|p|15||o||
1323449|Spectral Wolf Pack|8408196|p|-1||o||
1323476|Spirit of the Spectral Wolf Pack|8408196|p|-1||o||
1323500|Stun|135860|p|5||o||
1323651|Moonfire|136096|t|12|magic|o||
1323656|Poisoned Shot|132273|t|60|poison|o||
1323676|Slam|132357|t|2||o||
1323802|Fear|136183|t|6|magic|o||
1323969|Gore Drinker|135727|p|8||o||
1323994|Eternal Night|136223|p|-1||o||
1324106|Summoning Disorientation|133477|a|10||o||
1324187|Polymorph|136071|p|40||o||
1324188|Polymorph|136071|p|30||o||
1324189|Polymorph|136071|p|20||o||
1324282|Mana Void|135731|t|5||o||
1324306|Arcane Jaunt|136116|t|6|magic|o||
1324308|Ogre Dominance|236695|p|30||s||
1324315|Violet Meditation|136090|p|15||s||
1324401|Counterspell - Silenced|135856|p|4||o||
1324415|Shackle Undead|136091|p|30|magic|o||
1324420|Shackle Undead|136091|p|40|magic|o||
1324422|Shackle Undead|136091|p|50|magic|o||
1324427|Silence|136164|p|5|magic|o||
1324448|Fear|136183|p|10|magic|o||
1324451|Fear|136183|p|15|magic|o||
1324453|Fear|136183|p|20|magic|o||
1324459|Death Coil|136145|p|3|magic|o||
1324462|Banish|136135|p|20|magic|o||
1324463|Banish|136135|p|30|magic|o||
1324468|Subjugate Demon|136154|p|300|magic|o||
1324473|Bane of Havoc|460695|p|300|magic|o||
1324474|Kidney Shot|132298|p||magic|o||
1324475|Kidney Shot|132298|p|1||o||
1324477|Blind|136175|p|10|magic|o||
1324481|Gouge|132155|p|4||o||
1324482|Sap|132310|p|25||o||
1324483|Sap|132310|p|35||o||
1324484|Sap|132310|p|45||o||
1324485|Silenced - Kick|132310|p|2||o||
1324487|Bash|132114|p|2||o||
1324488|Bash|132114|p|3||o||
1324490|Bash|132114|p|4||o||
1324494|Intimidation|132111|p|3||o||
1324499|Scatter Shot|132153|p|4||o||
1324500|Freezing Trap|135834|p|10||o||
1324501|Freezing Trap|135834|p|15||o||
1324502|Freezing Trap|135834|p|20||o||
1324506|Scare Beast|132118|p|10||o||
1324507|Scare Beast|132118|p|15||o||
1324510|Scare Beast|132118|p|20||o||
1324511|Improved Concussive Shot|135860|p|3||o||
1324513|Hammer of Justice|135963|p|3||o||
1324515|Hammer of Justice|135963|p|4||o||
1324516|Hammer of Justice|135963|p|5||o||
1324517|Hammer of Justice|135963|p|6||o||
1324538|Repentance|135942|p|6||o||
1324542|Tranquility|136107|p|30||o||
1324543|Turn Undead|135983|p|10||o||
1324545|Turn Undead|135983|p|15||o||
1324546|Turn Undead|135983|p|20||o||
1324551|Silenced|132357|p|3||o||
1324556|Concussion Blow|132325|p|5||o||
1324558|Disarm|132343|p|10||o||
1324618|Terrifying Roar|132111|t|5||o||
1324683|Defias Juggernaut|132109|p|20||s||
1325147|Adventurer's Tent|4624631|p|900||o||
1325508|Perfected Form|135280|p|20||o||
1325509|Improving Form|135280|p|-1||i||
1325556|Fungal Bloom|136243|p|-1||o||
1325571|Disease Cloud|136006|p|-1||o||
1325739|Cooldown Reduction|136243|p|1||o||
1325755|Banished|236693|p|86400||o||
1325762|Being Watched|136215|p|120||o||
1325764|Dismissal|237508|p|1.5||o||
1325799|L70 ETC Lightning Cloud|136243|p|10||o||
1325800|L70 ETC Earthquake|136025|p|8||o||
1325801|L70 ETC Rain of Fire|136243|p|10||o||
1325828|Tim's Test Stealth|136243|p|-1||o||i
1325968|Bloodlust|136012|t|30||o||
1325971|Samuro Spawn|136243|p|3||o||
1326053|Frost Blast|135989|t|9|magic|o||
1326054|Frost Blast|135989|t|9|magic|o||
1326055|Frost Blast|135989|t|9|magic|o||
1326056|Blackthorne's Ward|1769069|p|-1|magic|i||
1326064|Vigilant|135432|p|-1||o||
1326083|Missile Barrage|236221|p|15|magic|o||
1326114|Sleep|136090|t|20|magic|o||
1326146|Pool of Fire|135826|a|-1||o||
1326175|Stealth|132320|p|-1||o||
1326203|Untrackable|136243|p|-1||o||
1326475|Flash Bundle|133581|p|8||i||
1326548|Chains of Hogger|132507|t|20||o||
1327064|Hunger...|135983|p|-1||o||
1327082|You're Infected!|136206|t|5|disease|o||
1327241|Void Bolt|136163|t|10||o||
1327245|Warstomp|132368|t|4|magic|o||
1327341|Dreamfall|1033487|a|-1||o||
1327369|Fixate|841379|a|-1||o||
1327506|Arcane Bolt|236205|a|20||o||
1327657|Frost Breath|135848|t|3||o||
1327713|Terrifying Roar|132111|t|8||o||
1327726|Rushing Charge|132368|p|8||o||
1327736|Elixir of Endless Intellect|135754|p|3600||i||
1327737|Elixir of Endless Power|236310|p|3600||i||
1327738|Elixir of Endless Healing|136041|p|3600||i||
1327751|Elixir of Endless Rapidity|132306|p|3600||i||
1327753|Elixir of Endless Opportunity|132212|p|3600||i||
1327754|Scroll of Endless Fortitude|136112|p|3600||i||
1327836|Denial of the Call|8408196|p|-1||o||
1327926|Ultra Hogger|134163|p|-1||o||
1327961|Giga Hogger|134163|p|-1||o||
1327963|Cosmic Hogger|134163|p|-1||o||
1327978|Frenzy|136146|p|10||o||
1327987|Manastorm|135857|t|-1||o||
1327989|Chill|135852|t|4|magic|o||
1327990|Chill|135833|p|-1||o||
1328019|Mortal Strike|132355|t|15||o||
1328022|Ding!|136224|p|45||o||
1328028|Charge|132337|t|2||o||
1328032|Elixir of Endless Mana|237551|p|3600||i||
1328040|Hurricane|136018|t|-1||o||
1328069|Summon Infernal|135860|t|4||o||
1328118|Elixir of Endless Growth|134721|p|600||i||
1328119|Scroll of Endless Speed|132219|p|30||i||
1328127|Elixir of Endless Experience|134803|p|3600||i||
1328198|Echo of Light|135917|p|15||o||
1328206|Echo of Wisdom|135960|p|15||o||
1328372|Turn Evil|135983|t|20||o||
1328373|Turn Evil|135983|t|15||o||
1328374|Turn Evil|135983|t|10||o||
1328375|Violet Flames|236296|p|-1||o||
1328676|[DNT] Hunter Pet Scaling (Old Testing Backup)|132252|p|-1||o||i
1328749|Emerald Stasis|132119||-1||o||
1328846|Boiling Water|576310|a|-1||o||
1328891|Enrage|136224|p|-1||o||
1328904|Enrage|136224|p|-1||o||
1328911|Enrage|136224|p|-1||o||
1328913|Enrage|136224|p|-1||o||
1329552|Counterspell - Silenced|135856|t|2|magic|o||
1329553|Counterspell - Silenced|135856|p|2||o||
]==],
items=[==[
id|name|level|spell|category|cooldown|icon|type|flags
117|Tough Jerky|1|433|11||133972|c|
118|Minor Healing Potion|1|439|4|120|134829|c|
159|Refreshing Spring Water|1|430|59|1|132794|c|
414|Dalaran Sharp|5|434|11||133995|c|
422|Dwarven Mild|15|435|11||133949|c|
724|Goretusk Liver Pie|5|1248384|||133952|c|
733|Westfall Stew|5|1248687|||133748|c|
744|Thunderbrew's Boot Flask|1|12257||300|132788|t|
761|Deprecated Elwynn Trout|1|433|11||133888|c|i
787|Slitherskin Mackerel|1|1249503|||133910|c|
835|Large Rope Net|2|8312|24|60|134325|c|
858|Lesser Healing Potion|3|440|4|120|134830|c|
929|Healing Potion|12|441|4|120|134831|c|
941|Deprecated Speedstone|35|47|||135229|t|i
954|Scroll of Strength|10|8118|||134938|c|
955|Scroll of Intellect|5|8096|||134937|c|
961|Healing Herb|1|433|11||134181|c|
1017|Seasoned Wolf Kabob|15|1248387|||133972|c|
1072|Full Moonshine|1|438|4|120|132798|c|
1082|Redridge Goulash|5|1248383|||133748|c|
1113|Conjured Bread|5|434|11||133951|c|
1114|Conjured Rye|15|435|11||133968|c|
1119|Bottled Spirits|1|435|11||132793|c|
1127|Flash Bundle|1|1326475|24|120|133581|c|
1165|Test Food|1|7291|11||133943|c|i
1176|Smelling Salts|1|2006|||133588|c|
1177|Oil of Olaf|1|673|2593|3|134743|c|
1178|Explosive Rocket|1|1940|24|60|132383|c|
1179|Ice Cold Milk|5|431|59|1|132815|c|
1180|Scroll of Stamina|5|8099|||134943|c|
1181|Scroll of Spirit|1|8112|||134937|c|
1184|Deprecated Scarlet Badge|1|547|12|60|133281|t|i
1186|Deprecated Gnoll Taskmaster Whip|35|682|||134325|t|i
1187|Spiked Collar|27|8176|||133075|c|
1191|Bag of Marbles|1|5917|24|60|133581|c|
1205|Melon Juice|15|432|59|1|132796|c|
1251|Linen Bandage|1|746|150||133685|c|
1258|Bind On Use Test Item|35|133|24|30|135279|t|i
1262|Keg of Thunderbrew|1|5257|59|1|132621|c|
1267|Deprecated Cask of Merlot|1|431|4||134514|c|i
1268|Deprecated Bottle of Moonshine|1|432|4||134754|c|i
1321|Deprecated Broiled Sunfish|1|434|11||133888|c|i
1322|Fishliver Oil|1|7396|1153|120|134743|c|
1326|Sauteed Sunfish|1|434|11||133888|c|
1350|Deprecated Hex Doll|1|805|22|30|134231|t|i
1399|Magic Candle|1|133|24|60|133751|c|
1400|Swiftfeather Token|2|65|28|300|134414|c|
1401|Green Tea Leaf|4|833|4|30|134190|c|
1402|Brimstone|2|143|24|60|135230|c|
1403|Deprecated Capstone|35|834|28|30|134414|t|i
1434|Glowing Wax Stick|1|13424|24|60|133752|c|
1444|Deprecated Inferno Stone|35|707|||135231|t|i
1450|Potion of Fervor|15|806|4|120|134720|c|
1472|Deprecated Polished Lakestone Charm|35|835|29|30|134431|t|i
1477|Scroll of Agility II|25|8116|||134938|c|
1478|Scroll of Protection II|15|8094|||134943|c|
1487|Conjured Pumpernickel|25|1127|11||133950|c|
1544|Deprecated Candle of Black Smoke|1|1184|||133750|t|i
1612|Deprecated Skullsplitter Idol|28|706||120|134232|c|i
1622|Deprecated Foreman's Whip|37|955|||134412|t|i
1645|Moonberry Juice|35|1135|59|1|132789|c|
1700|Deprecated Blood Totem|33|365|||134415|c|i
1703|Crystal Basilisk Spine|25|1138|1153|120|133720|c|
1704|Deprecated Cold Basilisk Eye|29|1139|29|30|133884|c|i
1707|Stormwind Brie|25|1127|11||133994|c|
1708|Sweet Nectar|25|1133|59|1|132799|c|
1710|Greater Healing Potion|21|2024|4|120|134832|c|
1711|Scroll of Stamina II|20|8100|||134943|c|
1712|Scroll of Spirit II|15|8113|||134937|c|
1851|Cleansing Water|1|1152|28|300|134754|c|
1854|Deprecated Brooch of the Night Watch|1|1139|||133282|t|i
1912|Deprecated Reed Pipe|35|1459|||134374|t|i
1914|Deprecated Miniature Silver Hammer|35|403|||133038|t|i
1970|Restoring Balm|1|8070|1153|120|134712|c|
1995|Deprecated Cat's Paw|24|370|29|20|134296|c|i
2012|Deprecated Phylactery of Rot|35|689|24|30|133436|t|i
2070|Darnassian Bleu|1|433|11||133948|c|
2071|Deprecated Mountain Spring Water|1|430|59||132794|c|i
2091|Magic Dust|10|1090|24|60|133849|c|
2136|Conjured Purified Water|15|432|59|1|132816|c|
2287|Haunch of Meat|5|434|11||133974|c|
2288|Conjured Fresh Water|5|431|59|1|132794|c|
2289|Scroll of Strength II|25|8119|||134938|c|
2290|Scroll of Intellect II|20|8097|||134937|c|
2304|Light Armor Kit|1|2831|||133611|c|
2313|Medium Armor Kit|5|2832|||133609|c|
2454|Elixir of Minor Strength|1|2367|2593|3|134836|c|
2455|Minor Mana Potion|5|437|4|120|134850|c|
2456|Minor Rejuvenation Potion|5|2370|4|120|134713|c|
2457|Elixir of Minor Agility|2|2374|2593|3|134871|c|
2458|Elixir of Minor Fortitude|2|2378|2593|3|134822|c|
2459|Swiftness Potion|5|2379|4|120|134875|c|
2461|Deprecated Elemental Resistance Potion|10|2381|79|3|134754|c|i
2462|Deprecated Potion of Lesser Invulnerability (Fix)|1|440|4|120|134712|c|i
2478|Deprecated Replenishing Font|35|437|||134712|t|i
2581|Heavy Linen Bandage|1|1159|150||133688|c|
2593|Flask of Stormwind Tawny|1|11008|||134743|c|
2594|Flagon of Dwarven Honeymead|1|11009|||132792|c|
2595|Jug of Badlands Bourbon|1|11009|||132621|c|
2596|Skin of Dwarven Stout|1|11008|||132816|c|
2633|Jungle Remedy|22|3592|4|120|134743|c|
2679|Charred Wolf Meat|1|433|||133974|c|
2680|Spiced Wolf Meat|1|1248378|||134021|c|
2681|Roasted Boar Meat|1|1248380|||133974|c|
2682|Cooked Crab Claw|1|1248379|||133708|c|
2683|Crab Cake|5|1248383|||133950|c|
2684|Coyote Steak|5|1248382|11||134021|c|
2685|Succulent Pork Ribs|15|1248389|||133972|c|
2686|Thunder Ale|1|11007|||132800|c|
2687|Dry Pork Ribs|5|1248384|||134004|c|
2723|Bottle of Dalaran Noir|1|11007|||132797|c|
2803|Deprecated Static Charm|35|905|28|60|133435|t|i
2820|Nifty Stopwatch|1|14530|44|10|134376|t|
2826|Deprecated Medal of Fortitude|1|554|||133282|t|i
2862|Rough Sharpening Stone|1|2828|||135248|c|
2863|Coarse Sharpening Stone|5|2829|||135249|c|
2871|Heavy Sharpening Stone|15|2830|||135250|c|
2888|Beer Basted Boar Ribs|1|1248380|||134004|c|
2892|Deadly Poison|30|2823|||132290|c|
2893|Deadly Poison II|38|2824|||132290|c|
2894|Rhapsody Malt|1|11007|||132800|c|
2948|Deprecated Talisman of Cleansing|1|1152|||133439|t|i
3012|Scroll of Agility|10|8115|||134938|c|
3013|Scroll of Protection|1|8091|||134943|c|
3015|Deprecated Chatter's Rock|35|109|||135242|t|i
3087|Mug of Shimmer Stout|1|29236|4|120|132792|c|
3220|Blood Sausage|5|1248384|||134005|c|
3239|Rough Weightstone|1|3112|||135255|c|
3240|Coarse Weightstone|5|3113|||135256|c|
3241|Heavy Weightstone|15|3114|||135257|c|
3382|Minor Troll's Blood Elixir|1|3219|2593|3|134858|c|
3383|Elixir of Wisdom|10|3166|2593|3|134717|c|
3384|Minor Magic Resistance Potion|12|2380|4|120|134719|c|
3385|Lesser Mana Potion|14|438|4|120|134851|c|
3386|Potion of Poison Cleansing|14|26677|79|3|134743|c|
3387|Limited Invulnerability Potion|45|3169|4|120|134842|c|
3388|Lesser Troll's Blood Elixir|15|3222|2593|3|134859|c|
3389|Elixir of Lesser Defense|16|3220|2593|3|134844|c|
3390|Elixir of Lesser Agility|18|3160|2593|3|134872|c|
3391|Elixir of Ogre Strength|20|3164|2593|3|134837|c|
3434|Slumber Sand|1|700|24|60|133849|c|
3438|Ankh of Resurrection|1|2006|||133439|c|
3441|Deprecated Crippling Agent|1|89|||134799|c|i
3448|Senggin Root|1|2639|11||134187|c|
3507|Deprecated Test Fishliver Oil|6|65|||134720|c|i
3530|Wool Bandage|1|3267|150||133684|c|
3531|Heavy Wool Bandage|1|3268|150||133687|c|
3662|Crocolisk Steak|5|1248382|||134003|c|
3663|Murloc Fin Soup|1|1248377|||133748|c|
3664|Crocolisk Gumbo|15|1248387|11||133748|c|
3665|Curiously Tasty Omelet|15|1248386|||132835|c|
3666|Gooey Spider Cake|15|1248386|||133952|c|
3703|Southshore Stout|1|11008|||132795|c|
3726|Big Bear Steak|5|1248384|||134003|c|
3727|Hot Lion Chops|15|1248387|||133974|c|
3728|Tasty Lion Steak|25|1248391|||133970|c|
3729|Soothing Turtle Bisque|15|1248386|||133748|c|
3768|Deprecated Anti-magic Potion|18|708|4|120|134720|c|i
3770|Mutton Chop|15|435|11||133970|c|
3771|Wild Hog Shank|25|1127|11||133969|c|
3772|Conjured Spring Water|25|1133|59|1|132797|c|
3773|Deprecated Murkwood Sap|35|1135|59||132794|c|i
3775|Crippling Poison|20|3408|||132274|c|
3776|Crippling Poison II|50|11202|||132274|c|
3823|Lesser Invisibility Potion|23|3680|4|120|134798|c|
3824|Shadow Oil|24|3594||1|134803|c|
3825|Elixir of Lesser Fortitude|25|3593|2593|3|134823|c|
3826|Troll's Blood Elixir|26|3223|2593|3|134860|c|
3827|Mana Potion|22|2023|4|120|134852|c|
3828|Draught of Detect Lesser Invisibility|29|6512|2593|3|134712|c|
3829|Frost Oil|30|3595||1|134800|c|
3927|Fine Aged Cheddar|35|1129|11||133945|c|
3928|Superior Healing Potion|35|4042|4|120|134833|c|
4130|Smotts' Compass|1|1317740|||134377|t|
4265|Heavy Armor Kit|20|2833|||133610|c|
4358|Rough Dynamite|1|4054|24|60|133714|c|
4360|Rough Copper Bomb|1|4064|24|60|133717|c|
4365|Coarse Dynamite|1|4061|24|60|133714|c|
4366|Target Dummy|1|4071|1153|120|132766|c|
4367|Small Seaforium Charge|1|4056|||134514|c|
4370|Large Copper Bomb|1|4065|24|60|133709|c|
4374|Small Bronze Bomb|1|4066|24|60|133717|c|
4376|Flame Deflector|15|4057||900|132995|c|
4378|Heavy Dynamite|1|4062|24|60|133714|c|
4380|Big Bronze Bomb|1|4067|24|60|133713|c|
4381|Minor Recombobulator|1|18805|1153|120|133001|t|
4384|Explosive Sheep|1|4074|24|60|136071|c|
4386|Ice Deflector|21|4077||900|132995|c|
4388|Discombobulator Ray|1|4060|24|60|134441|c|
4390|Iron Grenade|1|4068|24|60|133716|c|
4391|Compact Harvest Reaper Kit|30|4078|24|60|133076|c|
4392|Advanced Target Dummy|1|4072|1153|120|132765|c|
4394|Big Iron Bomb|1|4069|24|60|133709|c|
4395|Goblin Land Mine|1|4100|24|60|134954|c|
4396|Mechanical Dragonling|30|4073|94|60|134153|t|
4397|Gnomish Cloaking Device|1|4079|2465|3600|132995|t|
4398|Large Seaforium Charge|1|4075|||134514|c|
4403|Portable Bronze Mortar|1|4067|24|60|134535|c|
4405|Crude Scope|5|3974|||134441|c|
4406|Standard Scope|10|3975|||134441|c|
4407|Accurate Scope|20|3976|||134441|c|
4418|Deprecated Creeper Cakes|35|1129|11||133952|c|i
4419|Scroll of Intellect III|35|8098|||134937|c|
4421|Scroll of Protection III|30|8095|||134943|c|
4422|Scroll of Stamina III|35|8101|||134943|c|
4424|Scroll of Spirit III|30|8114|133|1|134937|c|
4425|Scroll of Agility III|40|8117|||134938|c|
4426|Scroll of Strength III|40|8120|||134938|c|
4427|Deprecated Scroll of Spirit Armor V|29|2864|||134941|c|i
4457|Barbecued Buzzard Wing|25|1248392|||133974|c|
4479|Burning Charm|25|4132|||133434|c|
4480|Thundering Charm|25|4131|||133435|c|
4481|Cresting Charm|25|4130|||133438|c|
4536|Shiny Red Apple|1|433|11||133975|c|
4537|Tel'Abim Banana|5|434|11||133980|c|
4538|Snapvine Watermelon|15|435|11||133978|c|
4539|Goldenbark Apple|25|1127|11||133976|c|
4540|Tough Hunk of Bread|1|433|11||133964|c|
4541|Freshly Baked Bread|5|434|11||133968|c|
4542|Moist Cornbread|15|435|11||133950|c|
4544|Mulgore Spice Bread|25|1127|11||133964|c|
4546|Call of the Raptor|1|4318||1|134229|c|
4592|Longjaw Mud Snapper|5|1249506|||133918|c|
4593|Bristle Whisker Catfish|15|1249508|||133916|c|
4594|Rockscale Cod|25|1249511|||133890|c|
4595|Junglevine Wine|1|11009|||132796|c|
4596|Minor Discolored Healing Potion|5|1244863|4|120|134815|c|
4598|Goblin Fishing Pole|1|4062|24|60|133711|c|
4599|Cured Ham Steak|35|1129|11||133970|c|
4600|Cherry Grog|25|11009|59|1|132790|c|
4601|Soft Banana Bread|35|1129|11||133951|c|
4602|Moon Harvest Pumpkin|35|1129|11||133981|c|
4604|Forest Mushroom Cap|1|433|11||134534|c|
4605|Red-speckled Mushroom|5|434|11||134532|c|
4606|Spongy Morel|15|435|11||134529|c|
4607|Delicious Cave Mold|25|1127|11||134186|c|
4608|Raw Black Truffle|35|1129|11||134524|c|
4623|Lesser Stoneshield Potion|33|4941|4|120|134847|c|
4656|Small Pumpkin|1|433|11||133981|c|
4791|Enchanted Water|25|1133|59|1|134797|c|
4852|Flash Bomb|27|5134|24|60|133581|c|
4941|Really Sticky Glue|1|8312|24|60|134712|c|
4945|Faintly Glowing Skull|1|16375|||133728|c|
4952|Stormstout|1|5020|59|1|132791|c|
4953|Trogg Brew|1|5021|59|1|132800|c|
5013|Fertile Bulb|5|5100|24|60|134188|c|
5057|Ripe Watermelon|1|433|11||133978|c|
5066|Fissure Plant|5|434|11||134184|c|
5079|Cold Basilisk Eye|35|1139||420|133884|t|
5095|Rainbow Fin Albacore|5|1249501|||133913|c|
5205|Sprouted Frond|5|2052|1153|120|134184|c|
5206|Bogling Root|1|5665|||134187|c|
5232|Minor Soulstone|1|20707|831|1800|134336|c|
5237|Mind-numbing Poison|24|5761|||136066|c|
5265|Watered-down Beer|1|5909|59|1|132800|c|
5342|Raptor Punch|1|6114|59|1|132791|c|
5349|Conjured Muffin|1|433|11||133952|c|
5350|Conjured Water|1|430|59|1|132793|c|
5421|Fiery Blaze Enchantment|1|6296|||133434|c|
5457|Severed Voodoo Claw|1|8277|24|60|134296|c|
5472|Kaldorei Spider Kabob|1|1248377|||134024|c|
5473|Scorpid Surprise|1|6410|||133952|c|
5474|Roasted Kodo Meat|1|1248377|11||134016|c|
5476|Fillet of Frenzy|5|1249505|||133891|c|
5477|Strider Stew|1|1248379|||133748|c|
5478|Dig Rat Stew|15|435|||133748|c|
5479|Crispy Lizard Tail|5|1248381|11||133973|c|
5480|Lean Venison|15|1248389|||134028|c|
5507|Ornate Spyglass|1|12883|||134440|c|
5509|Healthstone|24|5720|1153|120|135230|c|
5510|Greater Healthstone|36|5723|1153|120|135230|c|
5511|Lesser Healthstone|12|6263|1153|120|135230|c|
5512|Minor Healthstone|1|6262|1153|120|135230|c|
5513|Mana Jade|38|10052|1153|120|134105|c|
5525|Boiled Clams|1|433|||134432|c|
5526|Clam Chowder|5|434|||134712|c|
5527|Goblin Deviled Clams|15|5006|||134431|c|
5631|Rage Potion|4|6612|4|120|134804|c|
5633|Great Rage Potion|25|6613|4|120|134801|c|
5634|Free Action Potion|20|6615|4|120|134715|c|
5740|Red Fireworks Rocket|1|6668|||135808|c|
5816|Light of Elune|1|6724|4|120|134754|c|
5823|Poisonous Mushroom|5|6727|11||134527|c|
5845|Flank of Meat|15|435|11||133970|c|
5859|Party Grenade|1|6758|||132385|c|
5878|Super Snuff|1|6902|||133849|c|
5880|Crate With Holes|1|6918|||132765|c|
5951|Moist Towelette|1|7108|||133677|c|
5996|Draught of Water Breathing|8|7178|2593|3|134797|c|
5997|Elixir of Minor Defense|1|673|2593|3|134843|c|
6038|Giant Clam Scorcho|25|1248390|||132386|c|
6041|Steel Weapon Chain|1|7220|||135834|c|
6042|Iron Shield Spike|1|7216|||133596|c|
6043|Iron Counterweight|1|7218|||134333|c|
6048|Shadow Protection Potion|17|7242|4|120|134824|c|
6049|Fire Protection Potion|23|7233|4|120|134787|c|
6050|Frost Protection Potion|28|7239|4|120|134754|c|
6051|Holy Protection Potion|10|7245|4|120|134720|c|
6052|Nature Protection Potion|28|7254|4|120|134717|c|
6074|War Horn Mouthpiece|1|7285|||134374|c|
6149|Greater Mana Potion|31|11903|4|120|134853|c|
6183|Unlit Poor Torch|1|7364|||135434|c|
6290|Brilliant Smallfish|1|1249500|||133893|c|
6299|Sickly Looking Fish|1|7737|11||133914|c|
6316|Loch Frenzy Delight|5|1249502|||134712|c|
6372|Swim Speed Potion|10|7840|4|120|134754|c|
6373|Elixir of Fire Power|18|7844|2593|3|134835|c|
6450|Silk Bandage|1|7926|150||133671|c|
6451|Heavy Silk Bandage|1|7927|150||133672|c|
6452|Anti-Venom|1|7932|150|60|134437|c|
6453|Strong Anti-Venom|1|7933|150|60|134437|c|
6458|Oil Covered Fish|5|433|11||134300|c|
6522|Deviate Fish|1|8063|11||134299|c|
6529|Shiny Bauble|1|8087|||134335|c|
6530|Nightcrawlers|1|8088|||134324|c|
6532|Bright Baubles|1|8090|||134139|c|
6533|Aquadynamic Fish Attractor|1|8089|||133982|c|
6635|Earth Sapta|1|8202|||134743|c|
6636|Fire Sapta|1|8898|||134732|c|
6637|Water Sapta|1|8899|||134754|c|
6638|Air Sapta|1|8900|||134754|c|
6657|Savory Deviate Delight|1|8213|11||134302|c|
6662|Elixir of Giant Growth|8|8212|2593|3|134721|c|
6714|Ez-Thro Dynamite|10|8331|24|60|133714|c|
6807|Frog Leg Stew|1|1127|11||133748|c|
6811|Aquadynamic Fish Lens|1|8532|||134440|c|
6887|Spotted Yellowtail|35|1249513|||133887|c|
6888|Herb Baked Egg|1|1248377|11||132834|c|
6890|Smoked Bear Meat|1|1248380|||133969|c|
6947|Instant Poison|20|8679|||132273|c|
6949|Instant Poison II|28|8686|||132273|c|
6950|Instant Poison III|36|8688|||132273|c|
6951|Mind-numbing Poison II|38|8693|||136066|c|
7097|Leg Meat|1|433|11||133974|c|
7148|Goblin Jumper Cables|1|8342|1051|1800|133868|t|
7228|Tigule's Strawberry Ice Cream|15|435|11||133987|c|
7307|Flesh Eating Worm|1|9092|||134324|c|
7388|Skull Key|1|9172|||133719|c|
7506|Gnomish Universal Remote|1|8344||180|134376|t|
7676|Thistle Tea|5|9512|1153|120|132819|c|
7806|Lollipop|1|5004|11||133982|c|
7807|Candy Bar|1|5004|11||133983|c|
7808|Chocolate Square|1|5004|11||133985|c|
7964|Solid Sharpening Stone|25|9900|||135251|c|
7965|Solid Weightstone|25|9903|||135258|c|
7967|Mithril Shield Spike|1|9781|||133597|c|
7969|Mithril Spurs|1|9783|||132307|c|
7970|E.C.A.C.|1|9976|||134059|c|
8007|Mana Citrine|48|10057|1153|120|134116|c|
8008|Mana Ruby|58|10058|1153|120|134128|c|
8075|Conjured Sourdough|35|1129|11||133964|c|
8076|Conjured Sweet Roll|45|1131|11||133989|c|
8077|Conjured Mineral Water|35|1135|59|1|132796|c|
8078|Conjured Sparkling Water|45|1137|59|1|132798|c|
8079|Conjured Crystal Water|55|22734|59|1|132805|c|
8095|Hinott's Oil|1|10723|||134807|c|
8173|Thick Armor Kit|30|10344|||133602|c|
8243|Scooby Snack|1|10369|||133983|c|
8364|Mithril Head Trout|25|1249509|||133888|c|
8410|R.O.I.D.S.|1|10667|103|3600|135241|c|
8411|Lung Juice Cocktail|1|10668|103|3600|132799|c|
8412|Ground Scorpok Assay|1|10669|103|3600|133849|c|
8423|Cerebral Cortex Compound|1|10692|103|3600|134812|c|
8424|Gizzard Gum|1|10693|103|3600|133986|c|
8432|Eau de Mixilpixil|1|10723|||134807|c|
8444|Executioner's Key|1|10738|||134236|c|
8493|Weegli's Barrel|1|10772|||132620|c|
8529|Noggenfogger Elixir|35|16589||3|134863|c|
8543|Underwater Mushroom Cap|25|1127|11||134533|c|
8544|Mageweave Bandage|1|10838|150||133689|c|
8545|Heavy Mageweave Bandage|1|10839|150||133690|c|
8546|Powerful Smelling Salts|1|10850|||133588|c|
8688|Bind On Acquire Test Item|35|133|24|30|135279|t|i
8703|Signet of Expertise|1|11209|||133603|t|
8766|Morning Glory Dew|45|1137|59|1|134712|c|
8827|Draught of Water Walking|24|11319|2593|3|134776|c|
8926|Instant Poison IV|44|11338|||132273|c|
8927|Instant Poison V|52|11339|||132273|c|
8928|Instant Poison VI|60|11340|||132273|c|
8932|Alterac Swiss|45|1131|11||133993|c|
8948|Dried King Bolete|45|1131|11||134526|c|
8949|Elixir of Agility|27|11328|2593|3|134873|c|
8950|Homemade Cherry Pie|45|1131|11||133952|c|
8951|Elixir of Defense|29|11349|2593|3|134845|c|
8952|Roasted Quail|45|1131|11||133971|c|
8953|Deep Fried Plantains|45|1131|11||133979|c|
8956|Oil of Immolation|31|11350|79|3|134732|c|
8957|Spinefin Halibut|45|1249514|||133908|c|
8984|Deadly Poison III|46|11355|||132290|c|
8985|Deadly Poison IV|54|11356|||132290|c|
9030|Restorative Potion|32|11359|4|120|134712|c|
9036|Magic Resistance Potion|32|11364|4|120|134744|c|
9088|Gift of Arthas|38|11371|79|3|134808|c|
9144|Wildvine Potion|35|11387|4|120|134814|c|
9154|Draught of Detect Undead|36|11389|2593|3|134833|c|
9155|Arcane Elixir|37|11390|2593|3|134810|c|
9172|Invisibility Potion|37|11392|4|120|134805|c|
9179|Elixir of Greater Intellect|37|11396|2593|3|134721|c|
9186|Mind-numbing Poison III|52|11399|||136066|c|
9187|Elixir of Greater Agility|38|11334|2593|3|134874|c|
9197|Draught of Dream Vision|38|11403|2593|3|134765|c|
9206|Elixir of Greater Strength|48|11405|2593|3|134839|c|
9224|Potion of Demon Slaying|40|11406|||134807|c|
9233|Draught of Detect Demon|40|11407|2593|3|134833|c|
9260|Volatile Rum|1|11009|||132788|c|
9264|Elixir of Shadow Power|40|11474|2593|3|134828|c|
9312|Blue Firework|1|11540|||135989|c|
9313|Green Firework|1|11541|||136006|c|
9314|Red Streaks Firework|1|11542|||135815|c|
9315|Yellow Rose Firework|1|11544|||135920|c|
9317|Red, White and Blue Firework|1|11543|||135934|c|
9318|Red Firework|1|6668|||135808|c|
9319|Nimboya's Laden Pike|1|11547|||135125|c|
9360|Cuergo's Gold|1|11009|||132788|c|
9361|Cuergo's Gold with Worm|1|11629|||132788|c|
9421|Major Healthstone|48|11732|1153|120|135230|c|
9451|Bubbling Water|15|432|59|1|134712|c|
9681|Grilled King Crawler Legs|35|1129|11||132274|c|
10305|Scroll of Protection IV|45|12175|||134943|c|
10306|Scroll of Spirit IV|45|12177|||134937|c|
10307|Scroll of Stamina IV|50|12178|||134943|c|
10308|Scroll of Intellect IV|50|12176|||134937|c|
10309|Scroll of Agility IV|55|12174|||134938|c|
10310|Scroll of Strength IV|55|12179|||134938|c|
10418|Glimmering Mithril Insignia|1|12733||600|133435|t|
10507|Solid Dynamite|1|12419|24|60|133714|c|
10514|Mithril Frag Bomb|1|12421|24|60|133710|c|
10546|Deadly Scope|30|12459|||134441|c|
10548|Sniper Scope|40|12460|||134441|c|
10562|Hi-Explosive Bomb|1|12543|24|60|133715|c|
10576|Mithril Mechanical Dragonling|40|23075|94|60|134153|t|
10577|Goblin Mortar|1|13237|1141|10|134535|t|
10586|The Big One|1|12562|24|60|133712|c|
10587|Goblin Bomb Dispenser|1|23134||600|133000|t|
10592|Catseye Draught|30|12608|2593|3|134816|c|
10645|Gnomish Death Ray|1|13278|1141|10|133002|t|
10646|Goblin Sapper Charge|1|13241|24|60|135826|c|
10663|Essence of Hakkar|1|12735|||136148|c|
10684|Colossal Parachute|1|12438|||132369|c|
10687|Empty Vial Labeled #1|1|12802|||132793|c|
10688|Empty Vial Labeled #2|1|12805|||132793|c|
10689|Empty Vial Labeled #3|1|12806|||132793|c|
10690|Empty Vial Labeled #4|1|12808|||132793|c|
10716|Gnomish Shrink Ray|1|13006||300|133003|t|
10719|Mobile Alarm|1|4074|24|60|132761|c|
10720|Gnomish Net-o-Matic Projector|1|13120||600|134325|t|
10725|Gnomish Battle Chicken|1|23133|2267|1800|135996|t|
10727|Goblin Dragon Gun|1|13183|1141|10|135812|t|
10830|M73 Frag Grenade|1|13808|24|60|133716|c|
10841|Goldthorn Tea|25|1249906|||132802|c|
10918|Wound Poison|32|13219|||134197|c|
10920|Wound Poison II|40|13225|||134197|c|
10921|Wound Poison III|48|13226|||134197|c|
10922|Wound Poison IV|56|13227|||134197|c|
11109|Special Chicken Feed|1|7737|11||134058|c|
11148|Samophlange Manual Page|1|14199|||134332|c|
11325|Dark Iron Ale Mug|1|14814|||132791|c|
11415|Mixed Berries|45|1131|11||133996|c|
11444|Grim Guzzler Boar|45|1131|11||133969|c|
11584|Cactus Apple Surprise|1|5004|11||133975|c|
11590|Mechanical Repair Kit|1|15057||120|132997|c|
11825|Pet Bombling|1|55884|||133712|c|
11826|Lil' Smoky|1|55884|||2915723|c|
11846|Wizbang's Special Brew|1|11008|||132801|c|
11905|Linken's Boomerang|1|15712|1141|10|135646|t|
11914|Empty Cursed Ooze Jar|1|15698|||134864|c|
11948|Empty Tainted Ooze Jar|1|15699|||134864|c|
11950|Windblossom Berries|45|26030|11||134014|c|
11951|Whipper Root Tuber|45|15700|1153|120|134011|c|
11952|Night Dragon's Breath|45|15701|1153|120|134001|c|
11953|Empty Pure Sample Jar|1|15702|||134864|c|
12003|Dark Dwarven Lager|1|11629|||132792|c|
12190|Dreamless Sleep Potion|35|15822|4|120|134863|c|
12209|Lean Wolf Steak|15|1248387|||134003|c|
12210|Roast Raptor|15|1248388|||134006|c|
12212|Jungle Stew|35|1248395|||132804|c|
12213|Carrion Surprise|5|1248381|11||134005|c|
12214|Mystery Stew|15|1248386|||132806|c|
12215|Heavy Kodo Stew|25|1248390|||132806|c|
12216|Spiced Chili Crab|25|1248392|||134004|c|
12217|Dragonbreath Chili|25|15852|||132804|c|
12218|Monster Omelet|35|1248394|||133948|c|
12224|Crispy Bat Wing|1|1248379|||134002|c|
12238|Darkshore Grouper|5|434||1|133912|c|
12404|Dense Sharpening Stone|35|16138|||135252|c|
12440|Magic Knucklebone (DND)|1|16195|||133723|c|i
12526|TEST Challenge to Urok|1|16447|||134151|c|i
12586|Immature Venom Sac|1|16537|||134339|c|
12643|Dense Weightstone|35|16622|||135259|c|
12645|Thorium Shield Spike|1|16623|||133614|c|
12650|Attuned Dampener|1|16629|||134961|c|
12763|Un'Goro Etherfruit|45|1131|11||133998|c|
12820|Winterfall Firewater|45|17038||60|134872|c|
12886|Pamela's Doll's Head|1|17133|||134164|c|
12922|Empty Canteen|1|17161|||132788|c|
13156|Mystic Crystal|1|17271|||134095|c|
13164|Heart of the Scale|56|17275||1800|134084|t|
13442|Mighty Rage Potion|46|17528|4|120|134821|c|
13443|Superior Mana Potion|41|17530|4|120|134854|c|
13444|Major Mana Potion|49|17531|4|120|134856|c|
13445|Elixir of Greater Defense|43|11348|2593|3|134846|c|
13446|Major Healing Potion|45|17534|4|120|134834|c|
13447|Elixir of the Sages|38|17535|2593|3|134809|c|
13452|Elixir of the Mongoose|46|17538|2593|3|134812|c|
13453|Elixir of Brute Force|45|17537|2593|3|134820|c|
13454|Greater Arcane Elixir|47|17539|2593|3|134731|c|
13455|Greater Stoneshield Potion|46|17540|4|120|134849|c|
13456|Greater Frost Protection Potion|48|17544|4|120|134800|c|
13457|Greater Fire Protection Potion|48|17543|4|120|134804|c|
13458|Greater Nature Protection Potion|48|17546|4|120|134802|c|
13459|Greater Shadow Protection Potion|48|17548|4|120|134803|c|
13460|Greater Holy Protection Potion|48|17545|4|120|134720|c|
13461|Greater Arcane Protection Potion|48|17549|4|120|134863|c|
13462|Purification Potion|47|17550|4|120|134811|c|
13506|Flask of Petrification|50|17624|2593|3|134806|c|
13509|Clutch of Foresight|55|29443|24|60|134416|c|
13510|Flask of the Titans|50|17626|2593|3|134842|c|
13511|Flask of Distilled Wisdom|50|17627|2593|3|134877|c|
13512|Flask of Supreme Power|50|17628|2593|3|134821|c|
13513|Flask of Chromatic Resistance|50|17629|2593|3|134828|c|
13546|Bloodbelly Fish|25|1129|11||133892|c|
13724|Enriched Manna Biscuit|45|1226814|11||133989|c|
13755|Raw Winter Squid|35|1127|11||133899|c|
13810|Blessed Sunfruit|45|18124|11||133997|c|
13813|Blessed Sunfruit Juice|45|18140|59|1|132803|c|
13851|Hot Wolf Ribs|25|1248391|||134004|c|
13893|Large Raw Mightfish|45|1129|11||134300|c|
13927|Cooked Glossy Mightfish|35|1249512|||134301|c|
13928|Grilled Squid|35|1249522|||133899|c|
13929|Hot Smoked Bass|35|1249522|||133889|c|
13930|Filet of Redgill|35|1249514|||133892|c|
13931|Nightfin Soup|35|1249513|||132804|c|
13932|Poached Sunscale Salmon|35|1249515|||133905|c|
13933|Lobster Stew|45|1249516|||132804|c|
13934|Mightfish Steak|45|1249515|||134003|c|
13935|Baked Salmon|45|1249516|||133906|c|
14529|Runecloth Bandage|1|18608|150||133681|c|
14530|Heavy Runecloth Bandage|1|18610|150||133682|c|
14894|Lily Root|1|18832|4|120|134182|c|
15564|Rugged Armor Kit|40|19057|||133604|c|
15723|Tea with Sugar|50|19199|1153|120|132802|c|
15778|Mechanical Yeti|1|19363|24|60|132189|c|
15846|Salt Shaker|1|19566|791|255600|132836|c|
15869|Silver Skeleton Key|1|19646|||134237|c|
15870|Golden Skeleton Key|1|19649|||134247|c|
15871|Truesilver Skeleton Key|1|19651|||134245|c|
15872|Arcanite Skeleton Key|1|20709|||134242|c|
15993|Thorium Grenade|1|19769|24|60|133716|c|
16005|Dark Iron Bomb|1|19784|24|60|133713|c|
16022|Arcanite Dragonling|50|19804|94|60|134153|t|
16023|Masterwork Target Dummy|1|19805|1153|120|132762|c|
16040|Arcane Bomb|1|19821|24|60|136173|c|
16086|Test Enchant Chest Health|1|19929|||133434|c|i
16102|Test Enchant Chest Mana|1|19930|||133434|c|i
16103|Test Enchant Boots Stamina|1|19931|||133434|c|i
16105|Test Enchant Bracer Greater Stamina|1|19933|||133434|c|i
16106|Test Enchant Weapon Greater Striking|1|19934|||133434|c|i
16107|Test Enchant Bracer Greater Spirit|1|19935|||133434|c|i
16108|Test Enchant 2H Weapon Greater Impact|1|19936|||133434|c|i
16166|Bean Soup|1|433|11||132804|c|
16167|Versicolor Treat|5|434|11||133984|c|
16168|Heaven Peach|35|1129|11||133998|c|
16169|Wild Ricecake|25|1127|11||133991|c|
16170|Steamed Mandu|15|435|11||134007|c|
16171|Shinsollo|45|1131|11||134019|c|
16766|Undermine Clam Chowder|35|1129|||132804|c|
16892|Lesser Soulstone|1|20762|831|1800|134336|c|
16893|Soulstone|1|20763|831|1800|134336|c|
16895|Greater Soulstone|1|20764|831|1800|134336|c|
16896|Major Soulstone|1|20765|831|1800|134336|c|
16971|Clamlette Surprise|40|10256|11||134433|c|
17048|Rumsey Rum|1|20875|||132790|c|
17119|Deeprun Rat Kabob|5|434|11||134024|c|
17162|Eric Test Item A|1|23853|||132381|c|i
17196|Holiday Spirits|1|11007|||132797|c|
17197|Gingerbread Cookie|1|5004|11||134018|c|
17198|Egg Nog|1|21149|11||132791|c|
17222|Spider Sausage|35|1248394|||134022|c|
17344|Candy Cane|1|433|11||134017|c|
17348|Major Healing Draught|45|21393|4|300|134818|c|
17349|Superior Healing Draught|35|21394|4|300|134819|c|
17351|Major Mana Draught|45|21395|4|300|134860|c|
17352|Superior Mana Draught|35|21396|4|300|134861|c|
17402|Greatfather's Winter Ale|1|11009|||132800|c|
17403|Steamwheedle Fizzy Spirits|1|11008|||132798|c|
17404|Blended Bean Brew|5|431|59|1|132802|c|
17406|Holiday Cheesewheel|5|434|11||133945|c|
17407|Graccu's Homemade Meat Pie|25|1127|11||133952|c|
17408|Spicy Beefstick|35|1129|11||134005|c|
17690|Frostwolf Insignia Rank 1|1|22563|1091|120|133283|t|
17691|Stormpike Insignia Rank 1|1|22564|1091|120|133429|t|
17708|Elixir of Frost Power|28|21920|2593|3|134856|c|
17716|Snowmaster 9000|1|21935|991|82800|135863|c|
17747|Razorlash Root|40|21955|1153|120|134187|c|
17759|Mark of Resolution|1|21956|2554|10|133440|t|
17900|Stormpike Insignia Rank 2|1|22564|1091|120|133429|t|
17901|Stormpike Insignia Rank 3|1|22564|1091|120|133430|t|
17902|Stormpike Insignia Rank 4|1|22564|1091|120|133431|t|
17903|Stormpike Insignia Rank 5|1|22564|1091|120|133432|t|
17904|Stormpike Insignia Rank 6|1|22564|1091|1|133433|t|
17905|Frostwolf Insignia Rank 2|1|22563|1091|120|133283|t|
17906|Frostwolf Insignia Rank 3|1|22563|1091|120|133284|t|
17907|Frostwolf Insignia Rank 4|1|22563|1091|120|133285|t|
17908|Frostwolf Insignia Rank 5|1|22563|1091|120|133286|t|
17909|Frostwolf Insignia Rank 6|1|22563|1091|1|133287|t|
18045|Tender Wolf Steak|35|1248395|||134003|c|
18209|Energized Sparkplug|1|5917|24|180|133001|c|
18232|Field Repair Bot 74A|1|22700|||132836|c|
18251|Core Armor Kit|50|22725|||133600|c|
18253|Major Rejuvenation Potion|50|22729|4|120|134827|c|
18254|Runn Tum Tuber Surprise|35|1248396|||134019|c|
18255|Runn Tum Tuber|45|1129|11||134011|c|
18262|Elemental Sharpening Stone|50|22756|||135228|c|
18269|Gordok Green Grog|1|22789|||132790|c|
18283|Biznicks 247x128 Accurascope|50|22779|||134441|c|
18284|Kreeg's Stout Beatdown|1|22790|||132792|c|
18287|Evermurky|1|11008|||132798|c|
18288|Molasses Firewater|1|11009|||132621|c|
18294|Draught of Greater Water Breathing|35|22807|2593|3|134716|c|
18297|Thornling Seed|55|22792|||132877|c|
18300|Hyjal Nectar|55|22734|59|1|132801|c|
18406|Onyxia Blood Talisman|1|1287808|2554|15|136168|t|
18587|Goblin Jumper Cables XL|1|22999|1051|1800|133869|t|
18588|Ez-Thro Dynamite II|30|23000|24|60|133711|c|
18594|Powerful Seaforium Charge|1|23008|||136152|c|
18606|Alliance Battle Standard|1|23034|1153|120|132486|c|
18607|Horde Battle Standard|1|23035|1153|120|132485|c|
18632|Moonbrook Riot Taffy|25|1127|11||133986|c|
18633|Styleen's Sour Suckerpop|5|434|11||133982|c|
18634|Gyrofreeze Ice Reflector|47|23131||300|133860|t|
18635|Bellara's Nutterbar|35|1129|11||133983|c|
18637|Major Recombobulator|1|23064|1153|120|133867|t|
18638|Hyper-Radiant Flame Reflector|53|23097||300|133862|t|
18639|Ultra-Flash Shadow Reflector|55|23132||300|133874|t|
18640|Happy Fun Rock|1|23065|||132384|c|
18641|Dense Dynamite|1|23063|24|60|133714|c|
18645|Gnomish Alarm-O-Bot|1|23004|1153|120|133871|c|
18660|World Enlarger|1|23126||3600|133866|c|
18662|Heavy Leather Ball|1|23135|||134480|c|
18820|Talisman of Ephemeral Power|60|23271|1141|15|134465|t|
18834|Insignia of the Horde|1|5579|||133453|t|
18839|Combat Healing Potion|35|4042|4|120|134819|c|
18841|Combat Mana Potion|41|17530|4|120|134861|c|
18845|Insignia of the Horde|1|5579|||133453|t|
18846|Insignia of the Horde|1|5579|||133453|t|
18849|Insignia of the Horde|1|23273|||133453|t|
18850|Insignia of the Horde|1|23274|||133453|t|
18851|Insignia of the Horde|1|23276|||133453|t|
18852|Insignia of the Horde|1|23273|||133453|t|
18853|Insignia of the Horde|1|23277|||133453|t|
18854|Insignia of the Alliance|1|5579|||133452|t|
18856|Insignia of the Alliance|1|5579|||133452|t|
18857|Insignia of the Alliance|1|23273|||133452|t|
18858|Insignia of the Alliance|1|23273|||133452|t|
18859|Insignia of the Alliance|1|23274|||133452|t|
18862|Insignia of the Alliance|1|23276|||133452|t|
18863|Insignia of the Alliance|1|23277|||133452|t|
18864|Insignia of the Alliance|1|23276|||133452|t|
19004|Minor Healthstone|1|23468|1153|120|135230|c|
19005|Minor Healthstone|1|23469|1153|120|135230|c|
19006|Lesser Healthstone|12|23470|1153|120|135230|c|
19007|Lesser Healthstone|12|23471|1153|120|135230|c|
19008|Healthstone|24|23472|1153|120|135230|c|
19009|Healthstone|24|23473|1153|120|135230|c|
19010|Greater Healthstone|36|23474|1153|120|135230|c|
19011|Greater Healthstone|36|23475|1153|120|135230|c|
19012|Major Healthstone|48|23476|1153|120|135230|c|
19013|Major Healthstone|48|23477|1153|120|135230|c|
19024|Arena Grand Master|50|23506|2554|20|133599|t|
19026|Snake Burst Firework|1|11544|||135920|c|
19045|Stormpike Battle Standard|1|23539|1153|120|132486|c|
19046|Frostwolf Battle Standard|1|23538|1153|120|132485|c|
19060|Warsong Gulch Enriched Ration|45|23540|11||133989|c|
19061|Warsong Gulch Iron Ration|35|23541|11||133950|c|
19062|Warsong Gulch Field Ration|25|23542|11||133951|c|
19066|Warsong Gulch Runecloth Bandage|45|23567|150||133682|c|
19067|Warsong Gulch Mageweave Bandage|35|23568|150||133690|c|
19068|Warsong Gulch Silk Bandage|25|23569|150||133672|c|
19141|Luffa|1|23595|||132911|t|
19183|Hourglass Sand|1|23645|||133849|c|
19221|Darkmoon Special Reserve|1|11629|||132790|c|
19222|Cheap Beer|1|11007|||132795|c|
19223|Darkmoon Dog|1|433|11||134022|c|
19224|Red Hot Wings|25|1127|11||134002|c|
19225|Deep Fried Candybar|45|1131|11||133983|c|
19299|Fizzy Faire Drink|15|432|59|1|132792|c|
19300|Bottled Winterspring Water|35|1135|59|1|132805|c|
19301|Alterac Manna Biscuit|51|23692|11||133989|c|
19304|Spiced Beef Jerky|5|434|11||134256|c|
19305|Pickled Kodo Foot|15|435|11||134061|c|
19306|Crunchy Frog|35|1129|11||133919|c|
19307|Alterac Heavy Runecloth Bandage|1|23696|150||133682|c|
19318|Bottled Alterac Spring Water|55|23698|59|1|132798|c|
19336|Arcane Infused Gem|60|23721|1141|10|136116|t|
19337|The Black Book|60|23720|1141|30|133738|t|
19339|Mind Quickening Gem|60|23723|1141|20|136115|t|
19340|Rune of Metamorphosis|60|23724|||134419|t|
19341|Lifegiving Gem|60|23725|||134124|t|
19342|Venomous Totem|60|23726|1141|20|134232|t|
19343|Scrolls of Blinding Light|60|23733|1141|20|134944|t|
19344|Natural Alignment Crystal|60|23734|1141|20|134073|t|
19345|Aegis of Preservation|60|23780|||135880|t|
19440|Powerful Anti-Venom|1|23786|150|60|132801|c|
19696|Harvest Bread|1|24005|11||133989|c|
19948|Zandalarian Hero Badge|1|24574||120|133300|t|
19949|Zandalarian Hero Medallion|1|24661|1141|20|133300|t|
19950|Zandalarian Hero Charm|1|24658|1141|20|133300|t|
19951|Gri'lek's Charm of Might|60|24571|1141|10|133306|t|
19952|Gri'lek's Charm of Valor|60|24498|1141|20|133306|t|
19953|Renataki's Charm of Beasts|60|24531|1141|10|133306|t|
19954|Renataki's Charm of Trickery|60|24532|1141|10|133306|t|
19955|Wushoolay's Charm of Nature|60|24542||180|133306|t|
19956|Wushoolay's Charm of Spirits|60|24499|1141|20|133306|t|
19957|Hazza'rah's Charm of Destruction|60|24543|1141|20|133306|t|
19958|Hazza'rah's Charm of Healing|60|24546||180|133306|t|
19959|Hazza'rah's Charm of Magic|60|24544|1141|20|133306|t|
19971|High Test Eternium Fishing Line|1|24302|||132893|c|
19979|Hook of the Master Angler|1|24347|||136245|t|
19994|Harvest Fruit|1|24005|11||133997|c|
19995|Harvest Boar|1|24005|11||134016|c|
19996|Harvest Fish|1|24005|11||133905|c|
19997|Harvest Nectar|1|24355|59|1|132791|c|
20002|Greater Dreamless Sleep Potion|55|24360|4|120|134863|c|
20004|Major Troll's Blood Elixir|53|24361|2593|3|134862|c|
20007|Mageblood Elixir|40|24363|2593|3|134762|c|
20008|Living Action Potion|47|24364|4|120|134718|c|
20031|Essence Mango|55|24384|11||133998|c|
20062|Arathi Basin Enriched Ration|45|24411|11||133989|c|
20063|Arathi Basin Field Ration|25|24409|11||133951|c|
20064|Arathi Basin Iron Ration|35|24410|11||133950|c|
20065|Arathi Basin Mageweave Bandage|35|24413|150||133690|c|
20066|Arathi Basin Runecloth Bandage|45|24414|150||133682|c|
20067|Arathi Basin Silk Bandage|25|24412|150||133672|c|
20071|Talisman of Arathor|58|23991|1155|180|133438|t|
20072|Defiler's Talisman|58|23991|1155|180|133438|t|
20074|Heavy Crocolisk Stew|25|1248391|||134020|c|
20079|Spirit of Zanza|55|24382|79|3|134810|c|
20080|Sheen of Zanza|55|24417|79|120|134809|c|
20081|Swiftness of Zanza|55|24383|79|3|134811|c|
20084|Hunting Net|1|8312||180|134325|t|
20222|Defiler's Enriched Ration|45|24411|11||133989|c|
20223|Defiler's Field Ration|25|24409|11||133951|c|
20224|Defiler's Iron Ration|35|24410|11||133950|c|
20225|Highlander's Enriched Ration|45|24411|11||133989|c|
20226|Highlander's Field Ration|25|24409|11||133951|c|
20227|Highlander's Iron Ration|35|24410|11||133950|c|
20232|Defiler's Mageweave Bandage|35|24413|150||133690|c|
20234|Defiler's Runecloth Bandage|45|24414|150||133682|c|
20235|Defiler's Silk Bandage|25|24412|150||133672|c|
20237|Highlander's Mageweave Bandage|35|24413|150||133690|c|
20243|Highlander's Runecloth Bandage|45|24414|150||133682|c|
20244|Highlander's Silk Bandage|25|24412|150||133672|c|
20388|Lollipop|1|24707|11||133982|c|
20389|Candy Corn|1|24707|11||133986|c|
20390|Candy Bar|1|24707|11||133983|c|
20397|Hallowed Wand - Pirate|1|24717|||135474|c|
20398|Hallowed Wand - Ninja|1|24718|||135474|c|
20399|Hallowed Wand - Leper Gnome|1|24719|||135474|c|
20409|Hallowed Wand - Ghost|1|24737|||135474|c|
20410|Hallowed Wand - Bat|1|24733|||135474|c|
20411|Hallowed Wand - Skeleton|1|24724|||135474|c|
20413|Hallowed Wand - Random|1|24720|||135474|c|
20414|Hallowed Wand - Wisp|1|24741|||135474|c|
20452|Smoked Desert Dumplings|45|1248401|||134020|c|
20475|Soul Gem|1|24828|||134074|c|
20516|Bobbing Apple|1|24869|11||133975|c|
20525|Earthen Sigil|1|24884|||136069|t|
20557|Hallow's End Pumpkin Treat|1|24930|79||134015|c|
20636|Hibernation Crystal|60|24998|||134134|t|
20709|Rumsey Rum Light|1|25037|||132795|c|
20744|Minor Wizard Oil|5|25117|||134711|c|
20745|Minor Mana Oil|20|25118|||134878|c|
20748|Brilliant Mana Oil|45|25123|||134722|c|
20749|Brilliant Wizard Oil|45|25122|||134727|c|
20750|Wizard Oil|40|25121|||134726|c|
20844|Deadly Poison V|60|25351|||132290|c|
21023|Dirge's Kickin' Chimaerok Chops|45|25660|||134021|c|
21030|Darnassus Kimchi Pie|35|1129|11||133952|c|
21031|Cabbage Kimchi|45|1131|11||134019|c|
21033|Radish Kimchi|45|1131|11||134020|c|
21038|Hardpacked Snowball|1|25677|||132387|c|
21072|Smoked Sagefish|10|1249504|||133906|c|
21114|Rumsey Rum Dark|1|25722|||132791|c|
21115|Defiler's Talisman|48|25746|1155|180|133438|t|
21116|Defiler's Talisman|38|25747|1155|180|133438|t|
21117|Talisman of Arathor|48|25746|1155|180|133438|t|
21118|Talisman of Arathor|38|25747|1155|180|133438|t|
21119|Talisman of Arathor|28|25750|1155|180|133438|t|
21120|Defiler's Talisman|28|25750|1155|180|133438|t|
21151|Rumsey Rum Black Label|1|25804|||132791|c|
21180|Earthstrike|1|25891|1141|20|136006|t|
21181|Grace of Earth|1|25892||300|134182|t|
21212|Fresh Holly|40|25860|||133749|c|
21215|Graccu's Mince Meat Fruitcake|40|25990|11||132934|c|
21217|Sagefish Delight|30|1249507|||133907|c|
21235|Winter Veil Roast|1|24005|11||134006|c|
21236|UNUSED ITEM|1|24005|11||133968|c|i
21238|UNUSED ITEM|1|24005|11||134018|c|i
21240|UNUSED ITEM|1|24005|11||134017|c|i
21241|Winter Veil Eggnog|1|24355|59|1|132803|c|
21254|Winter Veil Cookie|1|24869|11||134018|c|
21325|Mechanical Greench|1|26067|24|60|132189|c|
21326|Defender of the Timbermaw|1|26066|94|20|134227|t|
21473|Eye of Moam|60|26166|1141|30|133884|t|
21488|Fetish of Chitinous Spikes|60|26168|||133571|t|
21537|Festival Dumplings|1|26263|11||134056|c|
21546|Elixir of Holy Power|40|1310077|2593|3|134842|c|
21552|Striped Yellowtail|35|1129|11||133887|c|
21579|Vanquished Tentacle of C'Thun|60|26391|||133574|t|
21625|Scarab Brooch|60|26467|||133575|t|
21647|Fetish of the Sand Reaver|60|26400|||133572|t|
21670|Badge of the Swarmguard|60|26480|||133573|t|
21685|Petrified Scarab|60|26463|||133570|t|
21711|Lunar Festival Invitation|1|26373|||134941|c|
21713|Elune's Candle|1|26374|||134536|c|
21721|Moonglow|1|26389|||134800|c|
21744|Lucky Rocket Cluster|1|26521|1136|2|134280|c|
21745|Elder's Moonstone|1|25823|||134123|c|
21891|Shard of the Fallen Star|60|26789|||133573|t|
22192|Bloodkelp Elixir of Dodging|1|27653|2593|3|134832|c|
22193|Bloodkelp Elixir of Resistance|1|27652|2593|3|134801|c|
22236|Buttermilk Delight|1|27720|||135457|c|
22237|Dark Desire|1|27723|||135460|c|
22238|Very Berry Cream|1|27721|||135458|c|
22239|Sweet Surprise|1|27722|||135459|c|
22259|Unbestowed Friendship Bracelet|1|26899|||133345|c|
22324|Winter Kimchi|45|1131|11||134019|c|
22678|Talisman of Ascendance|1|28200|1141|20|134123|t|
22895|Conjured Cinnamon Roll|55|29073|11||134029|c|
22954|Kiss of the Spider|60|28866|1141|15|135442|t|
23001|Eye of Diminution|60|28862|||135440|t|
23027|Warmth of Forgiveness|60|28760|||135439|t|
23040|Glyph of Deflection|60|28773|||135443|t|
23041|Slayer's Crest|60|28777|1141|20|135441|t|
23042|Loatheb's Reflection|60|28778|||135443|t|
23046|The Restrained Essence of Sapphiron|60|28779|1141|20|135444|t|
23047|Eye of the Dead|60|28780|||135439|t|
23122|Consecrated Sharpening Stone|50|28891|||135249|c|
23123|Blessed Wizard Oil|50|28898|||134806|c|
23160|Friendship Bread|45|29008|11||133991|c|
23161|Freshly-Squeezed Lemonade|45|29007|59|1|132801|c|
23163|Performer's Wand|1|29004|||135468|c|
23164|Bubbly Beverage|1|29006|||132799|c|
23172|Refreshing Red Apple|1|29055|11||133975|c|
23175|Tasty Summer Treat|1|29041|11||133984|c|
23176|Fizzy Energy Drink|1|29029|||132489|c|
23194|Lesser Mark of the Dawn|1|30088|||134499|c|
23195|Mark of the Dawn|1|30089|||134500|c|
23196|Greater Mark of the Dawn|1|30090|||134501|c|
23211|Toasted Smorc|1|29334|11||135267|c|
23215|Bag of Smorc Ingredients|1|29116|||133642|c|
23246|Fiery Festival Brew|1|29388|||135262|c|
23326|Midsummer Sausage|1|29333|||134009|c|
23327|Fire-toasted Bun|1|29332|||133964|c|
23379|Cinder Bracers|1|29305|24|60|132608|c|
23435|Elderberry Pie|1|29335|||133952|c|
23558|The Burrower's Shell|60|29506||120|134969|t|
23570|Jom Gabbar|60|29602|1141|20|133877|t|
23578|Diet McWeaksauce|49|17531|4|120|134856|c|
23579|The McWeaksauce Classic|45|17534|4|120|134834|c|
23684|Crystal Infused Bandage|1|30020|150||133686|c|
23696|[PH] Potion of Heightened Senses [DEP]|1|30297|79||134813|c|
23714|Perpetual Purple Firework|1|30161||600|134284|t|
23715|Permanent Lung Juice Cocktail|1|30164|103||132799|c|
23716|Carved Ogre Idol|1|30167||3600|134230|t|
23718|Permanent Ground Scorpok Assay|1|30173|103||133849|c|
23719|Permanent Cerebral Cortex Compound|1|30175|103||134812|c|
23721|Permanent Gizzard Gum|1|30177|103||133986|c|
23722|Permanent R.O.I.D.S.|1|30178|103||135241|c|
23794|Permanent Sheen of Zanza|55|30331|79||134809|c|
23795|Permanent Spirit of Zanza|55|30336|79||134810|c|
23796|Permanent Swiftness of Zanza|55|30338|79||134811|c|
184937|Chronoboon Displacer|1|349858|1928|3600|133879|c|
184938|Supercharged Chronoboon Displacer|1|349863|||133881|c|
191204|Lesser Deathstone|1|370289|1951|0.5|132871|c|
191267|Rune of Teleportation: Antechamber|1|370301|79|1|134421|c|
191268|Orb of Corruption|1|370303|79|1|134120|c|
191272|Rod of Necromancy|1|370308|79|1|135474|c|
191280|Fungal Spore Cluster|1|370336|79|1|134530|c|
191288|Rune of Teleportation: Frostwyrm's Lair|1|370343|79|1|134422|c|
191292|Ritual Dagger|1|370347|79|1|135341|c|
191313|Mask of Death|1|370423|79|1|136147|c|
191414|Skeletal Artifact|1|370531|79|1|136083|c|
191459|Rune of Fortune|1|370630|79|1|134418|c|
191660|Thaddius' Lightning Bolts|1|370831|79|1|134068|c|
191661|Monstrous Spider Fang|1|370832|79|1|135367|c|
202251|Bag of Pet Treats|1|398117|24|60|132165|c|
202316|Runecarving Test - Crippling Poison|20|398608|||132274|c|i
203726|Cutty's Rune|1|401489|||134419|c|
203750|Elwynn Treasure Map|1|401617|||134269|c|
203784|Top-Right Map Piece|1|401847|||134327|c|
203785|Top-Left Map Piece|1|401847|||134327|c|
203786|Bottom-Right Map Piece|1|401847|||134327|c|
203787|Bottom-Left Map Piece|1|401847|||134327|c|
203990|Rune of Mutilation|1|402265|||134419|c|
203991|Rune of Quick Draw|1|402265|||134419|c|
203992|Rune of Trickery|1|402756|||134419|c|
203993|Rune of Slaughter|1|402265|||134419|c|
203994|Rune of Deadly Brew|1|402265|||134419|c|
204174|Rune of Precision|1|402265|||134419|c|
204441|Rune of Blood Frenzy|1|402265|||134419|c|
204688|Monster Hunter's First Rune Fragment|1|406651|||134455|c|
204689|Monster Hunter's Second Rune Fragment|1|406651|||134455|c|
204690|Monster Hunter's Third Rune Fragment|1|406651|||134455|c|
204703|Rune of Devastate|1|402265|||134419|c|
204716|Rune of Frenzied Assault|1|402265|||134419|c|
204795|Rune of Shadowstrike|1|402265|||134419|c|
204806|Rune of Victory Rush|1|402265|||134419|c|
204809|Rune of Furious Thunder|1|402265|||134419|c|
204912|Rune of Grace|1|402265|||134419|c|
205022|Rune of Soul Siphon|1|402265|||134419|c|
205215|Rune of Tactics|1|402265|||134419|c|
205228|Rune of Chaos Bolt|1|402265|||134419|c|
205230|Rune of Haunting|1|402265|||134419|c|
205683|Rune of Rebuke|1|402265|||134419|c|
205685|Rune of Aegis|1|402265|||134419|c|
205897|Rune of Divine Light|1|402265|||134419|c|
205905|Memory of a Devout Champion|1|410958|||136222|c|
205932|Prophecy of a King's Demise|1|410971|||135975|c|
205940|Memory of a Dark Purpose|1|410958|||136222|c|
205942|Chimaeric Epiphany|1|402265|||135791|c|
205943|Prophecy of a Desecrated Citadel|1|410971|||135975|c|
205944|Reciprocal Epiphany|1|402265|||135791|c|
205945|Memory of an Imprisoned Savior|1|410958|||136222|c|
205946|Memory of a Leader's Betrayal|1|410958|||136222|c|
205947|Prophecy of a Desecrated Citadel|1|410971|||135975|c|
205948|Anodyne Epiphany|1|402265|||135791|c|
205949|Manifold Epiphany|1|402265|||135791|c|
205950|Tenebrous Epiphany|1|402265|||135791|c|
205951|Memory of a Troubled Acolyte|1|410958|||136222|c|
205952|Memory of a Shattered World|1|410958|||136222|c|
205953|Prophecy of a Broken Vow|1|410971|||135975|c|
205979|Rune of Flanking|1|402265|||134419|c|
205995|Prairie Dog Musk|1|411622|||134743|c|
206032|Rune of Carve|1|402265|||134419|c|
206155|Rune of Marksmanship|1|402265|||134419|c|
206168|Rune of the Chimera|1|402265|||134419|c|
206169|Rune of Explosive Shot|1|402265|||134419|c|
206177|Pine Nut Butter|1|5004|11||133213|c|
206264|Rune of Inspiration|1|402265|||134419|c|
206466|Prairie Crown|1|414724|||132767|c|
206469|Prairie Flower|1|413651|||133941|c|
206963|Rune of Natural Potential|1|402265|||134419|c|
206970|Rune of Life|1|402265|||134419|c|
206985|Echo of the Alpha|3|402265|||136095|c|
206989|Rune of the Sun|1|402265|||134419|c|
206992|Rune of Skull Bash|1|402265|||134419|c|
207106|Bottom-Left Map Piece|1|416288|||134327|c|
207107|Bottom-Right Map Piece|1|416288|||134327|c|
207108|Top-Left Map Piece|1|416288|||134327|c|
207109|Top-Right Map Piece|1|416288|||134327|c|
207110|Durotar Treasure Map|1|416304|||134269|c|
207631|Adder Pheromone|1|416861|||134743|c|
208034|Tirisfal Treasure Map|1|417433|||134269|c|
208035|Top-Right Map Piece|1|417434|||134327|c|
208036|Top-Left Map Piece|1|417434|||134327|c|
208037|Bottom-Right Map Piece|1|417434|||134327|c|
208038|Bottom-Left Map Piece|1|417434|||134327|c|
208180|Rabbit Musk|1|418236|||134743|c|
208213|Top-Right Map Piece|1|418600|||134327|c|
208215|Top-Left Map Piece|1|418600|||134327|c|
208218|Bottom-Right Map Piece|1|418600|||134327|c|
208219|Bottom-Left Map Piece|1|418600|||134327|c|
208220|Dun Morogh Treasure Map|1|418599|||134269|c|
208601|Top-Right Map Piece|1|421425|||134327|c|
208602|Top-Left Map Piece|1|421425|||134327|c|
208603|Bottom-Right Map Piece|1|421425|||134327|c|
208604|Bottom-Left Map Piece|1|421425|||134327|c|
208605|Teldrassil Treasure Map|1|421424|||134269|c|
208607|Deer Musk|1|421311|||134743|c|
208609|Glade Flower|1|421436|||133941|c|
208687|Rune of Lacerate|1|402265|||134419|c|
208701|Rune of Beast Mastery|1|402265|||134419|c|
208741|Rune of Endless Rage|1|402265|||134419|c|
208744|Rune of Shadowbolts|1|402265|||134419|c|
208750|Rune of Channeling|1|402265|||134419|c|
208758|Earthen Rune|1|402265|||134419|c|
208760|Glade Crown|1|414724|||132767|c|
208764|Rune of the Mind|1|402265|||134419|c|
208767|Rune of Mending|1|402265|||134419|c|
208771|Rune of Blade Dance|1|402265|||134419|c|
208772|Rune of Saber Slash|1|402265|||134419|c|
208773|Fishing Harpoon|1|420964|||135129|c|
208777|Rune of the Sniper|1|402265|||134419|c|
208778|Rune of Quick Strike|1|402265|||134419|c|
208799|Spell Notes: Living Bomb|1|402265|||134939|c|
208823|Offering Coin|1|421197|||237281|c|
208828|Memory of a Broken Vow|1|410958|||136222|c|
208833|Malevolent Pie|1|421262|||237359|c|
208843|Battle Totem|1|421406|||134920|c|
208855|Rainbow Fin Albacore Chum|1|421599|||237270|c|
209027|Crab Treats|1|422171|||237270|c|
209047|Gnarled Harpoon|1|422397|||135129|c|
209057|Prototype Engine|1|422478|||133000|c|
209611|Insignia of the Alliance|1|5579|||133452|t|
209612|Insignia of the Alliance|1|23273|||133452|t|
209613|Insignia of the Alliance|1|23276|||133452|t|
209614|Insignia of the Alliance|1|23276|||133452|t|
209615|Insignia of the Alliance|1|23273|||133452|t|
209616|Insignia of the Alliance|1|5579|||133452|t|
209617|Insignia of the Alliance|1|23277|||133452|t|
209618|Insignia of the Alliance|1|23274|||133452|t|
209619|Insignia of the Horde|1|5579|||133453|t|
209620|Insignia of the Horde|1|23273|||133453|t|
209621|Insignia of the Horde|1|23276|||133453|t|
209622|Insignia of the Horde|1|23273|||133453|t|
209623|Insignia of the Horde|1|23274|||133453|t|
209624|Insignia of the Horde|1|23277|||133453|t|
209625|Insignia of the Horde|1|5579|||133453|t|
209626|Insignia of the Horde|1|5579|||133453|t|
209852|Rune of Kill Command|1|402265|||134419|c|
210015|Rune of Raging Blow|1|402265|||134419|c|
210137|Rune of Wild Growth|1|402265|||134419|c|
210147|Shredder Autosalvage Unit|1|424788|||133870|c|
210229|Rune of Mutilation|1|402265|||134419|c|
210252|Rune of Shiving|1|402265|||134419|c|
210253|Rot Totem|1|425285|||136008|c|
210322|Rune of Venom|1|402265|||134419|c|
210499|Marshroom|1|426019|||134052|c|
210500|Rune of the Stars|1|402265|||134419|c|
210569|Rune of Flagellation|1|402265|||134419|c|
210573|Rune of Consuming Rage|1|402265|||134419|c|
210589|Echo of the Ancestors|1|402265|||237571|c|
210596|Rune of Cobra Strikes|1|402265|||134419|c|
210653|Rune of Main Gauche|1|402265|||134419|c|
210708|Elixir of Coalesced Regret|20|426606|79|3|134799|c|
210712|Elixir of Insight|1|426612|||134791|c|
210746|Rune of Earth Shield|1|402265|||134419|c|
210811|Rune of Primordial Fury|1|402265|||134419|c|
210817|Rune of Survival|1|402265|||134419|c|
210818|Rune of Lone Wolf|1|402265|||134419|c|
210820|Rune of Sacrifice|1|402265|||134419|c|
210822|Harmonious Epiphany|1|402265|||135791|c|
210823|Rune of Dual Wield Specialization|1|402265|||134419|c|
210824|Rune of the Pact|1|402265|||134419|c|
210825|Rune of the Warbringer|1|402265|||134419|c|
210979|Rune of Shadowstep|1|402265|||134419|c|
210980|Rune of Metamorphosis|1|402265|||134419|c|
211205|Rune of Cobra Slayer|1|402265|||134419|c|
211301|Rune of Expose Weakness|1|402265|||134419|c|
211385|Rune of Serpent Spread|1|402265|||134419|c|
211387|Rune of Beckoning Light|1|402265|||134419|c|
211390|Rune of Teasing|1|402265|||134419|c|
211391|Rune of Healing Rain|1|402265|||134419|c|
211392|Rune of Everlasting Affliction|1|402265|||134419|c|
211393|Rune of Single-Minded Fury|1|402265|||134419|c|
211476|Rune of Fires Wake|1|402265|||134419|c|
211477|Rune of Incinerate|1|402265|||134419|c|
211487|Demolition Explosives|1|429732|||133709|c|
211488|Rune of the Avenger|1|402265|||134419|c|
211490|Prophecy of a Thousand Lights|1|410971|||135975|c|
211514|Spell Notes: Mass Regeneration|1|402265|||134939|c|
211528|Dark Insight|1|429972|||135736|c|
211530|Prophecy of a City Enthralled|1|410971|||135975|c|
211531|Prophecy of Seven Visitors|1|410971|||135975|c|
211534|Primal Insight|1|430021|||135736|c|
211691|Spell Notes: Arcane Blast|1|402265|||134939|c|
211800|Scroll of Reintegration|12|430318|||134937|c|
211815|Silverwing Battle Hymn|1|430352|||237052|c|
211816|Warsong Battle Drum|1|430352|||133841|c|
211953|Scroll of Arcane Recovery I|20|430948|||237449|c|
211954|Scroll of Arcane Accuracy I|20|430949|||237450|c|
211955|Scroll of Arcane Protection - Fire I|20|430950|||237451|c|
211956|Scroll of Arcane Protection - Frost I|20|430951|||237447|c|
211957|Scroll of Arcane Power I|20|430952|||237448|c|
212160|Chronoboon Displacer|1|1223679|1928|300|133879|c|
212548|Rune of Eclipse|1|402265|||134419|c|
212549|Rune of the Trapper|1|402265|||134419|c|
212551|Rune of Warfare|1|402265|||134419|c|
212552|Psychosophic Epiphany|1|402265|||135791|c|
212559|Rune of the Poisoned Blade|1|402265|||134419|c|
212560|Rune of Ancestral Awakening|1|402265|||134419|c|
212561|Rune of Burning Darkness|1|402265|||134419|c|
212562|Rune of Healing Rage|1|402265|||134419|c|
212568|Wolfshead Trophy|40|432190|||132203|c|
213074|Rune of Nourishing|1|402265|||134419|c|
213086|Rune of the Storm|1|402265|||134419|c|
213090|Rune of Synergy|1|402265|||134419|c|
213093|Rune of Power|1|402265|||134419|c|
213094|Rune of Fire Nova|1|402265|||134419|c|
213096|Rune of Decoys|1|402265|||134419|c|
213098|Rune of Invocation|1|402265|||134419|c|
213100|Rune of Forbidden Knowledge|1|402265|||134419|c|
213101|Rune of Shadowflames|1|402265|||134419|c|
213102|Rune of Wickedness|1|402265|||134419|c|
213103|Rune of Blood Surge|1|402265|||134419|c|
213104|Rune of Ruthless Precision|1|402265|||134419|c|
213109|Rune of Focused Rage|1|402265|||134419|c|
213110|Rune of the Commander|1|402265|||134419|c|
213111|Rune of Intervention|1|402265|||134419|c|
213112|Spell Notes: Missile Barrage|1|402265|||134939|c|
213117|Rune of Berserk|1|402265|||134419|c|
213118|Rune of the Jungle King|1|402265|||134419|c|
213119|Rune of Instinct|1|402265|||134419|c|
213120|Rune of the Dreamer|1|402265|||134419|c|
213121|DEPRECATED ITEM|25|434495|||133749|c|i
213122|Rune of Steady Shot|1|402265|||134419|c|
213123|Rune of Exposure|1|402265|||134419|c|
213124|Rune of Close Combat|1|402265|||134419|c|
213125|Rune of Invigoration|1|402265|||134419|c|
213126|Rune of the Scrapper|1|402265|||134419|c|
213128|Rune of Piety|1|402265|||134419|c|
213129|Rune of Light's Embrace|1|402265|||134419|c|
213130|Rune of Infusions|1|402265|||134419|c|
213131|Rune of Sacred Shields|1|402265|||134419|c|
213132|Rune of the Guardian|1|402265|||134419|c|
213136|Rune of Subtlety|1|402265|||134419|c|
213137|Rune of the Assailant|1|402265|||134419|c|
213138|Rune of the Southpaw|1|402265|||134419|c|
213139|Rune of the Assassin|1|402265|||134419|c|
213140|Prophecy of the Quickened Path|1|410971|||135975|c|
213141|Rune of Hope|1|402265|||134419|c|
213142|Prophecy of Imprisoned Malice|1|410971|||135975|c|
213143|Apocryphal Epiphany|1|402265|||135791|c|
213144|Luminous Epiphany|1|402265|||135791|c|
213426|Ogre Lightning Rod|1|434350|||134921|c|
213548|Scroll of Liminal Passage|1|434752|||4549171|c|
213550|Scroll of Polymorph: Odd Melon|16|434754|||4549172|c|
213564|Scroll of Minor Evocation|1|434851|||4549171|c|
213599|Unsettling Vision|1|435120|||136222|c|
215126|UNUSED Flask of Merciless Pursuit|40|17628|2593|3|134726|c|i
215257|Scroll of Comprehension|1|435563|||4549171|c|
216606|Rune of Two-Handed Mastery|1|402265|||134419|c|
216619|Student Fodder|1|436432|103|300|134057|c|
216748|Grimoire of Portal of Summoning|1|402265|||133733|c|
216879|Mysterious Troll Scroll|1|437707|||237446|c|
217308|Enchanted Sigil: Innovation|40|439155|||254884|c|
217345|Sebacious Poison|60|439462|||132108|c|
217346|Numbing Poison|60|439464|||132098|c|
217347|Atrophic Poison|60|439465|||132100|c|
217398|Lesser Arcane Elixir|28|439959|2593|3|134730|c|
217495|Scroll of Cryoblast|16|440212|24|60|4549168|c|
217496|Scroll of the Blade|1|1302286|||4549173|c|
217693|Invisibility Potion|1|440505|||236874|c|
217736|Rune of the Coterie|1|402265|||134419|c|
219147|Rune of Grace|1|402265|||134419|c|
219345|Infernal Lasso|50|443265|1141|12|136091|t|
220164|Rune of the Gladiator|1|402265|||134419|c|
220165|Rune of Wrath|1|402265|||134419|c|
220217|Rune of the Ravenous|1|402265|||134419|c|
220360|Rune of Efflorescence|1|402265|||134419|c|
220610|Rune of Mental Dexterity|1|402265|||134419|c|
220612|Rune of Tidal Waves|1|402265|||134419|c|
220613|Rune of Rolling Thunder|1|402265|||134419|c|
220614|Rune of Static Shock|1|402265|||134419|c|
220616|Rune of Overcharged|1|402265|||134419|c|
220617|Rune of Pandemic|1|402265|||134419|c|
220618|Rune of Immolation Aura|1|402265|||134419|c|
220682|Rune of the Unbridled|1|402265|||134419|c|
220687|Rune of the Raptor|1|402265|||134419|c|
220754|Rune of the Windstorm|1|402265|||134419|c|
220791|Rune of the Jungle Cat|1|402265|||134419|c|
220792|Scroll of Spatial Mending|1|448381|||134945|c|
220913|Rune of Demolition|1|402265|||134419|c|
221020|Rune of the Moon Goddess|1|402265|||134419|c|
221199|Satyrweed Tincture|1|447475|||236868|c|
221267|Rune of the Bloodthirsty|1|402265|||134419|c|
221317|Feralas Leycryst|1|446454|||237189|c|
221318|Azshara Leycryst|1|446454|||237193|c|
221319|Blackrock Leycryst|1|446454|||237192|c|
221320|Hinterlands Leycryst|1|446454|||237191|c|
221418|Agamaggan's Roar|1|446704|||237378|c|
221428|Rune of Foul Play|1|402265|||134419|c|
221433|Rune of Focus|1|402265|||134419|c|
221445|Rune of Focused Fire|1|402265|||134419|c|
221461|Rune of Carnage|1|402265|||134419|c|
221473|Rune of the Watchman|1|402265|||134419|c|
221480|Spell Notes: Molten Armor|1|402265|||134939|c|
221481|Nihilist Epiphany|1|402265|||135791|c|
221482|Rune of Affliction|1|402265|||134419|c|
221483|Rune of Burn|1|402265|||134419|c|
221487|Spell Notes: Advanced Warding|1|402265|||134939|c|
221488|Resolute Epiphany|1|402265|||135791|c|
221489|Rune of Vengeance|1|402265|||134419|c|
221490|Rune of Riptide|1|402265|||134419|c|
221499|Rune of the Felguard|1|402265|||134419|c|
221510|Rune of the Knight|1|402265|||134419|c|
221511|Rune of the Protector|1|402265|||134419|c|
221512|Rune of Alacrity|1|402265|||134419|c|
221513|Rune of Potency|1|402265|||134419|c|
221514|Rune of Firepower|1|402265|||134419|c|
221515|Rune of Detonation|1|402265|||134419|c|
221516|Rune of Primal Energy|1|402265|||134419|c|
221517|Rune of Bloodshed|1|402265|||134419|c|
221979|Prophecy of Verdant Winter|1|410971|||135975|c|
221980|Prophecy of Awakened Chaos|1|410971|||135975|c|
221981|Prophecy of the Lost Tribe|1|410971|||135975|c|
222962|Hyjal's Wisdom|1|448149|||236160|c|
223147|Spell Notes: Balefire Bolt|1|402265|||134939|c|
223168|Worldcore Fragment|1|448627|||132842|c|
223171|Scroll of Geomancy|1|448627|||134938|c|
223288|Rune of the Hammer|1|402265|||134419|c|
223912|Purification Potion|25|450105|4|120|134721|c|
223913|Major Healing Potion|40|450106|4|120|236885|c|
223914|Greater Healing Potion|20|450107|4|120|134718|c|
224806|Legion Portal Tuner|1|454017|||135222|c|
224893|Overcharged Portal Tuner|1|454466|||135224|c|
224912|Portal Tuner Tuner|1|454469|||134429|c|
225686|Rune of Decimation|1|402265|||134419|c|
225687|Rune of Infernal Armor|1|402265|||134419|c|
225688|Rune of Mark of Chaos|1|402265|||134419|c|
225689|Spell Notes: Arcane Barrage|1|402265|||134939|c|
225690|Spell Notes: Frozen Orb|1|402265|||134939|c|
225691|Spell Notes: Overheat|1|402265|||134939|c|
225740|Rune of Composure|1|402265|||134419|c|
225914|Rune of the Bound Spirit|1|402265|||134419|c|
225955|Rune of the Resourceful|1|402265|||134419|c|
226252|Rune of the Guerrilla|1|402265|||134419|c|
226374|Occult Poison I|54|458821|||135935|c|
226406|Rune of Sword Specialization|1|402265|||134419|c|
226407|Rune of Axe Specialization|1|402265|||134419|c|
226408|Rune of Mace Specialization|1|402265|||134419|c|
226409|Rune of Dagger Specialization|1|402265|||134419|c|
226410|Rune of Ranged Weapon Specialization|1|402265|||134419|c|
226411|Rune of Fist Weapon Specialization|1|402265|||134419|c|
226412|Rune of Pole Weapon Specialization|1|402265|||134419|c|
226413|Rune of Arcane Specialization|1|402265|||134419|c|
226414|Rune of Fire Specialization|1|402265|||134419|c|
226415|Rune of Frost Specialization|1|402265|||134419|c|
226416|Rune of Nature Specialization|1|402265|||134419|c|
226417|Rune of Shadow Specialization|1|402265|||134419|c|
226418|Rune of Holy Specialization|1|402265|||134419|c|
226419|Rune of Feral Combat Specialization|1|402265|||134419|c|
226546|Desert Sonar|1|459221|||133878|t|
226587|Rune of Shelling|1|402265|||134419|c|
226679|Timeless Wanderer's Insights|1|402265|||133739|c|
226680|Rune of the First Warrior|1|402265|||133747|c|
226694|Rune of Defense Specialization|1|402265|||134419|c|
227286|Warmed Rumsey Rum with Cream|1|460332|||132790|c|
227456|Rune of the Crimson Tempest|1|402265|||134419|c|
227746|Rune of the World Tree|1|402265|||134419|c|
227749|Rune of the Falling Star|1|402265|||134419|c|
227797|Mysterious 'Darnassian' Scroll|1|460928|||237446|c|
227921|Rune of Knives|1|402265|||134419|c|
227922|Rune of the Swashbuckler|1|402265|||134419|c|
228123|Jubilant Epiphany|1|402265|||135791|c|
228124|Oneiric Epiphany|1|402265|||135791|c|
228126|Aperitive Epiphany|1|402265|||135791|c|
228227|Scroll of Overwhelming Power|1|461520|||134938|c|
228978|Enchanted Sigil: Flowing Waters|60|463864|||254883|c|
228980|Conductive Shield Coating|40|463868|||134722|c|
231298|Scroll of Lesser Spatial Mending|1|468211|||134944|c|
231778|Mountain Spring Water|55|468767|59|1|132830|c|
231828|Rune of Meditation Specialization|1|402265|||134419|c|
231829|Rune of Healing Specialization|1|402265|||134419|c|
231836|Glowing Scroll of Spatial Mending|1|469020|||134943|c|
231843|First Sigil Fragment|1|469128|||136078|c|
231844|Second Sigil Fragment|1|469128|||136078|c|
231845|Third Sigil Fragment|1|469128|||136078|c|
232343|QAEnchant Shield - Law of Nature|1|469753|||133434|c|i
232344|Vick's VIP Pass|1|469777|||134938|c|
232433|Dense Runecloth Bandage|50|470345|150||133692|c|
232436|Darkclaw Bisque|45|470362|11||237331|c|
232438|Smoked Redgill|35|470369|11||133965|c|
232458|Rune of Improved Sanctuary|1|402265|||134419|c|
232459|Rune of Backdraft|1|402265|||134419|c|
232460|Rune of Displacement|1|402265|||134419|c|
232461|Rune of Despair|1|402265|||134419|c|
232462|Rune of Purifying Power|1|402265|||134419|c|
232611|Magnificent Trollshine|45|471401|||134876|c|
234444|Occult Poison II|60|1214171|||135935|c|
235597|Spell Notes: Deep Freeze|1|402265|||134939|c|
235598|Spell Notes: Icy Veins|1|402265|||134939|c|
235599|Spell Notes: Temporal Anomaly|1|402265|||134939|c|
235600|Rune of Divine Storm|1|402265|||134419|c|
235601|Rune of Fanaticism|1|402265|||134419|c|
235602|Rune of Hammer of the Righteous|1|402265|||134419|c|
235603|Rune of Righteous Vengeance|1|402265|||134419|c|
235604|Rune of Shield of Righteousness|1|402265|||134419|c|
235605|Rune of Shock and Awe|1|402265|||134419|c|
237023|Pop-Up Shrub|10|1221337|||237425|c|
238637|Prowler Steak|55|1225769|11||134040|c|
238638|Filet o' Flank|55|1225771|11||134044|c|
238639|Sunrise Omelette|55|1225772|11||133991|c|
238641|Specklefin Feast|55|1225906|11||237331|c|
238642|Grand Lobster Banquet|55|1225907|11||134019|c|
240945|Slice of Carrie's Apple Pie|1|433|||236212|c|
241650|Major Discolored Healing Potion|60|1231578|4|120|134820|c|
242269|Brilliance of the Grand Sorcerer|1|1232054|||132882|c|
242270|Brilliance of the Grand Arcanist|1|1232077|||132875|c|
242271|Brilliance of the Grand Crusader|1|1232079|||237014|c|
242362|Brilliance of the Grand Inquisitor|1|1232176|||237015|c|
244231|Ensemble: Stillwater Fisher Attire|1|1236676|||6893245|c|
246948|Distilled Firewater|45|17038||60|134872|c|
247239|Lesser Discolored Healing Potion|3|1244864|4|120|134816|c|
247240|Discolored Healing Potion|12|1244865|4|120|134817|c|
247241|Greater Discolored Healing Potion|21|1244866|4|120|134818|c|
247242|Superior Discolored Healing Potion|35|1244867|4|120|134819|c|
247754|Minor Arcane Elixir|1|1245244|2593|3|134728|c|
247755|Elixir of Minor Force|1|1245249|2593|3|134857|c|
247824|Thunder Applejack|1|11009|||132793|c|
247840|Mining for Dummies|1|1245608|||4625105|c|
247841|Wild Harvest|1|1245609|||4624731|c|
247846|Pelt Collecting for Beginners|1|1245610|||4625106|c|
248206|Sealed Craftsman's Writ|10|1247526|||134328|c|
248613|Lightning in a Bottle|15|435|11||134811|c|
248682|Waylaid Crate: Apprentice Herbs|10|1247426|||236994|c|
248683|Waylaid Crate: Apprentice Ore|10|1247427|||236994|c|
248684|Waylaid Crate: Apprentice Textiles|10|1247428|||236994|c|
248685|Waylaid Crate: Apprentice Curiosities|10|1247429|||236994|c|
248686|Waylaid Crate: Journeyman Herbs|10|1247430|||236994|c|
248687|Waylaid Crate: Journeyman Ore|10|1247431|||236994|c|
248688|Waylaid Crate: Journeyman Textiles|10|1247432|||236994|c|
248689|Waylaid Crate: Journeyman Curiosities|10|1247433|||236994|c|
248690|Waylaid Crate: Earthly Expert Herbs|20|1247434|||236994|c|
248691|Waylaid Crate: Flowering Expert Herbs|20|1247435|||236994|c|
248692|Waylaid Crate: Expert Ore|20|1247436|||236994|c|
248693|Waylaid Crate: Expert Textiles|20|1247437|||236994|c|
248694|Waylaid Crate: Expert Curiosities|20|1247438|||236994|c|
248695|Waylaid Crate: Earthly Artisan Herbs|35|1247439|||236994|c|
248696|Waylaid Crate: Flowering Artisan Herbs|35|1247440|||236994|c|
248697|Waylaid Crate: Artisan Ore|35|1247441|||236994|c|
248698|Waylaid Crate: Artisan Textiles|35|1247442|||236994|c|
248699|Waylaid Crate: Artisan Curiosities|35|1247443|||236994|c|
248702|Waylaid Crate: Apprentice Fabrics|10|1247446|||236994|c|
248703|Waylaid Crate: Apprentice Ingots|10|1247447|||236994|c|
248704|Waylaid Crate: Apprentice Parts|10|1247448|||236994|c|
248705|Waylaid Crate: Journeyman Fabrics|10|1247449|||236994|c|
248706|Waylaid Crate: Journeyman Ingots|10|1247450|||236994|c|
248707|Waylaid Crate: Journeyman Parts|10|1247451|||236994|c|
248708|Waylaid Crate: Expert Fabrics|20|1247452|||236994|c|
248709|Waylaid Crate: Expert Ingots|20|1247453|||236994|c|
248710|Waylaid Crate: Expert Parts|20|1247454|||236994|c|
248711|Waylaid Crate: Artisan Fabrics|35|1247455|||236994|c|
248712|Waylaid Crate: Artisan Ingots|35|1247456|||236994|c|
248713|Waylaid Crate: Artisan Parts|35|1247457|||236994|c|
249469|Frozen Heart of the Mountain|50|1249110|1141|15|134131|t|
249470|Molten Heart of the Mountain|50|1249113|1141|15|134128|t|
249796|Hyjal Berries|45|1129|||133996|c|
249865|Peace Tea|1|1249920|||132802|c|
249866|Royal Tea|5|1249921|||132802|c|
249867|Root Tea|15|1249922|||132802|c|
249868|Triage Tea|25|1249923|||132802|c|
249869|Sunny Tea|35|1249924|||132802|c|
249870|Sage's Tea|45|1249925|||132802|c|
249871|Venomous Smoothie|1|1249914|||132808|c|
249872|Slimy Smoothie|5|1249915|||4621577|c|
249873|Mrrggl Smrrthle|15|1249916|||4621583|c|
249874|Calcified Smoothie|25|1249917|||4621575|c|
249875|Spicy Smoothie|35|1249918|||4621586|c|
249876|Wicked Smoothie|45|1249919|||4621578|c|
250065|Savory Stag Sliders|35|1248397|||237335|c|
250066|Soaring Pamplona|45|1248400|||350562|c|
250067|Bat Hachee|45|1248400|||237329|c|
250068|Savory Turtle Stew|45|1248398|||651567|c|
250069|Flank au Poivre|45|1248399|||350563|c|
250070|Bear Bruscitti|45|1248401|||1387649|c|
250071|Steaming Stag Steak|45|1248401|||350558|c|
250072|Swiftstrike Steak|45|1248399|||134005|c|
250073|Raging Raptor Ribs|25|1248392|||1387664|c|
250074|Bear Brisket|25|1248393|||134003|c|
250075|Prehistoric Pulled Raptor|45|1248400|||237337|c|
250076|Raptor Rouladen|35|1248396|||350564|c|
250077|Twice-Spiced Raptor Slice|5|1248383|||1387662|c|
250078|Giant Scrambled Eggs|25|1248390|||133748|c|
250079|Tasty Raptor Bites|1|1248379|||134024|c|
250080|Breakfast Omelette|5|1248381|||651570|c|
250081|Clam Linguine|45|1131|||133748|c|
250327|Potion of Predatory Senses|45|1250889|4|120|967555|c|
250328|Elixir of Cunning|55|1250918|2593|3|134794|c|
250329|Elixir of the Phalanx|55|1250920|2593|3|967529|c|
250330|Minor Cleric's Elixir|5|1250922|2593|3|967524|c|
250331|Lesser Cleric's Elixir|25|1250924|2593|3|134752|c|
250332|Cleric's Elixir|45|1250925|2593|3|134764|c|
250333|Greater Cleric's Elixir|55|1250926|2593|3|134777|c|
250334|Elixir of Fortitude|45|1250928|2593|3|134824|c|
250335|Elixir of Greater Fortitude|55|1250931|2593|3|134825|c|
250336|Elixir of Wicked Regeneration|55|1250932|2593|3|967526|c|
250337|Elixir of the Owl|55|1250940|2593|3|134792|c|
250338|Elixir of Sages|55|1250941|2593|3|134793|c|
250339|Minor Mageblood Elixir|5|1250942|2593|3|967519|c|
250340|Lesser Mageblood Elixir|25|1250944|2593|3|134750|c|
250341|Greater Mageblood Elixir|55|1250948|2593|3|134796|c|
250342|Lesser Arcane Elixir|25|1250971|2593|3|134729|c|
250343|Elixir of Nature Power|55|1250972|2593|3|134877|c|
250344|Elixir of Minor Spirit|5|1250974|2593|3|134736|c|
250345|Elixir of Lesser Spirit|25|1250976|2593|3|134737|c|
250346|Elixir of Spirit|45|1250978|2593|3|134738|c|
250347|Elixir of Greater Spirit|55|1250979|2593|3|134739|c|
250348|Elixir of the Whale|55|1250981|2593|3|134791|c|
250349|Elixir of Strength|45|1250984|2593|3|134838|c|
250350|Elixir of Ferocity|55|1250985|2593|3|134789|c|
250351|Elixir of the Grizzly|55|1250986|2593|3|134788|c|
250353|Elixir of Lesser Intellect|25|1250988|2593|3|134823|c|
250354|Elixir of Intellect|45|1250989|2593|3|134824|c|
250932|Minor Spellblasting Potion|5|1251919|||967557|c|
250933|Lesser Spellblasting Potion|15|1251922|||463545|c|
250934|Spellblasting Potion|25|1251923|||463921|c|
250935|Greater Spellblasting Potion|35|1251924|||464027|c|
250936|Superior Spellblasting Potion|45|1251931|||463859|c|
250937|Major Spellblasting Potion|55|1251932|||463929|c|
250938|Minor Frenzy Potion|5|1251933|||967555|c|
250939|Lesser Frenzy Potion|15|1251935|||463548|c|
250940|Frenzy Potion|25|1251936|||463922|c|
250941|Greater Frenzy Potion|35|1251937|||464024|c|
250942|Superior Frenzy Potion|45|1251938|||463863|c|
250943|Major Frenzy Potion|55|1251940|||463931|c|
250944|Minor Mender's Potion|5|1251942|||967556|c|
250945|Lesser Mender's Potion|15|1251944|||463547|c|
250946|Mender's Potion|25|1251945|||463925|c|
250947|Greater Mender's Potion|35|1251946|||464026|c|
250948|Superior Mender's Potion|45|1251947|||463860|c|
250949|Major Mender's Potion|55|1251948|||463927|c|
250950|Potion of Venomous Blood|30|1251986|||134799|c|
250951|Caustic Smog Potion|45|1252525|||967550|c|
250953|Dragonfire Potion|35|1252554|||134813|c|
250954|Potion of Elemental Purging|40|1252558|||2057575|c|
250955|Potion of Beast Slaying|40|1252559|||2057578|c|
251525|Savory Whimsyfin Delight|1|1252576|11||237320|c|
251917|Falorne's Homemade Tart|1|433|11||2066016|c|
252022|Galestrider Jerky|1|433|11||133972|c|
252023|Zaalanarr Sharp|1|433|11||133948|c|
252026|Gustberry Pie|5|434|||133952|c|
252027|Gustberry Juice|5|431|||454047|c|
252028|Fresh Gustberry Bread|1|433|11||2466573|c|
252029|Hippogryph Flank|5|434|||237335|c|
252030|Pungent Skycheddar|5|434|11||133954|c|
252031|Crisp Spring Water|1|430|59|1|132820|c|
252032|Red Delicious Stormapple|5|434|||133975|c|
252436|Mystic Medium Armor Kit|15|1254742|||133609|c|
252437|Forceful Medium Armor Kit|15|1254740|||133609|c|
252452|Mystic Heavy Armor Kit|30|1254750|||133610|c|
252453|Forceful Heavy Armor Kit|30|1254748|||133610|c|
252462|Mystic Thick Armor Kit|40|1254767|||133602|c|
252463|Forceful Thick Armor Kit|40|1254768|||133602|c|
252487|Mystic Rugged Armor Kit|50|1254770|||133604|c|
252488|Forceful Rugged Armor Kit|50|1254772|||133604|c|
255663|Windstone|1|1259231|4|120|5172975|c|
260623|Candied Fruit Sampler|25|1127|11||895875|c|
260624|Pristine Peach|35|1129|11||133998|c|
260625|Garnished Rice Cake|35|1129|11||650006|c|
260627|Savory Shen'dralar Steak|45|1131|11||351502|c|
260628|Stuffed Pumpkin|45|1131|11||651582|c|
260629|Spectral Spirits|1|11007|||132797|c|
260631|Arcane Wine|1|11008|||4621586|c|
260632|Slushberry Brandy|1|11008|||461801|c|
260633|Sip of Lemonale|1|11009|||413581|c|
260792|SAF-T Dynamite|1|1269155|24|60|133714|c|
260793|SAF-T Copper Bomb|1|1269161|24|60|133717|c|
260795|EZ-Thro Copper Bomb XL|1|1269192|24|60|133709|c|
260797|SAF-T Bronze Bomb|1|1269216|24|60|133717|c|
260798|SAF-T Jumbo Dynamite|1|1269264|24|60|133714|c|
260800|Shafety Sheep|1|1269265|24|60|538563|c|
260802|EZ-Thro Bronze Mortar|1|1269268|||134535|t|
260803|EZ-Thro Grenade|1|1269270|24|60|133714|c|
260805|SAF-T Bomb|1|1269272|24|60|133709|c|
260806|Emergency Field Cloak|1|4079|2465|3600|133872|t|
260807|Compact Critter Carrier|40|1318024|||132598|c|
260809|Tru-Trigger Frag Bomb|1|1269278|24|60|133710|c|
260814|SAF-T Clever Dynamite|1|1269282|24|60|133714|c|
260816|EZ-Thro Thorium Grenade|1|1269330|24|60|133716|c|
260817|EZ-Thro Dark Bomb|1|1269334|24|60|133713|c|
260818|EZ-Thro Mana Bomb|1|1269337|24|60|136173|c|
260819|EZ-Thro Field Transporter: Gadgetzan|55|23453|2467|14400|133860|t|
260820|SAF-T Emergency Ripper: Everlook|55|23442|2467|14400|133859|t|
260821|EZ and SAF Field Transporter: Mt. Hyjal|60|1269339|2467|14400|133868|t|
260822|Ultrasafe Rechargeable Battery|60|1270940|||465875|c|
260824|Gnomish Poultryizer|60|1270941|||133864|t|
260827|Stealthman 52|55|1271266|1153|300|133862|c|
260830|SAF-T Teleport|55|1225951|||133874|c|
262433|Ketharas' Hyjal Stew|1|1269354|11||351504|c|
262887|Sealed Apprentice's Writ|10|1269670|||134328|c|
262888|Sealed Journeyman's Writ|10|1269671|||134328|c|
262889|Sealed Expert's Writ|10|1269673|||134328|c|
262890|Sealed Artisan's Writ|10|1269675|||134328|c|
263509|Skywall Souffle|5|1248377|||651570|c|
263512|Pincer Bites|5|1248379|||1508493|c|
267341|Sweetpaw Jam|55|1294006|||133748|c|
267474|Galeswept Forestshroom|1|433|11||134526|c|
268873|Defender of the Barkskin|55|1294063|94|20|134228|t|
268880|"Secret" Bait|1|8087|||4554362|c|
268881|Perishable Minor Healing Potion|1|439|4|120|134829|c|
268882|Perishable Lesser Healing Potion|3|440|4|120|134830|c|
268883|Perishable Healing Potion|12|441|4|120|134831|c|
268912|Expiring Crab Cake|5|1248381|||133950|c|
268913|Expiring Crocolisk Steak|5|1248381|||134003|c|
269741|Scented Runewood Brooch|1|1296664|||463480|t|
269902|Hoof-Shaped Foot Pedal|1|1286814|||1534178|c|
270226|Golden Banana|1|1287571|1141|15|133980|t|
271731|Ensemble: Shen'dorei Magister's Garb|1|1289402|||7751149|c|
271744|Ensemble: Shen'dorei Peacekeeper's Garb|1|1289407|||7751149|c|
271755|Ensemble: Shen'dorei Skyseer's Garb|1|1289417|||7751149|c|
271765|Ensemble: Al'Aketh Zealot's Garb|1|1289419|||7751149|c|
271871|Gift of Galloping|60|1289654|||136103|c|
272053|Darkspear Islands Field Ration|25|1290860|11||133951|c|
272054|Darkspear Islands Iron Ration|35|1290859|11||133950|c|
272055|Darkspear Islands Enriched Ration|45|1290861|11||133989|c|
272056|Darkspear Islands Silk Bandage|25|1290867|150||133672|c|
272057|Darkspear Islands Mageweave Bandage|35|1290863|150||133690|c|
272058|Darkspear Islands Runecloth Bandage|45|1290865|150||133682|c|
272437|Adaptive Combat Assistant|60|1291097|1141|15|3610508|t|
272438|Weakness Analyzer|60|1291101|1141|20|321487|t|
272439|Serenity Field|60|1291103|1141|15|465877|t|
272440|Defender's Grip Stabilizer|60|1291105|1141|15|4620673|t|
273458|Enchant Bracer - Inferior Stamina|1|7418|||463531|c|
273459|Enchant Chest - Inferior Stamina|1|7420|||463531|c|
273460|Enchant Chest - Minor Absorption|1|7426|||463531|c|
273461|Enchant Bracer - Minor Deflect|1|7428|||463531|c|
273462|Enchant Chest - Minor Intellect|1|7443|||463531|c|
273463|Enchant Cloak - Minor Resistance|1|7454|||463531|c|
273464|Enchant Bracer - Minor Stamina|1|7457|||463531|c|
273465|Enchant 2H Weapon - Minor Impact|1|7745|||463531|c|
273466|Enchant Chest - Lesser Stamina|1|7748|||463531|c|
273467|Enchant Bracer - Minor Spirit|1|7766|||463531|c|
273468|Enchant Cloak - Minor Protection|1|7771|||463531|c|
273469|Enchant Chest - Lesser Intellect|1|7776|||463531|c|
273470|Enchant Bracer - Minor Agility|1|7779|||463531|c|
273471|Enchant Bracer - Minor Strength|1|7782|||463531|c|
273472|Enchant Weapon - Minor Beastslayer|1|7786|||463531|c|
273473|Enchant Weapon - Minor Striking|1|7788|||463531|c|
273474|Enchant 2H Weapon - Lesser Intellect|1|7793|||463531|c|
273475|Enchant Chest - Stamina|1|7857|||463531|c|
273476|Enchant Bracer - Lesser Spirit|1|7859|||463531|c|
273477|Enchant Cloak - Lesser Fire Resistance|1|7861|||463531|c|
273478|Enchant Boots - Minor Stamina|1|7863|||463531|c|
273479|Enchant Boots - Minor Agility|1|7867|||463531|c|
273480|Enchant Shield - Minor Stamina|1|13378|||463531|c|
273481|Enchant 2H Weapon - Lesser Spirit|1|13380|||463531|c|
273482|Enchant Cloak - Minor Agility|1|13419|||463531|c|
273483|Enchant Cloak - Lesser Protection|1|13421|||463531|c|
273484|Enchant Shield - Lesser Protection|1|13464|||463531|c|
273485|Enchant Shield - Lesser Spirit|1|13485|||463531|c|
273486|Enchant Bracer - Lesser Stamina|1|13501|||463531|c|
273487|Enchant Weapon - Lesser Striking|1|13503|||463531|c|
273488|Enchant Cloak - Lesser Shadow Resistance|1|13522|||463531|c|
273489|Enchant 2H Weapon - Lesser Impact|1|13529|||463531|c|
273490|Enchant Bracer - Lesser Strength|1|13536|||463531|c|
273491|Enchant Chest - Lesser Absorption|1|13538|||463531|c|
273492|Enchant Chest - Intellect|1|13607|||463531|c|
273493|Enchant Gloves - Mining|1|13612|||463531|c|
273494|Enchant Gloves - Herbalism|1|13617|||463531|c|
273495|Enchant Gloves - Fishing|1|13620|||463531|c|
273496|Enchant Bracer - Lesser Intellect|1|13622|||463531|c|
273497|Enchant Chest - Minor Stats|1|13626|||463531|c|
273498|Enchant Shield - Lesser Stamina|1|13631|||463531|c|
273499|Enchant Cloak - Defense|1|13635|||463531|c|
273500|Enchant Boots - Lesser Agility|1|13637|||463531|c|
273501|Enchant Chest - Greater Stamina|1|13640|||463531|c|
273502|Enchant Bracer - Spirit|1|13642|||463531|c|
273503|Enchant Boots - Lesser Stamina|1|13644|||463531|c|
273504|Enchant Bracer - Lesser Deflection|1|13646|||463531|c|
273505|Enchant Bracer - Stamina|1|13648|||463531|c|
273506|Enchant Weapon - Lesser Beastslayer|1|13653|||463531|c|
273507|Enchant Weapon - Lesser Elemental Slayer|1|13655|||463531|c|
273508|Enchant Cloak - Fire Resistance|1|13657|||463531|c|
273509|Enchant Shield - Spirit|1|13659|||463531|c|
273510|Enchant Bracer - Strength|1|13661|||463531|c|
273511|Enchant Chest - Greater Intellect|1|13663|||463531|c|
273512|Enchant Boots - Lesser Spirit|1|13687|||463531|c|
273513|Enchant Shield - Lesser Block|1|13689|||463531|c|
273514|Enchant Weapon - Striking|1|13693|||463531|c|
273515|Enchant 2H Weapon - Impact|1|13695|||463531|c|
273516|Enchant Gloves - Skinning|1|13698|||463531|c|
273517|Enchant Chest - Lesser Stats|1|13700|||463531|c|
273518|Enchant Cloak - Greater Defense|1|13746|||463531|c|
273519|Enchant Cloak - Resistance|1|13794|||463531|c|
273520|Enchant Gloves - Agility|1|13815|||463531|c|
273521|Enchant Shield - Stamina|1|13817|||463531|c|
273522|Enchant Bracer - Intellect|1|13822|||463531|c|
273523|Enchant Boots - Stamina|1|13836|||463531|c|
273524|Enchant Gloves - Advanced Mining|1|13841|||463531|c|
273525|Enchant Bracer - Greater Spirit|1|13846|||463531|c|
273526|Enchant Chest - Superior Stamina|1|13858|||463531|c|
273527|Enchant Gloves - Advanced Herbalism|1|13868|||463531|c|
273528|Enchant Cloak - Lesser Agility|1|13882|||463531|c|
273529|Enchant Gloves - Strength|1|13887|||463531|c|
273530|Enchant Boots - Minor Speed|1|13890|||463531|c|
273531|Enchant Weapon - Fiery Weapon|1|13898|||463531|c|
273532|Enchant Shield - Greater Spirit|1|13905|||463531|c|
273533|Enchant Weapon - Demonslaying|1|13915|||463531|c|
273534|Enchant Chest - Superior Intellect|1|13917|||463531|c|
273535|Enchant Bracer - Deflection|1|13931|||463531|c|
273536|Enchant Shield - Frost Resistance|1|13933|||463531|c|
273537|Enchant Boots - Agility|1|13935|||463531|c|
273538|Enchant 2H Weapon - Greater Impact|1|13937|||463531|c|
273539|Enchant Bracer - Greater Strength|1|13939|||463531|c|
273540|Enchant Chest - Stats|1|13941|||463531|c|
273541|Enchant Weapon - Greater Striking|1|13943|||463531|c|
273542|Enchant Bracer - Greater Stamina|1|13945|||463531|c|
273543|Enchant Gloves - Riding Skill|1|13947|||463531|c|
273544|Enchant Gloves - Minor Haste|1|13948|||463531|c|
273545|Enchant Bracer - Greater Intellect|1|20008|||463531|c|
273546|Enchant Bracer - Superior Spirit|1|20009|||463531|c|
273547|Enchant Bracer - Superior Strength|1|20010|||463531|c|
273548|Enchant Bracer - Superior Stamina|1|20011|||463531|c|
273549|Enchant Gloves - Greater Agility|1|20012|||463531|c|
273550|Enchant Gloves - Greater Strength|1|20013|||463531|c|
273551|Enchant Cloak - Greater Resistance|1|20014|||463531|c|
273552|Enchant Cloak - Superior Defense|1|20015|||463531|c|
273553|Enchant Shield - Superior Spirit|1|20016|||463531|c|
273554|Enchant Shield - Greater Stamina|1|20017|||463531|c|
273555|Enchant Boots - Greater Stamina|1|20020|||463531|c|
273556|Enchant Boots - Greater Agility|1|20023|||463531|c|
273557|Enchant Boots - Spirit|1|20024|||463531|c|
273558|Enchant Chest - Greater Stats|1|20025|||463531|c|
273559|Enchant Chest - Major Stamina|1|20026|||463531|c|
273560|Enchant Chest - Major Intellect|1|20028|||463531|c|
273561|Enchant Weapon - Icy Chill|1|20029|||463531|c|
273562|Enchant 2H Weapon - Superior Impact|1|20030|||463531|c|
273563|Enchant Weapon - Superior Striking|1|20031|||463531|c|
273564|Enchant Weapon - Lifestealing|1|20032|||463531|c|
273565|Enchant Weapon - Unholy Weapon|1|20033|||463531|c|
273566|Enchant Weapon - Crusader|1|20034|||463531|c|
273567|Enchant 2H Weapon - Major Spirit|1|20035|||463531|c|
273568|Enchant 2H Weapon - Major Intellect|1|20036|||463531|c|
273569|Enchant Weapon - Winter's Might|1|21931|||463531|c|
273570|Enchant Weapon - Spell Power|1|22749|||463531|c|
273571|Enchant Weapon - Healing Power|1|22750|||463531|c|
273572|Enchant Weapon - Strength|1|23799|||463531|c|
273573|Enchant Weapon - Agility|1|23800|||463531|c|
273574|Enchant Bracer - Mana Regeneration|1|23801|||463531|c|
273575|Enchant Bracer - Healing Power|1|23802|||463531|c|
273576|Enchant Weapon - Mighty Spirit|1|23803|||463531|c|
273577|Enchant Weapon - Mighty Intellect|1|23804|||463531|c|
273578|Enchant Gloves - Threat|1|25072|||463531|c|
273579|Enchant Gloves - Shadow Power|1|25073|||463531|c|
273580|Enchant Gloves - Frost Power|1|25074|||463531|c|
273581|Enchant Gloves - Fire Power|1|25078|||463531|c|
273582|Enchant Gloves - Healing Power|1|25079|||463531|c|
273583|Enchant Gloves - Superior Agility|1|25080|||463531|c|
273584|Enchant Cloak - Greater Fire Resistance|1|25081|||463531|c|
273585|Enchant Cloak - Greater Nature Resistance|1|25082|||463531|c|
273586|Enchant Cloak - Stealth|1|25083|||463531|c|
273587|Enchant Cloak - Subtlety|1|25084|||463531|c|
273588|Enchant Cloak - Dodge|1|25086|||463531|c|
273589|Enchant 2H Weapon - Agility|1|27837|||463531|c|
273590|Enchant Weapon - Dismantle|1|435481|||463531|c|
273591|Enchant Chest - Retricutioner|1|435903|||463531|c|
273592|Enchant Shield - Law of Nature|1|463871|||463531|c|
273593|Enchant Chest - Living Stats|1|1213616|||463531|c|
273594|Enchant Gloves - Holy Power|1|1213622|||463531|c|
273595|Enchant Gloves - Arcane Power|1|1213626|||463531|c|
273596|Enchant Bracer - Spell Power|1|1217189|||463531|c|
273597|Enchant Bracer - Agility|1|1217203|||463531|c|
273598|Enchant Off-Hand - Superior Intellect|1|1219577|||463531|c|
273599|Enchant Off-Hand - Excellent Spirit|1|1219578|||463531|c|
273600|Enchant Off-Hand - Wisdom|1|1219579|||463531|c|
273601|Enchant 2H Weapon - Spellblasting|1|1219580|||463531|c|
273602|Enchant Shield - Excellent Stamina|1|1219581|||463531|c|
273604|Enchant Cloak - Agility|1|1219587|||463531|c|
273605|Enchant Shield - Critical Strike|1|1220623|||463531|c|
273606|Enchant Bracer - Greater Spellpower|1|1220624|||463531|c|
273607|Enchant Weapon - Grand Crusader|1|1231128|||463531|c|
273608|Enchant 2H Weapon - Grand Arcanist|1|1231139|||463531|c|
273609|Enchant Weapon - Grand Sorcerer|1|1231164|||463531|c|
273610|Enchant 2H Weapon - Grand Inquisitor|1|1232172|||463531|c|
273611|Enchant Bracer - Minor Intellect|1|1248458|||463531|c|
273612|Enchant Bracer - Minor Healing Power|1|1248459|||463531|c|
273613|Enchant Bracer - Lesser Agility|1|1248460|||463531|c|
273614|Enchant Bracer - Agility|1|1248497|||463531|c|
273615|Enchant Bracer - Lesser Healing Power|1|1248498|||463531|c|
273616|Enchant Bracer - Greater Agility|1|1248500|||463531|c|
273617|Enchant 2H Weapon - Lesser Agility|1|1248510|||463531|c|
273618|Enchant 2H Weapon - Lesser Strength|1|1248511|||463531|c|
273619|Enchant Gloves - Advanced Skinning|1|1248528|||463531|c|
273620|Enchant Bracer - Superior Agility|1|1248599|||463531|c|
273621|Enchant 2H Weapon - Mighty Spell Power|1|1248607|||463531|c|
273622|Enchant 2H Weapon - Mighty Healing Power|1|1248636|||463531|c|
273623|Enchant Gloves - Superior Strength|1|1248640|||463531|c|
273624|Enchant Gloves - Natural Power|1|1248645|||463531|c|
273625|Enchant Bracer - Superior Intellect|1|1248661|||463531|c|
273626|Enchant Bracer - Superior Deflection|1|1248665|||463531|c|
273627|Enchant Weapon - Insight|1|1248757|||463531|c|
273628|Enchant Weapon - Recovery|1|1248760|||463531|c|
273629|Enchant Weapon - Revelation|1|1248805|||463531|c|
273630|Enchant Necklace - Strength|1|1249019|||463531|c|
273631|Enchant Necklace - Spell Power|1|1249057|||463531|c|
273632|Enchant Necklace - Healing Power|1|1249058|||463531|c|
273633|Enchant Necklace - Agility|1|1249059|||463531|c|
273634|Enchant Necklace - Deflection|1|1249060|||463531|c|
273635|Enchant Chest - Absorption|1|1249071|||463531|c|
274273|Flask of Natural Accuracy|55|1293740|2593|3|463902|c|
274274|Flask of Natural Aggression|55|1293741|2593|3|463898|c|
274275|Flask of Natural Precision|55|1293742|2593|3|463900|c|
274276|Flask of Natural Swiftness|55|1293743|2593|3|463901|c|
274386|Toy Soldier|1|1293820|2554|20|133070|t|
274426|Enchant Gloves - Lotus Claw|1|1294054|||463531|c|
274444|Greater Insignia of the Horde|1|438273|||133453|t|
274445|Greater Insignia of the Alliance|1|438273|||133452|t|
274709|Potion of Experience - Level 23|1|1294877|||134877|c|
274710|Potion of Experience - Level 38|1|1294909|||134742|c|
274711|Potion of Experience - Level 57|1|1294911|||134835|c|
274712|Potion of Experience - Level 60|1|1294913|||134735|c|
274759|Everlook Pathcarver|50|1295270|1141|15|133874|t|
274760|Everlook Delivery Bot|50|1295271|1141|20|133861|t|
274761|Parachute-Priest Pager|50|1295272|2554|15|133863|t|
274917|Brittle Trap|2|8312|24|60|134325|c|
274918|Warding Candle|1|1295608|4|60|5948076|c|
274922|Riverglades Marsh Gas|1|1295639|||650640|c|
274935|Tessa's Tonic|35|1295688|4|120|134826|c|
274947|Scroll of Imbue Lesser Flame|5|1295720|||4549170|c|
274971|Briny Seafood Stew|25|1249510|||461131|c|
274976|Plain Ol' Paletusk|25|1248393|||133972|c|
275067|Scroll of Imbue Chillknife|5|1296225|||4549168|c|
275069|Scroll of Rat Familiar|5|1296202|||4549169|c|
275347|Lichbane|1|1296564|||133439|t|
275633|Foxtail Ward|1|1297109|24|60|134323|c|
275688|Power Recycler|1|1297671|1153|120|134519|c|
276145|Explosive Runeshard|1|1298707|24|60|133573|c|
276337|Thaelemaches' Talisman|1|1299440|||133442|t|
276895|Transformative Cocoon|1|1301167|||237431|t|
277132|Harvester Override Signalcaster|1|1301683||180|133015|c|
277483|Scroll of Frog Familiar|16|1302285|||4549169|c|
277484|Scroll of Confuse Beast|16|1309788|||4549172|c|
277485|Scroll of Imbue Frost|16|1302283|||4549168|c|
277486|Scroll of Imbue Striking|16|1302217|||4549172|c|
277487|Scroll of Imbue Baleflame|16|1302219|||4549170|c|
277488|Scroll of Imbue Iceknife|16|1302284|||4549168|c|
277489|Scroll of Imbue Spark|16|1302227|||4549170|c|
277490|Scroll of the Saber|1|1302293|||4549173|c|
277491|Scroll of Rebuke Elemental|25|1302301|||4549172|c|
277492|Scroll of Khadgar's Unlocking|25|1302297|||4549171|c|
277493|Scroll of Cat Familiar|25|1302303|||4549169|c|
277494|Scroll of Imbue Accuracy|25|1302306|||4549172|c|
277495|Scroll of Imbue Quickening|25|1302307|||4549172|c|
277496|Scroll of Imbue Balefrost|25|1302305|||4549168|c|
277497|Scroll of Imbue Flame|25|1302304|||4549170|c|
277498|Scroll of Imbue Manablade|25|1302308|||4549172|c|
277499|Scroll of Greater Cryoblast|46|1302309|24|60|4549168|c|
277500|Scroll of Imbue Greater Flame|46|1302311|||4549170|c|
277501|Scroll of Imbue Greater Frost|46|1302312|||4549168|c|
277502|Scroll of Imbue Precision|46|1302310|||4549172|c|
277503|Scroll of Imbue Spellbreak|46|1295720|||4549170|c|
277504|Scroll of Wit|1|1302294|||4549173|c|
277519|Nelanna's Enchanted Jewel|60|1302223|||134131|c|
277844|Mirage Mirror|35|1302833|44|10|458243|t|
277910|Mysticbloom Seed|35|1302874|||656679|t|
278069|Potion of Tradeskill Testing - Level 60|1|1303457|||134803|c|
278117|Hard Boiled Eggs|5|434|11||132832|c|
278118|Rich Broth|25|1127|11||132804|c|
278119|Bread with Butter|1|433|11||133964|c|
278120|Fruit Platter|25|1127|11||133998|c|
278121|Smoked Sausage|15|435|11||134009|c|
278122|Carrot Salad|45|1131|11||134010|c|
278265|Nutritious Slime Sludge|1|7737|11||1500939|c|
278543|Pouch of Tomb Dust|1|1305116|24|60|133639|c|
278569|Yesterday's Leftovers|1|433|11||133972|c|
279182|Ensemble: Veteran Adventurer's Outdoor Wear|1|1306128|||7711862|c|
279258|Wild Leather Armor Kit|60|1306907|||4632799|c|
279272|SAF-T Ultra Precision Scope|60|1307050|||3610512|c|
279276|Mathystral Amulet Fragment|1|1306410|||441146|c|
279277|Mathystral Amulet|1|1306411|||133279|c|
279938|Trapper's Workbench|1|1307397|97|3600|5948139|c|
279940|Toxin Study|1|1307396|97|3600|463860|c|
279941|Tanning Rack|1|1307395|97|3600|4559256|c|
279943|Spinning Wheel|1|1307393|97|3600|4777839|c|
279944|Sharpening Wheel|1|1307392|97|3600|135243|c|
279945|Sewing Machine|1|1307391|97|3600|3622223|c|
279947|Seed Hybridizer|1|1307387|97|3600|656440|c|
279948|Rock Garden|1|1307386|97|3600|134385|c|
279949|Repair Bot|1|1307385|97|3600|1336885|c|
279950|Reagent Bot|1|1307266|97|3600|133871|c|
279951|Plague Doctor's Laboratory|1|1307265|97|3600|4626285|c|
279952|Molten Foundry|1|1307264|97|3600|5931157|c|
279955|Master Forge|1|1307261|97|3600|4374708|c|
279956|Mana Well|1|1307259|97|3600|135738|c|
279957|Cookie's Feast|1|1307257|97|3600|2066011|c|
279959|Loom|1|1307255|97|3600|2067081|c|
279960|Lodestone|1|1307254|97|3600|134419|c|
279961|Journeyman Campfire Kit|1|1307252|2511|300|7808148|c|
279962|Incense Candle|1|1307251|97|3600|133751|c|
279964|Greenhouse|1|1307248|97|3600|134188|c|
279965|Fishing Rack|1|1307247|97|3600|1053359|c|
279966|Fishing Hut|1|1307246|97|3600|132930|c|
279967|Fish Bowl|1|1307245|97|3600|4777763|c|
279968|First Aid Kit|1|1307244|97|3600|133681|c|
279969|Field Guide|1|1307243|97|3600|133735|c|
279970|Fermenter|1|1307242|97|3600|3566827|c|
279972|Faction Banner|1|1307240|97|3600|132484|c|
279973|Faction Banner|1|1307239|97|3600|132484|c|
279974|Expert Campfire Kit|1|1307237|2511|300|7808148|c|
279976|Enchanted Lute|1|1307234|97|3600|4631367|c|
279978|Camp Tent|1|1307230|97|3600|134250|c|
279979|Camp Chair|1|1307229|97|3600|132761|c|
279981|Basic Campfire Kit|1|1307227|2511|300|7808148|c|
279982|Iron Oven|1|1307226|97|3600|629055|c|
279985|Arcane Salvager|1|1307223|97|3600|986482|c|
279987|Arcane Forge|1|1307176|97|3600|3622205|c|
279988|Anvil|1|1307175|97|3600|1020356|c|
279989|Anarchist's Workbench|1|1307174|97|3600|4624728|c|
279990|Alchemy Laboratory|1|1307172|97|3600|4777830|c|
280766|Satchel of Potions|1|1309685|||133633|t|
281059|Loose Clearcutter Blade|1|1310168|24|60|134427|c|
281234|Potion of Winterspring Shrouding|1|1310655|||134776|c|
281282|A Little Somethin'|1|11629|||4639575|c|
282006|Crumbling Hearthstone|1|1312670|||1016352|c|
282011|Restored Healing Potion|1|1312698|4|120|134765|c|
282013|Restored Mana Potion|1|1312702|4|120|134797|c|
282018|Restorative Bread|1|1312719|||133950|c|
282285|Clearcutter Key|1|1313374|||134246|c|
284868|Holy Hand Grenade of Alterac|1|1317268|24|60|136173|c|
284869|Unsanctified Grenade|1|1317269|||133709|c|
286152|Plated Armorfish|35|1319311|||133890|c|
286405|Blooming Heart|1|1320093|||133940|c|
287416|Truskis' Cheesecake Slice|1|1322587|11|1|237359|c|
287647|Ensemble: Gilded Blademaster's Armor|1|1323998|||8382586|c|
287963|Roasted Quail|1|1131|11||133971|c|
287964|Morning Glory Dew|1|1137|59|1|134712|c|
287966|Minor Healing Potion|1|439|4|120|134829|c|
287967|Lesser Healing Potion|1|440|4|120|134830|c|
287968|Minor Mana Potion|1|437|4|120|134850|c|
287969|Lesser Mana Potion|1|438|4|120|134851|c|
287972|Rumsey Rum Dark|1|25722|||132791|c|
287973|Tender Wolf Steak|1|1248395|||134003|c|
287974|Grilled Squid|1|1249522|||133899|c|
287975|Swiftness Potion|1|2379|4|120|134875|c|
287976|Free Action Potion|1|6615|4|120|134715|c|
287977|Greater Healing Potion|1|2024|4|120|134832|c|
287978|Rough Sharpening Stone|1|2828|||135248|c|
287980|Elemental Sharpening Stone|1|22756|||135228|c|
288336|Blue Firework|1|11540|||135989|c|
288337|Green Firework|1|11541|||136006|c|
288338|Red Firework|1|6668|||135808|c|
288339|Red Streaks Firework|1|11542|||135815|c|
288340|Yellow Rose Firework|1|11544|||135920|c|
288896|Superior Healing Potion|1|4042|4|120|134833|c|
288897|Superior Mana Potion|1|17530|4|120|134854|c|
288898|Swiftness Potion|1|2379|4|120|134875|c|
289081|Noggenfogger Elixir|1|16589||3|134863|c|
289082|Elixir of Endless Intellect|1|1327736|2593|3|134823|c|
289083|Elixir of Endless Power|1|1327737|2593|3|134830|c|
289084|Elixir of Endless Healing|1|1327738|2593|3|134858|c|
289086|Elixir of Endless Rapidity|1|1327751|2593|3|134837|c|
289087|Elixir of Endless Opportunity|1|1327753|2593|3|134816|c|
289088|Scroll of Endless Fortitude|1|1327754|2593|3|134943|c|
289321|Elixir of Endless Mana|1|1328032|2593|3|134851|c|
289329|Elixir of Endless Growth|1|1328118|2593|3|134721|c|
289330|Scroll of Endless Speed|1|1328119|2593|3|134938|c|
289334|Elixir of Endless Experience|1|1328127|2593|3|134803|c|
289559|Enchant Boots - Speed|1|1328948|||463531|c|
]==],
enchants=[==[
id|name|spell|kind|flags
1|Rockbiter 3|8019|i|
2|Frostbrand 1|8033|i|
3|Flametongue 3|8030|i|
4|Flametongue 2|8027|i|
5|Flametongue 1|8024|i|
6|Rockbiter 2|8018|i|
7|Deadly Poison|2823|t|
8|Deadly Poison II|2824|t|
10|Poison (20 Dmg)|2826|t|i
11|Poison (25 Dmg)|2827|t|i
12|Frostbrand 2|8038|i|
13|Sharpened +3|2829|t|
14|Sharpened +4|2830|t|
19|Weighted +2|3112|t|
20|Weighted +3|3113|t|
21|Weighted +4|3114|t|
22|Crippling Poison|3408|t|
23|Mind-numbing Poison II|8693|t|
25|Shadow Oil|3594|t|
26|Frost Oil|3595|t|
28|+4 All Resistances|7439|o|
29|Rockbiter 1|8017|i|
31|Beastslaying +4|7434|o|
35|Mind Numbing Poison|5761|t|
40|Sharpened +2|2828|t|
42|Poison (Instant 20)|6650|t|
63|Lesser Absorption|7448|o|
64|Spirit +3|7451|t|
244|Intellect +4|7769|o|i
252|Spirit +6|7853|o|
253|Absorption (50)|7855|o|
257|Armor +10|7865|o|
263|Fishing Lure +25|8087|t|
264|Fishing Lure +50|8088|t|
265|Fishing Lure +75|8090|t|
266|Fishing Lure +100|8089|t|
283|Windfury 1|8232|i|
284|Windfury 2|8235|i|
323|Instant Poison|8679|t|
324|Instant Poison II|8686|t|
325|Instant Poison III|8688|t|
483|Sharpened +6|9900|t|
484|Weighted +6|9903|t|
503|Rockbiter 4|10399|i|
523|Flametongue 4|16339|i|
524|Frostbrand 3|10456|i|
525|Windfury 3|10486|i|
603|Crippling Poison II|11202|t|
623|Instant Poison IV|11338|t|
624|Instant Poison V|11339|t|
625|Instant Poison VI|11340|t|
626|Deadly Poison III|11355|t|
627|Deadly Poison IV|11356|t|
643|Mind-Numbing Poison III|11399|t|
683|Rockbiter 6|16315|i|
703|Wound Poison|13219|t|
704|Wound Poison II|13225|t|
705|Wound Poison III|13226|t|
706|Wound Poison IV|13227|t|
1643|Sharpened +8|16138|t|
1663|Rockbiter 5|16314|i|
1664|Rockbiter 7|16316|i|
1665|Flametongue 5|16341|i|
1666|Flametongue 6|16342|i|
1667|Frostbrand 4|16355|i|
1668|Frostbrand 5|16356|i|
1669|Windfury 4|16362|i|
1703|Weighted +8|16622|t|
1803|Firestone 1|758|t|
1823|Firestone 2|17945|t|
1824|Firestone 3|17947|t|
1825|Firestone 4|17949|t|
2506|Critical +2%|22756|t|
2623|Minor Wizard Oil|25117|t|
2624|Minor Mana Oil|25118|t|
2625|Lesser Mana Oil|25120|t|
2626|Lesser Wizard Oil|25119|t|
2627|Wizard Oil|25121|t|
2628|Brilliant Wizard Oil|25122|t|
2629|Brilliant Mana Oil|25123|t|
2630|Deadly Poison V|25351|t|
2684|+100 Attack Power vs Undead|28891|t|
2685|+60 Spell Damage vs Undead|28898|t|
6708|Deadly Brew|400080|t|
6709|Between the Eyes|400081|t|
6710|Just a Flesh Wound|400082|t|
6714|Rolling with the Punches|400093|t|
6715|Mutilate|400094|t|
6716|Quick Draw|400095|t|
6717|Shuriken Toss|400096|t|
6718|Blade Dance|400099|t|
6719|Shadowstep|400101|t|
6720|Shadowstrike|400105|t|
6723|Arcane Barrage|401722|t|
6725|Brain Freeze|401752|t|
6726|Advanced Warding|401754|t|
6728|Arcane Blast|401757|t|
6729|Burnout|401759|t|
6730|Ice Lance|401760|t|
6732|Frostfire Bolt|401762|t|
6733|Missile Barrage|401763|t|
6734|Overheat|401764|t|
6735|Fingers of Frost|401765|t|
6736|Regeneration|401767|t|
6737|Living Flame|401768|t|
6740|Prayer of Mending|402848|t|
6741|Shadow Word: Death|402849|t|
6742|Soul Warding|402850|t|
6744|Homunculi|402852|t|
6745|Binding Heal|402853|t|
6746|Shared Pain|402854|t|
6747|Pain Suppression|402855|t|
6749|Vampiric Touch|402857|t|
6750|Circle of Healing|402859|t|
6751|Shadowfiend|402861|o|
6752|Penance|402862|t|
6754|Eye of the Void|402864|t|
6785|Shadowstep|400104|o|
6787|Envenom|400102|t|
6788|Commanding Shout|403446|o|
6789|Enraged Regeneration|403467|t|
6790|Victory Rush|403470|t|
6792|Intervene|403472|t|
6793|Flagellation|403480|t|
6799|Blood Frenzy|403474|t|
6800|Devastate|403475|t|
6801|Furious Thunder|403476|t|
6803|Haunt|403919|t|
6805|Chaos Bolt|403925|t|
6811|Master Channeler|403932|t|
6814|Shadow Bolt Volley|403936|t|
6815|Lake of Fire|403937|t|
6816|Metamorphosis|403938|t|
6834|Focused Rage|409163|t|
6843|Beacon of Light|409999|t|
6844|Hand of Reckoning|410001|t|
6845|Crusader Strike|410002|t|
6849|Hammer of the Righteous|410013|t|
6850|Divine Storm|410014|t|
6853|Aura Mastery|410005|o|
6854|Avenger's Shield|410008|t|
6856|Hand of Sacrifice|410010|t|
6857|Inspiration Exemplar|410011|t|
6858|Wild Strikes|410021|t|
6859|Survival Instincts|410027|t|
6860|Wild Growth|410028|t|
6861|Improved Frenzied Regeneration|431461|t|
6863|Savage Roar|410023|t|
6865|Lifebloom|410033|t|
6868|Mangle|410025|t|
6870|Nourish|410059|t|
6871|Dreamstate|410060|t|
6872|Fury of Stormrage|410061|t|
6873|Fire Nova|410093|t|
6874|Dual Wield Specialization|410096|t|
6875|Water Shield|410097|t|
6876|Shield Mastery|410098|t|
6877|Ancestral Guidance|410099|t|
6878|Overload|410094|t|
6879|Maelstrom Weapon|410100|t|
6880|Earth Shield|410101|t|
6882|Spirit of the Alpha|410103|t|
6883|Lava Burst|410095|t|
6884|Lava Lash|410104|o|
6885|Riptide|410105|t|
6886|Way of Earth|410107|t|
6888|Steady Shot|410109|t|
6889|Master Marksman|410113|t|
6890|Expose Weakness|410114|t|
6892|Dual Wield Specialization|410116|t|
6895|Trap Launcher|410118|t|
6898|Kill Shot|410111|t|
6899|Chimera Shot|410121|t|
6900|Explosive Shot|410123|t|
6901|Lone Wolf|410122|t|
6911|Crimson Tempest|415918|t|
6914|Waylay|415926|t|
6919|Blunderbuss|415922|t|
6921|Spell Power|415934|t|
6922|Enlightenment|415942|t|
6923|Living Bomb|415936|t|
6927|Mass Regeneration|415939|t|
6930|Spellfrost Bolt|415948|t|
6932|Serendipity|415995|t|
6933|Pain and Suffering|415991|t|
6934|Mind Sear|415996|t|
6936|Strength of Soul|415997|t|
6941|Blood Surge|416004|t|
6943|Precise Timing|416005|t|
6946|Gladiator Stance|416002|t|
6948|Single-Minded Fury|416003|t|
6950|Everlasting Affliction|416008|t|
6952|Demonic Tactics|416009|t|
6953|Demonic Knowledge|416014|t|
6957|Dance of the Wicked|416017|t|
6960|Sacred Shield|416028|t|
6963|Guarded by the Light|416035|t|
6965|Aura Mastery|416037|t|
6966|The Art of War|416031|t|
6972|Survival of the Fittest|416042|t|
6975|Living Seed|416050|t|
6976|Sunfire|416044|t|
6977|Elune's Fires|416051|t|
6980|Power Surge|416054|t|
6982|Mental Dexterity|416055|t|
6984|Healing Rain|416057|t|
6987|Burn|416066|t|
6990|Catlike Reflexes|416083|t|
6991|Wyvern Strike|416089|t|
6992|Aspect of the Viper|416084|o|
6993|Rapid Killing|416090|t|
6994|Lock and Load|416085|t|
6995|Sniper Training|416091|t|
6996|Kill Shot|416087|o|
6998|Melee Specialist|416086|t|
6999|Raptor Fury|416093|t|
7000|Coherence|416062|t|
7011|Starsurge|424718|t|
7012|Berserk|424760|t|
7013|King of the Jungle|424765|t|
7014|Saber Slash|424984|t|
7015|Cutthroat|424988|t|
7016|Main Gauche|424990|t|
7017|Slaughter from the Shadows|424992|t|
7018|Poisoned Knife|425102|t|
7019|Master of Subtlety|425103|t|
7020|Icy Veins|425170|t|
7021|Arcane Surge|425171|t|
7022|Chronostatic Preservation|425189|t|
7024|Twisted Faith|425215|t|
7026|Empowered Renew|425309|t|
7027|Renewed Hope|425310|t|
7028|Spirit of the Redeemer|425312|t|
7029|Dispersion|425314|t|
7030|Greater Ghost Wolf|425343|t|
7031|Molten Blast|425344|t|
7033|Quick Strike|425443|t|
7034|Raging Blow|425444|t|
7035|Warbringer|425445|t|
7036|Consumed by Rage|425446|t|
7037|Frenzied Assault|425447|t|
7038|Demonic Pact|425476|t|
7039|Demonic Grace|425477|t|
7040|Hallowed Ground|425618|t|
7041|Aegis|425619|t|
7042|Rebuke|425621|t|
7043|Carve|425758|t|
7044|Cobra Strikes|425759|t|
7045|Serpent Spread|425760|t|
7046|Flanking Strike|425762|t|
7047|Decoy Totem|425882|t|
7048|Ancestral Awakening|425883|t|
7049|Malleable Protection|426175|t|
7050|Sheath of Light|426178|t|
7051|Infusion of Light|426180|t|
7053|Invocation|426443|t|
7054|Grimoire of Synergy|426445|t|
7056|Shadow and Flame|426452|t|
7057|Shadowflame|426467|t|
7058|Vengeance|426470|t|
7059|Rallying Cry|426491|t|
7065|Taste for Blood|427076|t|
7066|Vigilance|427078|t|
7067|Shield Mastery|427080|t|
7068|Rampage|427081|t|
7069|Sword and Board|427082|t|
7070|Wrecking Crew|427084|t|
7088|Fanaticism|429251|t|
7089|Wrath|429249|t|
7090|Purifying Power|429255|t|
7091|Improved Hammer of Wrath|429261|t|
7092|Improved Sanctuary|429247|t|
7093|Deep Freeze|429304|t|
7094|Temporal Anomaly|429306|t|
7095|Molten Armor|429308|t|
7096|Displacement|429309|t|
7097|Balefire Bolt|429311|t|
7098|Hit +2%|430392|t|
7099|Blackfathom Mana Oil|430585|t|
7102|Gore|431447|t|
7103|Improved Barkskin|431449|t|
7104|Gale Winds|431451|t|
7105|Efflorescence|431468|t|
7106|Eclipse|410029|t|
7107|Focus Fire|431601|t|
7108|T.N.T.|431611|t|
7109|Divine Aegis|431650|t|
7110|Mind Spike|431663|t|
7111|Surge of Light|431669|t|
7112|Despair|431673|t|
7113|Void Zone|431705|t|
7114|Pandemic|431743|t|
7115|Backdraft|431745|t|
7116|Unstable Affliction|431747|t|
7117|Summon Felguard|431756|t|
7118|Immolation Aura|431758|t|
7125|Tidal Waves|432234|t|
7126|Rolling Thunder|432236|t|
7127|Static Shock|432238|t|
7128|Overcharged|432241|t|
7129|Focused Attacks|432291|t|
7130|Combat Potency|432293|t|
7131|Honor Among Thieves|432295|t|
7132|Cut to the Chase|432297|t|
7133|Carnage|432299|t|
7134|Unfair Advantage|432301|t|
7224|Two-Handed Mastery|436368|t|
7242|Fan of Knives|436609|t|
7254|Sebacious Poison|439462|t|
7255|Numbing Poison|439464|t|
7256|Atrophic Poison|439465|t|
7257|Improved Swipe|439765|t|
7258|Tree of Life|439767|t|
7259|Starfall|439770|t|
7261|Fresh Meat|440492|t|
7262|Sudden Death|440494|t|
7263|Shockwave|440496|o|
7264|Resourcefulness|440557|t|
7265|Improved Volley|440560|t|
7266|Hit and Run|440563|t|
7267|Feral Spirit|440630|t|
7268|Storm, Earth, and Fire|440634|t|
7269|Shield of Righteousness|440788|t|
7270|Shock and Awe|440790|t|
7271|Righteous Vengeance|440792|t|
7272|Frozen Orb|440858|t|
7275|Infernal Armor|440926|t|
7327|Cleaned|446637|t|
7491|Skull Bash|416046|t|
7492|Lacerate|416049|t|
7499|Light's Grace|429242|t|
7507|Sword Specialization|453635|t|
7508|Axe Specialization|453688|t|
7509|Mace Specialization|453689|t|
7510|Dagger Specialization|453690|t|
7511|Fist Weapon Specialization|453691|t|
7512|Ranged Weapon Specialization|453692|t|
7513|Pole Weapon Specialization|453694|t|
7514|Arcane Specialization|453695|t|
7515|Fire Specialization|453696|t|
7516|Frost Specialization|453697|t|
7517|Nature Specialization|453698|t|
7518|Shadow Specialization|453700|t|
7519|Holy Specialization|453702|t|
7520|Feral Combat Specialization|453703|t|
7541|Void Plague|425216|t|
7542|Occult Poison I|458821|t|
7555|Defense Specialization|459313|t|
7560|Hot Streak|401749|t|
7561|Rewind Time|401761|t|
7562|Divine Light|410015|t|
7566|Frostbrand 5|461633|o|
7567|Flametongue 6|461634|o|
7568|Rockbiter 7|461635|o|
7569|Windfury 4|461636|o|
7588|Endless Rage|403489|t|
7589|Power Word: Barrier|425213|t|
7590|Soul Siphon|403920|t|
7591|Incinerate|416015|t|
7602|Conductive Shield Coating|463868|t|
7636|Beast Mastery|410110|t|
7637|Cobra Slayer|410115|t|
7638|Healing Specialization|468761|t|
7639|Meditation Specialization|468763|t|
7642|Mark of Chaos|440924|t|
7643|Decimation|440922|t|
7644|Magnificent Trollshine|471401|t|
7650|Enchanted Repellent|1214004|t|
7651|Occult Poison II|1214171|t|
7668|Tactician|1219740|t|
7669|War Veteran|1219742|t|
7670|Battle Forecaster|1219743|t|
7671|Bloodseeker|1219745|t|
7672|Titan|1219747|t|
7673|Destroyer|1219748|t|
7674|Deathbound|1219749|t|
7675|Sanguinist|1219751|t|
7676|Pristine Blocker|1219752|t|
7677|Savage|1219753|t|
7678|Pillar of Enmity|1219754|t|
7679|Deflective Tendencies|1219755|t|
7680|Swift Revenge|1219756|t|
7681|Incessant Attacker|1219757|t|
7682|Thunderbringer|1219758|t|
7683|Sentinel|1219760|t|
7685|Southpaw|1219762|t|
7686|Gladiator|1219763|t|
7687|Aftershock|1219764|t|
7688|Avoidant|1219766|t|
7689|Toxicologist|1219767|t|
7690|Executioner|1219768|t|
7691|Opportunist|1219769|t|
7692|Butcher|1219770|t|
7693|Phantom|1219771|t|
7694|Scoundrel|1219772|t|
7695|Thrill Seeker|1219773|t|
7696|Shiv Savant|1219774|t|
7697|Stalker|1219775|t|
7698|Efficient Striking|1219776|t|
7699|Knife Juggler|1219777|t|
7700|Shadow Master|1219778|t|
7701|Equilibrist|1219779|t|
7702|Poised Brawler|1219780|t|
7703|Black Belt|1219781|t|
7704|Fencer|1219782|t|
7705|Swashbuckler|1219783|t|
7706|Bloodthirsty|1219784|t|
7707|Transfusionist|1219785|t|
7708|Refined Spells|1219786|t|
7709|Decimator|1219787|t|
7710|Rotbringer|1219788|t|
7711|Malevolent|1219789|t|
7712|Shadowmancer|1219790|t|
7713|Chaos Harbinger|1219791|t|
7714|Arsonist|1219792|t|
7715|Infernal Shepherd|1219793|t|
7716|Demonlord|1219794|t|
7717|Demonic Exorcist|1219795|t|
7718|Pain Siphon|1219796|t|
7719|Flamewraith|1219797|t|
7720|Fleshfeaster|1219798|t|
7721|Abyssal Essence|1219799|t|
7722|Voidborne|1219800|t|
7723|Umbral Blade|1219801|t|
7724|Ritualist|1219802|t|
7725|Pain Spreader|1219803|t|
7726|Misleader|1219804|t|
7727|Preyseeker|1219805|t|
7728|Sharpshooter|1219806|t|
7729|Hazard Harrier|1219807|t|
7730|Alternator|1219808|t|
7731|Toxinologist|1219809|t|
7732|Bounty Hunter|1219810|t|
7733|Trick Shooter|1219811|t|
7734|Beast Tender|1219812|t|
7735|Hound Master|1219813|t|
7736|Alpha Tamer|1219815|t|
7737|Huntsman|1219816|t|
7739|Retaliator|1219818|t|
7740|Echoing Strikes|1219819|t|
7741|Lethal Lasher|1219820|t|
7742|Kineticist|1219821|t|
7743|Strategist|1219822|t|
7744|Deadly Striker|1219823|t|
7745|Hastened Healer|1219824|t|
7746|Refined Spells|1219825|t|
7747|Celebrant|1219826|t|
7748|Faithful|1219827|t|
7749|Serendipitous|1219828|t|
7750|Resonant|1219829|t|
7751|Devotee|1219830|t|
7752|Archbishop|1219831|t|
7753|Penitent|1219832|t|
7754|Soul Warder|1219833|t|
7755|Twilight Walker|1219834|t|
7756|Mind Breaker|1219835|t|
7757|Deathdealer|1219836|t|
7758|Spirit Font|1219837|t|
7759|Zealot|1219838|t|
7760|Unwavering Defiler|1219839|t|
7761|Contemnor|1219840|t|
7762|Plaguebringer|1219841|t|
7763|Reverberant|1219842|t|
7764|Chronohealer|1219843|t|
7765|Temporal Longing|1219844|t|
7766|Precognition|1219845|t|
7767|Arcanist|1219846|t|
7768|Eternal Caretaker|1219847|t|
7769|Spellbider|1219848|t|
7770|Wardshaper|1219849|t|
7771|Winter's Grasp|1219850|t|
7772|Cryomancer|1219851|t|
7773|Evoker|1219852|t|
7774|Elementalist|1219853|t|
7775|Magical Armaments|1219854|t|
7776|Kindler|1219855|t|
7777|Fiery Convergence|1219856|t|
7778|Perpetual Blaze|1219857|t|
7779|Pyromaniac|1219858|t|
7780|Igniter|1219859|t|
7781|Agonizing Torcher|1219860|t|
7782|Pristine Blocker|1219861|t|
7783|Lightwarden|1219862|t|
7784|Radiant Defender|1219863|t|
7785|Shieldbearer|1219864|t|
7786|Bastion|1219865|t|
7787|Reckoner|1219866|t|
7788|Ironclad|1219867|t|
7789|Guardian|1219868|t|
7790|Peacekeeper|1219869|t|
7791|Refined Spells|1219870|t|
7792|Exemplar|1219871|t|
7793|Inquisitor|1219872|t|
7794|Sovereign|1219873|t|
7795|Dominus|1219874|t|
7796|Vindicator|1219875|t|
7797|Altruist|1219876|t|
7798|Arbiter|1219877|t|
7799|Sealbearer|1219878|t|
7800|Justicar|1219879|t|
7801|Judicator|1219880|t|
7802|Ascendant|1219881|t|
7803|Retributor|1219882|t|
7804|Excommunicator|1219883|t|
7805|Lightbringer|1219884|t|
7806|Exile|1219885|t|
7807|Templar|1219886|t|
7808|Windwalker|1219887|t|
7809|Shield Master|1219888|t|
7810|Totemic Protector|1219889|t|
7811|Shock-Absorber|1219890|t|
7812|Spiritual Bulwark|1219891|t|
7813|Maelstrombringer|1219892|t|
7814|Lavawalker|1219893|t|
7815|True Alpha|1219894|t|
7816|Totemkeeper|1219895|t|
7817|Ancestral Invigoration|1219896|t|
7818|Spiritweaver|1219897|t|
7819|Waterwalker|1219898|t|
7820|Stormtender|1219899|t|
7821|Elemental Seer|1219900|t|
7822|Vitalist|1219901|t|
7823|Spirithealer|1219902|t|
7824|Refined Spells|1219903|t|
7825|Chieftain|1219904|t|
7826|Furycharged|1219905|t|
7827|Stormbreaker|1219906|t|
7828|Tempest|1219907|t|
7829|Seismic Smasher|1219908|t|
7830|Flamebringer|1219909|t|
7831|Volcano|1219910|t|
7832|Raging Flame|1219911|t|
7833|Elemental Master|1219912|t|
7834|Tribesman|1219913|t|
7835|Spirit Guide|1219914|t|
7836|Elder|1219915|t|
7837|Heir of the Elements|1219916|t|
7838|Lava Sage|1219917|t|
7839|Ancestral Warden|1219918|t|
7840|Power Corrupt|1219919|t|
7841|Gentle Paw|1219920|t|
7842|Ferocious Focus|1219921|t|
7843|Paw and Claw|1219922|t|
7844|Territorial|1219923|t|
7845|Beastly|1219924|t|
7846|Lacerator|1219925|t|
7847|Furious|1219926|t|
7848|Mangler|1219927|t|
7849|Innervator|1219928|t|
7850|Nurturer|1219929|t|
7851|Tranquil|1219930|t|
7852|Dreamwalker|1219931|t|
7853|Grove Tender|1219932|t|
7854|Feathered Sage|1219933|t|
7855|Benevolent Seer|1219934|t|
7856|Lifeweaver|1219935|t|
7857|Illuminator|1219936|t|
7858|Predatory Instincts|1219937|t|
7859|Rip and Tear|1219938|t|
7860|Mercy of the Claw|1219939|t|
7861|Prideful|1219940|t|
7862|Barbaric|1219941|t|
7863|Frenetic|1219942|t|
7864|Exsanguinator|1219943|t|
7865|Thornkeeper|1219944|t|
7866|Lunatic|1219945|t|
7867|Starcaller|1219946|t|
7868|Night|1219947|t|
7869|Keeper of the Grove|1219948|t|
7870|Wrathful|1219949|t|
7871|Graceful|1219950|t|
7872|Astral Ascendant|1219951|t|
7873|Cometcaller|1219952|t|
7874|Wrath of the Forest|1219953|t|
7875|Animalistic Expertise|1219954|t|
7896|+200 Attack Power vs Undead|1223689|t|
8059|Spellstone 1|1237152|t|
8060|Spellstone 2|1237156|t|
8061|Spellstone 3|1237159|t|
8696|Tyler Test Imbue|1295197|o|i
8698|Chillknife|1296225|t|
8700|Lesser Flame|1295720|t|
8706|Baleflame|1302219|t|
8707|Spark|1302227|t|
8708|Striking|1302217|t|
8709|Frost|1302283|t|
8710|Iceknife|1302284|t|
8711|Accuracy|1302306|t|
8712|Quickening|1302307|t|
8713|Flame|1302304|t|
8714|Balefrost|1302305|t|
8715|Manablade|1302308|t|
8716|Greater Flame|1302311|t|
8717|Greater Frost|1302312|t|
8718|Precision|1302310|t|
]==],
}
