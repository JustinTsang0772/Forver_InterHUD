


local a,b=...
local a=b.Schema



a.SCALE={min=0.25,max=4,step=0.05}
local function g()
return{name="scale",type="number",default=1,min=a.SCALE.min,max=a.SCALE.max,
step=a.SCALE.step,unit="x",label="Scale"}
end
a.MAX_SPELLS=20





a.SPELL_ENTRY="spellEntry"
a.record(a.SPELL_ENTRY,{fields={
{name="id",type="spell",required=true,label="Spell"},
{name="name",type="string",max=64,exportOnly=true,label="Name"},
{name="exact",type="boolean",label="Exact"},
{name="matches",type="list",of="integer",exportOnly=true,label="Matches"},
}})


a.record("position",{fields={
{name="point",type="point",default="CENTER",label="Anchor"},
{name="x",type="number",default=0,min=-4000,max=4000,step=0.5,control="edit",
label="X"},
{name="y",type="number",default=0,min=-4000,max=4000,step=0.5,control="edit",
label="Y"},
}})



local function d(c,a)
local c=c.element
for d,b in ipairs(a~=nil and b.Layers.layersOf(c)or{})do
if b.id==a then return b,c end
end
end
local function c(c,e)
local c,d=d(c,e)
if not c then return{}end
return b.Layers.pieces(c,type(d.baseSize)=="number"and d.baseSize or a.field("element","baseSize").default)
end

local function h(b,a)return not(a and(a.kind=="text"or a.kind=="bar"))end

local e="Empty: the element's Base size."
a.EMPTY_SIZE=e
a.record("layerPosition",{
context=function(a,b)b.placedAgainst=type(a)=="table"and a.to or nil end,

after={"point"},
fields={

{name="to",type="id",ref="layer",control="choice",resets={"piece"},label="Anchor to",
noneLabel="The element",
choicesFrom=function(c,a)
local d,e=b.Layers.layersOf(a.element),{}
local c
for d,b in ipairs(d)do
if b==a.layer or(b.id~=nil and a.layer and b.id==a.layer.id)then c=d end
end
local f=c and b.Layers.anchoredTo(d,c)or{}
for a,b in ipairs(d)do
if a~=c and not f[a]and b.id~=nil then e[#e+1]=b.id end
end
return e
end,
labelsFrom=function(a)
local c,d=b.Layers.layersOf(a.element),{}
for e,a in ipairs(c)do
if a.id~=nil then d[a.id]=b.Layers.nameOf(c,a)end
end
return d
end},
{name="piece",type="integer",min=1,control="choice",label="Picture",noneLabel="The whole layer",
choicesFrom=function(a,b)
local a=#c(b,a.to)
local b={}
for a=1,a>1 and a or 0 do b[a]=a end
return b
end,
labelsFrom=function(a)
local b={}
for a,c in ipairs(c(a,a.placedAgainst))do b[a]=c.label end
return b
end},
{name="toPoint",type="point",defaultFrom=function(a)return a.point or"CENTER"end,
label="To the element's",
labelFrom=function(a)return a.placedAgainst~=nil and"At its"or"To the element's"end},

{name="point",type="point",default="CENTER",label="Anchor direction"},
{name="x",type="number",default=0,min=-1000,max=1000,step=0.5,control="edit",label="X"},
{name="y",type="number",default=0,min=-1000,max=1000,step=0.5,control="edit",label="Y"},
}})




local c,d={},{}
for b,a in ipairs(a.STYLE_PARTS)do
c[#c+1]={name=a,type="record",record="style:"..a,style=a}
d[#d+1]={name=a,type="record",record="style:"..a,style=a,
inherit="global"}
end
a.record("styles",{refusable=true,fields=c,
context=function(b,a)a.ownStyle=false end})


a.record("buttonCues",{refusable=true})

a.record("ownStyles",{fields=d,context=function(b,a)a.ownStyle=true end})








a.PRESETS_MAX=50
local c={}
for d,b in ipairs(a.STYLE_PARTS)do
a.record("stylePreset:"..b,{unit=true,refusable=true,
context=function(b,a)a.ownStyle=false end,fields={
{name="id",type="id",required=true,label="Id"},
{name="name",type="string",max=48,required=true,label="Name"},
{name="style",type="record",record="style:"..b,label="Style"},
}})

a.rule("stylePreset:"..b,"name",function(a,c,b)
a.name=strtrim(a.name)
if a.name==""then c:problem((b==""and""or b..".").."name","is empty; give it a name.")end
end)
c[#c+1]={name=b,type="list",record="stylePreset:"..b,
maxItems=a.PRESETS_MAX}
end
a.record("stylePresets",{refusable=true,fields=c})


a.rule("stylePresets","unique",function(h,d)
local c=d.unit
for c,f in ipairs(a.STYLE_PARTS)do
local i=b.Styles.spec(f).label
local c,j,g=h[f],{},{}
local e=1
while type(c)=="table"and e<=#c do
local b=c[e]
d.unit=b.id
if j[b.id]then
d:dropItem("","repeats the id of another "..i.." preset; refused.")
table.remove(c,e)
else
j[b.id]=true
if g[b.name:lower()]then
local a=a.numberedName(b.name,a.field("stylePreset:"..f,"name").max,
function(a)return g[a:lower()]end)
d:note("name",string.format("%q is another %s preset's name; named %q.",b.name,i,a))
b.name=a
end
g[b.name:lower()]=true
e=e+1
end
end
if type(c)=="table"and#c==0 then h[f]=nil end
end
d.unit=c
end)


a.gameFact("inCombat",{label="In combat",holds="you're in combat"})
a.gameFact("hostileTarget",{label="Hostile target",holds="your target is one you can attack"})
a.gameFact("inGroup",{label="In a group",holds="you're in a party or raid"})
a.gameFact("inRaid",{label="In a raid",holds="you're in a raid"})
a.gameFact("targetCasting",{label="Target casting",holds="your target casts or channels, interruptible or not"})



local function c(a,b,c,d)
local a={name=a,type="keys",minItems=1,maxItems=c or 8,failsRecord=true,label=b}
for b,c in pairs(d or{})do a[b]=c end
return a
end



local d
local function f()
if d then return d end
d={}
for e,c in ipairs(a.sourceKeys())do
local a=a.source(c)
local e=a.unit and(", with \"unit\": \""..a.unit.."\"")or""
local e=(a.noun or"it").." is \"kind\": \""..a.kind.."\""..e.."."
local b=b.Sources.get(a.kind)
local b=b and b.idWord
if type(b)=="function"then b=b({kind=a.kind,unit=a.unit})end
for c,b in ipairs({c,b})do
if b~=a.kind and d[b]==nil then
d[b]="\""..b.."\" isn't a kind: "..e
end
end
end
return d
end




a.record("source",{
fields={
{name="id",type="id",label="Id"},
{name="kind",type="choice",required=true,label="Kind",
choicesFrom=function()return a.variantKeys("source"),f()end},

{name="name",type="string",max=48,label="Name"},
{name="enabled",type="boolean",default=true,label="On"},
},
idSpace="element",
madeId=function(c)
local a=b.Sources.get(c.kind)
local a=a and a.idWord
if type(a)=="function"then a=a(c)end
return a or c.kind
end,
after={"kind","unit"},
variantOf=function(a)return a.kind end,
retired={
requires="is no longer a setting; left out.",
dimsWithMain="is now a look keyed on that source's state (\"while\": \"spell.coolingDown\", \"opacity\": 50);"
.." left out.",
states="are now looks on its layers, keyed on its states; left out.",
spell="is now spells, a list; left out.",
shows="is now shownSpell; left out.",
stackRanges="are now facts.stacks, a list of atLeast, atMost or between; left out.",
counts="is now spells; left out.",
item="is now items; left out.",
},
context=function(b,c)a.sourceVars(b,c)end,
})



a.record("fact",{
fields={
{name="enabled",type="boolean",default=true,label="On"},
{name="events",type="record",record="changeEvents",label="Events"},
},
context=function(c,b,a)b.fact=a and a.fact end,
})



a.record("event",{
fields={{name="effects",type="list",record="effect",maxItems=16,label="Effects"}},
context=function(c,b,a)b.event=a and a.event end,
})

local d={word="enters",label="Enters",holds="it starts holding"}
local f={word="leaves",label="Leaves",holds="it stops holding"}
a.record("changeEvents",{
fields={
{name="enters",type="record",record="event",event=d,label=d.label},
{name="leaves",type="record",record="event",event=f,label=f.label},
},
context=function(b,a)a.moment="plain"end,
})
a.CHANGE_EVENTS={enters=d,leaves=f}



local function i(a)
local b=b.Layers.effect(a)
return"a "..(b and b.label or a):lower()
end

local j=setmetatable({},{__mode="k"})
local function f(h,d)
local c,f=d.event,d.spec
if type(c)~="table"or(#h==0 and not c.later)then return nil end
local g=j[c]or setmetatable({},{__mode="k"})
j[c]=g
local e=g[f or c]or{}
g[f or c]=e
local g=d.moment or"plain"
if e[g]then return e[g]end
local j=a.subjectOf(f)




local k=d.moment=="engine"and", as the game shows it itself in combat."or"."
local l=c.holds and("when "..c.holds)or("at "..tostring(c.label))
local d={}
for a,b in ipairs(h)do d[a]=i(b)end
local f={}
local b=#d>0 and(" It can play "..b.Clean.orList(d)..".")or""
for d,a in ipairs(a.variantKeys("effect"))do
local c=c.later and c.later[a]
f[a]=j.." can't play "..i(a).." "..l..(c and" yet."or k)
..b
end
e[g]=f
return f
end



local function d(b,c)
local b,d=c.event,type(b)=="table"and b.kind
if not(type(b)=="table"and b.later and type(d)=="string"and b.later[d])then return nil end
if a.effectAllowed(b,d,c.moment)then return nil end
local a=a.variantKeys("effect",function(e,d)return a.effectAllowed(b,d,c.moment)end)
return f(a,c)[d]
end



a.record("effect",{
fields={
{name="id",type="id",label="Id"},
{name="kind",type="choice",required=true,label="Effect",
choicesFrom=function(c,b)
local a=a.variantKeys("effect",function(d,c)
return a.effectAllowed(b.event,c,b.moment)
end)
return a,f(a,b)
end},
{name="enabled",type="boolean",default=true,label="On"},
c("while","While"),
c("unless","Unless"),
},
idSpace="element",
madeId=function(a)return a.kind end,
after={"kind"},
variantOf=function(a)return a.kind end,
leftOut=d,
retired={
source="is said by where the effect sits: under its source's events; left out.",
state="is said by where the effect sits: under a custom state's events; left out.",
when="is said by where the effect sits: under that event; left out.",
requires="is no longer a setting; left out.",
["if"]="is now while and unless; left out.",
on="is now over; left out.",
},
context=function(b,a)a.ownStyle=true end,
})



function a.overField()
return{name="over",type="list",of="id",unique=true,minItems=1,maxItems=32,ref="layer",
label="Over"}
end



a.record("layer",{
retired={
source="is said by where the layer sits: under that source's layers; left out.",
requires="is no longer a setting; left out.",
states="are now looks, a list each with while and unless; left out.",
when="is no longer a setting; left out.",

buttonCues="is now each cue's own On (outOfRange, notEnoughPower, notUsable and pressed, each with enabled);",
},


moves={buttonCues=function(a,d,g)
if type(a)~="table"then return false end
local e=false
for c,h in pairs(a)do
local f=b.Sources.FACTS[c]
local a=d[c]
if h==false and f and f.look and g[c]and(a==nil or type(a)=="table")then
a=b.copy(a or{})
a.enabled=false
d[c]=a
e=true
end
end
return e
end},
fields={
{name="id",type="id",label="Id"},
{name="kind",type="choice",required=true,label="Layer",
choicesFrom=function(c,b)
local b=b.kind
return a.variantKeys("layer",function(a)return b==nil or a.serves[b]end)
end},


{name="name",type="string",max=48,label="Name"},
{name="enabled",type="boolean",default=true,label="On"},

{name="shown",type="boolean",default=true,label="Shown"},

{name="opacity",type="percent",default=100,label="Opacity"},


{name="width",type="number",min=1,max=1024,softMax=300,step=0.5,label="Width",
help=e,shownIf=h},
{name="height",type="number",min=1,max=1024,softMax=100,step=0.5,label="Height",
help=e,shownIf=h},
{name="position",type="record",record="layerPosition",label="Place"},
},
idSpace="element",
madeId=function(a)return a.kind end,
after={"kind"},
variantOf=function(a)return a.kind end,
context=function(b,a)
a.ownStyle=true
a.layer=b
end,
})


local d={width=true,height=true,length=true,thickness=true,position=true,segments=true,
size=true}
function a.notByLook(a)
if d[a]then return"doesn't change by look; set it on the layer."end
end





a.record("hold",{fields={

{name="after",type="string",max=64,required=true,ref="event",label="After"},
{name="seconds",type="number",min=0.5,max=60,step=0.5,unit="s",required=true,label="For"},
}})
a.record("customState",{
fields={
{name="id",type="id",label="Id"},
{name="name",type="string",max=48,label="Name"},
{name="enabled",type="boolean",default=true,label="On"},
c("all","All of these",16),
c("any","Any of these",16),
c("none","None of these",16),

{name="hold",type="record",record="hold",failsRecord=true,label="Hold"},
{name="events",type="record",record="changeEvents",label="Events"},
},
idSpace="element",
madeId=function()return"customState"end,
})

a.rule("customState","terms",function(a,b,c)
if a.all==nil and a.any==nil and a.none==nil and a.hold==nil then
b:problem(c,"has no terms; give it all, any, none or a hold.")
end
end)

















a.record("quickWrite",{fields={
{name="part",type="string",max=65,ref="part",label="Part"},
{name="look",type="string",max=32,label="Look"},
{name="field",type="string",max=32,label="Field"},
{name="value",type="scalar",label="Value"},
{name="clear",type="boolean",label="Clear"},
}})
a.record("quickChoice",{fields={
{name="label",type="string",max=64,label="Label"},
{name="writes",type="list",record="quickWrite",maxItems=16,label="Writes"},
}})
a.QUICK_MAX=32



a.record("quickTarget",{fields={
{name="part",type="string",max=65,ref="part",label="Part"},
{name="look",type="string",max=32,label="Look"},
{name="field",type="string",max=32,label="Field"},
}})
a.record("quickSetting",{fields={
{name="section",type="string",max=64,label="Section"},
{name="label",type="string",max=80,label="Label"},
{name="help",type="string",max=120,label="Help"},
{name="part",type="string",max=65,ref="part",label="Part"},
{name="look",type="string",max=32,label="Look"},
{name="field",type="string",max=32,label="Field"},
{name="also",type="list",record="quickTarget",maxItems=16,label="Also"},
{name="choices",type="list",record="quickChoice",maxItems=8,label="Choices"},
{name="rows",type="list",record="quickSetting",maxItems=a.QUICK_MAX,label="Rows"},
}})




a.record("origin",{fields={
{name="kind",type="choice",choices={"premade","blueprint"},required=true,label="From"},
{name="id",type="id",required=true,label="Id"},
{name="name",type="string",max=64,label="Name"},
}})





local d={"while","unless","otherwise"}
local function e(a)
return{
c("while","While",8,{minItems=0,keepEmpty=true,inherit=a,failsRecord=false,
failsWith=d}),
c("unless","Unless",8,{inherit=a,failsRecord=false,failsWith=d}),
{name="otherwise",type="percent",default=0,inherit=a,label="Otherwise",
tip="The opacity while While and Unless don't hold; 0 hides it."},
}
end
a.SHOWING=d

a.SHOWING_ALL={"while","unless","otherwise","opacity"}




local f={
kind="is no longer a setting: an element holding a spellAlert layer is a Spell Alert; left out.",
source="is now the first of sources; left out.",
modifiers="are now looks keyed on facts and custom states; left out.",
layers="now sit under the source whose value they draw (sources[n].layers); left out.",
effects="now sit under the event they play at (sources[n].events); left out.",
whenItShows="is now while and unless; left out.",
otherwiseOpacity="is now otherwise; left out.",
holdEffects="is no longer a setting (Global's While dead or on a flight path decides); left out.",
showNotLearned="is now the profile's Ignore \"Only while you know\"; left out.",
styles="is no longer a setting (each part takes its own style, a preset or Global's); left out.",
states="are now looks on its layers; left out.",
events="now sit on their source (sources[n].events); left out.",
}


local function d(a)
local a=type(a.name)=="string"and a.name:lower():gsub("[^%w]+","-"):gsub("^%-+",""):gsub("%-+$","")
:sub(1,32)or""
return"is missing; give it an id: 1 to 32 letters, digits or dashes, as \""..(a~=""and a or"my-element")
.."\"."
end
local c={
{name="id",type="id",required=true,missing=d,label="Id"},
{name="name",type="string",max=64,label="Name"},


{name="menuIcon",type="integer",min=1,control="fileId",label="Menu icon",
help="Its picture in the options window's list. When empty, it uses the picture of its first source."},
{name="enabled",type="boolean",default=true,label="On"},



{name="baseSize",type="number",default=40,min=8,max=400,step=0.5,label="Base size",
help="Layers with no size of their own are this size. Groups can use this value in some arrangement options."},


g(),

{name="position",type="record",record="position",label="Place",
shownIf=function(a)return a.groupArrangement==nil or a.groupArrangement=="free"end},
}
for b,a in ipairs(e("group"))do c[#c+1]=a end


c[#c+1]={name="opacity",type="percent",default=100,inherit="group",
label="Opacity"}


c[#c+1]={name="onlyWhileYouKnow",type="spells",minItems=1,
maxItems=a.MAX_SPELLS,unique=true,control="spells",label="Only while you know",
help="Hidden until you know one of these."}
c[#c+1]={name="sources",type="list",record="source",maxItems=16,
label="Sources"}
c[#c+1]={name="customStates",type="list",record="customState",maxItems=50,
label="Custom states"}
c[#c+1]={name="quick",type="list",record="quickSetting",maxItems=a.QUICK_MAX,
label="Quick settings"}

c[#c+1]={name="origin",type="record",record="origin",label="Made from",
shownIf=function()return false end}
a.record("element",{
unit=true,refusable=true,retired=f,fields=c,
context=function(a,b)b.element=a end,
})



a.rule("element","menuIcon",function(c,a,d)
if c.menuIcon==nil or not a:strict()then return end
local e=a.vars.before
if a.mode=="edit"and type(e)=="table"and e.menuIcon==c.menuIcon then return end
if b.Media.knownFile(c.menuIcon)then return end
local b,d=(d==""and""or d..".").."menuIcon","is "..c.menuIcon
..", a file this game doesn't have"
if a.mode=="edit"then return a:problem(b,d..".")end
a:note(b,d.."; left out.")
c.menuIcon=nil
end)



local b={
{name="id",type="id",required=true,missing=d,label="Id"},
{name="name",type="string",max=64,label="Name"},


{name="enabled",type="boolean",default=true,label="On"},

{name="opacity",type="percent",default=100,label="Opacity"},
}
for c,a in ipairs(e(nil))do b[#b+1]=a end
for c,a in ipairs({
{name="arrangement",type="choice",choices={"row","column","grid","free"},default="row",
labels={row="Row",column="Column",grid="Grid",free="Free"},label="Arrangement"},
{name="columns",type="integer",default=4,min=1,max=40,under={"arrangement","grid"},
label="Columns"},
{name="spacing",type="number",default=4,min=0,max=100,step=0.5,label="Spacing"},

{name="growFrom",type="choice",choices={"centre","start","end"},default="centre",
labels={centre="Centre",start="Start",["end"]="End"},under={"arrangement",{"row","column"}},
label="Grow from"},


{name="lineUpBy",type="choice",choices={"baseSize","element"},default="baseSize",
labels={baseSize="Base size",element="Whole element"},
under={"arrangement",{"row","column","grid"}},
label="Line up by",help="What the \"Align\" option measures each element by. \"Base size\" uses each"
.." element's \"Base size\" square. This exists so a Group of icons, some of which may have layers outside"
.." their primary icon (e.g. a bar or small icons beside the main icon), can be aligned neatly."},
{name="align",type="choice",choices={"start","centre","end"},default="centre",
labels={start="Top or left",centre="Centre",["end"]="Bottom or right"},
under={"arrangement",{"row","column","grid"}},label="Align"},

{name="keepSlots",type="boolean",default=false,under={"arrangement",{"row","column","grid"}},
label="Keep empty slots"},
g(),
{name="position",type="record",record="position",label="Place"},
{name="members",type="list",of="id",unique=true,maxItems=200,default={},label="Members"},

{name="origin",type="record",record="origin",label="Made from",shownIf=function()return false end},
})do b[#b+1]=a end
a.record("group",{
unit=true,refusable=true,fields=b,
retired={
layout="is now arrangement; left out.",
whenItShows="is now while and unless; left out.",
otherwiseOpacity="is now otherwise; left out.",
},
})









a.record("specials",{refusable=true,unknownLeftOut=true,
unknown=function()return"isn't a special this InterHUD has; left out."end})





a.record("profileSettings",{fields={
{name="soundChannel",type="choice",choices={"Master","SFX","Music","Ambience","Dialog"},
default="Master",labels={Master="Master",SFX="Effects",Music="Music",Ambience="Ambience",
Dialog="Dialog"},label="Sound channel"},
{name="cantAct",type="choice",choices={"usual","grey","hide"},default="usual",
labels={usual="HUD behaves as normal",grey="HUD is greyed out",hide="HUD is hidden"},
label="While dead or on a flight path"},
{name="fadeTime",type="number",default=0.2,min=0,max=1,step=0.1,unit="s",label="Fade time"},




{name="showUnlearned",type="boolean",default=false,label='Ignore "Only while you know"',
help="Turns off every element's \"Only while you know\" setting, so an element shows even when you don't"
.." know the spell it needs. Use it to check an element that stays hidden when it shouldn't."},


{name="spellIdTooltips",type="boolean",default=false,label="Spell IDs on tooltips"},

{name="hideCastBar",type="boolean",default=false,label="Hide Blizzard's cast bar"},
}})





a.record("profile",{
after={"presets","buttonCues"},
context=function(a,b)b.presets,b.buttonCues=a.presets or false,a.buttonCues or false end,
retired={modifierLooks="is now buttonCues; left out.",factLooks="is now buttonCues; left out."},
fields={
{name="name",type="string",max=48,exportOnly=true,label="Name"},
{name="settings",type="record",record="profileSettings",label="Settings"},
{name="styles",type="record",record="styles",label="Global styles"},
{name="buttonCues",type="record",record="buttonCues",label="Button cues"},
{name="presets",type="record",record="stylePresets",label="Style presets"},
{name="groups",type="list",record="group",maxItems=100,default={},label="Groups"},
{name="elements",type="list",record="element",maxItems=500,default={},label="Elements"},
{name="specials",type="record",record="specials"},
},
})


a.rule("profile","ids",function(c,f)
local d={}
for a,e in ipairs({"elements","groups"})do
local b=c[e]or{}
local a=1
while a<=#b do
local c=b[a].id
if d[c]then
f:dropItem(c,"repeats an id already used; refused.")
table.remove(b,a)
else
d[c]=true
a=a+1
end
end
if#b==0 then c[e]=nil end
end
end)



a.rule("profile","members",function(c,b)
local g={}
for b,a in ipairs(c.elements or{})do g[a.id]=a end
local h={}
for c,f in ipairs(c.groups or{})do
local e=f.members or{}
local d=1

local c=b.unit
b.unit=f.id
while d<=#e do
local c=e[d]
if not g[c]then
b:note("","member \""..c.."\" names no element; left out.")
table.remove(e,d)
elseif a.alertFlag(g[c],"loose")then
b:note("","member \""..c.."\" is a Spell Alert, which is never in a group; left out.")
if not b:strict()then b.dropped=b.dropped+1 end
table.remove(e,d)
elseif h[c]then
b:note("","member \""..c.."\" is in group \""..h[c].."\" already; left out.")
table.remove(e,d)
else
h[c]=f.id
if(f.arrangement or"row")~="free"then g[c].position=nil end
d=d+1
end
end
b.unit=c
if#e==0 then f.members=nil end
end
end)


a.record("windowPlace",{fields={
{name="x",type="number",min=-4000,max=4000,step=0.5,required=true},
{name="y",type="number",min=-4000,max=4000,step=0.5,required=true},
{name="width",type="number",min=400,max=4000,step=0.5,required=true},
{name="height",type="number",min=300,max=4000,step=0.5,required=true},
}})



a.record("minimapButton",{fields={
{name="hidden",type="boolean",default=false,label="Hide the minimap button"},
{name="angle",type="number",default=195,min=0,max=360,step=0.1,label="Place"},
}})



a.record("uiState",{
retired={collectionsDismissed="is no longer read; left out."},
fields={
{name="grid",type="boolean",default=true,label="Snap to grid"},
{name="gridSize",type="number",default=32,min=8,max=128,step=4,label="Grid size"},
{name="snap",type="boolean",default=true,label="Snap to groups and elements"},
{name="gridHidden",type="boolean",default=false,label="Hide grid"},

{name="previewUnlearned",type="boolean",default=false,label="Show unlearned"},

{name="previewAlerts",type="boolean",default=true,label="Spell Alerts"},


{name="showDrafts",type="boolean",default=false,label="Show drafts"},
{name="window",type="record",record="windowPlace"},



{name="windowScale",type="number",default=1,min=0.8,max=1.3,step=0.01,label="Menu scale"},

{name="listWidth",type="integer",default=220,min=180,max=360,label="List width"},

{name="contentsWidth",type="integer",default=265,min=200,max=400,label="Contents width"},
{name="folded",type="list",of="string",item={max=64},unique=true,maxItems=500},

{name="letterDismissed",type="string",max=64},


{name="notesDismissed",type="map",record="noteDismissed"},

{name="roadmapSeen",type="list",of="string",item={max=48},unique=true,maxItems=300},

{name="roadmapVersion",type="string",max=32},

{name="roadmapSaid",type="string",max=32},
{name="minimap",type="record",record="minimapButton"},
}})


a.record("noteDismissed",{fields={
{name="rev",type="integer",min=1,max=9999},
}})


a.record("lastSeen",{fields={
{name="key",type="string",required=true,max=200},
{name="spell",type="spell",required=true},
}})



a.record("character",{fields={
{name="profiles",type="list",of="string",item={max=48},maxItems=2},

{name="off",type="boolean",default=false},
{name="lastSeen",type="list",record="lastSeen",maxItems=200},
}})




a.record("caches",{fields={}})


a.record("envelope",{fields={
{name="kind",type="choice",choices={"elements","profile"},required=true},
{name="class",type="string",max=32},
{name="locale",type="string",max=8},
{name="name",type="string",max=64},
{name="description",type="string",max=500},
{name="styles",type="record",record="styles"},
{name="presets",type="record",record="stylePresets"},
{name="groups",type="list",record="group",maxItems=100},
{name="elements",type="list",record="element",maxItems=500},
{name="profile",type="record",record="profile"},
{name="interhud",type="integer",min=1,required=true},
}})
