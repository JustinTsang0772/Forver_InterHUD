



local a,c=...
local d=c.Clean
local e=c.Schema
local i=c.Resolve
local r=c.Events
local w=c.Combat
local h=c.Migrate

local a={}
c.Store=a





a.VERSION=9

local b
local g
local t
local m
local k=1


function a.ready()
return b~=nil and g~=nil
end


local f=e.field("profile","name").max
local function q(a)
if type(a)~="string"then return nil end
local a=d.cleanValue(e.field("profile","name"),strtrim(a),d.newCtx("load"),"name")
if a==d.FAIL or a==nil then return nil end
a=strtrim(a)
if a==""then return nil end
return a
end


local function j(b,a)
if#b<=a then return b end
local a=a
while a>0 and b:byte(a+1)>=128 and b:byte(a+1)<192 do a=a-1 end
return b:sub(1,a)
end



local function n(a)
if not b.profiles[a]then return a end
local c=2
while true do
local d=" "..c
local a=strtrim(j(a,f-#d))..d
if not b.profiles[a]then return a end
c=c+1
end
end



local function u(a,d)
local c=strtrim(j(a,f))
if not b.profiles[c]then return c end
return n(strtrim(j(a.." - "..d,f)))
end



function a.freeName(b)
b=a.ready()and q(b)
return b and n(b)or nil
end


local o=false


local f



local function l(a)
if type(a.interhud)=="number"then return a.interhud<h.OLDEST or a.interhud%1~=0 end
return type(a.profiles)=="table"and next(a.profiles)~=nil
end



local function j(b,g,d,e)
local a={}
for f,b in ipairs(b)do
local g,c,h=c.try("format step",h.element,b,g)
if g then
a[f]=c
if d then d(c,h)end
else
a[f]=b
if e then e(b)end
end
end
return a
end







local function p(a,b)
if type(a.profiles)~="table"then return end
if type(a.before)~="table"then a.before={}end
a.before[b]=c.copy(a.profiles)
f={from=b,changed={},failed={}}
local d
local function g(b,a)
if#a>0 then f.changed[#f.changed+1]={rec=b,notes=a,profile=d}end
end
local function i(a)f.failed[#f.failed+1]={raw=a,profile=d}end
local c,e={},{}
for a in pairs(a.profiles)do
if type(a)=="string"then c[#c+1]=a end
end
table.sort(c)
for f,c in ipairs(c)do
local a=a.profiles[c]
if type(a)=="table"and type(a.elements)=="table"then
d=c
e[c]=j(a.elements,b,g,i)
end
end
local d={}
if type(a.backups)=="table"then
for c,a in pairs(a.backups)do
if type(a)=="table"and type(a.elements)=="table"then d[c]=j(a.elements,b)end
end
end
for b,c in pairs(e)do a.profiles[b].elements=c end
for b,c in pairs(d)do a.backups[b].elements=c end

for c,a in ipairs({a.profiles,type(a.backups)=="table"and a.backups or{}})do
for c,a in pairs(a)do
if type(a)=="table"and type(a.groups)=="table"then
for c,d in ipairs(a.groups)do a.groups[c]=h.group(d,b)end
end
end
end

for d,c in ipairs(c)do
if h.dropSwing(a.profiles[c],b)then f.swingOn=true end
end
if type(a.backups)=="table"then
for c,a in pairs(a.backups)do h.dropSwing(a,b)end
end
end



local function v()
local c=InterHUDDB
if type(c)=="table"and type(c.interhud)=="number"and c.interhud>a.VERSION then
m=c.interhud
return
end
if type(c)=="table"and l(c)then
c={old=c}
InterHUDDB=c
o=true
end
if type(c)~="table"then
c={}
InterHUDDB=c
end
if type(c.interhud)=="number"and c.interhud<a.VERSION then p(c,c.interhud)end
for b,a in ipairs({"profiles","chars","backups","ui","caches"})do
if type(c[a])~="table"then c[a]={}end
end
c.interhud=a.VERSION
b=c
end



e.record("character",{fields={
{name="name",type="string",max=96},
{name="realm",type="string",max=64},
}})

local function j(a)
return type(a)=="string"and a~=""and not c.isSecret(a)and a or nil
end






local function x()
local a,d=UnitName("player")
a,d=j(a)or"Unknown",j(d)
local f
local e=_G.NameUtil
if e and e.FormatUnitNameForDisplay then
local a,b=c.try("NameUtil",e.FormatUnitNameForDisplay,"player")
f=a and j(b)or nil
end
local e=f or(d and a.." "..d or a)
local c=j(GetRealmName())or"Unknown"
local f=j(UnitGUID("player"))
local d=f or(a.." - "..c)
if b.chars[d]==nil then
for c,a in ipairs({a.." - "..c,e.." - "..c})do
if a~=d and type(b.chars[a])=="table"then
b.chars[d],b.chars[a]=b.chars[a],nil
break
end
end
end
t=f==nil
return d,e,c
end






local j=e.field("character","profiles")
local j={name="profiles",type=j.of,max=j.item.max}
local function y()
local a={}
for b in pairs(b.profiles)do
if type(b)=="string"then
local c=d.cleanValue(j,b,d.newCtx("load"),"name")

if c~=b and type(c)=="string"and c~=""then a[#a+1]=b end
end
end
table.sort(a)
for c,a in ipairs(a)do

local c=n(d.cleanValue(j,a,d.newCtx("load"),"name"))
b.profiles[c],b.profiles[a]=b.profiles[a],nil
b.backups[c],b.backups[a]=b.backups[a],nil
for d,b in pairs(b.chars)do
if type(b)=="table"then
if b.profile==a then b.profile=c end
if type(b.profiles)=="table"then
for d,e in pairs(b.profiles)do
if e==a then b.profiles[d]=c end
end
end
end
end
end
end




local function z()
return"empty, so add elements with New"
end



local function p(a)
if type(a)~="table"then return nil end
if type(a.name)=="string"and a.name~=""then return a.name end
local b=type(a.sources)=="table"and a.sources[1]
local b=type(b)=="table"and c.Spells.firstOf(b.spells)
local b=type(b)=="number"and c.Spells.label(b)
if b then return b end
return(type(a.id)=="string"or type(a.id)=="number")and tostring(a.id)or nil
end
local function j(a,b,c)return a.." "..(a==1 and b or c)end

local function l(a,b)
local b=#a-1+(b or 0)
local a="“"..a[1].."”"
if b>0 then a=a.." and "..j(b,"other element","other elements")end
return a
end
local s={{"customState","custom state","custom states"},{"look","look","looks"},
{"effect","effect","effects"},{"quick","quick setting","quick settings"}}

local function A(a,b)
for c,b in ipairs(b)do
if b.leftOut then a[b.leftOut]=(a[b.leftOut]or 0)+1 end
if b.cleared then a.cleared=true end
if b.cuesUnder then a.cues=(a.cues or 0)+1 end
end
end
local function B(a,b)
for a,c in pairs(a)do
if b[a]~=c then return false end
end
for b in pairs(b)do
if a[b]==nil then return false end
end
return true
end



local function C(a)
local e,c={},{}
for a,b in ipairs(a)do
local d=p(b.rec)or"?"
local a=e[d]
if not a then
a={name=d,n=0,tallies={},order={}}
e[d]=a
c[#c+1]=a
end
local c=a.tallies[b.profile]
if not c then
c={}
a.tallies[b.profile]=c
a.order[#a.order+1]=b.profile
a.n=a.n+1
end
A(c,b.notes)
end
for b,a in ipairs(c)do
a.first,a.same=a.tallies[a.order[1]],true
for b=2,#a.order do
if not B(a.first,a.tallies[a.order[b]])then a.same=false end
end
end
return c
end



local function A()
if not f then return nil end
local b=C(f.changed)
local i,d,c,e,g,a={},{},{},{},0,{}
for b,a in ipairs(b)do
local f=false
for c,b in ipairs(s)do
local a=a.first[b[1]]
if a then
i[b[1]]=(i[b[1]]or 0)+a
f=true
end
end
if f then d[#d+1]=a.name end
if a.first.cleared then c[#c+1]=a.name end
if a.first.cues then
e[#e+1]=a.name
g=g+a.first.cues
end
end
if#d>0 then
local b,c={},0
for d,a in ipairs(s)do
local d=i[a[1]]
if d then
b[#b+1]=j(d,a[2],a[3])
c=c+d
end
end
local b=#b==1 and b[1]
or(table.concat(b,", ",1,#b-1).." and "..b[#b])
a[#a+1]="InterHUD couldn't bring over everything in "..l(d).." to this version: "
..b..(c==1 and" was"or" were").." left out."
end
if#c>0 then
a[#a+1]="“When it shows” was cleared in "..l(c)..", so "
..(#c==1 and"it now always shows."or"they now always show.")
end
if#e>0 then
local b=g==1
a[#a+1]="In "..l(e)..", the button cues on "..j(g,"icon","icons")
.." are now drawn under "..(b and"the icon's"or"the icons'").." own looks, because "
..(b and"the icon"or"the icons").." had no room for more looks."
end

local d,e,c=false,true,nil
for b,a in ipairs(b)do
if a.n>1 then d=true end
if not a.same or(c and a.n~=c)then e=false end
c=c or a.n
end

if d and#a>0 then
if e then
a[#a+1]="This is the same in "..c.." of your profiles."
elseif#b==1 then
a[#a+1]="“"..b[1].name.."” is counted once here, though it is in "..b[1].n
.." of your profiles."
else
a[#a+1]="Each element is counted once here, though some are in more than one of your profiles."
end
end
if#f.failed>0 then
local b,d,c={},{},0
for e,a in ipairs(f.failed)do
local a=p(a.raw)
if not a then
c=c+1
elseif not d[a]then
d[a]=true
b[#b+1]=a
end
end
local d=#b>0 and l(b,c)or j(c,"element","elements")
local b=#b+c==1
a[#a+1]=d.." couldn't be fully updated, so the parts of "..(b and"it"or"them")
.." this version can't read were left out."
end
if f.swingOn then a[#a+1]=h.SWING_GONE end
if#a==0 then return nil end
a[#a+1]="A copy of your settings from before this update is kept in InterHUD's saved file."
return table.concat(a," ")
end




local function j()
if m then
c.print("these settings were saved by a newer InterHUD (format "..m.."): update it. "
.."Nothing is shown or changed until then.")
return
end
if not b then return end
y()
local h=0
for e,a in pairs(b.profiles)do
if type(e)~="string"then
b.profiles[e]=nil
else
local f=type(a)=="table"and a or{}
local g,a=d.clean("profile",f,"load")
if a.dropped>0 then b.backups[e]=c.copy(f)end


if a.dropped>0 and c.isDev then

local b={}
for a,c in ipairs(a.droppedPaths)do b[a]=d.cut(c,60):gsub("|","||")end
c.print((string.format("dev: the load dropped %d setting%s in profile %q (saved form kept as a backup): %s",
a.dropped,a.dropped==1 and""or"s",e,table.concat(b,", "))))
end
b.profiles[e]=g or{}
h=h+a.dropped
end
end
a.droppedAtLoad=h
b.ui=d.clean("uiState",b.ui,"load")or{}
b.caches=d.clean("caches",b.caches,"load")or{}
for c,a in pairs(b.chars)do
a=type(a)=="table"and a or{}
b.chars[c]=type(c)=="string"and d.clean("character",a,"load")or nil
end
local d,h,i=x()
g=d
local e=b.chars[g]or{}
b.chars[g]=e
e.name,e.realm=h,i
local d=e.profiles or{}
e.profiles=d
local e=false
if type(d[1])~="string"or not b.profiles[d[1]]then

local a=u(h,i)
b.profiles[a]={}
d[1]=a
e=true
end
if d[2]~=nil and not b.profiles[d[2]]then d[2]=nil end
k=a.readTalentGroup()
if f and c.isDev then
local b={}
for a,c in ipairs(f.changed)do b[a]=tostring(c.rec.id)end
c.print(string.format("dev: format %d converted to %d: %d element%s changed (%s), %d failed; the saved"
.." profiles kept under before[%d]",f.from,a.VERSION,#b,#b==1 and""or"s",
table.concat(b,", "),#f.failed,f.from))
end
local b=A()
if b then c.print(b)end
f=nil
if e then
c.print((o and"settings start afresh with this version, the old ones kept aside. "or"")
.."A new profile for "..h..": "..z()..".")
end
c.changed("profile",a.profileName())
end



local f=false
local function h()
if f then return end
f=true
c.print("your settings couldn't be loaded because of an error, so InterHUD may show nothing this session.")
end
r.on("ADDON_LOADED","store",function(b,a)
if a==c.name and not c.try("store load",v)then h()end
end)
r.on("PLAYER_LOGIN","store",function()
if not c.try("store login",j)then h()end
end)

function a.newerVersion()return m end





function a.profileFor(c)
if not a.ready()then return nil end
local a=b.chars[g].profiles or{}
local c=a[c]
if c~=nil and b.profiles[c]then return c end

if a[1]~=nil and b.profiles[a[1]]then return a[1]end
return nil
end


function a.profileName()
return a.profileFor(k)
end


function a.talentGroup()return k end




function a.readTalentGroup()
local a=C_SpecializationInfo and C_SpecializationInfo.GetActiveSpecGroup
if not a then return 1 end
local b,a=c.try("GetActiveSpecGroup",a)
if b and not c.isSecret(a)and(a==1 or a==2)then return a end
return 1
end

function a.profile()
local a=a.profileName()
return a and b.profiles[a]
end

function a.profileNamed(c)return a.ready()and b.profiles[c]or nil end

function a.profileNames()
local c={}
if not a.ready()then return c end
for a in pairs(b.profiles)do c[#c+1]=a end
table.sort(c)
return c
end




local f=setmetatable({},{__mode="k"})
local function l(b,d)
if not b then return nil end
local a=f[b]
local c=a and a[d]
if c and b[c]and b[c].id==d then return c end
a={}
for c,b in ipairs(b)do
if b.id~=nil and a[b.id]==nil then a[b.id]=c end
end
f[b]=a
return a[d]
end

function a.element(b)
local a=a.profile()
local b=a and l(a.elements,b)
return b and a.elements[b]
end

function a.group(b)
local a=a.profile()
local b=a and l(a.groups,b)
return b and a.groups[b]
end





local f={{kind="refuse",path="",text="Settings aren't loaded yet."}}



local function h(b)
for c,a in ipairs(e.fieldsOf("profile"))do
local b=b[a.name]
if a.type=="list"and a.maxItems and type(b)=="table"and#b>a.maxItems then
return{{kind="refuse",path=a.name,
text="A profile holds at most "..a.maxItems.." "..a.label:lower().."."}}
end
end
end



local function s(c)
local b=h(c)
if b then return false,b end
local b=d.newCtx("edit")
for d,a in ipairs(e.get("profile").rules)do
a.fn(c,b,"")
if b.failed or#b.messages>0 then return false,b.messages end
end
local a=a.profile()
for b in pairs(a)do a[b]=nil end
for b,c in pairs(c)do a[b]=c end
return true,b
end

local function h(b,d,e,a)
local f,b=s(b)
if not f then return false,b end
c.changed(d,e)
for c,b in ipairs(b.notes)do a[#a+1]=b end
return true,a
end



local function o()
return c.copy(a.profile())
end




local function j(a)
return{presets=a and a.presets or false,buttonCues=a and a.buttonCues or false}
end



local function p(k,n,m,g,i)
if not a.ready()then return false,f end



local e={}
for a,b in pairs(a.profile())do e[a]=b end
local a={}
for b,c in ipairs(e[k]or{})do a[b]=c end
e[k]=a
local b=l(a,g)
local l={}
if i==nil then
if not b then return false,{{kind="refuse",path="",text="No such "..m..": "..g}}end
table.remove(a,b)
else
local f
if type(i)=="function"then
if not b then return false,{{kind="refuse",path="",text="No such "..m..": "..g}}end
f=c.copy(a[b])
i(f)
else
if b then
return false,{{kind="refuse",path="",text="The id \""..g.."\" is used already."}}
end
f=c.copy(i)
end

local c=j(e)
c.before=b and a[b]or nil
local c,d=d.clean(n,f,"edit",c)
if not c or#d.messages>0 then return false,d.messages end
l=d.notes
if b then a[b]=c else a[#a+1]=c end
end
if#a==0 then e[k]=nil end
return h(e,m,g,l)
end

function a.editElement(a,b)return p("elements","element","element",a,b)end



function a.wouldEditElement(b,e)
if not a.ready()then return false end
local b=a.element(b)
if not b then return false end
local f=b
b=c.copy(b)
e(b)
local a=j(a.profile())
a.before=f
local a,b=d.clean("element",b,"edit",a)
return a~=nil and#b.messages==0
end
function a.addElement(a)return p("elements","element","element",a.id,a)end
function a.removeElement(a)return p("elements","element","element",a,nil)end
function a.editGroup(a,b)return p("groups","group","group",a,b)end
function a.addGroup(a)return p("groups","group","group",a.id,a)end
function a.removeGroup(a)return p("groups","group","group",a,nil)end


function a.moveGroup(c,e)
if not a.ready()then return false,f end
local b={}
for a,c in pairs(a.profile())do b[a]=c end
local a={}
for b,c in ipairs(b.groups or{})do a[b]=c end
local d=l(a,c)
if not d then return false,{{kind="refuse",path="",text="No such group: "..tostring(c)}}end
local d=table.remove(a,d)
table.insert(a,math.max(1,math.min(math.floor(e or#a+1),#a+1)),d)
b.groups=a
return h(b,"group",c,{})
end



function a.freeId(b)
local c={}
local a=a.ready()and a.profile()or{}
for d,b in ipairs({"elements","groups"})do
for b,a in ipairs(a[b]or{})do c[a.id]=true end
end
b=b:sub(1,32)
if not c[b]then return b end
local a=2
while true do
local d="-"..a
local b=b:sub(1,32-#d)..d
if not c[b]then return b end
a=a+1
end
end







local function p(i,b,k,n,m)
if not a.ready()then return false,f end
local a=o()
local f=a.elements or{}
a.elements=f
local g=l(f,i)
local l={}
if b then
if g then return false,{{kind="refuse",path="",text="The id \""..i.."\" is used already."}}end
b=c.copy(b)
elseif not g then
return false,{{kind="refuse",path="",text="No such element: "..tostring(i)}}
elseif m~=nil then
b=c.copy(f[g])
end

if k~=nil and e.alertFlag(b or f[g],"loose")then
return false,{{kind="refuse",path="",text="A Spell Alert is never in a group."}}
end
if b then
if m~=nil then b.position=c.copy(m)end
local a,b=d.clean("element",b,"edit",j(a))
if not a or#b.messages>0 then return false,b.messages end
l=b.notes
if g then f[g]=a else f[#f+1]=a end
end
local b
for d,c in ipairs(a.groups or{})do
local a=c.members or{}
for b=#a,1,-1 do
if a[b]==i then table.remove(a,b)end
end
c.members=#a>0 and a or nil
if c.id==k then b=d end
end
if k~=nil then
if not b then
return false,{{kind="refuse",path="",text="No such group: "..tostring(k)}}
end
local e=a.groups[b]
local c=e.members or{}
e.members=c
local f=math.max(1,math.min(math.floor(n or#c+1),#c+1))
table.insert(c,f,i)

local c,d=d.clean("group",e,"edit")
if not c or#d.messages>0 then return false,d.messages end
a.groups[b]=c
end
return h(a,"group",k,l)
end


function a.addElementTo(b,c,d)
if c==nil then return a.addElement(b)end
return p(b.id,b,c,d)
end




function a.duplicateElement(d,e)
local b=a.ready()and a.element(d)
if not b then return false,{{kind="refuse",path="",text="No such element: "..tostring(d)}}end
local b=c.copy(b)
b.id=a.freeId(d)
for a,d in pairs(e or{})do b[a]=c.copy(d)end
local c=a.groupOf(d)
if c and not a.full("members",c)then
local a=a.group(c).members or{}
local e=#a
for a,b in ipairs(a)do if b==d then e=a end end
local a,c=p(b.id,b,c,e+1)
return a,c,b.id
end
local a,c=a.addElement(b)
return a,c,b.id
end


function a.moveElement(a,b,c,d)
return p(a,nil,b,c,d)
end


function a.full(c,g)
local f=a.ready()and a.profile()
if not f then return true end
local b,d
if c=="members"then
local a=a.group(g)
b,d=e.field("group","members"),a and a.members or{}
else
b,d=e.field("profile",c),f[c]or{}
end
return b.maxItems~=nil and#d>=b.maxItems
end




function a.deleteGroup(b,k,g)
if not a.ready()then return false,f end
local a=o()
local e=l(a.groups,b)
if not e then return false,{{kind="refuse",path="",text="No such group: "..tostring(b)}}end
local m=a.groups[e].members or{}
table.remove(a.groups,e)
if#a.groups==0 then a.groups=nil end
local f,i={},{}
for b,e in ipairs(m)do
local b=l(a.elements,e)
if b and k then
table.remove(a.elements,b)
f[#f+1]=e
elseif b and g and g[e]then
local f=c.copy(a.elements[b])
f.position=c.copy(g[e])
local d,c=d.clean("element",f,"edit",j(a))
if not d or#c.messages>0 then return false,c.messages end
a.elements[b]=d
for b,a in ipairs(c.notes)do i[#i+1]=a end
end
end
if a.elements and#a.elements==0 then a.elements=nil end
local a,b=h(a,"group",b,i)
if a then
for b,a in ipairs(f)do c.changed("element",a)end
end
return a,b
end


function a.groupOf(b)
local a=a.profile()
for c,a in ipairs(a and a.groups or{})do
for c,d in ipairs(a.members or{})do
if d==b then return a.id,c end
end
end
end



local l,p
function a.ui()
if not a.ready()then return i.record("uiState",{})end
if l~=b.ui then l,p=b.ui,i.record("uiState",b.ui)end
return p
end
function a.editUI(e)
if not a.ready()then return false,f end
local a=c.copy(b.ui)
e(a)
local d,a=d.clean("uiState",a,"edit")
if not d or#a.messages>0 then return false,a.messages end
b.ui=d
c.changed("ui")
return true,a.notes
end


function a.editStyles(e)
if not a.ready()then return false,f end
local b=c.copy(a.profile().styles or{})
e(b)
local d,b=d.clean("styles",b,"edit")
if#b.messages>0 then return false,b.messages end


local c={}
for a,b in pairs(a.profile())do c[a]=b end
c.styles=d
return h(c,"styles",nil,b.notes)
end





local l={C2=true,C4=true}
local function p(a,g,h)
local f={}
for a,b in ipairs(a or{})do
local a=false
e.eachRecord("element",b,function(b,c)
if b:match("^look:")and i.valuesOf(c)==nil then a=true end
end)
if a then
local e={}
for b,a in ipairs(c.Check.problems(b,g))do
if l[a.rule]and not a.note then e[a.path..a.text]=true end
end
for c,a in ipairs(c.Check.problems(b,h))do
if l[a.rule]and not a.note and not e[a.path..a.text]then
f[#f+1]=d.message("note",b.id,a.path,a.text
.." With these fact looks, what goes past it draws only as a cover (tint, overlay and ring).")
end
end
end
end
return f
end


function a.editFactLooks(b)
if not a.ready()then return false,f end
local e=a.profile().buttonCues
local a=c.copy(e or{})
b(a)
local c,a=d.clean("buttonCues",a,"edit")
if#a.messages>0 then return false,a.messages end
local b=o()
b.buttonCues=c
local a=a.notes
for c,b in ipairs(p(b.elements,e,c))do a[#a+1]=b end
return h(b,"styles",nil,a)
end





function a.special(b)
local a=a.ready()and a.profile()
return a and a.specials and a.specials[b]or nil
end
function a.editSpecial(b,g)
if not a.ready()then return false,f end
local e=e.field("specials",b)
if not(e and e.record)then
return false,{{kind="refuse",path="",text="No such special: "..tostring(b)}}
end
local c=c.copy(a.special(b)or{})
g(c)
local a,c=d.clean(e.record,c,"edit",j(a.profile()))
if not a or#c.messages>0 then return false,c.messages end
local d=o()
local e=d.specials or{}
e[b]=next(a)~=nil and a or nil
d.specials=next(e)~=nil and e or nil
return h(d,"special",b,c.notes)
end








local l={elements={"position","scale"},groups={"position","scale","members"},
specials={"position","scale"}}
local v={elements="element",groups="group",specials="special"}
local x={"position","width","height"}

function a.placement()
local b={elements={},groups={},specials={},layers={}}
local a=a.ready()and a.profile()
if not a then return b end
local function d(b,d,e,f)
local a={}
for d,b in ipairs(f)do a[b]=c.copy(e[b])end
b[d]=a
end
for e,a in ipairs(a.elements or{})do
d(b.elements,a.id,a,l.elements)
local d={}
for b,a in ipairs(a.sources or{})do
for e,b in ipairs(a.id and a.layers or{})do
if b.id then
d[a.id]=d[a.id]or{}
d[a.id][b.id]=c.copy(b.position)or false
end
end
end
b.layers[a.id]=d
end
for c,a in ipairs(a.groups or{})do d(b.groups,a.id,a,l.groups)end



b.areas={}
for e,a in pairs(a.specials or{})do
d(b.specials,e,a,l.specials)
local d={listed=type(a.areas)=="table",at={}}
for b,a in ipairs(d.listed and a.areas or{})do

d.at[a.id or""]={position=c.copy(a.position),width=a.width,height=a.height}
end
b.areas[e]=d
end
return b
end


local function y(a,b)
if#a~=#b then return false end
local c={}
for b,a in ipairs(a)do c[a]=true end
for b,a in ipairs(b)do
if not c[a]then return false end
end
return true
end



local function z(e,d,a)
local a=a
for g,b in ipairs(d and e.sources or{})do
local f=b.id and d[b.id]
for h,d in ipairs(f and b.layers or{})do
local b=d.id and f[d.id]
if b~=nil and not c.equal(d.position,b or nil)then
a=a or c.copy(e)
a.sources[g].layers[h].position=b and c.copy(b)or nil
end
end
end
return a
end


local function p(b,d,a)
local e
for f,a in ipairs(a)do
local f=a=="members"and b.members and d.members and not y(b.members,d.members)
if not f and not c.equal(b[a],d[a])then
e=e or c.copy(b)
e[a]=c.copy(d[a])
end
end
return e
end

function a.restorePlacement(b)
if not a.ready()then return false,f end
local e={}
for a,b in pairs(a.profile())do e[a]=b end
local f={}
for c,a in ipairs({"elements","groups"})do
if e[a]then
local h={}
for i,g in ipairs(e[a])do
local c=b[a][g.id]and p(g,b[a][g.id],l[a])
if a=="elements"then
c=z(c or g,b.layers and b.layers[g.id],c)


if c then c=d.clean("element",c,"load",j(e))end
end
h[i]=c or g
if c then f[#f+1]={v[a],g.id}end
end
e[a]=h
end
end
local d,a={},{}
for b,c in pairs(e.specials or{})do d[b],a[b]=c,true end
for b in pairs(b.specials)do a[b]=true end
for e in pairs(a)do
local a=p(d[e]or{},b.specials[e]or{},l.specials)

local g=b.areas and b.areas[e]
local b=a or d[e]
if g and b and type(b.areas)=="table"then
local d
for h,f in ipairs(b.areas)do
local a=g.at[f.id or""]
if a~=nil or not g.listed then
a=a or{}
for g,e in ipairs(x)do
if not c.equal(f[e],a[e])then
d=d or c.copy(b.areas)
d[h][e]=c.copy(a[e])
end
end
end
end
if d then
a=a or c.copy(b)
a.areas=d
end
end
if a then
d[e]=next(a)~=nil and a or nil
f[#f+1]={"special",e}
end
end
e.specials=next(d)~=nil and d or nil
if#f==0 then return 0 end
local a,b=s(e)
if not a then return false,b end
for b,a in ipairs(f)do c.changed(a[1],a[2])end
return#f
end


function a.editSettings(b)
if not a.ready()then return false,f end
local a=c.copy(a.profile().settings or{})
b(a)
local a,b=d.clean("profileSettings",a,"edit")
if not a or#b.messages>0 then return false,b.messages end
local c=o()
c.settings=next(a)~=nil and a or nil
return h(c,"settings",nil,b.notes)
end
function a.settings()
return i.record("profileSettings",a.ready()and a.profile().settings or{})
end







local function x(a)return{{kind="refuse",path="",text=a}}end

local function v(a)
local a=c.Styles.spec(a)
return a and a.label
end


function a.presets(b)
local a=a.ready()and a.profile()
local a=a and a.presets and a.presets[b]
return type(a)=="table"and a or{}
end


function a.preset(b,c)
return i.preset(a.ready()and a.profile()or nil,b,c)
end



local l=e.field("stylePreset:border","name")
local function p(a)
if type(a)~="string"then return nil end
local a=d.cleanValue(l,strtrim(a),d.newCtx("load"),"name")
if a==d.FAIL or a==nil then return nil end
a=strtrim(a)
return a~=""and a or nil
end


local function s(a,b,c)
for d,a in ipairs(a or{})do
if a.id~=c and a.name:lower()==b:lower()then return true end
end
return false
end



function a.freePresetName(c,b)
b=p(b)
if not b then return nil end
local a=a.presets(c)
return e.numberedName(b,l.max,function(b)return s(a,b)end)
end



local function y(c,a)
local a=a:lower():gsub("%s+","-"):gsub("[^%w%-]",""):gsub("%-+","-"):gsub("^%-",""):gsub("%-$","")
a=a:sub(1,32):gsub("%-$","")
if a==""then a="preset"end
local b={}
for c,a in ipairs(c or{})do b[a.id]=true end
if not b[a]then return a end
local c=2
while true do
local d="-"..c
local a=a:sub(1,32-#d):gsub("%-$","")..d
if not b[a]then return a end
c=c+1
end
end





local function l(b)
if not a.ready()then return false,f end
local a=o()
a.presets=a.presets or{}
local c,b=b(a)
if c==false then return false,x(b)end
c=c or{}
local g,b=d.clean("stylePresets",a.presets,"edit")
if not g or#b.messages>0 then return false,b.messages end
local f=b.notes
a.presets=next(g)~=nil and g or nil
for e in pairs(c.elements or{})do
local c
c,b=d.clean("element",a.elements[e],"edit",j(a))
if not c or#b.messages>0 then return false,b.messages end
a.elements[e]=c
for b,a in ipairs(b.notes)do f[#f+1]=a end
end
for g in pairs(c.specials or{})do
local c
c,b=d.clean(e.field("specials",g).record,a.specials[g],"edit",j(a))
if not c or#b.messages>0 then return false,b.messages end
a.specials[g]=next(c)~=nil and c or nil
for b,a in ipairs(b.notes)do f[#f+1]=a end
end
if a.specials and next(a.specials)==nil then a.specials=nil end
return h(a,"styles",nil,f)
end


local function h(g,d,a,h)
local f=v(d)
if not f then return false,"No such style part: "..tostring(d)end

if e.field("buttonCues",d)then return false,f.." takes no presets."end
a=p(a)
if not a then return false,"A preset needs a name."end
local b=g.presets[d]or{}
if#b>=e.PRESETS_MAX then
return false,f.." holds at most "..e.PRESETS_MAX.." presets."
end
if s(b,a)then return false,"Another "..f.." preset is named that."end
local e=y(b,a)
b[#b+1]={id=e,name=a,style=c.copy(h)}
g.presets[d]=b
return e
end



function a.newPreset(c,e,a)
local d
local b,a=l(function(b)
if a==nil then a=b.styles and b.styles[c]end
local a,b=h(b,c,e,a)
if not a then return false,b end
d=a
end)
if not b then return nil,a end
return d,a
end



function a.duplicatePreset(a,b,f)
local c
local b,a=l(function(d)
local e=i.preset(d,a,b)
if not e then return false,"No such preset: "..tostring(b)end
local a,b=h(d,a,f,e.style)
if not a then return false,b end
c=a
end)
if not b then return nil,a end
return c,a
end



function a.editPreset(a,b,c)
return l(function(d)
local a=i.preset(d,a,b)
if not a then return false,"No such preset: "..tostring(b)end
a.style=a.style or{}
c(a.style)
end)
end


function a.renamePreset(a,b,c)
return l(function(d)
local e=i.preset(d,a,b)
if not e then return false,"No such preset: "..tostring(b)end
local c=p(c)
if not c then return false,"A preset needs a name."end
if s(d.presets[a],c,b)then
return false,"Another "..v(a).." preset is named that."
end
e.name=c
end)
end




function a.deletePreset(b,g,h)
return l(function(d)
local f=d.presets[b]
local a
for b,c in ipairs(f or{})do
if c.id==g and not a then a=b end
end
if not a then return false,"No such preset: "..tostring(g)end
local i=f[a].style
table.remove(f,a)
if#f==0 then d.presets[b]=nil end
local a,f={elements={},specials={}},{}
for a,b in ipairs(d.elements or{})do f[b.id]=a end
e.eachProfileStyleField(d,function(e,j,k,m,d,l)
if e.style~=b or j.preset~=g then return end
k[e.name]=h and c.Styles.asOwn(b,i,l)or nil
if d.kind=="element"then a.elements[f[d.key]]=true else a.specials[d.key]=true end
end)
return a
end)
end





function a.saveAsPreset(c,g,i,a,f)
local d
local b,a=l(function(b)
local c,g=h(b,c,g,i)
if not c then return false,g end
d=c
local d={elements={},specials={}}
if a.kind=="element"then
for e,b in ipairs(b.elements or{})do
if b.id==a.key then
f(b,c)
d.elements[e]=true
end
end
if next(d.elements)==nil then return false,"No such element: "..tostring(a.key)end
else
if not e.field("specials",a.key)then return false,"No such special: "..tostring(a.key)end
b.specials=b.specials or{}
b.specials[a.key]=b.specials[a.key]or{}
f(b.specials[a.key],c)
d.specials[a.key]=true
end
return d
end)
if not b then return nil,a end
return d,a
end


function a.editChar(e)
if not a.ready()then return false,f end
local a=c.copy(b.chars[g])
e(a)
local d,a=d.clean("character",a,"edit")
if not d or#a.messages>0 then return false,a.messages end
b.chars[g]=d
c.changed("char")
return true,a.notes
end





function a.useProfile(e,d)
d=d or k
if not a.ready()or(d~=1 and d~=2)then return false end
if e==nil then
if d==1 then return false end
elseif not b.profiles[e]then
return false
end
local f=a.profileName()
local b=b.chars[g].profiles
b[d]=e
if d==1 and b[2]==e then b[2]=nil end
if a.profileName()~=f then c.changed("profile",a.profileName())end
return true
end




local function e()
w.whenUnlocked("store talent group",function()
local b=a.readTalentGroup()
if b==k then return end
local d=a.profileName()
k=b
if a.ready()and a.profileName()~=d then c.changed("profile",a.profileName())end
end)
end
r.on("ACTIVE_TALENT_GROUP_CHANGED","store",e)

function a.newProfile(d)
d=a.ready()and q(d)
if not d then return nil end
d=n(d)
b.profiles[d]={}
c.changed("profiles")
return d
end

function a.copyProfile(e,d)
d=a.ready()and b.profiles[e]and q(d)
if not d then return nil end
d=n(d)
b.profiles[d]=c.copy(b.profiles[e])
c.changed("profiles")
return d
end


function a.renameProfile(e,d)
d=a.ready()and q(d)
if not d or not b.profiles[e]or b.profiles[d]then return false end
b.profiles[d],b.profiles[e]=b.profiles[e],nil
b.backups[d],b.backups[e]=b.backups[e],nil
for b,a in pairs(b.chars)do
for b,c in ipairs(a.profiles or{})do
if c==e then a.profiles[b]=d end
end
end
c.changed("profiles")
return true
end


function a.usedHere(c)
if not a.ready()then return false end
for b,a in ipairs(b.chars[g].profiles or{})do
if a==c then return true end
end
return false
end



function a.deleteProfile(d)
if not a.ready()or a.usedHere(d)or not b.profiles[d]then return false end
b.profiles[d],b.backups[d]=nil,nil



for b,a in pairs(b.chars)do
local a=a.profiles
if type(a)=="table"then
if a[2]==d then a[2]=nil end
if a[1]==d then a[1]=""end
end
end
c.changed("profiles")
return true
end




function a.deleteAllProfiles()
if not a.ready()then return false end
for a in pairs(b.profiles)do b.profiles[a]=nil end
for a in pairs(b.backups)do b.backups[a]=nil end
for b,a in pairs(b.chars)do
if type(a)=="table"then a.profiles={}end
end
local a=b.chars[g]
local d=u(a.name,a.realm)
b.profiles[d]={}
a.profiles[1]=d
c.changed("profile",d)
return true
end



function a.resetProfile()
local a=a.ready()and a.profileName()
if not a then return false end
b.profiles[a]={}
c.changed("profile",a)
return true
end




function a.replaceProfile(e)
if not a.ready()then return false,f end
local e,d=d.clean("profile",e,"edit")
if not e or#d.messages>0 then return false,d.messages end
local a=a.profileName()
b.profiles[a]=e
c.changed("profile",a)
return true,d.notes
end



a.PROFILES_MAX=50

function a.profilesFull()
if not a.ready()then return nil end
local c=0
for a in pairs(b.profiles)do c=c+1 end
if c<a.PROFILES_MAX then return nil end
return"You have "..c.." profiles, the most: delete one first."
end



local h={{kind="refuse",path="",text="That profile name can't be used."}}
function a.addProfile(e,g)
if not a.ready()then return nil,f end
local a=a.profilesFull()
if a then return nil,{{kind="refuse",path="",text=a}}end
e=q(e)
if not e then return nil,h end
local d,a=d.clean("profile",g,"edit")
if not d or#a.messages>0 then return nil,a.messages end
local e=n(e)
b.profiles[e]=d
c.changed("profiles")
return e,a.notes
end



function a.profileUsers(d)
local c={}
if not a.ready()then return c end
for a,b in pairs(b.chars)do
for e,b in ipairs(b.profiles or{})do
if b==d then
c[#c+1]=a
break
end
end
end
table.sort(c,function(b,c)
local a,d=a.charLabel(b),a.charLabel(c)
return a==d and b<c or a<d
end)
return c
end


function a.charKey()return g end



function a.charLabel(c)
local a=a.ready()and b.chars[c]
if type(a)=="table"and a.name and a.realm then return a.name.." - "..a.realm end
return c
end




function a.talentGroups()
if not GetNumSpecGroups then return 1 end
local b,a=c.try("GetNumSpecGroups",GetNumSpecGroups)
if b and not c.isSecret(a)and type(a)=="number"and a>=2 then return 2 end
return 1
end


function a.backup(c)
return a.ready()and b.backups[c]or nil
end


function a.char()
return a.ready()and b.chars[g]or nil
end



function a.caches()
return a.ready()and b.caches or nil
end

function a.describe()
if m then
return{"settings: made by a newer InterHUD (format "..m.."): not loaded; update first"}
end
local c=a.profile()
local e=a.profileName()

local d={}
for a in pairs(b and type(b.before)=="table"and b.before or{})do
if type(a)=="number"then d[#d+1]=a end
end
table.sort(d)

return{string.format("settings: profile %q (talent group %d of %d), %d elements, %d groups, %d dropped at load%s%s%s",
tostring(e),k,a.talentGroups(),c and c.elements and#c.elements or 0,
c and c.groups and#c.groups or 0,
a.droppedAtLoad or 0,e and b.backups[e]and" (its saved form kept as a backup)"or"",
#d>0 and("; the profiles as saved at format "..table.concat(d,", ").." kept")or"",
t and"; keyed by name (the client gave no game ID)"or"")}
end

c.Debug.register("settings",a.describe)
