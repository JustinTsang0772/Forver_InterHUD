







local a,r=...
local h=r.Schema

local b={}
r.Clean=b

local e={}
b.FAIL=e

local a={}
a.__index=a

local function m(b,c)
return setmetatable({mode=b or"load",vars=c or{},messages={},notes={},dropped=0,
droppedPaths={}},a)
end


local function j(a,b)
a.dropped=a.dropped+1
if#a.droppedPaths<10 then a.droppedPaths[#a.droppedPaths+1]=tostring(b)end
end
b.newCtx=m

function a:strict()return self.mode~="load"end




local c={unit=80,path=160,text=400}
local function d(a,b)
if type(a)~="string"or#a<=b then return a end
local b=b
while b>1 and a:byte(b+1)and a:byte(b+1)>=128 and a:byte(b+1)<192 do b=b-1 end
return a:sub(1,b).."…"
end
b.cut=d
function b.message(a,b,e,f)
return{kind=a,unit=d(b,c.unit),path=d(e,c.path),text=d(f,c.text)}
end
local function c(a,c,d,e)return b.message(c,a.unit,d,e)end


function a:fault(a,b)
if self:strict()then
self.messages[#self.messages+1]=c(self,"refuse",a,b)
else
j(self,a)
end
return e
end


function a:note(a,b)
if self:strict()then self.notes[#self.notes+1]=c(self,"note",a,b)end
end


function a:dropItem(a,b)
if self:strict()then
self.messages[#self.messages+1]=c(self,"refuse",a,b)
if self.mode=="edit"then self.failed=true end
else
j(self,a)
end
end


function a:problem(a,c,b)
if self:strict()or not b then
self:fault(a,c)
self.failed=true
else
j(self,a)
b()
end
end


function b.format(a)
local b=a.path~=""and a.path or nil
local b=a.unit and(b and(a.unit..": "..b)or(a.unit..":"))or b
return(b and(b.." ")or"")..a.text
end

function b.lines(c)
local a={}
for c,d in ipairs(c)do a[c]=b.format(d)end
return a
end



local function f(a)
return type(a)=="number"and a==a and a~=math.huge and a~=-math.huge
end
b.isNumber=f

local function c(a)
if type(a)=="string"then return string.format("%q",d(a,60))end
if type(a)=="number"and a~=a then return"NaN"end
if a==math.huge then return"Infinity"end
if a==-math.huge then return"-Infinity"end
if type(a)=="table"then return"a table"end
return tostring(a)
end

local function i(a)
if#a==0 then return"nothing here"end
if#a==1 then return a[1]end
return table.concat(a,", ",1,#a-1).." or "..a[#a]
end
b.orList=i

local function d(a)
if a==math.floor(a)then return string.format("%d",a)end
return(string.format("%.3f",a):gsub("0+$",""))
end

local function g(a,b,c,e)
if a.min and b<a.min then
c:note(e,d(b).." is below "..d(a.min).."; set to "..d(a.min)..".")
return a.min
elseif a.max and b>a.max then
c:note(e,d(b).." is above "..d(a.max).."; set to "..d(a.max)..".")
return a.max
end
return b
end


local function k(a,b,e,f)
b=g(a,b,e,f)
if a.step then
local c=a.min or 0
local c=tonumber(string.format("%.6f",c+math.floor((b-c)/a.step+0.5)*a.step))
if a.max and c>a.max then c=c-a.step end
if c~=b then
e:note(f,d(b).." isn't a step of "..d(a.step).."; set to "..d(c)..".")
b=c
end
end
return b
end

local g

local n={"player","target"}


local function o(a,b,c)
if a.choicesFrom then
local a,b=a.choicesFrom(b or{},c)
return a or{},b
end

if a.type=="unit"then return a.units or n end
if a.type=="point"then return g end
return a.choices or{}
end

b.choicesOf=o

local function l(a,b)
for c,a in ipairs(a)do
if a==b then return true end
end
return false
end

g={"TOPLEFT","TOP","TOPRIGHT","LEFT","CENTER","RIGHT","BOTTOMLEFT","BOTTOM","BOTTOMRIGHT"}
b.POINTS=g

local a={}
b.types=a

function a.boolean(e,a,b,d)
if type(a)~="boolean"then return b:fault(d,c(a).." isn't true or false.")end
return a
end

function a.number(e,a,b,d)
if not f(a)then return b:fault(d,c(a).." isn't a number.")end
return k(e,a,b,d)
end

function a.integer(e,a,b,d)
if not f(a)or a~=math.floor(a)then return b:fault(d,c(a).." isn't a whole number.")end
return k(e,a,b,d)
end


function a.percent(g,a,b,e)
if f(a)and a>0 and a<1 then
return b:fault(e,"is a percent: "..d(a*100)..", not "..d(a)..".")
end
if not f(a)or a~=math.floor(a)then
return b:fault(e,c(a).." isn't a whole percent, 0 to 100.")
end
if a==1 then b:note(e,"1 means 1%; for full use 100.")end
return k({min=g.min or 0,max=g.max or 100,step=g.step},a,b,e)
end

function a.choice(g,b,d,e,f)
local f,h=o(g,f,d.vars)
if type(b)=="string"and l(f,b)then return b end
if type(b)=="string"and h and h[b]then return d:fault(e,h[b])end
if type(b)=="string"and g.open and b~=""then

b=a.string(g,b,d,e)
if l(f,b)then return b end
d:note(e,c(b).." isn't here now; kept.")
return b
end
if#f==0 then return d:fault(e,c(b).." isn't offered here.")end

if type(b)=="number"and l(f,tostring(b))then
return d:fault(e,c(b).." is a number; write it as text: "..string.format("%q",tostring(b))..".")
end
return d:fault(e,c(b).." isn't a choice; use "..i(f)..".")
end


function a.scalar(g,b,e,f)
local d=type(b)
if d=="boolean"or d=="number"then return b end
if d=="string"then return a.string(g,b,e,f)end
return e:fault(f,c(b).." isn't a plain value: true or false, a number or text.")
end

function a.id(e,a,b,d)
if type(a)~="string"or#a<1 or#a>32 or not a:match("^[%w%-]+$")then
return b:fault(d,c(a).." isn't an id: 1 to 32 letters, digits or dashes.")
end
return a
end



function a.string(e,a,b,d)
if type(a)~="string"then return b:fault(d,c(a).." isn't text.")end
if a:find("|",1,true)then
a=a:gsub("|","")
b:note(d,"had the | character, which the game reads as a code; taken out.")
end
if a:find("%c")then
a=a:gsub("%c+"," ")
b:note(d,"had a line break or another control character; made a space.")
end
local c=e.max or 64
if#a>c then
b:note(d,"is too long; cut to fit.")
local b=c
while b>0 and a:byte(b+1)and a:byte(b+1)>=128 and a:byte(b+1)<192 do b=b-1 end
a=a:sub(1,b)
end
return a
end




local function k(e,c,a,d,f,b)
if not b or#c<=b then return#c end
if a:strict()then return a:fault(d,"has "..#c.." "..f.."; at most "..b..".")end
for b=b+1,#c do j(a,d.."["..b.."]")end
if e.record then a.recordsDropped=(a.recordsDropped or 0)+1 end
return b
end


local d="takes one spell: its ID, its name, or { \"id\", \"name\" }."
function a.spell(h,a,e,g)
if type(a)=="table"then return e:fault(g,(b.isList(a)and"is a list; "or"")..d)end
if not f(a)or a~=math.floor(a)or a<1 then
return e:fault(g,c(a).." isn't a spell; this "..d)
end
return a
end




function a.spells(h,d,a,g)
if type(d)=="table"and next(d)~=nil and not b.isList(d)then
return a:fault(g,"isn't a list, or has a gap.")
end
if type(d)~="table"then return a:fault(g,c(d).." isn't a list of spells; write them as [324, 408510].")end
local b=h.maxItems or 20
if#d==0 then
return a:fault(g,(h.minItems or 1)>0 and("is empty; give at least one spell: its ID, its name or"
.." { \"id\", \"name\" }.")or"is empty; leave it out for none.")
end
local b=k(h,d,a,g,"spells",b)
if b==e then return e end
local i,j,h={},{},false
for e=1,b do
local b=d[e]
local d=g.."["..e.."]"
if not f(b)or b~=math.floor(b)or b<1 then
a:fault(d,c(b).." isn't a spell ID.")
h=h or a:strict()
elseif j[b]then
a:fault(d,c(b).." is repeated.")
h=h or a:strict()
else
j[b]=true
i[#i+1]=b
end
end
if h then return e end
if#i==0 then return a:fault(g,"has nothing left that fits here.")end
return i
end





local d="^[%w%-]+$"
local function f(a)
if type(a)~="string"or#a>65 then return false end
local b,c=a:match("^([^%.]+)%.([^%.]+)$")
if b then return#b<=32 and#c<=32 and b:match(d)~=nil and c:match(d)~=nil end
return#a<=32 and a:match(d)~=nil
end
b.isKey=f
function a.keys(g,a,d,e)
if type(a)=="string"then a={a}end
if type(a)=="table"and next(a)~=nil and not b.isList(a)then
return d:fault(e,"isn't a key or a list of keys: write one as \"ready\", several as [\"ready\", \"game.inCombat\"].")
end
if type(a)~="table"then return d:fault(e,c(a).." isn't a key or a list of keys.")end
local b,g=g.minItems or 1,g.maxItems or 8
if#a<b then
return d:fault(e,#a==0 and"is empty; leave it out instead."or("needs at least "..b.." keys."))
end
if#a>g then return d:fault(e,"has "..#a.." keys; at most "..g..".")end
local g,h={},{}
for b=1,#a do
local a=a[b]
local e=e.."["..b.."]"
if not f(a)then
return d:fault(e,c(a).." isn't a key: a word, or source.word, of letters, digits or dashes.")
elseif h[a]then
return d:fault(e,c(a).." is repeated.")
end
h[a]=true
g[b]=a
end
return g
end

function a.unit(b,c,d,e)
return a.choice({choices=b.units or n},c,d,e)
end

function a.point(e,b,c,d)
return a.choice({choices=g},b,c,d)
end

function a.colour(e,a,b,d)
if type(a)~="string"or not(a:match("^#%x%x%x%x%x%x$")or a:match("^#%x%x%x%x%x%x%x%x$"))then
return b:fault(d,c(a).." isn't a colour: \"#rrggbb\" or \"#rrggbbaa\".")
end
return a:lower()
end



local f=100
function a.sound(e,a,b,d)
if type(a)~="string"or a==""then return b:fault(d,c(a).." isn't a sound.")end
if a:match("^file:")and not(a:match("^file:%d+$")and#a<=#"file:"+10)then
return b:fault(d,c(a).." isn't a sound file: \"file:\" and its number, at most 10 digits.")
end
if#a>f then return b:fault(d,c(a).." isn't a sound: at most "..f.." characters.")end
if a=="media:"then return b:fault(d,"names no shared-media sound.")end
return a
end



local function l(a)
local b,c=0,0
for a in pairs(a)do
if type(a)~="number"or a<1 or a~=math.floor(a)then return false end
b=b+1
if a>c then c=a end
end
return b==c
end
b.isList=l



local function f(d,b)
if math.abs(#d-#b)>2 then return 3 end
local c={}
for a=0,#b do c[a]=a end
for e=1,#d do
local f={[0]=e}
for a=1,#b do
f[a]=math.min(c[a]+1,f[a-1]+1,c[a-1]+(d:sub(e,e)==b:sub(a,a)and 0 or 1))
end
c=f
end
return c[#b]
end
function b.unknownField(a,b)
local a=tostring(a):lower()
if#a>32 then return"isn't a field here."end
local c,d
for b,e in ipairs(b)do
local b=e.name:lower()
local a=(#a>=3 and(b:sub(1,#a)==a or a:sub(1,#b)==b))and 1 or f(a,b)
if a<=2 and(d==nil or a<d)then c,d=e.name,a end
end
if c then return"isn't a field here; did you mean "..c.."?"end
local a={}
for c,b in ipairs(b)do a[#a+1]=b.name end
return"isn't a field here; use "..i(a).."."
end

local i



local function n(d,a,e,f)
if type(a)=="string"or type(a)=="number"then
return e:fault(f,"isn't a list; write it as ["..c(a).."].")
end
local b
for a in pairs(type(a)=="table"and d.record and a or{})do
if type(a)=="string"and(b==nil or a<b)then b=a end
end
if b then
return e:fault(f,"is a list of records, each with its id: [ { \"id\": "..c(b).." } ]"
..(d.repeats and("; a look's "..d.name.." is the map by id")or"")..".")
end
return e:fault(f,"isn't a list, or has a gap.")
end

function a.list(b,f,d,g,p)
if type(f)~="table"or not l(f)then return n(b,f,d,g)end
local j=k(b,f,d,g,"items",b.maxItems)
if j==e then return e end
local q=b.record and h.get(b.record).refusable


local n=b.record and h.get(b.record).leftOut
local h,o,l,m={},{},false,0
for k=1,j do
local j=g.."["..k.."]"
local g
local n=n and n(f[k],d.vars)
if n then
m=m+1
if d.mode=="import"then
d:note(j,n:gsub("%.$","").."; left out.")
else
d:dropItem(j,n)
if not d:strict()then d.recordsDropped=(d.recordsDropped or 0)+1 end
end
elseif b.record then
g=i(b.record,f[k],d,j,b)
else
g=a[b.of](b.item or{},f[k],d,j,p)
end
if g==e then

if d:strict()and not q then l=true end
if b.record and not d:strict()then d.recordsDropped=(d.recordsDropped or 0)+1 end
elseif g~=nil then
if b.unique and o[g]then
d:fault(j,c(g).." is repeated.")
if d:strict()then l=true end
else
if b.unique then o[g]=true end
h[#h+1]=g
end
end
end
if l then return e end
if b.minItems and#h<b.minItems then
return d:fault(g,#f==0 and"is empty; leave it out instead."or#h<#f and"has nothing left that fits here."
or("needs at least "..b.minItems.." items."))
end


if#h==0 and j>0 and(not d:strict()or m==j)and not b.keep and not b.keepEmpty then return nil end
return h
end


function a.map(f,d,b,h)
if type(d)~="table"or(next(d)~=nil and l(d))then
return b:fault(h,"isn't an object of ids.")
end
local g,c={},false
for d,j in pairs(d)do
local h=h.."."..tostring(d)
if a.id(f,d,b,h)==e then
c=c or b:strict()
else
local a=i(f.record,j,b,h,f)
if a==e then
c=c or b:strict()
elseif type(a)=="table"and next(a)~=nil then
g[d]=a
end
end
end
if c then return e end
if next(g)==nil then return nil end
return g
end

function a.record(a,c,b,d)
local b=i(a.record,c,b,d,a)

local a=a.keepEmpty==true or(a.keepEmpty=="own"and type(c)=="table"and c.preset==nil)
if b~=e and type(b)=="table"and next(b)==nil and not a then return nil end
return b
end

local function n(b,c,d,e,f)
local a=a[b.type]
assert(a,"unknown type "..tostring(b.type).." for "..b.name)
return a(b,c,d,e,f)
end
b.cleanValue=n



function b.defaultOf(a,b,c)
if a.defaultFrom then return a.defaultFrom(b,c)end
return a.default
end

local function k(a,b)return a==""and b or(a.."."..b)end

function i(o,d,a,g,q)
local c=h.get(o)
if type(d)~="table"or(next(d)~=nil and l(d))then
return a:fault(g,"isn't a record (an object with named fields).")
end
local f,p,l=a.unit,a.vars,a.failed
a.failed=false
local u=#a.messages

if c.unit and type(d.id)=="string"then
a.unit=d.id
g=""
end
local function i(b)
a.unit,a.vars,a.failed=f,p,l
return b
end
local f,l={},false
local m={}

local function s(b)
if m[b.name]then return end
local c=d[b.name]
local g=k(g,b.name)
if c==nil then
if b.required then
a:fault(g,b.missing and b.missing(d)or"is missing.")
l=true
end
return
end
local c=n(b,c,a,g,f)
if c==e then
local c=b.type=="record"and h.get(b.record).refusable


if b.required or b.failsRecord or(a:strict()and not c)then l=true end
for b,a in ipairs(b.failsWith or{})do
f[a]=nil
m[a]=true
end
return
end

f[b.name]=c
end


local t={}
for b,a in ipairs(c.after or{})do
local b=h.afterField(o,a,f,p)
if b then
s(b)
t[a]=true
end
end
if l then return i(e)end
local h,q,m,n=h.frame(o,f,p,q)
a.vars=m
if not n then return i(a:fault(g,"has no kind offered here."))end
local n={}
for b,a in ipairs(h)do n[a.name]=true end


for b,f in pairs(c.moves or{})do
if d[b]~=nil and not n[b]then
local e={}
for a,b in pairs(d)do e[a]=b end
e[b]=nil

local f=f(d[b],e,n)
d=e
if a:strict()then
a:note(k(g,tostring(b)),(c.retired and c.retired[b]or"")..(f and" moved there."or" left out."))
end
end
end

local q={}
for a in pairs(d)do q[#q+1]=a end
table.sort(q,function(a,b)return tostring(a)<tostring(b)end)
for e,d in ipairs(q)do
local e=c.retired and c.retired[d]
if not n[d]and(c.unknownLeftOut or e)then


if a:strict()then
a:note(k(g,tostring(d)),e or(c.unknown and c.unknown(d,m))or"isn't known here; left out.")
else
j(a,k(g,tostring(d)))
end
elseif not n[d]then
a:fault(k(g,tostring(d)),c.unknown and c.unknown(d,m)or b.unknownField(d,h))
if a:strict()then l=true end
end
end
for b,a in ipairs(h)do
if not t[a.name]then s(a)end
end
if l then


if a:strict()and c.faultsPast then c.faultsPast(d,a,g,p,u)end
return i(e)
end
if a.mode~="import"then
for b,a in ipairs(h)do
if a.exportOnly then f[a.name]=nil end
end
end
for c,b in ipairs(a.noRules==o and{}or c.rules)do
b.fn(f,a,g)
if a.failed then return i(e)end
end

local c={}
for d,a in ipairs(h)do
if f[a.name]~=nil and not a.inherit and not(a.keep and a.keep(f,m))then
c[a.name]=b.defaultOf(a,f,m)
end
end
for a,b in pairs(c)do
if r.equal(f[a],b)then f[a]=nil end
end
return i(f)
end
b.cleanRecord=i



function b.clean(a,c,b,d)
local b=m(b,d)
local a=i(a,c,b,"")
if a==e then a=nil end
return a,b
end
