

local a,c=...
local i=c.Schema

local b={}
c.JSON=b



local d={['"']='\\"',["\\"]="\\\\",["\n"]="\\n",["\r"]="\\r",["\t"]="\\t",

["|"]="\\u007c"}
c.Debug.experimental("the export's \\u007c for |","I")

local function j(a)
return'"'..a:gsub('[%c"\\|]',function(a)
return d[a]or string.format("\\u%04x",a:byte())
end)..'"'
end



local function d(a)
if a~=a or a==math.huge or a==-math.huge then error("can't write "..tostring(a).." as JSON")end
if a==0 then return"0"end
if a==math.floor(a)and math.abs(a)<2^53 then return string.format("%.0f",a)end
for b=15,16 do
local b=string.format("%."..b.."g",a)
if tonumber(b)==a then return b end
end
return string.format("%.17g",a)
end

local function e(a)return type(a)~="table"end

local function f(a)
if type(a)=="string"then return j(a)end
if type(a)=="number"then return d(a)end
if type(a)=="boolean"then return a and"true"or"false"end
error("can't write a "..type(a).." as JSON")
end

local function k(b)
local a=0
for b in pairs(b)do a=a+1 end
return a==#b
end


local function p(a)
if e(a)then return true end
if not k(a)then return false end
for b=1,#a do
if not e(a[b])then return false end
end
return true
end

local function l(a)
if e(a)then return f(a)end
local b={}
for c=1,#a do b[c]=f(a[c])end
return"["..table.concat(b,", ").."]"
end

local q=116




local function r(c,b,e,g,h)
local a,f,d={},{},{}
for e,b in ipairs(h or{})do
if c[b]~=nil and not d[b]then
a[#a+1]=b
d[b]=true
end
end
if b then
local b,h,g=i.frame(b,c,e,g)
e=g
for e,b in ipairs(b)do
if c[b.name]~=nil then
a[#a+1]=b.name
f[b.name]=b
d[b.name]=true
end
end
end
local b={}
for a in pairs(c)do
if not d[a]then b[#b+1]=a end
end
table.sort(b,function(a,b)return tostring(a)<tostring(b)end)
for c,b in ipairs(b)do a[#a+1]=b end
return a,f,e
end

local d


local function m(b,a)
local b=b.ref=="part"and type(a)=="table"and type(a.layer)=="table"and a.layer[b.name]
if type(b)~="table"then return nil end
local a={}
for c,b in ipairs(b)do
if type(b)=="table"and b.id~=nil then a[#a+1]=b.id end
end
return a
end



local function s(b,a,g,h,e,c)
if a and(a.type=="list"or a.type=="keys")and type(b)=="table"and next(b)==nil then
c[#c+1]="[]"
return
end
if a and a.type=="keys"and type(b)=="table"and#b==1 then
c[#c+1]=f(b[1])
return
end
if a and a.type=="map"and type(b)=="table"then
d(b,g,h,nil,false,e,c,a.record,a,m(a,e))
return
end

if a and a.type=="spells"and type(b)=="table"then
d(b,g,h,i.SPELL_ENTRY,false,e,c,nil,a)
return
end
d(b,g,h,a and a.record,a and a.type=="list"and a.record~=nil,e,c,nil,a)
end

function d(b,g,t,m,c,h,a,n,o,u)
if e(b)then
a[#a+1]=f(b)
return
end
local c=c or(k(b)and next(b)~=nil)
local f,i
if not c then f,i,h=r(b,m,h,o,u)end

if n then
local a={type="record",record=n}
for c,b in ipairs(f)do i[b]=a end
end

local k=true
for b,a in pairs(b)do
if not(c and e(a)or not c and p(a))then
k=false
break
end
end
if k then
local d
if next(b)==nil then
d=c and"[]"or"{}"
elseif c then
d=l(b)
else
local e={}
for d,c in ipairs(f)do
local b,a=i[c],b[c]

if b and b.type=="keys"and type(a)=="table"and#a==1 then a=a[1]end
e[d]=j(tostring(c))..": "..l(a)
end
d="{ "..table.concat(e,", ").." }"
end
if#g+t+#d<=q then
a[#a+1]=d
return
end
end
local e=g.."  "
if c then
a[#a+1]="[\n"
for c=1,#b do
a[#a+1]=e
d(b[c],e,0,m,false,h,a,nil,o)
a[#a+1]=c<#b and",\n"or"\n"
end
a[#a+1]=g.."]"
else
a[#a+1]="{\n"
for g,c in ipairs(f)do
local d=j(tostring(c))..": "
a[#a+1]=e..d
s(b[c],i[c],e,#d,h,a)
a[#a+1]=g<#f and",\n"or"\n"
end
a[#a+1]=g.."}"
end
end



function b.write(b,c)
local a={}
d(b,"",0,c,false,{},a)
return table.concat(a)
end







local d='"interhud"%s*:%s*'

local function e(b,a)
local c,a=b:find("^%-?%d+",a)
if not a then return nil end
local c,b=b:find("^%.%d*",a+1)
return b or a
end

local function f(a)
local b=1
while true do
local c,d=a:find(d,b)
if not c then return nil end
local d=e(a,d+1)
local a=d and select(2,a:find("^%s*}",d+1))
if a then return a end
b=c+1
end
end

local function g(a)
local b=1
while true do
local c,d=a:find(d,b)
if not c then return false end
local d=e(a,d+1)
local d=d and select(2,a:find("^%s*}",d+1))
if d and a:find("^%s*$",d+1)then return true end
b=c+1
end
end




local function h(a)
local b,c,f=nil,nil,1
while true do
local d=a:find("```",f,true)
local d=d and a:find("\n",d+3,true)
if not d then break end
local e=a:find("```",d+1,true)
if not e then c=a:sub(d+1);break end
local a=a:sub(d+1,e-1)
if a:find('"interhud"',1,true)then return a end
b=b or a
f=e+3
end
if c and(c:find('"interhud"',1,true)or not b)then return c end
return b
end




function b.tidyText(a)
if type(a)~="string"then return""end
a=a:gsub("^\239\187\191","")
local b=h(a)
if b then a=b end
a=a:gsub("^\239\187\191",""):gsub("^%s+","")


local b=#a
while b>0 and a:find("^%s",b)do b=b-1 end
a=a:sub(1,b)
local b=a:find("{",1,true)
if b and b>1 then a=a:sub(b)end
local b=f(a)
local b=b or(a:find("}",1,true)and a:match(".*()}"))
if b and b<#a then a=a:sub(1,b)end
return a
end



local function h(a)
if a:sub(1,1)~="{"then return false end
local b,d,f=0,1,#a
while true do
local c,g,e=a:find('([%[%]{}"])',d)
if not c then return b==0 end
if e=='"'then

local c=c+1
while true do
local b=a:find('["\\]',c)
if not b then return false end
if a:sub(b,b)=="\\"then c=b+2 else c=b+1 break end
end
d=c
else
b=b+((e=="{"or e=="[")and 1 or-1)
if b<0 or(b==0 and c<f)then return false end
d=c+1
end
end
end



function b.tidy(a)
if type(a)~="string"then return nil,"Nothing to import."end

local i,f=a:gsub('"interhud"%s*:',"")
a=b.tidyText(a)
if a==""then return nil,"Nothing to import."end
if f>1 then
return nil,"This is two or more texts pasted together: paste one at a time."
end
if not g(a)then


if f==0 and h(a)then
local b,a=pcall(C_EncodingUtil.DeserializeJSON,a)
if b and type(a)=="table"and next(a)~=nil then
return nil,'The text has no "interhud" line: add "interhud": '..c.Store.VERSION..' as its last field.'
end
end

local d,b=a:find(d)
local a=b and a:sub(e(a,b+1)or b,-1):sub(2)
if a and a:find("[,:]")then
return nil,'Move "interhud": '..c.Store.VERSION..' to the end of the text.'
end
return nil,'The text doesn\'t end with its "interhud" line: it was cut short. Copy the whole export again.'
end
return a
end



function b.decode(a)
local b,a=pcall(C_EncodingUtil.DeserializeJSON,a)
if not b then

local a=tostring(a):gsub("\n[^\n]*[Tt]aint[^\n]*$","")
return nil,"This isn't valid JSON: "..a
end
if type(a)~="table"or next(a)==nil or#a>0 then
return nil,"This isn't InterHUD's text, or it was changed partway (a curly quote?)."
end
return a
end
