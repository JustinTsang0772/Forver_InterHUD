


local a,c=...
local b=c.Schema
local l=c.Clean

local a={}
c.Resolve=a

























local d




local e=setmetatable({},{__mode="k"})
c.onChanged(function()wipe(e)end,"resolve presets")
function a.preset(a,d,f)
local c=type(a)=="table"and type(a.presets)=="table"and a.presets or nil
if not c or f==nil then return nil end
local a=e[c]
if not a then
a={}
for d,b in ipairs(b.STYLE_PARTS)do
local d={}
for b,a in ipairs(type(c[b])=="table"and c[b]or{})do
if type(a)=="table"and a.id~=nil and d[a.id]==nil then d[a.id]=a end
end
a[b]=d
end
e[c]=a
end
return a[d]and a[d][f]
end



local function f(c,d,b)
if type(b)~="table"or b.preset==nil then return b end
local a=a.preset(c,d,b.preset)
if not a then return nil end
return a.style or{}
end

local function h(a,b,e,f)
if a.type=="record"then
return d(a.record,b or{},e,f,a)
elseif a.type=="list"and a.record then
local c={}
for b,g in ipairs(b or{})do c[b]=d(a.record,g,e,f,a)end
return c
elseif a.type=="map"then
local c={}
for b,g in pairs(b or{})do c[b]=d(a.record,g,e,f,a)end
return c
elseif type(b)=="table"then
return c.copy(b)
end
return b
end


local function i(a,c,g,d,e)
local b=c[a.name]
if a.style then b=f(d.profile,a.style,b)end
if b~=nil then return b end
if a.inherit then
local a=d.inherit(a,c,e)
if a~=nil then return a end
end
return l.defaultOf(a,g,e)
end







local e={}
local function f(a)
if e[a]~=nil then return e[a]end
e[a]=false
local b=b.get(a)
local c=not(b.after or b.variantOf or b.extra or b.finish)
for b,a in ipairs(c and b.fields or{})do
if a.defaultFrom or a.inherit or a.style
or a.record and(a.type=="record"or a.default~=nil)and not f(a.record)then
c=false
end
end
e[a]=c
return c
end





local m={}
local n={}
local function j(d,k,l,j,e)
local g=d.fact
local g=g.default and g.default(e.source)
if not(g and next(g)==nil and f(d.record))then return nil end
local g=m[d]
if not g then
g={}
m[d]=g
end
local m=e.kind==nil and n or e.kind
local f=g[m]
if not f then
f=h(d,i(d,k,l,j,e),j,e)
for c,a in ipairs(f)do b.constItem(a)end
g[m]=f
elseif a.narrowCheck then
local b=h(d,i(d,k,l,j,e),j,e)
if not c.equal(f,b)then a.narrowCheck(k,f,b)end
end
return f
end



function d(f,c,d,e,k)
local g=b.get(f)
local a={}
for j,g in ipairs(g.after or{})do
local b=b.afterField(f,g,a,e)
if b then a[g]=h(b,i(b,c,a,d,e),d,e)end
end
local b,f,e=b.frame(f,a,e,k)
for f,b in ipairs(b)do
if a[b.name]==nil then
local f=b.fact~=nil and b.type=="list"and c[b.name]==nil and j(b,c,a,d,e)
if f then
a[b.name]=f
else
local c=i(b,c,a,d,e)
if c~=nil or b.type=="record"then a[b.name]=h(b,c,d,e)end
end
end
end
if g.finish then g.finish(c,a,e)end
return a
end


local function m(a,b)
local a=a and(c.Styles.isLook(b)and a.buttonCues or a.styles)
return a and a[b]
end


local g


function a.stylePart(a,b)
local c=m(a,b)
if g and g.profile==a then g.parts[b]=c or false end
return c
end


local function f(b,d)
for c,a in ipairs(c.Layers.partsOf(b.kind))do
local b=b[a.key]
if a.list then
for b,c in ipairs(b or{})do d(c,a.key,b,a.kind)end
elseif type(b)=="table"then
d(b,a.key,nil,a.kind)
end
end
end
a.eachPart=f


local function h(a)
local b
for c,a in pairs(a)do
if type(a)=="table"then a=h(a)end
if a~=nil then
b=b or{}
b[c]=a
end
end
return b
end
a.pruned=h



local function e(c,d)
local b={}
for a,c in pairs(c)do b[a]=c end
local a=c.style and{}or nil
for b,c in pairs(c.style or{})do a[b]=c end
for c,d in pairs(d)do
if a and a[c]~=nil then a[c]=d end
b[c]=d
end
b.style=a
return b
end


local function p(d,b)
local a={}
for b,c in pairs(d)do a[b]=c end
a.looks,a.compiled=nil,nil
local f={}
for b,a in ipairs(c.Layers.partsOf(d.kind))do f[a.key]=a.list end
for b,c in pairs(b)do
local d=d[b]
if type(c)~="table"then
a[b]=c
elseif f[b]and type(d)=="table"then
local f={}
for b,a in ipairs(d)do f[b]=c[a.id]and e(a,c[a.id])or a end
a[b]=f
elseif type(d)=="table"then
a[b]=e(d,c)
end
end
return a
end


local function i(b,c)
if b==nil then return c end
if c==nil then return b end
local a={}
for b,c in pairs(b)do a[b]=c end
for b,c in pairs(c)do
if type(c)=="table"and type(a[b])=="table"then a[b]=i(a[b],c)else a[b]=c end
end
return a
end
a.merged=i




function a.canonical(c,a)
local b,d=b.splitKey(c)
if d then return c end
if a and a.words[b]and a.words[b].what~="event"then return a.rec.id.."."..b end
return b
end





local function j(d,a,f)
local e=c.Layers.get(d.kind)
if type(a)=="string"then
local b=type(d[a])=="table"and d[a].style
local a=b or f and f[a]
return a and e and e.buttonCue and e.buttonCue(a)or nil
elseif type(a)=="table"then
local e
for a,f in pairs(a)do
if b.has("look:"..d.kind)and b.field("look:"..d.kind,a)then
e=e or{}
e[a]=c.copy(f)
end
end
return e
end
end
a.globalValues=j

local function e(a)
if a==nil then return{}end
if type(a)=="table"then return a end
return{a}
end
local k={["while"]=true,unless=true}

local function n(b)
local a={}
for b,c in pairs(b)do
if not k[b]then a[b]=c end
end
return h(a)
end
a.valuesOf=n




function a.lookOn(a,c,d)
local a=type(a)=="table"and type(a.looks)=="table"and a.looks or{}
for e,a in ipairs(a)do
if type(a)=="table"then
local a,b=a["while"],a.unless
if type(a)=="table"then a=#a==1 and a[1]or nil end
if(b==nil or(type(b)=="table"and#b==0))and(a==c or(d~=nil and a==d.."."..c))then
return e
end
end
end
end





local function q(h,d,i)
local g,f=d.spec,d.rec
local c={source=f.id,kind=b.layerKind(f),stateOrder=g.stateOrder or{},factOrder=g.factOrder,
states={},stateValues={},flags={},global={},borrowed={},factOn={}}
for g,h in ipairs(h.looks or{})do
local i,k=e(h["while"]),e(h.unless)
local h=n(h)
local j=#i==1 and#k==0 and a.canonical(i[1],d)or nil
local b,l=b.splitKey(j)
local e=l==f.id and d.words[b]or nil
if e and e.what=="state"then
c.states[b]=c.states[b]or{}
local a=c.states[b]
a[#a+1]=g
c.stateValues[g]=h
else
local e={i=g,["while"]={},unless={},values=h}
for b,c in ipairs(i)do e["while"][b]=a.canonical(c,d)end
for b,c in ipairs(k)do e.unless[b]=a.canonical(c,d)end
if h==nil and j then e.borrow=j end
c.flags[#c.flags+1]=e
if e.borrow and l==f.id then c.borrowed[b]=true end
end
end
local e=type(f.facts)=="table"and f.facts or{}
for d,a in ipairs(g.factOrder)do
local d=g.facts[a]
if not b.isListFact(d)and d.look then
c.global[a]=j(h,d.look,i)


local b=h[a]
c.factOn[a]=not(type(e[a])=="table"and e[a].enabled==false)
and not(type(b)=="table"and b.enabled==false)
end
end
return c
end


local function n(a,b)
for c,b in ipairs(b)do
if not a(b)then return false end
end
return true
end

local function o(a,b)
for c,b in ipairs(b)do
local a,b=a(b)
if a or b then return false end
end
return true
end


local function h(c,a,b)
for c,d in pairs(c)do
local a=a==""and tostring(c)or(a.."."..tostring(c))
if type(d)=="table"then h(d,a,b)else b(a)end
end
end









function a.lookAt(d,e,f)
local b=d.compiled
local e=type(e)=="function"and e or function(a)return e~=nil and e[a]==true end
if f then
for b,a in ipairs(a.leafPaths(d))do f[a]="base"end
end
if not b then return d end
local a
local function g(b,d)
if not b then return end
a=i(a,c.copy(b))
if f then h(b,"",function(a)f[a]=d end)end
end
for c,a in ipairs(b.stateOrder)do
if b.states[a]and e(b.source.."."..a)then
for c,a in ipairs(b.states[a])do g(b.stateValues[a],a)end
break
end
end
for c,a in ipairs(b.factOrder)do
if b.global[a]and not b.borrowed[a]and b.factOn[a]and e(b.source.."."..a)then
g(b.global[a],"global:"..a)
end
end
for b,a in ipairs(b.flags)do
if n(e,a["while"])and o(e,a.unless)then
if a.borrow then
g(d.borrowed and d.borrowed[a.borrow],a.i)
else
g(a.values,a.i)
end
end
end
if not a then return d end
return p(d,a)
end





local h={}
function a.leafPaths(d,e)
e=e or(type(d.compiled)=="table"and d.compiled.kind)or nil
local f={}
for b,a in ipairs(c.Layers.partsOf(d.kind))do
if a.list then
for c,b in ipairs(type(d[a.key])=="table"and d[a.key]or{})do f[#f+1]=a.key..":"..tostring(b.id)end
end
end
local a=tostring(d.kind).."|"..tostring(e).."|"..table.concat(f,",")
if h[a]then return h[a]end
local c={}
local f="look:"..tostring(d.kind)
if b.has(f)then
for f,a in ipairs(b.get(f).fields)do
local e=not(a.serves and e and not a.serves[e])
if e and a.type=="record"then
for d,b in ipairs(b.get(a.record).fields)do c[#c+1]=a.name.."."..b.name end
elseif e and a.type=="map"then
for e,d in ipairs(type(d[a.name])=="table"and d[a.name]or{})do
for e,b in ipairs(b.get(a.record).fields)do
c[#c+1]=a.name.."."..tostring(d.id).."."..b.name
end
end
elseif e and a.type~="record"and a.type~="map"and not k[a.name]then
c[#c+1]=a.name
end
end
end
h[a]=c
return c
end









function a.holds(a,d,c)
d=d or{}
c=c or b.keyIndex(a)
local g,i,j={},{},{}
local f
local function a(a)
if g[a]~=nil then return g[a],j[a]end
local b=c.customStates[a]
if not b or b.rec.enabled==false or i[a]then return false end


if d.held~=nil and d.held[a]==true then
g[a]=true
return true
end
i[a]=true
local b=b.rec
local h=false
for c,a in ipairs({"all","any","none"})do
for b,a in ipairs(b[a]~=nil and e(b[a])or{})do
local b,a=f(a)
if a then h=true end
end
end
local c=not h
if c and b.all~=nil then c=n(f,e(b.all))end
if c and b.any~=nil then
local a=false
for c,b in ipairs(e(b.any))do
if f(b)then a=true break end
end
c=a
end
if c and b.none~=nil then c=o(f,e(b.none))end

if c and type(b.hold)=="table"and b.hold.after~=nil then c=d.held~=nil and d.held[a]==true end
i[a]=nil
g[a],j[a]=c,h
return c,h
end
f=function(e)
local e,f=b.splitKey(e)
if f==b.GAME then return d.game~=nil and d.game[e]==true end
if f==nil then return a(e)end
local g=c.sources[f]
local a=g and g.words[e]
if not a or a.on==false then return false end
local c=d[f]or{}
local d=c.state~=nil and g.words[c.state]
if d and d.what=="state"and d.class=="held"then return false,true end
if a.what=="state"then return c.state==e end
if a.what=="fact"or a.what=="item"then
if not b.holdsWithin(a.within,c.state)then return false end
return c.facts~=nil and c.facts[e]==true
end
return false
end
return f
end


function a.groupOf(a,b)
for c,a in ipairs(a and a.groups or{})do
for d,c in ipairs(a.members or{})do
if c==b then return a end
end
end
end

function a.group(c,b)
return d("group",c,{profile=b,inherit=function(c)
if c.inherit=="global"then return a.stylePart(b,c.style)end
end},{})
end

local e={inherit=function()end}

function a.buttonCues(a)
local f=a and a.buttonCues or{}
local c={}
for b,a in ipairs(b.get("buttonCues").fields)do
c[a.name]=d(a.record,f[a.name]or{},e,{})
end
return c
end



function a.compileLayer(a,d,e,c)
a.compiled=q(a,d,c)

for f,d in ipairs(a.compiled.flags)do
local f,b=b.splitKey(d.borrow)
local b=b and e.sources[b]
local b=b and b.words[f]
if b and b.what=="fact"and b.fact.look then
a.borrowed=a.borrowed or{}
a.borrowed[d.borrow]=j(a,b.fact.look,c)
end
end
end





local function n(d)
local e=b.keyIndex(d)
d.layers,d.effects={},{}
d.sourcesById,d.customStatesById={},{}
for c,a in ipairs(d.sources or{})do
if a.id then d.sourcesById[a.id]=a end
a.variant=b.variantKey(a)
end
for b,a in ipairs(d.customStates or{})do
if a.id then d.customStatesById[a.id]=a end
end
for b,g in ipairs(d.sources or{})do
local h=e.sources[g.id]
for i,b in ipairs(g.layers or{})do
d.layers[#d.layers+1]=b
b.index,b.source=#d.layers,g.id
b.scale=d.rootScale
f(b,function(a,f,g,e)
a.scale=d.rootScale

for d,c in ipairs(c.Layers.part(e).fromLayer or{})do a[c]=b[c]end
end)
local c=b.border
b.framedBy=b.kind=="icon"and type(c)=="table"and c.enabled~=false and c.shown~=false
and c.style or nil
f(b,function(a)a.framedBy=b.framedBy end)

local f=b.kind=="icon"and type(b.sweep)=="table"and b.sweep.style or nil
if type(b.gcdSweep)=="table"then b.gcdSweep.sweep=f end
if type(c)=="table"then c.onBar=b.kind=="bar"or nil end
if h then a.compileLayer(b,h,e,d.buttonCues)end
end
end

b.eachRecord("element",d,function(e,c,f,a)

if e~="effect"then return not b.isConstItem(c)end
local b={moment=a.moment or"plain",event=a.event and a.event.word}
local e=a.source
b.source=type(e)=="table"and e.id or nil
b.fact=a.fact and a.fact.word
c.at,c.scale=b,d.rootScale
d.effects[#d.effects+1]=c
return false
end)

for b,a in ipairs(d.customStates or{})do
for c,b in pairs(type(a.events)=="table"and a.events or{})do
for c,b in ipairs(type(b)=="table"and b.effects or{})do b.at.customState,b.at.source=a.id,nil end
end
end
for b,a in ipairs(d.sources or{})do
for c,a in pairs(type(a.facts)=="table"and a.facts or{})do
for b,a in ipairs(#a>0 and a or{})do
for d,b in pairs(type(a.events)=="table"and a.events or{})do
for d,b in ipairs(type(b)=="table"and b.effects or{})do b.at.item,b.at.fact=a.id,c end
end
end
end
end
return e
end


local function k(c,f)
local e=a.groupOf(f,c.id)
local e=e and a.group(e,f)


local g=false
for b,a in ipairs(b.SHOWING)do
if c[a]~=nil then g=true end
end
local g={
profile=f,
inherit=function(b)
if b.inherit=="global"then return a.stylePart(f,b.style)end
if b.inherit=="group"and e and(b.name=="opacity"or not g)then
return e[b.name]
end
end,
}
local h=c.baseSize or l.defaultOf(b.field("element","baseSize"),c,{})
local c=d("element",c,g,{elementSize=h})

if not e then c.opacity=100 end

c.groupScale=e and e.scale or 1

c.rootScale=c.groupScale*(c.scale or 1)
c.groupArrangement=e and e.arrangement

c.groupOn=e==nil or e.enabled~=false
c.alert=b.holdsAlert(c)or nil
c.buttonCues=a.buttonCues(f)
return c,n(c)
end








local h=setmetatable({},{__mode="k"})
local j=setmetatable({},{__mode="k"})
local o=setmetatable({},{__mode="k"})



local p=setmetatable({},{__mode="k"})
local i=0
local f={}
local l
local function q(d,a)
local b=c.Store
if not(b and b.ready()and a==b.profile())then return false end
if l~=a.elements then
wipe(f)
for b,a in ipairs(a.elements or{})do f[a]=true end
l=a.elements
end
return f[d]==true
end
c.onChanged(function(a,b)
l=nil
if a=="group"and b then
local a=c.Store.group(b)
local c={}
for b,a in ipairs(a and a.members or{})do c[a]=true end
for a in pairs(h)do
if o[a]==b or c[a.id]then h[a]=nil end
end
elseif a=="styles"then
i=i+1
elseif a~="element"then
wipe(h)
end
end,"resolve kept views")



local function l(a,b)
if b.presets~=a.presets or b.buttonCues~=a.buttonCues then
return false
end
for d,a in pairs(a.parts)do
local b=m(b,d)or false
if b~=a and not(type(b)=="table"and type(a)=="table"and c.equal(b,a))then return false end
end
return true
end




a.narrowCheck=false

function a.element(d,f)
if not q(d,f)then return(k(d,f))end
local e=h[d]
if e then
local b=p[d]
if b.gen~=i then
if l(b,f)then b.gen=i else e=nil end
end
if e and a.narrowCheck then
local b=k(d,f)
if not c.equal(e,b)then a.narrowCheck(d,e,b)end
end
end
if not e then
local c={gen=i,parts={},profile=f}

local l=g
g=c
local i
e,i=k(d,f)
g=l
c.profile=nil
c.presets,c.buttonCues=f.presets,f.buttonCues
b.freeze(e,i)
j[e]=true
h[d],p[d]=e,c
local a=a.groupOf(f,d.id)
o[d]=a and a.id or false
end
return e
end







local function f(d,g)
local a={}
for b,c in pairs(d)do a[b]=c end
local function e(b)
local a={}
for b,c in pairs(b)do a[b]=c end
return a
end
local f={}
for b,a in ipairs(d.sources or{})do
if a.enabled~=false and not c.Sources.unset(a)and not(g and not g(a))then
local d=e(a)
local b={}
for d,a in ipairs(a.layers or{})do
if a.enabled~=false then
local a=e(a)
for c,b in ipairs(c.Layers.partsOf(a.kind))do
local c=a[b.key]
if b.list and c then
local d={}
for b,a in ipairs(c)do
if a.enabled~=false then d[#d+1]=e(a)end
end
a[b.key]=d
elseif type(c)=="table"then
a[b.key]=e(c)
end
end
b[#b+1]=a
end
end
d.layers=b
f[#f+1]=d
end
end
a.sources=f
local e=n(a)


a.allLayers=d.allLayers or d.layers

local c={}
for b,a in ipairs(a.effects)do
if a.enabled~=false then c[#c+1]=a end
end
a.effects=c
b.freeze(a,e)
j[a]=true
return a
end



local function g(a,b)
if a.sources==nil then return true end
for d,a in ipairs(a.sources)do
if a.enabled==false or c.Sources.unset(a)or(b and not b(a))then return true end
if a.layers==nil then return true end
for b,a in ipairs(a.layers or{})do
if a.enabled==false then return true end
for c,b in ipairs(c.Layers.partsOf(a.kind))do
if b.list then
for b,a in ipairs(a[b.key]or{})do
if a.enabled==false then return true end
end
end
end
end
end
return false
end





local function h(a)
local c={}
for a,b in pairs(a)do c[a]=b end
c.allLayers=a.allLayers or a.layers
local d=false
for b,a in ipairs(a.effects or{})do
if a.enabled==false then d=true break end
end
if d then
local b={}
for c,a in ipairs(a.effects)do
if a.enabled~=false then b[#b+1]=a end
end
c.effects=b
end
if not j[a]then
b.freeze(c)
j[c]=true
end
return c
end

function a.drawn(b,d)
if g(b,d)then return f(b,d)end
local e=h(b)
if a.narrowCheck then
local d=f(b,d)
if not c.equal(e,d)then a.narrowCheck(b,e,d)end
end
return e
end



local function h(b)
local a=c.Sources.get(b.kind)
return not(a and a.learned)or a.learned(b)
end
a.kindLearned=h

local function f(a)
if a.enabled==false or c.Sources.unset(a)then return nil end
local b=c.Sources.get(a.kind)
local a=b and b.yourSpells and b.yourSpells(a)
return a and#a>0 and a or nil
end

local function g(a)
for b,a in ipairs(a.layers or{})do
if a.enabled~=false then return true end
end
return false
end


local function i(a)
local b=nil
for c,a in ipairs(a and a.sources or{})do
if f(a)then
if g(a)then return true end
b=false
end
end
return b
end




function a.youKnowFrom(b)
local a,c={},{}
local d=i(b)
if d==nil then return a end
for e,b in ipairs(b.sources)do
local b=g(b)==d and f(b)
for d,b in ipairs(b or{})do
if not c[b]then
c[b]=true
a[#a+1]=b
end
end
end
return a
end




function a.youKnow(a)
local b=a and a.onlyWhileYouKnow
if type(b)=="table"and#b>0 then
for b,a in ipairs(b)do
if c.Spells.knowsAtLeast(a)then return true end
end
return false
end
local b=i(a)
if b==nil then return true end
for c,a in ipairs(a.sources)do
if g(a)==b and f(a)and h(a)then return true end
end
return false
end

function a.record(a,b)
return d(a,b or{},e,{})
end


function a.styles(f)
local c={}
for g,b in ipairs(b.STYLE_PARTS)do
c[b]=d("style:"..b,a.stylePart(f,b)or{},e,{})
end
return c
end





function a.special(e,f,c)
local b=b.field("specials",e)
if not(b and b.record)then return nil end
return d(b.record,f or{},{profile=c,inherit=function(b)
if b.inherit=="global"then return a.stylePart(c,b.style)end
end},{})
end



b.get("layer").finish=function(d,a,b)
local c=c.Layers.get(a.kind)
if c and c.finish then c.finish(d,a,b)end
a.fill=d.position==nil
a.width=a.width or b.elementSize
a.height=a.height or b.elementSize
end
