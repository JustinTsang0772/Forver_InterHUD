


local a,c=...

local a=c.Schema or{}
c.Schema=a














































local b={}


a.GROUPS={font="Font",motion="Motion",place="Place",ring="Ring"}
function a.groupLabel(b)return a.GROUPS[b]or b end
local d={}













function a.record(c,e)
d={}
local a=b[c]
if not a then
a={name=c,fields={},byName={},variants={},variantOrder={},rules={}}
b[c]=a
end
for b,d in pairs(e)do
if b=="fields"then
for d,b in ipairs(d)do
assert(not a.byName[b.name],c..": field declared twice: "..b.name)
a.fields[#a.fields+1]=b
a.byName[b.name]=b
end
else
a[b]=d
end
end
return a
end



function a.variant(e,c,f,g)
d={}
local b=b[e]or a.record(e,{})
assert(not b.variants[c],e..": variant declared twice: "..c)
local a={key=c,fields={},byName={},meta=g or{}}
for c,b in ipairs(f or{})do
a.fields[#a.fields+1]=b
a.byName[b.name]=b
end
b.variants[c]=a
b.variantOrder[#b.variantOrder+1]=c
return a
end




function a.rule(c,d,e)
local a=b[c]or a.record(c,{})
a.rules[#a.rules+1]={name=d,fn=e}
end


function a.get(a)
local b=b[a]
if not b then error("no record declared: "..tostring(a),2)end
return b
end
function a.has(a)return b[a]~=nil end
function a.recordNames()
local a={}
for b in pairs(b)do a[#a+1]=b end
table.sort(a)
return a
end



function a.groupGaps()
local c={}
local function d(e,a)
local d,b={},nil
for f,a in ipairs(a)do
if a.group~=b then
if b then d[b]=true end
if a.group and d[a.group]then c[#c+1]=e..": "..a.group end
b=a.group
end
end
end
for e,c in ipairs(a.recordNames())do
local b=b[c]
d(c,b.fields)
for e,b in ipairs(b.variantOrder)do d(c.."."..b,a.fieldsOf(c,b))end
end
return c
end


function a.variantKeys(b,c)
local d=a.get(b)
local a={}
for e,b in ipairs(d.variantOrder)do
if not c or c(d.variants[b].meta,b)then a[#a+1]=b end
end
return a
end


function a.extendVariant(c,e,f)
d={}
local b=assert(a.get(c).variants[e],c..": no variant "..tostring(e))
for d,a in ipairs(f)do
assert(not b.byName[a.name],c.."."..e..": field declared twice: "..a.name)
b.fields[#b.fields+1]=a
b.byName[a.name]=a
end
end

function a.moveLast(c,b,d)
local a=a.get(c)
local a=b and a.variants[b].fields or a.fields
for c,b in ipairs(a)do
if b.name==d then
table.remove(a,c)
a[#a+1]=b
return
end
end
end



function a.fieldsOf(c,b)
local c=a.get(c)
local a=b and c.variants[b]
if not a then return c.fields end
local b=a.allFields
if b and b.common==#c.fields and b.own==#a.fields then return b.list end
local b={}
for c,a in ipairs(c.fields)do b[#b+1]=a end
for c,a in ipairs(a.fields)do b[#b+1]=a end
a.allFields={common=#c.fields,own=#a.fields,list=b}
return b
end

function a.field(d,b,c)
local a=a.get(d)
local c=c and a.variants[c]
return a.byName[b]or(c and c.byName[b])
end



local e=setmetatable({},{__mode="k"})
local f={}
local function h(a,g)
local d=g.kind
local c=e[a]
local b=c and c[d==nil and f or d]
if b and b.n==#a then return b.list end
local b
for d,c in ipairs(a)do
if c.serves and not c.serves[g.kind]then
if not b then
b={}
for c=1,d-1 do b[c]=a[c]end
end
elseif b then
b[#b+1]=c
end
end
if not c then
c={}
e[a]=c
end
c[d==nil and f or d]={n=#a,list=b or a}
return b or a
end



local f=setmetatable({},{__mode="kv"})
local i={}




function a.frame(g,e,d,j)
local b=a.get(g)
local c
if d==nil then
c=i
else
c=f[d]
if not c then
c={__index=d}
f[d]=c
end
end
local c=setmetatable({},c)
if b.context then b.context(e,c,j)end
local d
if b.variantOf then
d=b.variantOf(e,c)
if d==nil or not b.variants[d]then return b.fields,nil,c,false end
end
local f=h(a.fieldsOf(g,d),c)

local b=b.extra and b.extra(e,c)
if b and#b>0 then
local a={}
for b,c in ipairs(f)do a[b]=c end
for c,b in ipairs(b)do a[#a+1]=b end
f=a
end
return f,d,c,true
end



function a.afterField(c,b,d,e)
local a=a.get(c)
if a.byName[b]then return a.byName[b]end
local c=a.variantOf and a.variantOf(d,e)
local a=c and a.variants[c]
return a and a.byName[b]
end



local e,g,f={},{},{}
function a.choiceSet(b,d,c,h)
local a=e[b]
if not a then
a={}
e[b]=a
f[b]={}
end
for c,b in ipairs(d or{})do
local c=false
for d,a in ipairs(a)do
if a==b then c=true end
end
if not c then a[#a+1]=b end
end
if c~=nil then g[b]=c end
for a,c in pairs(h or{})do f[b][a]=c end
return a
end
function a.choicesOf(a)
return function()return e[a]or{}end
end
function a.choiceDefault(a)
return g[a]or(e[a]and e[a][1])
end
function a.choiceLabels(a)
return f[a]or{}
end





local e,f={},{}
function a.caveat(a,b)
assert(not e[a],"caveat registered twice: "..a)
b.key=a
e[a]=b
f[#f+1]=a
end

function a.caveatCanSit(a,b)
for d,c in ipairs(f)do
if e[c].at(a,b or{})then return true end
end
return false
end


function a.caveatsSitting(c,d)
local a={}
for f,b in ipairs(f)do
if e[b].at(c,d or{})then a[#a+1]=e[b]end
end
return a
end


function a.caveatsAt(g,c,d)
local a={}
for f,b in ipairs(f)do
local b=e[b]
if b.at(c,d or{})and b.applies(g,c,d or{})then a[#a+1]=b end
end
return a
end

function a.isPath(a,...)
local b={...}
if#a~=#b then return false end
for c,b in ipairs(b)do
if b~="*"and a[c]~=b then return false end
end
return true
end



a.STYLE_PARTS={"border","sweep","pressed","glow","flash","pop","font","barTexture"}





function a.styleField(a,b,c)
return{name="style",type="record",record=c or("style:"..a),style=a,inherit="global",
label=b or"Style",keepEmpty="own"}
end




local function h(a,c)
if d[a]~=nil then return d[a]end
c=c or{}
if c[a]then return false end
c[a]=true
local b=b[a]
local e=false
local function f(a)
for b,a in ipairs(a)do
if e then return end
e=a.style~=nil or(a.record~=nil and h(a.record,c))
end
end
if b then
f(b.fields)
for c,a in ipairs(b.variantOrder)do f(b.variants[a].fields)end
end
c[a]=nil
d[a]=e
return e
end





function a.eachStyleField(b,d,c,e,f,g)
if type(d)~="table"then return end
f=f or""
local b,c,g=a.frame(b,d,c or{},g)
for c,b in ipairs(b)do
local c=d[b.name]
if type(c)=="table"and(b.style or(b.record and h(b.record)))then
local f=f==""and b.name or(f.."."..b.name)
if b.style then
e(b,c,d,f,g)
elseif b.type=="record"then
a.eachStyleField(b.record,c,g,e,f,b)
elseif b.type=="list"and b.record then
for c,d in ipairs(c)do a.eachStyleField(b.record,d,g,e,f.."["..c.."]",b)end
elseif b.type=="map"then
for c,d in pairs(c)do a.eachStyleField(b.record,d,g,e,f.."."..tostring(c),b)end
end
end
end
end





function a.eachStyleSlot(b,d,c,e,f)
if type(d)~="table"then return end
local b,c,f=a.frame(b,d,c or{},f)
for c,b in ipairs(b)do
local c=d[b.name]
if b.style then
e(b,c,d)
elseif b.record and h(b.record)then
if b.type=="record"then
local g=type(c)=="table"and c or{}
a.eachStyleSlot(b.record,g,f,e,b)
if c==nil and next(g)then d[b.name]=g end
elseif b.type=="list"and type(c)=="table"then
for d,c in ipairs(c)do a.eachStyleSlot(b.record,c,f,e,b)end
elseif b.type=="map"and type(c)=="table"then
for d,c in pairs(c)do a.eachStyleSlot(b.record,c,f,e,b)end
end
end
end
end




function a.numberedName(a,f,d)
if not d(a)then return a end
local c=2
local b,e=a:match("^(.-%S) (%d+)$")
if b and#e<=6 then a,c=b,tonumber(e)+1 end
while true do
local e=" "..c
local b=math.max(0,f-#e)
while b>0 and a:byte(b+1)and a:byte(b+1)>=128 and a:byte(b+1)<192 do b=b-1 end
local a=a:sub(1,b):gsub("%s+$","")..e
if not d(a)then return a end
c=c+1
end
end




function a.eachProfileStyleField(b,c)
if type(b)~="table"then return end
for d,b in ipairs(type(b.elements)=="table"and b.elements or{})do
local d={kind="element",key=type(b)=="table"and b.id or nil}
a.eachStyleField("element",b,{},function(a,b,e,f,g)c(a,b,e,f,d,g)end)
end
local d=type(b.specials)=="table"and b.specials or{}
for e,b in ipairs(a.fieldsOf("specials"))do
if b.record and type(d[b.name])=="table"then
local e={kind="special",key=b.name}
a.eachStyleField(b.record,d[b.name],{},function(a,b,d,f,g)
c(a,b,d,f,e,g)
end)
end
end
end




a.GAME="game"
local d,e={},{}
function a.gameFact(a,b)
assert(not d[a],"game fact declared twice: "..a)
b.word,b.read=a,b.read or"lua"
d[a]=b
e[#e+1]=a
end
function a.gameFactSpec(a)return d[a]end
function a.gameFacts()return e end

















local d,f={},{}

local function g()
return{
{name="id",type="id",label="Id"},
{name="name",type="string",max=48,label="Name"},
{name="enabled",type="boolean",default=true,label="On"},
{name="events",type="record",record="changeEvents",label="Events"},
}
end

function a.isListFact(a)return type(a)=="table"and a.setting~=nil end

function a.isRangeFact(a)
local a=type(a)=="table"and a.setting
return type(a)=="table"and#a==3 and a[1].name=="atLeast"and a[2].name=="atMost"and a[3].name=="between"
end
a.LIST_MAX=16

function a.sourceVariant(e,b)
assert(not d[e],"source variant declared twice: "..e)
b.key=e
b.read,b.moment=b.read or"lua",b.moment or"plain"
b.factOrder,b.facts=b.factOrder or{},b.facts or{}
b.eventOrder,b.events=b.eventOrder or{},b.events or{}
d[e]=b
f[#f+1]=e
local d={}
for f,c in ipairs(b.factOrder)do
local b=b.facts[c]
b.word=c
if a.isListFact(b)then
local e="factItem:"..e..":"..c
local f=g()
for b,a in ipairs(b.setting)do f[#f+1]=a end
a.record(e,{fields=f,idSpace="source",unit=false,retired=b.retired,
madeId=function()return c end,
context=function(c,a)a.fact=b end})
if b.rule then a.rule(e,c,b.rule)end
if b.finish then a.get(e).finish=b.finish end
d[#d+1]={name=c,type="list",record=e,maxItems=a.LIST_MAX,cap=b.max,
fact=b,label=b.label,help=b.holds,

defaultFrom=function(d,a)
local a=b.default and b.default(a.source)
if not a then return{}end
a.id=c
return{a}
end,
keep=function(a)return type(a[c])=="table"and#a[c]==0 end}
else
d[#d+1]={name=c,type="record",record="fact",fact=b,label=b.label,
help=b.holds}
end
end
a.variant("facts",e,d)
local c={}
for a,d in ipairs(b.eventOrder)do
local a=b.events[d]
a.word=d
c[#c+1]={name=d,type="record",record="event",event=a,label=a.label,
help=a.holds}
end
a.variant("events",e,c)
return b
end

function a.source(a)return a~=nil and d[a]or nil end
function a.sourceKeys()return f end



function a.variantKey(a)
if type(a)~="table"or a.kind==nil then return nil end
local b=b.source and b.source.variants[a.kind]
local b=b and b.meta.variantOf
if b then return b(a)end
return a.kind
end
function a.variantOf(b)return d[a.variantKey(b)or false]end



function a.sourceVars(c,b)
local a=a.variantKey(c)
local d=a and d[a]
b.source,b.variant,b.spec=c,a,d
b.kind=d and d.layerKind or type(c)=="table"and c.kind or nil
return b
end


function a.layerKind(b)
local a=d[a.variantKey(b)]
return a and a.layerKind or type(b)=="table"and b.kind or nil
end


function a.sourceTypeLabel(b)
local a=b and a.source(a.variantKey(b))
return a and a.add and a.add.label or tostring(b and b.kind or"")
end





local function e(a)return a:match("^(.-) (%S+)$")end
local g={["of"]=true,["the"]=true,["a"]=true,["an"]=true,["and"]=true,["or"]=true,
["to"]=true,["for"]=true,["with"]=true,["in"]=true,["on"]=true,["at"]=true,["by"]=true}
local function h(a)
local a=a:match("(%S+)$")or""
return not a:match("%p$")and not g[a:lower()]
end
function a.namesWords(a)
local b,c={},{}
for d,a in ipairs(a)do
if not c[a]then
c[a]=true
b[#b+1]=a
end
end
a=b
if#a==0 then return""end
if#a==1 then return a[1]end
if#a>4 then
return table.concat(a,", ",1,3).." or "..(#a-3).." more"
end

local c,b={},nil
for f,a in ipairs(a)do
local a,d=e(a)
if not a or(b and d~=b)or not h(a)then
c,b=nil,nil
break
end
c[f],b=a,d
end
local a=c or a
local a=table.concat(a,", ",1,#a-1).." or "..a[#a]
return b and(a.." "..b)or a
end



function a.sourceWords(b)
if c.Sources.unset(b)then return a.sourceTypeLabel(b)end
local d=b and b.kind and c.Sources.get(b.kind)
if d and d.wordsFirst and d.words(b)then return d.words(b)end
local f=c.Spells.listOf(b and b.spells)
local e={}

for b,a in ipairs(f)do e[b]=c.Spells.label(a)or tostring(a)end
if#e==0 then
local c=d and d.words and d.words(b)
return c or a.sourceTypeLabel(b)
end
return a.namesWords(e)
end



local function e(b)
local a=c.Sources.get(b.kind)
local a=a and a.idWord
if type(a)=="function"then a=a(b)end
return a or b.kind
end
function a.sourceName(d,b)
if type(b.name)=="string"and b.name~=""then return b.name end
local c=a.sourceWords(b)
for f,d in ipairs(type(d)=="table"and d or{})do
if d~=b and type(d)=="table"and a.sourceWords(d)==c then
return c.." · "..e(b)
end
end
return c
end

function a.customStateName(a)
return type(a.name)=="string"and a.name~=""and a.name or tostring(a.id)
end


function a.sourceFields()
return{
{name="facts",type="record",record="facts",label="Facts"},
{name="layers",type="list",record="layer",maxItems=32,label="Layers"},
{name="events",type="record",record="events",label="Events"},
}
end
a.record("facts",{variantOf=function(b,a)return a.variant end})


function a.subjectOf(b,c)
local a=b and(b.subject or b.noun)or"this"
if b and b.unit=="target"then
a=a:find("the target",1,true)and a:gsub("the target","your target")
or(a.." on your target")
end
if c then return a end
return a:sub(1,1):upper()..a:sub(2)
end

local function e(g,b)
local b=b and b.spec
if not(b and type(g)=="string"and b.events)then return nil end
local e
for b,a in ipairs(f)do
local a=d[a].events[g]
if a then
e=a.label
break
end
end
if not e then return nil end
local d={}
for c,a in ipairs(b.eventOrder or{})do d[c]=b.events[a].label or a end
return a.subjectOf(b).." has no "..e..(#d>0 and(", only "..c.Clean.orList(d))or"")
..". Take what plays at "..e.." out first."
end
a.record("events",{variantOf=function(b,a)return a.variant end,
context=function(b,a)a.moment=a.spec and a.spec.moment or"plain"end,unknown=e})




function a.effectAllowed(a,b,d)
if a==nil then return false end
local a=a.effects and a.effects[b]
if d=="engine"then return a==true end
if a==false then return false end
local a=c.Layers.effect(b)
return a~=nil and(a.plainMoments~=false)
end





a.ALERT_LAYER="spellAlert"
a.ALERT_FLAGS={below=true,lit=true,hidesGreyed=true,noQuiet=true,loose=true}
function a.holdsAlert(b)
for c,b in ipairs(type(b)=="table"and type(b.sources)=="table"and b.sources or{})do
for c,b in ipairs(type(b)=="table"and type(b.layers)=="table"and b.layers or{})do
if type(b)=="table"and b.kind==a.ALERT_LAYER then return true end
end
end
return false
end

function a.alertFlag(b,c)return a.ALERT_FLAGS[c]==true and a.holdsAlert(b)end






local function i(a,b)return a==""and b or(a.."."..b)end
a.join=i
local function e(h,c,b,j,d,f)
if type(c)~="table"then return end
local a,b,f=a.frame(h,c,b or{},f)
for b,a in ipairs(a)do
local b=c[a.name]
if b~=nil then
local g=i(j,a.name)
if d(a,b,c,g,f,h,j)~=false and type(b)=="table"then
if a.type=="record"then
e(a.record,b,f,g,d,a)
elseif a.type=="list"and a.record then
for b,c in ipairs(b)do e(a.record,c,f,g.."["..b.."]",d,a)end
elseif a.type=="map"then
local c={}
for a in pairs(b)do c[#c+1]=a end
table.sort(c,function(a,b)return tostring(a)<tostring(b)end)
for h,c in ipairs(c)do e(a.record,b[c],f,g.."."..tostring(c),d,a)end
end
end
end
end
end
a.walk=e







local g
function a.reserved()
if g and g.n==#f then return g.set end
local b={[a.GAME]="the game's facts"}
for c,e in ipairs(f)do
local c=d[e]
local d=c.kind or e
for c,a in ipairs(c.stateOrder or{})do b[a]=b[a]or(d.."'s state")end
for f,e in ipairs(c.factOrder)do
if not a.isListFact(c.facts[e])then b[e]=b[e]or(d.."'s fact")end
end
for c,a in ipairs(c.eventOrder)do b[a]=b[a]or(d.."'s event")end
end
g={n=#f,set=b}
return b
end



function a.partId(b,c,d)
local b=tostring(b or"part"):gsub("(%u)",function(a)return"-"..a:lower()end)
b=b:gsub("[^%w%-]",""):sub(1,28)
if b==""then b="part"end
if not c[b]and b~=a.GAME and not(d and d[b])then return b end
local a=2
while c[b.."-"..a]do a=a+1 end
return b.."-"..a
end




function a.eachRecord(b,c,d,f,e,g)
if type(c)~="table"then return end
e=e or""
local h,j,f=a.frame(b,c,f or{},g)
if d(b,c,e,f,g)==false then return end
for g,b in ipairs(h)do
local c=c[b.name]
if type(c)=="table"and b.record then
local g=i(e,b.name)
if b.type=="record"then
a.eachRecord(b.record,c,d,f,g,b)
elseif b.type=="list"then
for e,c in ipairs(c)do
if type(c)=="table"then a.eachRecord(b.record,c,d,f,g.."["..e.."]",b)end
end
elseif b.type=="map"then
local e={}
for a in pairs(c)do e[#e+1]=a end
table.sort(e,function(a,b)return tostring(a)<tostring(b)end)
for h,e in ipairs(e)do
if type(c[e])=="table"then a.eachRecord(b.record,c[e],d,f,i(g,tostring(e)),b)end
end
end
end
end
end



function a.eachId(c,e)
a.eachRecord("element",c,function(d,c,f,g)
local b=b[d]
if b and b.idSpace then e(c.id,c,f,b.idSpace,d,g)end

if a.isConstItem(c)then return false end
end)
end








function a.eachRef(b,d,f)
local a={}
local function c(...)a[#a+1]={...}end
e(f or"element",b,{},"",function(a,b,d,e,f,g,h)
if a.type=="keys"then
if type(b)=="table"then
for b,i in ipairs(b)do c("keys",i,d,a.name,e.."["..b.."]",f,b,g,h)end
else
c("keys",b,d,a.name,e,f,nil,g,h)
end
elseif a.ref=="event"then
c("after",b,d,a.name,e,f,nil,g,h)
elseif a.ref=="layer"and type(b)=="table"then
for b,i in ipairs(b)do c("over",i,d,a.name,e.."["..b.."]",f,b,g,h)end
elseif a.ref=="layer"then
c("layer",b,d,a.name,e,f,nil,g,h)
elseif a.type=="map"and a.ref=="part"and type(b)=="table"then
local j={}
for a in pairs(b)do j[#j+1]=a end
table.sort(j,function(a,b)return tostring(a)<tostring(b)end)
for j,b in ipairs(j)do
c("map",b,d,a.name,i(e,tostring(b)),f,nil,g,h)
end
elseif a.ref=="part"then
c("part",b,d,a.name,e,f,nil,g,h)
end
end)
for b,a in ipairs(a)do d(unpack(a,1,9))end
end



local f={}
function a.keyFieldsOf(c)
local d=f[c]
if d and d.n==#b[c].fields then return d.list end
local d={}
for b,a in ipairs(a.get(c).fields)do
if a.type=="keys"then d[#d+1]=a.name end
end
f[c]={n=#b[c].fields,list=d}
return d
end


function a.splitKey(a)
if type(a)~="string"then return nil end
local b,c=a:match("^([^%.]+)%.([^%.]+)$")
if b then return c,b end
return a,nil
end


function a.holdsWithin(a,b)
if a==nil then return true end
if type(a)~="table"then return a==b end
for c,a in ipairs(a)do
if a==b then return true end
end
return false
end













local j={}
local d={}
local f={}

function a.constItem(a)f[a]=f[a]or{}end
function a.isConstItem(a)return f[a]~=nil end
local function l(c)
local b=d[c]
if not b then
b={{id=c.word,standIn=true}}
d[c]=b
a.constItem(b[1])
end
return b
end





local d={}
local function g(b)
local a={}
for b,c in pairs(b)do a[b]=c end
return a
end
local function k(f,b)
local e=d[b]
if not e then
if b.what then
d[b]={entry=g(b),item=c.copy(b.item)}
else
d[b]=c.copy(b)
end
return
end
local d
if b.what then
d=c.equal(b.item,e.item)
for a,c in pairs(e.entry)do d=d and rawequal(b[a],c)end
for a in pairs(b)do d=d and e.entry[a]~=nil end
else
d=c.equal(b,e)
end
if not d then a.keyIndexCheck(f,b,e)end
end

local function d(d,b)
local e,c={},{}
local function g(a)
e[a.word]=a
c[#c+1]=a
end
local h=d.enabled~=false
for a,c in ipairs(b.stateOrder or{})do
local a=b.states[c]
g({what="state",word=c,label=a.label,holds=a.holds,class=a.read or b.read,on=h})
end
local i=type(d.facts)=="table"and d.facts or{}
for m,c in ipairs(b.factOrder)do
local b=b.facts[c]
if a.isListFact(b)then
local c=i[c]
if c==nil then
local e=b.default and b.default(d)
c=e and l(b)or j
if e and a.keyIndexCheck then k(d,c)end
end
for i,c in ipairs(type(c)=="table"and c or j)do
if type(c)=="table"and type(c.id)=="string"and not e[c.id]then
local h=h and c.enabled~=false
local e=f[c]
local f=e and e[h]
if not f then
f={what="item",word=c.id,label=c.name or b.label,holds=b.holds,
class=b.read,fact=b,within=b.within,item=c,standIn=c.standIn,on=h}
if e then e[h]=f end
end
if e and a.keyIndexCheck then k(d,f)end
g(f)
end
end
else
local a=type(i[c])=="table"and i[c]or{}
g({what="fact",word=c,label=b.label,holds=b.holds,class=b.read,fact=b,
within=b.within,on=h and a.enabled~=false})
end
end
for c,a in ipairs(b.eventOrder)do
if not e[a]then
local c=b.events[a]
g({what="event",word=a,label=c.label,holds=c.holds,event=c,moment=b.moment})
end
end
return e,c
end
a.entriesOf=d









local f=true
local h=setmetatable({},{__mode="kv"})
local g=setmetatable({},{__mode="kv"})


a.keyIndexCheck=false


function a.freeze(a,b)
if not(f and type(a)=="table"and type(a.sources)=="table")then return end
h[a.sources]=a
g[a.sources]=b
end

local f

local function i(c,d)
local a=b.element.fields
for b=1,#a do
local a=a[b].name
if not rawequal(rawget(c,a),rawget(d,a))then return false end
end
return true
end



local function j(b,c)
for d,a in ipairs({"ids","sources","customStates","layers"})do
for d,b in pairs(b[a])do
local a=c[a][d]
if not(a and rawequal(b.rec,a.rec)and rawequal(b.spec,a.spec))then return false end
end
end
return true
end

function a.keyIndex(d)
local e=type(d)=="table"and rawget(d,"sources")
local h=type(e)=="table"and h[e]
if not(h and i(d,h))then return f(d)end
local b=g[e]
if not b then
b=f(h)
g[e]=b
end
if a.keyIndexCheck then
local e=f(d)
if not(c.equal(e,b)and j(e,b))then a.keyIndexCheck(d,b,e)end
end
return b
end

function f(c)
local b={ids={},sources={},customStates={},layers={}}
if type(c)~="table"then return b end
for e,c in ipairs(type(c.sources)=="table"and c.sources or{})do
local a=type(c)=="table"and a.variantOf(c)
if a and type(c.id)=="string"and not b.sources[c.id]then
local d,f=d(c,a)
local d={rec=c,path="sources["..e.."]",i=e,spec=a,words=d,order=f}
b.sources[c.id]=d
b.sources[#b.sources+1]=d
for e,a in ipairs(type(c.layers)=="table"and c.layers or{})do
if type(a)=="table"and type(a.id)=="string"then
b.layers[a.id]=b.layers[a.id]or{rec=a,path=d.path..".layers["..e.."]",
source=c.id,i=e}
end
end
end
end
for c,a in ipairs(type(c.customStates)=="table"and c.customStates or{})do
if type(a)=="table"and type(a.id)=="string"and not b.customStates[a.id]then
b.customStates[a.id]={rec=a,path="customStates["..c.."]",i=c}
end
end
a.eachId(c,function(a,c,d,e,f)
if e=="element"and a~=nil and not b.ids[a]then
b.ids[a]={rec=c,path=d,record=f}
end
end)
return b
end





local function i(f,g,c,b,d,h,i)
local e,a=a.splitKey(g)
if f=="keys"or f=="after"then
if d then
return e==b and(a==d or(a==nil and c.layer~=nil and c.source~=nil
and c.source.id==d))
end
if h then return a==b end
local d=i.ids[b]
if a~=nil or e~=b or not(d and d.record=="customState")then return false end
local a=c.layer~=nil and c.source~=nil and i.sources[c.source.id]
return not(a and a.words[e])
elseif f=="part"then
if d then return a==d and e==b end
return g==b or(h and a==b)
end
return d==nil and g==b
end





function a.renameId(d,b,c,g)
local f=a.keyIndex(d)
local j=g==nil and f.sources[b]~=nil
local h=0
a.eachRef(d,function(k,l,d,e,o,n,m)
if not i(k,l,n,b,g,j,f)then return end
h=h+1
if k=="map"then
d[e][c],d[e][b]=d[e][b],nil
return
end
local f,b=a.splitKey(l)
local a
if j then a=c.."."..f
elseif b then a=b.."."..c
else a=c end
if m and type(d[e])=="table"then d[e][m]=a else d[e]=a end
end)
if g then
local e=f.sources[g]
local d=e and e.rec
if not d then return h end
for g,f in ipairs(e.spec.factOrder)do
local e=e.spec.facts[f]
if a.isListFact(e)then
local a=type(d.facts)=="table"and d.facts or nil
local g=a and a[f]
if g==nil and f==b and e.default and e.default(d)then
d.facts=a or{}
d.facts[f]={{id=c}}
end
for d,a in ipairs(type(g)=="table"and g or{})do
if type(a)=="table"and a.id==b then a.id=c end
end
end
end
elseif f.ids[b]then
f.ids[b].rec.id=c
end
return h
end




function a.pointersTo(c,d,e)
local b={}
local f=a.keyIndex(c)
local g=e==nil and f.sources[d]~=nil
a.eachRef(c,function(a,c,h,j,k,l,n,m)
if i(a,c,l,d,e,g,f)then
b[#b+1]={path=k,kind=a,owner=h,key=j,record=m}
end
end)
return b
end







local function g(a,b)return type(a[b])=="table"and a[b]or nil end

local function l(h,e,f,i,j,k)
local b=a.pointersTo(h,e,f)
for b,c in ipairs(b)do
local b,d=c.owner,c.key
if c.kind=="keys"and(d=="all"or d=="any"or d=="none")then
local c=g(b,d)
for b=#(c or{}),1,-1 do
local d,a=a.splitKey(c[b])
if(a==nil and d==e and f==nil)or(f==nil and a==e)or(f and a==f and d==e)then
table.remove(c,b)
end
end
if c and#c==0 then b[d]=nil end
k[b]=true
elseif c.kind=="keys"and b==h then
for b,a in ipairs(a.SHOWING or{})do h[a]=nil end
elseif c.kind=="part"then

local a=i[b]
local a=a and a.field=="writes"and a.owner or nil
local a=a and i[a]
j(a and a.owner or b)
elseif c.kind=="keys"then
j(b)
elseif c.kind=="after"then

for a in pairs(i)do
if a.hold==b then
a.hold=nil
k[a]=true
end
end
elseif c.kind=="layer"then

b[d]=nil
local a=a.field(c.record,d)
for c,a in ipairs(a and a.resets or{})do b[a]=nil end
elseif c.kind=="over"then
local a=g(b,d)
for b=#(a or{}),1,-1 do
if a[b]==e then table.remove(a,b)end
end
if a and#a==0 then b[d]=nil end
elseif c.kind=="map"then
local a=g(b,d)
if a then a[e]=nil end
if a and next(a)==nil then b[d]=nil end
local a=false
for b in pairs(b)do
if b~="while"and b~="unless"then a=true end
end
if not a then j(b)end
end
end
return#b
end
function a.removeId(c,f,g)

local h={}
e("element",c,{},"",function(a,b,d)
if a.type=="list"and a.record and type(b)=="table"then
for e,c in ipairs(b)do
if type(c)=="table"then h[c]={list=b,owner=d,field=a.name}end
end
end
end)
local function j(b)
local a=h[b]
if not a then return end
for c=#a.list,1,-1 do
if a.list[c]==b then table.remove(a.list,c)end
end
if#a.list==0 and a.field~=nil and not(a.owner==c and a.field=="sources")then a.owner[a.field]=nil end
end
local k,e={},0
local d=g==nil and a.keyIndex(c).ids[f]or nil

local i={f}
if d then
a.eachRecord(d.record,d.rec,function(c,a)
if a~=d.rec and b[c]and b[c].idSpace=="element"and type(a.id)=="string"then
i[#i+1]=a.id
end
end)
end
for b,a in ipairs(i)do e=e+l(c,a,g,h,j,k)end

for b in pairs(k)do
if b.all==nil and b.any==nil and b.none==nil and b.hold==nil and type(b.id)=="string"then
a.removeId(c,b.id)
end
end
if g then
local b=a.keyIndex(c).sources[g]
local c=b and b.rec
for e,d in ipairs(b and b.spec.factOrder or{})do
local e=b.spec.facts[d]
local g=type(c.facts)=="table"and c.facts or nil
local b=g and g[d]
if a.isListFact(e)and b==nil and d==f and e.default and e.default(c)then

c.facts=g or{}
c.facts[d]={}
end
for a=#(type(b)=="table"and b or{}),1,-1 do
if type(b[a])=="table"and b[a].id==f then table.remove(b,a)end
end
end
elseif d then
j(d.rec)
end
return e
end




function a.fieldAt(e,d,c,f)
local b={}
for a in tostring(c):gmatch("[^%.]+")do b[#b+1]=a end
if#b==0 or#b>2 then return nil end
local c
for h,g in ipairs(b)do
local a,j,i=a.frame(e,d or{},f)
c=nil
for b,a in ipairs(a)do
if a.name==g then c=a end
end
if not c then return nil end
if h<#b then
if c.type~="record"then return nil end
e,d,f=c.record,type(d)=="table"and d[g]or nil,i
end
end
return c,b
end
