


















local a,e=...
local b,c=e.SFImport,e.Check

local f=b.CONVERT.pct



local function a(a,b,d,e,f)
return c.quickApply(a,{part=b,look=d,field=e,value=f})
end


local function c(b,c,d,e)
if e==nil then
local e=a(b,c,d,"shown",nil)
return a(b,c,d,"opacity",nil)and e
elseif e<=0 then
local e=a(b,c,d,"opacity",nil)
return a(b,c,d,"shown",false)and e
end
local g=a(b,c,d,"shown",nil)
return a(b,c,d,"opacity",f(e))and g
end
local function d(a)return b.sfGet(a.o,"idleAlpha",a.spec.idleAlpha or 0.3)end


local d={

cooldown=function(a,e,f)
local b,g=f.spec.icon or"icon",f.spec.readyLook or"ready"
local d=d(f)
if e=="offcd"then return c(a,b,g,d)end
if e=="oncd"or e=="oncdany"then
local e=c(a,b,g,nil)
return c(a,b,"coolingDown",d)and e
end
return c(a,b,g,nil)
end,

buff=function(a,f,b)
local e=b.spec.icon or"icon"
if f=="never"then return c(a,e,"missing",nil)end
return c(a,e,"missing",d(b))
end,

shield=function(a,b,e)
local b=b~="never"and d(e)or nil
local d=c(a,"icon","charged",b)
return c(a,"charges","charged",b)and d
end,

imbue=function(b,c)

if c=="never"then return a(b,"icon","present","shown",nil)end
return a(b,"icon","present","shown",false)
end,

target=function(a,b,c)
if b=="notarget"and d(c)<=0 then a.unless={"game.hostileTarget"}end
return true
end,
}



local g={
cooldown={text=true,swipe=true,bar=false},
uptime={text=true,swipe=false,bar=true},
}


local function f(c,d,a)
local e=b.sfGet(c.o,"timers."..d,nil)
if type(e)=="table"and e.follow==false and type(e[a])=="boolean"then return e[a]end
local e=c.spec.timers and c.spec.timers[d]
if type(e)=="table"and type(e[a])=="boolean"then return e[a]end
local b=b.sfGet(c.profile,"timers."..d,nil)
if type(b)=="table"and type(b[a])=="boolean"then return b[a]end
return g[d][a]
end
local function c(d,b,c)
local b=c.spec
if b.noTimer then return true end
local e=b.icon or"icon"
local g=b.kind=="buff"and"uptime"or"cooldown"
local h=a(d,e,nil,"time.enabled",f(c,g,"text"))
local g=a(d,e,nil,"sweep.enabled",f(c,g,"swipe"))
local e=true
if b.upBar then e=a(d,b.upBar,nil,"enabled",f(c,"uptime","bar"))end
return h and g and e
end

local f={uptime={text=false,swipe=true,bar=false}}
local i={uptime={text=true,swipe=false,bar=true}}
local g={uptime={text=false,bar=true}}


local function h(f,c,d)
local c=b.sfGet(d.o,"gcdStyle",nil)
local e
if type(c)=="table"and c.follow==false and type(c.show)=="boolean"then
e=c.show
else
e=b.sfGet(d.profile,"gcdStyle.show",true)
end
return a(f,d.spec.icon or"icon",nil,"gcdSweep.enabled",e)
end


local function j(e,c,d)
local c=d.spec.d or{}
local f=b.sfGet(d.o,"expire.fade",c["expire.fade"]~=nil and c["expire.fade"]or true)
local b=b.sfGet(d.o,"expire.glow",c["expire.glow"]~=nil and c["expire.glow"]or false)
return a(e,"expiring-pulse",nil,"enabled",f==true or b==true)
end


local k={lightning={324},water={408510},either={324,408510}}
local function l(a,b)
local b=k[b]
if not b then return true end
for c,a in ipairs(a.sources or{})do
if a.id=="buff"or a.id=="spell"then a.spells=e.copy(b)end
end
return true
end


local e={earth=8042,flame=8050,frost=8056}
local function k(a,b)
local b=e[b]
if not b then return true end
for c,a in ipairs(a.sources or{})do
if a.id=="spell"then a.shownSpell,a.chosen="chosen",b end
end
return true
end


local e={rockbiter=8017,flametongue=8024,frostbrand=8033,windfury=8232}
local function m(a,b)
for c,a in ipairs(a.sources or{})do
if a.id=="enchant"then
if b=="last"then
a.shownSpell="lastSeen"
elseif e[b]then
local c={e[b]}
for d,a in ipairs(a.spells or{})do
if a~=e[b]then c[#c+1]=a end
end
a.spells,a.shownSpell=c,"first"
end
end
end
return true
end


local function n(f,d,c)
local d=b.sfGet(c.o,"reset",nil)
if type(d)~="table"or d.follow~=false then return true end
local e=true
for b,c in pairs(b.popStyle(d,c.notes,c.unit))do
e=a(f,"reset-pop",nil,"style."..b,c)and e
end
return e
end



local o={["shaman-reincarnation"]=true}
local p={["shaman-naturesswiftness"]=true,["shaman-projection"]=true,["shaman-reincarnation"]=true}
local a={["shaman-flameshock"]=true,["shaman-imbue"]=true,["shaman-maelstrom"]=true,
["shaman-shields"]=true,["shaman-waterbreathing"]=true,["shaman-waterwalking"]=true}

local e={["shaman-purge"]=true}
for a in pairs(a)do e[a]=true end

b.KIND={
cooldown={
{sf="ready.pop",d=true,part="ready-pop",field="enabled",opt=o},
{sf="ready.glow",d=false,part="ready-glow",field="enabled",opt=p},
{sf="ready.sound",d="none",as="sound",sound={src="$spell",moment="comesReady",id="ready-sound"}},
{sf="gcdStyle",set=h},
{sf="mana.on",d=true,part="$icon",field="notEnoughPower.enabled"},
{sf="range.on",d=false,part="$icon",field="outOfRange.enabled"},
{sf="idleWhen",d="never",set=d.cooldown},
{sf="timers",set=c},
},
totem={
{sf="ready.pop",d=true,part="ready-pop",field="enabled"},
{sf="ready.sound",d="none",as="sound",sound={src="spell",moment="comesReady",id="ready-sound"}},
{sf="gcdStyle",set=h},
{sf="mana.on",d=true,part="icon",field="notEnoughPower.enabled"},
{sf="expire.secs",d=5,part="totem.expiring",field="enabled",as="nonzero"},
{sf="expire.secs",d=5,part="totem.expiring",field="seconds",as="secs"},
{sf="expire",set=j},
{sf="killed.flash",d=true,part="killed-flash",field="enabled"},
{sf="killed.pop",d=true,part="killed-pop",field="enabled",opt={["shaman-manatide"]=true}},
{sf="ended.pop",d=true,part="ranout-pop",field="enabled",
opt={["shaman-grounding"]=true,["shaman-manatide"]=true}},
{sf="ended.flash",d=true,part="ranout-flash",field="enabled",
opt={["shaman-earthbind"]=true,["shaman-stoneclaw"]=true}},
{sf="ended.sound",d="none",as="sound",sound={src="totem",moment="ranOut",id="ranout-sound"}},
{sf="idleWhen",d="offcd",set=d.cooldown},
{sf="timers",set=c},
},
buff={
{sf="active.pop",d=true,part="arrival-pop",field="enabled",opt=e},
{sf="active.glow",d=true,part="glow",field="enabled",opt=a},
{sf="active.sound",d="none",as="sound",sound={src="$aura",moment="arrived",id="arrival-sound"}},
{sf="idleWhen",d="notup",set=d.buff},
{sf="timers",set=c},
},
racial={
{sf="ready.pop",d=true,part="ready-pop",field="enabled"},
{sf="ready.glow",d=false,part="ready-glow",field="enabled"},
{sf="ready.sound",d="none",as="sound",sound={src="spell",moment="comesReady",id="ready-sound"}},
{sf="gcdStyle",set=h},
{sf="idleWhen",d="never",set=d.cooldown},
{sf="timers",set=c},
},
}



local function a(b)
local a={kind="cooldown"}
for b,c in pairs(b or{})do a[b]=c end
return a
end

local function c(a)return{kind="racial",aura="buff",upBar=a and"buff-bar"or nil}end

local function e(b)
local a={kind="buff",aura="buff",idleAlpha=0,timers=f,d={idleAlpha=0}}
for b,c in pairs(b or{})do a[b]=c end
return a
end
local function j()
return{kind="buff",aura="dispel",idleAlpha=0,timers=f,
d={idleAlpha=0,["active.pop"]=true,["active.glow"]=false}}
end
local function o(a,b,c,d)
return{
{sf="count.bar",d=true,part=a,field="enabled"},
{sf="count.number",d=true,part=b,field=c},
{sf="count.barColor",part=a,field="colour",as="colour"},
{sf="count.barHeight",d=d,part=a,field="thickness",as="num"},
}
end
local function h(a)
return{kind="totem",readyLook="ready-no-totem",idleAlpha=0.3,timers=g,d=a}
end

b.TABLE={
["shaman-shields"]={kind="buff",aura="buff",timers={uptime={text=false,swipe=false,bar=false}},
d={idleWhen="never",idleAlpha=0.3},rows={
{sf="track",d="lightning",set=l},
{sf="count.bar",d=true,part="charges",field="enabled"},
{sf="count.number",d=false,part="icon",field="count.enabled"},
{sf="count.barColor",part="charges",field="colour",as="colour"},
{sf="count.barHeight",d=8,part="charges",field="thickness",as="num"},
{sf="warn.grey",d=true,part="icon",look="missing",field="desaturated"},
{sf="warn.ring",d=true,part="icon",look="missing",field="border.ring"},
{sf="warn.glow",d=true,part="missing-glow",field="enabled"},
{sf="warn.sound",d="none",as="sound",sound={src="buff",moment="removed",id="removed-sound"}},
{sf="idleWhen",d="never",set=d.shield},
}},
["shaman-shocks"]=a({idleAlpha=0.3,d={["range.on"]=true,["mana.on"]=true},rows={
{sf="track",d="earth",set=k},
{sf="marks.frost",d=true,part="frost",field="enabled"},
{sf="marks.flame",d=true,part="flame",field="enabled"},
}}),
["shaman-flameshock"]={kind="buff",aura="debuff",upBar="bar",idleAlpha=0,noTimer=true,
d={on=false,idleWhen="notarget",idleAlpha=0,["active.pop"]=false,["active.glow"]=false},rows={
{sf="expire.bar",d=true,part="bar",field="enabled"},
{sf="expire.barColor",part="bar",look="expiring",field="colour",as="colour"},
{sf="warn.grey",d=true,part="icon",look="missing",field="desaturated"},
{sf="warn.ring",d=false,part="icon",look="missing",field="border.ring"},
{sf="warn.glow",d=true,part="missing-glow",field="enabled"},
{sf="idleWhen",d="notarget",set=d.target},
}},
["shaman-maelstrom"]={kind="buff",aura="buff",idleAlpha=0,timers=f,
d={idleWhen="notup",idleAlpha=0,["active.pop"]=false},rows={
{sf="count.bar",d=true,part="stacks",field="enabled"},
{sf="count.number",d=true,part="number",field="enabled"},
{sf="count.barColor",part="stacks",field="colour",as="colour"},
{sf="count.barHeight",d=6,part="stacks",field="thickness",as="num"},
{sf="count.markColor",part="number",look="atStacks",field="colour",as="colour"},
{sf="active.glow",d=true,part="five-glow",field="enabled"},
}},
["shaman-flurry"]=e({d={on=false,idleAlpha=0,["active.pop"]=false,["active.glow"]=false},
rows=o("charges","number","enabled",5)}),
["shaman-elementalfocus"]=e(),
["shaman-improvedstormstrike"]=e({d={on=false,idleAlpha=0,["active.pop"]=false,["active.glow"]=false}}),
["shaman-curepoison"]=j(),
["shaman-curedisease"]=j(),
["shaman-purge"]={kind="buff",aura="dispel",idleAlpha=0,noTimer=true,
d={idleAlpha=0,["active.pop"]=false,["active.glow"]=true},rows={
{sf="active.glow",d=true,part="glow",field="enabled"},
{sf="skipLong",d=false,part="dispel",field="skipLong"},
{sf="skipLongMins",d=2,part="dispel",field="longest"},
}},
["shaman-imbue"]={kind="buff",aura="enchant",idleAlpha=0,timers={uptime={text=true,swipe=false,bar=false}},
d={idleWhen="notlow",idleAlpha=0,["active.pop"]=false,["active.glow"]=false},rows={
{sf="icon",d="last",set=m},
{sf="showUnderMins",d=5,part="enchant.expiring",field="enabled",as="nonzero"},
{sf="showUnderMins",d=5,part="enchant.expiring",field="seconds",as="minsToSecs"},
{sf="warn.grey",d=true,part="icon",look="missing",field="desaturated"},
{sf="warn.ring",d=true,part="icon",look="missing",field="border.ring"},
{sf="warn.glow",d=true,part="missing-glow",field="enabled"},
{sf="warn.pop",d=true,part="removed-pop",field="enabled"},
{sf="warn.sound",d="none",as="sound",sound={src="enchant",moment="removed",id="removed-sound"}},
{sf="expire.glow",d=false,part="expiring-glow",field="enabled"},
{sf="idleWhen",d="notlow",set=d.imbue},
}},
["shaman-waterwalking"]={kind="buff",aura="buff",upBar="bar",idleAlpha=0,timers=i,
d={idleAlpha=0,["active.pop"]=false,["active.glow"]=false},rows={
{sf="expire.bar",d=true,part="bar",field="enabled"},
{sf="expire.barColor",part="bar",look="expiring",field="colour",as="colour"},
{sf="expire.text",d=true,part="icon",field="time.enabled"},
}},
["shaman-waterbreathing"]={kind="buff",aura="buff",upBar="bar",idleAlpha=0,timers=i,
d={idleAlpha=0,["active.pop"]=false,["active.glow"]=false},rows={
{sf="expire.bar",d=true,part="bar",field="enabled"},
{sf="expire.barColor",part="bar",look="expiring",field="colour",as="colour"},
{sf="expire.text",d=true,part="icon",field="time.enabled"},
{sf="warn.on",d=true,part="breath",field="enabled"},
{sf="warn.glow",d=false,part="breath-glow",field="enabled"},
{sf="warn.ring",d=true,part="breath-icon",look="draining",field="border.ring"},
}},
["shaman-stormstrike"]=a({upBar="debuff-bar",timers=g,
d={["ready.glow"]=true,["range.on"]=true,["mana.on"]=true},rows={
{sf="reset.pop",d=true,part="reset-pop",field="enabled"},
{sf="reset.text",d=false,part="reset-words",field="enabled"},
{sf="reset.words",d="Reset!",part="reset-words",field="text"},
{sf="wordColor",part="reset-words",field="colour",as="colour"},
{sf="reset.sound",d="none",as="sound",sound={src="spell",moment="reset",id="reset-sound"}},
{sf="reset",set=n},
{sf="active.on",d=true,part="debuff",field="enabled"},
{sf="buffBar",d=false,part="improved",field="enabled"},
}}),
["shaman-earthbind"]=h({idleWhen="offcd",["mana.on"]=true}),
["shaman-stoneclaw"]=h({idleWhen="offcd",["mana.on"]=true}),
["shaman-grounding"]=h({idleWhen="offcd",["mana.on"]=true}),


["shaman-manatide"]={kind="totem",readyLook="ready",idleAlpha=0.3,timers=g,
d={idleWhen="never",["mana.on"]=true,["expire.secs"]=3,["expire.fade"]=false,["expire.glow"]=true}},
["shaman-firenova"]=a({d={["mana.on"]=true}}),
["shaman-naturesswiftness"]=a({rows={
{sf="active.glow",d=true,part="buff-glow",field="enabled"},
}}),
["shaman-elementalmastery"]=a({upBar="with-bar"}),
["shaman-farseer"]=a({upBar="buff-bar"}),
["shaman-riptide"]=a({d={["mana.on"]=true}}),
["shaman-chainlightning"]=a({d={["ready.pop"]=false,["mana.on"]=true}}),
["shaman-projection"]=a({d={idleWhen="offcd",["mana.on"]=true}}),
["shaman-reincarnation"]=a({idleAlpha=0,d={idleWhen="offcd",idleAlpha=0}}),
["racial-berserking"]=c(true),
["racial-bloodfury"]=c(true),
["racial-rapidregeneration"]=c(),
["racial-shattercurse"]=c(true),
["racial-skysight"]=c(),
["racial-stoneform"]=c(true),
["racial-walkonair"]=c(),
["racial-warstomp"]=c(),
}
