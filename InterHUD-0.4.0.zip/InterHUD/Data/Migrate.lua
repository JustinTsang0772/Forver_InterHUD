


local a,d=...
local h,p=d.Schema,d.Clean

local b={}
d.Migrate=b


b.OLDEST=8

b.steps={}





b.PLACES={element={"while","unless"},look={"while","unless"},effect={"while","unless"},
customState={"all","any","none"},hold={"after"},quickSetting={"part","look"},
quickWrite={"part","look"},quickTarget={"part","look"}}
b.LEAVES={group={"while","unless"},effect={"over"},layerPosition={"to"},
look={"glows","texts","colourSteps","marks"}}




local function a(a,b)
if type(a)~="table"then return end
for c,a in ipairs(a)do
if type(a)=="table"then b(a,c)end
end
end

local function l(b,c)
if type(b)~="table"then return end
local a={}
for b,c in pairs(b)do
if type(b)=="string"and type(c)=="table"then a[#a+1]=b end
end
table.sort(a)
for d,a in ipairs(a)do c(b[a],a)end
end

local function e(c,b)
a(c.sources,function(d,c)
local c="sources["..c.."]"
b(d.events,c..".events")
l(d.facts,function(d,e)
b(d.events,c..".facts."..e..".events")
a(d,function(a,d)b(a.events,c..".facts."..e.."["..d.."].events")end)
end)
end)
a(c.customStates,function(a,c)b(a.events,"customStates["..c.."].events")end)
end


local function m(b,c)
c(b,"element","")
a(b.sources,function(b,e)
a(b.layers,function(d,f)
a(d.looks,function(g,a)
c(g,"look","sources["..e.."].layers["..f.."].looks["..a.."]",b,d.looks,a)
end)
end)
end)
e(b,function(b,d)
l(b,function(b,e)
a(b.effects,function(f,a)
c(f,"effect",d.."."..e..".effects["..a.."]",nil,b.effects,a)
end)
end)
end)
a(b.customStates,function(d,a)c(d,"customState","customStates["..a.."]",nil,b.customStates,a)end)
end


local function j(e,c)
local function f(b,d,e)
a(b.choices,function(b,f)
a(b.writes,function(a,b)c(a,d..".choices["..f.."].writes["..b.."]",e)end)
end)
end

local function g(b,d)
a(b.also,function(a,e)c(a,d..".also["..e.."]",{rec=a,list=b.also})end)
end
a(e.quick,function(b,d)
local d="quick["..d.."]"
local e={rec=b,list=e.quick}
c(b,d,e)
f(b,d,e)
g(b,d)
a(b.rows,function(a,e)
local b,d=d..".rows["..e.."]",{rec=a,list=b.rows}
c(a,b,d)
f(a,b,d)
g(a,b)
end)
end)
end


local function q(b,c,d)
local a=b[c]
if type(a)=="string"then
local a=d(a)
if a then b[c]=a end
elseif type(a)=="table"then
for c,b in ipairs(a)do
if type(b)=="string"then
local b=d(b)
if b then a[c]=b end
end
end
end
end
local function k(b,c,d)
local a=false
q(b,c,function(b)
if b==d then a=true end
end)
return a
end

local function t(b,c,d,e)
local a=b[c]
local a=type(a)=="table"and a or(type(a)=="string"and{a}or{})
if#a>=e then return false end
a[#a+1]=d
b[c]=a
return true
end



local function f(a)
local b={}
local function c(a,d)
if d>20 then return end
if type(a.id)=="string"then b[a.id]=true end
for b,a in pairs(a)do
if type(a)=="table"and b~="origin"then c(a,d+1)end
end
end
for b,a in pairs(a)do
if type(a)=="table"and b~="origin"then c(a,1)end
end
return b
end

local function g(c)
local b={}
a(c.sources,function(c)
a(c.layers,function(a)
if type(a.id)=="string"then b[a.id]=c end
end)
end)
return b
end




local function o(a,d,c,f)
local e=d.id
m(a,function(a,f,i,g)
for f,b in ipairs(b.PLACES[f])do
q(a,b,function(a)
local a,b=h.splitKey(a)
if b==e then return c(a,true)end
if b==nil and g==d then return c(a,false)end
end)
end
end)
local b=g(a)
j(a,function(a)
if type(a.look)=="string"and type(a.part)=="string"and b[a.part]==d then
a.look=c(a.look,false)or a.look
end
local b,d=h.splitKey(a.part)
if f and d==e then
local b=c(b,true)
if b then a.part=b end
end
end)
end






local n={
hold="Its hold followed an event a Spell source doesn't have; the custom state was left out.",
full="This custom state's hold followed the cooldown ending. It would now also need the spell to be usable, but"
.." “All of these” is already full, so it was left out.",
cascade="This custom state used one that couldn't be carried over to this version, so it was left out too.",
}
local r="This used a custom state that couldn't be carried over to this version, so it was left out too."
local s="Its While or Unless used a custom state that couldn't be carried over, so its While, Unless and"
.." Otherwise were cleared, and it now always shows."

local function i(a,b,c,d)
local b=p.message("note",a.unit,a.paths[b]or c,d)
a.notes[#a.notes+1]=b
return b
end

local function c(a,b)
if type(a[b])=="table"and next(a[b])==nil then a[b]=nil end
end
local function v(b)
a(b.sources,function(b)
a(b.layers,function(a)c(a,"looks")end)
end)
e(b,function(a)
l(a,function(a)c(a,"effects")end)
end)
a(b.quick,function(b)
a(b.rows,function(a)c(a,"also")end)
c(b,"also")
c(b,"rows")
end)
c(b,"quick")
c(b,"customStates")
end
local function u(f,c,h,d)
local g,d={},{{cs=c,why=d}}
while#d>0 do
local e=table.remove(d,1)
local c=e.cs.id
if not g[e.cs]then
g[e.cs]=true
for a,b in ipairs(f.customStates)do
if b==e.cs then
i(h,b,"customStates["..a.."]",n[e.why]).leftOut="customState"
table.remove(f.customStates,a)
break
end
end

local n={[c]=true}
l(e.cs.events,function(b)
a(b.effects,function(a)
if type(a.id)=="string"then n[a.id]=true end
end)
end)
local e={}
m(f,function(a,f,j,m,l)
if g[a]or type(c)~="string"then return end
if f=="customState"then
if k(a,"all",c)or k(a,"none",c)then
d[#d+1]={cs=a,why="cascade"}
elseif k(a,"any",c)then
local b=a.any
if type(b)=="table"then
for a=#b,1,-1 do
if b[a]==c then table.remove(b,a)end
end
end
if type(b)~="table"or#b==0 then
a.any=nil
d[#d+1]={cs=a,why="cascade"}
end
end
return
end
local d=false
for e,b in ipairs(b.PLACES[f])do
if k(a,b,c)then d=true end
end
if not d then return end
if f=="element"then
a["while"],a.unless,a.otherwise=nil,nil,nil
i(h,a,j,s).cleared=true
else
e[#e+1]={owner=a,list=l,path=j,place=f}

if f=="effect"and type(a.id)=="string"then n[a.id]=true end
end
end)
j(f,function(a,d,b)
if(type(a.part)=="string"and n[a.part])or(type(c)=="string"and a.look==c)then
e[#e+1]={owner=b.rec,list=b.list,path=d,place="quick"}
end
end)
for b,a in ipairs(e)do
if not g[a.owner]then
g[a.owner]=true
i(h,a.owner,a.path,r).leftOut=a.place
for b=#a.list,1,-1 do
if a.list[b]==a.owner then table.remove(a.list,b)end
end
end
end
end
end
v(f)
end







local r={
readyToUse={id="ready-and-usable",name="Ready and usable",all={"ready","usable"}},
coming={id="cooling-and-usable",name="Cooling down and usable",all={"coolingDown","usable"}},
waiting={id="ready-not-usable",name="Ready, not usable",all={"ready"},none={"usable"}},
coolingDown={id="cooling-not-usable",name="Cooling down, not usable",all={"coolingDown"},
none={"usable"}},
}
local v={"readyToUse","coming","waiting","coolingDown"}
local w={needsPower=false,checksEvery="0.1"}
local z,A=8,16
local x=48


local function c(a)
local a,b=a["while"],a.unless
if type(a)=="table"and#a==1 then a=a[1]end
if type(a)~="string"or(b~=nil and not(type(b)=="table"and#b==0))then return nil end
return h.splitKey(a)
end
local function s(a,b)
local c,a=c(a)
if a==nil or a==b then return c end
end






local e={ring=true,ringColour=true,ringSize=true}
local function c(a)
if a.tint~=nil or a.overlay~=nil or a.overlayColour~=nil or a.desaturated~=nil then return true end
if type(a.border)=="table"then
for a in pairs(a.border)do
if e[a]then return true end
end
end
return false
end
local l={

{word="pressed",sets=function(a)return type(a.pressed)=="table"and a.pressed.shown~=nil end,
look=function()return{["while"]="pressed",pressed={shown=true}}end},
{word="notEnoughPower",sets=c,look=function()return{["while"]="notEnoughPower"}end},
{word="outOfRange",sets=c,look=function()return{["while"]="outOfRange"}end},
}
local n=32
local y="The button cues on this icon now sit under its converted looks, as the icon has no room for the"
.." looks that would keep them on top. Where a cue and a converted look set the same thing, the look now wins."
local function B(e,b,h,j)
local g=type(e.facts)=="table"and e.facts or{}
a(e.layers,function(a,k)
if a.kind~="icon"or type(a.looks)~="table"then return end
local c,f={},{}
for d,a in ipairs(a.looks)do
if b[a]then c[#c+1]=a else f[#f+1]=a end
end
if#c==0 then return end
local d={}
for h,b in ipairs(l)do
local h=not(type(g[b.word])=="table"and g[b.word].enabled==false)
and not(type(a[b.word])=="table"and a[b.word].enabled==false)
local a,g=false,false
for d,c in ipairs(c)do
if b.sets(c)then a=true end
end

for c,a in ipairs(f)do
if type(a)=="table"and s(a,e.id)==b.word and next(a,nil)=="while"
and next(a,"while")==nil then g=true end
end
if h and a and not g then d[#d+1]=b.look()end
end

if#a.looks+#d>n then
d={}
i(h,a,j..".layers["..k.."]",y).cuesUnder=true
end
local b=0
for d,c in ipairs({c,d,f})do
for d,c in ipairs(c)do
b=b+1
a.looks[b]=c
end
end
end)
end


local function y(a)
if type(a.name)=="string"and a.name~=""then return a.name end
local a=type(a.spells)=="table"and a.spells[1]or a.spells
if type(a)=="table"then a=type(a.name)=="string"and a.name or a.id end
if type(a)=="number"then return d.Spells.label(a)or tostring(a)end
return type(a)=="string"and a or nil
end



local function n(f,b,g,j)
if type(b.id)~="string"or type(b.facts)~="table"then return end
for d,c in pairs(b.facts)do
if d~="usable"and type(c)=="table"then
for k,c in ipairs(c)do
if type(c)=="table"and c.id=="usable"then
local e={}
for c,b in pairs(b.facts)do
a(b,function(a)
if type(a.id)=="string"then e[a.id]=true end
end)
end
local a=h.partId(d,e)
c.id=a
o(f,b,function(c,d)
if c~="usable"then return nil end
return d and(b.id.."."..a)or a
end,true)
i(j,c,"sources["..g.."].facts."..d.."["..k.."]",
"Its id was “usable”, which is now the name of the spell's Usable fact. Its id is now “"..a
.."”, and everything that used it was changed to match.")
end
end
end
end
end

local function g(b,c)

local g={notes=c,unit=type(b.id)=="string"and b.id or nil,paths={}}
m(b,function(a,c,b)g.paths[a]=b end)
j(b,function(a,b)g.paths[a]=b end)
if type(b.sources)~="table"then return end
local l=f(b)

local e={}
a(b.sources,function(a,c)
if a.kind=="spell"then n(b,a,c,g)end
if a.id==nil and(a.kind=="spell"or a.kind=="reactive")then
local b=h.partId("spell",l)
l[b]=true
if a.kind=="reactive"then a.id=b end
end
if a.kind=="reactive"and type(a.id)=="string"then e[#e+1]={src=a,i=c}end
end)
if#e==0 then return end
if b.customStates~=nil and type(b.customStates)~="table"then b.customStates=nil end


for d,c in ipairs(e)do
local d=c.src.id
local c={}
a(b.customStates,function(a)
local b=type(a.hold)=="table"and a.hold.after
if b==d..".opens"or b==d..".usable"then c[#c+1]=a end
end)
for c,a in ipairs(c)do u(b,a,g,"hold")end
if b.customStates and#b.customStates==0 then b.customStates=nil end
end

for c,n in ipairs(e)do
local c,f=n.src,n.src.id

local d={}
local function C(a)
if d[a]then return d[a]end
local b=r[a]
local h=h.partId(b.id,l)
l[h]=true
local g=b.name
if#e>1 then
g=p.cut(g..": "..(y(c)or f),x-3)
end
local c={id=h,name=g}
for d,a in ipairs({"all","none"})do
if b[a]then
c[a]={}
for b,d in ipairs(b[a])do c[a][b]=f.."."..d end
end
end
d[a]=c
return c
end
local y={}
a(c.layers,function(b)
a(b.looks,function(a)
if r[s(a,f)or""]then y[a]=true end
end)
end)
local s={}
o(b,c,function(a)
if r[a]then s[a]=true end
end)

local e=type(c.events)=="table"and c.events or nil
local m=e and type(e.usable)=="table"and e.usable.effects
if type(m)=="table"and#m>0 then s.readyToUse=true end
for b,a in ipairs(v)do
if s[a]then C(a)end
end
o(b,c,function(a)
return d[a]and d[a].id or nil
end)
B(c,y,g,"sources["..n.i.."]")


local o={id="usable"}
for a,d in pairs(w)do
local b=c[a]
if b~=nil and tostring(b)~=tostring(d)then o[a]=b end
c[a]=nil
end
if type(c.facts)~="table"then c.facts={}end

local r=false
a(c.layers,function(a)
if a.kind=="icon"then
r=true

if type(a.gcdSweep)~="table"then a.gcdSweep={}end
a.gcdSweep.enabled=false
end
end)
if r then
if type(c.facts.notUsable)~="table"then c.facts.notUsable={}end
c.facts.notUsable.enabled=false
end


if e then
local b=type(e.opens)=="table"and e.opens.effects
if type(b)=="table"and#b>0 then o.events={enters={effects=b}}end
if type(m)=="table"and#m>0 then d.readyToUse.events={enters={effects=m}}end
e.opens,e.usable=nil,nil
local b=type(e.comesReady)=="table"and e.comesReady.effects
a(b,function(b)
local c=f..".usable"
if k(b,"while",c)or t(b,"while",c,z)then return end

local a=type(b.id)=="string"and b.id or nil

local a={id=h.partId((a or"effect").."-while",l),name=a
and("When “"..p.cut(a,x-23).."” can play")or"When its effect can play"}
l[a.id]=true
a.all={}
q(b,"while",function(b)a.all[#a.all+1]=b end)
a.all[#a.all+1]=c
b["while"]=a.id
d[#d+1]=a
end)
if next(e)==nil then c.events=nil end
end
for a in pairs(o)do
if a~="id"then
c.facts.usable={o}
break
end
end
if next(c.facts)==nil then c.facts=nil end


local e={}
a(b.customStates,function(a,b)
if type(a.hold)=="table"and a.hold.after==f..".comesReady"then
if k(a,"all",f..".usable")then return end
if t(a,"all",f..".usable",A)then
i(g,a,"customStates["..b.."]",
"Its hold followed the cooldown ending; it now also needs the spell to be usable.")
else
e[#e+1]=a
end
end
end)
for c,a in ipairs(e)do u(b,a,g,"full")end

j(b,function(a)
if a.part==f and w[a.field]~=nil then a.part=f..".usable"end
end)


c.kind="spell"
local a=b.customStates or{}
for c,b in ipairs(v)do
if d[b]then a[#a+1]=d[b]end
end
for c,b in ipairs(d)do a[#a+1]=b end
if#a>0 then b.customStates=a end
i(g,c,"sources["..n.i.."]","This source is now a Spell source: its"
.." states became custom states named for what they hold, and its Usable settings are in its Usable fact.")
end
end





local function e(a)return type(a)=="table"and a.field=="checksEvery"end

local function c(b)
local c=false
for d=#b,1,-1 do
local a=b[d]
if e(a)then
table.remove(b,d)
c=true
elseif type(a)=="table"and type(a.choices)=="table"then
for c=#a.choices,1,-1 do
local b=a.choices[c]
if type(b)=="table"and type(b.writes)=="table"then
for a=#b.writes,1,-1 do
if e(b.writes[a])then table.remove(b.writes,a)end
end
if#b.writes==0 then table.remove(a.choices,c)end
end
end
if#a.choices==0 then
table.remove(b,d)
c=true
end
end
end
return c
end
local function e(a)
if type(a.sources)~="table"then return end
for b,a in ipairs(a.sources)do
local a=type(a)=="table"and type(a.facts)=="table"and a.facts.usable
for b,a in ipairs(type(a)=="table"and a or{})do
if type(a)=="table"then a.checksEvery=nil end
end
end
if type(a.quick)~="table"then return end
for d=#a.quick,1,-1 do
local b=a.quick[d]
if type(b)=="table"and type(b.rows)=="table"and c(b.rows)and#b.rows==0 then
table.remove(a.quick,d)
end
end
c(a.quick)
end



local function c(a)
if a.baseSize==nil then a.baseSize=a.size end
a.size=nil
j(a,function(a)
if a.part==nil and a.field=="size"then a.field="baseSize"end
end)
end




local f={up=true,down=true}
local function h(b)
local c={}
a(b.sources,function(b)
a(b.layers,function(a)
if a.kind~="bar"then return end
local b=f[a.grows]and{width="thickness",height="length"}
or{width="length",height="thickness"}
local d,e=a.width,a.height
a.width,a.height=nil,nil
if a[b.width]==nil then a[b.width]=d end
if a[b.height]==nil then a[b.height]=e end
if type(a.id)=="string"then c[a.id]=b end
end)
end)
j(b,function(a)
local b=type(a.part)=="string"and c[a.part]
if b and b[a.field]then a.field=b[a.field]end
end)
end


b.steps[8]=function(a,b)
g(a,b)
e(a)
c(a)
h(a)
end

b.groupSteps={}
b.groupSteps[8]=function(a)
if a.lineUpBy=="box"then a.lineUpBy="baseSize"end
end





b.SWING_GONE="The swing timer is no longer a special, so its settings were left out. You can now build a swing"
.." timer as an element, or pick one of the swing timer pre-mades in New, after turning on \"Show drafts\"."

function b.dropSwing(b,a)
if type(a)~="number"or a>8 or type(b)~="table"then return false end
local a=b.specials
if type(a)~="table"or a.swingTimer==nil then return false end
local c=a.swingTimer
a.swingTimer=nil
if next(a)==nil then b.specials=nil end
return type(c)=="table"and c.enabled==true
end





function b.element(a,e)
if type(a)~="table"then return a,{}end
local c,d=d.copy(a),{}
local a=e or b.OLDEST
while b.steps[a]do
b.steps[a](c,d)
a=a+1
end
return c,d
end


function b.group(a,e)
if type(a)~="table"then return a end
local c=d.copy(a)
local a=e or b.OLDEST
while b.steps[a]do
if b.groupSteps[a]then b.groupSteps[a](c)end
a=a+1
end
return c
end
