


local a,b=...
local a,e,o,i,p,u,f,j=
b.Kit,b.Form,b.Store,b.Specials,b.Schema,b.StyleArea,b.TotemBar,b.Totems

local c={}
b.TotemPage=c

local d="totemBar"
c.ORDER_HINT="Drag to reorder. Untick a slot to hide it."













local m={
{key="down",label="Totem down"},
{key="expiring",label="Expiring"},
{key="notDown",label="Not down",empty=true},
{key="otherPick",label="Different totem down"},
{key="picking",label="Picking",empty=true},
{key="noPower",label="Not enough power",empty=true},
{key="range",label="Out of range"},
{key="killed",label="Killed early",empty=true},
{key="ranOut",label="Ran out",empty=true},
}
local l={}
for b,a in ipairs(m)do
a.n=b
l[a.key]=a
end


local h
b.onChanged(function()h=nil end,"page totem bar")
local function g()
if not h then h=e.specialView(d)end
return h
end


local function k()
for b,a in ipairs(i.list())do
if a.key==d then return a.state end
end
return"never"
end
c.state=k

local function q()
for a=1,4 do
if#j.spellsOf(a)>0 then return true end
end
return false
end


function c.chips()
local a={}
for c,b in ipairs(f.chips())do a[#a+1]=l[b]or{key=b,label=b,n=#m+#a}end
table.sort(a,function(a,b)return a.n<b.n end)
return a
end



local h,m,r=12,54,18
local s,n,t,v=260,120,18,16

a.confirm("RESET_TOTEM_BAR","Reset the totem bar to its defaults?","Reset",function()
o.editSpecial(d,function(a)wipe(a)end)
end)

local function w(g)
local e=CreateFrame("Frame")
local f=a.cornerRoom("header",h)
local b={frame=e,chips={},lines={},side=f}
b.ground=a.panel(e,"heroFill","heroEdge",nil,"header")
b.ground:cover(e,1)
e:HookScript("OnSizeChanged",function(d,a,c)b.ground:fitArt(a,c)end)
b.name=a.fontString(e,"bannerName")

local c=a.metric("banner","top")
b.name:SetPoint("TOPLEFT",f,-c)
b.name:SetShadowOffset(1,-1)
b.name:SetText(i.get(d)and i.get(d).label or"Totem bar")
b.sub=e:CreateFontString(nil,"OVERLAY",a.font("small"))
b.sub:SetPoint("TOPLEFT",b.name,"BOTTOMLEFT",0,-4)
a.tint(b.sub,"heroText")

b.switch=a.pillSwitch(e,function()return k()=="on"end,function(a)return i.setOn(d,a)end,
"On",nil,a.font("label"))
b.switch:SetPoint("TOPRIGHT",e,"TOPRIGHT",-f-28,-c)

b.reset=a.textLink(e,"Reset totem bar",function()a.showPopup("RESET_TOTEM_BAR")end,true)
b.reset:SetPoint("RIGHT",b.switch,"LEFT",-16,0)

local c=CreateFrame("Frame",nil,e)
c:SetSize(s,n)
c:SetPoint("TOPLEFT",e,"TOPLEFT",f,-(h+m))
c.ground=a.panel(c,"shade","panelEdge")
c.ground:cover(c,1)

c:SetClipsChildren(true)
c.label=a.fontString(c,"dim")
c.label:SetPoint("TOPLEFT",6,-4)
c.label:SetText("Preview")
a.tint(c.label,"help")
c.fit=a.fontString(c,"dim")
c.fit:SetPoint("TOPRIGHT",-6,-4)
c.stage=CreateFrame("Frame",nil,c)
c.stage:SetScript("OnHide",function()if b.preview then b.preview:hide()end end)
b.area=c
b.chipArea=CreateFrame("Frame",nil,e)
b.chipArea:SetPoint("TOPLEFT",c,"TOPRIGHT",v,0)
b.chipArea:SetPoint("RIGHT",e,"RIGHT",-f,0)
b.chipArea:SetHeight(1)
b.page=g
return b
end


local function i(b)
local a={}
if b=="never"then a[#a+1]="Shamans only: it doesn't show for this character."end
if b=="on"and not q()then a[#a+1]="No totems learned yet, so it isn't on screen."end
if b=="on"and f.besideShamanForever()then
a[#a+1]="ShamanForever is loaded too: turn one totem bar off, or move one."
end
return a
end




local function v(a,c)
local k,e=a.area,a.area.stage
if not a.preview then a.preview=f.newPreview(e)end
local d=a.preview
local b=q()
local h={scale=c.scale or 1,known=function(a)return not b or#j.spellsOf(a)>0 end}
local g,o=d:layout(c,h)
local b=d:reach(a.picked)
local j,m=s-12,n-t-8
local i=UIParent:GetEffectiveScale()/k:GetEffectiveScale()
local i=(c.scale or 1)*i
local g=math.min(1,j/math.max((g+b.left+b.right)*i,1),
m/math.max((o+b.top+b.bottom)*i,1))
if g<1 then
h.scale=(c.scale or 1)*g
d:layout(c,h)
b=d:reach(a.picked)
end
local h=i*g
e:SetScale(h)
e:ClearAllPoints()
e:SetPoint("CENTER",k,"CENTER",0,-(t-8)/2/h)
e:SetSize(j/h,m/h)
d.holder:ClearAllPoints()

d.holder:SetPoint("CENTER",e,"CENTER",(b.left-b.right)/2,(b.bottom-b.top)/2)
local b=a.picked and l[a.picked]
local e={}
for d=1,4 do e[d]=f.madeUp(d,a.picked,c,{down=not(b and b.empty)})end
d:show(c,e)
return g
end

local l,q=5,25
local function s(b,e,g)
local c,d=0,0
for f,e in ipairs(e)do
local a=b.chips[f]or a.chip(b.chipArea)
b.chips[f]=a
a:say(e.label,b.picked==e.key,false,function()
b.picked=e.key
b.page:refresh()
end)
local e=a:GetWidth()
if c>0 and c+e>g then c,d=0,d+q end
a:ClearAllPoints()
a:SetPoint("TOPLEFT",b.chipArea,"TOPLEFT",c,-d)
c=c+e+l
end
for a=#e+1,#b.chips do b.chips[a]:Hide()end
end


function c.paintBanner(b)
local e,f=k(),g()
if not f then return end
b.switch:SetShown(e~="never")
b.switch:show(e=="on")
b.reset:SetShown(e~="never"and o.special(d)~=nil)
local d=p.field(d,"enabled")
b.sub:SetText(e=="off"and d and d.help or"")
local d=h+m
b.area:SetShown(e=="on")
b.chipArea:SetShown(e=="on")
if e=="on"then
local a=c.chips()
local c=false
for d,a in ipairs(a)do c=c or a.key==b.picked end
if not c then b.picked=a[1]and a[1].key or nil end
local c=v(b,f)
b.area.fit:SetText(c<0.999 and string.format("Shown at %d%% to fit",math.floor(c*100+0.5))or"")

s(b,a,math.max((b.chipArea:GetWidth()or 0),100))
d=d+n+4
end
local c=i(e)
for e,f in ipairs(c)do
local c=b.lines[e]
if not c then
c=b.frame:CreateFontString(nil,"OVERLAY",a.font("small"))
a.tint(c,"heroText")
b.lines[e]=c
end
c:ClearAllPoints()
c:SetPoint("TOPLEFT",b.frame,"TOPLEFT",b.side,-(d+4+(e-1)*r))
c:SetText(f)
c:Show()
end
for a=#c+1,#b.lines do b.lines[a]:Hide()end
d=d+#c*r+h
if b.height~=d then
b.height=d
b.page:setPinHeight(d)
end
end



local i,o=28,16

local function q(c)
for d=0,1 do
for e=-1,1 do
local b=c:CreateTexture(nil,"ARTWORK")
a.fill(b,"dots")
b:SetSize(2,2)
b:SetPoint("CENTER",c,"LEFT",6+d*4,e*4)
end
end
end

local function l(a)
local b={}
for c,a in ipairs(a and a.hidden or{})do b[a]=true end
return b
end


function c.moveSlot(h,a)
local c=f.normalOrder(g())
local b
for a,c in ipairs(c)do if c==h then b=a end end
if not b then return false end
if b<a then a=a-1 end
if a==b then return true end
table.remove(c,b)
table.insert(c,a,h)
return(e.setSpecial(d,{"order"},c))
end


function c.setHidden(c,h)
local a={}
for d,b in ipairs(f.ELEMENTS)do
if(b==c and h)or(b~=c and l(g())[b])then a[#a+1]=b end
end
return(e.setSpecial(d,{"hidden"},#a>0 and a or nil))
end

local function n(a)
local c=j.spellsOf(j.SLOTS[a])[1]
local c,b=b.Spells.highest(c or 0)
return b or f.SLOT_ICON[a]
end

local function j(e)
local d=a.row(e.content,4*i)
d.rows={}
for f=1,4 do
local b=CreateFrame("Button",nil,d)
b:SetHeight(i-2)
b:SetPoint("TOPLEFT",0,-(f-1)*i)
b:SetWidth(260)
b:EnableMouse(true)
local h=b:CreateTexture(nil,"HIGHLIGHT")
h:SetAllPoints()
a.fill(h,"white",0.05)
q(b)
b.box=a.checkBox(b,a.metric("form","checkBox"))
b.box:SetPoint("LEFT",o,0)
b.box:SetScript("OnClick",function()
c.setHidden(b.el,not l(g())[b.el])
d.refresh()
end)
a.setTip(b.box,"Shown","Show this slot on the bar.")
b.icon=b:CreateTexture(nil,"ARTWORK")
b.icon:SetSize(20,20)
b.icon:SetPoint("LEFT",b.box,"RIGHT",8,0)
a.cropIcon(b.icon)
b.text=a.fontString(b,"label")
b.text:SetPoint("LEFT",b.icon,"RIGHT",8,0)
a.draggable(b,{payload=function()return b.el end,icon=function()return n(b.el)end,
label=function()return b.text:GetText()end,
scroll={frame=e.scroll,by=function(a)e:scrollBy(a)end}})
d.rows[f]=b
end
d.zone=a.dropZone(d,{rows=function()return d.rows end,
drop=function(a,b)c.moveSlot(a,b)end,clip=e.scroll})
return a.finishRow(d,function()
local b=g()
if not b then return end
local e=l(b)
for c,b in ipairs(f.normalOrder(b))do
local c=d.rows[c]
c.el=b
c.box:setChecked(not e[b])
c.icon:SetTexture(n(b))
c.icon:SetDesaturated(e[b]and true or false)
c.text:SetText(f.ELEMENT_LABELS[b])
a.tint(c.text,e[b]and"off"or"text")
end
end)
end





local function l(c,b,h)
local function f()
local a=g()
return h()and a~=nil and e.shown(b,a)
end
if b.heading then
c:subhead(b.label,nil,f)
return
end
local function j()
local a=e.read(g(),b.path)
if b.widget=="choice"and a==nil then return e.NONE end
return a
end
local function h(a)
if b.widget=="choice"and a==e.NONE then a=nil end
return(e.setSpecial(d,b.path,a))
end
local i={}
if b.widget=="choice"then
i.choices=function()
local b,c=e.choices(b,g())
local a={}
for d,b in ipairs(b)do a[d]={b,c[b]}end
return a
end
end
local d
if b.widget=="edit"or b.widget=="text"then
d=a.textbox(c.content,b.label,b.field.tip,function()
local a=e.read(g(),b.path)
return a==nil and""or tostring(a)
end,function(a)
if b.widget=="text"then return h(a~=""and a or nil)end
if a==""and e.optional(b.field)then return h(nil)end
local a=tonumber(a)
return a~=nil and h(a)
end,i)
else
d=a.fieldRow(c.content,b,j,h,i)
end

if not d then return end
c:addRow(d,f)
if b.field and b.field.help then c:hint(b.field.help,nil,f)end
if b.widget=="sound"then c:hint(a.SOUND_NOTE,nil,f)end
end


local function n()
local c={}
local function f(a,d,g)
for b,a in ipairs(p.fieldsOf(a))do
local b={}
for a,c in ipairs(d)do b[a]=c end
b[#b+1]=a.name
local d=a.section or g
c[#c+1]={key=e.pathKey(b),section=d}
if a.type=="record"and a.record~="ownStyles"and not a.style then f(a.record,b,d)end
end
end
f(d,{},nil)
return c
end



function c.model(k)
local b,h={},{}
for c,a in ipairs(f.rows())do b[a.key],h[a.key]=a.build,a.after end
b.order=function(a,b)
a:addRow(j(a),b.shown)
a:hint(c.ORDER_HINT,4,b.shown)
end
local function l(a)
while a do
if b[a]then return a end
a=a:match("^(.*)%.[^.]+$")
end
end
local g,i={},{}
for b,a in ipairs(n())do
g[a.key],i[a.key]=b,a.section
end

i.order,g.order="layout",0
local a,j={},{}
for c,b in ipairs(e.recordSections(d,k))do
if b.style then
j[#j+1]=b
else
local c={}
for b,a in ipairs(b.rows)do
if not l(a.key)then c[#c+1]={row=a,at=g[a.key]or 0}end
end
a[b.key]=c
end
end
local d={}
for b,e in pairs(b)do
local c=i[b]
if c then
local d=a[c]or{}
a[c]=d
local a=h[b]and g[h[b]]and g[h[b]]+0.5 or g[b]
local c=1
for b,d in ipairs(d)do if d.at<=a then c=b+1 end end
table.insert(d,c,{hand=b,build=e,at=a})
else
d[#d+1]={hand=b,build=e}
end
end
table.sort(d,function(a,b)return a.hand<b.hand end)
for d,b in ipairs(d)do
if a[b.hand]or c.sectionTitle(b.hand)then
a[b.hand]=a[b.hand]or{}
table.insert(a[b.hand],{hand=b.hand,build=b.build,at=math.huge})
end
end
local b={}
for d,c in ipairs(f.SECTIONS)do
b[#b+1]={key=c.key,title=c.title,items=a[c.key]or{}}
end
return b,j
end

function c.sectionTitle(b)
for c,a in ipairs(f.SECTIONS)do
if a.key==b then return a.title end
end
end

local j={}
for b,a in ipairs(f.SECTIONS)do j[a.key]=a end


local function i(c)
local a=k()
if a=="never"then return false end
if a~="on"then return false end
local a=j[c]
if a and a.shown then
local a,b=b.try("totem page section "..c,a.shown,g())
return a and b and true or false
end
return true
end

c.sectionShown=i



local function j(a,b)
u.special(a,d,b,{shown=function()return i("style")end})
end

a.registerPage(d,{build=function(a)
local f=w(a)
a:pin(f.frame,h+m+h,function()c.paintBanner(f)end,12)
a.banner=f
local c,k=c.model(g()or{})
for c,f in ipairs(c)do
local c=f.key
local function h()return i(c)end
if c=="style"then
a:section("Style",h)
end
if#f.items>0 then

local i=c=="style"
a:block({key=c,title=not i and f.title or nil,card=not i or nil,shown=h})
for f,c in ipairs(f.items)do
if c.row then
l(a,c.row,h)
else
local d={key=d,view=g,shown=h,
set=function(a,b,c)return e.setSpecial(d,a,b,c)end}
b.try("totem page row "..c.hand,c.build,a,d)
end
end
end
if c=="style"then
for c,b in ipairs(k)do j(a,b)end
end
end
a:endBlock()
end})
