



local b,a=...
local f,i,e,L,c,M,x,l,y,b,m,d,o=
a.Schema,a.Events,a.Combat,a.Quiet,a.Layers,a.Media,a.Spells,a.Store,a.Totems,a.TotemBar,
a.TotemTimers,a.Debug,a.Weapons

local g={}
a.TotemRange=g
local z=c.get("icon")









d.experimental("the totem bar's out of range marks for Flametongue, Windfury and Mana Tide totems: their buff on"
.." you (TO-11's four totems T 70338; these three's buffs unrecorded)","C")
d.experimental("Ghost Wolf's form read in combat, shutting the weapon totems' marks (UN-15: 16 at rest; EP-20)","C")



local function h(a)
local a=a and a.timeLeft
return a~=nil and a.bar==true and a.barPlace=="beside"
end

local function d(b,a)return not(a and a.shape=="none")end
f.record("totemBarRange",{fields={
{name="shown",type="boolean",default=true,section="range",label="Show",
help="While you're out of range of your totems that buff you. It can take a few seconds, as the buff"
.." lingers."},
{name="marks",type="choice",choices={"out","both"},default="out",
labels={out="Out of range only",both="Out of range and in range"},under={"shown",true},
shownIf=d,section="range",label="Marks"},
{name="greyed",type="boolean",default=false,under={"shown",true},section="range",
label="Greyed icon",help="Greys out the whole totem picture while you're out of range."},
{name="shape",type="choice",choices={"strip","dot","none"},default="strip",
labels={strip="Strip",dot="Dot",none="None"},under={"shown",true},section="range",
label="Shape"},
{name="inColour",type="colour",default="#33cc40cc",under={"marks","both"},shownIf=d,
section="range",label="In range colour",help="While your own totem's buff is on you."},
{name="colour",type="colour",default="#e61f14cc",under={"shown",true},shownIf=d,
section="range",label="Colour"},
{name="thickness",type="number",default=7,min=1,max=12,step=1,unit="px",
under={"shape","strip"},section="range",label="Thickness"},
{name="dotSize",type="number",default=12,min=3,max=30,step=1,unit="px",
under={"shape","dot"},section="range",label="Dot size"},
{name="x",type="number",default=0,min=-48,max=48,step=1,unit="px",under={"shape","dot"},
section="range",label="X offset",help="It stays inside the icon, or beside it."},
{name="y",type="number",default=0,min=-48,max=48,step=1,unit="px",under={"shape","dot"},
section="range",label="Y offset"},
{name="place",type="choice",choices={"in","beside"},default="in",
labels={["in"]="In the icon",beside="Beside the icon"},under={"shown",true},shownIf=d,
section="range",label="Place",help="Beside: on the side away from the pickers."},
{name="gap",type="number",default=3,min=0,max=20,step=1,unit="px",under={"place","beside"},
shownIf=d,section="range",label="Distance",help="From the icon or the time bar."},
{name="order",type="choice",choices={"after","before"},default="after",
labels={after="Time bar nearer the icon",before="Mark nearer the icon"},under={"place","beside"},
shownIf=function(a,b)return h(a)and d(a,b)end,section="range",
label="Order"},
}})
f.record("totemBar",{fields={
{name="range",type="record",record="totemBarRange",label="Out of range"},
}})





local A,v=200,100
f.record("totemRangeBuff",{fields={
{name="family",type="integer",required=true,min=1,max=99999999},
{name="id",type="integer",required=true,min=1,max=99999999},
}})
f.record("totemRangeCaches",{fields={
{name="buffs",type="list",record="totemRangeBuff",maxItems=A},
{name="seen",type="list",of="integer",item={min=1,max=99999999},unique=true,
maxItems=v},
}})
f.record("caches",{fields={{name="totemRange",type="record",record="totemRangeCaches"}}})



local w={
earth={8075,8071},
fire={8181,8227},
water={5394,5675,8184,16190},
air={8835,10595,15107,8512},
}

local E={[8075]=true,[8071]=true,[5394]=true,[5675]=true}


local I={[8227]=8024,[8512]=8232}

local N=1
local O=2
local P=3
local Q=3
local n=2
local p=2
local B=1
local q="DisableUntrustedLayoutScriptsTemplate"
local R="Interface\\CharacterFrame\\TempPortraitAlphaMask"

local C=c.curve({0,0,0.05,1})


local r={}
local d={}
local j
for c,b in pairs(w)do
for e,b in ipairs(b)do
r[b]=c
d[b]={}
local a=a.SpellTable.families[b]
for c,a in ipairs(a and a.gives and a.gives.player or{})do d[b][a]=true end
end
end

local function s(b)
if type(b)~="number"or a.isSecret(b)then return nil end
return(x.family(b))
end

local function k(b,a)
local a=s(a)
return a and r[a]==b and a or nil
end
function g.covers(a,b)return k(a,b)~=nil end

local function f(a)return a.marks=="both"and a.shape~="none"end


local h={}
local u=false
local function t()
local a=l.caches()
if not a then return nil end
a.totemRange=a.totemRange or{}
return a.totemRange
end
local function l()
if u then return end
local a=t()
if not a then return end
u=true
for b,a in ipairs(a.buffs or{})do
if d[a.family]then d[a.family][a.id]=true end
end
for b,a in ipairs(a.seen or{})do h[a]=true end
end
local function D(a,b,c)
a[#a+1]=b
while#a>c do table.remove(a,1)end
end

local function u(a)
l()
return E[a]or h[a]==true
end
local function S(b)
local a=t()
if not a or h[b]then return end
h[b]=true
a.seen=a.seen or{}
D(a.seen,b,v)
end


local function E(b)
l()
local a={}
for c,b in ipairs(w[b])do
for b in pairs(d[b])do a[b]=true end
end
return a
end
local function F(b)
local a={}
for b in pairs(b)do a[#a+1]=b end
table.sort(a)
return table.concat(a,",")
end



local G={}

local function H(b)
local b=I[b]
if not b then return nil end
if GetTime()<(G[b]or 0)then return"its imbue cast"end
local c=o.imbue("main")
if c==nil or c==b or c=="unknown"then return"a main-hand imbue"end

if not GetShapeshiftFormID then return"shapeshifted"end
local c,b=a.try("totem range form",GetShapeshiftFormID)
if not c or a.isSecret(b)or(b~=nil and b~=0)then return"shapeshifted"end

if not o.itemOf("main")then return"no main-hand weapon"end
return nil
end



local function I(a)return c.truePixel()/((a and a.scale)or 1)end
local h=c.round
local function v(a,b,c)return math.max(b,math.min(a,c))end
local w=c.part("border")
local function T(a,b)
local c=a.styles and a.styles.border
if not c then return 0 end
return w.framing(c,math.min(b.w,b.h),a.scale).inset
end
local function w(b,a)
return c.lineWidth(h(a.shape=="dot"and a.dotSize or a.thickness,1),(b and b.scale)or 1)
end

local J=m.awaySide

local c={below={"y",-1},above={"y",1},left={"x",-1},right={"x",1}}
local function K(d,a,e)
local b=a.gap
if a.shape=="dot"then
local c=c[e]
b=math.max(b+a[c[1]]*c[2],0)
end
return h(b,I(d))
end

function g.beside(b,c)
local a=b and b.range
if not(a and a.shown and a.place=="beside"and a.shape~="none"and c)then return nil end
local c=a.order~="before"and m.beside(b,c)or nil
local d=c and c.side or J(b)
local c=(c and c.reach or 0)+K(b,a,d)
return{side=d,offset=c,reach=c+w(b,a)}
end

m.markFirst(function(b,c)
local a=b.range
if not(a and a.shown and a.place=="beside"and a.order=="before"and a.shape~="none"and c)then return 0 end
return K(b,a,J(b))+w(b,a)
end)


local function m(d,b)
local c,j=d.range,I(d)
if c.shape=="none"then return nil end
local f,i,a,l=b.w,b.h,w(d,c),c.shape=="dot"
local e=l and"dot"or"strip"
local g=g.beside(d,b)
if g then
local b,k=g.side,g.offset
local n=b=="below"or b=="above"
local m=n and f or i
local d,g=0,m
if l then
local b=n and c.x or-c.y
d,g=v(h((m-a)/2+b,j),0,m-a),a
end
if b=="below"then return{x=d,y=i+k,w=g,h=a},e end
if b=="above"then return{x=d,y=-(k+a),w=g,h=a},e end
if b=="left"then return{x=-(k+a),y=d,w=a,h=g},e end
return{x=f+k,y=d,w=a,h=g},e
end

local b=T(d,b)
local d=d.timeLeft
local d=d~=nil and d.bar==true and d.barPlace~="beside"and d.barEdge=="top"
if l then
local d=d and i-b-a or b
return{x=v(h((f-a)/2+c.x,j),b,f-b-a),y=v(h(d-c.y,j),b,i-b-a),
w=a,h=a},e
end
return{x=b,y=d and i-b-a or b,w=math.max(f-2*b,j),h=a},e
end



local function v(a,b,c)
local a=CreateFrame("Frame",nil,a,c)
a:SetFrameLevel(b)
a.copy=z.create(a)
a.copy.cd:Hide()
a.copy.frame:Hide()


local function b(b,a,c)
local c,a=b:CreateTexture(nil,a,nil,c),b:CreateTexture(nil,a,nil,c)
local b=b:CreateMaskTexture()
b:SetTexture(R,"CLAMPTOBLACKADDITIVE","CLAMPTOBLACKADDITIVE")
b:SetAllPoints(a)
a:AddMaskTexture(b)
c:Hide()
a:Hide()
return{strip=c,dot=a}
end
a.own,a.onCopy=b(a,"ARTWORK",0),b(a.copy.frame,"OVERLAY",7)
return a
end



local function h(c,b,e)
local a,d=m(c,b)
local c=e~="in"and c.range.greyed==true
if not c then return a,d,a,false end
local c={x=0,y=0,w=b.w,h=b.h}
if a then
local d,e=math.min(0,a.x),math.min(0,a.y)
local a,b=math.max(b.w,a.x+a.w),math.max(b.h,a.y+a.h)
c={x=d,y=e,w=a-d,h=b-e}
end
return c,d,a,true
end

local I,w="#00000066",{enabled=false}



local function m(b,j,f,m)
local c,k=j.rect,f and f.range
if not(c and k)then return end
local e=b.laid
local d,l,g,i
if e then d,l,g,i,c=e.u,e.kind,e.mr,e.grey,e.rect
else d,l,g,i=h(f,c,m)end
local e,h=b.own,b.onCopy
if i then e,h=b.onCopy,b.own end
for a,c in ipairs({"strip","dot"})do
local a=e[c]
h[c]:Hide()
if d and c==l then
a:ClearAllPoints()
a:SetPoint("TOPLEFT",b,"TOPLEFT",g.x-d.x,-(g.y-d.y))
a:SetSize(g.w,g.h)
a:SetColorTexture(M.rgba(m=="in"and k.inColour or k.colour))
a:Show()
else
a:Hide()
end
end
local e=b.copy
if not i then
e.frame:Hide()
return
end
e.frame:ClearAllPoints()
e.frame:SetPoint("TOPLEFT",b,"TOPLEFT",-d.x,d.y)
e.frame:SetSize(c.w,c.h)
z.apply(e,{desaturated=true,overlay=true,overlayColour=I,sweep=w,time=w,
framedBy=f.styles and f.styles.border,scale=f.scale},{level=b:GetFrameLevel()},
{x=0,y=0,w=c.w,h=c.h})
local b=j.s and j.s.icon
if a.isSecret(b)or b then e.tex:SetTexture(b)end
e.frame:Show()
end








local c={}
c.__index=c

local function w(b,a)
local a=setmetatable({slot=b,inverted=a,waiting=0,wanted=false,on=true,
key="totem range "..b.slot..(a and" in"or" out")},c)
local c=b.level+B
a.hold=CreateFrame("Frame",nil,b.look)
a.hold:SetAllPoints(b.look)
a.hold:SetFrameLevel(c)
a.hold:SetAlpha(0)

a.hold:SetScript("OnShow",function()a:wait()end)
a.cell=CreateFrame("Frame",nil,a.hold)
a.cell:SetPoint("TOPLEFT",b.look,"TOPLEFT",0,0)
a.cell:SetSize(1,1)
a.ids={}
a.cw,a.ch=1,1
a.clip=CreateFrame("Frame",nil,a.hold,q)
a.clip:SetClipsChildren(true)
a.clip:SetFrameLevel(c)
a.area=CreateFrame("Frame",nil,a.clip,q)
a.area:SetAllPoints(a.cell)
a.area:SetFrameLevel(c)
a.mark=v(a.area,c,q)
a:make()
return a
end



function c:make()
if self.sensor then return true end
local c,b=E(self.slot.element),self
local a=a.try(b.key.." sensor",function()
local a=CreateFrame("AuraContainer",nil,b.hold,"CustomAuraContainerTemplate")
a:SetPoint("TOPLEFT",b.cell,"TOPLEFT",0,0)
a:SetFrameStrata("MEDIUM")
a:SetUnit("player")
pcall(a.EnableMouse,a,false)
pcall(a.SetFlowLayoutPadding,a,0,0,0,0)
a:AddAuraGroup("sensor",b.inverted and"HELPFUL|PLAYER"or"HELPFUL",{
candidateFilters={includeSpellIDs=c},maxFrameCount=1,
layout={elementWidth=b.cw+p,elementHeight=b.ch},
initializeFrame=function(a)
a:SetSize(1,1)
pcall(a.EnableMouse,a,false)
end,
})
b.sensor=a
end)
if not(a and b.sensor)then
b.sensor=nil
return false
end
b.ids,b.applied=c,F(c)
b.clip:ClearAllPoints()
if b.inverted then
b.clip:SetPoint("TOPLEFT",b.sensor,"TOPLEFT",0,0)
b.clip:SetPoint("BOTTOMRIGHT",b.sensor,"BOTTOMRIGHT",-p,0)
else
b.clip:SetPoint("TOPLEFT",b.sensor,"TOPRIGHT",0,0)
b.clip:SetPoint("BOTTOMRIGHT",b.cell,"BOTTOMRIGHT",0,0)
end
b:wait()
return true
end



function c:ready()
return self.sensor~=nil and self.on and self.waiting==0 and not self.stale
end
function c:update()
self.hold:SetAlpha((self.wanted and self:ready())and 1 or 0)
end

local function q(a)
a.waiting=a.waiting-1
if a.waiting>0 then
i.atFrameEnd(a.key,q,a)
return
end
a:update()
end
function c:wait()
self.waiting=2
self:update()
i.atFrameEnd(self.key,q,self)
end
function c:want(a)
a=a and true or false
if a==self.wanted then return end
self.wanted=a
self:update()
end

function c:setOn(a)
a=a and true or false
if a==self.on then return end
self.on=a
self.hold:SetShown(a)
self:update()
end

function c:place(b)
local c,d=b.w+n+1,b.h+2
self.cell:ClearAllPoints()
self.cell:SetPoint("TOPLEFT",self.slot.look,"TOPLEFT",b.x-n,-(b.y-1))
self.cell:SetSize(c,d)
self.mark:ClearAllPoints()
self.mark:SetPoint("TOPLEFT",self.area,"TOPLEFT",n,-1)
self.mark:SetSize(b.w,b.h)
if self.sensor and(c~=self.cw or d~=self.ch)then
self.cw,self.ch=c,d
a.try(self.key.." layout",self.sensor.SetAuraGroupLayout,self.sensor,"sensor",
{elementWidth=c+p,elementHeight=d})
self:wait()
end
end


function c:refilter()
local b=E(self.slot.element)
local c=F(b)
if not self.sensor or c==self.applied then return end
local a=a.try(self.key.." filter",self.sensor.SetAuraGroupCandidateFilters,self.sensor,"sensor",
{includeSpellIDs=b})
if a then self.ids,self.applied=b,c end
self.stale=not a
self:wait()
end
function c:describe()
local a=0
for b in pairs(self.ids)do a=a+1 end
return string.format("%s: sensor %s, %d buffs, %s, wanted %s%s",self.inverted and"in range"or"out of range",
self.sensor and"made"or"not made",a,self.on and"on"or"off",tostring(self.wanted),
(self.waiting>0 and", settling"or"")..(self.stale and", filter not taken"or""))
end



local function p(b)
local a=b.range
if not a then
a={open=false,settled=0,shutUntil=0}
b.range=a
end
return a
end



local function q(a,c,d)
local c=c and c.range
if not(c and c.shown and a.shown and a.s.down and b.running())then return false end
if GetTime()<d.shutUntil or L.isQuiet(nil)then return false end
local a=k(a.element,a.s.owner)
return a~=nil and u(a)and not H(a)
end



local function n(c,e)
local b=c.range
if not(b and b.out)then return end
local d=q(c,e,b)
if d and not b.open then b.settled=GetTime()+N end
b.open=d
local d=d and GetTime()>=b.settled
b.out:want(d)
if b.inn then b.inn:want(d and f(e.range))end
local c,e,f=c.s.duration,false,0
if d and c and C then e,f=a.try("totem range time",c.EvaluateRemainingDuration,c,C)end
b.out.mark:SetAlpha(e and f or 0)
if b.inn then b.inn.mark:SetAlpha(e and f or 0)end
end


local function q(b)
l()
for b in pairs(d[b])do
local c,b=a.try("totem range buff",C_UnitAuras.GetPlayerAuraBySpellID,b)
if c and b~=nil and not a.isSecret(b)and not a.isSecret(b.isFromPlayerOrPlayerPet)
and b.isFromPlayerOrPlayerPet==true then
return true
end
end
return false
end



local function z(c,b)
local a=b.look
if not a or GetTime()<a.at then return end
local c=s(c.s.owner)
if c and c~=a.family then
b.look=nil
return
end
if e.inCombat()or e.aurasSecret()then
a.at=GetTime()+1
return
end
if q(a.family)then
S(a.family)
b.look=nil
else
a.tries=a.tries-1
a.at=GetTime()+1
if a.tries<=0 then b.look=nil end
end
end




local function c()
if not(b.running()and C_UnitAuras.GetAuraDataByIndex)then return end
local c=b.view()
if not(c and c.range and c.range.shown)or e.inCombat()or e.aurasSecret()then return end
if not j then
j={}
for b,a in pairs(d)do
for a in pairs(a)do
local a=x.nameOf(a)
if a then j[a]=b end
end
end
end
l()
local f={}
for b=1,40 do
local c,b=a.try("totem range learn",C_UnitAuras.GetAuraDataByIndex,"player",b,"HELPFUL|PLAYER")
if not c or b==nil or a.isSecret(b)then break end
local c=not a.isSecret(b.name)and j[b.name]
local e=b.spellId
if c and type(e)=="number"and not a.isSecret(e)and not d[c][e]and not a.isSecret(b.duration)
and b.duration==0 then
d[c][e]=true
local a=t()
if a then
a.buffs=a.buffs or{}
D(a.buffs,{family=c,id=e},A)
end
f[r[c]]=true
end
end
for a=1,4 do
local a=b.slots[a]
local b=a and a.range
if b then
for c,b in ipairs({b.out or false,b.inn or false})do
if b and(f[a.element]or b.stale)then b:refilter()end
end
end
end
end
i.onUnit("UNIT_AURA","player","totem range",c)



i.onUnit("UNIT_SPELLCAST_SUCCEEDED","player","totem range",function(c,d,e,a)
local a=s(a)
if not(a and o.IMBUES[a])then return end
G[a]=GetTime()+P
if not b.running()then return end
local a=b.view()
for c=1,4 do n(b.slots[c],a)end
end)


local function a(b,d,e)
local g=e.range
if b.preview then
local a=b.rangeStandIn
local c=a and h(e,d,a.which)
if c then
a:ClearAllPoints()
a:SetPoint("TOPLEFT",b.look,"TOPLEFT",c.x,-c.y)
a:SetSize(c.w,c.h)
end
return
end
local c=p(b)
local a=h(e,d,"out")
local i=g.shown and b.shown and a~=nil
if i and not c.out then c.out=w(b,false)end
if i and f(g)and not c.inn then c.inn=w(b,true)end
for j,a in ipairs({c.out or false,c.inn or false})do
if a then
local f=i and(a==c.out or f(g))
a:setOn(f)
if f then
a:make()
local c=a==c.out and"out"or"in"
local f,g,h,i=h(e,d,c)
a.mark.laid={u=f,kind=g,mr=h,grey=i,rect={w=d.w,h=d.h}}
a:place(f)
m(a.mark,b,e,c)
a:refilter()
end
end
end
end


local function i(a)
local b=a.rangeStandIn
if not b then
b=v(a.look,a.level+B)
a.rangeStandIn=b
end
return b
end


local function j(a,c)
if a.s.preview~="range"or not c.range.shown then return nil end
local d=true
for e,b in ipairs(b.normalOrder(c))do
local e=y.SLOTS[b]
local h=a.preview.slotList[e]
if h.shown and g.covers(b,y.spellsOf(e)[1])then
if h==a then
if d then return"out"end
return f(c.range)and"in"or nil
end
d=false
end
end
return nil
end
local function d(a,b,c)
local d=c and c.range
if not d then return end
if a.preview then
local e=j(a,c)
if not e and not a.rangeStandIn then return end
local b=i(a)
b.which=e
local d=e and a.rect and h(c,a.rect,e)
b:SetShown(d~=nil)
if d then
b:ClearAllPoints()
b:SetPoint("TOPLEFT",a.look,"TOPLEFT",d.x,-d.y)
b:SetSize(d.w,d.h)
m(b,a,c,e)
end
return
end
local b=a.range
if not(b and b.out)then return end
m(b.out.mark,a,c,"out")
if b.inn then m(b.inn.mark,a,c,"in")end

if not(d.shown and a.shown and(d.greyed or d.shape~="none"))then
b.out:setOn(false)
if b.inn then b.inn:setOn(false)end
elseif b.inn and not f(d)then
b.inn:setOn(false)
end
n(a,c)
end




local function g(c,a,e)
if c.preview then return end
local d=p(c)
if a=="placed"or a=="owner"or a=="emptied"then
d.open=false
elseif a=="dismissed"then
d.shutUntil=GetTime()+O
elseif a=="cast"then
local a=k(c.element,e)
if a and not u(a)then d.look={family=a,at=GetTime()+1,tries=Q}end
end
n(c,b.view())
end

b.onLayout("range",function(b,d,a)if not a then c()end end)

b.tick("range",function(a,c,b)
if a.preview or not a.range then return end
z(a,a.range)
n(a,b)
end)

local function c()
local a=b.view()
local a=a and a.range
if not a then return{}end
local d={string.format("out of range: %s, %s%s, %s, %s",a.shown and"on"or"off",a.shape,
a.greyed and" and greyed"or"",
a.place=="beside"and"beside"or"in the icon",f(a)and"in range too"or"out of range only")}
local f=not(e.inCombat()or e.aurasSecret())
for a=1,4 do
local c=b.slots[a]
local a=c and c.range
if a and a.out then
local e=c.s
local b=e.down and k(c.element,e.owner)
local g=not e.down and"none"or not b and"without a buff"
or(u(b)and"with a buff"or"with a buff, not confirmed yet")
local f=b and(f and(q(b)and", your buff on you"or", your buff not on you")
or", your buff unreadable now")or""
local b=b and H(b)
local e={a.out:describe()}
if a.inn then e[2]=a.inn:describe()end
d[#d+1]=string.format("range %s: totem %s%s%s, open %s; %s",c.element,g,f,
b and(", shut: "..b)or"",tostring(a.open),table.concat(e,"; "))
end
end
return d
end

b.part("range",{
order=40,
layout=a,
paint=d,
event=g,
stopped=function(a)
local a=a.range
if not a then return end
a.open,a.look=false,nil
if a.out then a.out:want(false)end
if a.inn then a.inn:want(false)end
end,
chips={"range"},
describe=c,
})
