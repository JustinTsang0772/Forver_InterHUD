


local a,b=...
local e,w,d,g,n,k,a,f=
b.Schema,b.Events,b.Layers,b.Media,b.Spells,b.Totems,b.TotemBar,b.Debug

local c={}
b.TotemTimers=c
















f.experimental("the totem bar's countdown: a duration text binding on a totem's duration with our formatter, its"
.." colours by time left (TO-14 T 70205; CD-13's colours T 70338)","T 70205")
f.experimental("the totem bar's countdown tenths as a formatter rule (ShamanForever's; no record)","C")
f.experimental("the totem bar's Expiring gate: a curve on the slot's duration into its alpha, polled, held past its"
.." zero till the slot empties (A6; TO-7's curve route on a live duration and on an ended one; ShamanForever ships"
.." the gate)","C")
f.experimental("the totem bar's GCD sweep from its multi-cast action (C_ActionBar.GetActionCooldown's isOnGCD,"
.." CD-9 T 70009; GetActionCooldownDuration into our Cooldown: ShamanForever ships it)","C")


local f={off="2m, then seconds",["2m"]="1:31 in the last 2 minutes",
["5m"]="1:31 in the last 5 minutes",["10m"]="1:31 in the last 10 minutes"}
local s={off=0,["2m"]=120,["5m"]=300,["10m"]=600}
e.record("totemBarTimeLeft",{fields={
{name="text",type="boolean",default=true,label="Countdown text"},
{name="textColour",type="colour",default="#80ff66",under={"text",true},label="Text colour"},
{name="textSize",type="number",default=12,min=6,max=48,step=1,unit="px",under={"text",true},
label="Text size"},
{name="textPlace",type="choice",choices={"centre","topLeft","bottom"},default="centre",
labels={centre="Centre",topLeft="Top left",bottom="Bottom"},under={"text",true},
label="Text position"},
{name="abbrev",type="choice",choices={"off","2m","5m","10m"},default="off",labels=f,
under={"text",true},label="Time format"},
{name="timeColours",type="boolean",default=false,under={"text",true},label="Colour by time left"},
{name="soon",type="number",default=10,min=1,max=60,step=1,unit="s",
under={"timeColours",true},label="Soon",help="Seconds left when the first colour starts."},
{name="soonColour",type="colour",default="#ffd91a",under={"timeColours",true},label="Soon colour"},
{name="now",type="number",default=3,min=1,max=60,step=1,unit="s",
under={"timeColours",true},label="Now",help="Seconds left when the second colour starts."},
{name="nowColour",type="colour",default="#ff4033",under={"timeColours",true},label="Now colour"},
{name="tenths",type="number",default=0,min=0,max=10,step=1,unit="s",under={"text",true},
label="Tenths below",
help="Show tenths decimal place when the time value is less than this many seconds. 0 means never show tenths."},
{name="swipe",type="boolean",default=false,label="Swipe"},
{name="swipeDarkness",type="percent",default=60,min=10,max=100,under={"swipe",true},
label="Swipe darkness"},
{name="swipeDarkens",type="boolean",default=true,under={"swipe",true},
label="Darkens as time runs out"},
{name="bar",type="boolean",default=true,label="Time bar"},
{name="barHeight",type="number",default=8,min=1,max=20,step=1,unit="px",under={"bar",true},
label="Bar height"},
{name="barPlace",type="choice",choices={"in","beside"},default="in",
labels={["in"]="In the icon",beside="Beside the icon"},under={"bar",true},label="Bar position",
help="Beside: on the side away from the pickers."},
{name="barEdge",type="choice",choices={"bottom","top"},default="bottom",
labels={bottom="Bottom",top="Top"},under={"barPlace","in"},label="Bar edge"},
{name="barSchool",type="boolean",default=true,under={"bar",true},label="In the slot's colour"},
{name="barColour",type="colour",default="#75ff59",under={"barSchool",false},label="Bar colour"},
}})



e.record("totemBarExpiringTotem",{fields={
{name="spell",type="spell",required=true,label="Totem"},
{name="name",type="string",max=64,exportOnly=true,label="Name"},
{name="seconds",type="number",default=5,min=0,max=30,step=1,unit="s",
label="Warn in the last"},
}})


local i,j,l=2484,5730,16190
local f=24

local function h(b,a)
if type(a)~="table"then return true end
if(a.seconds or 0)>0 then return true end
for b,a in ipairs(a.totems or{})do
if(a.seconds or 0)>0 then return true end
end
return false
end


e.record("totemBarExpiring",{fields={
{name="seconds",type="number",default=10,min=0,max=30,step=1,unit="s",section="expiring",
label="Warn in the last",help="Seconds before it runs out. 0 turns the warning off."},
{name="totems",type="list",record="totemBarExpiringTotem",maxItems=f,section="expiring",
default={{spell=i,seconds=5},{spell=j,seconds=5},
{spell=l,seconds=3}},label="Totems' own times"},
{name="grey",type="boolean",default=false,section="expiring",shownIf=h,label="Grey icon"},
{name="ring",type="boolean",default=false,section="expiring",shownIf=h,label="Red ring"},
{name="pulse",type="boolean",default=true,section="expiring",shownIf=h,label="Dark pulse"},
{name="glow",type="boolean",default=false,section="expiring",shownIf=h,label="Pulsing glow"},
}})

e.record("totemBar",{fields={
{name="gcdSweep",type="boolean",default=true,section="style",label="GCD sweep",
help="The sweep after every cast, as on action bars. Only with Left-click casts."},
{name="timeLeft",type="record",record="totemBarTimeLeft",section="style",label="Time left"},
{name="expiring",type="record",record="totemBarExpiring",label="Expiring"},
}})

local h,i=d.part("border"),d.part("glow")



local o,x,p,l,y=2,3,4,5,d.RUNGS.text




local q=d.curve({0,0,0.05,1})


local e=setmetatable({},{__mode="k"})
local function j(a)return n.family(a)or a end
local function r(b)
local a=e[b]
if a then return a end
a={}
local c=b.expiring or{}
for c,b in ipairs(c.totems or{})do
local c=type(b.spell)=="number"and j(b.spell)
if c and a[c]==nil then a[c]=b.seconds or 0 end
end
e[b]=a
return a
end
function c.warnSeconds(a,c)
local d=a and a.expiring or{}
local a=type(c)=="number"and not b.isSecret(c)and r(a)[j(c)]
if a then return a end
return d.seconds or 0
end




local e=Enum.NumericRuleFormatRounding and Enum.NumericRuleFormatRounding.Up
local m,t=59.0001,3540.0001
local function u(b,c)
local a={}
if c>0 then
a[#a+1]={threshold=0,format="%.1f",step=0.1,rounding=e}
a[#a+1]={threshold=c,format="%d",step=1,rounding=e}
else
a[#a+1]={threshold=0,format="%d",step=1,rounding=e}
end
if b>60 then
a[#a+1]={threshold=m,format="%d:%02d",step=1,rounding=e,
components={{div=60},{mod=60}}}
end
a[#a+1]={threshold=math.max(b,m),format="%dm",rounding=e,
components={{div=60,step=1,rounding=e}}}
a[#a+1]={threshold=t,format="%dh",rounding=e,
components={{div=3600,step=1,rounding=e}}}
return a
end
local function e(a)
local a,b,c=g.rgba(a)
return string.format("|cff%02x%02x%02x",math.floor(a*255+0.5),math.floor(b*255+0.5),
math.floor(c*255+0.5))
end

function c.breakpoints(a)
local f=u(s[a.abbrev]or 0,a.tenths or 0)
local b,c={},{}
for c,a in ipairs(f)do b[a.threshold]=true end
if a.timeColours then b[a.soon],b[a.now]=true,true end
for a in pairs(b)do c[#c+1]=a end
table.sort(c)
local e,g=e(a.soonColour or"#ffd91a"),e(a.nowColour or"#ff4033")
local d={}
for b,c in ipairs(c)do
local b
for d,a in ipairs(f)do if a.threshold<=c then b=a end end
local a=a.timeColours and(c<a.now and g or c<a.soon and e)or nil
d[#d+1]={threshold=c,step=b.step,rounding=b.rounding,components=b.components,
format=a and(a..b.format.."|r")or b.format}
end
return d
end
local m,e={},0
local function z(a)
if not(C_StringUtil and C_StringUtil.CreateNumericRuleFormatter)then return nil end
local d=table.concat({tostring(a.abbrev),tostring(a.tenths),tostring(a.timeColours),tostring(a.soon),
tostring(a.now),tostring(a.soonColour),tostring(a.nowColour)},"|")
local f=m[d]
if f~=nil then return f or nil end
if e>=32 then
wipe(m)
e=0
end
local a,b=b.try("totem bar formatter",function()
local b=C_StringUtil.CreateNumericRuleFormatter()
b:SetBreakpoints(c.breakpoints(a))

for c,a in ipairs({0,2.5,59,61,3601})do b:FormatNumber(a)end
return b
end)
m[d]=a and b or false
e=e+1
return a and b or nil
end

local s=d.emptyDuration


local function A(b)
local c=b.look
local a={}
b.timers=a


local b=CreateFrame("Frame",nil,c)
b:SetAllPoints(c)
b:SetAlpha(0)
a.gate=b
a.copy=k.pulseCopy(b)
a.copy.frame:SetAllPoints(b)
local d=a.copy.pulse
a.pulse=d
a.ring=h.create(b)
a.ring.frame:SetAllPoints(b)

b:SetScript("OnShow",function()
if a.pulseOn then d:Play()end
if a.glow and a.glowOn then i.shown(a.glow)end
end)

local b=CreateFrame("StatusBar",nil,c)
b:SetStatusBarTexture(g.WHITE)
b:SetMinMaxValues(0,1)
b:SetValue(0)
b.bg=b:CreateTexture(nil,"BACKGROUND")
b.bg:SetAllPoints()
b.bg:SetColorTexture(0,0,0,0.6)
b:Hide()
a.bar=b
a.edge=h.create(b)
a.edge.frame:SetAllPoints(b)

local d=CreateFrame("Frame",nil,c)
d:SetAllPoints(c)
local b=CreateFrame("Cooldown",nil,d,"CooldownFrameTemplate")
b:SetDrawEdge(false)
b:SetDrawBling(false)
b:SetHideCountdownNumbers(true)
b:SetSwipeColor(0,0,0,0.6)
a.sweep,a.gcd=d,b

local b=CreateFrame("Frame",nil,c)
b:SetAllPoints(c)
local c=b:CreateFontString(nil,"OVERLAY")
c:SetFont(STANDARD_TEXT_FONT,12,"OUTLINE")
a.textFrame,a.fs=b,c
if C_DurationUtil and C_DurationUtil.CreateDurationTextBinding then
local b=C_DurationUtil.CreateDurationTextBinding()
b:SetFontString(c)
b:SetZeroDurationText("")
a.binding=b
end
end


local function B(c,b)
if not b.barSchool then return g.rgba(b.barColour or"#75ff59")end
local a=a.COLOUR[c.element]
return math.min(1,a[1]*1.15),math.min(1,a[2]*1.15),math.min(1,a[3]*1.15),1
end



local e={up="below",down="above",right="left",left="right"}
function c.awaySide(a)return e[b.TotemPickers.sideOf(a)]or"below"end


local function t(a,b)return a.timers and a.timers.laid or b end

local e
function c.markFirst(a)e=a end


local function u(a)return d.truePixel()/((a and a.scale)or 1)end
local function v(a,b)return d.lineWidth(b,(a and a.scale)or 1)end
local m=d.round

function c.beside(a,f)
local d=a and a.timeLeft
if not(d and d.bar and d.barPlace=="beside"and f)then return nil end
local g=u(a)
local h=0
if e then
local b,a=b.try("totem bar mark first",e,a,f)
if b and type(a)=="number"then h=a end
end

local b=math.max(m(f.w*3/44,g),v(a,2))
local b=h+b
return{side=c.awaySide(a),offset=b,reach=b+m(d.barHeight or 8,g)+v(a,2)}
end


local function v(a,b)
local c=a.styles and a.styles.border
if not c then return 0 end
return h.framing(c,math.min(b.w,b.h),a.scale).inset
end

local C={kind="line",thickness=1,colour="#000000"}
local D="#ff0000e6"


local function E(d,g,f,i)
local a,b=d.bar,d.bar:GetParent()
local e=c.beside(f,i)
if e then g=f end
local j=g.timeLeft or{}
local c=u(g)
local f=m(j.barHeight or 8,c)
a:ClearAllPoints()
local c=false
if e then
local e,d=e.side,e.offset
if e=="below"then
a:SetPoint("TOPLEFT",b,"BOTTOMLEFT",0,-d)
a:SetPoint("TOPRIGHT",b,"BOTTOMRIGHT",0,-d)
elseif e=="above"then
a:SetPoint("BOTTOMLEFT",b,"TOPLEFT",0,d)
a:SetPoint("BOTTOMRIGHT",b,"TOPRIGHT",0,d)
elseif e=="left"then
a:SetPoint("TOPRIGHT",b,"TOPLEFT",-d,0)
a:SetPoint("BOTTOMRIGHT",b,"BOTTOMLEFT",-d,0)
c=true
else
a:SetPoint("TOPLEFT",b,"TOPRIGHT",d,0)
a:SetPoint("BOTTOMLEFT",b,"BOTTOMRIGHT",d,0)
c=true
end
else

local c=v(g,i)
local e=j.barEdge=="top"and-c or c
local d=j.barEdge=="top"and"TOP"or"BOTTOM"
a:SetPoint(d.."LEFT",b,d.."LEFT",c,e)
a:SetPoint(d.."RIGHT",b,d.."RIGHT",-c,e)
end
if c then a:SetWidth(f)else a:SetHeight(f)end
a:SetOrientation(c and"VERTICAL"or"HORIZONTAL")
a:SetRotatesTexture(c)
d.edgeShown=e~=nil
d.edge.frame:SetShown(d.edgeShown)
if e then
local b=c and f or i.w
h.apply(d.edge,{style=C,scale=g.scale,onBar=true},{level=0},
{x=0,y=0,w=c and f or b,h=c and i.h or f})
d.edge.frame:SetFrameLevel(a:GetFrameLevel()+1)
end
return f,e
end


local function u(a,d,g,e,b,f)
local a,c=a.fs,a.textFrame
local d=v(d,g)
a:ClearAllPoints()
if e.textPlace=="topLeft"then
local b=b=="top"and-(f+1)or-1
a:SetPoint("TOPLEFT",c,"TOPLEFT",1+d,b-d)
a:SetJustifyH("LEFT")
elseif e.textPlace=="bottom"then
local b=(b and b~="top")and(f+1)or 1
a:SetPoint("BOTTOM",c,"BOTTOM",0,b+d)
a:SetJustifyH("CENTER")
else
a:SetPoint("CENTER",c,"CENTER",0,0)
a:SetJustifyH("CENTER")
end
end


local function v(a,b,d)
local c=b.styles and b.styles.glow
if not c then return nil end
local e=i.kindOf(c).key
if a.glow and a.glowKey~=e then
a.glow.frame:Hide()
a.glow=nil
end
if not a.glow then
a.glow=i.create(a.gate,{style=c},{})
a.glow.frame:SetAllPoints(a.gate)
a.glowKey=e
end

i.apply(a.glow,{style=c,framedBy=b.styles and b.styles.border,scale=b.scale},
{level=d.level+l},{x=0,y=0,w=d.rect.w,h=d.rect.h})
return a.glow
end




local function m(e,b)
local a,f=e.timers,e.rect
if not(a and f and b)then return end
a.view,a.w,a.h=b,f.w,f.h
local n=t(e,b)
local c,i=b.timeLeft or{},b.expiring or{}
local d=e.level
a.gate:SetFrameLevel(d+o)
a.bar:SetFrameLevel(d+x)
a.sweep:SetFrameLevel(d+p-1)
a.gcd:SetFrameLevel(d+p)
a.textFrame:SetFrameLevel(d+y)
local m={x=0,y=0,w=f.w,h=f.h}
local j=b.styles and b.styles.border

k.applyPulse(a.copy,{overlay=i.pulse and true or false,framedBy=j,scale=b.scale},
{level=d+o},m)
a.copy.tex:SetShown(i.grey and true or false)

a.ring.frame:SetShown(i.ring and true or false)
if i.ring and j then
h.apply(a.ring,{style=j,ring=true,ringColour=D,ringSize=3,scale=b.scale},
{level=d+l},m)
for b,a in ipairs(a.ring.rings)do a.holder:Hide()end
a.ring.art:Hide()
a.ring.frame:SetFrameLevel(d+l)
end
a.glowOn=i.glow and true or false
local d=a.glowOn and v(a,b,e)or a.glow
if d then d.frame:SetShown(a.glowOn)end

local d=b.styles and b.styles.barTexture
if d then g.setBar(a.bar,d)end
a.bar:SetStatusBarColor(B(e,c))
local i,k=E(a,b,n,f)
a.barOn=c.bar and true or false
if not a.barOn then a.bar:Hide()end

h.frameSwipe(a.gcd,a.sweep,{framedBy=j,scale=b.scale},m)
if not(b.gcdSweep and n.cast)then a.gcd:Clear()end

local d=b.styles and b.styles.font
if d then g.setFont(a.fs,d,c.textSize or 12)end
a.fs:SetTextColor(g.rgba(c.textColour or"#80ff66"))
u(a,b,f,c,(a.barOn and not k)and(c.barEdge or"bottom")or nil,i)
a.textOn=c.text and true or false
a.textFrame:SetShown(a.textOn)
if a.binding then
local b=a.textOn and z(c)or nil
if b~=a.formatter then
a.formatter=b
if b then a.binding:SetFormatter(b)end
end
end

e.picture.cd:SetSwipeColor(0,0,0,(c.swipeDarkness or 60)/100)
end


local function p(c,a,b)
local b=b and b.timeLeft or{}
a.sweep={enabled=b.swipe and true or false,darkens=b.swipeDarkens and true or false}
a.time={enabled=false}
end



local e=15
local function g(a,b,d)
local c=c.warnSeconds(d,b.owner)
if c<=0 then return nil end
local a=a.timers
local b=GetTime()
if a.madeUp and b<a.madeUpEnd-0.2 then return a.madeUp,false end
local c=math.min(5,c)
a.madeUp=a.madeUp or C_DurationUtil.CreateDuration()
a.madeUp:SetTimeFromStart(b-(e-c),e)
a.madeUpEnd=b+c
return a.madeUp,true
end
local function o(b,a,c)
if a.preview=="expiring"then return(g(b,a,c))or a.duration end
return a.duration
end


local function i(a,c)
if a.barOn and q then
local b,c=b.try("totem bar time bar",c.EvaluateRemainingDuration,c,q)
a.bar:SetAlpha(b and c or 1)
end
local d=a.curve
if d then
local b,c=b.try("totem bar expiring",c.EvaluateRemainingDuration,c,d)
a.gate:SetAlpha(b and c or 0)
else
a.gate:SetAlpha(0)
end
end

local function l(b)
local a=b.timers
a.duration,a.curve=nil,nil
b.picture.cd:Clear()
a.bar:Hide()
a.gate:SetAlpha(0)
a.pulse:Stop()
a.pulseOn=false
if a.binding then a.binding:SetDuration(s())end
end


local function e(e,g,f)
local a=e.timers
if not(a and f)then return end
local h=e.rect
if h and(a.view~=f or a.w~=h.w or a.h~=h.h)then m(e,f)end
local h=g.down and o(e,g,f)or nil
if not h then return l(e)end
a.duration=h
local j,k=f.timeLeft or{},f.expiring or{}
if j.swipe then
b.try("totem bar swipe",e.picture.cd.SetCooldownFromDurationObject,e.picture.cd,h,true)
else
e.picture.cd:Clear()
end
if a.barOn then
b.try("totem bar time bar",a.bar.SetTimerDuration,a.bar,h,Enum.StatusBarInterpolation.Immediate,
Enum.StatusBarTimerDirection.RemainingTime)
a.bar:Show()
end
if a.binding then
a.binding:SetDuration(a.textOn and h or s())
a.binding:SetEnabled(a.textOn==true)
end

a.secs=c.warnSeconds(f,g.owner)
a.curve=d.lastCurve(a.secs,not e.preview)
if b.isSecret(g.icon)or g.icon then a.copy.tex:SetTexture(g.icon)end
a.pulseOn=a.curve~=nil and k.pulse and true or false
if a.pulseOn then
if not a.pulse:IsPlaying()then a.pulse:Play()end
else
a.pulse:Stop()
end
i(a,h)
end


a.tick("totemTimers",function(b,c,d)
local a=b.timers
if not(a and d)then return end
if c.preview=="expiring"and a.duration and a.madeUp==a.duration then
local f,a=g(b,c,d)

if a then return e(b,c,d)end
end
if a.duration then i(a,a.duration)end
end)



local function g(a)
local c=C_ActionBar
local e,d=b.try("totem bar HasAction",c.HasAction,a)
if not e or(not b.isSecret(d)and not d)then return nil end
local e,d=b.try("totem bar action cooldown",c.GetActionCooldown,a)
if not e or type(d)~="table"or b.isSecret(d.isOnGCD)or d.isOnGCD~=true then return nil end
local a,b=b.try("totem bar action GCD",c.GetActionCooldownDuration,a)
return a and b or nil
end
local function d()
if not a.running()then return end
local c=a.view()
for e=1,4 do
local b=a.slots[e]
local d=b and b.timers
if d then

local c=c and c.gcdSweep and t(b,c).cast
local a=c and b.shown and g(a.actionFor(e))
if a then d.gcd:SetCooldownFromDurationObject(a,true)else d.gcd:Clear()end
end
end
end
c.refreshGCD=d
w.on("SPELL_UPDATE_COOLDOWN","totemTimers",d)



local function o(a)return n.nameOf(a)or("Spell "..tostring(a))end
local function d(a)return(a and a.expiring and a.expiring.totems)or{}end
local function h(b)
local a={}
for c,b in ipairs(d(b))do a[c]={spell=b.spell,seconds=b.seconds}end
return a
end


function c.addable(a)
local e,c,a=r(a),{},{}
for b=1,4 do
for b,d in ipairs(k.spellsOf(b))do
local b=j(d)
if e[b]==nil and not c[b]then
c[b]=true
a[#a+1]={id=b,name=o(d)}
end
end
end
table.sort(a,function(a,b)return a.name<b.name end)
return a
end

local i={"expiring","totems"}

c.WORDS={add="Add a totem",hint="Give a totem its own warning time.",remove="Remove",
removeTip="Use the bar's time for this totem.",off="Off"}
c.MAX_TOTEMS=f
c.listOf=function(a)return d(a)end
local function n(a)return a==0 and c.WORDS.off or string.format("%d s",a)end

a.row("expiring.totems",function(g,a)
local j=b.Kit
local function k()return d(a.view())end
local function l(b)return function()return a.shown()and k()[b]~=nil end end
for d=1,f do
local e=j.slider(g.content,"",nil,function()
local a=k()[d]
return a and a.seconds
end,function(c)
local b=h(a.view())
if not b[d]then return false end
b[d].seconds=c
return a.set(i,b)
end,{min=0,max=30,step=1,format=n})
e.simLabel="Totem "..d
local b=CreateFrame("Button",nil,e)
b:SetSize(16,18)
b:SetPoint("LEFT",e.tail,"RIGHT",6,0)
b.icon=b:CreateTexture(nil,"ARTWORK")
b.icon:SetTexture(j.art("close"))
b.icon:SetSize(12,12)
b.icon:SetPoint("CENTER")
b:SetScript("OnClick",function()
local b=h(a.view())
table.remove(b,d)
a.set(i,b)
end)
j.setTip(b,c.WORDS.remove,c.WORDS.removeTip)
b.simRole,b.simLabel="button","Remove totem "..d
e.remove=b
local b=e.refresh
e.refresh=function(c)
local a=k()[d]
e.label:SetText(a and o(a.spell)or"")
b(c)
end
g:addRow(e,l(d))
end
g:dropdown(c.WORDS.add,nil,function()return nil end,function(d)
local b=h(a.view())
if#b>=f then return false end
local c=a.view().expiring.seconds
b[#b+1]={spell=d,seconds=c>0 and c or 5}
return a.set(i,b)
end,function()return a.shown()and#c.addable(a.view())>0 end,{choices=function()
local b={}
for c,a in ipairs(c.addable(a.view()))do b[c]={a.id,a.name}end
return b
end})
g:hint(c.WORDS.hint,nil,
function()return a.shown()and#c.addable(a.view())>0 end)
end)


a.part("timers",{
order=10,
create=A,
layout=function(a,c,b)
if a.timers then a.timers.laid=b end
m(a,b)
end,
picture=p,
paint=e,
stopped=function(a)
if a.timers then
l(a)
a.timers.gcd:Clear()
end
end,
chips={"down","expiring"},
describe=function()
local b=a.view()or{}
local c={}
for b=1,4 do
local a=a.slots[b]
local b=a and a.timers
if b then
c[#c+1]=string.format("%s %s",a.element,b.duration and("expiring at "..tostring(b.secs or 0)
.." s")or"none down")
end
end
return{string.format("timers: text %s, swipe %s, bar %s, GCD sweep %s, Expiring %s s; %s",
tostring(b.timeLeft and b.timeLeft.text),tostring(b.timeLeft and b.timeLeft.swipe),
tostring(b.timeLeft and b.timeLeft.bar),tostring(b.gcdSweep),
tostring(b.expiring and b.expiring.seconds),table.concat(c,"; "))}
end,
})
