


local a,c=...
local e,w,m,f,q,j,n,d,x,k,l=
c.Schema,c.Combat,c.Events,c.Spells,c.Layers,c.Media,c.Art,c.TotemBar,c.TotemPickers,
c.TotemExtras,c.Debug

local b={}
c.TotemKeys=b















local g={"Fire","Earth","Water","Air"}
local h,i=k.CALLS,k.RECALL
local o={"Call of the Elements","Call of the Ancestors","Call of the Spirits"}

local a={dismissAll="InterHUDKeyDismissAll",nextSet="InterHUDKeyNextSet",recall="InterHUDKeyRecall"}
for c,b in ipairs(g)do
a["cast"..b]="InterHUDKeyCast"..b
a["dismiss"..b]="InterHUDKeyDismiss"..b
end
for b,c in ipairs({"Elements","Ancestors","Spirits"})do a["call"..b]="InterHUDKeyCall"..c end
b.NAMES=a
function b.command(b)return"CLICK "..a[b]..":LeftButton"end


e.record("totemBarKeyText",{fields={
{name="shown",type="boolean",default=false,section="keys",label="Show keybinding text",
help="Set the keys in Key Bindings, under InterHUD."},
{name="colour",type="colour",default="#d9d9d9",under={"shown",true},section="keys",
label="Text colour"},
{name="size",type="number",default=13,min=6,max=30,step=1,unit="px",under={"shown",true},
section="keys",label="Text size"},
{name="x",type="number",default=0,min=-20,max=20,step=1,unit="px",under={"shown",true},
section="keys",label="Offset X"},
{name="y",type="number",default=0,min=-20,max=20,step=1,unit="px",under={"shown",true},
section="keys",label="Offset Y"},
}})
e.record("totemBar",{fields={
{name="keyText",type="record",record="totemBarKeyText",label="Key text"},
}})


l.experimental("Quick Keybind Mode on the totem bar: our own catcher binding by hover with SetBinding, never"
.." Blizzard's mixin (A12, A16; ShamanForever's technique; by eye on 70425, no row), a controller's buttons too","C")



local function e(a,b)return f.nameOf(a)or b end
local function l()
_G.BINDING_HEADER_INTERHUD_TOTEMS="Totems"
for c,a in ipairs(g)do
_G["BINDING_NAME_"..b.command("cast"..a)]="Cast "..a.." totem"
_G["BINDING_NAME_"..b.command("dismiss"..a)]="Dismiss "..a.." totem"
end
_G["BINDING_NAME_"..b.command("dismissAll")]="Dismiss all totems"
for a=1,3 do _G["BINDING_NAME_"..b.command("call"..a)]=e(h[a],o[a])end
_G["BINDING_NAME_"..b.command("nextSet")]="Next totem set"
_G["BINDING_NAME_"..b.command("recall")]=e(i,"Totemic Recall")
end
l()



local r={}
local f
function b.onNext(a)f=a end

local function e(b,c)
local a=CreateFrame("Button",a[b],UIParent,"SecureActionButtonTemplate")
a:RegisterForClicks("AnyDown","AnyUp")
if c then a:SetAttribute("type",c)end
r[b]=a
return a
end

d.forShaman("keys",function()
for a,b in ipairs(g)do
local c=e("cast"..b,"action")
c:SetAttribute("action",d.actionFor(a,d.activeSet()))
d.follower(c,function(b)return d.actionFor(a,b)end)
e("dismiss"..b,"destroytotem"):SetAttribute("totem-slot",a)
end
e("dismissAll","macro"):SetAttribute("macrotext",k.DISMISS_ALL)
for a=1,3 do e("call"..a,"spell"):SetAttribute("spell",h[a])end

local a=e("nextSet")
a:HookScript("OnClick",function(b,d,a)
if not a and f then c.try("totem bar next set",f)end
end)
e("recall","spell"):SetAttribute("spell",i)
l()
m.on("UPDATE_BINDINGS","totem bar keys",function()b.refresh()end)
end)


local i={ALT="A",CTRL="C",SHIFT="S",META="M"}
local l={MOUSEWHEELUP="WU",MOUSEWHEELDOWN="WD",SPACE="Sp",BACKSPACE="BS",CAPSLOCK="Cap",
TAB="Tab",ENTER="Ent",ESCAPE="Esc",INSERT="Ins",DELETE="Del",HOME="Hm",END="End",
PAGEUP="PU",PAGEDOWN="PD",UP="Up",DOWN="Dn",LEFT="Lt",RIGHT="Rt",NUMLOCK="NL",
NUMPADPLUS="N+",NUMPADMINUS="N-",NUMPADMULTIPLY="N*",NUMPADDIVIDE="N/",NUMPADDECIMAL="N."}
local e={}
local function h(b)
if type(b)~="string"or b==""then return""end
if e[b]then return e[b]end
local f,a="",b
while true do
local b,c=a:match("^(%u+)%-(.+)$")
if not(b and i[b])then break end
f,a=f..i[b],c
end
local d=l[a]or(a:match("^BUTTON(%d+)$")and"M"..a:match("^BUTTON(%d+)$"))
or(a:match("^NUMPAD(%d)$")and"N"..a:match("^NUMPAD(%d)$"))
if not d then
d=a
local b=_G.GetBindingText
if#a>3 and b then
local b,a=c.try("GetBindingText",b,a,1)
if b and type(a)=="string"and a~=""then d=a end
end
end
e[b]=f..d
return e[b]
end
b.keyLabel=h

local function i(a)
local a,b=c.try("GetBindingKey",GetBindingKey,a)
return a and b or nil
end




local f="UI-HUD-ActionBar-IconFrame-Mouseover"
local e=false
local function s(b,c)
local a=CreateFrame("Frame",nil,b)
a:SetAllPoints(b)
a:EnableMouse(false)
a:SetFrameLevel(c)
local c=a:CreateFontString(nil,"OVERLAY")
c:SetFont(STANDARD_TEXT_FONT,13,"OUTLINE")
c:SetPoint("TOPRIGHT",-2,-2)
local b=a:CreateTexture(nil,"OVERLAY")
b:SetAllPoints()
if n.hasAtlas(f)then b:SetAtlas(f)else b:SetColorTexture(1,0.82,0,0.3)end
b:Hide()
return{frame=a,fs=c,glow=b}
end

local function t(a,b)
local c=b and b.keyText or{}
local d=c.size or 13
local b=b and b.styles and b.styles.font
if b then j.setFont(a.fs,b,d)else a.fs:SetFont(STANDARD_TEXT_FONT,d,"OUTLINE")end
a.fs:SetTextColor(j.rgba(c.colour or"#d9d9d9"))
a.fs:ClearAllPoints()
a.fs:SetPoint("TOPRIGHT",a.frame,"TOPRIGHT",-2+(c.x or 0),-2+(c.y or 0))
end


local function f(a,b)
local b=e or(b and b.keyText and b.keyText.shown)or false
a.fs:SetText(b and h(i(a.command))or"")
a.fs:SetShown(b and true or false)
a.glow:SetShown(e)
a.glow:SetAlpha(a.hovered and 1 or 0.5)
end

local l={}
for a,c in ipairs(g)do l[a]=b.command("cast"..c)end
local y={"call","recall"}
local function n(a)
if a=="call"then return b.command("call"..d.activeSet())end
return b.command("recall")
end





local a=CreateFrame("Frame",nil,UIParent)
a:SetFrameStrata("FULLSCREEN_DIALOG")
a:EnableMouse(true)
a:EnableKeyboard(true)
a:EnableMouseWheel(true)
a:Hide()
b.catcher=a

local function o(b)
local a=_G.QuickKeybindFrame
if a and a.SetOutputText and b then a:SetOutputText(b)end
end

local function u()
local b,d=_G.QuickKeybindTooltip,a.command
if not(b and d and _G.GameTooltip_AddHighlightLine)then return end
b:SetOwner(a,"ANCHOR_RIGHT")
local a,e=c.try("GetBindingName",GetBindingName,d)
_G.GameTooltip_AddHighlightLine(b,a and e or d)
local a=i(d)
if a then
local c,d=c.try("GetBindingText",GetBindingText,a)
_G.GameTooltip_AddInstructionLine(b,c and d or a)
_G.GameTooltip_AddNormalLine(b,_G.ESCAPE_TO_UNBIND or"Press Escape to unbind.")
else
_G.GameTooltip_AddErrorLine(b,_G.NOT_BOUND or"Not bound")
_G.GameTooltip_AddNormalLine(b,_G.PRESS_KEY_TO_BIND or"Press a key to bind.")
end
b:Show()
end

local function p()
local b=a.text
a.command,a.text=nil,nil
a:Hide()
if _G.QuickKeybindTooltip then _G.QuickKeybindTooltip:Hide()end
if b then
b.hovered=false
f(b,d.view())
end
end

local function v(c,b)
if not e or InCombatLockdown()or not b then return end
if not a.pad then

a.pad=true
pcall(function()a:EnableGamePadButton(true)end)
end
a.command,a.text=b.command,b
a:ClearAllPoints()
a:SetAllPoints(c)
a:Show()
b.hovered=true
f(b,d.view())
u()
end


local function j(g)
local d=a.command
if not d or InCombatLockdown()then return end
local a
local e=_G.C_KeyBindings
if e and e.GetBindingContextForAction then
local b,c=c.try("GetBindingContextForAction",e.GetBindingContextForAction,d)
if b then a=c end
end
local f,e=GetBindingKey(d,nil,a)
if g=="ESCAPE"then
if not f then return end
SetBinding(f,nil,a)
if e then SetBinding(e,d,a)end
o(_G.KEY_UNBOUND)
else
local b=_G.GetBindingFromClick
if b and b(g)=="SCREENSHOT"then return end
local b=_G.GetConvertedKeyOrButton and _G.GetConvertedKeyOrButton(g)or g

if _G.IsKeyPressIgnoredForBinding and _G.IsKeyPressIgnoredForBinding(b)then return end
if _G.CreateKeyChordStringUsingMetaKeyState then b=_G.CreateKeyChordStringUsingMetaKeyState(b)end
local g=GetBindingAction(b,nil,a)
if f then SetBinding(f,nil,a)end
if e then SetBinding(e,nil,a)end
if SetBinding(b,d,a)then
if e and e~=b then SetBinding(e,d,a)end
local a=g and g~=""and g~=d and not GetBindingKey(g,nil,a)
if a and _G.KEY_UNBOUND_ERROR then
local a,b=c.try("GetBindingName",GetBindingName,g)
o(_G.KEY_UNBOUND_ERROR:format(a and b or g))
else
o(_G.KEY_BOUND)
end
else
if f then SetBinding(f,d,a)end
if e then SetBinding(e,d,a)end
end
end
b.refresh()
u()
end
b.bind=j

a:SetScript("OnLeave",p)
a:SetScript("OnKeyDown",function(b,a)

local b=_G.GetBindingFromClick
if b and b(a)=="SCREENSHOT"then
if _G.Screenshot then _G.Screenshot()end
return
end
j(a)
end)
a:SetScript("OnMouseUp",function(b,a)
if a~="LeftButton"and a~="RightButton"then j(a)end
end)
a:SetScript("OnMouseWheel",function(b,a)j(a>0 and"MOUSEWHEELUP"or"MOUSEWHEELDOWN")end)
pcall(function()a:SetScript("OnGamePadButtonDown",function(b,a)j(a)end)end)


d.part("keys",{
order=70,
create=function(a)
local b=s(a.look,a.level+q.RUNGS.text+1)
b.command=l[a.slot]
a.keys=b
if not a.preview then a.button:HookScript("OnEnter",function(a)v(a,b)end)end
end,
layout=function(a,c,b)
t(a.keys,b)
f(a.keys,b)
end,
describe=function()
local a={}
for b,c in ipairs(g)do
a[#a+1]=c.." "..(h(i(l[b]))~=""and h(i(l[b]))
or"none")
end
local c=r.castFire and"made"or"not made"
local b=h(i(n("call")))
return{"keys: helpers "..c.."; cast "..table.concat(a,", ").."; Call (set "..d.activeSet()
..") "..(b~=""and b or"none").."; Quick Keybind Mode "..(e and"open"or"closed")}
end,
})


local c=setmetatable({},{__mode="k"})
local function g(e,b,f)
local a=c[b]
if a then return a end
local d=b.ihudExtra
a=s(b,(d and d.level or b:GetFrameLevel())+q.RUNGS.text+1)
a.command=n(e)
c[b]=a
if not f then b:HookScript("OnEnter",function(b)v(b,a)end)end
return a
end
function b.textOf(a)return c[a]end
d.onLayout("keys",function(d,a,c)
for b,a in ipairs(y)do
local b
if c then b=c.extraFrames[a]else b=k.button(a)end
if b then
local b=g(a,b,c)
b.command=n(a)
t(b,d)
f(b,d)
end
end
end)

function b.refresh()
local b=d.view()
for a=1,4 do
local a=d.slots[a]
if a and a.keys then f(a.keys,b)end
end
for c,a in pairs(c)do f(a,b)end
end

local function c(a)
e=a and true or false
if not e then p()end
x.hoverOff("qkb",e)
d.layout()
b.refresh()
end
function b.quickKeybindOpen()return e end

local b=false
local function e()
local a=_G.QuickKeybindFrame
if b or not a then return b end
b=true
a:HookScript("OnShow",function()c(true)end)
a:HookScript("OnHide",function()c(false)end)
if a:IsShown()then c(true)end
return true
end
d.forShaman("quick keybind",function()
if e()then return end
m.on("ADDON_LOADED","totem bar quick keybind",function(b,a)
if a=="Blizzard_QuickKeybind"and e()then m.off("ADDON_LOADED","totem bar quick keybind")end
end)
end)

w.onStart("totem bar quick keybind",function()if a:IsShown()then p()end end)
