



local a,d=...
local e,u,c,v,w,b=d.Schema,d.Combat,d.TotemBar,d.Totems,d.Layers,d.Debug

local a={}
d.TotemPickers=a



















local f={"up","down","right","left"}
local k={up="Up",down="Down",right="Right",left="Left"}
e.record("totemBar",{fields={


{name="pickerSide",type="choice",choices=f,default="up",labels=k,section="layout",
label="Pickers open"},
{name="arrows",type="boolean",default=true,section="buttons",label="Arrow opens a totem picker",
help="Alt+click a slot opens it too."},
{name="hoverPickers",type="boolean",default=true,section="buttons",label="Open pickers on hover"},
{name="dropWith",type="choice",choices={"shift","alt","ctrl","off"},default="shift",
labels={shift="Shift",alt="Alt",ctrl="Ctrl",off="Off"},section="buttons",label="Drop with",
help="Click a totem in a picker with this key held to drop it."},
{name="dropPicks",type="boolean",default=false,under={"dropWith",{"shift","alt","ctrl"}},
section="buttons",label="When dropping with a modifier, also set the picked totem"},
{name="arrowSize",type="number",default=20,min=8,max=32,step=1,unit="px",
under={"arrows",true},section="buttons",label="Arrow size"},
}})

local function l(a)
local b=a and a.pickerSide
if a and a.direction=="column"then return b=="left"and"left"or"right"end
return b=="down"and"down"or"up"
end
a.sideOf=l
a.SIDE_LABELS=k


b.experimental("the totem bar's pickers opened, picked from and closed by snippets in combat (FR-5: by hover and"
.." Alt+click, a pick taken, T 70425)","T 70425")
b.experimental("the arrows lifted over an open picker and put back by the header's snippets, in combat too (FR-5:"
.." at a dummy a second slot's picker opened in one click over the first, a pick took, and the character frame"
.." covered the arrows afterwards, by the user's eye, T 70862)","T 70862")
b.experimental("No totem: a picker's multispell of spell 0 clears the slot's pick (ShamanForever's; unrecorded)","C")








local n,i,e="DIALOG",10,"MEDIUM"
local j={catch=1,strip=1,arrow=3,look=4,button=5}
a.POP_STRATA,a.POP_LEVEL=n,i





local p=[[
	local open = ...
	for i = 1, self:GetAttribute("ihud-pops") or 0 do
		local pop = self:GetFrameRef("pop" .. i)
		if i == open then pop:Show() else pop:Hide() end
	end
	if open > 0 and self:GetAttribute("ihud-hovermode") then
		local pop = self:GetFrameRef("pop" .. open)
		pop:RegisterAutoHide(0.3)
		pop:AddToAutoHide(self:GetFrameRef("slot" .. open))
		pop:AddToAutoHide(self:GetFrameRef("strip" .. open))
	end
	self:RunAttribute("ihud-stack")
]]
local q=[[ self:GetFrameRef("pop" .. (...)):Hide() ]]


local r=string.format([[
	local up, n = false, self:GetAttribute("ihud-pops") or 0
	for i = 1, n do
		if self:GetFrameRef("pop" .. i):IsShown() then up = true end
	end
	for i = 1, n do
		local arrow = self:GetFrameRef("arrow" .. i)
		if up then
			arrow:SetFrameStrata("%s")
			arrow:SetFrameLevel(%d)
		else
			arrow:SetFrameStrata("%s")
			arrow:SetFrameLevel(arrow:GetAttribute("ihud-level"))
		end
	end
]],n,i+j.arrow,e)
local x=[[ owner:RunAttribute("ihud-stack") ]]

local y=[[
	local i = self:GetAttribute("ihud-pick")
	if button == "RightButton" then owner:RunAttribute("ihud-open", 0)
	elseif owner:GetFrameRef("pop" .. i):IsShown() then owner:RunAttribute("ihud-close", i)
	else owner:RunAttribute("ihud-open", i) end
	return false
]]
local z=[[
	owner:RunAttribute("ihud-close", self:GetAttribute("ihud-pick"))
	return false
]]

local A=[[
	if button == "LeftButton" and IsAltKeyDown() and self:GetAttribute("ihud-pick") then
		if not down then owner:RunAttribute("ihud-open", self:GetAttribute("ihud-pick")) end
		return false
	end
]]
local B=[[ return nil, self:GetAttribute("ihud-pick") ]]
local C=[[ owner:RunAttribute("ihud-close", message) ]]
local s=[[
	local i = self:GetAttribute("ihud-pick")
	if i and owner:GetAttribute("ihud-hovermode") then owner:RunAttribute("ihud-open", i) end
]]

local D=[[
	local i = self:GetAttribute("ihud-pick")
	if not i or not owner:GetAttribute("ihud-hovermode") then return end
	local pop = owner:GetFrameRef("pop" .. i)
	if pop:IsShown() and not owner:GetFrameRef("slot" .. i):IsUnderMouse()
			and not owner:GetFrameRef("strip" .. i):IsUnderMouse() then
		pop:Hide()
	end
]]
local E=[[ return ]]

local F=3
local h={0,0,0,0.72}

local t="InterHUDTotemDrop"
local f={shift="shift-",alt="alt-",ctrl="ctrl-"}

local b
local g=setmetatable({},{__mode="k"})
local o={}

function a.header()return b end

function a.rigOf(a)return g[a]end

local function m(a,c)
SecureHandlerWrapScript(a,"OnEnter",b,c or E)
SecureHandlerWrapScript(a,"OnLeave",b,D)
end


local function D()
if b then return b end
local a=c.holder()
b=CreateFrame("Frame",nil,UIParent,"SecureHandlerBaseTemplate")
b:SetAttribute("ihud-open",p)
b:SetAttribute("ihud-close",q)
b:SetAttribute("ihud-stack",r)
b:SetAttribute("ihud-pops",0)

SecureHandlerWrapScript(a,"OnHide",b,[[ owner:RunAttribute("ihud-open", 0) ]])



local a=CreateFrame("Frame",nil,a,"SecureFrameTemplate")
SecureHandlerWrapScript(a,"OnShow",b,[[
		if owner:GetAttribute("ihud-hovermode") then owner:RunAttribute("ihud-open", 0) end
	]])
return b
end


local E={up=0,down=math.pi,right=-math.pi/2,left=math.pi/2}
local function p(a)
local a=CreateFrame("Frame",nil,a)
a:EnableMouse(false)
a.bg=a:CreateTexture(nil,"BACKGROUND")
a.bg:SetAllPoints()
a.bg:SetColorTexture(0.06,0.05,0.03,0.92)
a.glyph=a:CreateTexture(nil,"OVERLAY")
a.glyph:SetPoint("CENTER")
a.glyph:SetTexture("Interface\\Buttons\\UI-TotemBar")
a.glyph:SetTexCoord(0.5625,0.71875,0.34375,0.3828125)
a.glyph:SetBlendMode("ADD")
return a
end



local function q(a)
local b=a.slot.level+c.OVER_SLOT
a.arrow:SetAttribute("ihud-level",b)
a.arrow:SetFrameStrata(e)
a.arrow:SetFrameLevel(b)
end



local function r(a)
a.look:SetAlpha((a.arrowsOn and next(a.over))and 1 or 0)
end

local function G(l)
local f=D()
local b,d,k=c.holder(),l.slot,l.button
local a={slot=l,buttons={},ids={},over={}}
k:SetAttribute("ihud-pick",d)
local e=CreateFrame("Button",nil,b,"SecureActionButtonTemplate")
e:RegisterForClicks("AnyUp")
e:SetAttribute("ihud-pick",d)
e:Hide()
SecureHandlerWrapScript(e,"OnClick",f,y)
a.arrow=e
q(a)

a.look=p(e)
a.look:SetAllPoints(e)
a.look:SetAlpha(0)


local b=CreateFrame("Frame",nil,b,"SecureFrameTemplate")
b:SetFrameStrata(n)
b:SetFrameLevel(i)
b:SetSize(1,1)
b:Hide()
b.bg=b:CreateTexture(nil,"BACKGROUND")
b.bg:SetAllPoints()
b.bg:SetColorTexture(h[1],h[2],h[3],h[4])
a.pop=b
a.openLook=p(b)
a.openLook:SetFrameLevel(i+j.look)
a.openLook:SetAllPoints(e)

local h=CreateFrame("Button",nil,b,"SecureActionButtonTemplate")
h:SetAllPoints(UIParent)
h:SetFrameLevel(i+j.catch)
h:RegisterForClicks("AnyUp")
h:SetAttribute("ihud-pick",d)
SecureHandlerWrapScript(h,"OnClick",f,z)
a.catch=h

local h=CreateFrame("Frame",nil,b,"SecureFrameTemplate")
h:SetFrameLevel(i+j.strip)
h:EnableMouse(true)
h:SetAttribute("ihud-pick",d)
h:Hide()
a.strip=h
SecureHandlerSetFrameRef(f,"pop"..d,b)
SecureHandlerSetFrameRef(f,"strip"..d,h)
SecureHandlerSetFrameRef(f,"slot"..d,k)
SecureHandlerSetFrameRef(f,"arrow"..d,e)
SecureHandlerWrapScript(b,"OnHide",f,x)
f:SetAttribute("ihud-pops",math.max(f:GetAttribute("ihud-pops")or 0,d))
SecureHandlerWrapScript(k,"OnClick",f,A)


local b=CreateFrame("Button",t..d,UIParent,"SecureActionButtonTemplate")
b:RegisterForClicks("AnyDown","AnyUp")
b:SetAttribute("useOnKeyDown",false)
c.follower(b,function(a)return c.actionFor(d,a)end)
a.drop=b
m(k,s)
m(e,s)
m(h)
for c,b in ipairs({k,e})do
b:HookScript("OnEnter",function()
a.over[b]=true
r(a)
end)
b:HookScript("OnLeave",function()
a.over[b]=nil
r(a)
end)
end
g[l]=a
end


local function n(b)
local d=b.preview
local c=b.level+12
local a={slot=b,preview=true,buttons={},ids={},base=c}
a.look=p(d.holder)
a.look:SetFrameLevel(c+j.look)
a.look:Hide()
a.pop=CreateFrame("Frame",nil,d.holder)
a.pop:SetFrameLevel(c)
a.pop:Hide()
a.pop.bg=a.pop:CreateTexture(nil,"BACKGROUND")
a.pop.bg:SetAllPoints()
a.pop.bg:SetColorTexture(h[1],h[2],h[3],h[4])
g[b]=a
end



local function p(e,f)
local a=e.buttons[f]
if a then return a end
local g=e.slot.slot
if e.preview then
a=CreateFrame("Frame",nil,e.pop)
a:SetFrameLevel(e.base+j.button)
else
a=CreateFrame("Button",nil,e.pop,"SecureActionButtonTemplate")
a:RegisterForClicks("AnyUp")
a:SetAttribute("useOnKeyDown",false)

a:SetAttribute("*type1","multispell")
a:SetAttribute("ihud-pick",g)
a:SetFrameLevel(i+j.button)
SecureHandlerWrapScript(a,"OnClick",b,B,C)
m(a)
a:HookScript("OnEnter",function(a)d.TotemExtras.pickTip(a,e.ids[f])end)
a:HookScript("OnLeave",function()d.TotemExtras.hideTip()end)
c.follower(a,function(a)return c.actionFor(g,a)end)
end
a.icon=a:CreateTexture(nil,"ARTWORK")
a.icon:SetAllPoints()
a.icon:SetTexCoord(0.07,0.93,0.07,0.93)
a.none=a:CreateFontString(nil,"OVERLAY","GameFontDisable")
a.none:SetPoint("CENTER")
a.none:SetText("X")
e.buttons[f]=a
return a
end

local function i(a)
local a=w.truePixel()/(a.scale or 1)
return function(b)return a>0 and math.floor(b/a+0.5)*a or math.floor(b+0.5)end
end





local function s(g,b,a,d,h)
local c,e=g.drop,f[h.dropWith or"shift"]
for c,a in pairs(f)do
b:SetAttribute(a.."type1",nil)
b:SetAttribute(a.."macrotext1",nil)
end
c:SetAttribute("*type-pick"..a,"multispell")
c:SetAttribute("*spell-pick"..a,d)
c:SetAttribute("*type-cast"..a,"spell")
c:SetAttribute("*spell-cast"..a,d)
if e and d~=0 then
local c=t..g.slot.slot
b:SetAttribute(e.."type1","macro")
local d=string.format("/click %s cast%d",c,a)
b:SetAttribute(e.."macrotext1",h.dropPicks and string.format("/click %s pick%d\n%s",c,a,d)or d)
end
end

local function t(a)
local b,a=d.try("GetSpellTexture",C_Spell.GetSpellTexture,a)
return b and not d.isSecret(a)and a or nil
end



local e={up="TOP",down="BOTTOM",right="RIGHT",left="LEFT"}
local f={up="BOTTOM",down="TOP",right="LEFT",left="RIGHT"}
local w={up={0,1},down={0,-1},right={1,0},left={-1,0}}
local function h(h,n,m)
local b=g[h]
if not b then return end
local d=i(m)
local a,g=l(m),h.button
local o=a=="up"or a=="down"
local i,j=d(F),d(m.arrowSize or 20)
local k=d(n.w*0.8)
local l=w[a]

local d=b.arrow or b.look
d:ClearAllPoints()
if o then
d:SetPoint(f[a].."LEFT",g,e[a].."LEFT")
d:SetPoint(f[a].."RIGHT",g,e[a].."RIGHT")
d:SetHeight(j)
else
d:SetPoint("TOP"..f[a],g,"TOP"..e[a])
d:SetPoint("BOTTOM"..f[a],g,"BOTTOM"..e[a])
d:SetWidth(j)
end
for c,b in ipairs({b.look,b.openLook})do
b.glyph:SetSize(math.max(j*1.1,10),math.max(j*0.6,6))
b.glyph:SetRotation(E[a])
end

local d={0}
for b,a in ipairs(v.spellsOf(h.slot))do d[#d+1]=a end
b.ids=d
for g,e in ipairs(d)do
local d=p(b,g)
d:SetSize(k,k)
d:ClearAllPoints()
local i=i+(g-1)*(k+i)
d:SetPoint(f[a],b.pop,f[a],l[1]*i,l[2]*i)
if e~=0 then
d.icon:SetTexture(t(e))
d.none:Hide()
else
d.icon:SetColorTexture(0.1,0.1,0.1,1)
d.none:Show()
end
if not b.preview then
d:SetAttribute("spell",e)
d:SetAttribute("action",c.actionFor(h.slot))
s(b,d,g,e,m)
end
d:Show()
end
for a=#d+1,#b.buttons do b.buttons[a]:Hide()end
if b.drop then b.drop:SetAttribute("action",c.actionFor(h.slot))end
local h,d=2*i+#d*k+(#d-1)*i,k+2*i
local c=b.pop
c:ClearAllPoints()
if o then c:SetSize(d,h)else c:SetSize(h,d)end
local i=j
c:SetPoint(f[a],g,e[a],l[1]*i,l[2]*i)
b.side,b.reach=a,i+h
if b.strip then
local b=b.strip
b:ClearAllPoints()
b:SetPoint(f[a],g,e[a])
b:SetPoint(e[a],c,e[a])
if o then b:SetWidth(math.max(n.w,d))else b:SetHeight(math.max(n.h,d))end
end
end



function a.closeAll()
if InCombatLockdown()then return end
for b,a in pairs(g)do
if not a.preview then
a.pop:Hide()
q(a)
end
end
end

local function e(a)
return a.hoverPickers~=false and next(o)==nil
end



local function i(d)
if not b then return end
local c=e(d)
b:SetAttribute("ihud-hovermode",c)
for b,a in pairs(g)do
if not a.preview then
local b=a.slot.shown and d.arrows~=false
a.arrowsOn=b
q(a)
a.arrow:SetShown(b)
a.look:SetShown(b)
a.openLook:SetShown(b)
a.catch:SetShown(not c)
a.strip:SetShown(c)
r(a)
end
end
a.closeAll()
end

function a.hoverOff(a,b)
o[a]=b and true or nil
c.layout()
end


local function f(a)
local b=a.preview.geometry
for c,b in ipairs(b and b.items or{})do
if b.slot then return b.slot==a.slot end
end
return false
end

local function j(b,c)
local a=g[b]
if not(c=="picking"and a and a.reach and f(b))then return nil end
return{[a.side]=a.reach}
end
local function m(b,c,d)
local a=g[b]
if not a then return end
local b=c.preview=="picking"and b.shown and f(b)
a.pop:SetShown(b)
a.look:SetShown(b and d.arrows~=false)
a.look:SetAlpha(1)
end

local function f()
if not b then return{"pickers: none made"}end
local a=c.view()or{}
local b={}
for c,a in pairs(g)do

local c=not a.preview and a.pop:IsShown()
if c and not d.isSecret(c)then b[#b+1]=a.slot.element end
end
table.sort(b)
return{string.format("pickers: open %s; side %s, arrows %s, hover %s%s, drop with %s%s",
#b>0 and table.concat(b,", ")or"none",l(a),a.arrows~=false and"on"or"off",
e(a)and"on"or"off",next(o)and" (held off)"or"",tostring(a.dropWith or"shift"),
a.dropPicks and" (sets the pick)"or"")}
end

c.part("pickers",{
order=40,
chips={"picking"},
reach=j,
create=function(a)
if a.preview then n(a)else G(a)end
end,
layout=h,
paint=function(a,b,c)
if a.preview then m(a,b,c)end
end,
stopped=function()a.closeAll()end,
describe=f,
})
c.onLayout("pickers",function(a,c,b)
if not b then i(a)end
end)
u.onEnd("totem pickers",a.closeAll)



c.row("pickerSide",function(b,a)
local c=d.Kit
local function d()
local a=(a.view()or{}).direction=="column"
local a,b=a and"right"or"up",a and"left"or"down"
return{{a,k[a]},{b,k[b]}}
end
local c=c.dropdown(b.content,"Pickers open",nil,function()return l(a.view())end,
function(b)return a.set({"pickerSide"},b)end,{choices=d})
b:addRow(c,a.shown)
end,"spacing")
