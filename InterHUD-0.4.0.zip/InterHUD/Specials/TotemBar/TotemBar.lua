


local a,b=...
local c,D,m,s,aa,i,j,t,d,J,ab=
b.Schema,b.Combat,b.Events,b.Ticker,b.Spells,b.Totems,b.Layers,b.Specials,b.Debug,b.Groups,b.HUD

local a={}
b.TotemBar=a



























































































a.SECTIONS={
{key="display",title="Display"},
{key="layout",title="Layout"},
{key="buttons",title="Buttons"},
{key="keys",title="Keys"},
{key="sets",title="Totem sets"},
{key="style",title="Style"},
{key="notDown",title="Totem not down"},
{key="otherPick",title="Different totem down"},
{key="expiring",title="Expiring"},
{key="ends",title="Ran out and Killed early"},
{key="noPower",title="Not enough power"},
{key="range",title="Out of range"},
}

local u={"fire","earth","water","air"}
local E=i.SLOTS


c.record("totemBarPosition",{fields={
{name="point",type="point",default="CENTER",label="Anchor"},
{name="x",type="number",default=-385,min=-4000,max=4000,step=0.5,control="edit",label="X"},
{name="y",type="number",default=-180,min=-4000,max=4000,step=0.5,control="edit",label="Y"},
}})

local e={fire="Fire",earth="Earth",water="Water",air="Air"}


local f={show="is no longer a setting (the totem bar always shows while it's on); left out."}

c.record("totemBar",{refusable=true,retired=f,fields={

{name="enabled",type="boolean",default=false,label="Totem bar",
help="Off: Blizzard's totem bar shows."},

{name="position",type="record",record="totemBarPosition",keepEmpty=true,label="Place"},

{name="order",type="list",of="choice",unique=true,maxItems=4,item={choices=u},
default={"fire","earth","water","air"},label="Order"},
{name="hidden",type="list",of="choice",unique=true,maxItems=4,item={choices=u},
default={},label="Hidden slots"},
{name="direction",type="choice",choices={"row","column"},default="row",
labels={row="Row",column="Column"},section="layout",label="Direction"},
{name="spacing",type="number",default=2,min=-10,max=20,step=1,unit="px",section="layout",
label="Spacing"},
{name="size",type="number",default=44,min=24,max=96,step=1,unit="px",section="layout",
label="Size"},
{name="scale",type="number",default=1,min=c.SCALE.min,max=c.SCALE.max,step=c.SCALE.step,
unit="x",section="layout",label="Scale"},

{name="opacity",type="percent",default=100,min=10,max=100,section="display",label="Opacity"},
{name="cast",type="boolean",default=true,section="buttons",label="Left-click casts your picked totem"},

{name="styles",type="record",record="ownStyles",parts={"border","glow","pop","font",
"barTexture"},section="style",label="Style"},
}})
c.record("specials",{fields={{name="totemBar",type="record",record="totemBar",
label="Totem bar"}}})



local x={earth={0.75,0.54,0.24},fire={0.89,0.38,0.18},water={0.25,0.69,0.77},
air={0.56,0.76,0.92}}
local K={earth=136098,fire=135825,water=136053,air=136046}
a.ELEMENTS,a.COLOUR,a.SLOT_ICON,a.ELEMENT_LABELS=u,x,K,e


d.experimental("the totem bar's slot buttons acting on the press (pressAndHoldAction; A12 citing FR-6, no record)",
"C")
d.experimental("the totem bar's visibility driver on a holder with secure children (FR-4's drivers T 70338;"
.." ShamanForever ships it)","C")
d.experimental("the totem bar's driver set again at the pull's PLAYER_REGEN_DISABLED (CA-9's order T 70425)","C")
d.experimental("a slot's pick followed in combat: read plain at ACTIONBAR_SLOT_CHANGED (TO-17 T 70425 reads the pick"
.." and the bar's index plain in one combat; the event after a pick in combat unread; bar 12 where secret)","C")
d.experimental("a totem slot's texture handed to SetTexture in combat (FR-27: the totem's icon drew, T 70425)","T 70425")
d.experimental("the Totem Action Bar handed back beside another addon hiding it (offline only)","I")

local function y()

if not UnitClass then return false end
local c,d,a=b.try("UnitClass",UnitClass,"player")
return c and not b.isSecret(a)and a=="SHAMAN"
end
a.isShaman=y




local c=b.keyed("totem bar for a shaman")
local F=false
function a.forShaman(a,d)
c:add(a,d)
if F then b.try("totem bar for a shaman "..a,d)end
end
m.on("PLAYER_LOGIN","totemBar",function()
if F or not y()then return end
F=true
c:call()
end)


local g={}
a.slots=g
local c,k
local l,d,v=false,false,false
local h
local z
local G=false


local e={known=false,w=1,h=1}

local L=j.BASE_LEVEL


a.OVER_SLOT=24


local f,B={},{}
local o,C={},{}
local S=b.keyed("totem bar layout")
local A=b.keyed("totem bar tick")
local n,q={},{}
local r={}
local w
local M=setmetatable({},{__mode="k"})

local function I(a)
table.sort(a,function(a,b)
if(a.spec.order or 0)~=(b.spec.order or 0)then return(a.spec.order or 0)<(b.spec.order or 0)end
return a.n<b.n
end)
end

local function p(a,c,...)
local d=a.spec[c]
if d then b.try("totem bar "..a.key.." "..c,d,...)end
end

local function H(a)
if l then
for b=1,4 do a(g[b])end
end
for b in pairs(M)do
for c=1,4 do a(b.slotList[c])end
end
end

function a.part(a,b)
assert(type(a)=="string"and not B[a],"TotemBar: a part registered twice or unnamed")
local b={key=a,spec=b,n=#f+1}
B[a]=b
f[#f+1]=b
I(f)
H(function(a)p(b,"create",a)end)
end

function a.parts()
local a={}
for c,b in ipairs(f)do a[c]={key=b.key,chips=b.spec.chips}end
return a
end


function a.chips()
local a,c={},{}
for d,b in ipairs(f)do
for d,b in ipairs(b.spec.chips or{})do
if not c[b]then
c[b]=true
a[#a+1]=b
end
end
end
return a
end

local function H(a,c)
local d,b=b.try("totem bar "..a.key.." create",a.spec.create,c.holder,c.preview)
if d and b then c.extraFrames[a.key]=b end
end

function a.extra(b,c)
assert(type(b)=="string"and not C[b],"TotemBar: an extra registered twice or unnamed")
local c={key=b,spec=c,n=#o+1}
C[b]=c
o[#o+1]=c
I(o)
if l then H(c,a.hud)end
for a in pairs(M)do H(c,a)end
end

function a.onLayout(a,b)S:add(a,b)end
function a.sectionShown(b,c)
for d,a in ipairs(a.SECTIONS)do
if a.key==b then a.shown=c end
end
end
function a.tick(a,b)A:add(a,b)end

function a.row(a,b,c)
if not n[a]then q[#q+1]=a end
n[a]={build=b,after=c}
end
function a.rows()
local b={}
for c,a in ipairs(q)do b[c]={key=a,build=n[a].build,after=n[a].after}end
return b
end

function a.running()return d end
function a.view()return h or t.view("totemBar")end
function a.style(b)
local a=a.view()
return a and a.styles and a.styles[b]
end


function a.besideShamanForever()
if not(C_AddOns and C_AddOns.IsAddOnLoaded)then return false end
local c,a=b.try("IsAddOnLoaded",C_AddOns.IsAddOnLoaded,"ShamanForever")
return c and not b.isSecret(a)and a==true
end


local B="not read"
function a.activeSet()
if w then
local b,a=b.try("totem bar active set",w)
if b and type(a)=="number"and a>=1 and a<=3 then return a end
end
return 1
end
function a.provideSets(a)w=a end

function a.actionFor(e,f)
local c
local d=C_ActionBar and C_ActionBar.GetMultiCastBarIndex
if d then
local d,a=b.try("GetMultiCastBarIndex",d)
if not d then
B="failed: 12"
elseif b.isSecret(a)then
B="secret: 12"
elseif type(a)=="number"and a>=1 then
c,B=a,tostring(a)
else
B=tostring(a)..": 12"
end
end
return((c or 12)-1)*12+((f or a.activeSet())-1)*4+e
end



function a.pickOf(c,d)
if not GetActionInfo then return nil,true end
local d,c,a=b.try("GetActionInfo",GetActionInfo,a.actionFor(c,d))
if not d or b.isSecret(c)or b.isSecret(a)then return nil,true end
if c=="spell"and type(a)=="number"and a>0 then return a end
return nil
end

function a.pickTexture(d,e)
local c=C_ActionBar and C_ActionBar.GetActionTexture
if not c then return nil end
local a,b=b.try("GetActionTexture",c,a.actionFor(d,e))
if a then return b end
return nil
end

function a.follower(a,b)
r[#r+1]={frame=a,actionOf=b}
end

function a.followSet(c)
for d,a in ipairs(r)do
local c,b=b.try("totem bar follower",a.actionOf,c)
if c and b then a.frame:SetAttribute("action",b)end
end
end



local function q(a)
return function(b)return a and a>0 and math.floor(b/a+0.5)*a or math.floor(b+0.5)end
end
local function n(a,c,f,d)
local e=a.spec[c]
if not e then return d end
local b,a=b.try("totem bar "..a.key.." "..c,e,f)
return b and type(a)=="number"and a or d
end
function a.geometry(a,i,c,d)
local e=q(d)
local f=e(a.size or 44)
local d,h={},{}
for e,c in ipairs(c)do
local a,b=b.try("totem bar "..c.key.." side",c.spec.side or function()return"after"end,a)
local a=(a and b=="before")and d or h
a[#a+1]=c
end
local c,b={},0
local function g(a,d)
if#c>0 then b=b+e(d)end
a.offset=b
c[#c+1]=a
b=b+a.size
end
for c,b in ipairs(d)do
g({extra=b.key,size=e(n(b,"size",a,f*0.8))},
c==1 and 0 or n(b,"between",a,2))
end
local d=#d>0 and n(d[#d],"gap",a,8)or 0
for b,c in ipairs(i)do g({slot=c,size=f},b==1 and d or a.spacing or 2)end
for c,b in ipairs(h)do
g({extra=b.key,size=e(n(b,"size",a,f*0.8))},
c==1 and n(b,"gap",a,8)or n(b,"between",a,2))
end

local g,i,d=0,0,f
for b,a in ipairs(c)do
g,i=math.min(g,a.offset),math.max(i,a.offset+a.size)
d=math.max(d,a.size)
end
local h=a.direction~="column"
for b,a in ipairs(c)do
a.offset=a.offset-g
local b=e((d-a.size)/2)
a.rect=h and{x=a.offset,y=b,w=a.size,h=a.size}
or{x=b,y=a.offset,w=a.size,h=a.size}
end
b=math.max(i-g,f)
return{items=c,long=b,across=d,row=h,
w=h and b or d,h=h and d or b}
end


local n,q=j.get("icon"),j.part("border")
local function T(c,e)
local k=u[e]
local b
if c.preview then
b=CreateFrame("Frame",nil,c.holder)
else
b=CreateFrame("Button",nil,c.holder,"SecureActionButtonTemplate")
b:RegisterForClicks("AnyUp","AnyDown")

b:SetAttribute("pressAndHoldAction",true)

b:SetAttribute("*type2","destroytotem")
b:SetAttribute("totem-slot",e)
a.follower(b,function(b)return a.actionFor(e,b)end)
end
local g=c.level
b:SetFrameLevel(g+1)
b:Hide()
local a=CreateFrame("Frame",nil,c.holder)
a:SetAllPoints(b)
a:EnableMouse(false)
a:SetFrameLevel(g+2)
a:Hide()
local i=a:CreateTexture(nil,"BACKGROUND")
i:SetAllPoints()
local d=n.create(a)
d.frame:SetAllPoints(a)
local h=q.create(d.frame)
h.frame:SetAllPoints(d.frame)
local a={slot=e,element=k,button=b,look=a,bg=i,picture=d,border=h,
level=g+3,shown=false,preview=c.preview and c or nil,
s={down=false,known=false}}
d.frame:SetFrameLevel(a.level+j.RUNGS.picture)
h.frame:SetFrameLevel(a.level+j.RUNGS.border)
for c,b in ipairs(f)do p(b,"create",a)end
return a
end


local function N(a,c)
local d=a.rect
if not(d and c)then return end
local e=c.styles and c.styles.border
local g={desaturated=false,overlay=false,sweep={enabled=false},time={enabled=false},
framedBy=e,scale=c.scale}
local e={style=e,scale=c.scale}
for d,b in ipairs(f)do
p(b,"picture",a,g,c)
p(b,"border",a,e,c,a.s)
end
local c={x=0,y=0,w=d.w,h=d.h}
b.try("totem bar picture",n.apply,a.picture,g,{level=a.level},c)
b.try("totem bar border",q.apply,a.border,e,{level=a.level+j.RUNGS.border},c)
end
function a.restyle(a)
N(a,a.preview and a.preview.view or h)
end



local function n(a,c)
local d=a.picture.tex
if c.down then
if b.isSecret(c.icon)or c.icon then d:SetTexture(c.icon)end
a.bg:SetColorTexture(0,0,0,1)
else
d:SetTexture(nil)
local b=x[a.element]
a.bg:SetColorTexture(b[1]*0.35,b[2]*0.35,b[3]*0.35,0.8)
end
end

local function U(a,b)
n(a,a.s)
for d,c in ipairs(f)do p(c,"paint",a,a.s,b)end
end


local function n(c)
local d,c=c.slot,c.s
c.down=i.isDown(d)
c.duration=c.down and i.durationOf(d)or nil
c.owner=c.down and i.ownerOf(d)or nil
c.icon=nil
if c.down and GetTotemInfo then
local d,e,f,g,h,a=b.try("GetTotemInfo",GetTotemInfo,d)
if d and(b.isSecret(a)or a)then c.icon=a end
end
c.pick=a.pickOf(d)
c.known=#i.spellsOf(d)>0
c.preview=nil
end

local function V(a)
if not(l and d)then return end
n(a)
U(a,h)
end
local function w()
if not(l and d)then return end
for a=1,4 do V(g[a])end
end
a.repaint=w




local q=false
local function O()
if not(d and e.known)or q then return"hide"end
return"show"
end
local function r()
if not c then return end
local a=O()
if a==z then return end
RegisterStateDriver(c,"visibility",a)
z=a
end

local function W()D.whenUnlocked("totem bar driver",r)end







local x,n=false,false
local function C()
local a=TotemFrame
if not a then return false end
local d={PlayerFrame,_G.PlayerBottomManagedFrameContainer}
local a=a:GetParent()
local c=0
while a and c<20 do
if b.isSecret(a)then return false end
for c,b in pairs(d)do
if a==b then return true end
end
a=a:GetParent()
c=c+1
end
return false
end
local function P(a)
local c=TotemFrame
x=a
n=true
c:SetAlpha(a and 0 or 1)
n=false


local d=not a
if d then
local a=c:GetAlpha()
if not b.isSecret(a)and a==0 then d=false end
end
for b,a in ipairs({c:GetChildren()})do
if a.EnableMouse and not(a.IsProtected and a:IsProtected())then a:EnableMouse(d)end
end
end
local function I()
if not TotemFrame then return end
if not C()then
if x then P(false)end
return
end
if d or x then P(d)end
end
if TotemFrame then
hooksecurefunc(TotemFrame,"SetAlpha",function(c,a)
if x and not n and(b.isSecret(a)or a~=0)and C()then
n=true
c:SetAlpha(0)
n=false

m.atFrameEnd("totem bar TotemFrame",I)
end
end)

if TotemFrame.Update then
hooksecurefunc(TotemFrame,"Update",function()if x then I()end end)
end
end






local n=MultiCastActionBarFrame
local C=n and n:GetParent()or nil
if b.isSecret(C)then C=nil end
local function P()
local a=n:IsVisible()
return not b.isSecret(a)and a==true
end
local function X()
if not(n and k)then return end
local a=n:GetParent()
if b.isSecret(a)then return end
if d then
k:Hide()
if a==k then return end
if a~=C and not P()then return end
n:SetParent(k)
else
if a==k then n:SetParent(C or UIParent)end
k:Show()
end
end




local function Y(c,a,d,e,f,g)
local a,b=a.position,a.scale or 1
c:ClearAllPoints()
c:SetPoint(a.point,UIParent,a.point,J.onPixels(a.point,(f or a.x)/b,(g or a.y)/b,
d,e,b,J.screenPoint(a.point)))
end
local function Z(a,b)Y(c,h,e.w,e.h,a,b)end
local P


a.hud={extraFrames={},preview=false,level=L}
local function Q()
if l then return end
l=true
c=CreateFrame("Frame",nil,UIParent,"SecureFrameTemplate")
c:SetFrameLevel(L)
c:SetSize(1,1)
c:Hide()
k=CreateFrame("Frame",nil,UIParent,"SecureFrameTemplate")
k:SetAllPoints()
k:Hide()
a.hud.holder,a.hud.slotList=c,g
for b=1,4 do g[b]=T(a.hud,b)end
for c,b in ipairs(o)do H(b,a.hud)end
end
function a.holder()return c end



local function J(d,e)
local c={}
for f,a in ipairs(o)do
local f=d.extraFrames[a.key]
local d=false
if f then
local a,b=b.try("totem bar "..a.key.." shown",a.spec.shown or function()return true end,e)
d=a and b and true or false
end
if d then c[#c+1]=a end
end
return c
end
local function R(b)
local c,a={},{}
for d,b in ipairs(b.order or{})do
if E[b]and not c[b]then
c[b]=true
a[#a+1]=b
end
end
for d,b in ipairs(u)do
if not c[b]then a[#a+1]=b end
end
return a
end
a.normalOrder=R

local function _(c,d,i,j)
local h={}
for b,a in ipairs(d.hidden or{})do h[a]=true end
local e,g={},false
for b,a in ipairs(R(d))do
local b=E[a]
local c=i(b)
if c then g=true end
if c and not h[a]then e[#e+1]=b end
end

local h=g and J(c,d)or{}
local a=a.geometry(d,e,h,j)
a.known=g
local g=c.slotList
local e={}
for b,a in ipairs(a.items)do e[a.slot or a.extra]=a end
for a=1,4 do
local a,b=g[a],e[a]
a.shown=b~=nil
a.rect=b and b.rect or a.rect
a.button:SetShown(a.shown)
a.look:SetShown(a.shown)
if b then
local b=b.rect
a.button:ClearAllPoints()
a.button:SetPoint("TOPLEFT",c.holder,"TOPLEFT",b.x,-b.y)
a.button:SetSize(b.w,b.h)
if not c.preview then a.button:SetAttribute("*type1",d.cast and"action"or nil)end
N(a,d)
for e,c in ipairs(f)do p(c,"layout",a,b,d)end
end
end
for a,f in ipairs(o)do
local a,e=c.extraFrames[f.key],e[f.key]
if a then
a:SetShown(e~=nil)
if e then
local e=e.rect
a:ClearAllPoints()
a:SetPoint("TOPLEFT",c.holder,"TOPLEFT",e.x,-e.y)
a:SetSize(e.w,e.h)
b.try("totem bar "..f.key.." layout",f.spec.layout or function()end,a,e,d,c.preview)
end
end
end
c.holder:SetSize(a.w,a.h)
S:call(d,a,c.preview and c or nil)
return a
end

local function J(a)return#i.spellsOf(a)>0 end


local function S()
if not d then return end
Q()
i.map()
local b=h
c:SetScale(b.scale or 1)
c:SetAlpha((b.opacity or 100)/100)
a.followSet(a.activeSet())
local a=_(a.hud,b,J,j.truePixel()/(b.scale or 1))
e.known,e.w,e.h=a.known,a.w,a.h
e.px,e.sw,e.sh=j.truePixel(),UIParent:GetSize()
Z()
r()
I()
X()
w()
t.laidOut()
end
local function r()D.whenUnlocked("totem bar layout",S)end
a.layout=r



ab.onRepixel("totem bar",function()
local a,b=UIParent:GetSize()
if j.truePixel()==e.px and a==e.sw and b==e.sh then return end
r()
end)


local function S()
if not d then return end
for a=1,4 do
local a=g[a]
if a.s.down then A:call(a,a.s,h)end
end
end
local function J()
G=false
for a=1,4 do
if g[a].s.down then G=true end
end
if d and G and A:count()>0 then
s.subscribe(0.1,"totembar",S)
else
s.unsubscribe(0.1,"totembar")
end
end


local S={placed=true,owner=true,refilled=true,emptied=true}
i.onChange("totemBar",function(a,b,c,e)
if not(d and l and g[a])then return end
local a=g[a]
if S[b]then
V(a)
J()
end
for f,d in ipairs(f)do p(d,"event",a,b,c,e)end
end)


aa.onChange("totemBar",function()if d then r()end end)



local function V(c)
if b.isSecret(c)or type(c)~="number"then return true end
if c==0 then return true end
local a=a.actionFor(1,1)-1
return c>a and c<=a+12
end
local function S(a)
if a then
m.on("PLAYER_ENTERING_WORLD","totemBar",function()
w()
J()
r()
end)
m.on("UPDATE_MULTI_CAST_ACTIONBAR","totemBar",r)
m.on("ACTIONBAR_SLOT_CHANGED","totemBar",function(b,a)if V(a)then w()end end)
else
m.off("PLAYER_ENTERING_WORLD","totemBar")
m.off("UPDATE_MULTI_CAST_ACTIONBAR","totemBar")
m.off("ACTIONBAR_SLOT_CHANGED","totemBar")
end
end


local function V(a)
h,d,v=a,true,false
if not l and not InCombatLockdown()then Q()end
i.watch("totembar")
S(true)
w()
J()

r()
t.laidOut()
end

local function aa(a)
h,v=a,false
if c then c:SetAlpha((a.opacity or 100)/100)end
if l then
for b=1,4 do N(g[b],a)end
end
w()
J()
r()
t.laidOut()
end



local function r()
d,v,h=false,false,nil
i.unwatch("totembar")
S(false)
s.unsubscribe(0.1,"totembar")
G=false
D.whenUnlocked("totem bar stop",function()
if d then return end
if c then
UnregisterStateDriver(c,"visibility")
c:Hide()
end
z=nil
X()
end)
I()
if l then
for a=1,4 do
for c,b in ipairs(f)do p(b,"stopped",g[a])end
end
end
end

local function i()
local c=c and c:IsShown()
local c={string.format("totem bar: driver %s%s, holder %s, totems known %s%s",
tostring(z),z~=O()and(" (wants "..O()..")")or"",
b.isSecret(c)and"secret"or(c and"shown"or"hidden"),
e.known and"yes"or"no",v and", stopping at combat's end"or"")}
local d={}
for c=1,4 do
local b=g[c]
if b then
local e=b.s

local a,c=a.pickOf(c)
d[#d+1]=string.format("%s %s%s, pick %s",b.element,b.shown and"shown"or"off",
e.down and(", down "..tostring(e.owner or"owner unknown"))or"",
a and tostring(a)or(c and"secret"or"none"))
end
end
c[#c+1]="  "..table.concat(d,"; ")
a.actionFor(1)
c[#c+1]="  multi-cast bar index "..B..", set "..a.activeSet()
local e=TotemFrame and TotemFrame:GetParent()
local a=n and n:GetParent()
local function d(a)
if a==nil then return"none"end
if b.isSecret(a)then return"secret"end
return a.GetName and a:GetName()or"unnamed"
end
c[#c+1]="  TotemFrame under "..d(e)..(x and", hidden by us"or"")
.."; Totem Action Bar "..(a==k and a~=nil and"under ours"
or a==C and("under its own ("..d(a)..")")
or("under another's ("..d(a)..")"))
for d,a in ipairs(f)do
if a.spec.describe then
local b,a=b.try("totem bar "..a.key.." describe",a.spec.describe)
for b,a in ipairs(b and type(a)=="table"and a or{})do c[#c+1]="  "..a end
end
end
return c
end

t.register("totemBar",{
label="Totem bar",icon=K.earth,
relevant=y,
start=V,
apply=aa,
stop=r,

stopping=function()
if not v then b.print("The totem bar turns off when combat ends.")end
v=true
end,
box=function()
if not(d and e.known and h)then return nil end
local a=h.scale or 1
return e.w*a,e.h*a
end,
moveTo=function(a,b)
if c and h then D.whenUnlocked("totem bar place",function()Z(a,b)end)end
P(a,b)
end,
describe=i,
})


local c={}
c.__index=c

function a.newPreview(b)

local a=setmetatable({preview=true,extraFrames={},slotList={},level=b:GetFrameLevel()+1},
c)
a.holder=CreateFrame("Frame",nil,b)
a.holder:SetFrameLevel(a.level)
a.holder:SetSize(1,1)
for b=1,4 do a.slotList[b]=T(a,b)end
for c,b in ipairs(o)do H(b,a)end
M[a]=true
return a
end

function c:slots()return self.slotList end


function c:reach(h)
local a={top=0,bottom=0,left=0,right=0}
local d=self.geometry
if not d then return a end
for c=1,4 do
local g,c=self.slotList[c],self.slotList[c].rect
if g.shown and c then
for f,e in ipairs(f)do
if e.spec.reach then
local e,b=b.try("totem bar "..e.key.." reach",e.spec.reach,g,h,self.view)
if e and type(b)=="table"then
a.top=math.max(a.top,(b.up or 0)-c.y)
a.bottom=math.max(a.bottom,c.y+c.h+(b.down or 0)-d.h)
a.left=math.max(a.left,(b.left or 0)-c.x)
a.right=math.max(a.right,c.x+c.w+(b.right or 0)-d.w)
end
end
end
end
end
return a
end



function c:layout(b,a)
a=a or{}
self.view=b
local a=_(self,b,a.known or function()return true end,j.truePixel()/(a.scale or 1))
self.geometry=a
return a.w,a.h
end

local function e(b)
for a=1,4 do
local a=b.slotList[a]
if a.shown and a.s.down then A:call(a,a.s,b.view)end
end
end


function c:show(b,c)
self.view=b
local d=false
for e=1,4 do
local a=self.slotList[e]
local c=c and c[e]or{down=false,known=true}
for b in pairs(a.s)do a.s[b]=nil end
for b,c in pairs(c)do a.s[b]=c end
if a.s.down then d=true end
U(a,b)
end
self.holder:Show()
local a="totembar preview "..tostring(self.holder)
if d and A:count()>0 then s.subscribe(0.1,a,function()e(self)end)
else s.unsubscribe(0.1,a)end
end

function c:hide()
self.holder:Hide()
s.unsubscribe(0.1,"totembar preview "..tostring(self.holder))
end



local e=120
a.PREVIEW_TOTEMS={3599,8075,5394,8835}
function a.madeUp(c,d,f,b)
b=b or{}
local a=a.PREVIEW_TOTEMS[c]
local f=a and C_Spell and C_Spell.GetSpellTexture and C_Spell.GetSpellTexture(a)
local a={down=b.down~=false,known=true,preview=d,owner=a,pick=a}
if a.down then
local d=C_DurationUtil.CreateDuration()
d:SetTimeFromStart(b.start or GetTime(),b.length or e)
a.duration=d
a.icon=f or K[u[c]]
end
return a
end





local c
function P(a,b)
if not(q and c and c.geometry)then return end
Y(c.holder,c.view,c.geometry.w,c.geometry.h,a,b)
end
local function d()
if not q then return end
local b=t.view("totemBar")
if not b then return end
if not c then
local b=CreateFrame("Frame",nil,UIParent)
b:SetFrameLevel(L-1)
c=a.newPreview(b)
end
local d=b.scale or 1
c:layout(b,{scale=d})
c.holder:SetScale(d)
P()
local d
for b,a in ipairs(R(b))do
if c.slotList[E[a]].shown then d=E[a]end
end
local e={}
for c=1,4 do e[c]=a.madeUp(c,c==d and"expiring"or"down",b)end
c:show(b,e)
end

function a.standIn()return c end
b.PreviewMode.register("totemBar",{
show=function()
if not y()then return end
q=true
d()
W()
end,
hide=function()
if not q then return end
q=false
if c then c:hide()end
W()
end,
})
b.onChanged(function()
if q then m.atFrameEnd("totem bar preview mode",d)end
end,"totem bar preview mode")

if y()then
F=true
Q()
end
