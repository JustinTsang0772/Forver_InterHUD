


local b,a=...
local c,m,r,h,d,l,v,w,q,n,o,b,s,e=
a.Schema,a.Events,a.Combat,a.Ticker,a.Layers,a.Art,a.Resolve,a.Store,a.Spells,a.Sounds,
a.Totems,a.TotemBar,a.TotemTimers,a.Debug

local i={}
a.TotemEnds=i







e.experimental("the totem bar's end pop moving a copy of the slot's picture inside its gate (TO-7's gates T 70425;"
.." ShamanForever's FX.endFlash ships it)","C")
e.experimental("the totem bar's end effects and sound only while the bar shows: IsVisible read on our own look"
.." under the driven holder (FR-1's IsShown on our own frames; this read unrecorded)","C")
e.experimental("Not down's pick, Different totem down's badge and Not enough power from the slot's pick read in combat"
.." (TO-17 T 70425: the pick plain, its event after a pick in combat unread; CA-15 reads bar slots only)","I")



local f={"show","pick"}
local e={"shown",true}
c.record("totemBarNotDown",{fields={
{name="show",type="choice",choices={"pick","colour","blank"},default="pick",
labels={pick="Your pick",colour="Its school colour",blank="Blank"},section="notDown",
label="Show as",help="With no totem picked, its school colour."},
{name="greyed",type="boolean",default=false,under=f,section="notDown",label="Greyed"},
{name="opacity",type="percent",default=35,min=10,max=100,under=f,section="notDown",
label="Opacity"},
}})
c.record("totemBarOtherPick",{fields={
{name="shown",type="boolean",default=true,section="otherPick",label="Show your pick",
help="While another of its totems is down, on the side away from the picker."},
{name="opacity",type="percent",default=75,min=10,max=100,under=e,
section="otherPick",label="Opacity"},
{name="saturation",type="percent",default=50,min=0,max=100,under=e,
section="otherPick",label="Colour",help="0% is grey, 100% full colour."},
{name="size",type="percent",default=45,min=25,max=80,under=e,
section="otherPick",label="Size"},
{name="x",type="number",default=0,min=-30,max=30,step=1,unit="px",
under=e,section="otherPick",label="X offset",help="From its place beside the slot."},
{name="y",type="number",default=0,min=-30,max=30,step=1,unit="px",
under=e,section="otherPick",label="Y offset"},
}})
c.record("totemBarRanOut",{fields={
{name="pop",type="boolean",default=true,label="Pop",help="The moment it runs out. In white."},
}})
local e={"flash",true}
c.record("totemBarKilled",{fields={

{name="flash",type="boolean",default=true,label="Red flash",
help="When it ends early. Not when you dismiss it."},
{name="pop",type="boolean",default=true,under=e,label="Pop",help="In red."},
{name="glow",type="boolean",default=true,under=e,label="Glow",help="In red."},
{name="cross",type="boolean",default=true,under=e,label="Cross until recast",
help="Up to 5 s."},
}})
c.record("totemBar",{fields={
{name="notDown",type="record",record="totemBarNotDown",label="Totem not down"},
{name="otherPick",type="record",record="totemBarOtherPick",label="Different totem down"},

{name="endSound",type="sound",section="ends",label="Sound when it ends",
help="Either end, while the bar shows. Not when you dismiss it."},
{name="ranOut",type="record",record="totemBarRanOut",section="ends",label="Ran out"},
{name="killed",type="record",record="totemBarKilled",section="ends",label="Killed early"},

{name="noPower",type="boolean",default=true,section="noPower",label="Show when short of mana",
help="While you can't pay for a slot's pick and a click or key casts it. In Global's Not enough power look."},
}})

local e,t,j,f=d.get("icon"),d.part("border"),d.part("glow"),d.effect("pop")



local x,k=12,d.RUNGS.border+1
local p=5
local y=5


local u,z,A="#ff1f14","#f21f14b3","#f2f2f2"

local B,C={0.05,0.2,0.5},{0.12,0.5,1.4}
local g={enabled=false}














local c={}
c.__index=c

function i.copyRig(b)
local a=CreateFrame("Frame",nil,b)
a:SetAllPoints(b)
a:SetAlpha(0)
local b=CreateFrame("Frame",nil,a)
b:SetAllPoints(a)
b:SetAlpha(0)
local d=e.create(b)
d.frame:SetAllPoints(b)
d.cd:Hide()
local e=b:CreateAnimationGroup()
local g,h=l.anim(e,"Alpha",1),l.anim(e,"Alpha",2)
g:SetFromAlpha(0)
g:SetToAlpha(1)
h:SetFromAlpha(1)
h:SetToAlpha(0)

local f=f.create(a,{},{shape="moves"},d)
f.frame:SetAllPoints(a)
local b=setmetatable({gate=a,body=b,copy=d,fade=e,fadeIn=g,fadeOut=h,
pop=f},c)
local function c()
if b.onRest then b.onRest(b)end
end
e:SetScript("OnFinished",c)

a:SetScript("OnHide",function()
if b.endsAt then
b:stop()
c()
end
end)
return b
end

function c:apply(a)
local b={x=0,y=0,w=a.rect.w,h=a.rect.h}
self.gate:SetFrameLevel(a.level)
self.body:SetFrameLevel(a.level)
self.copy.frame:SetFrameLevel(a.level+1)
e.apply(self.copy,{desaturated=a.desaturated and true or false,overlay=a.overlay and true or false,
overlayColour=a.overlayColour,sweep=g,time=g,framedBy=a.framedBy,scale=a.scale},
{level=a.level+1},b)
self.popStyle=a.pop
if a.pop then f.apply(self.pop,{style=a.pop},{level=a.level+1,backLevel=a.level},b)end
end

function c:setIcon(b)
if a.isSecret(b)or b then self.copy.tex:SetTexture(b)end
end


function c:gateBy(b,c)
local d,e=false,0
if b and c then d,e=a.try("totem bar end curve",b.EvaluateRemainingDuration,b,c)end
self.gate:SetAlpha(d and e or 0)
end
function c:open(a)self.gate:SetAlpha(a and 1 or 0)end

function c:stop()
self.fade:Stop()
for b,a in ipairs(self.pop.groups)do a:Stop()end
self.endsAt=nil
end

function c:play(a,b)
self:stop()
self.fadeIn:SetDuration(a[1])
self.fadeOut:SetStartDelay(a[2])
self.fadeOut:SetDuration(a[3])
self.fade:Play()
local a=a[1]+a[2]+a[3]
if b and self.popStyle then
f.play(self.pop)
a=math.max(a,self.pop.length or 0)
end
self.endsAt=GetTime()+a
return a
end

function c:playing()return self.endsAt~=nil and GetTime()<self.endsAt end



local function c(a)return q.family(a)or a end

local function D(a)return d.truePixel()/((a and a.scale)or 1)end
local function E(b,a)return math.floor(b/a+0.5)*a end



local function F(b)
local b=b.look:IsVisible()
return a.isSecret(b)or b==true
end



local function G(a,b)
if not pcall(function()a:SetDesaturation(1-b)end)then a:SetDesaturated(b<0.5)end
end


local f=setmetatable({},{__mode="k"})
local function q(b)
local a=f[b]
if a==nil then
local c=v.buttonCues(w.profile()).notEnoughPower
a=e.buttonCue(c)or false
f[b]=a
end
return a or nil
end



local f={"castFire","castEarth","castWater","castAir"}
local function l(b,d)
local c=b.ends
local c=c and c.laid or d
if c and c.cast then return true end
local c=a.TotemKeys
if not(c and GetBindingKey and f[b.slot])then return false end
local b,a=a.try("GetBindingKey",GetBindingKey,c.command(f[b.slot]))
return b and a~=nil and a~=""
end



local function v(d,b,c)
if not(c and c.noPower and b.pick)then return false end
if d.preview then return b.preview=="noPower"end
if not l(d,c)then return false end
local c,d,b=a.try("IsSpellUsable",C_Spell.IsSpellUsable,b.pick)
return c and not a.isSecret(b)and b==true
end


local f={}
local function l(a)
local b=a.ends
if b then b.cross:Hide()end
f[a]=nil
end
local function w()
local a=GetTime()
for b,c in pairs(f)do
if a>=c then l(b)end
end
if not next(f)then h.unsubscribe(0.1,"totembar crosses")end
end
local function H(a)
a.ends.cross:Show()
f[a]=GetTime()+y
h.subscribe(0.1,"totembar crosses",w)
end



local function h(a,b)
local a=a.glow
if not a then return end
a.frame:SetShown(b)
if b then j.shown(a)else
for b,a in ipairs(a.groups)do a:Stop()end
end
end
local function y(b,c,d,e)
local a=a.copy(c.styles and c.styles.glow or{})
a.colour=u
local f=j.kindOf(a).key
if not b.glow or b.glowKey~=f then
if b.glow then b.glow.frame:Hide()end
b.glow=j.create(b.killed.body,{style=a})
b.glow.frame:SetAllPoints(b.killed.body)
b.glowKey=f
end
b.glow.frame:SetFrameLevel(d+2)
j.apply(b.glow,{style=a,framedBy=c.styles and c.styles.border,scale=c.scale},
{level=d+1},{x=0,y=0,w=e.w,h=e.h})

h(b,b.glowWanted and b.killed:playing()or false)
end


local I={below={"TOP","BOTTOM",0,-1},above={"BOTTOM","TOP",0,1},left={"RIGHT","LEFT",-1,0},
right={"LEFT","RIGHT",1,0}}
local w={kind="line",thickness=1,colour="#000000"}



local function J(b,h,j)
local c,l=b.ends.badge,h.otherPick or{}
local f=b.ends.laid or h
local i=D(f)
local i=math.max(E(j.w*(l.size or 45)/100,i),8)
c.frame:SetSize(i,i)
c.frame:SetFrameLevel(b.level+k)
local i={x=0,y=0,w=i,h=i}
c.pic.frame:SetFrameLevel(b.level+k)
e.apply(c.pic,{sweep=g,time=g,framedBy=w,scale=h.scale},
{level=b.level+k},i)
t.apply(c.border,{style=w,scale=h.scale},{level=b.level+k+1},i)


local e=s.awaySide(f)
local g=s.beside(f,j)
local a=a.TotemRange and a.TotemRange.beside(f,j)
local a=math.max(g and g.side==e and g.reach or 0,a and a.side==e and a.reach or 0)
local d=d.lineWidth(1,f.scale or 1)+a
local a=I[e]
c.frame:ClearAllPoints()
c.frame:SetPoint(a[1],b.look,a[2],(l.x or 0)+a[3]*d,(l.y or 0)+a[4]*d)
end



local function j(h,c)
local f,b=h.ends,h.rect
if not(f and b and c)then return end
f.view,f.w,f.h=c,b.w,b.h
local j,k=c.styles and c.styles.border,c.scale

local i=c.styles and c.styles.pop
local l,m
if i then
l,m=a.copy(i),a.copy(i)
l.colour,m.colour=A,u
end
local a=h.level+x
f.ranOut:apply({level=a,rect=b,framedBy=j,scale=k,pop=l})
f.killed:apply({level=a,rect=b,framedBy=j,scale=k,pop=m,desaturated=true,
overlay=true,overlayColour=z})
y(f,c,a,b)

local i,l=f.cross,{x=0,y=0,w=b.w,h=b.h}
i:SetFrameLevel(a+p)
i.copy.frame:SetFrameLevel(a+p)
e.apply(i.copy,{desaturated=true,sweep=g,time=g,framedBy=j,scale=k},
{level=a+p},l)

i.copy.tex:SetAlpha(0.6)
i.x:SetSize(b.w*0.7,b.h*0.7)
f.notDown.frame:SetFrameLevel(h.level+d.RUNGS.picture)
J(h,c,b)
end



local function k(b)
local c=b.look
local a={}
b.ends=a
a.ranOut,a.killed=i.copyRig(c),i.copyRig(c)
a.killed.onRest=function()h(a,false)end
local b=CreateFrame("Frame",nil,a.killed.gate)
b:SetAllPoints(a.killed.gate)
b:Hide()
b.copy=e.create(b)
b.copy.frame:SetAllPoints(b)
b.copy.cd:Hide()
b.x=b:CreateTexture(nil,"OVERLAY")
b.x:SetTexture("Interface\\RaidFrame\\ReadyCheck-NotReady")
b.x:SetPoint("CENTER",b,"CENTER",0,0)
a.cross=b

a.notDown=e.create(c)
a.notDown.frame:SetAllPoints(c)
a.notDown.cd:Hide()
a.notDown.frame:Hide()
local b={frame=CreateFrame("Frame",nil,c)}
b.pic=e.create(b.frame)
b.pic.frame:SetAllPoints(b.frame)
b.pic.cd:Hide()
b.border=t.create(b.pic.frame)
b.border.frame:SetAllPoints(b.pic.frame)
b.frame:Hide()
a.badge=b
a.low=false
end



local function i(c,d)
if d.pick then return C_Spell.GetSpellTexture(d.pick)end
if c.preview then return nil end
local b=b.pickTexture(c.slot)
if a.isSecret(b)or b then return b end
return nil
end



local function p(b,a,c,k)
local f,h=b.ends.notDown,c.notDown or{}
local j=not a.down and h.show=="pick"and i(b,a)or nil
if j==nil then
f.frame:Hide()
if not a.down and h.show=="blank"then b.bg:SetColorTexture(0,0,0,0)end
return
end
local i=b.rect
if not i then return end
local a=k and q(c)or nil
local k=(h.opacity or 35)/100
f.tex:SetTexture(j)
e.apply(f,{desaturated=(h.greyed or(a and a.desaturated))and true or false,
tint=a and a.tint or nil,overlay=a and a.overlay or false,
overlayColour=a and a.overlayColour or nil,sweep=g,time=g,
framedBy=c.styles and c.styles.border,scale=c.scale},
{level=b.level+d.RUNGS.picture},{x=0,y=0,w=i.w,h=i.h})
f.tex:SetAlpha(k)
f.frame:Show()
b.bg:SetColorTexture(0,0,0,0.6*k)
end




local function i(e,f)
local d=a.TotemSets
local g=b.activeSet()
for a=1,3 do
if a~=g and(not d or d.known(a))then
local a,b=b.pickOf(e.slot,a)
if b or(a and c(a)==c(f))then return true end
end
end
return false
end




local function s(e,a,b)
local d,f=e.ends.badge,b.otherPick or{}
local b,g=a.pick,false
if f.shown and a.down then
if e.preview then
if a.preview=="otherPick"then
b=nil
for e,d in ipairs(o.spellsOf(e.slot))do
if not b and c(d)~=c(a.owner)then b=d end
end
g=b~=nil
end
else
g=b~=nil and a.owner~=nil and c(b)~=c(a.owner)
and not i(e,a.owner)
end
end
if not g then
d.frame:Hide()
return
end
d.pic.tex:SetTexture(C_Spell.GetSpellTexture(b))
G(d.pic.tex,(f.saturation or 50)/100)
d.frame:SetAlpha((f.opacity or 75)/100)
d.frame:Show()
end




local function g(b,c,e)
local a=b.ends
if not F(b)then return end
local f,d=c.ranOut or{},c.killed or{}
if f.pop and e~="killed"then a.ranOut:play(B,true)end
if d.flash and e~="ranOut"then
a.glowWanted=d.glow and true or false
h(a,a.glowWanted)
a.killed:play(C,d.pop)
if d.cross then H(b)end
end


if c.endSound and not b.preview then
n.play(c.endSound,"totembar end",n.muted("cantAct")and not n.muted("preview"))
end
end



local function i(d,e,f)
local a,c=d.ends,e.preview
if c~=a.chip then
a.ranOut:stop()
a.killed:stop()
h(a,false)
l(d)
a.chip=c
end
if c~="killed"and c~="ranOut"then return end
if a.ranOut:playing()or a.killed:playing()then return end
a.ranOut:open(c=="ranOut")
a.killed:open(c=="killed")
local b=e.icon or(e.owner and C_Spell.GetSpellTexture(e.owner))or b.SLOT_ICON[d.element]
a.ranOut:setIcon(b)
a.killed:setIcon(b)
a.cross.copy.tex:SetTexture(b)
g(d,f,c)
end


local function d(e,c,f)
local d=e.ends
if not(d and f)then return end
local g=e.rect
if g and(d.view~=f or d.w~=g.w or d.h~=g.h)then j(e,f)end

if c.down and(a.isSecret(c.icon)or c.icon)then
d.ranOut:setIcon(c.icon)
d.killed:setIcon(c.icon)
d.cross.copy.tex:SetTexture(c.icon)
end

local a=v(e,c,f)
local g=(a and"low"or"")..(c.down and" down"or"")
d.low=a
if g~=d.lookKey then
d.lookKey=g
b.restyle(e)
end
p(e,c,f,a)
s(e,c,f)
if e.preview then i(e,c,f)end
end




local c,i=o.endCurve("killedEarly"),o.endCurve("ranOut")
local function e(a,b)
a.ranOut:gateBy(b,i)
a.killed:gateBy(b,c)
end
local function i(d,c,f)
local a=d.ends
if not a then return end
if c=="emptied"then
e(a,f)
a.gatedAt=GetTime()
elseif c=="ended"then

if not(a.gatedAt and GetTime()-a.gatedAt<1)then e(a,f)end
a.gatedAt=nil
g(d,b.view())
elseif c=="placed"or c=="owner"then
l(d)
end
end

local function e(b)
local a=b.ends
if not a then return end
a.ranOut:stop()
a.killed:stop()
h(a,false)
l(b)
a.badge.frame:Hide()
a.notDown.frame:Hide()
a.low,a.lookKey,a.gatedAt=false,nil,nil
end



local function c()
if not b.running()then return end
local d=b.view()
for a=1,4 do
local a=b.slots[a]
local c=a and a.ends
if c and a.shown and v(a,a.s,d)~=c.low then return b.repaint()end
end
end
b.forShaman("ends",function()
m.on("SPELL_UPDATE_USABLE","totem bar no mana",c)
m.on("UPDATE_BINDINGS","totem bar no mana",c)
m.onUnit("UNIT_POWER_UPDATE","player","totem bar no mana",c)
r.onStart("totem bar no mana",c)
r.onEnd("totem bar no mana",c)
end)

local function c()
local c=b.view()or{}
local g,h,d=c.notDown or{},c.ranOut or{},c.killed or{}
local e={}
for c=1,4 do
local c=b.slots[c]
local d=c and c.ends
if d then
local b={}
if d.low then b[#b+1]="no mana"end
if d.badge.frame:IsShown()then b[#b+1]="different totem"end

if f[c]then
local c=d.killed.gate:GetAlpha()
if a.isSecret(c)then
b[#b+1]="cross (gated)"
elseif c>0.5 then
b[#b+1]="cross"
end
end
e[#e+1]=c.element..(#b>0 and(" "..table.concat(b,", "))or"")
end
end
return{string.format("ends: ran out pop %s; killed early flash %s (pop %s, glow %s, cross %s); sound %s; not down"
.." %s at %s%%; different totem %s; no mana %s; %s",tostring(h.pop),tostring(d.flash),tostring(d.pop),
tostring(d.glow),tostring(d.cross),tostring(c.endSound or"none"),tostring(g.show),tostring(g.opacity),
tostring(c.otherPick and c.otherPick.shown),tostring(c.noPower),table.concat(e,"; "))}
end



b.part("ends",{
order=20,
create=k,
layout=function(a,c,b)
if a.ends then a.ends.laid=b end
j(a,b)
end,
picture=function(a,b,d)
local c=a.ends
local a=c and c.low and a.s.down and q(d)
if not a then return end
if a.tint then b.tint=a.tint end
if a.overlay~=nil then
b.overlay=a.overlay
b.overlayColour=a.overlayColour
end
if a.desaturated then b.desaturated=true end
end,
border=function(b,a,c)
local b=b.ends
local b=b and b.low and q(c)
local b=b and b.border
if not b then return end
a.ring,a.ringColour,a.ringSize=true,b.ringColour,b.ringSize
end,
paint=d,
event=i,
stopped=e,
chips={"notDown","otherPick","noPower","killed","ranOut"},
describe=c,
})
