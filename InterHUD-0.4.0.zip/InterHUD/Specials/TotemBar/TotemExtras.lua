


local b,a=...
local e,i,n,g,c,d,j=a.Schema,a.Combat,a.Events,a.Spells,a.TotemBar,a.Layers,a.Debug

local b={}
a.TotemExtras=b
















local f={66842,66843,66844}
local h=36936
b.CALLS,b.RECALL=f,h


e.record("totemBarExtras",{fields={
{name="place",type="choice",choices={"after","before","ends"},default="after",
labels={after="After the slots",before="Before the slots",ends="Call before, Recall after"},
label="Place"},
{name="size",type="number",default=80,min=50,max=150,step=5,unit="%",label="Size"},
{name="gap",type="number",default=8,min=-10,max=30,step=1,unit="px",
label="Gap from the slots"},
{name="between",type="number",default=2,min=-10,max=20,step=1,unit="px",
label="Gap between them"},
}})
e.record("totemBar",{fields={
{name="tooltips",type="choice",choices={"always","ooc","never"},default="ooc",
labels={always="Always",ooc="Out of combat",never="Never"},section="display",label="Tooltips"},
{name="call",type="boolean",default=true,section="buttons",label="Call of the Elements"},
{name="recall",type="boolean",default=true,section="buttons",label="Totemic Recall",
help="Right-click it to dismiss every totem."},
{name="extras",type="record",record="totemBarExtras",section="layout",label="Call and Recall"},
}})


j.experimental("the totem bar's tooltips in combat (SetTotem, SetAction, SetSpellByID: no row; only Always shows"
.." them there)","C")


function b.tipsShown()
if not c.running()then return false end
local a=c.view()
local a=a and a.tooltips or"ooc"
return a=="always"or(a=="ooc"and not i.inCombat())
end

function b.hideTip()GameTooltip:Hide()end

local function e(b)
if not a.try("totem bar tooltip",GameTooltip.SetSpellByID,GameTooltip,b)then
GameTooltip:SetText(g.nameOf(b)or"")
end
end

function b.pickTip(c,a)
if not(a and b.tipsShown())then return end
GameTooltip:SetOwner(c,"ANCHOR_RIGHT")
if a~=0 then e(a)else GameTooltip:SetText("No totem")end
GameTooltip:Show()
end



local function i(d)
if not b.tipsShown()then return end
GameTooltip:SetOwner(d.button,"ANCHOR_RIGHT")
if d.s.down then
a.try("totem bar tooltip",GameTooltip.SetTotem,GameTooltip,d.slot)
else
local b=c.actionFor(d.slot)
local e,f=a.try("GetActionInfo",GetActionInfo,b)
if e and f==nil then
GameTooltip:SetText(c.ELEMENT_LABELS[d.element]..": no totem picked")
else
a.try("totem bar tooltip",GameTooltip.SetAction,GameTooltip,b)
end
end
GameTooltip:Show()
end

c.part("tooltips",{
order=60,
create=function(a)
if a.preview then return end

a.button:HookScript("OnEnter",function()i(a)end)
a.button:HookScript("OnLeave",b.hideTip)
end,
})



local i="InterHUDTotemDismiss"
local j={}
for a=1,4 do j[a]="/click "..i..a end
b.DISMISS_ALL=table.concat(j,"\n")
c.forShaman("dismissAll",function()
for b=1,4 do
local a=CreateFrame("Button",i..b,UIParent,"SecureActionButtonTemplate")
a:RegisterForClicks("AnyDown","AnyUp")
a:SetAttribute("type","destroytotem")
a:SetAttribute("totem-slot",b)
a:SetAttribute("useOnKeyDown",false)
end
end)


function b.callFor(a)
local a=f[a]or f[1]
return g.known(a)and a or f[1]
end
local function k(a)return a=="call"and b.callFor(c.activeSet())or h end

local i=a.keyed("totem bar tooltip lines")
function b.addTipLines(a,b)i:add(a,b)end


local function o(a)
if not b.tipsShown()then return end
GameTooltip:SetOwner(a.button,"ANCHOR_RIGHT")
e(a.spell)
if a.key=="recall"then
if not a.learned then GameTooltip:AddLine("Not learned yet",0.6,0.6,0.6)end
GameTooltip:AddLine("Right-click: dismiss all totems (no GCD, but no mana returned)",1,0.82,0,true)
end
i:call(a.key,GameTooltip)
GameTooltip:Show()
end



local l,m,i=d.get("icon"),d.part("border"),d.part("gcdSweep")
local e={}
local function j(f,g,n)
local j=n and g:GetFrameLevel()or c.hud.level
local a={key=f,spell=k(f),level=j+3}
local c
if n then
c=CreateFrame("Frame",nil,g)
else
c=CreateFrame("Button",nil,g,"SecureActionButtonTemplate")
c:RegisterForClicks("AnyUp","AnyDown")
if f=="recall"then
c:SetAttribute("spell",h)
c:SetAttribute("*type2","macro")
c:SetAttribute("macrotext",b.DISMISS_ALL)
end
c:HookScript("OnEnter",function()o(a)end)
c:HookScript("OnLeave",b.hideTip)
e[f]=a
end
c:SetFrameLevel(j+1)
c:Hide()
a.button=c

local b=CreateFrame("Frame",nil,c)
b:SetAllPoints(c)
b:EnableMouse(false)
b:SetFrameLevel(j+2)
a.look=b
a.picture=l.create(b)
a.picture.frame:SetAllPoints(b)
a.picture.frame:SetFrameLevel(a.level+d.RUNGS.picture)
a.border=m.create(a.picture.frame)
a.border.frame:SetAllPoints(a.picture.frame)
a.border.frame:SetFrameLevel(a.level+d.RUNGS.border)
a.sweep=i.create(a.picture.frame)
a.sweep.frame:SetAllPoints(a.picture.frame)
a.sweep.frame:SetFrameLevel(a.level+d.RUNGS.gcdSweep)
c.ihudExtra=a
return c
end

function b.button(a)return e[a]and e[a].button end

local function o(b)
local c,b=a.try("GetSpellTexture",C_Spell.GetSpellTexture,b)
return c and not a.isSecret(b)and b or nil
end



local function h(e,f,c,h)
local b=e.ihudExtra
b.spell=k(b.key)
b.learned=g.known(b.spell)
if not h then
e:SetAttribute("*type1",b.learned and"spell"or nil)
if b.key=="call"then e:SetAttribute("spell",b.spell)end
end
local g=c.styles and c.styles.border
local h={desaturated=not b.learned,overlay=false,sweep={enabled=false},
time={enabled=false},framedBy=g,scale=c.scale}
local e={x=0,y=0,w=f.w,h=f.h}
a.try("totem bar extra picture",l.apply,b.picture,h,{level=b.level},e)
a.try("totem bar extra border",m.apply,b.border,{style=g,scale=c.scale},
{level=b.level+d.RUNGS.border},e)
a.try("totem bar extra sweep",i.apply,b.sweep,h,{level=b.level+d.RUNGS.gcdSweep},e)
b.picture.tex:SetTexture(o(b.spell))

b.picture.tex:SetAlpha(b.learned and 1 or 0.6)
if not b.learned then b.sweep.cd:Clear()end
end

local function d(b,a)
local a=a.extras and a.extras.place or"after"
if a=="ends"then return b=="call"and"before"or"after"end
return a=="before"and"before"or"after"
end
local function b(a,b,c)
return{
order=b,
side=function(b)return d(a,b)end,
size=function(a)return(a.size or 44)*(a.extras and a.extras.size or 80)/100 end,
gap=function(a)return a.extras and a.extras.gap or 8 end,
between=function(a)return a.extras and a.extras.between or 2 end,
shown=c,
create=function(b,c)return j(a,b,c)end,
layout=h,
}
end
c.extra("call",b("call",1,function(a)return a.call~=false and g.known(f[1])end))
c.extra("recall",b("recall",2,function(a)return a.recall~=false end))


local d={}
c.onLayout("extras",function(c,a,b)
if b then return end
for a in pairs(d)do d[a]=nil end
for b,a in ipairs(a.items)do
if a.extra then d[a.extra]=true end
end
end)





local f={gcd=false}
local function b(b,c)
if c and d[b.key]and b.learned then
local d,c=a.try("GetSpellCooldown",C_Spell.GetSpellCooldown,b.spell)
if not d or type(c)~="table"or a.isSecret(c.isOnGCD)then return end
if c.isOnGCD==true then
local a,c=a.try("GetSpellCooldownDuration",C_Spell.GetSpellCooldownDuration,b.spell,false)
f.gcd=a and c or false
i.feed(b.sweep,f)
return
end
end
b.sweep.cd:Clear()
end
local function a()
if not c.running()then return end
local a=c.view()
local a=a and a.gcdSweep~=false
for d,c in pairs(e)do b(c,a)end
end
c.forShaman("extras sweep",function()n.on("SPELL_UPDATE_COOLDOWN","totem bar extras",a)end)


c.part("extras",{
order=61,
stopped=function()
for b,a in pairs(e)do a.sweep.cd:Clear()end
end,
describe=function()
local a={}
for c,b in ipairs({"call","recall"})do
local c=e[b]
if c then
a[#a+1]=string.format("%s %s, %s %s",b,d[b]and"placed"or"not placed",
tostring(c.spell),c.learned and"learned"or"not learned")
end
end
return{"extras: "..(#a>0 and table.concat(a,"; ")or"none made").."; tooltips "
..tostring((c.view()or{}).tooltips)}
end,
})
