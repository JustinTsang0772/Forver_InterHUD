




local a,c=...
local a,i,j,n,m,s,t,f,o,k,u,e=
c.Schema,c.Combat,c.Events,c.Spells,c.Store,c.Layers,c.Media,c.TotemBar,c.TotemPickers,
c.TotemExtras,c.TotemKeys,c.Debug

local b={}
c.TotemSets=b















local d=k.CALLS
local v={"Call of the Elements","Call of the Ancestors","Call of the Spirits"}
local w={"shift-","ctrl-"}
local x={"Shift-click","Ctrl-click"}

local function g(a)
if a==1 then return true end
return d[a]~=nil and n.known(d[a])
end
function b.known(a)return g(a)end
function b.count()
local a=0
for b=1,#d do if g(b)then a=a+1 end end
return a
end
local function l()return b.count()>1 end

f.sectionShown("sets",l)


a.record("character",{fields={
{name="totemSet",type="number",default=1,min=1,max=3,step=1},
}})
a.record("totemBarSets",{fields={
{name="switch",type="choice",choices={"picker","cycle"},default="picker",
labels={picker="Opens a picker",cycle="Goes to the next set"},section="sets",shownIf=l,
label="Right-click Call"},
{name="number",type="boolean",default=true,section="sets",shownIf=l,
label="Show set number"},
}})
a.record("totemBar",{fields={
{name="sets",type="record",record="totemBarSets",label="Totem sets"},
}})


e.experimental("Call's Shift and Ctrl clicks casting the other sets' Calls by modified spell attributes (A12's"
.." modifiers; FR-6's spell T 70205; no run yet: Call of the Ancestors comes at 30)","C")


local h=1
local function a()
local a=m.char()
local a=a and a.totemSet
if type(a)=="number"and d[a]then return a end
return 1
end
function b.active()return h end
f.provideSets(b.active)


local function p()
local a={h}
for b=1,#d do
if b~=h then a[#a+1]=b end
end
return a
end
function b.clicks()return p()end



local function q()
local a=a()
h=g(a)and a or 1
f.followSet(h)
f.layout()
end
local function a()i.whenUnlocked("totem sets follow",q)end


local e=false
local function r()
if not e then c.print("Totem sets switch out of combat only.")end
e=true
end
i.onEnd("totem sets",function()e=false end)

function b.switch(a)
if not(d[a]and g(a))then return false end
if i.inCombat()then
r()
return false
end
b.closePicker()

local b=m.char()
if b then b.totemSet=a~=1 and a or nil end
q()
return true
end

function b.next()
if b.count()<2 then return false end
local a=h
for b=1,#d do
a=a%#d+1
if g(a)then break end
end
return b.switch(a)
end
u.onNext(b.next)



f.forShaman("sets",function()
j.on("PLAYER_LOGIN","totem sets",a)
j.on("PLAYER_ENTERING_WORLD","totem sets",a)
j.on("UPDATE_MULTI_CAST_ACTIONBAR","totem sets",a)
n.onChange("totem sets",a)
if m.ready()then a()end
end)





local a

local e={}
local function q(a,b,c)
a:HookScript("OnEnter",function(c)
e[a]=true
if b then b(c)end
end)
a:HookScript("OnLeave",function(b)
e[a]=nil
if c then c(b)end
end)
end

local function u(c,a)
if(a=="LeftButton"or a=="RightButton")and next(e)==nil then b.closePicker()end
end
local function y(c)
local a=CreateFrame("Button",nil,a)
a:RegisterForClicks("LeftButtonUp")
a.icon=a:CreateTexture(nil,"ARTWORK")
a.icon:SetAllPoints()
a.on=a:CreateTexture(nil,"OVERLAY")
a.on:SetAllPoints()
a.on:SetTexture("Interface\\Buttons\\CheckButtonHilight")
a.on:SetBlendMode("ADD")
a:SetScript("OnClick",function()b.switch(c)end)
q(a,function(a)k.pickTip(a,d[c])end,k.hideTip)
return a
end
local function z(b)
a=CreateFrame("Frame",nil,b)
a:SetFrameStrata(o.POP_STRATA)
a:SetFrameLevel(o.POP_LEVEL)

a:EnableMouse(true)
q(a)
a:Hide()
a:SetScript("OnHide",function()
j.off("GLOBAL_MOUSE_DOWN","totem sets")
e[a]=nil
for b,a in ipairs(a.buttons)do e[a]=nil end
end)
a.bg=a:CreateTexture(nil,"BACKGROUND")
a.bg:SetAllPoints()
a.bg:SetColorTexture(0.06,0.05,0.03,0.92)
a.buttons={}
for b=1,#d do a.buttons[b]=y(b)end
end

function b.closePicker()if a then a:Hide()end end
function b.pickerShown()return a~=nil and a:IsShown()end
i.onStart("totem sets",b.closePicker)

local e=2
local function y(b)
if not a then z(b)end
local f=f.view()or{}
local f=o.sideOf(f)
local i=b:GetWidth()
local k={}
for b=1,#d do
local a=a.buttons[b]
a:SetShown(g(b))
if g(b)then k[#k+1]=a end
end
local g=f=="up"or f=="down"
local l=#k
a:SetSize(g and i+2*e or l*(i+e)+e,g and l*(i+e)+e or i+2*e)
a:ClearAllPoints()
if f=="up"then a:SetPoint("BOTTOM",b,"TOP",0,e)
elseif f=="down"then a:SetPoint("TOP",b,"BOTTOM",0,-e)
elseif f=="left"then a:SetPoint("RIGHT",b,"LEFT",-e,0)
else a:SetPoint("LEFT",b,"RIGHT",e,0)end
for j,b in ipairs(k)do
local g
for a,c in ipairs(a.buttons)do if c==b then g=a end end
b:SetSize(i,i)
b:ClearAllPoints()
local e=e+(j-1)*(i+e)

if f=="up"then b:SetPoint("BOTTOM",a,"BOTTOM",0,e)
elseif f=="down"then b:SetPoint("TOP",a,"TOP",0,-e)
elseif f=="left"then b:SetPoint("RIGHT",a,"RIGHT",-e,0)
else b:SetPoint("LEFT",a,"LEFT",e,0)end
local d,a=c.try("GetSpellTexture",C_Spell.GetSpellTexture,d[g])
b.icon:SetTexture(d and not c.isSecret(a)and a or nil)
b.on:SetShown(g==h)
end
a:Show()
j.on("GLOBAL_MOUSE_DOWN","totem sets",u)
end

local function c()
local a=f.view()or{}
return a.sets~=nil and a.sets.switch=="cycle"
end



local function o(d,a,e)
if e then return end
local e=a=="LeftButton"and IsAltKeyDown()and not c()
if a~="RightButton"and not e then return end
if b.count()<2 then return end
if i.inCombat()then
r()
return
end
if c()then
b.next()
elseif b.pickerShown()then
b.closePicker()
else
y(d)
end
end



local function r(a)
local b=p()
a:SetAttribute("*spell1",d[b[1]])
for e,c in ipairs(w)do
local b=b[e+1]
local e=b and g(b)
a:SetAttribute(c.."type1",e and"spell"or"")
a:SetAttribute(c.."spell1",e and d[b]or nil)
end

a:SetAttribute("alt-type1",(l()and not c())and""or nil)
end


local e=setmetatable({},{__mode="k"})
local function j(a)
local b=e[a]
if b then return b end
local d=a.ihudExtra
local c=CreateFrame("Frame",nil,a)
c:SetAllPoints(a)
c:EnableMouse(false)
c:SetFrameLevel((d and d.level or a:GetFrameLevel())+s.RUNGS.text+1)
local d=c:CreateFontString(nil,"OVERLAY")
d:SetFont(STANDARD_TEXT_FONT,13,"OUTLINE")
d:SetPoint("BOTTOMRIGHT",-1,2)
d:SetTextColor(1,1,1)
b={frame=c,fs=d}
e[a]=b
return b
end
b.numberOf=j
local function e(b,a)
local b=j(b)
local c=a.sets==nil or a.sets.number~=false
c=c and l()
local d=a.keyText or{}
local a=a.styles and a.styles.font
if a then t.setFont(b.fs,a,d.size or 13)else b.fs:SetFont(STANDARD_TEXT_FONT,d.size or 13,"OUTLINE")end
b.fs:SetText(c and tostring(h)or"")
b.fs:SetShown(c)
end

local j=setmetatable({},{__mode="k"})
f.onLayout("sets",function(c,d,a)
if a then
local a=a.extraFrames.call
if a then e(a,c)end
return
end
b.closePicker()
local a=k.button("call")
if not a then return end
if not j[a]then
j[a]=true
a:HookScript("OnClick",o)

a:HookScript("OnHide",b.closePicker)
q(a)
end
r(a)
e(a,c)
end)


local function e(a)return n.nameOf(d[a])or v[a]end
k.addTipLines("sets",function(d,a)
if d~="call"then return end
if b.count()<2 then return end
local b=p()
a:AddLine("Click: "..e(b[1]),1,0.82,0,true)
for c,d in ipairs(x)do
local b=b[c+1]
if b and g(b)then a:AddLine(d..": "..e(b),1,0.82,0,true)end
end
if i.inCombat()then
a:AddLine("Totem sets switch out of combat",0.6,0.6,0.6)
elseif c()then
a:AddLine("Right-click: next totem set",1,0.82,0,true)
else
a:AddLine("Right-click or Alt+click: choose a totem set",1,0.82,0,true)
end
end)


f.part("sets",{
order=71,
stopped=b.closePicker,
describe=function()
local a=m.char()
return{string.format("sets: active %d (saved %s), known %d, picker %s",h,tostring(a and a.totemSet or 1),
b.count(),b.pickerShown()and"open"or"closed")}
end,
})
