


local a,e=...
local g,C,s,y,m,D,t,d,E,F=e.Schema,e.Store,e.Specials,e.Media,e.Art,
e.Layers,e.Ticker,e.Debug,e.PreviewMode,e.Combat

local a={}
e.CombatText=a

local n="combatText"
a.KEY=n

d.experimental("scrolling combat text: a frame holding secret text moved, faded and scaled by its own animation"
.." group in a fight (FR-9 proves animations on our frames, FR-27 a secret drawn as text; the two together"
.." unseen)","I")


local u="a1"
local c=20
a.MAX_AREAS=c
local B=20
local G,H=1.5,0.2
local I=3




local f={
{"physical","Physical damage","damage","#ff1a1a"},
{"spell","Spell damage","damage","#c94dd9"},
{"miss","Miss","avoided","#ffffff"},
{"dodge","Dodge","avoided","#ffffff"},
{"parry","Parry","avoided","#ffffff"},
{"block","Block","avoided","#ffffff"},
{"resist","Resist","avoided","#ffffff"},
{"absorb","Absorb","avoided","#ffffff"},
{"immune","Immune","avoided","#ffffff"},
{"evade","Evade","avoided","#ffffff"},
{"deflect","Deflect","avoided","#ffffff"},
{"reflect","Reflect","avoided","#ffffff"},
{"heal","Heals","healing","#1aff1a"},
{"healOverTime","Heals over time","healing","#1aff1a"},
{"shield","Shields gained","healing","#1aff1a"},
{"gain","Mana, rage and energy gained","gains","#69ccf0"},
{"buffStart","Buff gained","auras","#1aff1a",false},
{"buffEnd","Buff faded","auras","#1aff1a",false},
{"debuffStart","Debuff gained","auras","#ff1a1a"},
{"debuffEnd","Debuff faded","auras","#ff1a1a",false},
{"ability","Ability became usable","abilities","#ffd100"},
{"combatStart","Entering combat","combat","#ff1a1a",false},
{"combatEnd","Leaving combat","combat","#ff1a1a",false},
{"reputation","Reputation","rewards","#8080ff",false},
{"honour","Honour","rewards","#8080ff",false},
}
a.EVENTS=f
a.HEADINGS={
{key="damage",title="Damage you take"},
{key="avoided",title="Avoided"},
{key="healing",title="Healing you get"},
{key="gains",title="Gains"},
{key="auras",title="Buffs and debuffs"},
{key="abilities",title="Abilities"},
{key="combat",title="Combat"},
{key="rewards",title="Rewards"},
}



g.record("combatTextPosition",{fields={
{name="point",type="point",default="CENTER",label="Anchor"},
{name="x",type="number",default=0,min=-4000,max=4000,step=0.5,control="edit",label="X"},
{name="y",type="number",default=112,min=-4000,max=4000,step=0.5,control="edit",label="Y"},
}})

g.record("combatTextArea",{fields={

{name="id",type="string",max=16,default=u,label="Id"},
{name="name",type="string",max=32,section="place",label="Name"},

{name="position",type="record",record="combatTextPosition",keepEmpty=true,label="Place"},
{name="width",type="number",default=300,min=40,max=1200,step=10,unit="px",section="place",
label="Width"},
{name="height",type="number",default=225,min=40,max=1200,step=5,unit="px",section="place",
label="Height",help="How far a line travels. In unlock mode, drag an area's corner to size it."},
{name="motion",type="choice",choices={"straight","arc","stay"},default="straight",
labels={straight="Straight",arc="Arc",stay="Stay in place"},section="motion",label="Motion"},
{name="direction",type="choice",choices={"up","down"},default="up",
labels={up="Up",down="Down"},section="motion",label="Direction"},
{name="curve",type="choice",choices={"alternate","left","right"},default="alternate",
labels={alternate="Left and right in turn",left="Left",right="Right"},
under={"motion","arc"},section="motion",label="Curves to"},
{name="align",type="choice",choices={"left","centre","right"},default="centre",
labels={left="Left",centre="Centre",right="Right"},section="motion",label="Align"},
{name="time",type="number",default=1.9,min=0.5,max=5,step=0.1,unit="s",section="motion",
label="Time on screen"},
{name="fade",type="number",default=0.6,min=0,max=2,step=0.1,unit="s",section="motion",
label="Fades over",help="The last part of its time on screen."},
{name="gap",type="number",default=4,min=0,max=40,step=1,unit="px",section="motion",
label="Space between lines"},
{name="size",type="number",default=25,min=8,max=72,step=1,unit="px",section="look",
label="Text size"},
{name="opacity",type="percent",default=100,min=20,max=100,section="look",label="Opacity"},
{name="critSize",type="number",default=1.2,min=1,max=2.5,step=0.05,unit="x",section="crit",
label="Critical hits bigger by"},
{name="critPop",type="boolean",default=true,section="crit",label="Critical hits pop",
help="A critical hit starts larger and quickly settles to its size."},
{name="critStays",type="boolean",default=false,section="crit",label="Critical hits stay in place"},
{name="critStars",type="boolean",default=false,section="crit",label="Stars around critical hits",
help="A critical hit's number shows between two stars, like *1,245*."},

{name="styles",type="record",record="ownStyles",parts={"font"},section="style",label="Style"},
}})


local function b(a,b)
local a=rawget(_G,"COMBAT_TEXT_"..a)or rawget(_G,a)
return type(a)=="string"and a or b
end

local o={
miss=b("MISS","Miss"),dodge=b("DODGE","Dodge"),parry=b("PARRY","Parry"),
block=b("BLOCK","Block"),resist=b("RESIST","Resist"),absorb=b("ABSORB","Absorb"),
immune=b("IMMUNE","Immune"),evade=b("EVADE","Evade"),deflect=b("DEFLECT","Deflect"),
reflect=b("REFLECT","Reflect"),
combatStart=b("ENTERING_COMBAT","+Combat"),combatEnd=b("LEAVING_COMBAT","-Combat"),
}
a.words=o
d.experimental("scrolling combat text: an event's own words in place of the game's (each event's line by its own"
.." Text, unplayed)","I")

local v,d={},{}
for e,a in ipairs(f)do
local b=a[1]
v[b]={key=b,label=a[2],heading=a[3]}
local c={
{name="shown",type="boolean",default=a[5]~=false,label=a[2]},

{name="areas",type="list",of="string",item={max=16},maxItems=c,label="Areas"},
}
if o[b]then

c[#c+1]={name="text",type="string",max=32,under={"shown",true},section="row",
label="Text",help="Left empty, it shows the game's own word: \""..o[b].."\"."}
end
for b,a in ipairs({
{name="colour",type="colour",default=a[4],under={"shown",true},section="row",
label="Colour"},
{name="size",type="number",default=100,min=50,max=200,step=5,unit="%",
under={"shown",true},section="row",label="Size"},
{name="rate",type="number",default=0,min=0,max=10,step=1,under={"shown",true},
section="row",label="Most lines a second",help="0 means no limit."},
})do c[#c+1]=a end
g.record("combatTextEvent:"..b,{fields=c})
d[e]={name=b,type="record",record="combatTextEvent:"..b,label=a[2]}
end
g.record("combatTextEvents",{fields=d})
function a.event(a)return v[a]end

g.record("combatText",{refusable=true,fields={
{name="enabled",type="boolean",default=false,label="Scrolling combat text",
help="Text that appears in areas on your screen for incoming damage, heals and other events."},
{name="numberFormat",type="choice",choices={"full","short"},default="full",
labels={full="Full (1,234)",short="Short (1.2k)"},section="general",label="Number format"},
{name="signs",type="boolean",default=true,section="general",label="Plus and minus signs",
help="A minus before damage and a plus before heals and gains."},

{name="names",type="boolean",default=false,section="general",label="Healer's name"},
{name="outOfCombat",type="boolean",default=true,section="general",label="Show out of combat"},

{name="areas",type="list",record="combatTextArea",maxItems=c,default={{}},
label="Areas"},
{name="events",type="record",record="combatTextEvents",label="Events"},
}})
g.record("specials",{fields={{name="combatText",type="record",record="combatText",
label="Scrolling combat text"}}})



local c
local f=false
local j,w=false,false
local function p()return j or w end
local i,q,z=false,false,0
local k=false
local d




local b,h,x={},{},{}
a.areas=h
local l={}
local r=0
local A={}


function a.word(b)
local a=c and c.events[b]
local a=a and a.text
if a~=nil and a~=""then return a end
return o[b]
end

function a.areaName(a,b)return a.name~=nil and a.name~=""and a.name or("Area "..b)end
function a.FIRST()return u end



local function o(a)
a.busy=false
a.frame:Hide()
end

local function J(a)
local b=CreateFrame("Frame",nil,a.frame)
b:SetSize(1,1)
b:Hide()
local a={frame=b,busy=false,born=0}
a.fs=b:CreateFontString(nil,"OVERLAY")

a.fs:SetFont(STANDARD_TEXT_FONT,12,"OUTLINE")
local b=b:CreateAnimationGroup()
b:SetToFinalAlpha(true)
a.group=b
a.rise=m.anim(b,"Translation")
a.drift=m.anim(b,"Translation")
a.drift:SetSmoothing("IN")
a.fade=m.anim(b,"Alpha")
a.fade:SetFromAlpha(1)
a.fade:SetToAlpha(0)



a.pop=m.anim(b,"Scale")
a.pop:SetScaleTo(1,1)
a.pop:SetDuration(H)
a.pop:SetSmoothing("OUT")
b:SetScript("OnFinished",function()o(a)end)
return a
end


local function H(a)
local b
for c=1,a.n do
local a=a.lines[c]
if not a.busy then return a end
if not b or a.born<b.born then b=a end
end
if a.n<B then
a.n=a.n+1
a.lines[a.n]=J(a)
return a.lines[a.n]
end
b.group:Stop()
return b
end

local m={left="LEFT",centre="CENTER",right="RIGHT"}
local J={up={left="BOTTOMLEFT",centre="BOTTOM",right="BOTTOMRIGHT"},
down={left="TOPLEFT",centre="TOP",right="TOPRIGHT"}}


local function K(a,b,...)
if select("#",...)==0 then a:SetText(b)else a:SetFormattedText(b,...)end
end



local L=setmetatable({},{__index=function(b,a)
b[a]=(a:gsub("^(.-%%s)","*%1*",1))
return b[a]
end})
local M={damage=true,healing=true}



local function B(b,a,f,g,...)
local c,h=b.view,c.events[a]
if f and c.critStars and M[v[a].heading]and select("#",...)>0 then g=L[g]end
local k=GetTime()
local i=c.size*(h.size or 100)/100*(f and c.critSize or 1)
local a=H(b)
r=r+1

a.busy,a.born=true,r
if a.slot then
if b.slots[a.slot]==a then b.slots[a.slot]=nil end
a.slot=nil
end
local d=a.fs
y.setFont(d,c.styles.font,i)
d:SetTextColor(y.rgba(h.colour))
if not e.try("combat text line",K,d,g,...)then return o(a)end
local g,l=c.align,c.direction~="down"
local h=l and 1 or-1
local e=i+c.gap
local p=c.motion=="stay"or(f and c.critStays)
local i
local n,j=0,0
if p then

local c=math.max(1,math.floor(c.height/e))
b.slot=b.slot%c+1
local c=b.slots[b.slot]
if c and c.busy then
c.group:Stop()
o(c)
c.slot=nil
end
b.slots[b.slot],a.slot=a,b.slot
i=h*(b.slot-1)*e
else


local d=c.height/c.time
local a=0
if b.lastAt then a=math.min(0,b.lastOff+d*(k-b.lastAt)-e)end
a=math.max(a,-I*e)
b.lastAt,b.lastOff=k,a
i,n=h*a,h*c.height
if c.motion=="arc"then
j=c.curve=="left"and-1 or c.curve=="right"and 1 or b.flip
b.flip=-b.flip
end
end
local e=a.frame
e:ClearAllPoints()
e:SetPoint("CENTER",b.frame,J[l and"up"or"down"][g],0,i)
d:ClearAllPoints()
d:SetPoint(m[g],e,"CENTER",0,0)
d:SetJustifyH(m[g])
local b=c.time

local d=math.max(math.min(c.fade,b),0.01)
a.rise:SetOffset(0,n)
a.rise:SetDuration(b)
a.rise:SetSmoothing(j~=0 and"OUT"or"NONE")
a.drift:SetOffset(j*c.width/2,0)
a.drift:SetDuration(b)
a.fade:SetStartDelay(b-d)
a.fade:SetDuration(d)


local b=f and c.critPop and G or 1
a.pop:SetScaleFrom(b,b)
e:SetAlpha(1)
e:Show()
a.group:Stop()
a.group:Play()
end


local function m(a,c,d,e,...)
local a,f=a.areas,false
for b=1,a and#a or 0 do
local a=h[a[b]]
if a then
f=true
B(a,c,d,e,...)
end
end
if not f and b[1]then B(b[1],c,d,e,...)end
end



function a.show(b,d,e,...)
if not(f and c)or p()then return end
local a=c.events[b]
if not(a and a.shown)then return end
if not c.outOfCombat and not F.inCombat()and not k then return end
if a.rate>0 and not k then
local c,d=GetTime(),A[b]
if d and c-d<1/a.rate then return end
A[b]=c
end
m(a,b,d,e,...)
end


function a.notice(b)
if not(f and c)or p()then return end
local c=c.events[b]
if c and c.shown then m(c,b,false,a.word(b))end
end

function a.view()return f and c or nil end



local function m(a)
for b=1,a.n do
local a=a.lines[b]
if a.busy then
a.group:Stop()
o(a)
end
a.slot=nil
end
wipe(a.slots)
a.lastAt,a.slot=nil,0
end

local function y(a,d,e)
local c=a.view
local b=c.position
a.frame:ClearAllPoints()
a.frame:SetPoint(b.point,UIParent,b.point,d or b.x,e or b.y)
a.frame:SetSize(c.width,c.height)
end

local function o(b)
return C.editSpecial(n,function(a)

a.areas=a.areas or{{}}
return b(a)
end)
end
a.edit=o
local function v(a,b)
for c,a in ipairs(a.areas)do
if(a.id or u)==b then return a,c end
end
end
a.recordArea=v


function a.setSize(e,c,d)
local a,b=g.field("combatTextArea","width"),g.field("combatTextArea","height")
c=math.min(a.max,math.max(a.min,math.floor(c/a.step+0.5)*a.step))
d=math.min(b.max,math.max(b.min,math.floor(d/b.step+0.5)*b.step))
return o(function(a)
local a=v(a,e)
if a then a.width,a.height=c,d end
end)
end




local function g()
local b,c=GetCursorPosition()
local a=UIParent:GetEffectiveScale()
return b/a,c/a
end
local function A(a)
local b,a=a.area,a.drag
local c,d=g()
a.w=math.max(40,a.w0+(c-a.x0)*a.kx)
a.h=math.max(40,a.h0-(d-a.y0)*a.ky)
b.frame:SetSize(a.w,a.h)
end
local function u(c)
if c.grip then return c.grip end
local b=CreateFrame("Button",nil,c.frame)
b:SetSize(14,14)
b:SetPoint("BOTTOMRIGHT",c.frame,"BOTTOMRIGHT",0,0)

b:SetFrameStrata("FULLSCREEN")
local d=b:CreateTexture(nil,"OVERLAY")
d:SetAllPoints()
d:SetColorTexture(1,0.82,0,0.9)
b.area,b.drag=c,{}
b:SetScript("OnMouseDown",function(d)
local a,b=d.drag,d.area.view
local c=b.position.point
a.x0,a.y0=g()
a.w0,a.h0,a.w,a.h=b.width,b.height,b.width,b.height
a.kx=c:find("LEFT")and 1 or c:find("RIGHT")and 0 or 2
a.ky=c:find("TOP")and 1 or c:find("BOTTOM")and 0 or 2
d:SetScript("OnUpdate",A)
end)
b:SetScript("OnMouseUp",function(b)
if not b:GetScript("OnUpdate")then return end
b:SetScript("OnUpdate",nil)
a.setSize(b.area.id,b.drag.w,b.drag.h)
end)
b:SetScript("OnHide",function(a)a:SetScript("OnUpdate",nil)end)
c.grip=b
return b
end

local function A(a)
m(a)
a.frame:Hide()
if a.grip then a.grip:Hide()end
h[a.id]=nil
x[#x+1]=a
end

local function B()
if not(f and c)then return end
local e={}
for a=#b,1,-1 do
e[b[a].id]=b[a]
b[a]=nil
end
wipe(l)
for f,d in ipairs(c.areas)do

if d.id~=nil and not h[d.id]or e[d.id]then
local c=e[d.id]
e[d.id]=nil
if not c then
c=table.remove(x)
if not c then
local a=CreateFrame("Frame",nil,UIParent)
a:SetFrameLevel(D.BASE_LEVEL)
c={frame=a,lines={},n=0,flip=1,slot=0,slots={},lastOff=0,box={}}
end
c.id=d.id
h[d.id]=c
end
c.view=d
y(c)
c.frame:SetAlpha(d.opacity/100)
c.frame:Show()
if i then u(c):Show()elseif c.grip then c.grip:Hide()end
local e=c.box
e.id,e.label,e.w,e.h,e.position=d.id,a.areaName(d,f),d.width,d.height,d.position

e.open=true
b[#b+1]=c
l[#l+1]=e
end
end
for b,a in pairs(e)do A(a)end
s.laidOut()
end




local x,g=0,0
local function C(a)
k=true
d.sample(a)
k=false
end
local function D()
if not f then return end
if not(i or q)and GetTime()>=z then
t.unsubscribe(0.1,"combat text samples")
return
end
local a=GetTime()
if a<x or p()then return end
x=a+0.45

for a=1,d and d.samples or 0 do
g=g%d.samples+1
local a=c.events[d.sampleEvent(g)]
if a and a.shown then
if not e.try("combat text sample",C,g)then k=false end
return
end
end
end
local function e()
if f then t.subscribe(0.1,"combat text samples",D)end
end

function a.test(a)
if not f then return false end
z=GetTime()+(a or 6)
e()
return true
end


function a.number(a)
if c and c.numberFormat=="short"then return AbbreviateNumbers(a)end
return BreakUpLargeNumbers(a)
end

E.register(n,{
show=function()
q=true
e()
end,
hide=function()q=false end,
})



function a.setFeed(a)d=a end

local function g(a)
c,f,j=a,true,false
B()
if d then d.start(a)end
if i or q then e()end
end


local function k(a)
c,j=a,false
B()
if d then d.apply(a)end
end

local function q()
f,c,j=false,nil,false
if d then d.stop()end
t.unsubscribe(0.1,"combat text samples")
for a=#b,1,-1 do
A(b[a])
b[a]=nil
end
wipe(l)
s.laidOut()
end

local function t()
local c={}
for f,d in ipairs(b)do
local b,e=d.view,d.view.position
c[#c+1]=string.format("%s (%s): %s %s, %d x %d at %s %.1f %.1f, %d lines made",a.areaName(b,f),
d.id,b.motion,b.direction,b.width,b.height,e.point,e.x,e.y,d.n)
end
c[#c+1]=r.." lines shown this session"..(p()and", quiet"or"")
for b,a in ipairs(d and d.describe()or{})do c[#c+1]=a end
return c
end

s.register(n,{
label="Scrolling combat text",icon=132333,
experimental=true,
start=g,
apply=k,
stop=q,

stopping=function()
j=true
for b,a in ipairs(b)do m(a)end
end,
placing=function(a)
i=a and true or false
for b,a in ipairs(b)do
if i then u(a):Show()elseif a.grip then a.grip:Hide()end
end
if i then e()end
end,

cantAct=function(a)
w=a=="hide"
if w then
for b,a in ipairs(b)do m(a)end
end
end,

boxes=function()return f and l or nil end,
moveTo=function(b,d,a)
local a=h[a]
if a and c then y(a,b,d)end
end,
commit=function(c,d,a)
local b=h[a]
if not b then return false end
local b=b.view.position.point
return o(function(e)
local a=v(e,a)
if a then a.position={point=b,x=c,y=d}end
end)
end,
describe=t,
})
