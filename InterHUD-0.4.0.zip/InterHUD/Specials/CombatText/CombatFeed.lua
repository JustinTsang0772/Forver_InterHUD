


local a,b=...
local a,m,n,c=b.CombatText,b.Events,b.Combat,b.Debug

c.experimental("scrolling combat text: COMBAT_TEXT_UPDATE with C_CombatText.GetCurrentEventInfo read by an addon"
.." (hits first and heals at once against UNIT_COMBAT, CA-7; its returns documented SecretReturns, a heal's"
.." amount and healer's name seen secret; whether it comes with the game's own text off untested)","C")
c.experimental("scrolling combat text: a secret name drawn through SetFormattedText (FR-27 proves numbers and"
.." their strings; a name unseen), each line's values counted and never nil-tested (SE-4)","D")

local e
local f=b.isSecret

local j=a.word

local function c(a,b)
local a=rawget(_G,a)
a=type(a)=="string"and a or b
return(a:gsub("%%%d*%$?[di]","%%s"))
end
local o={block=c("BLOCK_TRAILER"," (%s blocked)"),resist=c("RESIST_TRAILER"," (%s resisted)"),
absorb=c("ABSORB_TRAILER"," (%s absorbed)")}

local u="%s"..o.absorb
local v=" ("..a.words.absorb..")"
local w=c("AURA_END","<%s> fades")
local x=c("COMBAT_TEXT_HONOR_GAINED","%s Honor")

local function k()return e.signs and"-%s"or"%s"end
local function g()return e.signs and"+%s"or"%s"end


local d={}
local function y(b,c,e,g)
local a=d[b]
if not a then
a={0,0,0,0}
d[b]=a
end
a[1]=a[1]+1
if f(c)then a[2]=a[2]+1 end
if f(e)then a[3]=a[3]+1 end
if f(g)then a[4]=a[4]+1 end
end

local p={DAMAGE="physical",DAMAGE_CRIT="physical",SPELL_DAMAGE="spell",SPELL_DAMAGE_CRIT="spell",
DAMAGE_SHIELD="spell",SPLIT_DAMAGE="physical"}
local i={DAMAGE_CRIT=true,SPELL_DAMAGE_CRIT=true,HEAL_CRIT=true,PERIODIC_HEAL_CRIT=true,
HEAL_CRIT_ABSORB=true}
local l={HEAL="heal",HEAL_CRIT="heal",HEAL_ABSORB="heal",HEAL_CRIT_ABSORB="heal",
PERIODIC_HEAL="healOverTime",PERIODIC_HEAL_CRIT="healOverTime",PERIODIC_HEAL_ABSORB="healOverTime"}
local q={BLOCK="block",SPELL_BLOCK="block",ABSORB="absorb",SPELL_ABSORB="absorb",
RESIST="resist",SPELL_RESIST="resist"}
local h={}
for b,a in ipairs({"MISS","DODGE","PARRY","EVADE","IMMUNE","DEFLECT","REFLECT"})do
h[a],h["SPELL_"..a]=a:lower(),a:lower()
end
local r={SPELL_AURA_START="buffStart",SPELL_AURA_START_HARMFUL="debuffStart",
SPELL_AURA_END="buffEnd",SPELL_AURA_END_HARMFUL="debuffEnd"}



local c={HEAL=true,HEAL_CRIT=true,HEAL_ABSORB=true,HEAL_CRIT_ABSORB=true}
local function z(b,a)
if not(e.names and c[b])or f(a)then return false end
return type(a)=="string"and a~=UnitName("player")
end


local function s(a)return not f(a)and type(a)=="number"and a<=0 end


local function t(b,c,d,m)
if p[b]then
if i[b]or not s(c)then a.show(p[b],i[b],k(),a.number(c))end
elseif q[b]then
local g=q[b]


if d==nil then
a.show(g,false,j(g))
elseif not e.events[g].shown then
local d=not f(m)and m and true or false
a.show(b:find("^SPELL")and"spell"or"physical",d,k(),a.number(c))
elseif g=="absorb"and(f(c)or c==0)then

a.show(g,false,u,j(g),a.number(d))
else
a.show(g,false,k()..o[g],a.number(c),a.number(d))
end
elseif h[b]then
a.show(h[b],false,j(h[b]))
elseif l[b]then
if z(b,c)then
a.show(l[b],i[b],g().." [%s]",a.number(d),c)
else
a.show(l[b],i[b],g(),a.number(d))
end
elseif b=="ENERGIZE"or b=="PERIODIC_ENERGIZE"then
if s(c)then return end
local b=not f(d)and type(d)=="string"and rawget(_G,d)
if type(b)=="string"then
a.show("gain",false,g().." %s",a.number(c),b)
else
a.show("gain",false,g(),a.number(c))
end
elseif b=="ABSORB_ADDED"then
a.show("shield",false,g()..v,a.number(d))
elseif r[b]then
local b=r[b]
a.show(b,false,(b=="buffEnd"or b=="debuffEnd")and w or"<%s>",c)
elseif b=="SPELL_ACTIVE"then
a.show("ability",true,"<%s>",c)
elseif b=="FACTION"then
local b=not f(d)and type(d)=="number"and d>0
a.show("reputation",false,b and"(%s +%s)"or"(%s %s)",c,d)
elseif b=="HONOR_GAINED"then
a.show("honour",false,x,c)
end
end

local function g(c,a)
if f(a)or type(a)~="string"or not e then return end
local c,d,e=C_CombatText.GetCurrentEventInfo()
y(a,c,d,e)
b.try("combat text feed "..a,t,a,c,d,e)
end





local f=1126
local function c(c)return b.Spells.nameOf(f)or a.event(c).label end
local c={
{"physical","DAMAGE",87},{"spell","SPELL_DAMAGE_CRIT",1412},{"dodge","DODGE"},
{"heal","HEAL",nil,240},{"spell","SPELL_DAMAGE",156},{"gain","ENERGIZE",64},
{"miss","MISS"},{"physical","DAMAGE_CRIT",503},{"healOverTime","PERIODIC_HEAL",nil,38},
{"parry","PARRY"},{"block","BLOCK",45,30},{"heal","HEAL_CRIT",nil,1731},
{"debuffStart","SPELL_AURA_START_HARMFUL",c},{"resist","SPELL_RESIST",90,60},
{"shield","ABSORB_ADDED",nil,120},{"buffStart","SPELL_AURA_START",c},
{"absorb","ABSORB",0,120},{"ability","SPELL_ACTIVE",c},{"immune","IMMUNE"},
{"debuffEnd","SPELL_AURA_END_HARMFUL",c},{"evade","EVADE"},{"deflect","DEFLECT"},
{"buffEnd","SPELL_AURA_END",c},{"reflect","REFLECT"},{"combatStart","notice"},
{"honour","HONOR_GAINED",12},{"combatEnd","notice"},
{"reputation","FACTION",function(b)return a.event(b).label end,25},
}
local function f(b)
local b=c[b]
if b[2]=="notice"then return a.notice(b[1])end
local a=b[3]
if type(a)=="function"then a=a(b[1])end
t(b[2],a,b[4],b[5])
end



local function h()
if not(C_CombatText and C_CombatText.GetCurrentEventInfo)then return end


if C_CombatText.SetActiveUnit and not(C_CombatText.GetActiveUnit and C_CombatText.GetActiveUnit())then
b.try("combat text active unit",C_CombatText.SetActiveUnit,"player")
end
m.on("COMBAT_TEXT_UPDATE","combatText",g)
end

n.onStart("combatText",function()if e then a.notice("combatStart")end end)
n.onEnd("combatText",function()if e then a.notice("combatEnd")end end)

a.setFeed({
start=function(a)
e=a
h()
end,
apply=function(a)e=a end,
stop=function()
e=nil
m.off("COMBAT_TEXT_UPDATE","combatText")
end,
samples=#c,
sampleEvent=function(a)return c[a][1]end,
sample=f,
describe=function()
local b,a={},{}
for a in pairs(d)do b[#b+1]=a end
table.sort(b)
for b,c in ipairs(b)do
local b=d[c]
a[#a+1]=string.format("COMBAT_TEXT_UPDATE %s: %d seen, secret %d / %d / %d",c,b[1],b[2],b[3],
b[4])
end
if#a==0 then a[1]="no combat event heard yet"end
return a
end,
})
