


local a,g=...
local h,d,m,n,s,c=g.Kit,g.Form,g.Specials,g.Store,g.StyleArea,g.CombatText

local b={}
g.CombatPage=b

local f=c.KEY

b.GAME_TEXT="If the game's own combat text is also switched on, you will see two sets of combat text."
b.AREAS="Each area is a place on your screen where lines show. An event shows in the areas ticked in its"
.." \"Areas\" setting, or in the first area."
b.OFF="Switch on \"Scrolling combat text\" above to change its settings."
b.TABS={{key="general",label="General"},{key="areas",label="Areas"},
{key="events",label="Events"}}


local e,a
g.onChanged(function()e,a=nil,nil end,"page combat text")
local function i()
if not e then e=d.specialView(f)end
return e
end
local function e()return i()and i().areas or{}end

local function k()
if a==nil then
a=false
for c,b in ipairs(m.list())do
if b.key==f then a=b.state=="on"end
end
end
return a
end


local j="general"
local o={}
function b.tab(a)
if a then j=a end
return j
end
local function p(a)return function()return k()and j==a end end

local function q(b,c)
local a={}
for b,c in ipairs(b)do a[b]=c end
for c,b in ipairs(c)do a[#a+1]=b end
return a
end



local function l(b,a,g,k,j)
local function e()return d.read(i()or{},g())end
local function c()
local b=e()
return k()and b~=nil and d.shown(a,b)
end
if a.heading then return b:subhead(a.label,nil,c)end
local function k()
local b=d.read(e(),a.path)
if a.widget=="choice"and b==nil then return d.NONE end
return b
end
local function i(b)
if a.widget=="choice"and b==d.NONE then b=nil end
return(d.setSpecial(f,q(g(),a.path),b))
end

if a.field and a.field.type=="string"then
local function f()return j and j(a)or""end
b:addRow(h.textbox(b.content,a.label,nil,function()return d.read(e(),a.path)or f()end,
function(a)return i(a~=""and a~=f()and a or nil)end,
{maxLetters=a.field.max}),c)
if a.field.help then b:hint(a.field.help,nil,c)end
return
end
local f={}
if a.widget=="choice"then
f.choices=function()
local b,c=d.choices(a,e())
local a={}
for d,b in ipairs(b)do a[d]={b,c[b]}end
return a
end
end
local d=h.fieldRow(b.content,a,k,i,f)
if not d then return end
b:addRow(d,c)
if a.field and a.field.help then b:hint(a.field.help,nil,c)end
end


local function r(c,b,a,e,f)
for d,b in ipairs(d.recordSections(b,d.read(i()or{},a())or{}))do
if not b.style then
for d,b in ipairs(b.rows)do
if#b.path==1 then l(c,b,a,e,f)end
end
end
end
end



local function l(a)
local b={}
for d,a in ipairs(a)do b[a.id or c.FIRST()]=true end
local a=2
while b["a"..a]do a=a+1 end
return"a"..a
end

function b.addArea()
local a=#e()
if a>=c.MAX_AREAS then return false end
local a=e()[a]
local b
local a=c.edit(function(c)
b=l(c.areas)
c.areas[#c.areas+1]={id=b,position={point="CENTER",
x=(a and a.position.x or 0)+40,y=(a and a.position.y or 0)-40}}
end)
if a then o[b]=false end
return a
end

function b.removeArea(b)
if#e()<=1 then return false end
return c.edit(function(a)
local b=table.remove(a.areas,b)
local c=b and(b.id or c.FIRST())
for b,a in pairs(a.events or{})do
for b=#(a.areas or{}),1,-1 do
if a.areas[b]==c then table.remove(a.areas,b)end
end
if a.areas and#a.areas==0 then a.areas=nil end
end
end)
end
function b.moveUp(a)
if a<=1 or a>#e()then return false end
return c.edit(function(b)b.areas[a-1],b.areas[a]=b.areas[a],b.areas[a-1]end)
end

function b.reset()
return n.editSpecial(f,function(a)
for b in pairs(a)do
if b~="enabled"then a[b]=nil end
end
end)
end

h.confirm("COMBAT_TEXT_REMOVE_AREA","Remove this area? Its events will show in the first area.","Remove",
function(a)b.removeArea(a)end)
h.confirm("COMBAT_TEXT_RESET","Put every setting of Scrolling combat text back as it first was? This also puts"
.." back the one area it starts with, and every event's settings.","Reset",function()b.reset()end)


local l={}
local function t(c,d)
l[c]=l[c]or{}
local a=l[c][d]
if not a then
a={}
if c>1 then a[#a+1]={text="Move up",click=function()b.moveUp(c)end}end
if c<d then a[#a+1]={text="Move down",click=function()b.moveUp(c+1)end}end
if d>1 then
a[#a+1]={text="Remove",click=function()h.showPopup("COMBAT_TEXT_REMOVE_AREA",nil,c)end}
end
l[c][d]=a
end
return a
end



local function u(g,b)
local l={"areas",b}
local function a()return e()[b]end
local function h()return k()and j=="areas"and a()~=nil end
local function j()return a()and(a().id or c.FIRST())or""end
local e=g:block({key="area:"..b,card=true,shown=h,
title=function()return a()and c.areaName(a(),b)or""end,
menu=function()return t(b,#e())end})
e.isFolded=function()
local a=o[j()]
if a==nil then return b>1 end
return a
end
e.onFold=function(a)o[j()]=a end

r(g,"combatTextArea",function()return l end,h,function(d)
return d.field.name=="name"and a()and c.areaName(a(),b)or nil
end)

for b,a in ipairs(d.recordSections("combatTextArea",a()or{}))do
if a.style then

local b={}
for c,a in ipairs(a.rows)do
if not(a.field and a.field.name=="size")then
b[#b+1]=setmetatable({path=q(l,a.path)},{__index=a})
end
end
local c=q(l,a.style.path)
g:subhead("Font",nil,h)
s.add(g,{part=a.part,path=c,rows=b,
view=function()return i()or{}end,
own=function()return d.read(n.special(f),c)end,
write=function(a,b,c)return d.setSpecial(f,a,b,c)end,
save=function(b,e)
return d.saveAsPreset({kind="special",key=f},a.part,c,b,e)
end,
parent=function()return"Global"end,
shown=h})
end
end
end


local function l(d,e,g)
return n.editSpecial(f,function(a)
a.events=a.events or{}
for c,b in ipairs(c.EVENTS)do
if b[3]==d then
a.events[b[1]]=a.events[b[1]]or{}
a.events[b[1]][e]=g
end
end
end)
end
b.setAll=l

local function q()
local a={}
for b,d in ipairs(e())do a[b]={d.id,c.areaName(d,b)}end
return a
end


local function n(b)
local a={}
for d,c in ipairs(e())do
for d,b in ipairs(b.areas or{})do
if b==c.id then a[#a+1]=b end
end
end
if#a==0 and e()[1]then a[1]=e()[1].id end
return a
end

local function o(h,g)
local function b(a)
for c,b in ipairs(n(g()))do
if b==a then return true end
end
return false
end
return{
has=b,
toggle=function(c)
local a={}
for d,b in ipairs(n(g()))do
if b~=c then a[#a+1]=b end
end
if not b(c)then a[#a+1]=c end
if#a==0 then return end
local b=e()[1]
if#a==1 and b and a[1]==b.id then a=nil end
d.setSpecial(f,{"events",h,"areas"},a)
end,
words=function()
local a={}
for e,d in ipairs(e())do
if b(d.id)then a[#a+1]=c.areaName(d,e)end
end
return table.concat(a,", ")
end,
}
end
b.areasMulti=o

h.registerPage(f,{build=function(a)
local n=m.get(f)
a:header({title=n.label,icon=n.icon,
note="Text that appears in areas on your screen for incoming damage, heals and other events.",
switch={title=n.label,get=k,set=function(a)return m.setOn(f,a)end}})
a:tabs(b.TABS,function()return j end,function(a)j=a end)
local function m()return{}end

a:block({key="off",shown=function()return not k()end})
a:text(b.OFF)

local j=p("general")
a:block({key="general",title="General",card=true,shown=j})
a:text(b.GAME_TEXT,j)
a:buttons({
{text="Test",tip="Plays sample lines for a few seconds: in each area, the events it shows.",click=function()c.test(6)end},
{text="Move the areas",tip="Opens unlock mode, where each area can be dragged and sized.",
click=function()g.Placement.setUnlocked(true)end},
},j)
r(a,"combatText",m,j)
a:buttons({{text="Reset to defaults",click=function()h.showPopup("COMBAT_TEXT_RESET")end,
tip="Puts every setting here back as it first was. It stays switched on."}},j)

local g=p("areas")
a:block({key="areas",shown=g})
a:text(b.AREAS,g)
for b=1,c.MAX_AREAS do
a:lazy(function()return g()and b<=#e()end,function()u(a,b)end)
end
a:block({key="add area",shown=g})
a:buttons({
{text="Add an area",click=function()b.addArea()end,
enabled=function()return#e()<c.MAX_AREAS end},
},g)

local b=p("events")
for j,g in ipairs(c.HEADINGS)do
a:block({key="events:"..g.key,title=g.title,card=true,shown=b})
a:buttons({
{text="Show all",click=function()l(g.key,"shown",true)end},
{text="Hide all",click=function()l(g.key,"shown",false)end},
},b)
for c,j in ipairs(c.EVENTS)do
if j[3]==g.key then
local c=j[1]
local function k()return{"events",c}end
local function g()return i()and i().events[c]or{}end
local function i()return b()and g().shown==true end


a:subhead(j[2],nil,b)
a:addRow(h.checkbox(a.content,"Shown",nil,function()return g().shown==true end,
function(a)return(d.setSpecial(f,{"events",c,"shown"},a and true or false))end),b)
a:addRow(h.dropdown(a.content,"Areas",nil,nil,nil,
{choices=q,multi=o(c,g)}),
function()return i()and#e()>1 end)
r(a,"combatTextEvent:"..c,k,b)
end
end
end
a:endBlock()
end})
